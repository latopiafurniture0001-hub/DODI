ALUR PRODUKSI NYATA PK01 -> DODI

1. Order dibuat.
2. Varian dikunci dan stok dibaca dari database.
3. Stok cukup: stok dikurangi sesuai qty; TIDAK dibuat Job CNC.
4. Stok sebagian: stok yang tersedia dikurangi; Job dibuat hanya untuk kekurangan.
5. Stok nol: Job dibuat sebesar seluruh kebutuhan.
6. Job dibuat setelah transaksi order + mutasi stok berhasil COMMIT.
7. DODI mengambil Job status planned melalui API.
8. DODI membuat CAM/G-code.
9. DODI mengirim G-code ke PK01; Job menjadi gcode_ready.
10. Operator memeriksa mesin dan menjalankan CNC secara manual.
11. Hasil produksi menggunakan record_production_result() sehingga stok barang jadi bertambah melalui mekanisme produksi yang sudah ada.
12. Order kemudian dapat dilanjutkan ke packing/pengiriman.

KEAMANAN: API tidak menjalankan mesin CNC dari internet.

## v13.5 - Single Login
PK01 Operasional menjadi pintu login pengguna. DODI CNC dibuka dari Dashboard Operasional tanpa login kedua. Tombol per Job dapat membuka Job yang sama langsung di DODI CNC melalui parameter job_id.
