# PK01 v3.6.78 — Coding Map & Folder Maintenance

Tujuan: setiap pekerjaan memiliki **satu folder canonical** agar saat update/fix file mudah ditemukan. Jangan membuat file kedua untuk proses yang sama.

## 1. Struktur canonical

```text
includes/
├── core/                         # Mesin lintas modul / shared services saja
│   ├── database, engine, workflow, authorization, audit
│   ├── registry, REST, bridge, settings, login, frontend
│   └── PDF & health/ops utilities
└── modules/
    ├── admin/
    │   ├── core/                 # mesin admin
    │   ├── activity/
    │   ├── administration/
    │   ├── dashboard-role/
    │   ├── documents/
    │   ├── master-data/
    │   ├── settings/
    │   └── users/
    ├── ai/
    │   ├── core/                 # engine AI/orchestrator
    │   ├── assistant/
    │   └── center/
    ├── customer-service/
    │   ├── core/
    │   ├── channels/
    │   └── dashboard/
    ├── finance/
    │   ├── core/                 # finance + expense workflow
    │   ├── cash/ closing/ capital/ operational-costs/ overview/ reports/
    ├── hr/
    │   ├── core/                 # attendance engine
    │   ├── attendance/ employees/ payroll/
    ├── inventory/
    │   ├── products/ materials/ stock/ management/ assets/
    ├── logistics/
    │   ├── core/                 # shipping-smart engine
    │   ├── packing/ shipping/ tracking/
    ├── marketplace/
    ├── owner/
    ├── production/
    │   ├── core/                 # DODI/CNC + job communication engine
    │   ├── jobs/ employee-jobs/ job-wages/
    ├── purchasing/
    ├── sales/
    │   ├── cashier/ customers/ pricing/
    ├── security/
    │   ├── core/ dashboard/
    ├── seller/
    │   ├── core/                 # affiliate engine
    │   ├── management/ portal/ register/
    └── warehouse/
        ├── dashboard/            # pintu barang / kontrol gudang
        ├── inbound-supplier/
        ├── outbound/
        └── returns/              # SEMUA retur fisik
```

## 2. Aturan: cari berdasarkan pekerjaan

| Pekerjaan | Folder canonical | File utama saat ini |
|---|---|---|
| Retur fisik, scan, tanda terima, QC retur | `modules/warehouse/returns/` | `tampilan-retur.php` |
| Barang masuk/keluar gudang | `modules/warehouse/` | folder `dashboard/`, `inbound-supplier/`, `outbound/` |
| Produksi/job | `modules/production/jobs/` | `tampilan-produksi.php` |
| Penerimaan job karyawan | `modules/production/employee-jobs/` | `tampilan-penerimaan-job-karyawan.php` |
| Upah job | `modules/production/job-wages/` | `tampilan-upah-job.php` |
| CNC/DODI | `modules/production/core/` | `class-pk01-dodi-cnc.php` |
| Chat job DODI | `modules/production/core/` | `class-pk01-dodi-chat.php` |
| Produk/bahan/stok | `modules/inventory/` | subfolder sesuai fungsi |
| Packing | `modules/logistics/packing/` | `tampilan-packing.php` |
| Pengiriman/resi | `modules/logistics/shipping/` | `tampilan-pengiriman.php` |
| Tracking | `modules/logistics/tracking/` | `tampilan-lacak-resi.php` |
| Penjualan | `modules/sales/cashier/` | `tampilan-penjualan.php` |
| Seller | `modules/seller/` | subfolder sesuai fungsi |
| Keuangan/biaya | `modules/finance/` | subfolder sesuai fungsi |
| Karyawan/absensi/gaji | `modules/hr/` | subfolder sesuai fungsi |
| AI | `modules/ai/` | assistant/center/core |
| Security | `modules/security/` | core/dashboard |
| Administrasi sistem | `modules/admin/` | subfolder sesuai fungsi |

## 3. Mesin yang memang tetap di `core/`

Hanya kode yang benar-benar lintas pekerjaan, seperti DB, Engine, Kernel, Workflow, Authorization, Audit, Registry, REST, Settings, Login, Frontend, Bridge, Governance, Data Health, Backup, Idempotency, Duplicate Guard, dan utilitas bersama.

Mesin yang spesifik domain dipindahkan ke `modules/<domain>/core/` agar tidak tercecer di core global.

## 4. Retur adalah milik Gudang

Alur canonical: `Sales Order → Retur → Warehouse Scan → Tanda Terima → QC → Koreksi Seller/Tagihan → Stok → Laporan`.

Karena kejadian fisiknya diterima dan diproses Gudang, semua UI/proses retur harus berada di `modules/warehouse/returns/`. Jangan membuat `sales/returns/` atau `inventory/warehouse/`.

## 5. Prinsip update

1. Cari nama pekerjaan, bukan nama dashboard.
2. Update hanya folder canonical.
3. Jangan copy file ke folder lain untuk memperbaiki bug.
4. Jika logic benar-benar lintas modul, baru taruh di `includes/core/`.
5. Memindahkan file tidak boleh membuat tabel/database baru; semua tetap memakai Engine/DB PK01 yang sama.
