# PK01 Seller Payment v3.7.20

## Alur sederhana
1. Seller setor uang cash/transfer.
2. Kasir memilih Seller + nominal. Nomor invoice boleh kosong.
3. Transfer/QRIS wajib memakai referensi/bukti. Cash tidak memerlukan referensi eksternal karena PK01 membuat nomor setoran internal.
4. Keuangan menyetujui nilai. Maker tidak boleh approve.
5. Checker berbeda menerima/membukukan.
6. Saat receive, pembayaran dialokasikan ke invoice Seller tertua berdasarkan jatuh tempo; jika invoice dipilih, hanya invoice itu yang menerima.
7. AR dan kas final berubah satu kali pada tahap receive.

## Anti-double
- Referensi transfer tidak boleh pernah dipakai ulang.
- `seller_payments.deposit_id` mengikat setiap alokasi dengan satu dokumen setoran.
- Retry receive pada setoran yang sama ditolak.
- `cash_ledger` menggunakan reference setoran unik untuk mencegah kas masuk kedua.
- Pembayaran Seller dari transaksi kasir lama tidak dibuatkan kas kedua karena `apply_cashier_payment_to_seller_ar()` hanya mengalokasikan AR.
- Pembayaran melebihi total AR terbuka ditolak; PK01 tidak membuat AR negatif/kredit fiktif.
- Pembayaran cash Seller yang sudah diterima fisik Kasir dicatat sebagai `seller_cash_pending` untuk rekonsiliasi laci; bila ditolak, dibuat reversal. Jenis ini tidak dihitung lagi sebagai cash-in laporan periode.
