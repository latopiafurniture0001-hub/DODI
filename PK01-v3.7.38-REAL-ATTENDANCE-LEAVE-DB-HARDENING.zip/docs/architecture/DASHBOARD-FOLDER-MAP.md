# PK01 v3.7.8 — Dashboard → Folder Map

Gunakan tabel ini sebagai titik awal saat memperbaiki dashboard.

| Dashboard | Folder utama | File yang dicari pertama |
|---|---|---|
| Administrator | `includes/modules/admin/` | `dashboard-role/tampilan-dashboard-role.php` |
| Owner | `includes/modules/owner/` | `dashboard-owner/tampilan-dashboard-owner.php` |
| Gudang | `includes/modules/warehouse/` | `dashboard/tampilan-gudang.php` |
| Produksi | `includes/modules/production/` | `jobs/tampilan-produksi.php` |
| Kasir / Penjualan | `includes/modules/sales/` | `cashier/tampilan-penjualan.php` |
| Seller | `includes/modules/seller/` | `portal/tampilan-portal-penjual.php` |
| Pembelian | `includes/modules/purchasing/` | `purchase-orders/tampilan-pembelian.php` |
| Inventory | `includes/modules/inventory/` | `management/tampilan-inventory-management.php` |
| Packing / Pengiriman | `includes/modules/logistics/` | `packing/tampilan-packing.php` |
| Marketplace | `includes/modules/marketplace/` | `reconciliation/tampilan-marketplace.php` |
| Keuangan | `includes/modules/finance/` | `overview/tampilan-keuangan.php` |
| SDM | `includes/modules/hr/` | `employees/tampilan-karyawan.php` |
| Customer Service | `includes/modules/customer-service/` | `dashboard/tampilan-customer-service.php` |
| Security | `includes/modules/security/` | `dashboard/tampilan-security.php` |
| AI | `includes/modules/ai/` | `center/tampilan-ai-center.php` |

## Prinsip

- **Satu domain = satu folder canonical.**
- Dashboard, view, dan logic khusus domain tetap bersama.
- Engine/DB/Authorization/Workflow yang lintas domain tetap satu di `includes/core/`.
- Tidak ada copy class hanya untuk memudahkan pencarian.
- Memindahkan dokumentasi tidak mengubah runtime.
