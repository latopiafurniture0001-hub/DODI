# PK01 v3.7.0 — Canonical Folder & Maintenance Map

Dokumen ini adalah peta utama untuk maintenance. Saat memperbaiki sebuah dashboard/menu, cari berdasarkan **domain pekerjaan**, bukan berdasarkan nama file acak.

## 1. Domain → folder canonical

| Domain / pekerjaan | Folder canonical | Dashboard / view utama |
|---|---|---|
| Administrator | `includes/modules/admin/` | `dashboard-role/` |
| Seller | `includes/modules/seller/` | `portal/`, `management/`, `register/` |
| Gudang | `includes/modules/warehouse/` | `dashboard/`, `inbound-supplier/`, `outbound/`, `returns/` |
| Produksi | `includes/modules/production/` | `jobs/`, `employee-jobs/`, `job-wages/` |
| Penjualan / Kasir | `includes/modules/sales/` | `cashier/`, `customers/`, `pricing/` |
| Pembelian | `includes/modules/purchasing/` | `purchase-orders/`, `suppliers/` |
| Produk / Stok | `includes/modules/inventory/` | `products/`, `materials/`, `stock/`, `management/`, `assets/` |
| Packing / Pengiriman | `includes/modules/logistics/` | `packing/`, `shipping/`, `tracking/` |
| Marketplace | `includes/modules/marketplace/` | `reconciliation/`, `core/` |
| Keuangan | `includes/modules/finance/` | `cash/`, `overview/`, `reports/`, `closing/`, `capital/`, `operational-costs/` |
| SDM | `includes/modules/hr/` | `employees/`, `attendance/`, `payroll/` |
| Customer Service | `includes/modules/customer-service/` | `dashboard/`, `channels/`, `core/` |
| Security | `includes/modules/security/` | `dashboard/`, `core/` |
| Owner | `includes/modules/owner/` | `dashboard-owner/`, `capital/` |
| AI | `includes/modules/ai/` | `assistant/`, `center/`, `core/` |

## 2. Shared core

`includes/core/` hanya untuk layanan yang benar-benar lintas domain: DB, Business Engine, Kernel, Workflow, Authorization, Audit, Registry, REST, Settings, Login, Frontend, Bridge, Governance, Health, Backup, Idempotency, Duplicate Guard, PDF, dan utility bersama.

Jangan menyalin shared core ke domain tertentu.

## 3. Aturan update

### Contoh: update Dashboard Gudang

Cari dan ubah:

```text
includes/modules/warehouse/
├── dashboard/
├── inbound-supplier/
├── outbound/
└── returns/
```

Jika kebutuhan menyentuh permission/menu, ubah registry/authorization di `includes/core/` sebagai dependency lintas domain. Jangan membuat menu Gudang kedua.

### Contoh: update Seller

Cari:

```text
includes/modules/seller/
```

### Contoh: update Produksi

Cari:

```text
includes/modules/production/
```

## 4. Prinsip

- Satu Product Master.
- Satu Database.
- Satu Business Engine.
- Satu Job Engine.
- Satu Inventory Engine.
- Satu Sales Engine.
- Satu Finance Engine.
- Satu Dashboard/Presentation layer.
- Tidak ada dummy data.
- Tidak ada engine paralel.
- Tidak ada copy file untuk logic yang sama.
