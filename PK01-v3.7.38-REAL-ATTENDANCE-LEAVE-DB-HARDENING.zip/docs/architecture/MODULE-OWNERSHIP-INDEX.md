# PK01 v3.7.8 — MODULE OWNERSHIP INDEX

Dokumen ini adalah indeks maintenance. Setiap domain memiliki satu folder canonical. Jangan membuat copy logic di domain lain.

## admin
- Folder canonical: `includes/modules/admin/`
- File:
  - `includes/modules/admin/activity/tampilan-aktivitas.php`
  - `includes/modules/admin/administration/tampilan-administrasi.php`
  - `includes/modules/admin/core/class-pk01-admin.php`
  - `includes/modules/admin/dashboard-role/tampilan-dashboard-role.php`
  - `includes/modules/admin/documents/tampilan-dokumen.php`
  - `includes/modules/admin/master-data/tampilan-master-data.php`
  - `includes/modules/admin/settings/tampilan-pengaturan.php`
  - `includes/modules/admin/users/tampilan-pengguna.php`

## ai
- Folder canonical: `includes/modules/ai/`
- File:
  - `includes/modules/ai/assistant/tampilan-asisten-ai.php`
  - `includes/modules/ai/center/tampilan-ai-center.php`
  - `includes/modules/ai/core/class-pk01-ai-orchestrator.php`
  - `includes/modules/ai/core/class-pk01-ai.php`

## customer-service
- Folder canonical: `includes/modules/customer-service/`
- File:
  - `includes/modules/customer-service/channels/class-pk01-cs-channels.php`
  - `includes/modules/customer-service/core/class-pk01-customer-service.php`
  - `includes/modules/customer-service/dashboard/class-pk01-customer-service-dashboard.php`
  - `includes/modules/customer-service/dashboard/tampilan-customer-service.php`

## finance
- Folder canonical: `includes/modules/finance/`
- File:
  - `includes/modules/finance/capital/tampilan-modal.php`
  - `includes/modules/finance/cash/tampilan-kas.php`
  - `includes/modules/finance/closing/tampilan-tutup-periode.php`
  - `includes/modules/finance/core/class-pk01-expense-workflow.php`
  - `includes/modules/finance/core/class-pk01-finance.php`
  - `includes/modules/finance/operational-costs/tampilan-biaya-usaha.php`
  - `includes/modules/finance/overview/tampilan-keuangan.php`
  - `includes/modules/finance/reports/tampilan-laporan-keuangan.php`

## hr
- Folder canonical: `includes/modules/hr/`
- File:
  - `includes/modules/hr/attendance/tampilan-absensi.php`
  - `includes/modules/hr/core/class-pk01-hr-attendance.php`
  - `includes/modules/hr/employees/tampilan-karyawan.php`
  - `includes/modules/hr/payroll/tampilan-gaji.php`

## inventory
- Folder canonical: `includes/modules/inventory/`
- File:
  - `includes/modules/inventory/assets/tampilan-aset-inventory.php`
  - `includes/modules/inventory/management/tampilan-inventory-management.php`
  - `includes/modules/inventory/materials/tampilan-bahan.php`
  - `includes/modules/inventory/products/tampilan-produk.php`
  - `includes/modules/inventory/stock/tampilan-stok.php`

## logistics
- Folder canonical: `includes/modules/logistics/`
- File:
  - `includes/modules/logistics/core/class-pk01-shipping-smart.php`
  - `includes/modules/logistics/packing/tampilan-packing.php`
  - `includes/modules/logistics/shipping/tampilan-pengiriman.php`
  - `includes/modules/logistics/tracking/tampilan-lacak-resi.php`

## marketplace
- Folder canonical: `includes/modules/marketplace/`
- File:
  - `includes/modules/marketplace/core/class-pk01-marketplace-catalog.php`
  - `includes/modules/marketplace/reconciliation/tampilan-marketplace.php`

## owner
- Folder canonical: `includes/modules/owner/`
- File:
  - `includes/modules/owner/capital/tampilan-modal-pemilik.php`
  - `includes/modules/owner/dashboard-owner/tampilan-dashboard-owner.php`

## production
- Folder canonical: `includes/modules/production/`
- File:
  - `includes/modules/production/core/class-pk01-dodi-chat.php`
  - `includes/modules/production/core/class-pk01-dodi-cnc.php`
  - `includes/modules/production/employee-jobs/tampilan-penerimaan-job-karyawan.php`
  - `includes/modules/production/job-wages/tampilan-upah-job.php`
  - `includes/modules/production/jobs/tampilan-produksi.php`

## purchasing
- Folder canonical: `includes/modules/purchasing/`
- File:
  - `includes/modules/purchasing/purchase-orders/tampilan-pembelian.php`
  - `includes/modules/purchasing/suppliers/tampilan-pemasok.php`

## sales
- Folder canonical: `includes/modules/sales/`
- File:
  - `includes/modules/sales/cashier/tampilan-penjualan.php`
  - `includes/modules/sales/customers/tampilan-pelanggan.php`
  - `includes/modules/sales/pricing/tampilan-harga-jual.php`

## security
- Folder canonical: `includes/modules/security/`
- File:
  - `includes/modules/security/core/class-pk01-security.php`
  - `includes/modules/security/dashboard/class-pk01-security-dashboard.php`
  - `includes/modules/security/dashboard/tampilan-security.php`

## seller
- Folder canonical: `includes/modules/seller/`
- File:
  - `includes/modules/seller/core/class-pk01-affiliate.php`
  - `includes/modules/seller/management/tampilan-penjual.php`
  - `includes/modules/seller/portal/tampilan-portal-penjual.php`
  - `includes/modules/seller/register/tampilan-daftar-seller.php`

## warehouse
- Folder canonical: `includes/modules/warehouse/`
- File:
  - `includes/modules/warehouse/dashboard/tampilan-gudang.php`
  - `includes/modules/warehouse/inbound-supplier/tampilan-terima-supplier.php`
  - `includes/modules/warehouse/outbound/tampilan-kirim-barang.php`
  - `includes/modules/warehouse/returns/tampilan-retur.php`

## Shared Core
`includes/core/` berisi layanan lintas domain. Jangan dipindahkan ke folder domain hanya karena dipakai oleh satu dashboard.
