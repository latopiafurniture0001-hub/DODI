# Setoran Kasir → Keuangan v3.7.19

- Banyak user dapat memakai role `pk01_kasir`; tidak ada batas 1 kasir.
- Setiap kasir mempunyai akun kas internal `Kasir - Nama (#ID)` untuk rekonsiliasi.
- Setoran Cash: Kasir ajukan → Keuangan setujui nominal → Keuangan terima/bukukan sebagai transfer internal.
- Seller transfer: Kasir ajukan berdasarkan invoice nyata + referensi transfer → Keuangan setujui → Keuangan terima → sistem baru mencatat `seller_payments` dan kas masuk satu kali.
- Maker tidak boleh menyetujui setoran yang dibuat sendiri.
- Penolakan wajib disertai alasan.
- Tidak ada data transaksi dummy.
