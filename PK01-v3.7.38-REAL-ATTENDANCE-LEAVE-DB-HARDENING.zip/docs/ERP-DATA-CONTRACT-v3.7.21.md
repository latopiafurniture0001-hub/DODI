# PK01 v3.7.21 — ERP Data Contract

## Prinsip sumber data
- Product Master PK01 + Product Variant/SKU adalah sumber produk tunggal.
- E-Commerce/Theme membaca katalog melalui PK01_Ecommerce.
- Seller membaca katalog yang sama; seller tidak membuat master produk kedua.
- Marketplace hanya adapter/export; template harus dipasang dan diverifikasi Admin.
- Produksi/Job memakai Product Master dan snapshot Job; CNC memakai Master G-code yang cocok.
- Keuangan memakai transaksi PK01 yang sama; pemindahan uang antar-akun tidak boleh dihitung sebagai pendapatan kedua.

## Multi-account
Role tidak dibatasi satu akun. WordPress dapat memiliki banyak akun untuk role yang sama, misalnya 5 Kasir. Setiap akun memiliki user ID sendiri untuk audit dan rekonsiliasi.

## Marketplace mass upload
Seller memilih SKU yang akan diekspor. PK01 menghasilkan file berdasarkan template marketplace yang sudah diverifikasi. Jika template XLSX, hasil mengikuti XLSX; jika CSV/TSV, hasil mengikuti format tersebut. HPP internal tidak boleh diekspor.

## Anti-duplicate
- Entry guard + idempotency digunakan untuk transaksi yang memiliki natural key.
- Cash ledger memiliki reference type/id atau reference number sebagai kunci pencegahan replay.
- Pembayaran Seller final hanya melalui cashier_deposit maker-checker.
- Alokasi AR Seller hanya dapat dilakukan satu kali per deposit/invoice dan tidak boleh membuat AR negatif.

## Batas sistem nyata
PK01 tidak mengklaim menjalankan mesin CNC, memverifikasi kondisi fisik mesin, atau mengetahui hasil fisik tanpa input/feedback operator. G-code tetap dibuat/diuji melalui CAM dan diberikan ke CNC secara manual.
