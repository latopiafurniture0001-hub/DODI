# PK01 v3.6.71 — Retur Seller, AR, Tanda Terima & Notifikasi Terintegrasi

## Prinsip canonical
Retur bukan transaksi baru. Retur selalu mengacu pada order penjualan dan SKU yang benar-benar terjual. Saat Gudang melakukan scan dan menyatakan unit **DITERIMA SECARA FISIK**, PK01 otomatis menjalankan rekonsiliasi Seller.

## Alur retur
1. Retur dibuat dari order penjualan nyata.
2. Sistem memvalidasi SKU dan jumlah agar tidak melebihi unit yang pernah terjual dikurangi retur sebelumnya.
3. Data Seller, pelanggan, produk, harga unit, order, dan resi diambil dari database PK01.
4. Gudang scan resi retur.
5. Gudang menyatakan barang diterima.
6. Sistem otomatis:
   - menyimpan waktu/petugas penerimaan;
   - mencatat nama Seller;
   - menghitung nilai retur dari harga unit order/Seller yang nyata;
   - membuat koreksi negatif pada `seller_sales` sebagai histori audit, tanpa mengubah transaksi penjualan asli;
   - mengurangi total `seller_invoices`/AR sesuai nilai retur;
   - memperbarui statistik Seller agar omzet kembali bersih;
   - bila invoice sudah terbayar, membuat kredit Seller agar nilai tidak hilang dan dapat direkonsiliasi pada transaksi berikutnya;
   - mencatat audit log.
7. Retur tetap **MENUNGGU QC**. Penerimaan fisik tidak otomatis membuat barang baik masuk stok jual.
8. Setelah QC:
   - Baik → stok produk bertambah.
   - Rusak → dipisahkan sebagai stok rusak/karantina.
   - Reject → tidak masuk stok jual.

## Tanda terima dua salinan
Setiap retur yang diterima Gudang membuat dua dokumen:
- Salinan Kurir: tidak menampilkan nama Seller.
- Salinan Gudang: menampilkan nama Seller, order, barang, qty, dan nilai pengurang tagihan.

Keduanya memiliki referensi sumber yang sama sehingga tidak menciptakan transaksi stok kedua.

## Kasir
Kasir **READ ONLY** untuk retur. Kasir tidak menerima barang, tidak melakukan QC, dan tidak mengubah stok. Kasir hanya melihat laporan retur, Seller, resi, status, dan nilai pengurang tagihan serta dapat meneruskan laporan ke Seller melalui WhatsApp.

## Notifikasi
Saat retur diterima Gudang, PK01 mencoba mengirim email otomatis ke email Seller yang tersimpan. Jika nomor WhatsApp Seller tersedia, sistem menyediakan tautan WhatsApp siap kirim. Sistem tidak mengarang nomor atau membuat gateway WhatsApp palsu.

## Data nyata / anti-dummy
Tidak ada pembuatan order, Seller, invoice, stok, atau retur dummy pada alur operasional. Data baru hanya dibuat sebagai konsekuensi transaksi nyata (dokumen retur, koreksi ledger, tanda terima, dan audit). Test Lab tetap terisolasi untuk pengujian dan tidak menjadi sumber data operasional.
