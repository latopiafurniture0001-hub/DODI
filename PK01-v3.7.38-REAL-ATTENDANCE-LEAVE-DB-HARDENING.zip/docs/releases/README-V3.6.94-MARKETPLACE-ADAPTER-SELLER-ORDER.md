# PK01 v3.6.94 — Marketplace Adapter + Seller Order → Kasir

## Prinsip
- Master Produk PK01 adalah sumber kebenaran SKU, varian, ukuran, harga Seller dan stok riil.
- Seller tidak membuat ulang data produk setiap marketplace.
- Portal Seller menyediakan ekspor katalog per marketplace: Shopee, Tokopedia, TikTok Shop, Lazada, dan CSV umum.
- Setiap adapter memiliki schema header sendiri; data selalu berasal dari Master PK01.
- Order Seller dari Dashboard masuk ke antrean Kasir. Pengiriman tidak otomatis memotong stok.
- Resi/AWB boleh menyusul. Resi hanya referensi shipment, bukan penentu produk.
- Kasir menerima order. Jika stok cukup, fulfillment memotong stok dan membuat catatan penjualan Seller; jika stok kurang, order tetap tertahan untuk alur Produksi/Pembelian.
- Tidak ada dummy order, stok, resi, atau status tracking.

## Marketplace upload
PK01 tidak mengklaim bahwa header generik otomatis sama dengan template resmi yang dapat berubah. Untuk upload yang benar-benar mengikuti versi terbaru Seller Center, adapter dapat disesuaikan berdasarkan template resmi yang digunakan pada akun Seller. Ini sengaja agar PK01 tidak menebak kolom yang bisa menyebabkan import gagal.

## Sumber katalog
Katalog dibangun dari `products` + `product_variants` dan harga Seller dari Engine. Stok berasal dari `product_variants.stock`.
