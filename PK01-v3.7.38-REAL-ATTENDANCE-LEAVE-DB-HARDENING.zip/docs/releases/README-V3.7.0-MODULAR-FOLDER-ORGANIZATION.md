# PK01 v3.7.0 — Modular Folder Organization

## Tujuan

v3.7.0 merapikan source PK01 agar pekerjaan per domain dapat ditemukan dan diperbarui dari satu folder canonical. Dashboard, menu/view, dan kode domain dikelompokkan berdasarkan pekerjaan tanpa membuat Business Engine, Database Engine, atau sistem paralel.

## Aturan utama

1. **Satu domain = satu folder canonical di `includes/modules/<domain>/`.**
2. Dashboard dan seluruh view yang dimiliki domain berada di folder domain tersebut.
3. Kode engine yang spesifik domain berada di `<domain>/core/`.
4. Kode yang benar-benar lintas domain tetap di `includes/core/`.
5. Menu tidak diduplikasi per folder. Menu tetap berasal dari `PK01_Module_Registry` + `PK01_Authorization`, sehingga permission dan navigasi tetap satu sumber.
6. `PK01_Engine`, `PK01_DB`, Authorization, Audit, Workflow, Kernel, REST, Settings, dan layanan lintas domain tidak di-copy ke folder domain.
7. Memindahkan file tidak membuat tabel baru dan tidak mengubah relasi database.
8. Tidak ada file paralel sebagai alias untuk logic yang sama.

## Peta domain canonical

```text
includes/
├── core/                              # shared / lintas domain
│   ├── class-pk01-engine.php         # Business Engine tunggal
│   ├── class-pk01-db.php             # Database Engine tunggal
│   ├── class-pk01-authorization.php  # Authorization tunggal
│   ├── class-pk01-module-registry.php# Registry menu/view tunggal
│   ├── class-pk01-workflow.php
│   ├── class-pk01-domain.php
│   ├── class-pk01-kernel.php
│   ├── class-pk01-rest.php
│   ├── class-pk01-settings.php
│   ├── class-pk01-audit.php
│   ├── class-pk01-backup.php
│   ├── class-pk01-data-health.php
│   ├── class-pk01-idempotency.php
│   ├── class-pk01-duplicate-guard.php
│   ├── class-pk01-governance.php
│   ├── class-pk01-central-bridge.php
│   ├── class-pk01-theme-integration.php
│   ├── class-pk01-ecommerce.php      # storefront/bridge lintas domain
│   ├── class-pk01-shortcodes.php
│   ├── class-pk01-frontend.php
│   ├── class-pk01-login.php
│   └── PDF / ops utilities
│
└── modules/
    ├── admin/                         # Administrator
    │   ├── core/
    │   ├── dashboard-role/
    │   ├── activity/
    │   ├── administration/
    │   ├── documents/
    │   ├── master-data/
    │   ├── settings/
    │   └── users/
    ├── ai/                            # AI
    ├── customer-service/              # Customer Service
    ├── finance/                       # Keuangan
    ├── hr/                            # SDM
    ├── inventory/                     # Produk, bahan, stok, aset
    ├── logistics/                     # Packing, pengiriman, tracking
    ├── marketplace/                   # Adapter/export marketplace
    │   ├── core/
    │   │   └── class-pk01-marketplace-catalog.php
    │   └── reconciliation/
    ├── owner/                         # Owner
    ├── production/                    # Produksi, job, CNC
    ├── purchasing/                    # Pembelian & pemasok
    ├── sales/                         # Penjualan, Kasir, customer, pricing
    ├── security/                      # Security & CCTV
    ├── seller/                        # Seller / Affiliate
    └── warehouse/                     # SELURUH UI/fitur Gudang
        ├── dashboard/                 # Dashboard Gudang
        ├── inbound-supplier/          # Barang masuk dari pemasok
        ├── outbound/                  # Barang keluar
        └── returns/                   # Retur fisik & tanda terima
```

## Khusus Gudang

Jika nanti ada perubahan **Dashboard Gudang, menu Gudang, barang masuk, barang keluar, retur, scan resi, tanda terima, atau UI Gudang**, titik awal pencarian adalah:

`includes/modules/warehouse/`

Logic lintas modul yang dipanggil Gudang tetap di `includes/core/` dan **tidak boleh disalin** ke folder Gudang. Contohnya Business Engine tetap satu di `includes/core/class-pk01-engine.php`.

## Khusus Marketplace

`PK01_Marketplace_Catalog` sekarang berada di:

`includes/modules/marketplace/core/class-pk01-marketplace-catalog.php`

Bootstrap PK01 menggunakan path canonical tersebut. Tidak ada copy class lama di `includes/core/`.

## Registry menu

Menu tetap dikelola oleh:

`includes/core/class-pk01-module-registry.php`

Authorization tetap dikelola oleh:

`includes/core/class-pk01-authorization.php`

Dengan demikian saat dashboard/menu Gudang diperbarui, tidak perlu membuat menu kedua di folder Gudang. Registry menentukan menu, Authorization menentukan siapa yang boleh melihat/melakukan tindakan, sedangkan folder domain menyimpan view dan kode domain.

## Perubahan v3.7.0

- Merapikan kepemilikan `PK01_Marketplace_Catalog` ke `modules/marketplace/core/`.
- Memperbarui bootstrap agar memuat lokasi canonical baru.
- Menghapus referensi loader ke `class-pk01-production-router.php` yang memang tidak ada di paket, sehingga source tidak lagi menyimpan referensi file mati.
- Mempertahankan seluruh Engine/DB/Authorization/Workflow existing.
- Tidak membuat tabel, database, atau engine baru.
