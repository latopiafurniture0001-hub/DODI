# PK01 v3.6.49 — User Settings & Production Data Cleanup

- Pengaturan Pengguna kini mendukung edit nama, email, role operasional, dan password opsional.
- Username login tetap immutable untuk menjaga identitas audit.
- Role akun mengikuti WordPress User/Capability yang dipakai Login PK01.
- Perubahan role akun sendiri dibatasi untuk mencegah lockout.
- Test Lab tetap tersedia hanya untuk administrator, tetapi pembuatan dummy dinonaktifkan pada mode produksi kecuali sengaja diaktifkan.
- Ditambahkan pembersihan seluruh dummy run yang terdaftar dari halaman Pengaturan.
- Tidak menghapus master produk, akun pengguna, atau transaksi nyata.
