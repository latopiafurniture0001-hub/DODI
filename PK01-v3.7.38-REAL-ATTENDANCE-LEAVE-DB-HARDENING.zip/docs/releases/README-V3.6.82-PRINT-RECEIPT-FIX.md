# PK01 v3.6.82 — Print Receipt / Goods Receipt Fix

## Tujuan
Memastikan halaman Dokumen & Cetak Ulang tidak menampilkan daftar Goods Receipt sebagai dummy/0 hanya karena instalasi lama menyimpan tanda terima supplier pada `warehouse_documents`.

## Perubahan
- Goods Receipt (`goods_receipts`) tetap menjadi sumber transaksi canonical.
- `warehouse_documents` `doc_type=supplier_in` menjadi compatibility source untuk data lama.
- Halaman Dokumen menggabungkan kedua sumber tanpa membuat record baru.
- Data lama yang hanya mempunyai supplier-in document tetap bisa dicetak.
- Print `penerimaan-supplier` dapat menerima ID Goods Receipt atau ID supplier-in warehouse document.
- QR validation untuk `penerimaan-supplier` memeriksa Goods Receipt terlebih dahulu, lalu supplier-in warehouse document bila diperlukan.
- Tidak ada nomor/qty/bahan dummy yang dibuat saat print.
- Jika detail Goods Receipt tidak ada pada legacy document, PDF menyatakan data belum tersinkron dan tidak mengarang nilai.
- Semua print tetap melalui `fpdf/fpdf.php` → PDF loader → PDF gateway.
