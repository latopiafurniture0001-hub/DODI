# PK01 v3.6.75 — Struktur Folder Gudang Terpisah

Gudang dipisah berdasarkan pekerjaan fisik agar maintenance mudah.

- `includes/modules/warehouse/dashboard/` — Dashboard/ringkasan Gudang.
- `includes/modules/warehouse/returns/` — Retur: pendaftaran, scan penerimaan fisik, tanda terima, QC.
- `includes/modules/warehouse/outbound/` — Kirim Barang: scan resi dan serah-terima Gudang → Kurir.
- `includes/modules/warehouse/inbound-supplier/` — Terima Barang Supplier: penerimaan fisik bahan dari Supplier/PO.

Semua proses mutasi tetap menggunakan PK01 Engine dan tabel database yang sama; pemisahan folder hanya memisahkan UI/workflow supaya tidak ada file monolitik Gudang.
