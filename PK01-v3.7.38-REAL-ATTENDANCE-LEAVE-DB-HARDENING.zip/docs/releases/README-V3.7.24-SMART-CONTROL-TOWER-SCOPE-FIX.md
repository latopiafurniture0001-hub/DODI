# PK01 v3.7.24 — SMART CONTROL TOWER SCOPE FIX

## Perbaikan
Smart Control Tower / Pantauan Bisnis Terpadu sekarang hanya dirender untuk role dashboard yang memang memiliki fungsi monitoring manajerial:

- Administrator
- Admin Operasional
- Owner / Pemilik
- Manajer Operasional
- Keuangan

Role berikut tidak lagi mendapatkan Smart Control Tower pada dashboardnya:

- Seller
- Kasir
- Pekerja / Employee
- Gudang
- Produksi
- Packing
- Logistik
- HR
- Customer Service
- Security
- role operasional lain yang bukan monitoring manajerial

## Perbaikan penting untuk Admin Preview
Sebelumnya kondisi memakai `$is_admin`, sehingga Administrator yang sedang membuka Preview Seller/Kasir/Pekerja tetap melihat Smart Control Tower karena permission WordPress Administrator masih aktif.

Sekarang visibility Smart Control Tower mengikuti `PK01_Authorization::effective_role()` / role preview, bukan status permission Administrator.

Dengan demikian:

`Administrator -> Preview Seller` = tampilan Seller tanpa Smart Control Tower.

`Administrator -> Preview Kasir` = tampilan Kasir tanpa Smart Control Tower.

`Administrator -> Preview Pekerja` = tampilan Pekerja tanpa Smart Control Tower.

Permission Administrator tetap tidak berubah; yang berubah hanya cakupan tampilan dashboard.

## Tidak ada dummy data
Tidak ada perubahan pada sumber data transaksi/master. Panel tetap membaca data PK01 nyata ketika role memang berhak melihatnya.
