# PK01 v3.6.88 — Resi Massal Kasir → Gudang

## Alur resmi
1. Kasir dapat memasukkan nomor resi + kurir saat penjualan.
2. Resi hanya untuk Pengiriman/Gudang/Laporan; tidak mengubah harga, pembayaran, atau tagihan.
3. Kasir dapat import CSV UTF-8 dari Excel dengan kolom `order_no,resi,courier,service`.
4. Setiap resi wajib terhubung ke order PK01 nyata; resi ganda pada order lain ditolak.
5. Import membuat shipment + event `label_created`, sehingga Gudang langsung dapat mencari order berdasarkan resi.
6. Jika API kurir dikonfigurasi, PK01 mencoba verifikasi AWB dan menyimpan event asli. Jika API belum menemukan AWB, data tetap `unverified`; PK01 tidak mengarang status.
7. Gudang dapat scan/cari resi untuk melihat semua SKU, nama produk, qty, penerima, dan tujuan dari order asli.
8. Serah-terima fisik ke kurir tetap menjadi titik `picked_up`/`shipped`; membuat resi tidak berarti barang sudah keluar Gudang.
9. Retur menggunakan resi sebagai kunci untuk menemukan transaksi asli; koreksi tagihan baru terjadi setelah barang benar-benar diterima Gudang sesuai alur retur.

## Format CSV
`order_no,resi,courier,service`

Excel: Save As → CSV UTF-8.
