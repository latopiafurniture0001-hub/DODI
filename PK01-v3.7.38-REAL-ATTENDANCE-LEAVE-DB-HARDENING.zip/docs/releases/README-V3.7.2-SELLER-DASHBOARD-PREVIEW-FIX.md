# PK01 v3.7.2 — Seller Dashboard Preview Fix

## Perbaikan
- Role `pk01_seller` membuka Dashboard Seller nyata melalui `seller_portal`, bukan `seller_affiliate`.
- `seller_affiliate` tetap menjadi pusat afiliasi/material promosi dan tidak lagi dipakai sebagai landing dashboard Seller.
- Administrator Preview Seller memilih satu akun Seller aktif nyata hanya sebagai konteks tampilan jika Administrator tidak memiliki akun Seller sendiri.
- Pratinjau tidak mengubah role/capability Administrator.
- POST order, perubahan harga marketplace, dan export katalog dinonaktifkan selama preview.
- Tidak ada pembuatan data dummy.
