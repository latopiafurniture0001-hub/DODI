# PK01 v3.6.51 — Customer Service & Communication Hub

Update ini menambahkan pusat Customer Service nyata berbasis database untuk pelanggan, seller, komplain marketplace, dan komunikasi internal.

## Alur
- Login tetap satu melalui PK01/WordPress.
- Setiap workspace role memiliki akses cepat **Chat** di header jika role diizinkan.
- Customer Service menjadi satu pusat tiket; bukan chat terpisah per dashboard.
- Seller dapat membuat tiket layanan seller/marketplace.
- Pengguna operasional dapat membuat tiket koordinasi.
- Staff Customer Service/Admin/Shop Manager dapat melihat dan menangani seluruh tiket.
- Semua pesan tersimpan di database PK01 (`cs_tickets`, `cs_messages`).
- Asisten AI tetap memakai AI Engine PK01 yang sudah ada; UI Customer Service menyediakan jalur ke AI, tetapi AI tidak boleh mengubah transaksi tanpa otorisasi.
- Akun marketplace perusahaan ditangani sebagai konteks/channel `marketplace`; kredensial marketplace tidak disimpan di tiket.

## Anti-dummy
Tidak ada tiket contoh yang dibuat otomatis. Tabel dibuat kosong saat pertama kali tersedia.

## Security
Akses ticket dibatasi berdasarkan pemilik ticket atau staff. Penutupan ticket hanya staff. Nonce REST WordPress digunakan untuk UI browser.
