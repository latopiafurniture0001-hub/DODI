# PK01 v3.6.90 — SIMPLE RESI FLOW

Alur final Pengiriman PK01 dibuat sederhana:

Marketplace/Seller → Resi/AWB resmi → PK01 Shipment → Gudang scan Resi → Order → Produk/SKU/Qty → Handover → Tracking API.

- Resi adalah kunci pengiriman.
- PK01 tidak membuat AWB kurir palsu.
- Alamat tidak wajib untuk proses pencarian/picking Gudang.
- Import CSV menerima `resi` atau `tracking_no`; `order_no`, `courier`, `service` opsional.
- Resi harus dapat dihubungkan ke order PK01 nyata.
- Import resi hanya untuk Pengiriman/Gudang/Tracking/Laporan dan tidak membuat tagihan/pembayaran.
- Jika API kurir tersedia, PK01 memverifikasi dan menyimpan event tracking asli. Jika belum ditemukan, status tetap pending/unverified.
- Kode internal PK01 dan AWB kurir adalah dua identitas berbeda tetapi terhubung dalam satu shipment.
