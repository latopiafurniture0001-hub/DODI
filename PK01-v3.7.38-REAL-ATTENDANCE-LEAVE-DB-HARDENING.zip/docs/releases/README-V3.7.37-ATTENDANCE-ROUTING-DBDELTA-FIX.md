# PK01 v3.7.37 — Attendance/Cuti Routing + dbDelta Hardening

- Canonical HR page: `absensi-cuti-karyawan` stored in `pk01_attendance_page_id`.
- HR login landing goes to `pk01_view=attendance`.
- `attendance`, `leave`, and `cuti` aliases resolve to the same real attendance/cuti workspace.
- Attendance page is auto-created if missing; no business/demo data is created.
- dbDelta wrapper removes blank lines and normalizes index declarations before passing SQL to WordPress, preventing Undefined array key warnings from upgrade.php.
- No WordPress core file is modified.
