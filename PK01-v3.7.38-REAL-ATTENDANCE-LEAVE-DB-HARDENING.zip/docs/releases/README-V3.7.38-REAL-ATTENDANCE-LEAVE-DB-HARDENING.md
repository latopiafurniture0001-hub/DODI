# PK01 v3.7.38 — REAL ATTENDANCE & LEAVE + DB HARDENING

## Tujuan
Memperbaiki alur Absensi & Cuti yang sebelumnya jatuh ke renderer Dashboard Administrator serta memperbaiki sumber warning database.

## Perubahan utama
- `attendance` memiliki renderer resmi `PK01_Shortcodes::attendance()`.
- Registry menambahkan physical view canonical `modules/hr/attendance/tampilan-absensi.php`.
- URL `attendance`, `leave`, dan `cuti` tetap memakai satu workspace HR canonical.
- Presensi web dibatasi ke profil karyawan yang sedang login; user tidak dapat memilih employee lain.
- Urutan Clock In/Clock Out divalidasi server-side dan duplikasi waktu ditolak.
- Endpoint riwayat dan saldo cuti membatasi karyawan biasa ke datanya sendiri.
- Jenis cuti tidak lagi dibuat otomatis sebagai data kebijakan contoh. HR/Admin membuat jenis cuti sesuai kebijakan usaha.
- Master jenis cuti dapat dibuat dari workspace Absensi & Cuti.
- Saldo cuti dihitung dari entitlement + carryover + adjustment dan pengajuan approved sebagai source of truth; sistem tidak membuat row saldo hanya karena halaman dibuka.
- Ditambahkan schema canonical `marketplace_mappings` dan `marketplace_exports` tanpa membuat data marketplace dummy.
- `dbDelta_safe()` dinormalisasi menyeluruh: komentar, blank line, field/index top-level, format PRIMARY KEY/KEY/UNIQUE/FULLTEXT/SPATIAL.
- Versi plugin dan `PK01_VERSION` disamakan menjadi 3.7.38.

## Prinsip data
Tidak ada pembuatan transaksi, karyawan, absensi, cuti, produk, stok, order, pembayaran, atau data bisnis contoh. Struktur database boleh dipulihkan; data bisnis hanya berasal dari tindakan/integrasi nyata.

## Static QA
- Seluruh file PHP dilint dengan `php -l`.
- ZIP integrity diperiksa sebelum rilis.
- Tidak ada klaim runtime WordPress/Hostinger karena pengujian dilakukan secara statis.
