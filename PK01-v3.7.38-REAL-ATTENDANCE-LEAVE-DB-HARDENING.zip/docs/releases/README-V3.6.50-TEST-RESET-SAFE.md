# PK01 v3.6.50 — Test Data Reset Safe Flow

## Tujuan
Menambahkan alur reset khusus untuk pengujian agar Administrator dapat menguji PK01, lalu mengembalikan database dari data uji ke kondisi bersih tanpa menghapus data produksi nyata.

## Perubahan
- Menu Pengaturan memiliki **Reset Data Uji / Test Lab**.
- Hanya Administrator (`manage_options`) yang dapat menjalankan reset.
- Dua lapis konfirmasi: dialog peringatan + kata `RESET UJI`.
- Reset memanggil registry `PK01_Test_Lab::purge_all()`; hanya entitas yang dicatat sebagai Test Lab yang dihapus.
- Snapshot nomor dokumen Test Lab dipulihkan oleh Test Lab engine.
- Data master, akun pengguna, konfigurasi, dan transaksi nyata tidak menjadi target reset ini.
- Aktivitas reset dicatat melalui audit engine.
- Tombol nonaktif jika tidak ada test run aktif.

## Catatan keamanan
Jangan menggunakan **Reset Data Selektif** untuk data produksi kecuali memang sengaja dan sudah ada backup. Fitur Reset Data Uji adalah jalur yang direkomendasikan untuk siklus `uji → reset → uji ulang`.
