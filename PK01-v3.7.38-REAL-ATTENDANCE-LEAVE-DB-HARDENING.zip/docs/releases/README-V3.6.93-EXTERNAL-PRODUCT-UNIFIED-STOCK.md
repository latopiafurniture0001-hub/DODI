# PK01 v3.6.93 — Produk Sendiri + Produk Beli dari Luar

## Aturan inti
- Master SKU PK01 tetap satu. Produk beli dari luar tidak membuat SKU gudang kedua.
- Varian memakai `supply_mode`: `production` (produksi sendiri), `purchase` (dibeli), atau `hybrid` (bisa produksi dan beli).
- Pembelian produk jadi masuk ke stok `product_variants.stock` dan dicatat sebagai mutasi `stock_transactions`.
- Jika SKU `purchase` kekurangan stok saat Kasir membukukan penjualan, sistem membuat Permintaan Pembelian, bukan Job Produksi.
- Jika SKU `production` atau `hybrid` kekurangan stok, sistem membuat Order Produksi sesuai alur Kasir.
- Website/e-commerce membaca stok master PK01 secara real-time dari `product_variants.stock`; tidak memakai stok dummy/fallback yang dapat menyembunyikan stok nol.
- Portal Seller menyediakan Katalog Marketplace berbasis Master PK01. Seller dapat mengunduh data untuk Shopee, Tokopedia, TikTok Shop, Lazada, atau CSV umum. File akhir tetap harus mengikuti template resmi marketplace masing-masing.
- Seller memakai SKU/harga/stok dari PK01 sebagai sumber data internal.
