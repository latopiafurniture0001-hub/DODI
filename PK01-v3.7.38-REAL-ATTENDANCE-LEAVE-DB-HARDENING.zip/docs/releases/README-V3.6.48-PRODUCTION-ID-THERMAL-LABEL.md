# PK01 v3.6.48 — Identitas Produksi & Label Thermal

## Identitas
- Kode Produksi: `PRD-YYMMDD-JJJJJJ-RRRRR` (satu hasil produksi/result).
- Kode CNC: `CNC-YYMMDD-JJJJJJ-UUUU` (satu unit barang jadi).
- Batch `BTH-...` tetap dipertahankan untuk kompatibilitas.

## Penyimpanan
- `production_results`: sumber resmi hasil produksi, kode produksi, batch, status, QR payload.
- `production_units`: sumber resmi unit barang jadi, kode produksi induk, kode CNC, batch, tanggal, QR payload.
- Data lama dibackfill tanpa membuat transaksi produksi baru.

## Scan
- `/wp-json/pk01/v1/production/identity/{code}` mencari Kode Produksi, Batch, barcode, atau Kode CNC.
- Scanner menerima raw code maupun URL QR PK01 dan mengekstrak identitasnya.

## Label
- `label-thermal` menghasilkan PDF 58mm x 78mm, satu label per unit.
- Isi: nama produk, ukuran, SKU, Job, tanggal, Kode CNC + barcode, QR, Batch, Kode Produksi.
- QR adalah QR identitas produk, bukan QRIS pembayaran.
