# PK01 v3.6.98 — Authorization Dashboard Isolation

- Setiap renderer frontend melewati PK01_Authorization sebelum file tampilan di-include.
- Dashboard/workspace memiliki otorisasi terpisah dan tidak dapat dibuka lintas-role melalui URL/shortcode.
- `pk01_role_permissions` dari Pengaturan dihormati untuk navigation ketika modul memang ada pada profil job; explicit FALSE menutup akses.
- Administrator nyata tetap dapat melihat semua dashboard.
- Role Preview Administrator tetap read-only melalui authorization engine.
- Akses mutasi tetap memakai `can_action()`/Kernel; perubahan ini bukan pengganti guard business engine.
- Tidak ada dashboard duplikat; semua renderer tetap menggunakan data/Engine PK01 yang sama.
