# PK01 v3.6.54

- Aktivasi dibuat ringan: module init tidak dijalankan saat plugins_loaded/activation.
- Biaya operasional memakai workflow pending approval -> approved -> paid -> received.
- Kas hanya berkurang setelah approval dan pembayaran kasir.
- Penerima wajib dikonfirmasi dan tersedia PDF tanda terima profesional via FPDF.
- PDF bukan HTML browser.
- Data lama ditandai paid agar tidak terpotong kas dua kali.
