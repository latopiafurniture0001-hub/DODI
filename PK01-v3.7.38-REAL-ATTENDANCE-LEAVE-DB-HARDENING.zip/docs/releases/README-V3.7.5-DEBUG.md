# PK01 v3.7.5 — DEBUG BUILD

Build ini menambahkan diagnostic guard tanpa mengubah alur bisnis utama.

## Jika terjadi Critical Error
1. Setelah WordPress pulih, buka Tools → PK01 Debug.
2. Download Debug Log.
3. Kirim file `pk01-debug.log` ke AI.

Log juga otomatis ditulis ke:
`wp-content/uploads/pk01-debug/pk01-debug.log`

Log mencatat versi PHP/WordPress, tahap bootstrap, file runtime terakhir, dan detail fatal PHP yang tertangkap oleh shutdown handler.
