# PK01 v3.6.79 — Print Integration & Numbering

- Canonical FPDF: `fpdf/fpdf.php`
- `pdf/fpdf.php` is compatibility shim only.
- Official print requests route through `includes/core/pdf-loader.php` → `includes/core/pdf-gateway.php`.
- Print never increments document sequence. It reads the existing transaction document number.
- Transaction numbering is resolved from Central Settings where a corresponding numbering setting exists.
- Browser `window.print()` print paths for warehouse inbound/outbound, return receipts, and production employee slips are replaced with gateway PDF links.
- Legacy expense receipt endpoint delegates to the gateway.
