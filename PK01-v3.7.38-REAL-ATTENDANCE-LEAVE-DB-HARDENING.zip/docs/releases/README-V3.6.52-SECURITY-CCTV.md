# PK01 v3.6.52 — Security & CCTV

Modul Security operasional nyata untuk gate perusahaan.

- Role `pk01_security` dan RBAC terpisah.
- Identitas tamu: NIK, data kontak, foto KTP terenkripsi, dan riwayat kunjungan.
- Check-in/check-out tamu.
- Kendaraan masuk.
- Barang masuk/keluar dengan security code dan verifikasi gate.
- Laporan insiden dan audit trail.
- Registry IP Camera / DVR / NVR.
- Protokol ONVIF/RTSP sebagai sumber; HLS/WebRTC/proxy dapat ditampilkan di browser.
- Rekaman video tetap di kamera/DVR/NVR; PK01 menyimpan metadata dan referensi.
- AI/Customer Service tetap tersedia untuk role Security.

Catatan: browser tidak dapat memutar RTSP secara native. Untuk live view RTSP diperlukan CCTV gateway/media server yang menghasilkan HLS/WebRTC.
