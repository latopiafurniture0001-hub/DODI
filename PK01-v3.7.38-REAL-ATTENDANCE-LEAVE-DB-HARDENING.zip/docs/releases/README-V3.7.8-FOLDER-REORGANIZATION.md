# PK01 v3.7.8 — Folder Reorganization & Maintenance Index

## Tujuan
Membuat source code mudah dicari dan dikembangkan per dashboard/domain tanpa memecah shared engine.

## Perubahan
- Menjadikan `includes/modules/<domain>/` sebagai folder canonical setiap domain.
- Menambahkan `README.md` di setiap folder domain.
- Menambahkan `docs/architecture/DASHBOARD-FOLDER-MAP.md`.
- Menambahkan `docs/architecture/MODULE-OWNERSHIP-INDEX.md`.
- Memindahkan catatan release lama dari root ke `docs/releases/`.
- Memindahkan laporan lint/daftar file ke `docs/quality/`.
- Tidak memindahkan `includes/core/` ke domain karena core dipakai lintas dashboard.
- Tidak membuat engine/database/menu kedua.
- Tidak mengubah skema database atau alur transaksi.
