# PK01 v3.7.26 — LOGOUT + CHAT JOB FIX

- Dashboard non-Administrator mendapat tombol **↪ Keluar** di topbar.
- Sidebar Administrator tetap menjadi satu-satunya tempat logout untuk dashboard Administrator utama.
- Chat Job diperbaiki: fungsi room sebelumnya menggunakan variabel `$room` yang belum didefinisikan saat melakukan seed peserta, sehingga chat dapat gagal. Kini memakai room yang benar.
- Chat Job mencakup Seller pemilik order + karyawan yang ditugaskan pada Job. Karyawan yang sama-sama ditugaskan pada Job dapat berkomunikasi satu sama lain.
- Judul ruang diperjelas menjadi `Komunikasi Job`.
- Tidak membuat data pengguna/job/chat contoh.
