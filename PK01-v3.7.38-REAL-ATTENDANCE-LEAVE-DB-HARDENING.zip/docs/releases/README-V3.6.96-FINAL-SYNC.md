# PK01 v3.6.96 — FINAL SYNC

- Kasir is the acceptance gate for Seller Dashboard orders.
- Seller orders do not change stock/AR before Kasir accepts them.
- If stock is insufficient, acceptance creates a production job or finished-product purchase request and holds the Seller order in waiting status.
- If stock is sufficient, fulfillment moves the order to warehouse and creates the real Seller AR.
- Master PK01/E-Commerce/Theme Integration is the source of truth for product identity, SKU, specification, media and real stock. Stock transactions are preferred for real movement; master stock is opening/fallback.
- Seller may override marketplace selling price per marketplace without changing HPP or PK01 Seller AR.
- Marketplace exports are generated only from an uploaded marketplace template. No invented marketplace headers are used for production exports.
- CSV/TSV/XLSX template format is preserved on export; XLSX export is blocked if the server cannot generate a valid XLSX.
- Unmapped/ambiguous template columns block verification/export until reviewed.
- Seller catalog and order dashboards use the same PK01 variant IDs/SKUs. Marketplace SKU is stored as mapping/reference, not as the warehouse master.
- Warehouse uses PK01 SKU/order/resi; address is not the primary item lookup key.
- Production dashboard receives jobs from the Kasir flow and uses the saved product specification snapshot.
