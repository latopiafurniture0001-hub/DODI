# PK01 v3.7.3 — UNIFIED ROLE DASHBOARD

## Tujuan
Administrator dapat memeriksa tampilan seluruh dashboard dari Pusat Pratinjau tanpa login ulang atau impersonation.

## Perbaikan
- Semua role menggunakan satu Dashboard Engine: `modules/admin/dashboard-role/tampilan-dashboard-role.php`.
- Profil role menentukan KPI, pekerjaan, tindakan, dan menu yang relevan.
- Role tidak lagi diarahkan langsung ke modul transaksi sebagai dashboard utama.
- Kasir, Keuangan, SDM, dan Logistik memakai dashboard role yang sama dengan profil masing-masing; modul kerja dibuka melalui tindakan/menu.
- Sidebar saat preview mengikuti menu role yang sedang dilihat sehingga Administrator dapat memeriksa dashboard + menu sekaligus.
- Preview tetap menggunakan akun Administrator asli dan hanya bersifat baca.
- POST pada halaman preview diblokir oleh shell PK01.
- Dashboard Pekerja saat preview memakai satu profil karyawan aktif nyata jika diperlukan, tanpa membuat data baru.
- Tidak ada dummy transaction atau database baru.
