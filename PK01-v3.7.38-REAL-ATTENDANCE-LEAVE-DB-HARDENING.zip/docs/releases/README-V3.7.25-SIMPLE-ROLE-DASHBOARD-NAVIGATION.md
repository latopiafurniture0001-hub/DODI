# PK01 v3.7.25 — SIMPLE ROLE DASHBOARD NAVIGATION

## Tujuan
Menyederhanakan tampilan dashboard agar pengguna pekerjaan tidak dibebani sidebar/menu teknis.

## Aturan tampilan
- Sidebar hanya tampil pada Dashboard Administrator WordPress asli.
- Preview Administrator untuk role lain tidak menampilkan sidebar.
- Kasir, Seller, Gudang, Produksi, Keuangan, HR, Logistik, Packing, CS, Security, Pekerja, Owner, Investor, dan Admin Operasional memakai workspace penuh.
- Navigasi pekerjaan dilakukan dari kartu **Pilih Pekerjaan Anda / Menu Utama** di dashboard.
- Workspace non-admin mendapat tombol **Beranda** di topbar agar mudah kembali.
- Diagram teknis arsitektur disembunyikan dari dashboard pekerjaan; tetap tersedia untuk Administrator.

## Alur sederhana
Dashboard role → pilih pekerjaan → selesaikan transaksi → kembali ke Beranda.

Tidak ada perubahan pada database, business engine, atau permission inti.
