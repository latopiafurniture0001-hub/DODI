# PK01 v3.6.76 — Dashboard Routing & Visibility Fix

Memperbaiki tiga masalah runtime pada v3.6.75:

- Security dashboard sebelumnya memiliki renderer rekursif yang memanggil dirinya sendiri. Sekarang UI canonical berada di `includes/modules/security/dashboard/tampilan-security.php`.
- Customer Service dashboard sebelumnya memiliki renderer rekursif. Sekarang UI canonical berada di `includes/modules/customer-service/dashboard/tampilan-customer-service.php`.
- Registry/view router sekarang memiliki mapping eksplisit untuk `security`, `customer_service`, dan `administration`.
- Dashboard utama Administration dapat dirender melalui registry.
- Security, Customer Service, dan Administration diperlakukan sebagai modul dashboard yang tetap dapat terlihat walaupun tabel data belum terinisialisasi; angka dashboard aman menjadi 0, bukan menu hilang.
- Tidak membuat data dummy.

Struktur UI: satu menu → satu folder → satu file canonical.
