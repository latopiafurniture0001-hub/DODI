# PK01 v3.6.89 — Internal Shipment Barcode

## Tujuan
Order marketplace dapat masuk ke PK01 dari Excel/CSV tanpa harus menunggu AWB resmi kurir. PK01 membuat identitas shipment internal yang unik dan dapat dipindai Gudang.

## Prinsip penting
- `internal_shipment_no` / `internal_barcode` adalah ID internal PK01, bukan nomor AWB resmi kurir.
- AWB resmi kurir disimpan terpisah di `tracking_no`.
- Alamat pelanggan tidak diperlukan untuk proses picking internal jika order sudah terhubung; alamat tetap menjadi data order bila tersedia dari marketplace.
- Barcode internal menghubungkan Order -> Shipment -> SKU -> Qty -> Gudang.
- Saat AWB resmi sudah diterbitkan, operator dapat menghubungkannya ke shipment internal yang sama. Setelah itu verifikasi/tracking API dapat dijalankan.
- Satu AWB resmi tidak boleh dipakai oleh dua shipment.
- Scan Gudang menerima tiga bentuk kode: internal barcode, internal shipment number, atau AWB resmi.
- Handover dapat dilakukan menggunakan kode internal ketika AWB belum tersedia. Sistem tidak mengklaim tracking API sampai AWB resmi tersedia.
- Resi/AWB tetap hanya data logistik; tidak mengubah tagihan Seller.

## Contoh
CSV:
`order_no,resi,courier,service`
`ORD-001,,,JNE,REG`

PK01 menghasilkan shipment internal, misalnya `SHP/202609/00001`, barcode `PK01-SHP20260900001`. Gudang scan barcode tersebut dan melihat barang/order. Setelah kantor kurir memberikan AWB `JNE123456789`, operator menghubungkan AWB ke shipment yang sama. Tracking API kemudian memakai AWB resmi.
