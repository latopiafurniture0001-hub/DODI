# PK01 v3.6.46 — User Dashboard Tanpa Sidebar

Perubahan:
- Sidebar legacy PK01 hanya tampil pada dashboard Administrator WordPress.
- Semua role pengguna operasional memakai workspace full-width tanpa sidebar.
- Mobile menu/toggle sidebar tidak dirender untuk pengguna non-administrator.
- Layout dipaksa 1 kolom agar tidak menyisakan ruang sidebar.
- Role preview tidak mengubah dashboard administrator menjadi sidebar pengguna; preview tetap diperlakukan sebagai tampilan pengguna yang sedang diuji.
- Authorization backend dan registry modul tidak dihapus/diubah oleh patch tampilan ini.
