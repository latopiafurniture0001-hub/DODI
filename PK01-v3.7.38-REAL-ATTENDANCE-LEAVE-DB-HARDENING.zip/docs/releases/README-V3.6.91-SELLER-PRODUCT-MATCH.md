# PK01 v3.6.91 — Seller Product Identity & Master SKU Matching

## Logika utama
- Seller wajib membawa identitas produk dari marketplace: nama produk dan/atau SKU Seller; model dan ukuran/varian dapat diisi untuk memperjelas.
- Data marketplace Seller **bukan master PK01**.
- SKU/Varian PK01 adalah master barang untuk stok, harga internal, gudang, dan tagihan.
- Operator wajib mengonfirmasi/memilih Variant PK01 yang benar sebelum transaksi Seller dibuat.
- Jika SKU Seller persis sama dengan SKU PK01, engine dapat melakukan pencocokan deterministik 100%.
- Jika nama/model/ukuran hanya menghasilkan kandidat, engine tidak boleh menebak; transaksi harus dikonfirmasi.
- Mapping Seller + marketplace + identitas produk ke Variant PK01 disimpan agar transaksi berikutnya lebih cepat dan konsisten.
- Data identitas asli Seller disimpan di detail order untuk audit.
- Resi/AWB tetap menjadi kunci logistik; alamat tidak diperlukan untuk pencarian barang Gudang.
- Barcode/kode internal PK01 tidak pernah ditulis sebagai AWB resmi.

## Perbaikan Gudang
- Daftar shipment menampilkan shipment yang baru memiliki kode internal walaupun AWB resmi belum tersedia.
- Saat handover dengan barcode internal, PK01 tidak mengisi `sales_orders.tracking_no` dengan barcode internal.
