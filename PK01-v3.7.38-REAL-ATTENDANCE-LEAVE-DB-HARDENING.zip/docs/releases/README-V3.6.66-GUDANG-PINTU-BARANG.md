# PK01 v3.6.66 — Gudang sebagai Pintu Barang

Retur fisik dipindahkan dari Kasir ke Gudang. Gudang menjadi pintu barang masuk supplier, keluar ke kurir, retur masuk, dan penerimaan fisik produksi.
