# PK01 v3.6.63 — Manajemen Produksi Simple Flow

## Tujuan
Satu menu sederhana untuk memahami alur barang produksi tanpa mencampur pergerakan barang dengan uang.

## Menu
**Utama → Manajemen Produksi**. Diakses oleh Produksi, Gudang, Admin, dan role yang diberi izin.

## Logika
1. Bahan masuk → stok bahan bertambah.
2. Bahan keluar ke Job → stok bahan berkurang dan tercatat di job_materials.
3. Bahan terpakai → menjadi dasar HPP job.
4. Sisa bahan kembali → stok bahan bertambah.
5. Hasil baik → stok barang jadi bertambah.
6. Reject → dicatat terpisah.
7. Uang dibayar → tetap menjadi tanggung jawab Pusat Uang/Keuangan.
8. Bahan sudah diterima tetapi belum dibayar → tampil sebagai belum dibayar dan tidak mengurangi kas.

## Prinsip
Produksi/Gudang = pintu barang.
Keuangan/Pusat Uang = pintu uang.
Tidak membuat ledger uang kedua.
