# PK01 v3.6.72 — Dashboard Seller Terintegrasi

## Tujuan
Dashboard Penjual membaca satu sumber data PK01 yang sama untuk penjualan, retur, tagihan, dan pembayaran. Tidak membuat transaksi dummy atau meminta pengguna mengetik ulang angka.

## Perubahan
- Dashboard role `pk01_seller` memakai Penjualan Bersih, bukan omzet perusahaan.
- Penjualan bersih = penjualan asli Seller dikurangi nilai retur yang sudah dinyatakan diterima Gudang dan koreksi AR-nya berstatus `applied`.
- Menampilkan Nilai Retur Seller yang sudah mengurangi penjualan/tagihan.
- Menampilkan Tagihan Belum Dibayar dan Tagihan Sudah Dibayar dari `seller_invoices` + `seller_payments`.
- Portal Seller menambahkan tab Laporan Penjualan, Retur & Tagihan.
- Rincian retur menampilkan status apakah koreksi sudah diterapkan atau masih menunggu penerimaan Gudang.
- Rincian invoice menampilkan nilai tagihan, sudah dibayar, sisa belum dibayar, dan status.
- Rekap bulanan/tahunan menampilkan omzet bruto, retur, omzet bersih, dan komisi.
- Retur tetap terhubung ke order asli; histori penjualan tidak dihapus.
- Seluruh PHP di-lint setelah perubahan.

## Aturan bisnis
1. Retur belum diterima Gudang tidak mengurangi laporan finansial Seller.
2. Saat Gudang menerima unit retur, PK01 menerapkan koreksi Seller/AR satu kali.
3. Jika pembayaran invoice sudah lebih besar dari total setelah retur, kelebihan menjadi kredit Seller sesuai ledger kredit.
4. Dashboard hanya membaca data transaksi nyata yang tersimpan.
