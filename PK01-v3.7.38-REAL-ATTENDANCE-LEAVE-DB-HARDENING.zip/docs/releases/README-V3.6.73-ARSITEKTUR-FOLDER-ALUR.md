# PK01 v3.6.73 — Arsitektur Folder Berdasarkan Alur Operasional

Tujuan versi ini adalah membuat lokasi file mudah dicari saat maintenance/update. Folder UI sekarang mengikuti **alur pekerjaan**, bukan sekadar asal fungsi.

## Struktur utama

```text
includes/
├── core/                         # Mesin inti, database, workflow, security, registry
├── modules/
│   ├── admin/                   # Administrasi sistem
│   ├── ai/                      # AI assistant & AI center
│   ├── customer-service/        # CS & kanal komunikasi
│   ├── finance/                 # Kas, keuangan, closing, laporan
│   ├── hr/                      # Karyawan, absensi, payroll
│   ├── inventory/               # Master & kontrol stok
│   │   ├── products/
│   │   ├── materials/
│   │   ├── stock/
│   │   ├── management/
│   │   └── assets/
│   ├── warehouse/               # SEMUA pekerjaan fisik gudang
│   │   ├── dashboard/            # Pintu barang / kontrol gudang
│   │   │   └── tampilan-gudang.php
│   │   └── returns/              # RETUR + penerimaan + QC retur
│   │       └── tampilan-retur.php
│   ├── logistics/               # Packing, pengiriman, tracking
│   ├── marketplace/             # Rekonsiliasi marketplace
│   ├── production/              # Job produksi & upah
│   ├── purchasing/              # PO & supplier
│   ├── sales/                   # Penjualan, pelanggan, harga
│   │   ├── cashier/
│   │   ├── customers/
│   │   └── pricing/
│   ├── seller/                  # Data & portal seller
│   ├── security/                # Security/CCTV
│   └── owner/                   # Dashboard & modal owner
└── ...
```

## Aturan lokasi file baru

- **Retur fisik, scan retur, tanda terima retur, QC retur:** `modules/warehouse/returns/`
- **Barang masuk/keluar gudang dan pintu barang:** `modules/warehouse/dashboard/`
- **Penjualan kasir:** `modules/sales/cashier/`
- **Packing:** `modules/logistics/packing/`
- **Resi/pengiriman:** `modules/logistics/shipping/`
- **Tracking:** `modules/logistics/tracking/`
- **Produksi:** `modules/production/`
- **Tagihan/keuangan:** `modules/finance/`
- **Data seller:** `modules/seller/`
- **Stok/master produk:** `modules/inventory/`

## Prinsip integrasi

Folder adalah lokasi kode UI/proses, **bukan database baru**. Semua proses tetap menggunakan Engine/DB PK01 yang sama. Memindahkan file tidak membuat tabel, transaksi, stok, penjualan, retur, atau seller baru.

### Alur retur

`Sales Order asli → Retur → Warehouse Scan → Tanda Terima → QC → Koreksi Seller/Tagihan → Stok → Laporan`

Karena retur adalah kejadian fisik di gudang, kode UI retur secara kanonik berada di `modules/warehouse/returns/`.

## Perubahan path pada v3.6.73

- `modules/inventory/warehouse/tampilan-gudang.php`
  → `modules/warehouse/dashboard/tampilan-gudang.php`
- `modules/sales/returns/tampilan-retur.php`
  → `modules/warehouse/returns/tampilan-retur.php`
- Module Registry sudah diperbarui agar tidak ada referensi path lama.

## Aturan maintenance

Jika ingin update retur, **langsung buka:**

`includes/modules/warehouse/returns/tampilan-retur.php`

Jika ingin update proses pintu gudang/tanda terima barang masuk-keluar, buka:

`includes/modules/warehouse/dashboard/tampilan-gudang.php`

Jangan membuat file retur baru di `sales/returns/` atau `inventory/warehouse/`.
