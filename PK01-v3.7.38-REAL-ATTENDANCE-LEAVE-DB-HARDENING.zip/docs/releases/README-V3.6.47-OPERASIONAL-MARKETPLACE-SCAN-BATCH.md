# PK01 v3.6.47 — Dashboard Operasional, Scan, dan Batch Produksi

- Dashboard semua role mendapat satu Quick Control untuk pencarian produk, resi, dan batch/job.
- Scanner kamera menggunakan BarcodeDetector browser; input manual tetap tersedia sebagai fallback.
- REST product lookup membaca data produk aktif dari database PK01.
- Batch produksi dibuat unik pada saat hasil produksi disimpan dan dicatat ke production_results serta production_units.
- Label hasil produksi menampilkan batch code, barcode, dan QR payload.
- Tidak membuat tabel Job baru atau database bisnis kedua.
