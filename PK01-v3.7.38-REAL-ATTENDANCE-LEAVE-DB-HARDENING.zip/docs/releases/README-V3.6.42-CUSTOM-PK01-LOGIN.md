# PK01 v3.6.42 — Central Custom Login

## Tujuan
Seluruh dashboard/portal operasional PK01 diarahkan ke halaman login PK01 sendiri, bukan ke tampilan `wp-login.php`.

## Alur
1. Pengguna membuka dashboard/portal PK01.
2. Jika belum login, PK01 mengarahkan ke `/pk01-login/`.
3. Form login PK01 melakukan autentikasi terhadap akun WordPress yang sama menggunakan `wp_signon()`.
4. Jika berhasil, PK01 memakai routing role yang sudah ada untuk mengarahkan pengguna ke Dashboard PK01.
5. Jika seseorang membuka `wp-login.php?action=login` secara langsung, PK01 mengalihkannya ke halaman login PK01.
6. Tombol/link login yang masih menggunakan `wp_login_url()` mendapat URL PK01 melalui filter `login_url` dan fallback eksplisit pada modul yang ditemukan.
7. Logout tetap memakai mekanisme WordPress untuk menjaga kompatibilitas sesi, lalu kembali ke portal PK01.

## File utama
- `includes/core/class-pk01-login.php` — pusat login PK01.
- `includes/core/class-pk01-frontend.php` — auth guard dashboard memakai login PK01.
- `includes/core/class-pk01-shortcodes.php` — shortcode `[pk01_login]` dan prompt login.
- `includes/core/class-pk01-db.php` — membuat/menjaga halaman `pk01-login` secara idempotent.
- `pk01-operasional.php` — memuat dan menginisialisasi class login.

## Prinsip keamanan
- Nonce form login.
- `wp_signon()` tetap menjadi autentikasi WordPress canonical; PK01 hanya menyediakan UI/routing login.
- Redirect tujuan divalidasi menggunakan `wp_validate_redirect()`.
- Setelah autentikasi berhasil, routing role tetap melalui `PK01_Frontend::login_redirect()` sehingga aturan role lama tidak dibuat ulang.
- Tidak membuat user table atau sistem password kedua.

## Catatan
Password reset/registrasi akun bukan dibuat ulang pada versi ini. Akun tetap dikelola oleh WordPress/WooCommerce; PK01 hanya menjadi pintu login frontend.
