# PK01 v3.6.43 — Web Activation Fix

Perbaikan instalasi/aktivasi plugin di WordPress.

## Perbaikan
- Referensi `class-pk01-production-router.php` yang tidak ada pada paket tertentu tidak lagi dipanggil secara paksa.
- Router CNC dimuat hanya jika file tersedia dan dapat dibaca.
- Mencegah fatal error saat plugin diaktifkan dari halaman Plugins WordPress.
- API DODI CNC dan chat tetap dimuat seperti sebelumnya.
- Tidak dibuat router dummy.
- Migrasi database tetap dijalankan secara aman/idempotent setelah aktivasi.
