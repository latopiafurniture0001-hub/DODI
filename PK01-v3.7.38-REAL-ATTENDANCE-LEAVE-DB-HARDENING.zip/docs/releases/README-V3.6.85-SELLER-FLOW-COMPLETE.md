# PK01 v3.6.85 — Alur Seller/Marketplace Terpadu

## Aturan bisnis final
1. Penjualan Seller marketplace dicatat manual karena tidak ada API marketplace.
2. Harga tagihan Seller selalu harga internal PK01/seller contract price; harga Seller di marketplace tidak menjadi dasar tagihan.
3. Nomor order marketplace dan resi adalah referensi monitoring. Resi menjadi kunci pencarian retur.
4. Penjualan Seller yang nyata membuat `seller_order` -> stok gudang keluar -> `seller_sales` -> invoice AR Seller.
5. Pembayaran Seller adalah setoran terhadap saldo tagihan Seller secara keseluruhan. Sistem boleh mengalokasikan teknis ke invoice tertua, tetapi tidak pernah mengaitkan pembayaran ke resi.
6. Retur Seller dicari dari resi/order yang sudah ada. Saat Gudang menerima fisik retur, nilai harga internal dikurangi dari invoice/AR Seller.
7. Payout marketplace milik Seller hanya monitoring. Tidak masuk kas perusahaan dan tidak membuat tagihan baru. Tagihan sudah lahir dari penjualan PK01.
8. Payout marketplace milik perusahaan baru masuk kas perusahaan ketika settlement benar-benar dicatat.
9. Refund kas perusahaan hanya untuk retur transaksi perusahaan; retur Seller marketplace tidak membuat kas perusahaan keluar.
10. Tagihan manual Seller ditolak. Invoice normal hanya lahir dari order/penjualan nyata.
11. Nomor dokumen memakai registry PK01; tidak ada nomor random/dummy.
12. Dashboard Seller memisahkan Penjualan/Resi dari Tagihan/Pembayaran.

## Rantai data
`Marketplace Seller input -> seller_orders -> seller_sales -> seller_invoices -> seller_payments -> sisa tagihan`
`Resi -> shipment -> retur -> warehouse_received -> pengurang AR Seller`
`Marketplace payout Seller -> monitoring saja`
