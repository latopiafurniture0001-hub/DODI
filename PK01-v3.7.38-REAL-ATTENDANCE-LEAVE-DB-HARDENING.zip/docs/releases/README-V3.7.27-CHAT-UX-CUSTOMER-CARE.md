# PK01 v3.7.27 — CHAT UX + CUSTOMER CARE

- Chat internal tampil sebagai floating launcher di kiri bawah dashboard, dengan badge jumlah pesan baru dan polling notice.
- Notice unread disiapkan untuk Job nyata meskipun pengguna belum pernah membuka ruang chat.
- Chat Job tetap menjadi ruang Seller ↔ karyawan yang terhubung pada Job nyata.
- Ditambahkan Customer Care Chat untuk pengunjung website: widget kiri bawah dengan Chat Website + WhatsApp CS.
- Customer chat disimpan di database PK01; token publik hanya menjadi kredensial thread, bukan sumber data bisnis.
- CS/Admin dapat melihat inbox dan membalas konsumen dari modul Komunikasi.
- Nomor WhatsApp menggunakan pengaturan PK01 `company_whatsapp`; jika kosong, tombol WhatsApp tidak ditampilkan dan chat website tetap tersedia.
- Tidak ada dummy data.
