PK01 v3.6.60

Perbaikan fokus: activation-safe bootstrap, tidak menjalankan dbDelta/migrasi besar pada init, single runtime loader, duplicate PK01 guard, dan satu Shipping Engine canonical. Database setup untuk instalasi baru tersedia melalui Tools > PK01 Recovery. Alur bisnis dan role authorization dipertahankan.
