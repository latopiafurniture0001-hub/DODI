# PK01 v3.6.64 — Modular Security & Customer Service

## Tujuan
Memisahkan modul Security dan Customer Service dari core PK01 agar lebih mudah dikembangkan tanpa membuat `class-pk01-shortcodes.php` menjadi terlalu besar.

## Struktur
- `includes/modules/security/core/class-pk01-security.php` — logic Security, gate, visitor, vehicle, goods, incident, CCTV dan REST.
- `includes/modules/security/dashboard/class-pk01-security-dashboard.php` — UI dashboard Security & CCTV.
- `includes/modules/customer-service/core/class-pk01-customer-service.php` — logic tiket, percakapan dan REST Customer Service.
- `includes/modules/customer-service/dashboard/class-pk01-customer-service-dashboard.php` — UI dashboard Customer Service.
- `includes/modules/customer-service/channels/class-pk01-cs-channels.php` — daftar kanal layanan yang dapat dikembangkan terpisah.

## Kanal Customer Service
- Customer
- WhatsApp
- Seller
- Marketplace

Semua kanal menggunakan antrean tiket PK01 yang sama. Staff Customer Service/Admin dapat melihat dan menangani seluruh kanal; user non-staff dibatasi sesuai kepemilikan tiket.

## Keamanan
File core lama `includes/core/class-pk01-security.php` dan `includes/core/class-pk01-customer-service.php` dipindahkan, bukan diduplikasi, sehingga tidak ada class redeclaration.

## Kompatibilitas
- Endpoint REST Security tetap menggunakan namespace `pk01/v1/security/...`.
- Endpoint Customer Service tetap menggunakan `pk01/v1/customer-service/...`.
- Tabel PK01 yang sudah ada tidak dihapus.
- Dashboard lama memanggil renderer modular melalui `PK01_Shortcodes` sebagai facade kompatibilitas.
