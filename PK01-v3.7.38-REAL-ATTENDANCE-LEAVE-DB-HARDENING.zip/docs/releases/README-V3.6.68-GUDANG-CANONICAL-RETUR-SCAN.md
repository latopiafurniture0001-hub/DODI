PK01 v3.6.68 — GUDANG CANONICAL RETUR + SCAN

Perubahan:
- Inventory hub sekarang memiliki tab "Gudang & Tanda Terima" sehingga user tidak harus menemukan file/modul secara terpisah.
- Retur fisik hanya diproses oleh Gudang. Kasir tidak menjadi pintu penerimaan retur.
- Penerimaan retur sekarang berbasis scan/nomor resi; return_id dapat dicari otomatis dari tracking_no.
- Barang keluar ke kurir tetap berbasis scan resi dan membuat satu tanda terima unik.
- Gudang tetap menjadi pintu fisik: supplier -> gudang, produksi -> gudang, gudang -> kurir, kurir -> gudang (retur).
- Tidak membuat ledger stok/uangan kedua dan tidak menghapus data lama.
