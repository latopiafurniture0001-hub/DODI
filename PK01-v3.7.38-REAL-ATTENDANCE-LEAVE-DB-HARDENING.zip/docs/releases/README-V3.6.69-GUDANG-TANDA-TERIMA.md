# PK01 v3.6.69 — Gudang Retur & Tanda Terima

Perbaikan modul Gudang setelah v3.6.68:

- Memperbaiki renderer tab `Gudang & Tanda Terima` yang sebelumnya kosong karena mapping view `warehouse` belum terdaftar di Module Registry.
- Retur fisik tetap canonical di Gudang: scan nomor resi retur → penerimaan fisik → tanda terima retur → menunggu QC.
- Barang keluar ke kurir tetap berbasis scan resi dan satu tanda terima unik per pengiriman.
- Barang supplier yang masuk Gudang sekarang otomatis membuat tanda terima barang masuk.
- Bahan keluar dari Gudang ke Produksi dan sisa bahan kembali dari Produksi ke Gudang juga otomatis memiliki dokumen tanda terima di riwayat Gudang.
- Tidak membuat ledger stok kedua; seluruh perubahan stok tetap melalui Engine PK01 yang sudah ada.
- Hak akses tab `warehouse` ditambahkan untuk role Gudang dan Produksi.
- Tidak menghapus data lama.
