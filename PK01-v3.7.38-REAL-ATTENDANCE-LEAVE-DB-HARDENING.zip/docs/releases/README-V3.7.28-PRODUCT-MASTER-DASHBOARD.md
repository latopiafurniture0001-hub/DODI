# PK01 v3.7.28 — Product Master Dashboard Flow

- Administrator dashboard now has a prominent Product Master & SKU launcher.
- Clear flow: Master Produk → active product → Theme/E-Commerce → Seller/Marketplace.
- Seller marketplace wording changed from upload to catalog export to prevent confusion.
- Manual product section has a stable anchor for dashboard navigation.
- Product Master remains the single source of truth; no marketplace/Seller master-product creation.
