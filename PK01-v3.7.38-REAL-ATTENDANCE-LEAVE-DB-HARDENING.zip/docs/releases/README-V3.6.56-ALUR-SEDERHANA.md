# PK01 v3.6.56 — Alur Keuangan & Produksi Sederhana

## Keuangan
Pengguna diarahkan memahami 5 langkah: uang masuk → uang tersedia → bayar kebutuhan → catat pembayaran → lihat sisa/hasil. Detail akuntansi tetap di engine, tetapi UI laporan sederhana tidak menampilkan neraca.

## Produksi
Alur utama: pesanan masuk → buat Job → siapkan bahan → kerjakan (tim/CNC) → periksa hasil → selesai → siap dikirim. Status internal tetap dipertahankan agar integritas workflow tidak rusak.

## Prinsip
Tidak menghapus engine/ledger lama. Perubahan ini menyederhanakan navigasi dan penjelasan, bukan membuat data keuangan/produksi palsu.
