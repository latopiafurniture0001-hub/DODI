# PK01 v3.7.9 — Pembayaran Seller di Kasir

## Tujuan
Membuat menu pembayaran Kasir sesuai alur operasional: Seller harus sudah terdaftar, transaksi/order nyata menghasilkan invoice Seller, termin menentukan jatuh tempo, dan Kasir mencatat pembayaran terhadap invoice yang ada.

## Alur
Seller terdaftar → Order Seller nyata → Fulfillment → Invoice Seller → Termin/Jatuh Tempo → Kasir cari Resi/AWB atau Seller/Invoice/Order → tampil tagihan + sisa + status → catat pembayaran → invoice berubah UNPAID/PARTIAL/PAID → Buku Kas.

## Aturan
- Resi/AWB hanya alat pencarian/pengikat order, bukan sumber pembuatan tagihan.
- Tidak boleh membuat invoice Seller manual dari menu pembayaran.
- Pembayaran menggunakan Engine canonical `seller_pay_invoice()`.
- Termin disimpan di master `sales_accounts` melalui `payment_term_days` dan `payment_term_label`.
- Jika invoice dibuat tanpa due date, Engine menghitung jatuh tempo dari termin Seller.
- Pembayaran Seller adalah uang masuk ke kas usaha dan tercatat sebagai `Setoran Piutang Seller`.
- Komisi Seller tetap merupakan proses berbeda; pembayaran tagihan Seller tidak otomatis mencairkan komisi.
