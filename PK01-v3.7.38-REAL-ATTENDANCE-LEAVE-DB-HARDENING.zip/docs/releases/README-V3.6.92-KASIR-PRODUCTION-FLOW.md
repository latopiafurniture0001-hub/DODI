# PK01 v3.6.92 — KASIR → ORDER PRODUKSI

## Logika utama
1. Marketplace/Seller hanya menjadi sumber informasi penjualan; PK01 tidak bergantung pada API order marketplace.
2. Kasir mencatat penjualan dan memilih SKU/varian dari Master Produk PK01.
3. PK01 mengecek stok SKU tersebut.
4. Jika stok cukup, penjualan berjalan ke fulfillment/gudang.
5. Jika stok kurang, penjualan Kasir otomatis membuat **Order Produksi** untuk kekurangan qty. Sumber job dicatat sebagai order penjualan Kasir.
6. Team Produksi bekerja dari SKU/varian PK01, bukan nama produk marketplace.
7. Jika model belum ada di Master PK01, Kasir dapat mencentang **MODEL BARU** pada form penjualan. Model baru wajib memiliki:
   - Nama Model
   - Kode Produk
   - SKU PK01
   - Ukuran Panjang × Lebar × Tinggi
   - Material
   - Gambar Produk
   - Gambar Kerja/Drawing
   - Metode produksi
   - File CNC bila metode CNC
8. Setelah model baru disimpan, sistem membuat Master Produk + SKU/Variant PK01 dengan stok awal 0, lalu penjualan diproses. Karena stok awal 0, kebutuhan produksi dibuat dari penjualan Kasir.
9. Snapshot Order Produksi menyimpan ID Gambar Produk, Gambar Kerja, dan File CNC agar histori job tidak berubah jika Master Produk berubah.
10. Team Produksi menampilkan dokumen produksi dari snapshot dan hubungan ke sumber order Kasir.

## Tidak dilakukan
- Tidak mengambil order langsung dari marketplace untuk membuat SPK.
- Tidak membuat produk berdasarkan tebakan AI.
- Tidak menganggap nama marketplace sebagai SKU PK01.
- Tidak membuat AWB palsu.
- Tidak memotong stok saat Order Produksi dibuat.

## File utama
- `includes/modules/sales/cashier/tampilan-penjualan.php`
- `includes/modules/production/jobs/tampilan-produksi.php`
- `includes/core/class-pk01-engine.php`
- `includes/core/class-pk01-db.php`
