# PK01 v3.7.35 — Smart Plugin Auto Repair & Real Data Sync

- Auto-check canonical PK01 tables at runtime; if tables are actually missing, PK01 repairs the schema using the canonical DB installer.
- Auto-check official PK01 pages; missing/unpublished pages are recreated through `PK01_DB::ensure_pages()`.
- Finance General Ledger sync runs only from real PK01 transactions, idempotently; no dummy/demo transactions are created.
- Scheduled Smart Sync runs every 15 minutes via WP-Cron.
- Administrator receives a clear notice when database/pages/finance synchronization is not healthy.
- Recovery does not edit WordPress core files.
