# PK01 v3.7.11 — CNC + Prema Dual Stage Dispatch

## Alur resmi
Seller Dashboard → Kasir menerima Order Seller → jika stok kurang Engine membuat Job Produksi → PK01 membaca kebutuhan tahap → auto-dispatch assignment nyata → pekerja melihat Job yang sama.

## Tahap CNC
- Master G-code diambil dari `cnc_gcode_library` dengan prioritas varian/SKU → produk → material.
- Jika Master cocok tidak tersedia, tahap CNC berstatus blocked; PK01 tidak memilih file produk lain.
- Operator menerima ukuran, depth, material, versi dan Master G-code untuk diberikan manual ke komputer CNC. Mesin tidak dijalankan otomatis.

## Tahap CNC + Prema
- Satu Job Produksi memiliki dua assignment: role `cnc` dan `prema`.
- Sistem memilih pekerja berbeda berdasarkan `employee_job_roles`, lalu fallback posisi/divisi.
- Prema boleh menerima Job tetapi tidak dapat memulai sebelum assignment CNC selesai.
- CNC menyelesaikan tahap CNC saja; stok barang jadi belum ditambah.
- Prema/Finishing menjadi tahap akhir dan baru mencatat hasil produksi serta stok barang jadi.
- Status Job merupakan agregat seluruh assignment, bukan status satu pekerja.

## Kasir
Kasir memiliki Control Tower Job Produksi untuk melihat Job dari order Seller/penjualan, tahap, pekerja, status, dan tombol cek/kirim tahap. Tombol tersebut hanya menjalankan dispatch ke assignment yang belum ada; tidak menggandakan assignment tahap yang sudah aktif.

## Integritas
Tidak ada dummy worker, dummy G-code, atau eksekusi mesin otomatis. Jika pekerja/role belum tersedia, sistem menampilkan alasan dan Job tetap nyata di database.
