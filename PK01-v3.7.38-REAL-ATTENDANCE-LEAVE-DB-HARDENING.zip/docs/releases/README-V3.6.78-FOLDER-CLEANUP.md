# PK01 v3.6.78 — Folder Cleanup

## Tujuan
Merapiikan struktur source code agar setiap pekerjaan memiliki lokasi canonical yang mudah dicari ketika maintenance/update.

## Yang dipindahkan dari `includes/core/`
- Admin engine → `modules/admin/core/`
- Affiliate engine → `modules/seller/core/`
- AI + AI Orchestrator → `modules/ai/core/`
- Finance + Expense Workflow → `modules/finance/core/`
- HR Attendance engine → `modules/hr/core/`
- Shipping Smart engine → `modules/logistics/core/`
- DODI CNC + DODI Chat → `modules/production/core/`

## Yang sengaja tetap di `includes/core/`
Hanya mesin lintas modul/shared seperti DB, Engine, Kernel, Workflow, Authorization, Audit, Registry, REST, Bridge, Settings, Login, Frontend, Governance, Data Health, Backup, Idempotency, Duplicate Guard, dan utilitas bersama.

## Retur
Retur tetap canonical di `modules/warehouse/returns/`. Tidak dibuat salinan di Sales/Inventory.

## Kompatibilitas
Loader utama sudah diperbarui ke path baru. Nama class PHP tidak diubah, sehingga pemanggilan internal tetap menggunakan class yang sama.
