# PK01 v3.7.1 — Access & Folder Organization Repair

- Mempertahankan struktur modular v3.7.0.
- Memperbaiki launcher agar tidak pernah sengaja mengarah ke homepage WordPress biasa.
- Memulihkan halaman PK01 Portal/Dashboard bila option page ID hilang, tidak publish, atau salah menunjuk homepage.
- Memastikan URL launcher memakai halaman PK01 nyata yang memiliki shortcode [pk01_operasional].
- Tidak mengubah role/capability Administrator.
- Tidak membuat database paralel.
