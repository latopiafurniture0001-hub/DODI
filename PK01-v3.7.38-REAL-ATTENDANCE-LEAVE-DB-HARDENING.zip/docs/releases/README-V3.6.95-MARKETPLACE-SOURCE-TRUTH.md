# PK01 v3.6.95 — Marketplace Source of Truth

- Seller marketplace catalog uses PK01 E-Commerce/Theme Integration as source of truth for product name, SKU, variant, size, description, images, HPP and real stock.
- Seller can set a marketplace-specific selling price without changing PK01 HPP or Seller AR.
- Production exports are blocked until an administrator installs the current official marketplace template and verifies its column mapping.
- CSV/TSV/XLSX headers are read from the uploaded template; ambiguous fields such as `SKU` are not guessed.
- Admin gets a Marketplace Source & Template menu with template status and mapping verification.
- AI is advisory only: it may suggest field mapping/conflicts, but cannot invent SKU, stock, size, price or images and cannot mark a template verified without explicit admin confirmation.
- Seller downloads only a verified marketplace-specific export.
- Marketplace order flow remains Seller Dashboard -> Kasir -> stock check -> Warehouse / Production / Purchase.
