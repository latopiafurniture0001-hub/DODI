# PK01 v3.7.29 — Seller Marketplace Dashboard Flow

- Seller cards/actions no longer point to Seller management or Kasir umum; seller workspace stays on seller portal, except Job Chat and affiliate materials.
- Seller Beranda now shows Shopee, Tokopedia, TikTok Shop, Lazada download status and actions.
- Downloads are enabled only when the Administrator has installed and verified the official marketplace template.
- Administrator Beranda shows marketplace template readiness and a direct link to the Template Marketplace tab.
- Customer Care floating widget is no longer rendered on PK01 internal pages such as Communications; internal pages use Chat PK01.
- Source of truth remains PK01 Product Master → E-Commerce/Theme → Seller catalog.

Static validation only: PHP lint and ZIP integrity. WordPress/Hostinger runtime is not claimed tested.
