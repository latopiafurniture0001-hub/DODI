# PK01 v3.6.71 — Alur Operasional Terintegrasi

## Prinsip utama

PK01 menggunakan **satu transaksi nyata sebagai sumber kebenaran**. Modul tidak membuat order, resi, retur, packing, atau stok dummy hanya agar layar terlihat berisi. Setiap status berikut berasal dari data yang benar-benar tersimpan di database PK01.

## Alur Penjualan → Barang

1. **Kasir** membuat penjualan dan mencatat pembayaran.
2. Jika PAID dan stok tersedia, order otomatis berstatus **Siap Packing**.
3. Jika stok kurang, Engine membuat **Job Produksi** untuk kekurangan yang nyata. Setelah job selesai, order dilepas otomatis ke **Siap Packing**.
4. **Packing** memproses order yang berasal dari antrean penjualan. Setelah selesai: **Packed**.
5. **Logistik** membuat resi hanya dari order yang sudah Packed. Data pelanggan, alamat, kanal, dan order diambil otomatis dari order.
6. **Gudang** scan resi saat barang benar-benar diserahterimakan ke kurir. Pada titik ini order resmi menjadi **Shipped** dan dibuat **Tanda Terima Gudang → Kurir**.
7. Tracking kurir yang nyata memperbarui shipment/order. Saat Delivered, order menjadi **Completed**.

## Alur Retur

1. Retur harus terkait dengan **order penjualan nyata**.
2. Retur yang terdaftar menunggu barang fisik datang.
3. **Gudang** scan resi retur. Sistem mencari retur berdasarkan resi dan membuat **Tanda Terima Retur**. Status: `warehouse_received / menunggu QC`.
4. **QC Gudang** menentukan `good`, `damaged`, atau `reject`.
5. Hanya barang `good` yang menambah stok produk jadi. Tidak ada penambahan stok kedua saat tanda terima.
6. Setelah QC, order terkait menjadi retur/refund sesuai hasil proses.

## Pembagian pekerjaan

- **Kasir:** penjualan + pembayaran + pantauan status fulfillment. Tidak menerima retur, tidak membuat resi, tidak melakukan packing, dan tidak menyerahkan barang ke kurir.
- **Packing:** mengambil antrean order dari penjualan dan menyelesaikan packing.
- **Logistik:** membuat resi dari order yang sudah Packed dan mengelola tracking.
- **Gudang:** menerima barang fisik, scan barang keluar, serah-terima kurir, menerima retur, dan QC retur.
- **Produksi:** mengerjakan Job produksi yang benar-benar dibuat oleh kebutuhan stok/order.
- **Keuangan:** menangani kas/ledger dan transaksi keuangan; Kasir tidak mengelola modul kas terpisah.

## Aturan anti-duplikasi

- Satu order = satu sumber transaksi.
- Satu shipment = terhubung ke order.
- Resi tidak boleh dibuat dari order yang belum Packed.
- Membuat resi **belum berarti barang sudah keluar**.
- Barang resmi Shipped hanya setelah Gudang melakukan serah-terima fisik.
- Satu shipment hanya memiliki satu tanda terima outbound.
- Satu retur hanya memiliki satu tanda terima retur.
- Retur tidak masuk stok jual sebelum QC.
