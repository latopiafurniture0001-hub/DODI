# PK01 v3.6.67 — Retur Canonical Gudang

- Menghapus tab Retur dari Penjualan & Kasir.
- Menghapus tab Retur dari Pengiriman/Logistik.
- URL lama `sales_hub&pk01_tab=returns` dan `shipping_hub&pk01_tab=returns` dirender sebagai modul `returns` canonical milik Gudang.
- Penerimaan fisik retur tetap hanya pada role/modul Gudang.
- Kasir tidak menerima retur fisik.
- Tidak membuat ledger atau proses retur kedua.
