# PK01 v3.6.41 — Logout Critical Error Fix

## Root cause
`PK01_Audit::init()` registered `wp_logout` with `PK01_Audit::hook_user_logout`, but the method did not exist. WordPress therefore failed when the logout hook executed and showed a Critical Error.

## Fix
Added `PK01_Audit::hook_user_logout($user_id = 0)` with safe user lookup and centralized security audit logging.

## Flow after fix
Keluar → WordPress logout → PK01 audit hook → redirect to PK01 login/dashboard flow.

No sales, cash, AR, stock, or finance transaction is created by logout.
