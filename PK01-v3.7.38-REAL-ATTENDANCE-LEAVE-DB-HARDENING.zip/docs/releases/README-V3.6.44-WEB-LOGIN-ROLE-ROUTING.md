# PK01 v3.6.44 — Web Login → Role → Plugin Workspace

- Login tetap satu pintu melalui halaman login PK01/website.
- Role tetap berasal dari akun WordPress; plugin tidak membuat login kedua.
- Setelah autentikasi, role diarahkan ke workspace plugin yang relevan:
  - Produksi → Produksi
  - Karyawan → Pekerjaan Tim
  - Seller → Portal Seller
  - Gudang → Inventori
  - Kasir → Penjualan
  - Keuangan → Keuangan
  - SDM → SDM
  - Logistik/Packing → Pengiriman
  - Admin/Owner/Investor → Dashboard
- Redirect tujuan internal yang aman tetap dipertahankan saat pengguna masuk dari link modul tertentu.
- URL eksternal tidak diterima sebagai redirect login.
- Semua role operasional diberi capability `pk01_access_operational`.

Autentikasi tetap menggunakan akun WordPress melalui `wp_signon()` dan cookie sesi WordPress; PK01 hanya menyediakan UI/routing login. Ini mengikuti pola autentikasi WordPress untuk aplikasi frontend yang menggunakan sesi pengguna dan capability-based authorization.
