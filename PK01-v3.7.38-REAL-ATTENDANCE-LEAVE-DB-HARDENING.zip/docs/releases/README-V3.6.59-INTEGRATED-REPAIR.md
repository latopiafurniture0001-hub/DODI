# PK01 v3.6.59 — Integrated Repair

- Fix aktivasi ketika PK01 versi lama masih aktif.
- Deaktivasi otomatis salinan PK01 lama saat aktivasi versi baru.
- Bootstrap satu kali untuk mencegah class/function collision.
- PDF/FPDF lazy-load hanya ketika dokumen PDF diminta.
- Auto-init modul lama dihapus; init dikendalikan satu bootstrap pusat.
- Tidak mengubah alur bisnis utama, database pusat, role authorization, Security/CCTV, HR/Absensi/Cuti, Customer Service, Finance, atau Production.
- Runtime conflict dicatat pada option `pk01_runtime_conflict`.
