# PK01 v3.6.84 — Marketplace Simple Flow

- Penjualan Seller marketplace manual memakai harga internal PK01.
- Marketplace, nomor pesanan, dan resi hanya referensi.
- Harga Seller di marketplace tidak dicatat sebagai dasar tagihan.
- Penjualan Seller membuat order, mengurangi stok saat fulfillment, dan membuat invoice AR dari harga internal.
- Payout Seller tidak masuk kas perusahaan dan tidak membuat invoice baru.
- Pembayaran Seller tetap melalui Kasir (Cash/Transfer) dan mengurangi tagihan yang sudah ada.
- Payout marketplace perusahaan tetap mengikuti alur settlement manual perusahaan.
- Finance mengecualikan payout Seller dari jurnal kas perusahaan.
- Tidak ada API marketplace; semua input settlement/penjualan tetap manual.
