# PK01 v3.6.55 — Laporan Keuangan Sederhana

## Fokus
Laporan keuangan dibuat untuk pengguna non-akuntansi: uang masuk dari mana, uang keluar untuk apa, perubahan uang, dan laba/rugi usaha. Neraca/trial balance tidak ditampilkan di halaman utama.

## Alur
1. Uang masuk: penjualan, marketplace, modal, atau sumber lain.
2. Uang tersimpan di kas/bank.
3. Uang dipakai untuk bahan/barang, operasional, gaji, upah produksi, dan kebutuhan usaha lain.
4. Semua transaksi tetap dicatat pada database PK01 dan audit log.
5. Laporan membaca transaksi nyata untuk periode yang dipilih.

## Kategori yang dipisahkan
- HPP / bahan atau barang yang terjual
- Operasional kantor/usaha
- Gaji karyawan
- Upah pekerjaan produksi
- Penjualan bersih

Tidak ada input laba manual dan tidak ada neraca pada tampilan sederhana ini. Modul GL internal tetap dipertahankan untuk integritas sistem dan rekonsiliasi.
