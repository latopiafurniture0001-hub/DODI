# PK01 v3.7.32 — Chat Messenger + Internal Company Chat

- Floating Chat PK01 is now on the bottom-right and opens as a compact Messenger-style panel.
- Panel lists real Job conversations available to the logged-in user and an Internal Company room for employee/staff roles.
- Seller can only see Job rooms tied to the Seller's own real orders.
- Assigned employees can communicate with the Seller in the Job room and with other assigned employees in the same Job room.
- Employee/staff roles also get a separate `Chat Internal Perusahaan` room for company-internal communication; Sellers are excluded.
- Messages are stored in PK01 chat tables; no localStorage is used as a source of truth.
- Unread badge is checked periodically and marks messages read after the latest displayed message.
- Existing full Communications page remains available via "Buka semua percakapan".
- Chat tables are auto-installed/recovered via dbDelta on init.

Validation: PHP syntax lint only; WordPress/Hostinger runtime was not claimed.
