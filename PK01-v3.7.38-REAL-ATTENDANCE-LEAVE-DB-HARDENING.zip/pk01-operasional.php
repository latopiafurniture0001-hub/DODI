<?php
/**
 * Plugin Name: PK01 Operasional Usaha & AI
 * Plugin URI: https://dekoraliving.store/
 * Description: Business Operating System untuk produksi, pembelian, stok, penjualan, seller, keuangan, AI dan integrasi Masterpiece Commerce.
 * Version: 3.7.38
 * Author: PK01 / Masterpiece
 * Text Domain: pk01-operasional
 */
if (!defined('ABSPATH')) exit;

/*
 * IMPORTANT: activation must remain independent from the runtime loader.
 * Never install schema, create pages, load PDF libraries, or initialize modules
 * from the activation callback. This prevents a single broken module from taking
 * down wp-admin during activation.
 */
if (!function_exists('pk01_operasional_activate_360')) {
    function pk01_operasional_activate_360() {
        global $wpdb;
        // Preserve an existing schema marker. Older builds incorrectly reset this
        // to zero, forcing a huge dbDelta/migration on the first request after activation.
        $schema = get_option('pk01_schema_version', '');
        if ($schema === '' || $schema === false) {
            $prefix = (isset($wpdb->prefix) && is_string($wpdb->prefix) && $wpdb->prefix !== '') ? $wpdb->prefix : 'wp_';
            $core = $prefix . 'pk01_products';
            $exists = false;
            if (isset($wpdb) && is_object($wpdb) && method_exists($wpdb, 'get_var')) {
                $exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $core)) === $core);
            }
            // Existing installations keep their tables. Fresh installs are marked
            // pending and initialized from the explicit admin setup action later.
            update_option('pk01_schema_version', $exists ? '3.6.60' : '0', false);
            update_option('pk01_schema_pending', $exists ? 0 : 1, false);
        }
        update_option('pk01_activation_safe', '3.6.64', false);
        delete_option('pk01_boot_errors');
        delete_option('pk01_runtime_conflict');
        flush_rewrite_rules(false);
    }
}
register_activation_hook(__FILE__, 'pk01_operasional_activate_360');
if (!function_exists('pk01_operasional_deactivate_360')) {
    function pk01_operasional_deactivate_360() {
        if (function_exists('wp_clear_scheduled_hook')) wp_clear_scheduled_hook('pk01_smart_sync_event');
        if (function_exists('flush_rewrite_rules')) flush_rewrite_rules(false);
    }
}
register_deactivation_hook(__FILE__, 'pk01_operasional_deactivate_360');

// One authoritative PK01 runtime instance. If an older copy is already loaded,
// this copy stays passive for this request instead of redeclaring classes.
if (defined('PK01_BOOTSTRAPPED')) {
    return;
}
define('PK01_BOOTSTRAPPED', true);
define('PK01_VERSION', '3.7.38');
define('PK01_FILE', __FILE__);
define('PK01_DIR', plugin_dir_path(__FILE__));
define('PK01_URL', plugin_dir_url(__FILE__));

/*
 * PK01 Diagnostic Guard v3.7.5
 * Tujuan: bila satu file/modul menyebabkan fatal error, simpan lokasi file,
 * tahap bootstrap, error PHP, dan lingkungan dasar ke log terpisah.
 * Logger ini sengaja memakai PHP native agar tetap bekerja bahkan saat
 * WordPress sedang mengalami fatal error.
 */
if (!defined('PK01_DEBUG_VERSION')) define('PK01_DEBUG_VERSION', '1.0');
$GLOBALS['pk01_debug_current_file'] = 'bootstrap:main-plugin';
$GLOBALS['pk01_debug_stage'] = 'plugin-loaded';

function pk01_debug_log_path() {
    $base = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : (defined('ABSPATH') ? rtrim(ABSPATH,'/\\') . '/wp-content' : dirname(__FILE__));
    return rtrim($base,'/\\') . '/uploads/pk01-debug/pk01-debug.log';
}
function pk01_debug_write($event, $data = []) {
    $file = pk01_debug_log_path();
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $row = [
        'time' => function_exists('date_i18n') ? @date_i18n('c') : date('c'),
        'event' => (string)$event,
        'plugin_version' => defined('PK01_VERSION') ? PK01_VERSION : '',
        'php' => PHP_VERSION,
        'file' => isset($GLOBALS['pk01_debug_current_file']) ? (string)$GLOBALS['pk01_debug_current_file'] : '',
        'stage' => isset($GLOBALS['pk01_debug_stage']) ? (string)$GLOBALS['pk01_debug_stage'] : '',
        'data' => is_array($data) ? $data : ['value'=>(string)$data],
    ];
    @file_put_contents($file, wp_json_encode($row, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . PHP_EOL, FILE_APPEND | LOCK_EX);
}
function pk01_debug_shutdown_guard() {
    $e = error_get_last();
    if (!$e) return;
    $fatal_types = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
    if (!in_array((int)$e['type'], $fatal_types, true)) return;
    pk01_debug_write('FATAL_ERROR', [
        'type' => (int)$e['type'],
        'message' => isset($e['message']) ? substr((string)$e['message'], 0, 1000) : '',
        'error_file' => isset($e['file']) ? (string)$e['file'] : '',
        'error_line' => isset($e['line']) ? (int)$e['line'] : 0,
        'request_uri' => isset($_SERVER['REQUEST_URI']) ? substr((string)$_SERVER['REQUEST_URI'], 0, 500) : '',
    ]);
}
if (!defined('PK01_DEBUG_SHUTDOWN_REGISTERED')) {
    define('PK01_DEBUG_SHUTDOWN_REGISTERED', true);
    register_shutdown_function('pk01_debug_shutdown_guard');
}
pk01_debug_write('BOOT', [
    'wp_version' => defined('WP_VERSION') ? WP_VERSION : '',
    'is_admin' => function_exists('is_admin') ? (bool)is_admin() : null,
    'memory_limit' => ini_get('memory_limit'),
]);

$pk01_files = [
 'includes/core/class-pk01-settings.php','includes/core/class-pk01-product-master.php','includes/core/class-pk01-master-contract.php','includes/core/class-pk01-idempotency.php','includes/core/class-pk01-duplicate-guard.php','includes/modules/seller/core/class-pk01-affiliate.php','includes/core/class-pk01-data-health.php','includes/core/class-pk01-audit.php','includes/core/class-pk01-backup.php','includes/core/class-pk01-db.php','includes/core/class-pk01-smart-plugin.php','includes/core/class-pk01-domain.php','includes/core/class-pk01-authorization.php','includes/core/class-pk01-module-registry.php','includes/core/class-pk01-operational-flow.php','includes/core/class-pk01-engine.php','includes/modules/finance/core/class-pk01-finance.php','includes/modules/finance/core/class-pk01-expense-workflow.php','includes/core/class-pk01-kernel.php',
 'includes/modules/ai/core/class-pk01-ai.php','includes/modules/ai/core/class-pk01-ai-orchestrator.php','includes/core/class-pk01-ecommerce.php','includes/modules/marketplace/core/class-pk01-marketplace-catalog.php','includes/modules/logistics/core/class-pk01-shipping-smart.php',
 'includes/core/class-pk01-governance.php','includes/core/class-pk01-central-bridge.php','includes/core/class-pk01-theme-integration.php','includes/core/class-pk01-rest.php',
 'includes/core/class-pk01-workflow.php','includes/modules/customer-service/channels/class-pk01-cs-channels.php','includes/modules/customer-service/core/class-pk01-customer-service.php','includes/modules/security/core/class-pk01-security.php','includes/modules/hr/core/class-pk01-hr-attendance.php','includes/modules/customer-service/dashboard/class-pk01-customer-service-dashboard.php','includes/modules/security/dashboard/class-pk01-security-dashboard.php','includes/core/class-pk01-login.php','includes/core/class-pk01-shortcodes.php','includes/core/class-pk01-frontend.php','includes/modules/admin/core/class-pk01-admin.php','includes/core/pdf-loader.php',
 'includes/core/class-pk01-ops-tools.php','includes/modules/production/core/class-pk01-dodi-cnc.php','includes/modules/production/core/class-pk01-dodi-chat.php','includes/modules/production/cnc-library/class-pk01-cnc-library.php'
];

function pk01_customer_service_theme_conflict_file() {
    // Masterpiece-Commerce already provides PK01_Customer_Service in the active
    // theme. Do not load the plugin's duplicate declaration when that integration
    // file exists; the plugin bootstrap can use the theme-owned class later.
    $slugs = [];
    if (function_exists('get_option')) {
        $slugs[] = (string)get_option('stylesheet', '');
        $slugs[] = (string)get_option('template', '');
    }
    $slugs = array_values(array_unique(array_filter($slugs)));
    foreach ($slugs as $slug) {
        $candidate = trailingslashit(WP_CONTENT_DIR) . 'themes/' . sanitize_file_name($slug) . '/inc/integration/customer-service.php';
        if (is_readable($candidate)) return $candidate;
    }
    return '';
}

function pk01_load_runtime_files() {
    global $pk01_files;
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;
    foreach ((array)$pk01_files as $file) {
        $path = PK01_DIR . $file;
        $GLOBALS['pk01_debug_current_file'] = $path;
        $GLOBALS['pk01_debug_stage'] = 'require_runtime_file';

        // Prevent the known Customer Service class collision with the active
        // Masterpiece-Commerce theme. The theme implementation is allowed to
        // remain the owner of PK01_Customer_Service when present.
        if ($file === 'includes/modules/customer-service/core/class-pk01-customer-service.php') {
            $theme_conflict = pk01_customer_service_theme_conflict_file();
            if ($theme_conflict !== '') {
                pk01_debug_write('SKIP_THEME_CLASS_CONFLICT', [
                    'plugin_file' => $path,
                    'theme_file' => $theme_conflict,
                    'class' => 'PK01_Customer_Service',
                ]);
                continue;
            }
        }

        if (!is_readable($path)) {
            pk01_debug_write('SKIP_UNREADABLE_FILE', ['path'=>$path]);
            continue;
        }
        pk01_debug_write('REQUIRE_START', ['path'=>$path]);
        try {
            require_once $path;
            pk01_debug_write('REQUIRE_OK', ['path'=>$path]);
        } catch (Throwable $e) {
            pk01_debug_write('REQUIRE_THROWABLE', ['path'=>$path,'class'=>get_class($e),'message'=>substr($e->getMessage(),0,1000),'line'=>(int)$e->getLine()]);
            $errors = get_option('pk01_boot_errors', []);
            if (!is_array($errors)) $errors = [];
            $errors[] = basename($path) . ': ' . substr($e->getMessage(), 0, 300);
            update_option('pk01_boot_errors', array_slice($errors, -30), false);
        }
    }
}

add_action('admin_post_pk01_product_master_template', ['PK01_Product_Master','export_template']);

add_action('plugins_loaded', 'pk01_runtime_conflict_guard', 0);
function pk01_runtime_conflict_guard() {
    if (!function_exists('get_plugins')) return;
    $self = plugin_basename(__FILE__);
    $active = (array)get_option('active_plugins', []);
    $all = get_plugins();
    $conflicts = [];
    foreach ($active as $plugin) {
        if ($plugin === $self || empty($all[$plugin])) continue;
        $name = strtolower((string)($all[$plugin]['Name'] ?? ''));
        $file = strtolower((string)$plugin);
        if (strpos($name, 'pk01') !== false || strpos($file, 'pk01-operasional') !== false) $conflicts[] = $plugin;
    }
    if ($conflicts) update_option('pk01_runtime_conflict', $conflicts, false);
    else delete_option('pk01_runtime_conflict');
}
add_action('plugins_loaded', 'pk01_load_runtime_files', 1);

function pk01_bootstrap() {
    $init_map = [
        'PK01_Settings','PK01_Idempotency','PK01_Duplicate_Guard','PK01_Affiliate','PK01_Audit','PK01_Backup','PK01_DB','PK01_Smart_Plugin','PK01_Domain','PK01_Data_Health','PK01_Authorization','PK01_Module_Registry','PK01_Operational_Flow','PK01_Engine','PK01_Finance','PK01_Expense_Workflow','PK01_Kernel','PK01_Workflow','PK01_Customer_Service','PK01_Security','PK01_HR_Attendance','PK01_AI','PK01_AI_Orchestrator','PK01_Ecommerce','PK01_Marketplace_Catalog','PK01_Shipping_Smart','PK01_Governance','PK01_Central_Bridge','PK01_Theme_Integration','PK01_REST','PK01_Login','PK01_Shortcodes','PK01_Frontend','PK01_Admin','PK01_Ops_Tools','PK01_DODI_CNC','PK01_DODI_Chat','PK01_CNC_Library'
    ];
    foreach ($init_map as $class) {
        $GLOBALS['pk01_debug_current_file'] = 'bootstrap:init:' . $class;
        $GLOBALS['pk01_debug_stage'] = 'class_init';
        if (!class_exists($class) || !method_exists($class, 'init')) {
            pk01_debug_write('INIT_SKIP', ['class'=>$class,'reason'=>'class_or_init_missing']);
            continue;
        }
        pk01_debug_write('INIT_START', ['class'=>$class]);
        try { call_user_func([$class, 'init']); pk01_debug_write('INIT_OK', ['class'=>$class]); }
        catch (Throwable $e) {
            pk01_debug_write('INIT_THROWABLE', ['class'=>$class,'exception'=>get_class($e),'message'=>substr($e->getMessage(),0,1000),'line'=>(int)$e->getLine()]);
            $errors = get_option('pk01_boot_errors', []); if (!is_array($errors)) $errors = [];
            $errors[] = $class . '::init: ' . substr($e->getMessage(), 0, 300);
            update_option('pk01_boot_errors', array_slice($errors, -30), false);
        }
    }
}
function pk01_runtime_bootstrap() {
    static $ran = false;
    if ($ran) return;
    $ran = true;
    pk01_load_runtime_files();
    pk01_bootstrap();
}
add_action('init', 'pk01_runtime_bootstrap', 1);

/*
 * Database migration is deliberately NOT executed on every request.
 * Existing installations retain their previous schema marker. If a migration is
 * actually pending, it is performed only from an explicit administrator action.
 */
function pk01_debug_admin_menu() {
    if (!function_exists('current_user_can') || !current_user_can('manage_options')) return;
    add_management_page('PK01 Debug', 'PK01 Debug', 'manage_options', 'pk01-debug', 'pk01_debug_admin_page');
}
add_action('admin_menu', 'pk01_debug_admin_menu', 5);
function pk01_debug_admin_page() {
    if (!current_user_can('manage_options')) return;
    $file = pk01_debug_log_path();
    $log = is_readable($file) ? @file_get_contents($file) : '';
    if (isset($_POST['pk01_debug_clear']) && check_admin_referer('pk01_debug_clear')) {
        @file_put_contents($file, '');
        $log = '';
        echo '<div class="notice notice-success"><p>Log PK01 Debug sudah dikosongkan.</p></div>';
    }
    echo '<div class="wrap"><h1>PK01 Debug</h1>';
    echo '<p><strong>Tujuan:</strong> jika PK01 mengalami Critical Error, berikan isi log ini kepada AI. Log mencatat file terakhir yang dimuat dan fatal error PHP.</p>';
    echo '<p><strong>Lokasi log:</strong> <code>'.esc_html($file).'</code></p>';
    echo '<p><strong>Versi plugin:</strong> '.esc_html(defined('PK01_VERSION')?PK01_VERSION:'').'</p>';
    echo '<p><a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('tools.php?page=pk01-debug&download=1'),'pk01_debug_download')).'">Download Debug Log</a></p>';
    if (isset($_GET['download']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'pk01_debug_download')) {
        if (is_readable($file)) { nocache_headers(); header('Content-Type: text/plain; charset=utf-8'); header('Content-Disposition: attachment; filename="pk01-debug.log"'); readfile($file); exit; }
    }
    echo '<form method="post" style="margin:12px 0">'.wp_nonce_field('pk01_debug_clear','_wpnonce',true,false).'<button class="button" name="pk01_debug_clear" value="1">Kosongkan Log</button></form>';
    echo '<textarea readonly style="width:100%;min-height:520px;font-family:monospace;font-size:12px">'.esc_textarea($log ?: 'Belum ada log. Jika terjadi Critical Error, buka halaman ini setelah site pulih atau ambil file log dari lokasi di atas.').'</textarea>';
    echo '</div>';
}

function pk01_admin_recovery_menu() {
    if (!current_user_can('manage_options')) return;
    add_management_page('PK01 Recovery & Database', 'PK01 Recovery', 'manage_options', 'pk01-recovery', 'pk01_admin_recovery_page');
}
add_action('admin_menu', 'pk01_admin_recovery_menu', 20);

function pk01_admin_recovery_page() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['pk01_repair_schema']) && check_admin_referer('pk01_repair_schema')) {
        try {
            if (class_exists('PK01_DB') && method_exists('PK01_DB','install')) {
                PK01_DB::install();
                update_option('pk01_schema_version', PK01_VERSION, false);
                update_option('pk01_schema_pending', 0, false);
                update_option('pk01_schema_last_error', '', false);
                echo '<div class="notice notice-success"><p>Database PK01 berhasil diperiksa/diperbaiki.</p></div>';
            }
        } catch (Throwable $e) {
            update_option('pk01_schema_last_error', substr($e->getMessage(),0,500), false);
            echo '<div class="notice notice-error"><p>Perbaikan database gagal: '.esc_html($e->getMessage()).'</p></div>';
        }
    }
    $pending = (int)get_option('pk01_schema_pending',0);
    $err = (string)get_option('pk01_schema_last_error','');
    echo '<div class="wrap"><h1>PK01 Recovery & Database</h1><p>Gunakan halaman ini hanya jika instalasi baru atau migrasi database memang diperlukan.</p>';
    if ($pending) echo '<div class="notice notice-warning"><p>Database PK01 belum diinisialisasi.</p></div>';
    if ($err) echo '<div class="notice notice-error"><p>'.esc_html($err).'</p></div>';
    echo '<form method="post">'.wp_nonce_field('pk01_repair_schema','_wpnonce',true,false).'<p><button class="button button-primary" name="pk01_repair_schema" value="1">Periksa / Pasang Database PK01</button></p></form></div>';
}

add_action('admin_notices', function(){
    if (!current_user_can('manage_options')) return;
    $c = (array)get_option('pk01_runtime_conflict', []);
    if ($c) echo '<div class="notice notice-error"><p><strong>PK01:</strong> ditemukan salinan PK01 lain yang masih aktif. Gunakan hanya satu versi PK01.</p></div>';
    $pending = (int)get_option('pk01_schema_pending',0);
    if ($pending) echo '<div class="notice notice-warning"><p><strong>PK01:</strong> database belum diinisialisasi. Buka <a href="'.esc_url(admin_url('tools.php?page=pk01-recovery')).'">PK01 Recovery</a>.</p></div>';
});
