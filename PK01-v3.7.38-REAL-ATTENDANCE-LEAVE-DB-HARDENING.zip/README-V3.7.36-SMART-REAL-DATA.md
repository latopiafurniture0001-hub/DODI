# PK01 v3.7.36 — SMART REAL DATA / NO DUMMY

## Prinsip
- Tidak ada transaksi, produk, seller, stok, job, pembayaran, atau produksi demo/dummy.
- Infrastruktur yang benar-benar hilang (tabel/laman) boleh dibuat otomatis.
- Integrasi yang tidak dapat dijalankan karena API/kredensial/template resmi belum tersedia harus ditandai dengan status dan alasan, bukan dipalsukan.

## Smart Data Health
- Pengaturan memiliki panel Kesehatan & Data Nyata.
- Menampilkan total baris data, baris lengkap, kelengkapan per domain, jumlah transaksi penjualan sepanjang waktu, dan jumlah Job produksi nyata.
- Pemeriksaan dapat dijalankan manual; hasil disimpan sebagai health result.
- Perbaikan struktur + sinkronisasi hanya menggunakan sumber data PK01 yang sudah ada.

## Dashboard Administrator
Menampilkan:
- jumlah transaksi penjualan nyata sepanjang waktu;
- jumlah Job produksi yang pernah dibuat dan yang selesai;
- jumlah baris data lengkap vs total;
- skor/status kesehatan data.

## Validasi
PHP lint dan ZIP integrity harus dijalankan sebelum distribusi. Runtime database Hostinger tetap harus diverifikasi setelah instalasi.
