<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Operational Flow 1.0
 * Satu alur status lintas Penjualan -> Packing -> Pengiriman -> Retur.
 * Kelas ini TIDAK membuat data bisnis baru. Ia hanya menyelaraskan status
 * dari transaksi nyata yang sudah ada di Engine PK01.
 */
class PK01_Operational_Flow {
    public static function init() {}

    public static function role_can_mutate($area) {
        $role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
        if (in_array($role, ['administrator','pk01_admin'], true)) return true;
        $map = [
            'sales' => ['pk01_kasir'],
            'packing' => ['pk01_packing','pk01_logistik'],
            'shipping' => ['pk01_logistik'],
            'warehouse' => ['pk01_gudang'],
            'returns' => ['pk01_gudang'],
        ];
        return in_array($role, $map[$area] ?? [], true);
    }

    public static function cashier_read_only($area) {
        $role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
        return $role === 'pk01_kasir' && in_array($area, ['shipping','returns','warehouse'], true);
    }

    public static function status_label($status) {
        $map = [
            'pending'=>'Menunggu', 'processing'=>'Diproses', 'ready_to_pack'=>'Siap Packing',
            'packing'=>'Sedang Packing', 'packed'=>'Sudah Packing', 'label_created'=>'Resi Dibuat',
            'on_process'=>'Dalam Pengiriman', 'shipped'=>'Terkirim ke Kurir', 'delivered'=>'Sampai Pelanggan',
            'returned'=>'Retur', 'refunded'=>'Refund', 'cancelled'=>'Dibatalkan', 'completed'=>'Selesai'
        ];
        $key = strtolower((string)$status);
        return $map[$key] ?? ucwords(str_replace('_',' ',$key ?: '-'));
    }

    /** Pesanan paid + stok siap menjadi pekerjaan packing; tidak membuat order baru. */
    public static function release_to_packing($order_id) {
        global $wpdb;
        $t = PK01_DB::t('sales_orders');
        $o = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d", (int)$order_id), ARRAY_A);
        if (!$o) return false;
        if (in_array(strtolower((string)$o['status']), ['cancelled','failed','refunded'], true)) return false;
        if (strtolower((string)($o['payment_status'] ?? '')) !== 'paid') return false;
        if (in_array(strtolower((string)($o['shipping_status'] ?? '')), ['shipped','delivered','returned'], true)) return false;
        $new = 'ready_to_pack';
        if ((string)($o['shipping_status'] ?? '') === $new) return true;
        $wpdb->update($t, ['shipping_status'=>$new], ['id'=>(int)$order_id]);
        return true;
    }

    /** Produksi selesai untuk order kekurangan stok -> lepaskan ke antrean packing. */
    public static function release_order_job($job_no) {
        global $wpdb;
        $job_no = (string)$job_no;
        if (strpos($job_no, 'ORDER-') !== 0) return false;
        $invoice = substr($job_no, 6);
        $t = PK01_DB::t('sales_orders');
        $oid = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE order_no=%s OR invoice_no=%s LIMIT 1", $invoice, $invoice));
        return $oid ? self::release_to_packing($oid) : false;
    }

    public static function monitor_orders($limit=30) {
        global $wpdb;
        $limit=max(1,min(100,(int)$limit));
        $so=PK01_DB::t('sales_orders'); $sh=PK01_DB::t('shipments'); $rt=PK01_DB::t('returns');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT o.id,o.order_no,o.customer_name,o.product_name,o.qty,o.payment_status,o.status,o.shipping_status,o.tracking_no,o.created_at,
                    s.courier,s.status AS shipment_status,r.return_no,r.status AS return_status
             FROM `{$so}` o
             LEFT JOIN `{$sh}` s ON s.sale_id=o.id
             LEFT JOIN `{$rt}` r ON r.order_id=o.id AND r.id=(SELECT MAX(r2.id) FROM `{$rt}` r2 WHERE r2.order_id=o.id)
             ORDER BY o.id DESC LIMIT %d", $limit), ARRAY_A) ?: [];
    }
}
