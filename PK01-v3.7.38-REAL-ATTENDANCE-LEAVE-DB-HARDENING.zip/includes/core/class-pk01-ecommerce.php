<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise E-Commerce & Storefront Gateway
 * Menghubungkan tema toko online, keranjang belanja, REST API produk, 
 * dan portal pemesanan seller langsung ke Business Engine PK01.
 */
class PK01_Ecommerce {

    public static function init() {
        // Registrasi REST API Endpoint Toko Online
        add_action('rest_api_init', [__CLASS__, 'routes']);

        // AJAX Checkout Pesanan Satuan (Single Buy Now)
        add_action('wp_ajax_pk01_store_sale',        [__CLASS__, 'ajax_sale']);
        add_action('wp_ajax_nopriv_pk01_store_sale', [__CLASS__, 'ajax_sale']);

        // AJAX Checkout Keranjang Belanja (Multi-Item Cart)
        add_action('wp_ajax_pk01_store_order',        [__CLASS__, 'ajax_order']);
        add_action('wp_ajax_nopriv_pk01_store_order', [__CLASS__, 'ajax_order']);

        // AJAX Portal Pemesanan Mitra Seller
        add_action('wp_ajax_pk01_seller_order',        [__CLASS__, 'seller_order']);
        add_action('wp_ajax_nopriv_pk01_seller_order', [__CLASS__, 'seller_order']);

        // Shortcode Portal Mandiri Seller
        add_shortcode('pk01_seller_portal', [__CLASS__, 'seller_portal']);
    }

    /**
     * Daftarkan Rute REST API Toko Online
     */
    public static function routes() {
        register_rest_route('pk01/v2', '/store/products', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'products'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('pk01/v2', '/store/product/(?P<sku>[A-Za-z0-9\-_]+)', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'product_by_sku'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('pk01/v2', '/store/health', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'health'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('pk01/v2', '/store/seller/(?P<token>[A-Za-z0-9_\-]+)', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'seller_products'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('pk01/v2', '/store/config', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'config'],
            'permission_callback' => '__return_true'
        ]);
    }

    public static function health() {
        return rest_ensure_response([
            'ok'              => true,
            'plugin_version'  => defined('PK01_VERSION') ? PK01_VERSION : '2.4.0',
            'integration'     => 'PK01 Business Engine → Storefront Theme',
            'database_status' => 'connected'
        ]);
    }

    public static function config() {
        return rest_ensure_response([
            'ok'                => true,
            'plugin_version'    => defined('PK01_VERSION') ? PK01_VERSION : '2.4.0',
            'products_endpoint' => rest_url('pk01/v2/store/products'),
            'health_endpoint'   => rest_url('pk01/v2/store/health'),
            'source_of_truth'   => 'PK01 Operasional'
        ]);
    }

    /**
     * API KATALOG PRODUK REAL-TIME
     * Mengambil produk aktif, varian SKU, harga terkini, dan stok fisik riil.
     */
    public static function products() {
        global $wpdb;

        $tbl = function($k) use ($wpdb) {
            return class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
        };

        $p_tbl  = $tbl('products');
        $v_tbl  = $tbl('product_variants');
        $st_tbl = $tbl('stock_transactions');

        $rows = $wpdb->get_results(
            "SELECT 
                p.id, p.code, p.name, p.slug, p.description, p.image_id, p.status, p.category, p.brand, p.product_length, p.product_width, p.product_height, p.product_weight, p.weight_unit,
                v.id AS variant_id, v.sku, v.name AS variant_name, v.size, v.material, v.finishing, 
                v.hpp, COALESCE(v.price, 0) AS direct_price, COALESCE(v.stock, 0) AS direct_stock, v.supply_mode,
                COUNT(st.id) AS stock_tx_count,
                COALESCE(SUM(CASE WHEN st.direction = 'in' THEN st.qty ELSE -st.qty END), 0) AS calculated_stock
             FROM `{$p_tbl}` p
             INNER JOIN `{$v_tbl}` v ON v.product_id = p.id
             LEFT JOIN `{$st_tbl}` st ON st.stock_type = 'finished' AND st.item_id = v.id
             WHERE p.status = 'active' AND v.status = 'active'
             GROUP BY p.id, v.id
             ORDER BY p.id DESC, v.id ASC",
            ARRAY_A
        ) ?: [];

        $out = [];
        foreach ($rows as $r) {
            $key = (int)$r['id'];
            if (!isset($out[$key])) {
                $img_url = !empty($r['image_id']) ? wp_get_attachment_image_url((int)$r['image_id'], 'large') : '';
                $out[$key] = [
                    'id'          => $key,
                    'code'        => $r['code'],
                    'name'        => $r['name'],
                    'slug'        => $r['slug'] ?: sanitize_title($r['name']),
                    'description' => $r['description'] ?: '',
                    'category'    => (string)($r['category'] ?? ''),
                    'brand'       => (string)($r['brand'] ?? ''),
                    'length'      => (float)($r['product_length'] ?? 0),
                    'width'       => (float)($r['product_width'] ?? 0),
                    'height'      => (float)($r['product_height'] ?? 0),
                    'weight'      => (float)($r['product_weight'] ?? 0),
                    'weight_unit' => (string)($r['weight_unit'] ?? 'kg'),
                    'image'       => $img_url,
                    'variants'    => []
                ];
            }

            // Hitung Stok: Prioritaskan stok transaksi, fallback ke stok langsung
            $final_stock = ((int)($r['stock_tx_count'] ?? 0) > 0) ? (float)$r['calculated_stock'] : (float)$r['direct_stock'];
            
            // Dapatkan Harga Varian dengan Sistem Multi-Source Fallback
            $final_price = self::price_for_variant((int)$r['variant_id'], (float)$r['direct_price'], $r['sku']);

            $out[$key]['variants'][] = [
                'id'           => (int)$r['variant_id'],
                'sku'          => $r['sku'],
                'name'         => $r['variant_name'],
                'size'         => $r['size'],
                'material'     => $r['material'],
                'finishing'    => $r['finishing'],
                'hpp'          => (float)$r['hpp'],
                'price'        => $final_price,
                'price_format' => 'Rp ' . number_format($final_price, 0, ',', '.'),
                'stock'        => max(0, $final_stock),
                'supply_mode' => $r['supply_mode'] ?: 'production',
                'stock_source' => ((int)($r['stock_tx_count'] ?? 0) > 0) ? 'PK01 stock_transactions (real movement)' : 'PK01 master variant.stock (opening/fallback)'
            ];
        }

        return rest_ensure_response(array_values($out));
    }

    public static function product_by_sku($req) {
        $sku = sanitize_text_field($req['sku']);
        $data = self::products()->get_data();

        foreach ($data as $p) {
            foreach ($p['variants'] as $v) {
                if (strcasecmp($v['sku'], $sku) === 0) {
                    $p['selected_variant'] = $v;
                    return rest_ensure_response($p);
                }
            }
        }

        return new WP_Error('pk01_not_found', 'Produk dengan SKU tersebut tidak ditemukan.', ['status' => 404]);
    }

    public static function price_for_variant_public($vid) {
        return self::price_for_variant($vid);
    }

    /**
     * SISTEM RESOLVER HARGA CERDAS (MULTI-SOURCE FALLBACK)
     * Memeriksa harga di product_prices, tabel pricing, dan kolom varian agar harga tidak pernah 0.
     */
    private static function price_for_variant($vid, $fallback_price = 0, $sku = '') {
        global $wpdb;

        // 1. Cek Tabel product_prices (Harga Terjadwal)
        $t_pp = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_prices') : $wpdb->prefix . 'pk01_product_prices';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_pp)) === $t_pp) {
            $p1 = $wpdb->get_var($wpdb->prepare(
                "SELECT price FROM `{$t_pp}` 
                 WHERE variant_id = %d 
                 AND (valid_to IS NULL OR valid_to = '0000-00-00 00:00:00' OR valid_to > NOW()) 
                 ORDER BY valid_from DESC, id DESC LIMIT 1",
                $vid
            ));
            if ($p1 !== null && (float)$p1 > 0) return (float)$p1;
        }

        // 2. Cek Tabel Master pricing (Persetujuan Harga Jual)
        $t_prc = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('pricing') : $wpdb->prefix . 'pk01_pricing';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_prc)) === $t_prc) {
            $p2 = $wpdb->get_var($wpdb->prepare(
                "SELECT price FROM `{$t_prc}` 
                 WHERE (variant_id = %d OR (sku != '' AND sku = %s)) 
                 AND status = 'approved' 
                 ORDER BY id DESC LIMIT 1",
                $vid, $sku
            ));
            if ($p2 !== null && (float)$p2 > 0) return (float)$p2;
        }

        // 3. Gunakan Harga Langsung dari Varian
        if ($fallback_price > 0) {
            return (float)$fallback_price;
        }

        // 4. Query langsung ke tabel varian jika belum ada
        $t_var = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_variants') : $wpdb->prefix . 'pk01_product_variants';
        $p3 = $wpdb->get_var($wpdb->prepare("SELECT price FROM `{$t_var}` WHERE id = %d", $vid));
        if ($p3 !== null && (float)$p3 > 0) return (float)$p3;

        return 0;
    }

    /**
     * 1. PROSES CHECKOUT PESANAN SATUAN (AJAX BUY NOW)
     * Telah Diperbaiki Bebas Eror SQL & Terintegrasi Penuh
     */
    public static function ajax_sale() {
        if (!check_ajax_referer('pk01_store', 'nonce', false)) {
            wp_send_json_error(['message' => 'Sesi belanja kedaluwarsa. Silakan muat ulang halaman.'], 403);
        }

        global $wpdb;

        $vid        = absint($_POST['variant_id'] ?? 0);
        $qty        = max(1, (float)($_POST['qty'] ?? 1));
        $customer   = sanitize_text_field(wp_unslash($_POST['customer'] ?? 'Pelanggan Website'));
        $phone      = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
        $address    = sanitize_textarea_field(wp_unslash($_POST['address'] ?? ''));
        $request_id = sanitize_text_field($_POST['request_id'] ?? '');

        if ($vid <= 0 || $qty <= 0) {
            wp_send_json_error(['message' => 'Pilihan produk atau kuantitas belanja tidak valid.'], 422);
        }

        // Cegah Duplikasi Pesanan Ganda Akibat Dobel Klik
        if ($request_id) {
            $existing = get_transient('pk01_web_order_' . $request_id);
            if ($existing) {
                wp_send_json_success($existing);
            }
        }

        $tbl = function($k) use ($wpdb) {
            return class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
        };

        $t_var = $tbl('product_variants');
        $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t_var}` WHERE id = %d AND status = 'active'", $vid), ARRAY_A);
        if (!$v) {
            wp_send_json_error(['message' => 'Varian produk tidak ditemukan atau dinonaktifkan.'], 404);
        }

        // Cek Stok Fisik Riil
        $t_stk = $tbl('stock_transactions');
        $calc_stk = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CASE WHEN direction = 'in' THEN qty ELSE -qty END), 0) FROM `{$t_stk}` WHERE stock_type = 'finished' AND item_id = %d",
            $vid
        ));
        $available_stock = ($calc_stk > 0) ? $calc_stk : (float)($v['stock'] ?? 0);

        if ($available_stock < $qty) {
            wp_send_json_error(['message' => 'Stok produk tidak mencukupi. Sisa stok tersedia: ' . (int)$available_stock . ' unit.'], 409);
        }

        // Dapatkan Harga
        $price = self::price_for_variant($vid, (float)($v['price'] ?? 0), $v['sku']);
        if ($price <= 0) {
            wp_send_json_error(['message' => 'Harga produk belum diaktifkan di sistem PK01.'], 409);
        }

        $gross = round($price * $qty, 2);
        $hpp_total = round((float)($v['hpp'] ?? 0) * $qty, 2);

        // Generate Nomor Pesanan Sesuai Format Sentral
        $t_so = $tbl('sales_orders');
        $no = class_exists('PK01_Engine') ? PK01_Engine::document_number('invoice', get_option('pk01_invoice_prefix','INV'), absint(get_option('pk01_invoice_digits',5)), get_option('pk01_invoice_pattern','{PREFIX}/{YYYY}{MM}/{SEQ}')) : 'INV/'.current_time('Ym').'/'.wp_rand(10000,99999);

        // ID Saluran Website
        $t_ch = $tbl('channels');
        $channel_id = 1;
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_ch)) === $t_ch) {
            $ch_row = $wpdb->get_var("SELECT id FROM `{$t_ch}` WHERE code = 'website' LIMIT 1");
            if ($ch_row) {
                $channel_id = (int)$ch_row;
            } else {
                $wpdb->insert($t_ch, ['code' => 'website', 'name' => 'Website Store', 'status' => 'active', 'created_at' => current_time('mysql')]);
                $channel_id = (int)$wpdb->insert_id;
            }
        }

        // EKSEKUSI DATABASE TRANSACTION AMAN
        $wpdb->query('START TRANSACTION');
        try {
            // 1. Data Pesanan Lengkap (Mengisi Kolom Wajib Agar Tidak Error)
            $order_payload = [
                'order_no'         => $no,
                'invoice_no'       => $no,
                'channel_id'       => $channel_id,
                'channel'          => 'website',
                'customer_name'    => $customer,
                'customer_phone'   => $phone,
                'shipping_address' => $address,
                'variant_id'       => $vid,
                'product_name'     => $v['name'],
                'qty'              => $qty,
                'price'            => $price,
                'hpp'              => (float)($v['hpp'] ?? 0),
                'gross'            => $gross,
                'net'              => $gross,
                'total_amount'     => $gross,
                'payment_status'   => 'unpaid',
                'payment_method'   => 'Transfer Bank',
                'status'           => 'processing',
                'shipping_status'  => 'pending',
                'created_at'       => current_time('mysql')
            ];

            // Filter kolom terhadap skema tabel nyata
            $existing_cols = $wpdb->get_col("DESC `{$t_so}`", 0);
            $safe_order_payload = array_intersect_key($order_payload, array_flip($existing_cols));

            $inserted = $wpdb->insert($t_so, $safe_order_payload);
            if (!$inserted) {
                throw new Exception('Gagal membuat pesanan database: ' . $wpdb->last_error);
            }
            $sid = (int)$wpdb->insert_id;

            // 2. Simpan Item Pesanan
            $t_soi = $tbl('sales_order_items');
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_soi)) === $t_soi) {
                $wpdb->insert($t_soi, [
                    'order_id'   => $sid,
                    'variant_id' => $vid,
                    'product_name'=> $v['name'],
                    'qty'        => $qty,
                    'unit_price' => $price,
                    'hpp'        => (float)($v['hpp'] ?? 0),
                    'total'      => $gross
                ]);
            }

            // 3. Potong Stok Gudang & Catat Mutasi
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_stk)) === $t_stk) {
                $wpdb->insert($t_stk, [
                    'stock_type'     => 'finished',
                    'item_id'        => $vid,
                    'qty'            => $qty,
                    'direction'      => 'out',
                    'reference_type' => 'website_sale',
                    'reference_id'   => $sid,
                    'reference_no'   => $no,
                    'notes'          => 'Penjualan Toko Online (' . $no . ')',
                    'created_by'     => get_current_user_id(),
                    'created_at'     => current_time('mysql')
                ]);
            }

            // Update langsung kolom stok varian jika ada
            if (isset($v['stock'])) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE `{$t_var}` SET stock = GREATEST(0, stock - %f) WHERE id = %d",
                    $qty, $vid
                ));
            }

            // 4. JABAT TANGAN KE AFILIASI (ATRIBUSI KOMISI OTOMATIS)
            if (class_exists('PK01_Affiliate') && method_exists('PK01_Affiliate', 'attribute_order')) {
                PK01_Affiliate::attribute_order($sid);
            }

            // 5. Jabat Tangan ke Audit Trail Log
            if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
                PK01_Audit::write('website_sale', 'sales', 'sales_order', $no, null, [
                    'customer' => $customer,
                    'phone'    => $phone,
                    'total'    => $gross,
                    'qty'      => $qty
                ], 'Penjualan toko online berhasil diproses.', 'SUCCESS');
            }

            $wpdb->query('COMMIT');

            $result = [
                'order_no' => $no,
                'order_id' => $sid,
                'total'    => $gross,
                'message'  => 'Pesanan berhasil dibuat dan tercatat di sistem PK01.'
            ];

            if ($request_id) {
                set_transient('pk01_web_order_' . $request_id, $result, DAY_IN_SECONDS);
            }

            wp_send_json_success($result);
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            wp_send_json_error(['message' => 'Terjadi kendala penyimpanan: ' . $e->getMessage()], 500);
        }
    }

    /**
     * 2. PROSES CHECKOUT MULTI-ITEM (KERANJANG BELANJA)
     * Penanganan Mandiri Tanpa Bergantung Kelas Eksternal
     */
    public static function ajax_order() {
        if (!check_ajax_referer('pk01_store', 'nonce', false)) {
            wp_send_json_error(['message' => 'Sesi belanja tidak valid.'], 403);
        }

        $items = json_decode(wp_unslash($_POST['items'] ?? '[]'), true);
        if (empty($items) || !is_array($items)) {
            wp_send_json_error(['message' => 'Keranjang belanja kosong.'], 422);
        }

        $customer_name  = sanitize_text_field($_POST['customer'] ?? 'Pelanggan Toko');
        $customer_phone = sanitize_text_field($_POST['phone'] ?? '');
        $customer_email = sanitize_email($_POST['email'] ?? '');
        $shipping_addr  = sanitize_textarea_field($_POST['address'] ?? '');

        global $wpdb;
        $tbl = function($k) use ($wpdb) {
            return class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
        };

        $t_so  = $tbl('sales_orders');
        $t_soi = $tbl('sales_order_items');
        $t_var = $tbl('product_variants');

        $prefix = get_option('pk01_invoice_prefix', 'INV');
        $digits = absint(get_option('pk01_invoice_digits', 5));
        $order_no = class_exists('PK01_Engine') ? PK01_Engine::document_number('invoice', $prefix, $digits, get_option('pk01_invoice_pattern','{PREFIX}/{YYYY}{MM}/{SEQ}')) : ($prefix . '/' . current_time('Ym') . '/' . str_pad((string)wp_rand(1,99999), $digits, '0', STR_PAD_LEFT));

        $total_gross = 0;
        $total_hpp   = 0;

        $wpdb->query('START TRANSACTION');
        try {
            // Hitung Total Seluruh Item di Keranjang
            $validated_items = [];
            foreach ($items as $item) {
                $vid = absint($item['variant_id'] ?? 0);
                $qty = max(1, (float)($item['qty'] ?? 1));

                $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t_var}` WHERE id = %d AND status = 'active'", $vid), ARRAY_A);
                if (!$v) continue;
                $available = (float)$wpdb->get_var($wpdb->prepare("SELECT stock FROM `{$t_var}` WHERE id=%d FOR UPDATE", $vid));
                if ($available + 0.000001 < $qty) throw new Exception('Stok tidak mencukupi untuk SKU '.$v['sku'].'. Tersedia: '.$available);

                $unit_price = self::price_for_variant($vid, (float)($v['price'] ?? 0), $v['sku']);
                $subtotal   = $unit_price * $qty;
                $sub_hpp    = (float)($v['hpp'] ?? 0) * $qty;

                $total_gross += $subtotal;
                $total_hpp   += $sub_hpp;

                $validated_items[] = [
                    'variant_id' => $vid,
                    'qty'        => $qty,
                    'price'      => $unit_price,
                    'hpp'        => (float)($v['hpp'] ?? 0),
                    'name'       => (string)$v['name']
                ];
            }

            if (empty($validated_items)) {
                throw new Exception('Semua produk di keranjang tidak valid atau stok habis.');
            }

            // Simpan Master Pesanan
            $master_payload = [
                'order_no'         => $order_no,
                'channel'          => 'website',
                'customer_name'    => $customer_name,
                'customer_phone'   => $customer_phone,
                'shipping_address' => $shipping_addr,
                'gross'            => $total_gross,
                'net'              => $total_gross,
                'total_amount'     => $total_gross,
                'hpp'              => $total_hpp,
                'status'           => 'processing',
                'payment_status'   => 'unpaid',
                'created_at'       => current_time('mysql')
            ];

            $existing_cols = $wpdb->get_col("DESC `{$t_so}`", 0);
            $safe_master = array_intersect_key($master_payload, array_flip($existing_cols));

            if (!$wpdb->insert($t_so, $safe_master)) throw new Exception('Gagal menyimpan master pesanan: '.($wpdb->last_error ?: 'database error'));
            $order_id = (int)$wpdb->insert_id;

            // Simpan Item & Potong Stok
            foreach ($validated_items as $v_item) {
                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_soi)) === $t_soi) {
                    if (!$wpdb->insert($t_soi, [
                        'order_id'   => $order_id,
                        'variant_id' => $v_item['variant_id'],
                        'product_name'=> $v_item['name'] ?? '',
                        'qty'        => $v_item['qty'],
                        'unit_price' => $v_item['price'],
                        'hpp'        => $v_item['hpp'],
                        'total'      => $v_item['price'] * $v_item['qty']
                    ])) throw new Exception('Gagal menyimpan item keranjang: '.($wpdb->last_error ?: 'database error'));
                }

                // Potong Stok
                $changed = $wpdb->query($wpdb->prepare(
                    "UPDATE `{$t_var}` SET stock = stock - %f, updated_at=%s WHERE id = %d AND stock >= %f",
                    $v_item['qty'], current_time('mysql'), $v_item['variant_id'], $v_item['qty']
                ));
                if ($changed !== 1) throw new Exception('Stok berubah atau tidak mencukupi saat checkout.');
                if (!$wpdb->insert($t_stk, [
                    'stock_type'=>'finished','item_id'=>$v_item['variant_id'],'variant_id'=>$v_item['variant_id'],'qty'=>$v_item['qty'],
                    'direction'=>'out','reference_type'=>'website_sale','reference_id'=>$order_id,'reference_no'=>$order_no,
                    'notes'=>'Penjualan keranjang website','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')
                ])) throw new Exception('Gagal mencatat mutasi stok keranjang: '.($wpdb->last_error ?: 'database error'));
            }

            // Jabat Tangan Afiliasi
            if (class_exists('PK01_Affiliate')) {
                PK01_Affiliate::attribute_order($order_id);
            }

            $wpdb->query('COMMIT');

            wp_send_json_success([
                'order_no' => $order_no,
                'order_id' => $order_id,
                'total'    => $total_gross,
                'message'  => 'Pesanan keranjang berhasil dibukukan.'
            ]);
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            wp_send_json_error(['message' => $e->getMessage()], 409);
        }
    }

    public static function nonce() {
        return wp_create_nonce('pk01_store');
    }

    /**
     * API Katalog Produk Khusus Mitra Seller
     */
    public static function seller_products($req) {
        global $wpdb;
        $token = sanitize_text_field($req['token']);

        $tbl = function($k) use ($wpdb) {
            return class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
        };

        $t_sa = $tbl('sales_accounts');
        $seller = $wpdb->get_row($wpdb->prepare(
            "SELECT id, code, name, commission_percent, affiliate_percent FROM `{$t_sa}` WHERE portal_token = %s AND type = 'seller' AND active = 1",
            $token
        ), ARRAY_A);

        if (!$seller) {
            return new WP_Error('pk01_seller_invalid', 'Tautan portal seller tidak valid atau dinonaktifkan.', ['status' => 404]);
        }

        $data = self::products()->get_data();
        foreach ($data as &$prod) {
            foreach ($prod['variants'] as &$v) {
                // Harga Seller: Jika ada harga kontrak khusus di Engine, gunakan itu. Jika tidak, gunakan harga standar.
                $v['seller_price'] = (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_price'))
                    ? PK01_Engine::seller_price((int)$seller['id'], (int)$v['id'])
                    : (float)$v['price'];
            }
        }

        return rest_ensure_response([
            'seller'   => $seller,
            'products' => $data
        ]);
    }

    /**
     * AJAX Pesanan Mandiri Mitra Seller
     */
    public static function seller_order() {
        if (!check_ajax_referer('pk01_seller', 'nonce', false)) {
            wp_send_json_error(['message' => 'Sesi keamanan seller tidak valid.'], 403);
        }

        global $wpdb;
        $token = sanitize_text_field($_POST['token'] ?? '');

        $t_sa = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('sales_accounts') : $wpdb->prefix . 'pk01_sales_accounts';
        $seller = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM `{$t_sa}` WHERE portal_token = %s AND type = 'seller' AND active = 1",
            $token
        ), ARRAY_A);

        if (!$seller) {
            wp_send_json_error(['message' => 'Mitra seller tidak ditemukan.'], 404);
        }

        $variant_id = absint($_POST['variant_id'] ?? 0);
        $qty        = max(1, (float)($_POST['qty'] ?? 1));

        try {
            if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_create_order')) {
                $r = PK01_Engine::seller_create_order((int)$seller['id'], $variant_id, $qty);
                wp_send_json_success($r);
            } else {
                throw new Exception('Engine pesanan seller belum siap di sistem.');
            }
        } catch (Throwable $e) {
            wp_send_json_error(['message' => $e->getMessage()], 409);
        }
    }

    /**
     * SHORTCODE PORTAL MANDIRI SELLER [pk01_seller_portal]
     */
    public static function seller_portal() {
        global $wpdb;
        $token = sanitize_text_field($_GET['pk01_seller'] ?? '');
        if (!$token) return '';

        $t_sa = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('sales_accounts') : $wpdb->prefix . 'pk01_sales_accounts';
        $seller = $wpdb->get_row($wpdb->prepare(
            "SELECT id, code, name, commission_percent FROM `{$t_sa}` WHERE portal_token = %s AND type = 'seller' AND active = 1",
            $token
        ), ARRAY_A);

        if (!$seller) {
            return '<div style="padding:20px; background:#fee2e2; color:#991b1b; border-radius:8px;">⚠️ Tautan akses portal seller tidak valid atau akun Anda sedang dinonaktifkan oleh Admin.</div>';
        }

        $nonce = wp_create_nonce('pk01_seller');
        $api_url = esc_url_raw(rest_url('pk01/v2/store/seller/' . encode_uri_component($token)));
        $ajax_url = esc_url_raw(admin_url('admin-ajax.php'));

        ob_start();
        ?>
        <div id="pk01-seller-portal" data-token="<?php echo esc_attr($token); ?>" data-nonce="<?php echo esc_attr($nonce); ?>" style="max-width:900px; margin:20px auto; font-family:sans-serif;">
            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:20px; margin-bottom:20px;">
                <span style="font-size:11px; font-weight:700; color:#2563eb; text-transform:uppercase;">PORTAL MITRA SELLER</span>
                <h1 style="margin:4px 0; font-size:24px; color:#0f172a;"><?php echo esc_html($seller['name']); ?> (<?php echo esc_html($seller['code']); ?>)</h1>
                <p style="margin:0; font-size:13px; color:#64748b;">
                    Komisi Penjualan: <b><?php echo (float)$seller['commission_percent']; ?>%</b>. Stok dan harga kontrak terintegrasi langsung dengan pabrik PK01.
                </p>
            </div>

            <div id="pk01-seller-orders-alert"></div>
            <div id="pk01-seller-products" style="display:grid; gap:12px;">Memuat katalog produk...</div>
        </div>

        <script>
        (function() {
            var root = document.getElementById('pk01-seller-portal');
            var token = root.dataset.token;
            var box = document.getElementById('pk01-seller-products');
            var alertBox = document.getElementById('pk01-seller-orders-alert');

            fetch('<?php echo $api_url; ?>')
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (!res.products || !res.products.length) {
                        box.innerHTML = '<div style="padding:20px; color:#64748b;">Belum ada produk aktif yang tersedia.</div>';
                        return;
                    }

                    box.innerHTML = res.products.map(function(p) {
                        var v = p.variants[0] || {};
                        var hasStock = (v.stock > 0);
                        return '<div style="padding:16px; border:1px solid #e2e8f0; border-radius:10px; background:#fff; display:flex; justify-content:space-between; align-items:center;">' +
                            '<div>' +
                                '<strong style="font-size:15px; color:#0f172a;">' + p.name + '</strong>' +
                                '<div style="font-size:12px; color:#64748b; margin-top:2px;">SKU: ' + (v.sku || '-') + ' · Stok Pabrik: <b>' + (v.stock || 0) + '</b></div>' +
                                '<div style="font-size:14px; color:#047857; font-weight:700; margin-top:4px;">Harga: Rp ' + Number(v.seller_price || v.price || 0).toLocaleString('id-ID') + '</div>' +
                            '</div>' +
                            '<div>' +
                                '<button type="button" class="pk01-btn-pesan" data-v="' + v.id + '" ' + (!hasStock ? 'disabled' : '') + ' style="background:' + (hasStock ? '#2563eb' : '#cbd5e1') + '; color:#fff; border:none; padding:8px 16px; border-radius:6px; font-weight:700; cursor:' + (hasStock ? 'pointer' : 'not-allowed') + ';">' +
                                    (hasStock ? 'Pesan Stok' : 'Habis') +
                                '</button>' +
                            '</div>' +
                        '</div>';
                    }).join('');

                    box.querySelectorAll('.pk01-btn-pesan').forEach(function(btn) {
                        btn.onclick = function() {
                            var qty = prompt('Berapa unit yang ingin Anda pesan ke gudang?', '1');
                            if (!qty || isNaN(qty) || parseFloat(qty) <= 0) return;

                            var fd = new FormData();
                            fd.append('action', 'pk01_seller_order');
                            fd.append('nonce', root.dataset.nonce);
                            fd.append('token', token);
                            fd.append('variant_id', btn.dataset.v);
                            fd.append('qty', qty);

                            fetch('<?php echo $ajax_url; ?>', { method: 'POST', body: fd })
                                .then(function(r) { return r.json(); })
                                .then(function(z) {
                                    if (z.success) {
                                        alertBox.innerHTML = '<div style="padding:12px; background:#dcfce7; color:#15803d; border-radius:6px; margin-bottom:14px;">✅ Permintaan barang <b>' + z.data.order_no + '</b> berhasil dibuat! Menunggu serah-terima gudang.</div>';
                                    } else {
                                        alertBox.innerHTML = '<div style="padding:12px; background:#fee2e2; color:#991b1b; border-radius:6px; margin-bottom:14px;">❌ ' + (z.data.message || 'Gagal membuat pesanan.') + '</div>';
                                    }
                                });
                        };
                    });
                })
                .catch(function() {
                    box.innerHTML = '<div style="padding:20px; color:#b91c1c;">Gagal memuat katalog seller dari server.</div>';
                });
        })();
        </script>
        <?php
        return ob_get_clean();
    }
}

// Inisialisasi E-Commerce Gateway
