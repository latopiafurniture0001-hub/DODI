<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Role-Based Access Control (RBAC) Engine
 * Pengendali otorisasi terpusat, pengawas izin modul, isolasi lingkup data, 
 * dan simulator pratinjau peran (Role Preview Engine).
 */
class PK01_Authorization {

    /**
     * Inisialisasi Peran Bawaan Sistem PK01
     */
    public static function init() {
        add_action('init', [__CLASS__, 'ensure_roles'], 5);
    }

    /**
     * Daftarkan Peran Khusus PK01 ke WordPress Core
     */
    public static function ensure_roles() {
        if (!get_role('pk01_employee')) {
            add_role('pk01_employee', 'PK01 Karyawan Operasional', ['read' => true, 'upload_files' => true]);
        }
        if (!get_role('pk01_seller')) {
            add_role('pk01_seller', 'PK01 Mitra Seller', ['read' => true]);
        }

        // Role kerja nyata PK01. Role lama tetap dipertahankan untuk kompatibilitas.
        $roles = [
            'pk01_admin'             => ['PK01 Admin Operasional', ['read' => true, 'upload_files' => true]],
            'pk01_gudang'            => ['PK01 Admin Gudang', ['read' => true, 'upload_files' => true]],
            'pk01_produksi'          => ['PK01 Admin Produksi', ['read' => true, 'upload_files' => true]],
            'pk01_kasir'             => ['PK01 Kasir & Penjualan', ['read' => true]],
            'pk01_keuangan'          => ['PK01 Admin Keuangan', ['read' => true]],
            'pk01_hr'                => ['PK01 Admin SDM', ['read' => true]],
            'pk01_logistik'          => ['PK01 Admin Logistik', ['read' => true]],
            'pk01_packing'           => ['PK01 Admin Packing', ['read' => true]],
            'pk01_customer_service'  => ['PK01 Customer Service', ['read' => true]],
            'pk01_security'          => ['PK01 Security', ['read' => true]],
            'pk01_owner'             => ['PK01 Owner / Pemilik', ['read' => true]],
            'pk01_investor'          => ['PK01 Investor', ['read' => true]],
        ];
        foreach ($roles as $slug => $definition) {
            if (!get_role($slug)) {
                add_role($slug, $definition[0], $definition[1]);
            }
        }
    }

    /**
     * Normalisasi Nama Peran (Alias Resolver)
     */
    public static function normalize_role($role) {
        $role = strtolower(trim((string)$role));
        if ($role === 'seller')   return 'pk01_seller';
        if ($role === 'employee') return 'pk01_employee';
        if ($role === 'admin')    return 'administrator';
        if ($role === 'owner' || $role === 'pemilik') return 'pk01_owner';
        if ($role === 'investor') return 'pk01_investor';
        $aliases = [
            'gudang' => 'pk01_gudang', 'warehouse' => 'pk01_gudang',
            'produksi' => 'pk01_produksi', 'production' => 'pk01_produksi',
            'kasir' => 'pk01_kasir', 'cashier' => 'pk01_kasir',
            'keuangan' => 'pk01_keuangan', 'finance' => 'pk01_keuangan',
            'sdm' => 'pk01_hr', 'hr' => 'pk01_hr',
            'logistik' => 'pk01_logistik', 'logistics' => 'pk01_logistik',
            'packing' => 'pk01_packing', 'packer' => 'pk01_packing', 'worker' => 'pk01_employee',
            'admin_operasional' => 'pk01_admin',
        ];
        return $aliases[$role] ?? $role;
    }

    /**
     * Normalisasi Nama Modul Operasional (Alias Resolver)
     */
    public static function normalize_module($module) {
        $module = strtolower(trim((string)$module));
        $map = [
            'seller'            => 'seller',
            'sellers'           => 'seller',
            'seller_portal'     => 'seller_portal',
            'employee'          => 'employees',
            'cost'              => 'operational_costs',
            'costs'             => 'operational_costs',
            'ops'               => 'operational_costs',
            'order'             => 'sales',
            'orders'            => 'sales',
            'sales_hub'         => 'sales',
            'shipping'          => 'shipments',
            'shipping_hub'      => 'shipments',
            'stock'             => 'materials',
            'inventory'         => 'materials',
            'purchase'          => 'materials',
            'purchasing'        => 'materials',
            'finance_hub'       => 'finance',
            'production_hub'    => 'production',
            'jobs'              => 'production',
            'ai'                => 'ai_assistant',
            'ai_mobile'         => 'ai_assistant',
            'log'               => 'logs',
            'audit'             => 'logs',
        ];

        return $map[$module] ?? $module;
    }

    /**
     * Cek Apakah Pengguna Adalah Super Administrator Murni (Bukan Sedang Mode Simulasi)
     */
    public static function is_super_admin() {
        return is_user_logged_in() && current_user_can('manage_options') && !self::is_role_preview();
    }

    /**
     * Cek Apakah Sedang Berada dalam Pratinjau Dashboard Berdasarkan Peran
     */
    public static function is_role_preview() {
        if (!is_user_logged_in() || !current_user_can('manage_options')) return false;

        $preview = sanitize_key(wp_unslash($_GET['pk01_role_preview'] ?? ''));
        if (empty($preview) || $preview === 'administrator') return false;

        // Validasi apakah peran tersebut benar-benar terdaftar di WordPress
        $normalized = self::normalize_role($preview);
        return (bool) get_role($preview) || (bool) get_role($normalized);
    }

    /**
     * Cek Khusus: Administrator Sedang Melihat Perspektif Staf
     */
    public static function is_admin_preview() {
        return self::is_role_preview();
    }

    /**
     * Administrator sedang melihat sistem sebagai pengguna lain. Mode ini
     * benar-benar read-only: hanya operasi baca/cetak/download yang boleh.
     */
    public static function is_read_only_preview() {
        return self::is_role_preview() && in_array(self::actual_role(), ['administrator', 'pk01_admin'], true);
    }

    /**
     * Peran asli pengguna yang sedang login.
     * Role preview TIDAK pernah mengubah peran asli ini.
     */
    public static function actual_role() {
        $u = wp_get_current_user();
        if (!$u || empty($u->roles)) return 'guest';
        return self::normalize_role($u->roles[0]);
    }

    /**
     * Peran tampilan dashboard. Hanya digunakan oleh layer presentasi agar
     * Administrator dapat melihat tampilan role lain tanpa impersonation.
     */
    public static function view_role() {
        if (self::is_role_preview()) {
            $p = sanitize_key(wp_unslash($_GET['pk01_role_preview'] ?? ''));
            return self::normalize_role($p);
        }
        return self::actual_role();
    }

    /**
     * Peran efektif untuk konteks tampilan dashboard. Dipertahankan sebagai
     * kompatibilitas untuk view lama yang membaca effective_role().
     */
    public static function effective_role() {
        return self::view_role();
    }

    /**
     * Hak Akses Bawaan Sistem (Default System Permissions Matrix)
     */
    public static function get_default_permissions() {
        return [
            'security'          => ['administrator', 'pk01_admin', 'pk01_security', 'shop_manager'],
            'attendance'       => ['administrator', 'pk01_admin', 'pk01_hr', 'pk01_keuangan', 'pk01_employee', 'shop_manager'],
            'administration'   => ['administrator', 'pk01_admin', 'pk01_hr', 'shop_manager'],
            'customer_service'   => ['administrator', 'pk01_admin', 'pk01_owner', 'shop_manager', 'pk01_customer_service', 'pk01_seller', 'pk01_kasir', 'pk01_produksi', 'pk01_employee', 'pk01_gudang', 'pk01_logistik', 'pk01_packing', 'pk01_hr', 'pk01_keuangan', 'pk01_security'],
            'communications'   => ['administrator', 'pk01_admin', 'pk01_owner', 'shop_manager', 'pk01_customer_service', 'pk01_seller', 'pk01_kasir', 'pk01_produksi', 'pk01_employee', 'pk01_gudang', 'pk01_logistik', 'pk01_packing', 'pk01_hr', 'pk01_keuangan'],
            'cnc_dashboard'    => ['administrator', 'pk01_admin', 'pk01_produksi'],
            'dashboard'         => ['administrator', 'pk01_admin', 'pk01_owner', 'pk01_investor', 'editor', 'shop_manager', 'pk01_employee', 'pk01_seller', 'pk01_gudang', 'pk01_produksi', 'pk01_kasir', 'pk01_keuangan', 'pk01_hr', 'pk01_logistik', 'pk01_packing'],
            'sales'             => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_seller', 'pk01_kasir', 'pk01_keuangan'],
            'materials'         => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_gudang', 'pk01_produksi'],
            'products'          => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_gudang', 'pk01_produksi'],
            'production'        => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_produksi'],
            'production_flow'  => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_produksi', 'pk01_gudang'],
            'shipments'         => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_seller', 'pk01_gudang', 'pk01_logistik', 'pk01_kasir', 'pk01_packing'],
            'returns'           => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_gudang'],
            'warehouse'         => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_gudang', 'pk01_produksi'],
            'sellers'           => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan'],
            'employees'         => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_hr'],
            'payroll'           => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_hr', 'pk01_keuangan'],
            'job_wages'         => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_hr', 'pk01_keuangan', 'pk01_produksi'],
            'assets_inventory'  => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_gudang', 'pk01_keuangan'],
            'operational_costs' => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan'],
            'cash'              => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan'],
            'marketplace'       => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan'],
            'pricing'           => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan'],
            'finance'           => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan'],
            'ai_assistant'      => ['administrator', 'pk01_admin', 'pk01_owner', 'pk01_investor', 'editor', 'shop_manager', 'pk01_employee', 'pk01_seller', 'pk01_gudang', 'pk01_produksi', 'pk01_kasir', 'pk01_keuangan', 'pk01_hr', 'pk01_logistik', 'pk01_packing', 'pk01_security'],
            'ai_center'         => ['administrator', 'pk01_admin', 'editor', 'shop_manager'],
            'logs'              => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_keuangan', 'pk01_hr'],
            'users'             => ['administrator', 'pk01_admin'],
            'settings'          => ['administrator', 'pk01_admin'],
            'system'            => ['administrator', 'pk01_admin'],
            'documents'         => ['administrator'],
'master_data'       => ['administrator', 'pk01_admin', 'editor', 'shop_manager', 'pk01_hr', 'pk01_gudang', 'pk01_produksi', 'pk01_keuangan'],
            'seller_portal'     => ['administrator', 'pk01_seller'],
            'seller_affiliate'  => ['administrator', 'pk01_seller', 'pk01_admin'],
            'job_karyawan'      => ['administrator', 'pk01_admin', 'pk01_hr', 'pk01_produksi', 'pk01_employee'],
            'packing'           => ['administrator', 'pk01_admin', 'pk01_packing', 'pk01_logistik'],
            'owner_dashboard'   => ['administrator', 'pk01_owner'],
            'finance_reports'   => ['administrator', 'pk01_admin', 'pk01_owner', 'pk01_keuangan'],
            'general_ledger'    => ['administrator', 'pk01_admin', 'pk01_keuangan'],
            'job_role_engine'   => ['administrator', 'pk01_admin', 'pk01_hr', 'pk01_produksi'],
        ];
    }

    /**
     * Menu yang tampil mengikuti pekerjaan nyata pengguna.
     * Administrator mendapatkan seluruh menu; role operasional hanya melihat
     * modul yang memang dibutuhkan untuk pekerjaannya.
     */
    /** True when the logged-in WordPress user is linked to an active employee role. */
    public static function employee_has_job_role($role_code) {
        if (!is_user_logged_in()) return false;
        $role_code = sanitize_key($role_code);
        if ($role_code === '') return false;
        global $wpdb;
        $et = class_exists('PK01_DB') ? PK01_DB::t('employees') : '';
        $rt = class_exists('PK01_DB') ? PK01_DB::t('employee_job_roles') : '';
        if (!$et || !$rt) return false;
        $sql = "SELECT r.id FROM {$rt} r INNER JOIN {$et} e ON e.id=r.employee_id WHERE e.user_id=%d AND e.status='active' AND r.role_code=%s AND r.active=1 LIMIT 1";
        return (bool)$wpdb->get_var($wpdb->prepare($sql, get_current_user_id(), $role_code));
    }

    public static function role_navigation() {
        $profiles = [
            // Hanya Administrator WordPress yang menampilkan seluruh registry menu.
            // PK01 Admin Operasional memakai navigasi terkurasi agar sidebar tetap sesuai
            // kapasitas kerja; authorization backend tetap menjadi pagar akses sebenarnya.
            // Hak mutasi tetap dijaga oleh can_action().
            'administrator' => array_keys(class_exists('PK01_Module_Registry') ? PK01_Module_Registry::all() : [
                'dashboard'=>[], 'master_data'=>[], 'sales_hub'=>[], 'inventory'=>[],
                'production_hub'=>[], 'purchasing_hub'=>[], 'shipping_hub'=>[], 'hr'=>[],
                'finance_hub'=>[], 'seller'=>[], 'job_wages'=>[], 'assets_inventory'=>[],
                'ai_assistant'=>[], 'ai_center'=>[], 'logs'=>[], 'users'=>[], 'system'=>[], 'data_control'=>[]
            ]),
            'pk01_admin' => [
                'dashboard','communications','customer_service','attendance','master_data','sales_hub','inventory','production_hub','production_flow','purchasing_hub','shipping_hub','hr','finance_hub','seller','job_wages','assets_inventory','finance_reports','documents','ai_assistant','ai_center','logs'
            ],
            'pk01_owner' => ['owner_dashboard','customer_service','communications','finance_reports','ai_assistant'],
            'pk01_investor' => ['dashboard','communications','finance_reports','ai_assistant'],
            'pk01_owner_old_disabled' => array_keys(class_exists('PK01_Module_Registry') ? PK01_Module_Registry::all() : [
                'dashboard','master_data','sales_hub','inventory','production_hub','purchasing_hub','shipping_hub','hr','finance_hub','seller','job_wages','assets_inventory','ai_assistant','ai_center','logs','users','system','data_control'
            ]),
            'shop_manager' => [
                'dashboard','customer_service','sales_hub','inventory','production_hub','production_flow','purchasing_hub','shipping_hub','hr','seller','job_wages','assets_inventory','finance_hub','ai_assistant','ai_center'
            ],
            'editor' => [
                'dashboard','sales_hub','inventory','production_hub','production_flow','purchasing_hub','shipping_hub','seller','finance_hub','ai_assistant','ai_center','logs'
            ],
            'pk01_gudang' => [
                'dashboard','communications','customer_service','inventory','returns','purchasing_hub','production_flow','shipping_hub','assets_inventory','ai_assistant'
            ],
            'pk01_produksi' => [
                'dashboard','communications','customer_service','production_hub','production_flow','job_karyawan','cnc_dashboard','inventory','job_wages','ai_assistant'
            ],
            'pk01_kasir' => [
                'dashboard','communications','sales_hub','shipping_hub','ai_assistant'
            ],
            'pk01_keuangan' => [
                'dashboard','communications','customer_service','finance_hub','attendance','finance_reports','sales_hub','purchasing_hub','cash','operational_costs','payroll','job_wages','assets_inventory','marketplace','ai_assistant','logs'
            ],
            'pk01_hr' => [
                'dashboard','communications','customer_service','hr','attendance','job_wages','master_data','ai_assistant','logs'
            ],
            'pk01_logistik' => [
                'dashboard','communications','customer_service','shipping_hub','ai_assistant'
            ],
            'pk01_security' => [
                'dashboard','communications','customer_service','ai_assistant','logs'
            ],
            'pk01_packing' => [
                'dashboard','communications','customer_service','packing','shipping_hub','ai_assistant'
            ],
            'pk01_employee' => [
                'dashboard','communications','customer_service','job_karyawan','attendance','ai_assistant'
            ],
            'pk01_customer_service' => ['dashboard','communications','customer_service','ai_assistant','logs'],
            'pk01_seller' => [
                'dashboard','communications','customer_service','seller_affiliate','seller_portal','sales_hub','seller','shipping_hub','ai_assistant'
            ],
        ];
        $role = self::effective_role();
        $nav = $profiles[$role] ?? ['dashboard'];
        // Operator CNC is an employee capability, not a separate WordPress account role.
        // Only expose the CNC workspace when the employee has an active CNC job-role assignment.
        if (in_array($role, ['pk01_employee','pk01_produksi'], true) && self::employee_has_job_role('cnc') && !in_array('cnc_dashboard',$nav,true)) {
            $nav[] = 'cnc_dashboard';
        }
        if ($role === 'pk01_employee' && self::employee_has_job_role('prema')) {
            // Prema stays inside Job Saya; no duplicate dashboard is created.
        }
        return $nav;
    }

    /**
     * Otorisasi dashboard secara eksplisit. Dashboard adalah workspace terisolasi;
     * role tidak boleh membuka dashboard job lain melalui URL/shortcode.
     */
    public static function can_dashboard($dashboard) {
        if (!is_user_logged_in()) return false;
        $dashboard = self::normalize_module($dashboard);
        if (self::is_super_admin()) return true;
        $map = [
            'dashboard'=>'dashboard', 'owner_dashboard'=>'owner_dashboard',
            'warehouse'=>'warehouse', 'production'=>'production',
            'packing'=>'packing', 'seller_affiliate'=>'seller_affiliate',
            'job_karyawan'=>'job_karyawan', 'customer_service'=>'customer_service',
            'security'=>'security'
        ];
        $module = $map[$dashboard] ?? $dashboard;
        return self::can_navigate($module);
    }

    /**
     * Apakah modul merupakan menu yang memang boleh terlihat pada sidebar role.
     */
    public static function can_navigate($module) {
        if (!is_user_logged_in()) return false;
        $module = self::normalize_module($module);
        if (self::is_super_admin()) return true;

        // Navigasi sidebar HARUS mengikuti profil kerja. Jika Admin mengatur
        // permission modul secara eksplisit dari Pengaturan, nilai FALSE selalu
        // menghentikan navigasi; nilai TRUE hanya berlaku jika modul memang ada
        // di profil role tersebut. Dengan demikian pengaturan tidak dapat membuka
        // dashboard lintas-job secara tidak sengaja.
        $navigation = array_map([__CLASS__, 'normalize_module'], self::role_navigation());
        if (!in_array($module, $navigation, true)) return false;
        $role = self::effective_role();
        $custom_matrix = (array) get_option('pk01_role_permissions', []);
        if (isset($custom_matrix[$role]) && is_array($custom_matrix[$role]) && array_key_exists($module, $custom_matrix[$role])) {
            return !empty($custom_matrix[$role][$module]);
        }
        return true;
    }

    /**
     * CEK HAK AKSES MODUL UTAMA (CORE CAN FUNCTION)
     * Mengatasi Bug Matriks Array vs Boolean
     */
    public static function can($module) {
        if (!is_user_logged_in()) return false;

        // Otorisasi selalu mengikuti USER ASLI. Role preview hanya mengubah
        // tampilan dashboard; Administrator tetap memiliki akses Administrator.
        if (self::is_super_admin()) return true;
        $actual_role = self::actual_role();
        if (in_array($actual_role, ['administrator', 'pk01_admin'], true)) return true;
        $module = self::normalize_module($module);
        // CNC is a job capability attached to an employee, not a separate WP role.
        // Allow the dedicated CNC workspace only when the logged-in employee actually
        // has an active CNC assignment in the employee_job_roles master.
        if ($module === 'cnc_dashboard' && in_array($actual_role, ['pk01_employee','pk01_produksi'], true)) {
            return self::employee_has_job_role('cnc');
        }
        $role   = self::effective_role();

        // Batas domain wajib untuk role Logistik. Role ini hanya menangani
        // pengiriman/packing; kasir (sales) dan gudang (materials) tidak boleh
        // terbuka melalui URL langsung maupun matriks izin lama/kustom.
        if ($role === 'pk01_logistik' && in_array($module, ['sales', 'materials', 'products', 'production', 'finance', 'cash', 'marketplace', 'pricing', 'seller', 'seller_portal', 'employees', 'payroll', 'job_wages', 'assets_inventory', 'operational_costs'], true)) {
            return false;
        }

        // Batas domain wajib untuk Seller. Seller bekerja hanya di Dashboard/Portal Seller,
        // komunikasi Job, afiliasi, dan AI. Modul Kasir, Manajemen Seller, Logistik,
        // Customer Service, Gudang, Keuangan, dan produksi tidak boleh terbuka dari URL
        // lama maupun tombol yang salah arah. Order/pengiriman/tagihan Seller dibaca dari Portal Seller.
        if ($role === 'pk01_seller' && in_array($module, ['sales','sales_hub','seller','shipments','shipping_hub','customer_service','inventory','warehouse','materials','products','production','production_hub','finance','finance_hub','cash','marketplace','pricing','purchasing_hub','job_wages','assets_inventory','operational_costs','employees','payroll','hr','attendance'], true)) {
            return false;
        }

        if ($module === 'returns' && self::effective_role() === 'pk01_kasir') { return false; }

        // 1. Periksa Konfigurasi Matriks Kustom dari Menu Pengaturan Sentral
        $custom_matrix = (array) get_option('pk01_role_permissions', []);

        if (isset($custom_matrix[$role]) && is_array($custom_matrix[$role])) {
            // Jika modul diatur secara eksplisit di pengaturan, ambil nilai boolean-nya
            if (isset($custom_matrix[$role][$module])) {
                return !empty($custom_matrix[$role][$module]);
            }
        }

        // 2. Fallback ke Matriks Izin Standar Sistem PK01
        $defaults = self::get_default_permissions();
        $allowed_roles = $defaults[$module] ?? ['administrator'];

        return in_array($role, $allowed_roles, true);
    }

    /**
     * CEK HAK TINDAKAN SPESIFIK (CREATE, EDIT, DELETE, APPROVE, PRINT, DLL)
     */
    public static function can_action($module, $action = 'view') {
        if (!is_user_logged_in()) return false;

        $action = strtolower(sanitize_key($action));
        $module = self::normalize_module($module);

        // Jika modul utamanya saja tidak boleh diakses, tolak tindakan apa pun
        if (!self::can($module)) return false;

        // MODE SIMULASI (ROLE PREVIEW): Kunci semua tindakan mutasi menjadi Read-Only
        if (self::is_role_preview()) {
            return in_array($action, ['view', 'read', 'print', 'download'], true);
        }

        // Administrator tetap memiliki otorisasi penuh, tetapi preview hanya
        // mengizinkan pembacaan agar pemeriksaan tampilan tidak mengubah data.
        if (self::is_super_admin()) return true;
        if (self::is_role_preview() && in_array(self::actual_role(), ['administrator', 'pk01_admin'], true)) {
            return in_array($action, ['view', 'read', 'print', 'download'], true);
        }
        if (self::actual_role() === 'administrator' || self::actual_role() === 'pk01_admin') return true;
        // Owner dapat melakukan approval administratif yang relevan, tetapi bukan mutasi
        // transaksi harian dari dashboard. Mutasi tetap dijalankan modul/Engine terkait.
        if (!self::is_role_preview() && self::effective_role() === 'pk01_owner') {
            return in_array($action, ['view','read','print','download','approve'], true);
        }
        if (!self::is_role_preview() && self::effective_role() === 'pk01_investor') {
            return in_array($action, ['view','read','print','download'], true);
        }
        $role = self::effective_role();
        // Kasir adalah front-line penjualan. Setelah transaksi dibukukan,
        // proses fisik menjadi pekerjaan Packing/Gudang/Logistik. Kasir hanya
        // boleh membaca/mencetak status fulfillment dan tracking.
        if ($role === 'pk01_kasir' && in_array($module, ['shipments','returns','warehouse','packing'], true)) {
            return in_array($action, ['view','read','print','download','track'], true);
        }
        $custom_matrix = (array) get_option('pk01_role_permissions', []);

        // 1. Cek Matriks Tindakan Kustom
        if (isset($custom_matrix[$role]['actions'][$action])) {
            return !empty($custom_matrix[$role]['actions'][$action]);
        }

        // 2. Tindakan Membaca / Melihat selalu diizinkan jika modul terbuka
        if (in_array($action, ['view', 'read'], true)) return true;

        // 3. Aturan Proteksi Tindakan Kritis Bawaan
        if (in_array($action, ['delete', 'approve', 'reject', 'import'], true)) {
            // Tindakan hapus dan persetujuan hanya untuk role pengelola
            return in_array($role, ['administrator', 'shop_manager', 'editor'], true);
        }

        return true;
    }

    /**
     * ISOLASI LINGKUP DATA (DATA SCOPE)
     * Mengatur apakah user melihat data semua orang (ALL) atau hanya miliknya (OWN)
     */
    public static function data_scope() {
        // Administrator melihat seluruh data perusahaan
        if (self::is_super_admin()) return 'ALL';

        $role = self::effective_role();
        if ($role === 'pk01_admin') return 'ALL';
        $custom_matrix = (array) get_option('pk01_role_permissions', []);

        if (isset($custom_matrix[$role]['scope'])) {
            $scope = strtoupper(sanitize_key($custom_matrix[$role]['scope']));
            if (in_array($scope, ['ALL', 'OWN', 'TEAM', 'LOCATION'], true)) {
                return $scope;
            }
        }

        // Lingkup Bawaan: Seller dan Staf biasa hanya melihat data miliknya
        if (in_array($role, ['pk01_seller', 'pk01_employee', 'pk01_investor'], true)) {
            return 'OWN';
        }

        return 'ALL';
    }

    /**
     * Helper Pembuat URL Pratinjau Dashboard Bebas 404
     */
    public static function role_preview_url($role) {
        $role = sanitize_key($role);
        // Preview Administrator WAJIB dimulai dari halaman Dashboard Operasional
        // kanonis, bukan dari halaman PK01 Portal/Seller Portal milik Theme.
        // Sebelumnya fungsi ini memakai URL halaman yang sedang dibuka; jika Admin
        // sedang berada di /pk01-portal/, preview Seller ikut masuk ke template
        // portal/theme dan dapat jatuh ke [pk01_seller_portal] tanpa pk01_view.
        // Gunakan page_url('dashboard') agar renderer PK01::app() selalu menerima
        // pk01_view=dashboard dan effective_role() menentukan profil preview.
        $base = '';
        if (class_exists('PK01_DB') && method_exists('PK01_DB', 'page_url')) {
            $base = PK01_DB::page_url('dashboard');
        }
        if (!$base) {
            $id = (int) get_option('pk01_dashboard_page_id', 0);
            if ($id && get_post_status($id) === 'publish') {
                $base = add_query_arg('pk01_view', 'dashboard', get_permalink($id));
            }
        }
        if (!$base) $base = add_query_arg('pk01_view', 'dashboard', home_url('/dashboard-operasional/'));

        $base = remove_query_arg(['pk01_role_preview', 'pk01_seller']);
        if (!empty($role) && $role !== 'administrator') {
            return add_query_arg('pk01_role_preview', $role, $base);
        }
        return $base;
    }

    /**
     * Banner Pratinjau Dashboard (Ditampilkan di Atas Dashboard)
     */
    public static function render_preview_banner() {
        if (!self::is_role_preview()) return;

        $role = self::view_role();
        $label = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'role_label') ? PK01_Engine::role_label($role) : ucfirst(str_replace(['pk01_','_'],' ', $role));
        $exit_url = esc_url(remove_query_arg('pk01_role_preview'));

        echo '<div style="background:#eef6ff; border:1px solid #93c5fd; color:#1e3a8a; padding:12px 18px; border-radius:8px; margin-bottom:18px; display:flex; justify-content:space-between; align-items:center; font-size:13px; gap:14px;">';
        echo '<div>👁️ <strong>Pratinjau Dashboard:</strong> Administrator sedang melihat <b>' . esc_html($label) . '</b>. Akun dan hak akses Administrator tetap aktif; perubahan data dikunci.</div>';
        echo '<a href="' . $exit_url . '" style="background:#1d4ed8; color:#fff; padding:5px 12px; border-radius:6px; text-decoration:none; font-weight:700; font-size:12px; white-space:nowrap;">✕ Kembali ke Dashboard Administrator</a>';
        echo '</div>';
    }

    /**
     * Tautkan Peran Pengguna ke WordPress User Secara Aman
     */
    public static function assign_role($user_id, $role_slug) {
        $user_id = absint($user_id);
        if ($user_id <= 0) return false;

        $u = get_user_by('id', $user_id);
        if (!$u) return false;

        $role_slug = self::normalize_role($role_slug);
        $u->set_role($role_slug);

        // Catat ke log jika tersedia
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'security')) {
            PK01_Audit::security('role_assigned', "Menetapkan peran {$role_slug} kepada pengguna ID #{$user_id}", 'user_role', (string)$user_id);
        }

        return true;
    }
}

// Inisialisasi Engine Otorisasi PK01
