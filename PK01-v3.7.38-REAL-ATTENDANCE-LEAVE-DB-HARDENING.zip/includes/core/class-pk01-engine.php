<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Business Logic Engine
 * Jantung logika bisnis terpusat, pengatur alur transaksi, pengendali saldo kas, 
 * sinkronisasi stok otomatis, kalkulator HPP & margin, dan sumber data utama sistem.
 */
class PK01_Engine {

    public static function init() {}

    private static function now() {
        return current_time('mysql');
    }

    /** Central anti-double-entry boundary for business records. */
    private static function guard_entry($domain,$natural_key,$payload=[]) {
        if (class_exists('PK01_Duplicate_Guard')) PK01_Duplicate_Guard::claim($domain,$natural_key,$payload);
    }

    /**
     * Perekam Audit Log Cerdas (Terhubung ke PK01_Audit & Central Bridge)
     */
    public static function log($a, $m, $e = '', $tx = '', $b = null, $af = null, $reason = '', $level = 'info') {
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
            return PK01_Audit::write($a, $m, $e, $tx, $b, $af, $reason, strtoupper($level) === 'ERROR' ? 'ERROR' : 'SUCCESS', 'engine');
        }

        global $wpdb;
        $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('activity_logs') : $wpdb->prefix . 'pk01_activity_logs';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) {
            $wpdb->insert($t, [
                'timestamp'      => self::now(),
                'user_id'        => get_current_user_id(),
                'action'         => $a,
                'module'         => $m,
                'entity'         => $e,
                'transaction_id' => $tx,
                'before_data'    => $b ? wp_json_encode($b, JSON_UNESCAPED_UNICODE) : null,
                'after_data'     => $af ? wp_json_encode($af, JSON_UNESCAPED_UNICODE) : null,
                'reason'         => $reason,
                'level'          => $level
            ]);
        }

        if (class_exists('PK01_Central_Bridge') && method_exists('PK01_Central_Bridge', 'emit')) {
            PK01_Central_Bridge::emit($a, ['module' => $m, 'entity' => $e, 'transaction_id' => $tx, 'level' => $level]);
        }
    }

    /**
     * 1. MANAJEMEN BUKU KAS & PERBENDAHARAAN (PUBLIC METHOD)
     */
    /**
     * Nomor dokumen terpusat untuk seluruh modul. Satu sequence per jenis/periode,
     * sehingga invoice/PO/SPK/retur tidak lagi memakai COUNT(*) atau random number.
     */
    public static function document_number($type, $prefix = '', $digits = 5, $pattern = '') {
        global $wpdb;
        $type = sanitize_key($type ?: 'document');
        $now = current_time('mysql');
        $period = current_time('Ym');
        $defaults = [
            'invoice'=>['INV',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'po'=>['PO',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'delivery'=>['SJ',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'payment'=>['KK',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'seller'=>['SLR',4,'{PREFIX}-{YY}-{SEQ}'], 'seller_order'=>['SEL',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'seller_invoice'=>['SINV',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'sales'=>['SO',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'job'=>['SPK',5,'{PREFIX}/{YYYY}/{SEQ}'], 'production'=>['PROD',5,'{PREFIX}/{YYYY}/{SEQ}'],
            'payroll'=>['PAY',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'payout'=>['WD',4,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'employee'=>['KRY',3,'{PREFIX}-{SEQ}'],
            'material'=>['MAT',4,'{PREFIX}-{SEQ}'], 'return'=>['RET',4,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'shipment'=>['SHP',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'stock_adjustment'=>['ADJ',4,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'project'=>['PRJ',4,'{PREFIX}/{YYYY}/{SEQ}'], 'goods_receipt'=>['GR',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'warehouse_supplier'=>['WGR',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'warehouse_return'=>['WRT',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'warehouse_return_courier'=>['WRTC',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'warehouse_handover'=>['WHD',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'warehouse_production_out'=>['WPO',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'warehouse_production_in'=>['WPI',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'journal'=>['JNL',6,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'expense'=>['KK',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'capital'=>['CAP',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'closing'=>['CLOSE',5,'{PREFIX}/{YYYY}/{SEQ}'], 'owner_receipt'=>['OWN',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
            'security_visitor'=>['VIS',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'security_gate'=>['SEC-G',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'security_incident'=>['INC',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'seller_bonus'=>['BON',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'], 'cs_ticket'=>['CS',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'],
        ];
        $d = $defaults[$type] ?? ['DOC',5,'{PREFIX}/{YYYY}{MM}/{SEQ}'];
        $prefix = $prefix !== '' ? sanitize_text_field($prefix) : $d[0];
        $digits = max(1,min(10,(int)($digits ?: $d[1])));
        $pattern = $pattern !== '' ? sanitize_text_field($pattern) : $d[2];

        // Semua nomor resmi mengikuti Pengaturan PK01. Sequence tidak pernah
        // dinaikkan saat PRINT; hanya saat transaksi benar-benar dibuat di sini.
        if (class_exists('PK01_Settings') && method_exists('PK01_Settings','get')) {
            $settings_map = [
                'invoice'=>'invoice','po'=>'po','delivery'=>'delivery','payment'=>'payment','seller'=>'seller','seller_order'=>'seller_order','seller_invoice'=>'seller_invoice',
                'sales'=>'sales','job'=>'job','production'=>'production','payroll'=>'payroll','payout'=>'payout','employee'=>'employee','material'=>'material','return'=>'return',
                'shipment'=>'shipment','stock_adjustment'=>'stock_adjustment','project'=>'project','goods_receipt'=>'goods_receipt','warehouse_supplier'=>'warehouse_supplier',
                'warehouse_return'=>'warehouse_return','warehouse_return_courier'=>'warehouse_return_courier','warehouse_handover'=>'warehouse_handover',
                'warehouse_production_out'=>'warehouse_production_out','warehouse_production_in'=>'warehouse_production_in','journal'=>'journal','expense'=>'expense',
                'capital'=>'capital','closing'=>'closing','owner_receipt'=>'owner_receipt','security_visitor'=>'security_visitor','security_gate'=>'security_gate','security_incident'=>'security_incident','seller_bonus'=>'seller_bonus','cs_ticket'=>'cs_ticket'
            ];
            $sk = $settings_map[$type] ?? '';
            if ($sk !== '') {
                $sp = PK01_Settings::get($sk.'_prefix','');
                $sd = PK01_Settings::get($sk.'_digits',0);
                $st = PK01_Settings::get($sk.'_pattern','');
                if ($sp !== '') $prefix = sanitize_text_field($sp);
                if ((int)$sd > 0) $digits = max(1,min(10,(int)$sd));
                if ($st !== '') $pattern = sanitize_text_field($st);
                $configured_seq = max(1,(int)PK01_Settings::get($sk.'_sequence',1));
            } else {
                $configured_seq = 1;
            }
        } else {
            $configured_seq = 1;
        }
        $t = PK01_DB::t('document_sequences');
        $seed_tables = [
            'invoice'=>'sales_orders','po'=>'purchase_orders','job'=>'jobs','return'=>'returns','seller_invoice'=>'seller_invoices','seller_order'=>'seller_orders','payout'=>'marketplace_payouts',
            'goods_receipt'=>'goods_receipts','warehouse_supplier'=>'warehouse_documents','warehouse_return'=>'warehouse_documents','warehouse_return_courier'=>'warehouse_documents','warehouse_handover'=>'warehouse_documents',
            'warehouse_production_out'=>'warehouse_documents','warehouse_production_in'=>'warehouse_documents','journal'=>'journal_entries','expense'=>'operational_costs','capital'=>'capital_transactions','owner_receipt'=>'owner_transactions','payroll'=>'payroll','seller_bonus'=>'seller_bonus_ledger','cs_ticket'=>'cs_tickets'
        ];
        $seed = max(0, $configured_seq - 1);
        if (isset($seed_tables[$type])) {
            $src = PK01_DB::t($seed_tables[$type]);
            if ($src && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$src)) === $src) {
                $where = "DATE_FORMAT(created_at,'%%Y%%m')=%s"; $params=[$period];
                $field = [
                    'invoice'=>'invoice_no','po'=>'po_no','job'=>'job_no','return'=>'return_no','seller_invoice'=>'invoice_no','seller_order'=>'order_no','payout'=>'payout_no',
                    'goods_receipt'=>'receipt_no','warehouse_supplier'=>'doc_no','warehouse_return'=>'doc_no','warehouse_return_courier'=>'doc_no','warehouse_handover'=>'doc_no',
                    'warehouse_production_out'=>'doc_no','warehouse_production_in'=>'doc_no','journal'=>'entry_no','expense'=>'receipt_no','payroll'=>'reference_no','owner_receipt'=>'reference_no','seller_bonus'=>'reference_no','cs_ticket'=>'ticket_no'
                ][$type] ?? '';
                if (in_array($type,['warehouse_supplier','warehouse_return','warehouse_return_courier','warehouse_handover','warehouse_production_out','warehouse_production_in'],true)) {
                    $dt=['warehouse_supplier'=>'supplier_in','warehouse_return'=>'return_in','warehouse_return_courier'=>'return_in','warehouse_handover'=>'outbound_courier','warehouse_production_out'=>'production_out','warehouse_production_in'=>'production_in'][$type];
                    $where .= ' AND doc_type=%s'; $params[]=$dt;
                }
                if($field){
                    $rows=$wpdb->get_col($wpdb->prepare("SELECT `{$field}` FROM `{$src}` WHERE {$where} AND `{$field}`<>''",$params));
                    foreach((array)$rows as $existing_no){ if(preg_match('/(\d+)\s*$/',(string)$existing_no,$m)){ $seed=max($seed,(int)$m[1]); } }
                } else {
                    $historical_seed=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$src}` WHERE {$where}",$params)); $seed=max($seed,$historical_seed);
                }
            }
        }
        // Inisialisasi sequence dari data historis agar nomor baru tidak menabrak nomor lama.
        $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO `{$t}` (doc_type,period_key,last_seq,updated_at) VALUES (%s,%s,%d,%s)",
            $type,$period,$seed,$now
        ));
        $wpdb->query($wpdb->prepare(
            "UPDATE `{$t}` SET last_seq=LAST_INSERT_ID(last_seq+1), updated_at=%s WHERE doc_type=%s AND period_key=%s",
            $now,$type,$period
        ));
        $seq = (int)$wpdb->get_var('SELECT LAST_INSERT_ID()');
        if ($seq <= 0) $seq = $seed + 1;
        $vals = [strtoupper($prefix), current_time('Y'), current_time('y'), current_time('m'), str_pad((string)$seq,$digits,'0',STR_PAD_LEFT)];
        return str_replace(['{PREFIX}','{YYYY}','{YY}','{MM}','{SEQ}'], $vals, $pattern);
    }

    public static function cash($dir, $amt, $cat, $rt = '', $rid = 0, $desc = '', $account = 'Kas Tunai Toko', $ref_no = '') {
        global $wpdb;
        $amt = round((float)$amt, 2);
        if ($amt <= 0) return;

        $dir = in_array($dir, ['in', 'out'], true) ? $dir : 'in';
        $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('cash_ledger') : $wpdb->prefix . 'pk01_cash_ledger';

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) {
            if ((int)$rid > 0 && $rt !== '') self::guard_entry('cash', $rt.':'.(int)$rid.':'.$dir, ['amount'=>$amt,'reference_no'=>$ref_no]);
            elseif ($ref_no !== '') self::guard_entry('cash_ref', $dir.':'.$ref_no, ['amount'=>$amt,'reference_type'=>$rt,'reference_id'=>(int)$rid]);
            $payload = [
                'direction'      => $dir,
                'amount'         => $amt,
                'account'        => sanitize_text_field($account ?: 'Kas Tunai Toko'),
                'category'       => sanitize_text_field($cat),
                'reference_type' => $rt ?: 'manual',
                'reference_id'   => $rid ?: 0,
                'reference_no'   => sanitize_text_field($ref_no),
                'description'    => sanitize_textarea_field($desc),
                'created_by'     => get_current_user_id(),
                'created_at'     => self::now()
            ];

            // Filter kolom terhadap skema nyata
            $cols = $wpdb->get_col("DESC `{$t}`", 0);
            $safe_payload = array_intersect_key($payload, array_flip($cols));

            if (!$wpdb->insert($t, $safe_payload)) { throw new Exception('Gagal mencatat kas: '.($wpdb->last_error ?: 'database error')); }
            self::log('cash_' . $dir, 'cash', 'cash_ledger', (string)$rid, null, ['amount' => $amt, 'category' => $cat, 'account' => $account]);
        }
    }

    /**
     * Hitung Saldo Kas Riil (Akumulasi Tunai + Bank)
     */
    public static function cash_balance() {
        global $wpdb;
        $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('cash_ledger') : $wpdb->prefix . 'pk01_cash_ledger';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) return 0.00;

        return round((float) $wpdb->get_var("SELECT COALESCE(SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END), 0) FROM `{$t}`"), 2);
    }

    /**
     * Penyetoran Modal Usaha
     */
    /** Modal canonical: satu transaksi modal + satu kas masuk. */
    public static function record_capital_deposit($amount,$source_type='owner',$contributor_name='',$deposit_date='',$target_account='Kas Tunai Toko',$capital_no='',$notes='') {
        global $wpdb;
        $amount=round((float)$amount,2); if($amount<=0) throw new Exception('Nominal modal harus lebih dari Rp 0.');
        $source_type=in_array($source_type,['owner','investor','loan','other'],true)?$source_type:'owner';
        $contributor_name=sanitize_text_field($contributor_name?:($source_type==='owner'?'Pemilik Usaha':'Investor'));
        $deposit_date=sanitize_text_field($deposit_date?:current_time('Y-m-d')); $target_account=sanitize_text_field($target_account?:'Kas Tunai Toko');
        $capital_no=sanitize_text_field($capital_no?:self::document_number('capital'));
        $wpdb->query('START TRANSACTION');
        try {
            $t=PK01_DB::t('capital_transactions');
            self::guard_entry('capital_deposit',$capital_no,['amount'=>$amount,'source_type'=>$source_type,'contributor'=>$contributor_name]);
            $wpdb->insert($t,['amount'=>$amount,'reference_no'=>$capital_no,'owner_id'=>0,'investor_id'=>0,'capital_type'=>$source_type==='investor'?'investor_capital':($source_type==='loan'?'loan':'initial_capital'),'source'=>$source_type.':'.$contributor_name,'description'=>sanitize_textarea_field($notes),'created_at'=>$deposit_date.' '.current_time('H:i:s')]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Modal gagal disimpan.');
            $id=(int)$wpdb->insert_id;
            self::cash('in',$amount,'Penyetoran Modal','capital',$id,'Setoran modal '.$contributor_name.': '.$notes,$target_account,$capital_no);
            // Legacy capital table tetap diisi jika modul lama masih membacanya; ini bukan ledger kedua.
            $legacy=$wpdb->prefix.'pk01_capital';
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$legacy))===$legacy){
                $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$legacy}`",0); $data=['capital_no'=>$capital_no,'source_type'=>$source_type,'contributor_name'=>$contributor_name,'amount'=>$amount,'deposit_date'=>$deposit_date,'target_account'=>$target_account,'notes'=>$notes,'created_by'=>get_current_user_id(),'created_at'=>$deposit_date.' '.current_time('H:i:s')];
                $data=array_intersect_key($data,array_flip($cols)); $wpdb->insert($legacy,$data);
            }
            $wpdb->query('COMMIT'); self::log('capital_deposit','finance','capital_transaction',(string)$id,null,['amount'=>$amount,'capital_no'=>$capital_no]); return $id;
        } catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    /** Mutasi kas manual yang terhubung biaya: satu event menghasilkan kas + biaya satu kali. */
    public static function record_cash_mutation($direction,$amount,$account='Kas Tunai Toko',$category='Operasional',$reference_no='',$description='') {
        global $wpdb;
        $direction=in_array($direction,['in','out'],true)?$direction:'in'; $amount=round((float)$amount,2);
        if($amount<=0) throw new Exception('Nominal mutasi kas harus lebih dari Rp 0.');
        if(trim($description)==='') throw new Exception('Keterangan mutasi kas wajib diisi.');
        $ref=sanitize_text_field($reference_no); $key=$ref?:hash('sha256',$direction.'|'.$amount.'|'.$account.'|'.$category.'|'.$description.'|'.current_time('Y-m-d'));
        self::guard_entry('manual_cash',$direction.'|'.$key,['amount'=>$amount,'category'=>$category]);
        $wpdb->query('START TRANSACTION');
        try {
            self::cash($direction,$amount,$category,'manual',0,$description,$account,$ref);
            $operational=in_array(strtolower(trim($category)),['operasional','operasional toko','listrik & internet','listrik, air & internet','logistik & pengiriman','sewa tempat','pemasaran & iklan','peralatan & maintenance','biaya usaha'],true);
            if($direction==='out' && $operational){
                $t=PK01_DB::t('operational_costs'); $wpdb->insert($t,['cost_date'=>current_time('Y-m-d'),'category'=>$category,'amount'=>$amount,'payment_method'=>$account,'reference_no'=>$ref?:self::document_number('payment'),'description'=>'Pengeluaran Kas: '.$description,'created_by'=>get_current_user_id(),'created_at'=>self::now()]);
                if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Biaya kas gagal disinkronkan.');
            }
            $wpdb->query('COMMIT'); return true;
        } catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function create_capital($amount, $source = '', $desc = '', $owner_id = 0) {
        global $wpdb;
        $amount = round((float)$amount, 2);
        if ($amount <= 0) throw new Exception('Nominal modal harus lebih dari Rp 0.');

        $t = PK01_DB::t('capital_transactions'); $capital_no=self::document_number('capital');
        self::guard_entry('capital', ((int)$owner_id).'|'.number_format($amount,2,'.','').'|'.sanitize_key($source).'|'.md5(sanitize_textarea_field($desc)), ['owner_id'=>(int)$owner_id,'amount'=>$amount,'source'=>$source]);
        $wpdb->insert($t, [
            'amount'      => $amount,
            'reference_no'=> $capital_no,
            'owner_id'   => (int)$owner_id,
            'capital_type' => 'initial_capital',
            'source'      => sanitize_text_field($source),
            'description' => sanitize_textarea_field($desc),
            'created_at'  => self::now()
        ]);
        $id = $wpdb->insert_id;

        self::cash('in', $amount, 'Penyetoran Modal', 'capital', $id, $desc, 'Kas Tunai Toko');
        return $id;
    }

    /**
     * Tambah Pengeluaran Biaya Usaha (Jabat Tangan ke operational_costs.php)
     */
    /** Catat pembelian langsung persediaan: stok naik, kas hanya turun jika dibayar. */
    public static function record_inventory_receipt($material_id, $qty, $unit_cost, $paid = true, $notes = '', $receipt_no = '') {
        global $wpdb;
        $material_id=(int)$material_id; $qty=round((float)$qty,4); $unit_cost=round((float)$unit_cost,2);
        if($material_id<=0 || $qty<=0 || $unit_cost<0) throw new Exception('Bahan, qty dan harga beli tidak valid.');
        $tm=PK01_DB::t('materials'); $m=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tm}` WHERE id=%d",$material_id));
        if(!$m) throw new Exception('Bahan tidak ditemukan.');
        $total=round($qty*$unit_cost,2); $receipt_no=sanitize_text_field($receipt_no?:self::document_number('goods_receipt')); self::guard_entry('inventory_receipt', $material_id.'|'.$qty.'|'.$unit_cost.'|'.($paid?'1':'0').'|'.md5(sanitize_textarea_field($notes)), ['material_id'=>$material_id,'qty'=>$qty,'unit_cost'=>$unit_cost]); $wpdb->query('START TRANSACTION');
        try {
            $wpdb->query($wpdb->prepare("UPDATE `{$tm}` SET stock=stock+%f,cost=%f WHERE id=%d",$qty,$unit_cost,$material_id));
            $ts=PK01_DB::t('stock_transactions'); $wpdb->insert($ts,['stock_type'=>'material','item_id'=>$material_id,'material_id'=>$material_id,'qty'=>$qty,'unit_cost'=>$unit_cost,'total_value'=>$total,'direction'=>'in','reference_type'=>'inventory_receipt','reference_id'=>0,'reference_no'=>$receipt_no,'notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id(),'created_at'=>self::now()]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Mutasi stok gagal.');
            if($paid && $total>0) self::cash('out',$total,'Pembelian Persediaan','inventory_receipt',$wpdb->insert_id,sanitize_textarea_field($notes),'Kas Tunai Toko',$receipt_no);
            $wpdb->query('COMMIT'); self::log('inventory_receipt','inventory','materials',(string)$material_id,null,['qty'=>$qty,'unit_cost'=>$unit_cost,'total'=>$total,'paid'=>$paid],'Pembelian/input persediaan'); return $wpdb->insert_id;
        } catch(Throwable $e){$wpdb->query('ROLLBACK'); throw $e;}
    }

    /** Posting penyusutan aset tetap metode garis lurus; tidak mengurangi kas. */
    public static function post_asset_depreciation($asset_id, $period_key='') {
        global $wpdb; $asset_id=(int)$asset_id; $period_key=$period_key?:current_time('Y-m');
        $ta=PK01_DB::t('fixed_assets'); $td=PK01_DB::t('asset_depreciation');
        $a=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$ta}` WHERE id=%d AND status='active'",$asset_id)); if(!$a) throw new Exception('Aset aktif tidak ditemukan.');
        if($wpdb->get_var($wpdb->prepare("SELECT id FROM `{$td}` WHERE asset_id=%d AND period_key=%s",$asset_id,$period_key))) throw new Exception('Penyusutan periode tersebut sudah diposting.');
        $base=max(0,(float)$a->purchase_cost-(float)$a->residual_value); $monthly=round($base/max(1,(int)$a->useful_life_months),2);
        $prev=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(depreciation_amount),0) FROM `{$td}` WHERE asset_id=%d",$asset_id));
        $remaining=max(0,$base-$prev); $amount=min($monthly,$remaining); if($amount<=0) throw new Exception('Nilai aset sudah habis disusutkan.');
        $wpdb->insert($td,['asset_id'=>$asset_id,'period_key'=>$period_key,'depreciation_amount'=>$amount,'accumulated_amount'=>$prev+$amount,'status'=>'posted','created_at'=>self::now()]); if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Penyusutan gagal disimpan.');
        self::log('asset_depreciation','finance','fixed_asset',(string)$asset_id,null,['period'=>$period_key,'amount'=>$amount],'Penyusutan aset tetap'); return $wpdb->insert_id;
    }

    public static function add_operational_cost($data = []) {
        global $wpdb;
        $amount = round((float)($data['amount'] ?? 0), 2);
        if ($amount <= 0) throw new Exception('Nominal biaya operasional harus lebih dari 0.');

        $category       = sanitize_text_field($data['category'] ?? 'Operasional Toko');
        $cost_date      = sanitize_text_field($data['cost_date'] ?? current_time('Y-m-d'));
        $payment_method = sanitize_text_field($data['payment_method'] ?? 'Kas Tunai');
        $reference_no   = sanitize_text_field($data['reference_no'] ?? '');
        $description    = sanitize_textarea_field($data['description'] ?? '');
        $created_by     = get_current_user_id();

        $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('operational_costs') : $wpdb->prefix . 'pk01_operational_costs';
        $natural = $reference_no !== '' ? 'ref:'.$reference_no : ($cost_date.'|'.$category.'|'.number_format($amount,2,'.','').'|'.$payment_method.'|'.md5($description));
        self::guard_entry('operational_cost', $natural, ['amount'=>$amount,'category'=>$category,'cost_date'=>$cost_date]);
        $wpdb->insert($t, [
            'cost_date'      => $cost_date,
            'category'       => $category,
            'amount'         => $amount,
            'payment_method' => $payment_method,
            'reference_no'   => $reference_no,
            'description'    => $description,
            'created_by'     => $created_by,
            'created_at'     => self::now()
        ]);
        if (!$wpdb->insert_id) throw new Exception('Biaya operasional gagal disimpan: '.($wpdb->last_error ?: 'database error'));

        $cost_id = (int) $wpdb->insert_id;

        // Potong Otomatis Saldo Kas
        self::cash('out', $amount, $category, 'operational_cost', $cost_id, $description, $payment_method, $reference_no);

        self::log('operational_cost_create', 'finance', 'operational_costs', (string)$cost_id, null, ['amount' => $amount, 'category' => $category]);
        return $cost_id;
    }

    /**
     * 2. RUMUS HPP & PENETAPAN HARGA
     */
    public static function calculate_hpp($direct, $variable, $fixed, $volume, $other = 0) {
        return round((float)$direct + (float)$variable + (float)$other + ((float)$fixed / max(1, (float)$volume)), 2);
    }

    public static function price($hpp, $profit, $fee = 0, $round = 1000) {
        $den = 1 - ((float)$fee / 100);
        if ($den <= 0) throw new Exception('Biaya fee layanan harus kurang dari 100%.');
        $raw = ((float)$hpp * (1 + (float)$profit / 100)) / $den;
        $round = max(1, (int)$round);
        return round(ceil($raw / $round) * $round, 2);
    }

    /**
     * Penetapan harga jual berbasis HPP + target markup + biaya kanal.
     * Tidak menggantikan price(); ini adalah jalur tambahan agar biaya pihak ketiga
     * dan packing dapat dihitung eksplisit tanpa mengubah transaksi lama.
     */
    public static function recommended_selling_price($hpp, $markup_percent = 30, $fee_percent = 0, $selling_cost_fixed = 0, $round = 1000) {
        $hpp = max(0, (float)$hpp);
        $markup_percent = max(0, (float)$markup_percent);
        $fee_percent = max(0, (float)$fee_percent);
        $selling_cost_fixed = max(0, (float)$selling_cost_fixed);
        if ($fee_percent >= 100) throw new Exception('Total fee pihak ketiga harus kurang dari 100%.');
        $base = ($hpp * (1 + $markup_percent / 100)) + $selling_cost_fixed;
        $den = 1 - ($fee_percent / 100);
        $raw = $base / $den;
        $round = max(1, (int)$round);
        return round(ceil($raw / $round) * $round, 2);
    }

    public static function selling_price_breakdown($hpp, $markup_percent = 30, $fee_percent = 0, $selling_cost_fixed = 0, $price = null) {
        $hpp=max(0,(float)$hpp); $markup_percent=max(0,(float)$markup_percent); $fee_percent=max(0,(float)$fee_percent); $selling_cost_fixed=max(0,(float)$selling_cost_fixed);
        if ($fee_percent >= 100) throw new Exception('Total fee pihak ketiga harus kurang dari 100%.');
        $price = $price === null ? self::recommended_selling_price($hpp,$markup_percent,$fee_percent,$selling_cost_fixed) : max(0,(float)$price);
        $fee = $price * $fee_percent / 100;
        $gross_after_fee = $price - $fee - $selling_cost_fixed;
        $profit = $gross_after_fee - $hpp;
        return [
            'hpp'=>round($hpp,2),'markup_percent'=>round($markup_percent,2),'fee_percent'=>round($fee_percent,2),
            'selling_cost_fixed'=>round($selling_cost_fixed,2),'price'=>round($price,2),'fee_amount'=>round($fee,2),
            'profit_after_channel_cost'=>round($profit,2),
            'profit_on_hpp_percent'=>$hpp>0?round(($profit/$hpp)*100,2):0,
            'margin_on_selling_price'=>$price>0?round(($profit/$price)*100,2):0
        ];
    }

    /**
     * 3. PRODUK & SPESIFIKASI
     */
    /**
     * TRANSAKSI PENJUALAN TERPUSAT
     * Semua kanal internal/API harus menggunakan alur yang sama:
     * validasi stok -> invoice -> item -> mutasi stok -> pembayaran riil -> audit.
     */
    public static function create_sale($data = []) {
        global $wpdb;
        $variant_id=absint($data['variant_id']??0); $qty=max(0.0001,(float)($data['qty']??1));
        $customer_name=sanitize_text_field($data['customer_name']??'Pelanggan'); $customer_phone=sanitize_text_field($data['customer_phone']??'');
        $shipping_address=sanitize_textarea_field($data['shipping_address']??''); $channel=sanitize_key($data['channel']??'website');
        $seller_id=absint($data['seller_id']??0); $payment_method=sanitize_text_field($data['payment_method']??'Transfer Bank'); $tracking_no=strtoupper(sanitize_text_field($data['tracking_no']??'')); $courier=sanitize_key($data['courier']??''); $shipping_service=sanitize_text_field($data['shipping_service']??'REG');
        $raw_price=array_key_exists('price',$data)?(float)$data['price']:0; $payment_status=sanitize_key($data['payment_status']??'unpaid');
        $requested_paid=max(0,(float)($data['paid_amount']??0));
        if(!in_array($payment_status,['unpaid','partial','paid'],true))$payment_status='unpaid';
        if($customer_name==='')throw new Exception('Pelanggan wajib diisi.');

        $vt=PK01_DB::t('product_variants'); $v=null; $product_name=sanitize_text_field($data['product_name']??'Produk Kustom / Khusus'); $hpp=max(0,(float)($data['hpp']??0));
        $available_stock=0;$stock_used=0;$production_shortage=0;
        if($variant_id>0){
            $v=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$vt}` WHERE id=%d AND status='active' FOR UPDATE",$variant_id),ARRAY_A);
            if(!$v)throw new Exception('SKU produk tidak ditemukan atau tidak aktif.');
            $product_name=$v['name'];$hpp=(float)$v['hpp'];if(!array_key_exists('price',$data)||$raw_price<=0)$raw_price=(float)$v['price'];
            $available_stock=max(0,(float)$v['stock']);$stock_used=min($available_stock,$qty);$production_shortage=max(0,$qty-$available_stock);$supply_mode=in_array(($v['supply_mode']??'production'),['production','purchase','hybrid'],true)?$v['supply_mode']:'production';
        }
        if($raw_price<=0)throw new Exception('Harga jual belum ditetapkan.');
        $price=round($raw_price,2);$total=round($price*$qty,2);$paid=$payment_status==='paid'?$total:min($total,$requested_paid);
        if($payment_status==='partial'&&$paid<=0){$payment_status='unpaid';$paid=0;}if($payment_status==='paid')$paid=$total;

        $commission=0;
        if($seller_id>0){
            $seller=$wpdb->get_row($wpdb->prepare("SELECT id,commission_percent,active FROM `".PK01_DB::t('sales_accounts')."` WHERE id=%d",$seller_id),ARRAY_A);
            if(!$seller||empty($seller['active']))throw new Exception('Seller yang dipilih tidak aktif.');
            $commission=round($total*max(0,(float)$seller['commission_percent'])/100,2);
        }
        $no=self::document_number('invoice',get_option('pk01_invoice_prefix','INV'),absint(get_option('pk01_invoice_digits',5)),get_option('pk01_invoice_pattern','{PREFIX}/{YYYY}{MM}/{SEQ}'));$now=self::now();

        $wpdb->query('START TRANSACTION');
        try{
            $shipping_status=$production_shortage>0?'pending':($payment_status==='paid'?'ready_to_pack':'pending');
            $payload=['order_no'=>$no,'invoice_no'=>$no,'channel'=>$channel,'seller_id'=>$seller_id,'customer_name'=>$customer_name,'customer_phone'=>$customer_phone,'shipping_address'=>$shipping_address,'variant_id'=>$variant_id,'product_name'=>$product_name,'qty'=>$qty,'price'=>$price,'hpp'=>$hpp,'total_amount'=>$total,'gross'=>$total,'net'=>$total,'commission'=>$commission,'commission_status'=>$commission>0?'pending':'none','payment_method'=>$payment_method,'payment_status'=>$payment_status,'paid_amount'=>$paid,'deposit_amount'=>$paid,'paid_at'=>$paid>0?$now:null,'status'=>sanitize_key($data['status']??'processing'),'shipping_status'=>$shipping_status,'tracking_no'=>$tracking_no,'courier'=>$courier,'notes'=>sanitize_textarea_field($data['notes']??''),'created_at'=>$now];
            $cols=$wpdb->get_col("DESC `".PK01_DB::t('sales_orders')."`",0);$payload=array_intersect_key($payload,array_flip($cols));
            if(!$wpdb->insert(PK01_DB::t('sales_orders'),$payload))throw new Exception('Gagal menyimpan transaksi penjualan: '.($wpdb->last_error?:'database error'));
            $oid=(int)$wpdb->insert_id;
            if(!$wpdb->insert(PK01_DB::t('sales_order_items'),['order_id'=>$oid,'variant_id'=>$variant_id,'product_name'=>$product_name,'qty'=>$qty,'unit_price'=>$price,'hpp'=>$hpp,'total'=>$total]))throw new Exception('Gagal menyimpan item penjualan.');
            if($variant_id>0&&$stock_used>0){
                $changed=$wpdb->query($wpdb->prepare("UPDATE `{$vt}` SET stock=stock-%f,updated_at=%s WHERE id=%d AND stock>=%f",$stock_used,$now,$variant_id,$stock_used));
                if($changed!==1)throw new Exception('Stok berubah saat transaksi dikunci. Silakan ulangi.');
                if(!$wpdb->insert(PK01_DB::t('stock_transactions'),['stock_type'=>'finished','item_id'=>$variant_id,'variant_id'=>$variant_id,'qty'=>$stock_used,'direction'=>'out','reference_type'=>'sales_order','reference_id'=>$oid,'reference_no'=>$no,'notes'=>'Penjualan dari stok tersedia '.$channel.' '.$no,'created_by'=>get_current_user_id(),'created_at'=>$now]))throw new Exception('Gagal mencatat mutasi stok.');
            }
            $tc=PK01_DB::t('customers');
            if($tc&&$customer_name!==''){
                $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$tc}` WHERE name=%s OR (phone<>'' AND phone=%s) LIMIT 1",$customer_name,$customer_phone));
                if(!$existing)$wpdb->insert($tc,['name'=>$customer_name,'phone'=>$customer_phone,'created_at'=>$now]);
            }
            if($seller_id>0&&PK01_DB::t('seller_sales')){
                $st=PK01_DB::t('seller_sales');$scols=$wpdb->get_col("DESC `{$st}`",0);
                $sp=['seller_account_id'=>$seller_id,'order_id'=>$oid,'variant_id'=>$variant_id,'qty'=>$qty,'hpp'=>$hpp,'unit_price'=>$price,'total'=>$total,'sold_at'=>$now,'commission_amount'=>$commission,'status'=>$payment_status==='paid'?'completed':'pending','source_type'=>'cashier_sale'];$sp=array_intersect_key($sp,array_flip($scols));
                $existing_ss=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$st}` WHERE order_id=%d LIMIT 1",$oid));if(!$existing_ss&&!empty($sp))$wpdb->insert($st,$sp);
            }
            if($paid>0){ $cash_account=(stripos($payment_method,'kas')!==false || stripos($payment_method,'cash')!==false) ? self::cashier_account(get_current_user_id()) : $payment_method; self::cash('in',$paid,'Penjualan','sales_order',$oid,'Pembayaran penjualan '.$no.' ('.$customer_name.')',$cash_account,$no); }
            if($seller_id>0&&$paid>0)self::apply_cashier_payment_to_seller_ar($oid,$paid,$payment_method);
            $wpdb->query('COMMIT');

            // Bila Kasir sudah memiliki resi, resi langsung dibuat sebagai record
            // pengiriman untuk laporan/Gudang. Ini TIDAK mengubah nilai tagihan.
            $shipment_id = 0;
            if ($tracking_no !== '') {
                $shipment_id = self::create_shipment($channel ?: 'website', $tracking_no, $courier, $shipping_service, $oid, 0, $customer_name, $customer_phone, $shipping_address, true);
                if ($shipment_id && class_exists('PK01_Shipping_Smart')) PK01_Shipping_Smart::verify_shipment($shipment_id);
            }

            // Penjualan nyata otomatis menjadi pekerjaan fulfillment. Tidak membuat
            // data packing palsu; hanya mengubah order yang baru saja dibukukan.
            if ($production_shortage <= 0 && $payment_status === 'paid' && class_exists('PK01_Operational_Flow')) {
                PK01_Operational_Flow::release_to_packing($oid);
                $shipping_status = 'ready_to_pack';
            }

            $job_id=0; $purchase_request_id=0;
            if($production_shortage>0&&$variant_id>0){
                if($supply_mode==='purchase'){
                    $purchase_request_id=self::create_finished_purchase_request($variant_id,$production_shortage,$oid,'Kekurangan stok dari penjualan Kasir '.$no.'. Dipenuhi melalui pembelian produk jadi.');
                } else {
                    $job_id=self::create_production_job('ORDER-'.$no,$variant_id,$production_shortage,'CNC','',current_time('Y-m-d'),'Kekurangan stok Order '.$no.'. Produksi hanya '.$production_shortage.' unit.','normal',$oid,'sale');
                }
            }
            self::log('sale_created','sales','sales_order',$no,null,['order_id'=>$oid,'total'=>$total,'paid'=>$paid,'stock_used'=>$stock_used,'production_shortage'=>$production_shortage,'job_id'=>$job_id,'purchase_request_id'=>$purchase_request_id,'supply_mode'=>$supply_mode,'channel'=>$channel]);
            if(class_exists('PK01_Kernel'))PK01_Kernel::event('sale_created','sales','sales_order',$oid,['order_no'=>$no,'total'=>$total,'stock_used'=>$stock_used,'production_shortage'=>$production_shortage,'job_id'=>$job_id]);
            return ['order_id'=>$oid,'order_no'=>$no,'total'=>$total,'paid'=>$paid,'payment_status'=>$payment_status,'stock_used'=>$stock_used,'production_shortage'=>$production_shortage,'production_required'=>$production_shortage>0&&$supply_mode!=='purchase','job_id'=>$job_id,'purchase_required'=>$purchase_request_id>0,'purchase_request_id'=>$purchase_request_id,'supply_mode'=>$supply_mode,'shipping_status'=>$shipping_status,'shipment_id'=>$shipment_id];
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

public static function create_product($code, $name, $notes = '', $description = '', $spec = []) {
        global $wpdb;
        $n = self::now();
        $code = sanitize_text_field($code);
        $name = sanitize_text_field($name);

        if ($code === '') {
            $prefix = get_option('pk01_product_prefix', 'PRD');
            $code = $prefix . '-' . wp_rand(1000, 9999);
        }
        if ($name === '') throw new Exception('Nama produk wajib diisi.');

        $t = PK01_DB::t('products');
        self::guard_entry('product', 'code:'.$code, ['name'=>$name]);
        $data = [
            'code'        => $code,
            'name'        => $name,
            'slug'        => sanitize_title($name),
            'notes'       => sanitize_textarea_field($notes),
            'status'      => 'active',
            'image_id'    => absint($spec['image_id'] ?? 0),
            'created_at'  => $n,
            'updated_at'  => $n
        ];

        $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$t}`", 0);
        if (in_array('description', $cols, true)) $data['description'] = sanitize_textarea_field($description);
        // Simpan spesifikasi produksi di master produk; Job akan mengambil snapshot
        // sehingga perubahan master setelah Job dibuat tidak mengubah histori Job.
        $spec_map = [
            'product_length'=>'product_length','product_width'=>'product_width','product_height'=>'product_height',
            'product_thickness'=>'product_thickness','product_weight'=>'product_weight',
            'dimension_unit'=>'dimension_unit','weight_unit'=>'weight_unit','finishing'=>'finishing',
            'color'=>'color','product_description'=>'product_description','production_notes'=>'production_notes',
            'production_instructions'=>'production_instructions','spec_status'=>'spec_status','technical_drawing_id'=>'technical_drawing_id','cnc_file_id'=>'cnc_file_id'
        ];
        foreach ($spec_map as $src=>$dst) {
            if (array_key_exists($src,$spec) && in_array($dst,$cols,true)) {
                $data[$dst] = is_numeric($spec[$src]) ? (float)$spec[$src] : sanitize_textarea_field((string)$spec[$src]);
            }
        }

        if (!$wpdb->insert($t, $data)) {
            if(class_exists('PK01_Duplicate_Guard')) PK01_Duplicate_Guard::release('product','code:'.$code);
            throw new Exception('Produk gagal disimpan: ' . ($wpdb->last_error ?: 'Kesalahan database.'));
        }

        $id = (int) $wpdb->insert_id;
        self::log('product_create', 'products', 'product', (string)$id, null, $data);
        do_action('pk01_product_created', $id, $data);
        return $id;
    }

    public static function create_variant($product_id, $sku, $name, $size = '', $material = '', $finish = '', $hpp = 0, $price = 0, $stock = 0) {
        global $wpdb;
        $n = self::now();
        $t = PK01_DB::t('product_variants');
        self::guard_entry('variant', 'sku:'.sanitize_text_field($sku), ['product_id'=>(int)$product_id,'sku'=>$sku]);
        $wpdb->insert($t, [
            'product_id' => (int)$product_id,
            'sku'        => sanitize_text_field($sku),
            'name'       => sanitize_text_field($name),
            'size'       => sanitize_text_field($size),
            'material'   => sanitize_text_field($material),
            'finishing'  => sanitize_text_field($finish),
            'hpp'        => round((float)$hpp, 2),
            'price'      => round((float)$price, 2),
            'stock'      => max(0, (float)$stock),
            'status'     => 'active',
            'created_at' => $n,
            'updated_at' => $n
        ]);
        if(!$wpdb->insert_id && class_exists('PK01_Duplicate_Guard')) PK01_Duplicate_Guard::release('variant','sku:'.sanitize_text_field($sku));
        return (int) $wpdb->insert_id;
    }



    public static function set_variant_supply_mode($variant_id,$mode,$supplier_id=0,$external_product_code='',$purchase_cost=0){
        global $wpdb; $variant_id=(int)$variant_id; $mode=in_array($mode,['production','purchase','hybrid'],true)?$mode:'production';
        $t=PK01_DB::t('product_variants'); $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$t}`",0); $data=[];
        if(in_array('supply_mode',$cols,true))$data['supply_mode']=$mode;
        if(in_array('supplier_id',$cols,true))$data['supplier_id']=max(0,(int)$supplier_id);
        if(in_array('external_product_code',$cols,true))$data['external_product_code']=sanitize_text_field($external_product_code);
        if(in_array('purchase_cost',$cols,true))$data['purchase_cost']=max(0,(float)$purchase_cost);
        if($variant_id>0&&$data)$wpdb->update($t,$data,['id'=>$variant_id]); return $variant_id;
    }

    public static function purchase_finished_product($variant_id,$qty,$unit_cost,$supplier_id=0,$notes=''){
        global $wpdb; $variant_id=(int)$variant_id;$qty=(float)$qty;$unit_cost=max(0,(float)$unit_cost);$supplier_id=max(0,(int)$supplier_id);
        if($variant_id<=0||$qty<=0)throw new Exception('Produk jadi dan jumlah pembelian wajib valid.');
        $vt=PK01_DB::t('product_variants');$v=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$vt}` WHERE id=%d AND status='active' FOR UPDATE",$variant_id),ARRAY_A);
        if(!$v)throw new Exception('SKU produk jadi tidak ditemukan atau tidak aktif.');
        $no=self::document_number('finished_purchase');$now=self::now();$total=round($qty*$unit_cost,2);$wpdb->query('START TRANSACTION');
        try{
            $pt=PK01_DB::t('finished_product_purchases');
            if(!$wpdb->insert($pt,['purchase_no'=>$no,'supplier_id'=>$supplier_id,'variant_id'=>$variant_id,'qty'=>$qty,'unit_cost'=>$unit_cost,'total'=>$total,'status'=>'received','received_at'=>$now,'notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id(),'created_at'=>$now]))throw new Exception($wpdb->last_error?:'Pembelian produk jadi gagal dicatat.');
            $pid=(int)$wpdb->insert_id;$new_stock=(float)$v['stock']+$qty;
            $new_mode=(($v['supply_mode']??'production')==='purchase')?'purchase':((($v['supply_mode']??'production')==='hybrid')?'hybrid':'hybrid');
            $wpdb->query($wpdb->prepare("UPDATE `{$vt}` SET stock=%f,purchase_cost=%f,hpp=%f,supply_mode=%s,supplier_id=%d,updated_at=%s WHERE id=%d",$new_stock,$unit_cost,$unit_cost,$new_mode,$supplier_id,$now,$variant_id));
            if(!$wpdb->insert(PK01_DB::t('stock_transactions'),['stock_type'=>'finished','item_id'=>$variant_id,'variant_id'=>$variant_id,'qty'=>$qty,'direction'=>'in','unit_cost'=>$unit_cost,'total_value'=>$total,'reference_type'=>'finished_product_purchase','reference_id'=>$pid,'reference_no'=>$no,'notes'=>'Pembelian produk jadi dari pemasok','created_by'=>get_current_user_id(),'created_at'=>$now]))throw new Exception($wpdb->last_error?:'Mutasi stok pembelian produk jadi gagal.');
            $wpdb->query('COMMIT');self::log('finished_product_purchased','purchasing','finished_product_purchase',(string)$pid,null,['purchase_no'=>$no,'variant_id'=>$variant_id,'qty'=>$qty,'unit_cost'=>$unit_cost]);
            return ['id'=>$pid,'purchase_no'=>$no,'variant_id'=>$variant_id,'qty'=>$qty,'unit_cost'=>$unit_cost,'total'=>$total,'stock'=>$new_stock];
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function create_finished_purchase_request($variant_id,$qty,$source_order_id=0,$notes=''){
        global $wpdb;$variant_id=(int)$variant_id;$qty=(float)$qty;if($variant_id<=0||$qty<=0)throw new Exception('Produk dan jumlah permintaan pembelian tidak valid.');
        $v=$wpdb->get_row($wpdb->prepare("SELECT v.*,p.name product_name FROM `".PK01_DB::t('product_variants')."` v JOIN `".PK01_DB::t('products')."` p ON p.id=v.product_id WHERE v.id=%d",$variant_id),ARRAY_A);if(!$v)throw new Exception('SKU produk tidak ditemukan.');
        $t=PK01_DB::t('finished_product_purchase_requests');$no=self::document_number('finished_purchase_request');$cols=$wpdb->get_col("DESC `{$t}`",0);
        $data=array_intersect_key(['request_no'=>$no,'variant_id'=>$variant_id,'qty'=>$qty,'supplier_id'=>(int)($v['supplier_id']??0),'source_order_id'=>(int)$source_order_id,'status'=>'requested','notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id(),'created_at'=>self::now()],array_flip($cols));
        if(!$wpdb->insert($t,$data))throw new Exception($wpdb->last_error?:'Permintaan pembelian produk jadi gagal.');return (int)$wpdb->insert_id;
    }

    /**
     * Update master produk dari kanal terintegrasi.
     * Theme/storefront tidak menyentuh tabel PK01 secara langsung; perubahan
     * tetap melewati Business Engine agar audit dan aturan data terpusat.
     */
    public static function update_product($product_id, $data = []) {
        global $wpdb;
        $product_id = (int)$product_id;
        if ($product_id <= 0 || !is_array($data)) throw new Exception('Produk tidak valid.');
        $t = PK01_DB::t('products');
        $old = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d", $product_id), ARRAY_A);
        if (!$old) throw new Exception('Produk tidak ditemukan.');

        $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$t}`", 0);
        $allowed = ['code','name','slug','notes','description','status','image_id','category',
            'product_length','product_width','product_height','product_thickness','product_weight',
            'dimension_unit','weight_unit','finishing','color','product_description','production_notes',
            'production_instructions','spec_status'];
        $payload = [];
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $data) || !in_array($key, $cols, true)) continue;
            $v = $data[$key];
            if (in_array($key, ['product_length','product_width','product_height','product_thickness','product_weight'], true)) {
                $payload[$key] = (float)$v;
            } elseif ($key === 'image_id') {
                $payload[$key] = (int)$v;
            } elseif ($key === 'status') {
                $payload[$key] = in_array($v, ['active','inactive','draft'], true) ? $v : 'active';
            } else {
                $payload[$key] = sanitize_textarea_field((string)$v);
            }
        }
        if (isset($payload['name']) && $payload['name'] === '') throw new Exception('Nama produk wajib diisi.');
        if (isset($payload['code']) && $payload['code'] === '') throw new Exception('Kode produk wajib diisi.');
        if (isset($payload['name']) && !isset($data['slug'])) $payload['slug'] = sanitize_title($payload['name']);
        if (!$payload) return $product_id;
        if (in_array('updated_at', $cols, true)) $payload['updated_at'] = self::now();
        if (!$wpdb->update($t, $payload, ['id'=>$product_id])) {
            if ($wpdb->last_error) throw new Exception('Produk gagal diperbarui: '.$wpdb->last_error);
        }
        self::log('product_update','products','product',(string)$product_id,$old,$payload,'Perubahan master produk melalui integration gateway.');
        do_action('pk01_product_updated', $product_id, $old, $payload);
        return $product_id;
    }

    /**
     * Update master varian/SKU dari kanal terintegrasi.
     */
    public static function update_variant($variant_id, $data = []) {
        global $wpdb;
        $variant_id = (int)$variant_id;
        if ($variant_id <= 0 || !is_array($data)) throw new Exception('Varian tidak valid.');
        $t = PK01_DB::t('product_variants');
        $old = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d", $variant_id), ARRAY_A);
        if (!$old) throw new Exception('Varian tidak ditemukan.');
        $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$t}`", 0);
        $allowed = ['sku','name','size','material','finishing','hpp','price','stock','status'];
        $payload=[];
        foreach ($allowed as $key) {
            if (!array_key_exists($key,$data) || !in_array($key,$cols,true)) continue;
            $v=$data[$key];
            if (in_array($key,['hpp','price','stock'],true)) $payload[$key]=max(0,(float)$v);
            elseif ($key==='status') $payload[$key]=in_array($v,['active','inactive','draft'],true)?$v:'active';
            else $payload[$key]=sanitize_text_field((string)$v);
        }
        if (isset($payload['sku']) && $payload['sku']==='') throw new Exception('SKU wajib diisi.');
        if (!$payload) return $variant_id;
        if (in_array('updated_at',$cols,true)) $payload['updated_at']=self::now();
        if (!$wpdb->update($t,$payload,['id'=>$variant_id])) {
            if ($wpdb->last_error) throw new Exception('Varian gagal diperbarui: '.$wpdb->last_error);
        }
        self::log('variant_update','products','product_variant',(string)$variant_id,$old,$payload,'Perubahan SKU melalui integration gateway.');
        do_action('pk01_variant_updated', $variant_id, $old, $payload);
        return $variant_id;
    }

    /**
     * 4. GUDANG & MATERIAL
     */
    public static function create_material($code, $name, $unit = 'pcs', $cost = 0, $min_stock = 0, $supplier_id = 0) {
        global $wpdb;
        $code = sanitize_text_field($code);
        $name = sanitize_text_field($name);
        $cost = round((float)$cost, 2);
        $min_stock = max(0, (float)$min_stock);

        if ($code === '' || $name === '') throw new Exception('Kode dan nama bahan baku wajib diisi.');

        $t = PK01_DB::t('materials');
        self::guard_entry('material', 'code:'.$code, ['name'=>$name]);
        $ok = $wpdb->insert($t, [
            'code'        => $code,
            'name'        => $name,
            'unit'        => $unit ?: 'pcs',
            'cost'        => $cost,
            'stock'       => 0,
            'min_stock'   => $min_stock,
            'supplier_id' => (int)$supplier_id ?: null,
            'created_at'  => self::now()
        ]);

        if (!$ok) throw new Exception('Bahan baku gagal disimpan. Kode bahan mungkin sudah digunakan.');
        $id = (int)$wpdb->insert_id;
        self::log('material_create', 'materials', 'material', (string)$id, null, ['code' => $code, 'name' => $name]);
        return $id;
    }

    /**
     * 5. SDM, KARYAWAN & GAJI
     */
    public static function save_employee($id = 0, $code = '', $name = '', $position = '', $division = '', $pay_type = 'monthly', $rate = 0, $status = 'active', $user_id = 0) {
        global $wpdb;
        $id = (int)$id;
        $name = sanitize_text_field($name);
        if ($name === '') throw new Exception('Nama lengkap karyawan wajib diisi.');

        $t = PK01_DB::t('employees');
        $code = sanitize_text_field($code) ?: ('KRY-' . str_pad((string)(time() % 100000), 4, '0', STR_PAD_LEFT));

        $data = [
            'code'       => $code,
            'name'       => $name,
            'position'   => sanitize_text_field($position),
            'division'   => sanitize_text_field($division),
            'pay_type'   => in_array($pay_type, ['monthly', 'daily', 'piece'], true) ? $pay_type : 'monthly',
            'rate'       => max(0, (float)$rate),
            'status'     => in_array($status, ['active', 'inactive'], true) ? $status : 'active',
            'user_id'    => (int)$user_id ?: null
        ];

        if ($id > 0) {
            $data['updated_at'] = self::now();
            $wpdb->update($t, $data, ['id' => $id]);
            self::log('employee_update', 'employees', 'employee', (string)$id, null, $data);
            return $id;
        }

        $data['created_at'] = self::now();
        self::guard_entry('employee', 'code:'.$code, ['name'=>$name]);
        $wpdb->insert($t, $data);
        $new_id = (int)$wpdb->insert_id;
        self::log('employee_create', 'employees', 'employee', (string)$new_id, null, $data);
        return $new_id;
    }


    /**
     * Simpan bukti penyelesaian Job: hasil baik/reject + foto pekerjaan.
     * Foto masuk ke Media Library sebagai attachment milik laporan, bukan URL bebas.
     */
    public static function complete_job_assignment($assignment_id,$good_qty,$reject_qty=0,$notes='',$files=[]) {
        global $wpdb;
        $assignment_id=(int)$assignment_id; $good=max(0,(float)$good_qty); $reject=max(0,(float)$reject_qty);
        if($assignment_id<=0 || ($good+$reject)<=0) throw new Exception('Hasil pekerjaan wajib diisi.');
        $a=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_assignments')." WHERE id=%d",$assignment_id),ARRAY_A);
        if(!$a) throw new Exception('Penugasan pekerjaan tidak ditemukan.');
        $uid=get_current_user_id();
        $emp=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('employees')." WHERE id=%d",(int)$a['employee_id']),ARRAY_A);
        if(!current_user_can('manage_options') && (!$emp || (int)$emp['user_id']!==$uid)) throw new Exception('Anda tidak berwenang menyelesaikan pekerjaan ini.');
        if(!in_array($a['status'],['in_progress','accepted'],true)) throw new Exception('Job harus sudah diterima dan sedang dikerjakan sebelum dilaporkan selesai.');
        $job=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('jobs')." WHERE id=%d",(int)$a['job_id']),ARRAY_A);
        if(!$job) throw new Exception('Job produksi tidak ditemukan.');
        $already=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(good_qty+reject_qty),0) FROM ".PK01_DB::t('production_results')." WHERE job_id=%d",(int)$job['id']));
        if($already+$good+$reject>(float)$job['target_qty']+0.000001) throw new Exception('Hasil melebihi sisa target Job.');

        $photo_ids=[];
        if(is_array($files)) {
            require_once ABSPATH.'wp-admin/includes/file.php';
            require_once ABSPATH.'wp-admin/includes/media.php';
            require_once ABSPATH.'wp-admin/includes/image.php';
            foreach($files as $file) {
                if(empty($file['name'])) continue;
                if(!empty($file['error']) && (int)$file['error']!==UPLOAD_ERR_OK) throw new Exception('Upload foto gagal: '.sanitize_text_field($file['name']));
                $allowed=['image/jpeg','image/png','image/webp'];
                $check=wp_check_filetype_and_ext($file['tmp_name'],$file['name']);
                $mime=$check['type']?:($file['type']??'');
                if(!in_array($mime,$allowed,true)) throw new Exception('Foto harus JPG, PNG, atau WEBP.');
                $one=['name'=>sanitize_file_name($file['name']),'type'=>$mime,'tmp_name'=>$file['tmp_name'],'error'=>(int)$file['error'],'size'=>(int)$file['size']];
                $uploaded=wp_handle_upload($one,['test_form'=>false,'mimes'=>['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp']]);
                if(isset($uploaded['error'])) throw new Exception('Upload foto gagal: '.$uploaded['error']);
                $attachment_id=wp_insert_attachment([
                    'post_mime_type'=>$uploaded['type'],'post_title'=>sanitize_text_field($job['job_no'].' - Bukti Pekerjaan'),'post_content'=>'','post_status'=>'inherit','post_author'=>$uid
                ],$uploaded['file'],0,true);
                if(is_wp_error($attachment_id)) throw new Exception('Foto berhasil diupload tetapi gagal diregistrasikan.');
                $meta=wp_generate_attachment_metadata($attachment_id,$uploaded['file']); if($meta) wp_update_attachment_metadata($attachment_id,$meta);
                $photo_ids[]=(int)$attachment_id;
            }
        }

        $wpdb->query('START TRANSACTION');
        try {
            if(!empty($photo_ids)) {
                $existing=$wpdb->get_var($wpdb->prepare("SELECT photo_ids FROM ".PK01_DB::t('job_completion_reports')." WHERE assignment_id=%d ORDER BY id DESC LIMIT 1",$assignment_id));
                $old=is_array(json_decode((string)$existing,true))?json_decode((string)$existing,true):[];
                $photo_ids=array_values(array_unique(array_merge(array_map('intval',$old),$photo_ids)));
            }
            $wpdb->insert(PK01_DB::t('job_completion_reports'),[
                'assignment_id'=>$assignment_id,'job_id'=>(int)$a['job_id'],'employee_id'=>(int)$a['employee_id'],
                'good_qty'=>$good,'reject_qty'=>$reject,'photo_ids'=>wp_json_encode($photo_ids),'notes'=>sanitize_textarea_field($notes),
                'created_by'=>$uid,'created_at'=>self::now()
            ]);
            if(!$wpdb->insert_id) throw new Exception('Bukti penyelesaian gagal disimpan.');
            // Pada Job multi-tahap, CNC hanya menyelesaikan tahap CNC. Stok barang
            // jadi dan status Job final ditutup oleh tahap akhir Prema/Finishing.
            $role=sanitize_key($a['role_code']??'');
            $has_prema=(bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM `".PK01_DB::t('job_assignments')."` WHERE job_id=%d AND role_code='prema' AND status NOT IN ('returned') LIMIT 1",(int)$a['job_id']));
            $is_final_stage=!($role==='cnc' && $has_prema);
            if($is_final_stage) self::record_production_result((int)$a['job_id'],$good,$reject,true,false);
            $wpdb->update(PK01_DB::t('job_assignments'),[
                'status'=>'completed','completed_at'=>self::now(),'notes'=>sanitize_textarea_field($notes)
            ],['id'=>$assignment_id]);
            if($is_final_stage) $wpdb->update(PK01_DB::t('jobs'),['status'=>'completed','updated_at'=>self::now()],['id'=>(int)$a['job_id']]);
            else $wpdb->update(PK01_DB::t('jobs'),['status'=>'in_progress','updated_at'=>self::now()],['id'=>(int)$a['job_id']]);
            self::log('job_completion_reported','production','job_assignment',(string)$assignment_id,null,[
                'good_qty'=>$good,'reject_qty'=>$reject,'photo_ids'=>$photo_ids
            ]);
            $wpdb->query('COMMIT');
        } catch(Throwable $e) { $wpdb->query('ROLLBACK'); throw $e; }

        // Jika job berasal dari kekurangan stok order, hasil produksi yang benar-benar
        // selesai otomatis membuka kembali antrean packing order tersebut.
        if (class_exists('PK01_Operational_Flow')) {
            PK01_Operational_Flow::release_order_job((string)($job['job_no'] ?? ''));
        }

        // Create/update the wage obligation only when a real configured rate exists.
        self::ensure_job_wage_for_completed_assignment($assignment_id,$good);
        return ['photo_ids'=>$photo_ids,'good_qty'=>$good,'reject_qty'=>$reject];
    }

    public static function ensure_job_wage_for_completed_assignment($assignment_id,$good_qty) {
        global $wpdb;
        $a=$wpdb->get_row($wpdb->prepare("SELECT ja.*,j.job_no,j.target_qty,ji.qty target_item_qty, v.name variant_name FROM ".PK01_DB::t('job_assignments')." ja JOIN ".PK01_DB::t('jobs')." j ON j.id=ja.job_id LEFT JOIN ".PK01_DB::t('job_items')." ji ON ji.job_id=j.id LEFT JOIN ".PK01_DB::t('product_variants')." v ON v.id=ji.variant_id WHERE ja.id=%d",(int)$assignment_id),ARRAY_A);
        if(!$a) return 0;
        $e=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('employees')." WHERE id=%d",(int)$a['employee_id']),ARRAY_A); if(!$e) return 0;
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_wages')." WHERE job_id=%d AND employee_id=%d AND status IN ('pending','partial') ORDER BY id DESC LIMIT 1",(int)$a['job_id'],(int)$a['employee_id']),ARRAY_A);
        $rate=0; $unit='job'; $job_name=$a['variant_name']?:'Job Produksi';
        $pr=PK01_DB::t('employee_piece_rates');
        if($pr) {
            $rate_row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$pr}` WHERE employee_id=%d AND rate>0 ORDER BY CASE WHEN job_name=%s THEN 0 WHEN job_name='' THEN 1 ELSE 2 END,id DESC LIMIT 1",(int)$a['employee_id'],$job_name),ARRAY_A);
            if($rate_row){$rate=(float)$rate_row['rate'];$unit=sanitize_text_field($rate_row['unit']?:'job');}
        }
        if($rate<=0 && ($e['pay_type']??'')==='piece' && (float)($e['rate']??0)>0){$rate=(float)$e['rate'];$unit='job';}
        if($rate<=0) return 0; // Never invent a wage rate.
        $qty=(stripos($unit,'pcs')!==false || stripos($unit,'unit')!==false || stripos($unit,'buah')!==false) ? max(1,(float)$good_qty) : 1;
        $amount=round($qty*$rate,2);
        if($existing) {
            $paid=(float)($existing['paid_amount']??0);
            if($paid>0) return (int)$existing['id'];
            $wpdb->update(PK01_DB::t('job_wages'),['qty'=>$qty,'unit'=>$unit,'rate'=>$rate,'amount'=>$amount,'balance_amount'=>$amount,'job_detail'=>$job_name,'period_key'=>current_time('Y-m')],['id'=>(int)$existing['id']]);
            self::log('job_wage_auto_update','job_wages','job_wage',(string)$existing['id'],null,['amount'=>$amount]);
            return (int)$existing['id'];
        }
        return self::create_job_wage((int)$a['job_id'],(int)$a['employee_id'],$job_name,$qty,$rate,$unit,current_time('Y-m'),'pending','Transfer Bank','Dibuat otomatis setelah pekerja melaporkan hasil Job.');
    }

    /** Koreksi pemakaian/kembali bahan tanpa mengubah jumlah bahan yang sudah diserahkan. */
    public static function edit_job_material_usage($job_material_id,$new_used_qty,$new_returned_qty,$notes='') {
        global $wpdb;
        $id=(int)$job_material_id; $used=max(0,(float)$new_used_qty); $ret=max(0,(float)$new_returned_qty);
        $t=PK01_DB::t('job_materials');
        $wpdb->query('START TRANSACTION');
        try {
            $m=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$m) throw new Exception('Bahan Job tidak ditemukan.');
            if($used+$ret>(float)$m['issued_qty']+0.000001) throw new Exception('Pemakaian + pengembalian tidak boleh melebihi bahan yang diserahkan.');
            $delta=$ret-(float)$m['returned_qty'];
            $unit_cost=(float)($m['unit_cost']??0);
            if($unit_cost<=0){
                $unit_cost=(float)$wpdb->get_var($wpdb->prepare("SELECT cost FROM ".PK01_DB::t('materials')." WHERE id=%d",(int)$m['material_id']));
            }
            $wpdb->update($t,['used_qty'=>$used,'returned_qty'=>$ret,'unit_cost'=>$unit_cost,'issued_value'=>round((float)$m['issued_qty']*$unit_cost,2),'consumed_cost'=>round($used*$unit_cost,2),'returned_value'=>round($ret*$unit_cost,2),'used_at'=>$used>0?self::now():null,'returned_at'=>$ret>0?self::now():null,'notes'=>$notes!==''?sanitize_textarea_field($notes):$m['notes']],['id'=>$id]);
            if(abs($delta)>0.000001) {
                $wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('materials')." SET stock=stock+%f WHERE id=%d",$delta,(int)$m['material_id']));
                $wpdb->insert(PK01_DB::t('stock_transactions'),['stock_type'=>'material','item_id'=>(int)$m['material_id'],'material_id'=>(int)$m['material_id'],'qty'=>abs($delta),'direction'=>$delta>0?'in':'out','reference_type'=>'job_material_edit','reference_id'=>$id,'reference_no'=>'JM-'.$id,'notes'=>'Koreksi pengembalian bahan Job','created_by'=>get_current_user_id(),'created_at'=>self::now()]);
            }
            $wpdb->query('COMMIT');
            self::log('job_material_edited','production','job_material',(string)$id,null,['old_used'=>(float)$m['used_qty'],'new_used'=>$used,'old_returned'=>(float)$m['returned_qty'],'new_returned'=>$ret]);
        } catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
        return true;
    }

    /** Pembayaran upah job bertahap; setiap cicilan masuk biaya + kas hanya sebesar yang benar-benar dibayar. */
    public static function pay_job_wage_partial($id,$amount,$payment_method='',$notes='') {
        global $wpdb;
        $id=(int)$id; $amount=round((float)$amount,2); if($id<=0||$amount<=0) throw new Exception('Nominal pembayaran tidak valid.');
        $t=PK01_DB::t('job_wages'); $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d FOR UPDATE",$id),ARRAY_A);
        if(!$r || in_array($r['status'],['paid','cancelled'],true)) throw new Exception('Upah tidak tersedia untuk pembayaran.');
        if(class_exists('PK01_Workflow')) PK01_Workflow::assert_transition('wage',$r['status'],((float)($r['amount']??0)-(float)($r['paid_amount']??0)-$amount)<=0.000001?'paid':'partial');
        $paid=(float)($r['paid_amount']??0); $balance=max(0,(float)$r['amount']-$paid);
        if($amount>$balance+0.000001) throw new Exception('Pembayaran melebihi sisa upah.');
        $method=sanitize_text_field($payment_method?:($r['payment_method']?:'Transfer Bank')); $ref='UPJ-'.$id.'-'.time();
        $wpdb->query('START TRANSACTION');
        try {
            $new_paid=round($paid+$amount,2); $new_balance=max(0,round((float)$r['amount']-$new_paid,2)); $status=$new_balance<=0.000001?'paid':'partial';
            $wpdb->insert(PK01_DB::t('job_wage_payments'),['job_wage_id'=>$id,'amount'=>$amount,'payment_method'=>$method,'reference_no'=>$ref,'paid_at'=>self::now(),'notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id()]);
            if(!$wpdb->insert_id) throw new Exception('Riwayat pembayaran upah gagal disimpan.');
            $wpdb->update($t,['paid_amount'=>$new_paid,'balance_amount'=>$new_balance,'status'=>$status,'paid_at'=>current_time('Y-m-d'),'reference_no'=>$ref,'payment_method'=>$method],['id'=>$id]);
            $wpdb->insert(PK01_DB::t('operational_costs'),['cost_date'=>current_time('Y-m-d'),'category'=>'Upah Pekerjaan','amount'=>$amount,'payment_method'=>$method,'reference_no'=>$ref,'description'=>'Pembayaran upah job #'.$id.' ('.$r['job_detail'].')','created_by'=>get_current_user_id(),'created_at'=>self::now()]);
            self::cash('out',$amount,'Upah Pekerjaan','job_wage',(int)$id,'Pembayaran upah job #'.$id,$method,$ref);
            $wpdb->query('COMMIT');
            self::log('job_wage_payment','job_wage_payments','job_wage',(string)$id,null,['amount'=>$amount,'paid_total'=>$new_paid,'balance'=>$new_balance,'reference_no'=>$ref]); if(class_exists('PK01_Kernel')) PK01_Kernel::event('wage_paid','finance','job_wage',$id,['amount'=>$amount,'paid_total'=>$new_paid,'balance'=>$new_balance,'status'=>$status,'reference_no'=>$ref]);
        } catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
        return true;
    }

    public static function edit_job_wage($id,$job_detail,$qty,$rate,$unit,$period_key,$notes='') {
        global $wpdb; $id=(int)$id; $qty=max(0,(float)$qty); $rate=max(0,(float)$rate);
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_wages')." WHERE id=%d",$id),ARRAY_A);
        if(!$r) throw new Exception('Upah Job tidak ditemukan.');
        if((float)($r['paid_amount']??0)>0 || in_array($r['status'],['partial','paid'],true)) throw new Exception('Upah yang sudah dibayar tidak boleh diubah nominalnya. Buat koreksi pembayaran/akuntansi agar histori tetap utuh.');
        if($qty<=0 || $rate<0) throw new Exception('Qty dan tarif tidak valid.');
        $amount=round($qty*$rate,2); $wpdb->update(PK01_DB::t('job_wages'),['job_detail'=>sanitize_text_field($job_detail),'qty'=>$qty,'rate'=>$rate,'unit'=>sanitize_text_field($unit?:'job'),'amount'=>$amount,'balance_amount'=>$amount,'period_key'=>sanitize_text_field($period_key?:current_time('Y-m')),'notes'=>sanitize_textarea_field($notes)],['id'=>$id]);
        self::log('job_wage_edit','job_wages','job_wage',(string)$id,null,['amount'=>$amount]); return true;
    }

    /** Upah pekerjaan/job terpisah dari gaji bulanan. Hanya pembayaran final yang mengurangi kas. */
    public static function create_job_wage($job_id,$employee_id,$job_detail,$qty=1,$rate=0,$unit='job',$period_key='',$status='pending',$payment_method='Transfer Bank',$notes='') {
        global $wpdb;
        $job_id=(int)$job_id; $employee_id=(int)$employee_id; $qty=max(0,(float)$qty); $rate=max(0,(float)$rate);
        if(!$job_id || !$employee_id || !$job_detail || $qty<=0 || $rate<0) throw new Exception('Data upah job belum lengkap.');
        $t=PK01_DB::t('job_wages'); $amount=round($qty*$rate,2); $period_key=$period_key?:current_time('Y-m');
        self::guard_entry('job_wage', (int)$job_id.'|'.(int)$employee_id.'|'.md5(sanitize_text_field($job_detail)).'|'.sanitize_text_field($period_key), ['job_id'=>$job_id,'employee_id'=>$employee_id,'period_key'=>$period_key,'amount'=>$amount]);
        $wpdb->insert($t,[
            'job_id'=>$job_id,'employee_id'=>$employee_id,'job_detail'=>sanitize_text_field($job_detail),'qty'=>$qty,'unit'=>sanitize_text_field($unit?:'job'),'rate'=>$rate,'amount'=>$amount,
            'period_key'=>sanitize_text_field($period_key),'status'=>in_array($status,['pending','partial','paid','cancelled'],true)?$status:'pending','paid_amount'=>($status==='paid'?$amount:0),'balance_amount'=>($status==='paid'?0:$amount),'payment_method'=>sanitize_text_field($payment_method?:'Transfer Bank'),
            'notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id(),'created_at'=>self::now()
        ]);
        if(!$wpdb->insert_id) { if(class_exists('PK01_Duplicate_Guard')) PK01_Duplicate_Guard::release('job_wage',(int)$job_id.'|'.(int)$employee_id.'|'.md5(sanitize_text_field($job_detail)).'|'.sanitize_text_field($period_key)); throw new Exception($wpdb->last_error?:'Upah job gagal disimpan.'); }
        $id=(int)$wpdb->insert_id; self::log('job_wage_create','job_wages','job_wage',(string)$id,null,['job_id'=>$job_id,'employee_id'=>$employee_id,'amount'=>$amount]);
        return $id;
    }

    public static function pay_job_wage($id) {
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_wages')." WHERE id=%d",(int)$id),ARRAY_A);
        if(!$r) throw new Exception('Upah job tidak ditemukan.');
        $balance=max(0,(float)$r['amount']-(float)($r['paid_amount']??0));
        if($balance<=0) throw new Exception('Upah job sudah lunas.');
        return self::pay_job_wage_partial((int)$id,$balance,$r['payment_method']?:'Transfer Bank','Pembayaran lunas.');
    }

    /** Membuat aset investasi; pembelian mengurangi kas, bukan laba. */
    public static function create_fixed_asset($code,$name,$category,$purchase_date,$cost,$residual=0,$annual_rate=0,$useful_life_months=0,$payment_method='Transfer Bank',$notes='') {
        global $wpdb; $cost=max(0,(float)$cost); $residual=max(0,(float)$residual); $annual_rate=max(0,(float)$annual_rate);
        if(!$code || !$name || $cost<=0) throw new Exception('Kode, nama aset dan nilai pembelian wajib diisi.');
        if($residual>$cost) throw new Exception('Nilai residu tidak boleh melebihi harga perolehan.');
        if($useful_life_months<=0 && $annual_rate>0) $useful_life_months=(int)ceil(100/$annual_rate*12);
        if($useful_life_months<=0) throw new Exception('Isi umur manfaat atau persentase penyusutan tahunan.');
        $t=PK01_DB::t('fixed_assets');
        $wpdb->insert($t,['asset_code'=>sanitize_text_field($code),'name'=>sanitize_text_field($name),'category'=>sanitize_text_field($category?:'Alat Kerja'),'purchase_date'=>sanitize_text_field($purchase_date?:current_time('Y-m-d')),'purchase_cost'=>$cost,'residual_value'=>$residual,'useful_life_months'=>$useful_life_months,'annual_rate'=>$annual_rate,'status'=>'active','created_by'=>get_current_user_id(),'created_at'=>self::now()]);
        if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Aset gagal disimpan.');
        $id=(int)$wpdb->insert_id;
        self::cash('out',$cost,'Pembelian Aset Tetap','fixed_asset',$id,'Pembelian aset '.$name,$payment_method?:'Transfer Bank','AST-'.str_pad((string)$id,6,'0',STR_PAD_LEFT));
        self::log('fixed_asset_create','fixed_assets','fixed_asset',(string)$id,null,['cost'=>$cost,'category'=>$category,'annual_rate'=>$annual_rate]);
        return $id;
    }

    /**
     * Komponen kompensasi berulang per karyawan. Sumber aturan; bukan pembayaran.
     */
    public static function save_employee_compensation_rule($employee_id,$component_code,$component_name,$component_type='earning',$calculation_type='fixed_monthly',$amount=0,$active=1,$start_period='',$end_period='',$notes='') {
        global $wpdb;
        $employee_id=absint($employee_id); $code=sanitize_key($component_code); $name=sanitize_text_field($component_name);
        $type=in_array($component_type,['earning','deduction'],true)?$component_type:'earning';
        $calc=in_array($calculation_type,['fixed_monthly','per_day','per_attendance'],true)?$calculation_type:'fixed_monthly';
        $amount=round((float)$amount,2); if($employee_id<=0||$code===''||$name===''||$amount<0) throw new Exception('Aturan kompensasi tidak valid.');
        $e=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".PK01_DB::t('employees')." WHERE id=%d AND status='active'",$employee_id)); if(!$e) throw new Exception('Karyawan aktif tidak ditemukan.');
        $t=PK01_DB::t('employee_compensation_rules');
        $data=['employee_id'=>$employee_id,'component_code'=>$code,'component_name'=>$name,'component_type'=>$type,'calculation_type'=>$calc,'amount'=>$amount,'active'=>$active?1:0,'start_period'=>$start_period?sanitize_text_field($start_period):null,'end_period'=>$end_period?sanitize_text_field($end_period):null,'notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id(),'updated_at'=>self::now()];
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE employee_id=%d AND component_code=%s",$employee_id,$code));
        if($existing){$wpdb->update($t,$data,['id'=>(int)$existing]);$id=(int)$existing;$action='employee_compensation_updated';}else{$data['created_at']=self::now();$wpdb->insert($t,$data);$id=(int)$wpdb->insert_id;$action='employee_compensation_created';}
        if(!$id) throw new Exception($wpdb->last_error?:'Aturan kompensasi gagal disimpan.');
        self::log($action,'hr','employee_compensation_rule',(string)$id,null,$data); return $id;
    }

    public static function create_payroll($employee_id,$period,$status='paid',$payment_method='Transfer Bank',$description='',$manual_components=[]) {
        global $wpdb;
        $employee_id=absint($employee_id); $period=sanitize_text_field($period); $status=in_array($status,['paid','pending'],true)?$status:'paid';
        if($employee_id<=0 || !preg_match('/^\d{4}-\d{2}$/',$period)) throw new Exception('Karyawan dan periode payroll wajib valid.');
        $emp=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('employees')." WHERE id=%d AND status='active'",$employee_id),ARRAY_A); if(!$emp) throw new Exception('Karyawan aktif tidak ditemukan.');
        // Satu payroll utama per karyawan/periode. Status bukan bagian dari uniqueness agar pending+paid tidak menjadi dua payroll.
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".PK01_DB::t('payroll')." WHERE employee_id=%d AND period=%s LIMIT 1",$employee_id,$period));
        if($existing) throw new Exception('Payroll karyawan untuk periode '.$period.' sudah ada. Gunakan record yang sama untuk pembayaran/koreksi; jangan membuat payroll kedua.');
        $earn=[]; $ded=[]; $base=($emp['pay_type']??'')==='monthly'?max(0,(float)$emp['rate']):0;
        if($base>0)$earn[]=['code'=>'gaji_pokok','name'=>'Gaji Pokok','type'=>'earning','amount'=>$base,'source_type'=>'employee_master','source_id'=>$employee_id];
        $rules=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".PK01_DB::t('employee_compensation_rules')." WHERE employee_id=%d AND active=1 AND (start_period IS NULL OR start_period='' OR start_period<=%s) AND (end_period IS NULL OR end_period='' OR end_period>=%s) ORDER BY id",$employee_id,$period,$period),ARRAY_A)?:[];
        foreach($rules as $r){$amt=(float)$r['amount']; if(($r['calculation_type']??'fixed_monthly')!=='fixed_monthly'){ $amt=(float)$r['amount']; } if($amt<=0)continue; $item=['code'=>sanitize_key($r['component_code']),'name'=>$r['component_name'],'type'=>$r['component_type'],'amount'=>$amt,'source_type'=>'compensation_rule','source_id'=>(int)$r['id'],'notes'=>$r['notes']??'']; if($r['component_type']==='deduction')$ded[]=$item;else$earn[]=$item;}
        if(is_array($manual_components))foreach($manual_components as $c){$amt=round((float)($c['amount']??0),2);$name=sanitize_text_field($c['name']??'');$code=sanitize_key($c['code']??$name);$type=($c['type']??'earning')==='deduction'?'deduction':'earning';if($name!==''&&$amt>0){$item=['code'=>$code,'name'=>$name,'type'=>$type,'amount'=>$amt,'source_type'=>'manual','source_id'=>0,'notes'=>sanitize_textarea_field($c['notes']??'')];if($type==='deduction')$ded[]=$item;else$earn[]=$item;}}
        // Gabungkan kode yang sama agar satu komponen tidak menggandakan nominal.
        $merge=function($items){$out=[];foreach($items as $x){$k=$x['code'];if(!isset($out[$k]))$out[$k]=$x;else{$out[$k]['amount']+=(float)$x['amount'];$out[$k]['name']=$x['name'];}}return array_values($out);};$earn=$merge($earn);$ded=$merge($ded);
        $gross=array_sum(array_map(function($x){return (float)$x['amount'];},$earn));$ded_total=array_sum(array_map(function($x){return (float)$x['amount'];},$ded));$net=round(max(0,$gross-$ded_total),2);if($gross<=0)throw new Exception('Gaji pokok/komponen pendapatan belum dikonfigurasi untuk karyawan ini.');
        self::guard_entry('payroll',$employee_id.'|'.$period,['employee_id'=>$employee_id,'period'=>$period,'net'=>$net]);
        $t=PK01_DB::t('payroll'); $payroll_no=self::document_number('payroll'); $wpdb->insert($t,['employee_id'=>$employee_id,'name'=>$emp['name'],'period'=>$period,'amount'=>$net,'gross_amount'=>$gross,'deduction_amount'=>$ded_total,'payment_method'=>sanitize_text_field($payment_method?:'Transfer Bank'),'reference_no'=>$payroll_no,'status'=>$status,'paid_at'=>$status==='paid'?current_time('Y-m-d'):null,'description'=>sanitize_textarea_field($description),'created_at'=>self::now()]);$id=(int)$wpdb->insert_id;if(!$id){if(class_exists('PK01_Duplicate_Guard'))PK01_Duplicate_Guard::release('payroll',$employee_id.'|'.$period);throw new Exception($wpdb->last_error?:'Payroll gagal disimpan.');}
        $tc=PK01_DB::t('payroll_components');foreach(array_merge($earn,$ded) as $c){$wpdb->insert($tc,['payroll_id'=>$id,'component_code'=>$c['code'],'component_name'=>$c['name'],'component_type'=>$c['type'],'amount'=>round((float)$c['amount'],2),'source_type'=>$c['source_type'],'source_id'=>(int)$c['source_id'],'notes'=>$c['notes']??'','created_by'=>get_current_user_id(),'created_at'=>self::now()]);if(!$wpdb->insert_id)throw new Exception($wpdb->last_error?:'Komponen payroll gagal disimpan.');}
        if($status==='paid'){self::cash('out',$net,'Gaji & Upah','payroll',$id,'Pembayaran payroll '.$emp['name'].' '.$period,$payment_method,$payroll_no);}
        self::log('payroll_created','finance','payroll',(string)$id,null,['employee_id'=>$employee_id,'period'=>$period,'gross'=>$gross,'deductions'=>$ded_total,'net'=>$net,'components'=>count($earn)+count($ded)]);return ['id'=>$id,'gross'=>$gross,'deductions'=>$ded_total,'net'=>$net,'earnings'=>$earn,'deductions_detail'=>$ded];
    }

    public static function payroll_components($payroll_id){global $wpdb;$t=PK01_DB::t('payroll_components');return $wpdb->get_results($wpdb->prepare("SELECT * FROM `{$t}` WHERE payroll_id=%d ORDER BY component_type DESC,id",(int)$payroll_id),ARRAY_A)?:[];}

    /** Target seller/marketing berbasis penjualan aktual periode. Bonus hanya dibuat satu kali ketika target tercapai. */
    public static function set_seller_target($seller_account_id,$period,$target_amount,$bonus_type='fixed',$bonus_value=0,$participant_type='seller'){
        global $wpdb;
        $role=class_exists('PK01_Authorization')?PK01_Authorization::effective_role():'';
        if(!current_user_can('manage_options') && !in_array($role,['pk01_admin','pk01_keuangan','shop_manager'],true)) throw new Exception('Hanya Administrator/Admin Operasional/Keuangan/Manajer Toko yang dapat menetapkan target penjualan.');$seller_account_id=absint($seller_account_id);$period=sanitize_text_field($period);$target_amount=round((float)$target_amount,2);$bonus_type=in_array($bonus_type,['fixed','percent'],true)?$bonus_type:'fixed';$bonus_value=round((float)$bonus_value,2);$participant_type=in_array($participant_type,['seller','marketing'],true)?$participant_type:'seller';
        if($seller_account_id<=0||!preg_match('/^\d{4}-\d{2}$/',$period)||$target_amount<=0||$bonus_value<0)throw new Exception('Target penjualan/bonus tidak valid.');
        $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".PK01_DB::t('sales_accounts')." WHERE id=%d AND active=1",$seller_account_id));if(!$exists)throw new Exception('Mitra seller/marketing aktif tidak ditemukan.');
        $t=PK01_DB::t('seller_targets');$data=['seller_account_id'=>$seller_account_id,'participant_type'=>$participant_type,'period_key'=>$period,'target_amount'=>$target_amount,'bonus_type'=>$bonus_type,'bonus_value'=>$bonus_value,'status'=>'active','created_by'=>get_current_user_id(),'updated_at'=>self::now()];$id=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE seller_account_id=%d AND participant_type=%s AND period_key=%s",$seller_account_id,$participant_type,$period));if($id)$wpdb->update($t,$data,['id'=>(int)$id]);else{$data['created_at']=self::now();$wpdb->insert($t,$data);$id=$wpdb->insert_id;}if(!$id)throw new Exception($wpdb->last_error?:'Target seller gagal disimpan.');self::log('seller_target_saved','sales','seller_target',(string)$id,null,$data);self::evaluate_seller_target_bonus((int)$id);return (int)$id;
    }

    public static function evaluate_seller_target_bonus($target_id){global $wpdb;$tt=PK01_DB::t('seller_targets');$t=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tt}` WHERE id=%d AND status='active'",(int)$target_id),ARRAY_A);if(!$t)return 0;$period=$t['period_key'];$start=$period.'-01';$end=date('Y-m-t',strtotime($start));if(($t['participant_type']??'seller')==='marketing'){$ts=PK01_DB::t('seller_affiliate_ledger');$sales=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(base_amount),0) FROM `{$ts}` WHERE seller_account_id=%d AND created_at BETWEEN %s AND %s AND status IN ('pending','ready','paid','approved')",(int)$t['seller_account_id'],$start.' 00:00:00',$end.' 23:59:59'));}else{$ts=PK01_DB::t('seller_sales');$sales=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM `{$ts}` WHERE seller_account_id=%d AND sold_at BETWEEN %s AND %s",(int)$t['seller_account_id'],$start.' 00:00:00',$end.' 23:59:59'));}if($sales+0.000001<(float)$t['target_amount'])return 0;$bonus=$t['bonus_type']==='percent'?round($sales*((float)$t['bonus_value']/100),2):round((float)$t['bonus_value'],2);if($bonus<=0)return 0;$tb=PK01_DB::t('seller_bonus_ledger');$existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$tb}` WHERE target_id=%d",(int)$target_id));if($existing)return (int)$existing;$wpdb->insert($tb,['target_id'=>(int)$target_id,'seller_account_id'=>(int)$t['seller_account_id'],'period_key'=>$period,'sales_amount'=>$sales,'target_amount'=>$t['target_amount'],'bonus_amount'=>$bonus,'status'=>'earned','reference_no'=>self::document_number('seller_bonus'),'created_by'=>get_current_user_id(),'created_at'=>self::now()]);$id=(int)$wpdb->insert_id;if(!$id)throw new Exception($wpdb->last_error?:'Bonus target gagal dicatat.');self::log('seller_target_bonus_earned','finance','seller_bonus',(string)$id,null,['target_id'=>$target_id,'sales_amount'=>$sales,'bonus_amount'=>$bonus]);return $id;}

    public static function pay_seller_target_bonus($bonus_id){global $wpdb;$role=class_exists('PK01_Authorization')?PK01_Authorization::effective_role():'';if(!current_user_can('manage_options') && !in_array($role,['pk01_admin','pk01_keuangan'],true)) throw new Exception('Hanya Administrator/Admin Operasional/Keuangan yang dapat membayar bonus target.');$t=PK01_DB::t('seller_bonus_ledger');$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",(int)$bonus_id),ARRAY_A);if(!$r)throw new Exception('Bonus target tidak ditemukan.');if($r['status']==='paid')throw new Exception('Bonus target sudah dibayarkan.');if($r['status']!=='earned')throw new Exception('Bonus target belum berhak dibayar.');$amount=(float)$r['bonus_amount'];if($amount<=0)throw new Exception('Nominal bonus tidak valid.');self::guard_entry('seller_target_bonus_payment',(int)$bonus_id.'|'.number_format($amount,2,'.',''),['bonus_id'=>(int)$bonus_id,'amount'=>$amount]);self::cash('out',$amount,'Bonus Target Penjualan','seller_target_bonus',(int)$bonus_id,'Pembayaran bonus target penjualan','Kas Tunai Toko',$r['reference_no']);$wpdb->update($t,['status'=>'paid','paid_at'=>self::now()],['id'=>(int)$bonus_id]);self::log('seller_target_bonus_paid','finance','seller_bonus',(string)$bonus_id,null,['amount'=>$amount]);return $amount;}

    public static function pay_payroll($id) {
        global $wpdb;
        $t = PK01_DB::t('payroll');
        $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d", $id), ARRAY_A);
        if (!$r || $r['status'] === 'paid') throw new Exception('Catatan payroll tidak ditemukan atau sudah dibayarkan.');

        $wpdb->update($t, ['status' => 'paid', 'paid_at' => current_time('Y-m-d')], ['id' => $id]);
        self::cash('out', $r['amount'], 'Gaji & Upah', 'payroll', $id, 'Pembayaran payroll: ' . ($r['name'] ?: 'Karyawan ID ' . $r['employee_id']));
        return true;
    }



    public static function role_label($role) {
        $map=['administrator'=>'Administrator','pk01_admin'=>'Admin Operasional','shop_manager'=>'Manajer Toko',
              'pk01_sales'=>'Sales','pk01_seller'=>'Mitra Seller','pk01_worker'=>'Karyawan Produksi',
              'pk01_employee'=>'Pengguna Job Produksi','pk01_gudang'=>'Admin Gudang','pk01_produksi'=>'Admin Produksi',
              'pk01_kasir'=>'Kasir & Penjualan','pk01_keuangan'=>'Admin Keuangan','pk01_hr'=>'Admin SDM',
              'pk01_logistik'=>'Admin Logistik','pk01_packing'=>'Admin Packing','pk01_owner'=>'Pemilik / Owner','subscriber'=>'Pengguna'];
        return $map[$role] ?? ucwords(str_replace(['_','-'],' ',$role));
    }

    public static function save_customer($id,$name,$phone='',$email='',$user_id=0) {
        global $wpdb;
        $name=sanitize_text_field($name); if($name==='') throw new Exception('Nama pelanggan wajib diisi.');
        $data=['name'=>$name,'phone'=>sanitize_text_field($phone),'email'=>sanitize_email($email),'user_id'=>(int)$user_id,'status'=>'active'];
        $t=PK01_DB::t('customers');
        if($id) $wpdb->update($t,$data,['id'=>(int)$id]); else { $data['code']='CUS-'.current_time('Ymd').'-'.wp_rand(100,999); $data['created_at']=self::now(); $wpdb->insert($t,$data); $id=$wpdb->insert_id; }
        return (int)$id;
    }

    public static function save_supplier($id,$code,$name,$contact='',$status='active') {
        global $wpdb;
        $name=sanitize_text_field($name); if($name==='') throw new Exception('Nama pemasok wajib diisi.');
        $status=in_array($status,['active','inactive'],true)?$status:'active';
        $t=PK01_DB::t('suppliers');
        $data=['code'=>sanitize_text_field($code),'name'=>$name,'contact'=>sanitize_text_field($contact),'status'=>$status];
        if($id){$data['created_at']=self::now(); $wpdb->update($t,$data,['id'=>(int)$id]);}
        else{$data['created_at']=self::now();$wpdb->insert($t,$data);$id=$wpdb->insert_id;}
        return (int)$id;
    }

    public static function add_product_image($product_id,$attachment_id,$type='additional') {
        global $wpdb;
        $product_id=(int)$product_id;$attachment_id=(int)$attachment_id;
        if($product_id<=0||$attachment_id<=0) throw new Exception('Produk/gambar tidak valid.');
        $t=PK01_DB::t('product_gallery');
        $wpdb->insert($t,['product_id'=>$product_id,'attachment_id'=>$attachment_id,'sort_order'=>$type==='main'?0:99,'created_at'=>self::now()]);
        if($type==='main') $wpdb->update(PK01_DB::t('products'),['image_id'=>$attachment_id,'updated_at'=>self::now()],['id'=>$product_id]);
        return (int)$wpdb->insert_id;
    }

    public static function adjust_stock($type,$variant_id,$qty,$reason='') {
        global $wpdb;
        $type=in_array($type,['finished','damaged'],true)?$type:'finished';
        $variant_id=(int)$variant_id;$qty=(float)$qty;
        if($variant_id<=0||$qty==0) throw new Exception('SKU dan jumlah stok wajib valid.');
        $v=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('product_variants')." WHERE id=%d FOR UPDATE",$variant_id),ARRAY_A);
        if(!$v) throw new Exception('SKU tidak ditemukan.');
        $direction=$qty>0?'in':'out';$abs=abs($qty);
        if($direction==='out' && (float)$v['stock']+0.000001<$abs) throw new Exception('Penyesuaian keluar melebihi stok tersedia.');
        $wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('product_variants')." SET stock=stock+%f,updated_at=%s WHERE id=%d",$qty,self::now(),$variant_id));
        $wpdb->insert(PK01_DB::t('stock_transactions'),[
            'stock_type'=>$type,'item_id'=>$variant_id,'variant_id'=>$variant_id,'qty'=>$abs,'direction'=>$direction,
            'reference_type'=>'adjustment','reference_id'=>0,'notes'=>sanitize_textarea_field($reason),'created_by'=>get_current_user_id(),'created_at'=>self::now()
        ]);
        do_action('pk01_stock_changed', $variant_id, $qty, $direction, 'adjustment');
        return true;
    }

    /** Resolve retur hanya dari nomor resi/order yang sudah ada; tidak membuat transaksi penjualan baru. */
    public static function create_return_by_tracking($tracking_no,$variant_id,$qty,$reason='') {
        global $wpdb;
        $tracking=sanitize_text_field($tracking_no); $variant_id=absint($variant_id); $qty=(float)$qty;
        if($tracking===''||$variant_id<=0||$qty<=0) throw new Exception('Resi, SKU, dan qty retur wajib valid.');
        $seller_sale_id=(int)$wpdb->get_var($wpdb->prepare("SELECT ss.id FROM `".PK01_DB::t('seller_sales')."` ss WHERE ss.tracking_no=%s AND ss.variant_id=%d AND COALESCE(ss.source_type,'seller_order')<>'return_adjustment' ORDER BY ss.id DESC LIMIT 1",$tracking,$variant_id));
        if($seller_sale_id>0){
            $ss=$wpdb->get_row($wpdb->prepare("SELECT * FROM `".PK01_DB::t('seller_sales')."` WHERE id=%d",$seller_sale_id),ARRAY_A);
            return self::create_return('seller_order',(int)$ss['order_id'],$variant_id,$qty,$reason,$tracking);
        }
        $sale_id=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM `".PK01_DB::t('sales_orders')."` WHERE tracking_no=%s ORDER BY id DESC LIMIT 1",$tracking));
        if($sale_id>0) return self::create_return('sales_order',$sale_id,$variant_id,$qty,$reason,$tracking);
        $shipment=$wpdb->get_row($wpdb->prepare("SELECT * FROM `".PK01_DB::t('shipments')."` WHERE tracking_no=%s ORDER BY id DESC LIMIT 1",$tracking),ARRAY_A);
        if($shipment && !empty($shipment['seller_sale_id'])){
            $ss=$wpdb->get_row($wpdb->prepare("SELECT * FROM `".PK01_DB::t('seller_sales')."` WHERE id=%d",(int)$shipment['seller_sale_id']),ARRAY_A);
            if($ss) return self::create_return('seller_order',(int)$ss['order_id'],$variant_id,$qty,$reason,$tracking);
        }
        if($shipment && !empty($shipment['sale_id'])) return self::create_return('sales_order',(int)$shipment['sale_id'],$variant_id,$qty,$reason,$tracking);
        throw new Exception('Resi belum terdaftar pada penjualan PK01. Retur tidak dibuat agar data tidak mengarang.');
    }

    public static function create_return($source,$ref_id,$variant_id,$qty,$reason='',$tracking_no='') {
        global $wpdb;
        $qty=(float)$qty;if($qty<=0||$variant_id<=0) throw new Exception('Data retur tidak valid.');
        $order_id=$source==='sales_order'?(int)$ref_id:0;
        $seller_order_id=$source==='seller_order'?(int)$ref_id:0;
        if ($order_id<=0 && $seller_order_id<=0) throw new Exception('Retur wajib terhubung ke order penjualan nyata.');
        $order=$order_id>0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('sales_orders')." WHERE id=%d",$order_id),ARRAY_A) : null;
        $seller_order=$seller_order_id>0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('seller_orders')." WHERE id=%d AND status NOT IN ('cancelled','failed')",$seller_order_id),ARRAY_A) : null;
        if ($order_id>0 && !$order) throw new Exception('Order penjualan untuk retur tidak ditemukan.');
        if ($seller_order_id>0 && !$seller_order) throw new Exception('Order Seller untuk retur tidak ditemukan.');
        if (in_array(strtolower((string)($order['status'] ?? '')), ['cancelled','failed'], true)) throw new Exception('Order batal/gagal tidak dapat dibuatkan retur.');
        // Retur hanya boleh berasal dari unit yang benar-benar terjual pada order ini.
        $line=$order_id>0 ? $wpdb->get_row($wpdb->prepare("SELECT qty,unit_price,total FROM ".PK01_DB::t('sales_order_items')." WHERE order_id=%d AND variant_id=%d ORDER BY id ASC LIMIT 1",$order_id,(int)$variant_id),ARRAY_A) : null;
        if(!$line && $order_id>0){
            $line=$wpdb->get_row($wpdb->prepare("SELECT qty,price AS unit_price,total_amount AS total FROM ".PK01_DB::t('sales_orders')." WHERE id=%d AND variant_id=%d LIMIT 1",$order_id,(int)$variant_id),ARRAY_A);
        }
        if(!$line && $seller_order_id>0){
            $line=$wpdb->get_row($wpdb->prepare("SELECT qty,unit_price,total FROM ".PK01_DB::t('seller_order_items')." WHERE order_id=%d AND variant_id=%d ORDER BY id ASC LIMIT 1",$seller_order_id,(int)$variant_id),ARRAY_A);
        }
        if(!$line) throw new Exception('SKU retur tidak ditemukan pada item order penjualan asli.');
        $sold_qty=max(0,(float)($line['qty']??0));
        $prior_return=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(ri.qty),0) FROM ".PK01_DB::t('returns')." r JOIN ".PK01_DB::t('return_items')." ri ON ri.return_id=r.id WHERE (r.order_id=%d OR r.seller_order_id=%d) AND ri.variant_id=%d AND r.status NOT IN ('cancelled')",$order_id,$seller_order_id,(int)$variant_id));
        if($qty+$prior_return>$sold_qty+0.000001) throw new Exception('Jumlah retur melebihi jumlah unit yang benar-benar terjual pada order.');
        $unit_price=max(0,(float)($line['unit_price']??0));
        if($unit_price<=0) throw new Exception('Harga unit order asli tidak ditemukan. Retur tidak dibuat agar data finansial tidak mengarang.');
        $no=self::document_number('return');
        $seller_name='';
        $seller_id=$seller_order_id>0?(int)($seller_order['seller_account_id']??0):(int)($order['affiliate_seller_id']??0);
        if($seller_id<=0 && $order_id>0) $seller_id=(int)($order['seller_id']??0);
        if($seller_id>0){
            $seller_name=(string)$wpdb->get_var($wpdb->prepare("SELECT name FROM ".PK01_DB::t('sales_accounts')." WHERE id=%d",$seller_id));
        }
        $wpdb->insert(PK01_DB::t('returns'),[
            'return_no'=>$no,'order_id'=>$order_id,'seller_order_id'=>$seller_order_id,'tracking_no'=>sanitize_text_field($tracking_no),'courier_name'=>'','seller_name'=>$seller_name,
            'customer_name'=>$order['customer_name']??($seller_order['marketplace_order_no']??''),
            'refund_amount'=>round($unit_price*$qty,2),'seller_account_id'=>$seller_id,'seller_name'=>$seller_name,'seller_unit_amount'=>0,'seller_adjustment_amount'=>0,'seller_ar_adjustment_status'=>'pending','seller_ar_adjusted_at'=>null,'status'=>'pending','qc_status'=>'waiting','reason'=>sanitize_textarea_field($reason),'created_at'=>self::now()
        ]);
        $rid=(int)$wpdb->insert_id;
        $wpdb->insert(PK01_DB::t('return_items'),['return_id'=>$rid,'variant_id'=>(int)$variant_id,'qty'=>$qty,'condition_status'=>'pending']);
        return $rid;
    }

    /**
     * Rekonsiliasi finansial seller saat unit retur benar-benar diterima Gudang.
     * Tidak membuat penjualan baru/dummy. Penjualan asli tetap utuh dan koreksi
     * dicatat sebagai baris negatif seller_sales + pengurang invoice AR.
     */
    public static function apply_return_to_seller_financials($return_id) {
        global $wpdb;
        $return_id=(int)$return_id;
        if($return_id<=0) throw new Exception('Referensi retur tidak valid.');
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('returns')." WHERE id=%d FOR UPDATE",$return_id),ARRAY_A);
        if(!$r) throw new Exception('Retur tidak ditemukan untuk rekonsiliasi seller.');
        if((float)($r['seller_adjustment_amount']??0)>0 && ($r['seller_ar_adjustment_status']??'')==='applied') return (float)$r['seller_adjustment_amount'];
        $order_id=(int)($r['order_id']??0); $seller_order_id=(int)($r['seller_order_id']??0); $seller_id=(int)($r['seller_account_id']??0);
        if($seller_id<=0 && $seller_order_id>0){
            $seller_id=(int)$wpdb->get_var($wpdb->prepare("SELECT seller_account_id FROM ".PK01_DB::t('seller_orders')." WHERE id=%d",$seller_order_id));
        }
        if($seller_id<=0 && $order_id>0){
            $seller_id=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(NULLIF(affiliate_seller_id,0),NULLIF(seller_id,0),0) FROM ".PK01_DB::t('sales_orders')." WHERE id=%d",$order_id));
        }
        if($seller_id<=0){
            $wpdb->update(PK01_DB::t('returns'),['seller_ar_adjustment_status'=>'not_applicable','seller_ar_adjusted_at'=>self::now()],['id'=>$return_id]);
            return 0.0;
        }
        $it=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('return_items')." WHERE return_id=%d ORDER BY id LIMIT 1",$return_id),ARRAY_A);
        if(!$it) throw new Exception('Detail barang retur tidak ditemukan.');
        $qty=max(0,(float)$it['qty']); if($qty<=0) throw new Exception('Jumlah unit retur tidak valid.');
        $unit=0.0;
        $ss=PK01_DB::t('seller_sales');
        $seller_lookup_order=$seller_order_id>0?$seller_order_id:$order_id;
        if($seller_lookup_order>0 && $ss){
            $unit=(float)$wpdb->get_var($wpdb->prepare("SELECT unit_price FROM `{$ss}` WHERE order_id=%d AND seller_account_id=%d AND variant_id=%d AND source_type NOT IN ('return','return_adjustment') ORDER BY id ASC LIMIT 1",$order_id,$seller_id,(int)$it['variant_id']));
        }
        if($unit<=0 && $order_id>0){
            $unit=(float)$wpdb->get_var($wpdb->prepare("SELECT price FROM ".PK01_DB::t('sales_orders')." WHERE id=%d",$order_id));
        }
        if($unit<=0) throw new Exception('Harga seller asli tidak ditemukan; koreksi tagihan dibatalkan agar angka tidak mengarang.');
        $adjustment=round($unit*$qty,2);
        $seller_name=(string)$wpdb->get_var($wpdb->prepare("SELECT name FROM ".PK01_DB::t('sales_accounts')." WHERE id=%d",$seller_id));
        $invoice_id=0; $invoice_total_before=0; $invoice_total_after=0; $credit_created=0;
        $invoice_lookup_order=$seller_order_id>0?$seller_order_id:$order_id;
        if($invoice_lookup_order>0){
            $invoice=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('seller_invoices')." WHERE order_id=%d AND seller_account_id=%d ORDER BY id ASC LIMIT 1 FOR UPDATE",$invoice_lookup_order,$seller_id),ARRAY_A);
            if($invoice){
                $invoice_id=(int)$invoice['id']; $invoice_total_before=(float)$invoice['total'];
                $already_adj=(float)($invoice['return_adjustment_total']??0);
                $new_adj=round($already_adj+$adjustment,2);
                $payments=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM ".PK01_DB::t('seller_payments')." WHERE invoice_id=%d",$invoice_id));
                $new_total=max($payments,round((float)($invoice['original_total']??$invoice['total'])-$new_adj,2));
                $invoice_total_after=$new_total;
                $status=$payments+0.01 >= $new_total ? 'paid' : ($payments>0?'partial':'unpaid');
                $wpdb->update(PK01_DB::t('seller_invoices'),['total'=>$new_total,'original_total'=>max((float)($invoice['original_total']??$invoice['total']),$invoice_total_before),'return_adjustment_total'=>$new_adj,'status'=>$status,'last_return_at'=>self::now(),'paid_at'=>$status==='paid'?($invoice['paid_at']?:self::now()):null],['id'=>$invoice_id]);
                if($payments>$new_total+0.01){
                    $credit=round($payments-$new_total,2);
                    $wpdb->insert(PK01_DB::t('seller_credit_ledger'),['seller_account_id'=>$seller_id,'return_id'=>$return_id,'invoice_id'=>$invoice_id,'amount'=>$credit,'status'=>'available','notes'=>'Kredit seller akibat retur setelah invoice sudah dibayar/terbayar.','created_by'=>get_current_user_id(),'created_at'=>self::now()]);
                    $credit_created=(int)$wpdb->insert_id;
                }
            }
        }
        // Baris negatif menjaga histori penjualan asli dan membuat omzet seller kembali secara matematis.
        if($ss){
            $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$ss}` WHERE return_id=%d AND source_type='return_adjustment' LIMIT 1",$return_id));
            if(!$existing){
                $cols=$wpdb->get_col("DESC `{$ss}`",0);
                $data=['seller_account_id'=>$seller_id,'order_id'=>$order_id,'variant_id'=>(int)$it['variant_id'],'qty'=>-$qty,'hpp'=>0,'unit_price'=>$unit,'total'=>-$adjustment,'sold_at'=>self::now(),'commission_amount'=>0,'status'=>'returned','source_type'=>'return_adjustment','return_id'=>$return_id];
                $data=array_intersect_key($data,array_flip($cols));
                $wpdb->insert($ss,$data);
            }
        }
        // Simpan identitas seller di retur agar seluruh laporan tidak perlu menebak ulang.
        $wpdb->update(PK01_DB::t('returns'),['seller_account_id'=>$seller_id,'seller_name'=>$seller_name,'seller_unit_amount'=>$unit,'seller_adjustment_amount'=>$adjustment,'seller_ar_adjustment_status'=>'applied','seller_ar_adjusted_at'=>self::now()],['id'=>$return_id]);
        self::log('seller_return_reconciled','finance','return',(string)$return_id,null,['seller_id'=>$seller_id,'seller_name'=>$seller_name,'adjustment'=>$adjustment,'invoice_id'=>$invoice_id,'invoice_before'=>$invoice_total_before,'invoice_after'=>$invoice_total_after,'credit_id'=>$credit_created],'Retur diterima Gudang mengurangi penjualan/tagihan Seller');
        return $adjustment;
    }

    /** Notifikasi retur yang sudah diterima Gudang. Email otomatis; WA disediakan sebagai link siap kirim bila gateway otomatis belum dikonfigurasi. */
    public static function notify_return_received($return_id) {
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT r.*,sa.email seller_email,sa.phone seller_phone,sa.name seller_name,ri.qty,v.sku,v.name product_name FROM ".PK01_DB::t('returns')." r LEFT JOIN ".PK01_DB::t('sales_accounts')." sa ON sa.id=r.seller_account_id LEFT JOIN ".PK01_DB::t('return_items')." ri ON ri.return_id=r.id LEFT JOIN ".PK01_DB::t('product_variants')." v ON v.id=ri.variant_id WHERE r.id=%d",(int)$return_id),ARRAY_A);
        if(!$r) return ['email'=>false,'whatsapp_url'=>''];
        $name=$r['seller_name']?:'Mitra Seller';
        $subject='Retur diterima Gudang - '.($r['return_no']??('RET-'.$return_id));
        $body="Halo {$name},\n\nBarang retur dengan nomor {$r['return_no']} telah diterima secara fisik oleh Gudang.\nResi: ".($r['tracking_no']?:'-')."\nBarang: ".($r['product_name']?:'-')." (SKU ".($r['sku']?:'-').")\nJumlah: ".((float)($r['qty']??0))." unit\nKoreksi tagihan/AR seller: Rp ".number_format((float)($r['seller_adjustment_amount']??0),0,',','.')."\nStatus: Menunggu QC Gudang.\n\nData seller dan tagihan PK01 telah disinkronkan otomatis.\n";
        $email_sent=!empty($r['seller_email'])?wp_mail($r['seller_email'],$subject,$body):false;
        $phone=preg_replace('/\\D+/','',(string)($r['seller_phone']??''));
        if(strpos($phone,'62')!==0 && $phone!=='') $phone='62'.ltrim($phone,'0');
        $wa=''; if($phone!=='') $wa='https://wa.me/'.$phone.'?text='.rawurlencode($body);
        return ['email'=>$email_sent,'whatsapp_url'=>$wa,'seller_name'=>$name];
    }

    public static function receive_and_qc_return($return_id,$condition='good') {
        global $wpdb;
        $condition=in_array($condition,['good','damaged','reject'],true)?$condition:'good';
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('returns')." WHERE id=%d AND status IN ('pending','warehouse_received')",(int)$return_id),ARRAY_A);
        $it=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('return_items')." WHERE return_id=%d LIMIT 1",(int)$return_id),ARRAY_A);
        if(!$r||!$it) throw new Exception('Retur tidak ditemukan.');
        if ((string)($r['status'] ?? '') !== 'warehouse_received') throw new Exception('Retur belum diterima secara fisik oleh Gudang. QC hanya boleh dilakukan setelah tanda terima retur.');
        $wpdb->update(PK01_DB::t('return_items'),['condition_status'=>$condition],['id'=>(int)$it['id']]);
        if($condition==='good'){
            $wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('product_variants')." SET stock=stock+%f WHERE id=%d",(float)$it['qty'],(int)$it['variant_id']));
            $stock_type='finished';
        } elseif($condition==='damaged'){
            $stock_type='damaged';
        } else $stock_type='return_reject';
        if($condition!=='reject'){
            $wpdb->insert(PK01_DB::t('stock_transactions'),[
                'stock_type'=>$stock_type,'item_id'=>(int)$it['variant_id'],'variant_id'=>(int)$it['variant_id'],
                'qty'=>(float)$it['qty'],'direction'=>'in','reference_type'=>'return','reference_id'=>(int)$return_id,
                'reference_no'=>$r['return_no'],'notes'=>'QC retur: '.$condition,'created_by'=>get_current_user_id(),'created_at'=>self::now()
            ]);
        }
        $wpdb->update(PK01_DB::t('returns'),['status'=>'completed','qc_status'=>$condition,'completed_at'=>self::now()],['id'=>(int)$return_id]);
        if(!empty($r['order_id'])) {
            $wpdb->update(PK01_DB::t('sales_orders'),['status'=>'refunded','shipping_status'=>'returned'],['id'=>(int)$r['order_id']]);
            if(class_exists('PK01_Affiliate') && method_exists('PK01_Affiliate','sync_commission_status')) PK01_Affiliate::sync_commission_status((int)$r['order_id']);
        }
        if((float)$r['refund_amount']>0 && (int)($r['seller_order_id']??0)<=0) self::cash('out',(float)$r['refund_amount'],'Refund Retur','return',(int)$return_id,'Refund retur '.$r['return_no']);
        return true;
    }

    /** Gudang menerima retur dari kurir. Fisik masuk dulu, stok jual menunggu QC. */
    public static function warehouse_receive_return($return_id, $tracking_no='', $courier_name='', $seller_name='') {
        global $wpdb;
        $return_id=(int)$return_id;
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('returns')." WHERE id=%d FOR UPDATE",$return_id),ARRAY_A);
        if(!$r) throw new Exception('Retur tidak ditemukan.');
        if(in_array((string)$r['status'],['completed','cancelled'],true)) throw new Exception('Retur sudah selesai atau dibatalkan.');
        $tracking=sanitize_text_field($tracking_no ?: ($r['tracking_no']??''));
        $courier=sanitize_text_field($courier_name ?: ($r['courier_name']??''));
        $seller=sanitize_text_field($seller_name ?: ($r['seller_name']??''));
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".PK01_DB::t('warehouse_documents')." WHERE doc_type='return_in' AND return_id=%d LIMIT 1",$return_id));
        if($existing) throw new Exception('Retur ini sudah diterima oleh gudang.');
        $wpdb->query('START TRANSACTION');
        try {
        $doc=self::document_number('warehouse_return');
        $courier_doc=self::document_number('warehouse_return_courier');
        $base=['doc_type'=>'return_in','direction'=>'in','tracking_no'=>$tracking,'courier_name'=>$courier,'order_id'=>(int)$r['order_id'],'return_id'=>$return_id,'reference_no'=>$r['return_no'],'status'=>'received_waiting_qc','created_by'=>get_current_user_id(),'created_at'=>self::now()];
        $warehouse_data=array_merge($base,['doc_no'=>$doc,'copy_type'=>'warehouse','seller_name'=>sanitize_text_field($seller),'source_doc_no'=>$doc,'notes'=>'SALINAN GUDANG: Retur diterima dari kurir; nama Seller wajib terlihat; menunggu QC.']);
        $courier_data=array_merge($base,['doc_no'=>$courier_doc,'copy_type'=>'courier','seller_name'=>'','source_doc_no'=>$doc,'notes'=>'SALINAN KURIR: Bukti fisik retur diserahkan/diterima Gudang. Nama Seller tidak dicantumkan pada salinan kurir.']);
        if(!$wpdb->insert(PK01_DB::t('warehouse_documents'),$warehouse_data)) throw new Exception($wpdb->last_error?:'Tanda terima retur Gudang gagal dibuat.');
        if(!$wpdb->insert(PK01_DB::t('warehouse_documents'),$courier_data)) throw new Exception($wpdb->last_error?:'Tanda terima retur Kurir gagal dibuat.');
        $received_at=self::now();
        $wpdb->update(PK01_DB::t('returns'),['tracking_no'=>$tracking,'courier_name'=>$courier,'seller_name'=>$seller,'status'=>'warehouse_received','warehouse_received_at'=>$received_at,'warehouse_received_by'=>get_current_user_id(),'accepted_at'=>$received_at,'qc_status'=>'waiting'],['id'=>$return_id]);
        $adjustment=self::apply_return_to_seller_financials($return_id);
        $notice=self::notify_return_received($return_id);
        $wpdb->query('COMMIT');
        self::log('warehouse_return_received','inventory','return',(string)$return_id,null,['doc_no'=>$doc,'courier_doc_no'=>$courier_doc,'tracking_no'=>$tracking,'courier'=>$courier,'seller'=>$seller,'seller_adjustment'=>$adjustment,'email_notified'=>$notice['email']??false],'Gudang menerima retur dari kurir; AR Seller otomatis direkonsiliasi');
        return ['ok'=>true,'doc_no'=>$doc,'courier_doc_no'=>$courier_doc,'return_id'=>$return_id,'seller_adjustment'=>$adjustment,'seller_name'=>$seller,'notify'=>$notice];
        } catch(Throwable $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }
    }

    /** Gudang menyerahkan barang ke kurir berdasarkan resi. Tidak memotong stok kedua kali. */
    public static function warehouse_handover_shipment($tracking_no, $courier_name='') {
        global $wpdb;
        $tracking=sanitize_text_field($tracking_no);
        if($tracking==='') throw new Exception('Nomor resi wajib diisi.');
        $s=self::get_shipment_by_tracking($tracking);
        if(!$s) throw new Exception('Resi tidak ditemukan di data pengiriman PK01.');
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".PK01_DB::t('warehouse_documents')." WHERE doc_type='outbound_courier' AND shipment_id=%d LIMIT 1",(int)$s['id']));
        if($existing) throw new Exception('Resi ini sudah memiliki tanda terima serah-terima gudang.');
        $seller='';
        if(!empty($s['seller_sale_id'])) $seller=(string)$wpdb->get_var($wpdb->prepare("SELECT sa.name FROM ".PK01_DB::t('seller_sales')." ss LEFT JOIN ".PK01_DB::t('sales_accounts')." sa ON sa.id=ss.seller_account_id WHERE ss.id=%d",(int)$s['seller_sale_id']));
        if($seller==='' && !empty($s['sale_id'])) $seller=(string)$wpdb->get_var($wpdb->prepare("SELECT sa.name FROM ".PK01_DB::t('sales_orders')." so LEFT JOIN ".PK01_DB::t('sales_accounts')." sa ON sa.id=so.affiliate_seller_id WHERE so.id=%d",(int)$s['sale_id']));
        $courier=sanitize_text_field($courier_name ?: ($s['courier']??''));
        $doc=self::document_number('warehouse_handover');
        $wpdb->insert(PK01_DB::t('warehouse_documents'),[
            'doc_no'=>$doc,'doc_type'=>'outbound_courier','direction'=>'out','tracking_no'=>sanitize_text_field($s['tracking_no']??''),'internal_shipment_no'=>sanitize_text_field($s['internal_shipment_no']??''),'courier_name'=>$courier,'seller_name'=>sanitize_text_field($seller),
            'order_id'=>(int)($s['sale_id']??0),'shipment_id'=>(int)$s['id'],'reference_no'=>sanitize_text_field($s['internal_shipment_no']??$tracking),'status'=>'handed_over',
            'notes'=>'Barang diserahkan gudang kepada kurir. Tidak ada pemotongan stok tambahan.','created_by'=>get_current_user_id(),'created_at'=>self::now()
        ]);
        if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Tanda terima serah-terima gagal dibuat.');
        // Serah-terima fisik adalah titik resmi order menjadi SHIPPED.
        $wpdb->update(PK01_DB::t('shipments'), ['status'=>'shipped','last_event_at'=>self::now()], ['id'=>(int)$s['id']]);
        if (!empty($s['sale_id'])) {
            $order_update=['status'=>'shipped','shipping_status'=>'shipped'];
            // Jangan pernah menulis barcode internal PK01 sebagai AWB resmi.
            if(!empty($s['tracking_no'])) $order_update['tracking_no']=sanitize_text_field($s['tracking_no']);
            if(!empty($s['courier'])) $order_update['courier']=sanitize_key($s['courier']);
            $wpdb->update(PK01_DB::t('sales_orders'), $order_update, ['id'=>(int)$s['sale_id']]);
        }
        self::log('warehouse_shipment_handover','inventory','shipment',(string)$s['id'],null,['doc_no'=>$doc,'tracking_no'=>$s['tracking_no']??'','internal_shipment_no'=>$s['internal_shipment_no']??'','courier'=>$courier,'seller'=>$seller],'Gudang menyerahkan barang ke kurir');
        return ['ok'=>true,'doc_no'=>$doc,'shipment'=>$s,'seller_name'=>$seller,'courier_name'=>$courier];
    }

    public static function shipment_tracking($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT s.*,e.status last_status,e.event_time last_event_time FROM ".PK01_DB::t('shipments')." s LEFT JOIN ".PK01_DB::t('tracking_events')." e ON e.id=(SELECT MAX(id) FROM ".PK01_DB::t('tracking_events')." WHERE shipment_id=s.id) WHERE s.id=%d",(int)$id),ARRAY_A);
    }
    public static function get_shipment_by_tracking($tracking_no) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('shipments')." WHERE tracking_no=%s OR internal_shipment_no=%s OR internal_barcode=%s LIMIT 1",sanitize_text_field($tracking_no),sanitize_text_field($tracking_no),sanitize_text_field($tracking_no)),ARRAY_A);
    }

    public static function dashboard() {
        return self::smart_dashboard();
    }
    public static function smart_dashboard() {
        global $wpdb;
        $count=function($table,$where='1=1')use($wpdb){$t=PK01_DB::t($table);return $t?(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE {$where}"):0;};
        return ['sales_today'=>$count('sales_orders',"DATE(created_at)=CURDATE() AND status NOT IN ('cancelled','failed')"),
                'jobs_active'=>$count('jobs',"status NOT IN ('completed','cancelled')"),
                'employees_active'=>$count('employees',"status='active'"),
                'cash_balance'=>self::cash_balance()];
    }

    public static function seller_create($name,$code,$phone='',$email='',$commission=10,$affiliate=5,$payment_term_days=0,$payment_term_label='Langsung / COD') {
        $r=self::seller_register($name,$code,$phone,$email,'',$commission,'admin');
        global $wpdb;
        if ($r && $payment_term_days >= 0) { $wpdb->update(self::t('sales_accounts'), ['affiliate_percent'=>(float)$affiliate,'payment_term_days'=>(int)$payment_term_days,'payment_term_label'=>sanitize_text_field($payment_term_label ?: 'Langsung / COD')], ['id'=>(int)$r]); }
        if(!empty($r['seller_id'])){
            global $wpdb;
            $wpdb->update(PK01_DB::t('sales_accounts'),['affiliate_percent'=>max(0,min(100,(float)$affiliate))],['id'=>(int)$r['seller_id']]);
        }
        return $r['seller_id'] ?? 0;
    }
    public static function seller_update($id,$name,$code,$phone='',$email='',$commission=10,$affiliate=5,$active=1,$payment_term_days=0,$payment_term_label='Langsung / COD') {
        global $wpdb;
        $id=(int)$id;$t=PK01_DB::t('sales_accounts');
        if(!$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE id=%d",$id))) throw new Exception('Seller tidak ditemukan.');
        $wpdb->update($t,['name'=>sanitize_text_field($name),'code'=>sanitize_text_field($code),'phone'=>sanitize_text_field($phone),
            'email'=>sanitize_email($email),'commission_percent'=>max(0,min(100,(float)$commission)),
            'affiliate_percent'=>max(0,min(100,(float)$affiliate)),
            'payment_term_days'=>max(0,(int)$payment_term_days),
            'payment_term_label'=>sanitize_text_field($payment_term_label ?: 'Langsung / COD'),
            'active'=>$active?1:0,'updated_at'=>self::now()],['id'=>$id]);
        return true;
    }

    /**
     * PRODUKSI / SPK
     * Prinsip stok:
     * 1) Job dibuat -> tidak mengubah stok/kas.
     * 2) Bahan diserahkan -> stok bahan berkurang SATU KALI.
     * 3) Pemakaian bahan -> hanya mengubah used_qty, tidak memotong gudang lagi.
     * 4) Sisa bahan dikembalikan -> stok bahan bertambah.
     * 5) Hasil baik disetujui -> stok barang jadi bertambah dan unit traceability dibuat.
     * 6) Reject tidak masuk stok barang jadi.
     */
    public static function create_production_job($job_no, $variant_id, $qty, $location = '', $deadline = '', $production_date = '', $instructions = '', $priority = 'normal', $source_order_id = 0, $source_type = 'manual') {
        global $wpdb;
        $variant_id = (int)$variant_id;
        $qty = (float)$qty;
        if ($variant_id <= 0 || $qty <= 0) throw new Exception('Produk dan jumlah target wajib valid.');

        $v = $wpdb->get_row($wpdb->prepare(
            "SELECT v.*,p.* FROM ".PK01_DB::t('product_variants')." v JOIN ".PK01_DB::t('products')." p ON p.id=v.product_id WHERE v.id=%d",
            $variant_id
        ), ARRAY_A);
        if (!$v) throw new Exception('SKU produk tidak ditemukan.');
        if (($v['supply_mode'] ?? 'production') === 'purchase') throw new Exception('SKU ini adalah Produk Beli dari Luar. Gunakan Permintaan Pembelian.');

        $job_no = sanitize_text_field($job_no);
        if ($job_no === '') {
            $job_no = self::document_number('job');
        }
        $production_date = $production_date ? sanitize_text_field($production_date) : current_time('Y-m-d');
        $priority = in_array($priority,['low','normal','high','urgent'],true) ? $priority : 'normal';

        $snapshot = wp_json_encode([
            'product_id'=>(int)$v['product_id'],'variant_id'=>$variant_id,'sku'=>$v['sku'],
            'product_name'=>$v['name'],'length'=>$v['product_length']??0,'width'=>$v['product_width']??0,
            'height'=>$v['product_height']??0,'thickness'=>$v['product_thickness']??0,
            'dimension_unit'=>$v['dimension_unit']??'cm','material'=>$v['material']??'',
            'variant_finishing'=>$v['finishing']??'','product_finishing'=>$v['finishing']??'',
            'color'=>$v['color']??'','description'=>$v['product_description']??($v['description']??''),
            'production_notes'=>$v['production_notes']??'','production_instructions'=>$v['production_instructions']??'',
            'product_image_id'=>(int)($v['image_id']??0),'technical_drawing_id'=>(int)($v['technical_drawing_id']??0),'cnc_file_id'=>(int)($v['cnc_file_id']??0),
            'source_order_id'=>(int)$source_order_id,'source_type'=>sanitize_key($source_type)
        ]);

        $wpdb->query('START TRANSACTION');
        try {
            $ok=$wpdb->insert(PK01_DB::t('jobs'),[
                'job_no'=>$job_no,'location'=>sanitize_text_field($location),'production_date'=>$production_date,
                'deadline'=>$deadline?sanitize_text_field($deadline):null,'status'=>'planned','priority'=>$priority,
                'instructions'=>sanitize_textarea_field($instructions),'spec_snapshot'=>$snapshot,
                'target_qty'=>$qty,'product_id'=>(int)$v['product_id'],'created_by'=>get_current_user_id(),
                'source_order_id'=>(int)$source_order_id,'source_type'=>sanitize_key($source_type),
                'created_at'=>self::now()
            ]);
            if (!$ok) throw new Exception('Gagal membuat Job Produksi.');
            $job_id=(int)$wpdb->insert_id;
            $wpdb->insert(PK01_DB::t('job_items'),[
                'job_id'=>$job_id,'variant_id'=>$variant_id,'qty'=>$qty,'unit'=>'pcs','created_at'=>self::now()
            ]);
            if (!$wpdb->insert_id) throw new Exception('Gagal membuat detail Job Produksi.');
            $wpdb->query('COMMIT');
            self::log('production_job_created','production','jobs',(string)$job_id,null,['job_no'=>$job_no,'target_qty'=>$qty]);
            try { self::auto_dispatch_production_job($job_id); } catch(Throwable $dispatch_error) { self::log('production_job_dispatch_warning','production','jobs',(string)$job_id,null,['message'=>$dispatch_error->getMessage()]); }
            return $job_id;
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK'); throw $e;
        }
    }

    /** Auto-dispatch Job berdasarkan routing eksplisit Product Master. */
    public static function auto_dispatch_production_job($job_id) {
        global $wpdb;
        $job_id=(int)$job_id;
        $job=$wpdb->get_row($wpdb->prepare("SELECT j.*,p.name product_name,p.finishing product_finishing,p.cnc_required,p.prema_required,v.sku,v.name variant_name,v.material,v.finishing variant_finishing,ji.variant_id FROM ".PK01_DB::t('jobs')." j LEFT JOIN ".PK01_DB::t('products')." p ON p.id=j.product_id LEFT JOIN ".PK01_DB::t('job_items')." ji ON ji.job_id=j.id LEFT JOIN ".PK01_DB::t('product_variants')." v ON v.id=ji.variant_id WHERE j.id=%d ORDER BY ji.id LIMIT 1",$job_id),ARRAY_A);
        if(!$job) throw new Exception('Job Produksi tidak ditemukan.');
        $snapshot=json_decode((string)($job['spec_snapshot']??''),true); if(!is_array($snapshot)) $snapshot=[];
        $material=(string)($job['material']??($snapshot['material']??$job['variant_material']??''));
        $requires_cnc=!empty($job['cnc_required']);
        $requires_prema=!empty($job['prema_required']);
        $cnc_master=null;
        if($requires_cnc && class_exists('PK01_CNC_Library')) {
            try {$cnc_master=PK01_CNC_Library::best_match((int)$job['product_id'],(int)$job['variant_id'], $material);} catch(Throwable $e) {}
        }
        $stages=[]; if($requires_cnc)$stages[]='cnc'; if($requires_prema)$stages[]='prema';
        $results=[]; $used=[];
        foreach($stages as $stage){
            if($stage==='cnc' && !$cnc_master){
                $results[$stage]=['status'=>'blocked','reason'=>'Master G-code CNC yang cocok belum tersedia.'];
                continue;
            }
            $role=$stage==='cnc'?'cnc':'prema';
            $existing_stage=$wpdb->get_row($wpdb->prepare("SELECT ja.*,e.name employee_name,e.code employee_code FROM `".PK01_DB::t('job_assignments')."` ja JOIN `".PK01_DB::t('employees')."` e ON e.id=ja.employee_id WHERE ja.job_id=%d AND ja.role_code=%s AND ja.status NOT IN ('completed','returned') ORDER BY ja.id DESC LIMIT 1",$job_id,$role),ARRAY_A);
            if($existing_stage){ $used[]=(int)$existing_stage['employee_id']; $results[$stage]=['status'=>'assigned','assignment_id'=>(int)$existing_stage['id'],'employee_id'=>(int)$existing_stage['employee_id'],'employee_name'=>$existing_stage['employee_name'],'existing'=>true]; continue; }
            $emp=null; $role_table=PK01_DB::t('employee_job_roles');
            $exclude=empty($used)?'0':implode(',',array_map('intval',$used));
            if($role_table && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$role_table))===$role_table){
                $emp=$wpdb->get_row($wpdb->prepare("SELECT e.*,r.skill_level,r.confidence FROM `{$role_table}` r JOIN `".PK01_DB::t('employees')."` e ON e.id=r.employee_id WHERE r.role_code=%s AND r.active=1 AND e.status='active' AND e.id NOT IN ({$exclude}) ORDER BY r.confidence DESC, CASE r.skill_level WHEN 'expert' THEN 0 WHEN 'advanced' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,e.id ASC LIMIT 1",$role),ARRAY_A);
            }
            if(!$emp){
                $results[$stage]=['status'=>'unassigned','reason'=>'Tidak ada pekerja aktif yang memiliki role '.$role.'. PK01 tidak membuat pekerja dummy.'];
                continue;
            }
            $notes=$stage==='cnc'
                ? 'Tahap CNC. Master G-code: '.$cnc_master['code'].' v'.$cnc_master['version'].' | Ukuran '.$cnc_master['width'].' × '.$cnc_master['height'].' mm | Depth '.$cnc_master['depth'].' mm | Material '.($cnc_master['material']?:'Umum').'. File diberikan manual ke komputer CNC.'
                : 'Tahap Prema / Finishing. Mulai setelah seluruh tahap CNC Job ini selesai.';
            try{$aid=self::assign_job_employee_with_role($job_id,(int)$emp['id'],$role,'ai',max(0.1,min(1,(float)($emp['confidence']??0.8))),$notes);$used[]=(int)$emp['id'];$results[$stage]=['status'=>'assigned','assignment_id'=>$aid,'employee_id'=>(int)$emp['id'],'employee_name'=>$emp['name'],'notes'=>$notes,'cnc_master_id'=>(int)($cnc_master['id']??0)];}catch(Throwable $e){$results[$stage]=['status'=>'error','reason'=>$e->getMessage()];}
        }
        $new_status=empty($stages)?'planned':(!empty($results['cnc'])&&$results['cnc']['status']==='blocked'?'planned':(empty($used)?'planned':'assigned'));
        $wpdb->update(PK01_DB::t('jobs'),['status'=>$new_status,'updated_at'=>self::now()],['id'=>$job_id]);
        self::log('production_job_auto_dispatched','production','jobs',(string)$job_id,null,['stages'=>$results,'requires_cnc'=>$requires_cnc,'requires_prema'=>$requires_prema,'cnc_master_id'=>(int)($cnc_master['id']??0)]);
        return ['job_id'=>$job_id,'requires_cnc'=>$requires_cnc,'requires_prema'=>$requires_prema,'cnc_master'=>$cnc_master,'stages'=>$results];
    }

    public static function assign_job_employee($job_id,$employee_id,$notes='') {
        global $wpdb;
        $job=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('jobs')." WHERE id=%d",(int)$job_id),ARRAY_A);
        $emp=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('employees')." WHERE id=%d AND status='active'",(int)$employee_id),ARRAY_A);
        if(!$job || !$emp) throw new Exception('Job atau karyawan tidak ditemukan.');
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".PK01_DB::t('job_assignments')." WHERE job_id=%d AND employee_id=%d AND status NOT IN ('completed','returned') LIMIT 1",(int)$job_id,(int)$employee_id));
        if($existing) throw new Exception('Job sudah dikirim ke karyawan tersebut dan masih aktif.');
        $wpdb->insert(PK01_DB::t('job_assignments'),[
            'job_id'=>(int)$job_id,'employee_id'=>(int)$employee_id,'status'=>'assigned',
            'notes'=>sanitize_textarea_field($notes),'assigned_at'=>self::now(),
            'assigned_by'=>get_current_user_id()
        ]);
        $id=(int)$wpdb->insert_id;
        $wpdb->update(PK01_DB::t('jobs'),['status'=>'assigned','updated_at'=>self::now()],['id'=>(int)$job_id]);
        self::log('job_assigned','production','job_assignment',(string)$id,null,['job_id'=>$job_id,'employee_id'=>$employee_id]); if(class_exists('PK01_Kernel')) PK01_Kernel::event('job_assigned','production','job_assignment',$id,['job_id'=>$job_id,'employee_id'=>$employee_id]);
        return $id;
    }

    /** Penugasan baru dengan role pekerjaan; method lama tetap kompatibel. */
    public static function assign_job_employee_with_role($job_id,$employee_id,$role_code='',$source='manual',$confidence=0,$notes='') {
        global $wpdb;
        $id=self::assign_job_employee($job_id,$employee_id,$notes);
        $wpdb->update(PK01_DB::t('job_assignments'),['role_code'=>sanitize_key($role_code),'assignment_source'=>sanitize_key($source),'ai_confidence'=>max(0,min(1,(float)$confidence))],['id'=>(int)$id]);
        if($role_code && PK01_DB::t('employee_job_roles')) {
            $wpdb->query($wpdb->prepare("INSERT INTO `".PK01_DB::t('employee_job_roles')."` (employee_id,role_code,skill_level,active,source,confidence,created_at,updated_at) VALUES (%d,%s,'normal',1,%s,%f,%s,%s) ON DUPLICATE KEY UPDATE active=1,source=VALUES(source),confidence=VALUES(confidence),updated_at=VALUES(updated_at)",(int)$employee_id,sanitize_key($role_code),sanitize_key($source),(float)$confidence,self::now(),self::now()));
        }
        self::log('job_role_assigned','production','job_assignment',(string)$id,null,['role_code'=>$role_code,'source'=>$source,'confidence'=>$confidence]);
        return $id;
    }

    public static function update_job_worker_status($assignment_id,$status,$notes='') {
        global $wpdb;
        $allowed=['assigned','accepted','in_progress','completed','returned'];
        if(!in_array($status,$allowed,true)) throw new Exception('Status pekerjaan tidak valid.');
        $a=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_assignments')." WHERE id=%d",(int)$assignment_id),ARRAY_A);
        if(!$a) throw new Exception('Penugasan pekerjaan tidak ditemukan.');
        $uid=get_current_user_id();
        $emp=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('employees')." WHERE id=%d",(int)$a['employee_id']),ARRAY_A);
        if(!current_user_can('manage_options') && (!$emp || (int)$emp['user_id']!==$uid)) throw new Exception('Anda tidak berwenang mengubah pekerjaan ini.');
        $trans=[
            'assigned'=>['assigned'],
            'accepted'=>['assigned'],
            'in_progress'=>['accepted'],
            'completed'=>['in_progress'],
            'returned'=>['assigned','accepted','in_progress']
        ];
        if(!in_array($a['status'],$trans[$status],true) && $a['status']!==$status) throw new Exception('Urutan status pekerjaan tidak valid.');
        // Prema boleh menerima Job, tetapi tidak boleh mulai sebelum tahap CNC
        // selesai pada Job multi-tahap. Ini mencegah finishing dikerjakan dari
        // bahan yang belum keluar dari proses CNC.
        if($status==='in_progress' && sanitize_key($a['role_code']??'')==='prema') {
            $cnc_open=(bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM `".PK01_DB::t('job_assignments')."` WHERE job_id=%d AND role_code='cnc' AND status NOT IN ('completed','returned') LIMIT 1",(int)$a['job_id']));
            if($cnc_open) throw new Exception('Tahap CNC belum selesai. Prema dapat menerima Job, tetapi belum dapat memulai pekerjaan.');
        }
        if(class_exists('PK01_Workflow')) PK01_Workflow::assert_transition('job_assignment',$a['status'],$status);
        $data=['status'=>$status];
        if($notes!=='') $data['notes']=sanitize_textarea_field($notes);
        if($status==='accepted') $data['accepted_at']=self::now();
        if($status==='in_progress') $data['started_at']=self::now();
        if($status==='completed') $data['completed_at']=self::now();
        if($status==='returned') $data['returned_at']=self::now();
        $wpdb->update(PK01_DB::t('job_assignments'),$data,['id'=>(int)$assignment_id]);
        // Status Job adalah status agregat seluruh assignment, bukan status satu
        // pekerja. Job baru selesai bila seluruh assignment aktif selesai.
        $open=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `".PK01_DB::t('job_assignments')."` WHERE job_id=%d AND status NOT IN ('completed','returned')",(int)$a['job_id']));
        $any=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `".PK01_DB::t('job_assignments')."` WHERE job_id=%d",(int)$a['job_id']));
        $aggregate=$open===0 && $any>0 ? 'completed' : ((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `".PK01_DB::t('job_assignments')."` WHERE job_id=%d AND status='in_progress'",(int)$a['job_id']))>0 ? 'in_progress' : 'assigned');
        $wpdb->update(PK01_DB::t('jobs'),['status'=>$aggregate,'updated_at'=>self::now()],['id'=>(int)$a['job_id']]);
        self::log('job_status_'.$status,'production','job_assignment',(string)$assignment_id,null,$data); if(class_exists('PK01_Kernel')) PK01_Kernel::event('job_status_changed','production','job_assignment',$assignment_id,['from'=>$a['status'],'to'=>$status,'job_id'=>$a['job_id']??0]);
        return true;
    }

    public static function issue_job_material($job_id,$material_id,$qty,$notes='') {
        global $wpdb;
        $job_id=(int)$job_id; $material_id=(int)$material_id; $qty=(float)$qty;
        if($job_id<=0||$material_id<=0||$qty<=0) throw new Exception('Job, bahan, dan jumlah wajib valid.');
        $wpdb->query('START TRANSACTION');
        try {
            $m=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('materials')." WHERE id=%d FOR UPDATE",$material_id),ARRAY_A);
            $j=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('jobs')." WHERE id=%d FOR UPDATE",$job_id),ARRAY_A);
            if(!$m||!$j) throw new Exception('Job atau bahan tidak ditemukan.');
            if((float)$m['stock']+0.000001<$qty) throw new Exception('Stok bahan tidak mencukupi.');
            $wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('materials')." SET stock=stock-%f WHERE id=%d",$qty,$material_id));
            // Snapshot biaya pada saat bahan diserahkan. Ini menjadi dasar traceability HPP aktual Job.
            $unit_cost=max(0,(float)($m['cost']??0));
            $issued_value=round($qty*$unit_cost,2);
            $wpdb->insert(PK01_DB::t('job_materials'),[
                'job_id'=>$job_id,'material_id'=>$material_id,'issued_qty'=>$qty,'used_qty'=>0,
                'returned_qty'=>0,'unit_cost'=>$unit_cost,'issued_value'=>$issued_value,'consumed_cost'=>0,'returned_value'=>0,
                'issued_at'=>self::now(),'notes'=>sanitize_textarea_field($notes)
            ]);
            $jm=(int)$wpdb->insert_id;
            $wpdb->insert(PK01_DB::t('stock_transactions'),[
                'stock_type'=>'material','item_id'=>$material_id,'material_id'=>$material_id,'qty'=>$qty,'direction'=>'out',
                'reference_type'=>'job_issue','reference_id'=>$jm,'reference_no'=>$j['job_no'],
                'notes'=>'Bahan diserahkan ke job '.$j['job_no'],'created_by'=>get_current_user_id(),'created_at'=>self::now()
            ]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Mutasi stok bahan keluar gagal.');
            $whdoc=self::document_number('warehouse_production_out');
            $wpdb->insert(PK01_DB::t('warehouse_documents'),[
                'doc_no'=>$whdoc,'doc_type'=>'production_out','direction'=>'out','tracking_no'=>'','courier_name'=>'','seller_name'=>'',
                'order_id'=>0,'shipment_id'=>0,'return_id'=>0,'reference_no'=>$j['job_no'],'status'=>'handed_over',
                'notes'=>'Bahan keluar dari Gudang ke Job Produksi. Tidak membuat pemotongan stok kedua.','created_by'=>get_current_user_id(),'created_at'=>self::now()
            ]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Tanda terima bahan keluar ke produksi gagal dibuat.');
            $wpdb->query('COMMIT');
            self::log('job_material_issued','production','job_material',(string)$jm,null,['qty'=>$qty,'material_id'=>$material_id]);
            return $jm;
        } catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function record_job_material_usage($job_material_id,$used_qty,$notes='') {
        global $wpdb;
        $id=(int)$job_material_id; $used=(float)$used_qty;
        if($id<=0||$used<=0) throw new Exception('Jumlah pemakaian harus lebih dari 0.');
        $jm=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_materials')." WHERE id=%d",$id),ARRAY_A);
        if(!$jm) throw new Exception('Bahan Job tidak ditemukan.');
        $remaining=(float)$jm['issued_qty']-(float)$jm['used_qty']-(float)$jm['returned_qty'];
        if($used>$remaining+0.000001) throw new Exception('Pemakaian melebihi sisa bahan yang diserahkan.');
        $new_used=(float)$jm['used_qty']+$used;
        $unit_cost=(float)($jm['unit_cost']??0);
        if($unit_cost<=0){
            $unit_cost=(float)$wpdb->get_var($wpdb->prepare("SELECT cost FROM ".PK01_DB::t('materials')." WHERE id=%d",(int)$jm['material_id']));
        }
        $consumed_cost=round($new_used*$unit_cost,2);
        $returned_value=round((float)$jm['returned_qty']*$unit_cost,2);
        $wpdb->update(PK01_DB::t('job_materials'),[
            'used_qty'=>$new_used,'unit_cost'=>$unit_cost,'consumed_cost'=>$consumed_cost,'returned_value'=>$returned_value,'used_at'=>self::now(),
            'notes'=>$notes!==''?sanitize_textarea_field($notes):$jm['notes']
        ],['id'=>$id]);
        self::log('job_material_used','production','job_material',(string)$id,null,['used_qty'=>$used,'total_used'=>$new_used,'unit_cost'=>$unit_cost,'consumed_cost'=>$consumed_cost]); if(class_exists('PK01_Kernel')) PK01_Kernel::event('material_consumed','production','job_material',$id,['used_qty'=>$used,'total_used'=>$new_used,'consumed_cost'=>$consumed_cost]);
        return true;
    }

    public static function return_job_material($job_material_id,$return_qty,$notes='') {
        global $wpdb;
        $id=(int)$job_material_id; $ret=(float)$return_qty;
        if($id<=0||$ret<=0) throw new Exception('Jumlah pengembalian harus lebih dari 0.');
        $wpdb->query('START TRANSACTION');
        try{
            $jm=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_materials')." WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$jm) throw new Exception('Bahan Job tidak ditemukan.');
            $remaining=(float)$jm['issued_qty']-(float)$jm['used_qty']-(float)$jm['returned_qty'];
            if($ret>$remaining+0.000001) throw new Exception('Pengembalian melebihi sisa bahan Job.');
            $new_returned=(float)$jm['returned_qty']+$ret;
            $unit_cost=(float)($jm['unit_cost']??0);
            if($unit_cost<=0){
                $unit_cost=(float)$wpdb->get_var($wpdb->prepare("SELECT cost FROM ".PK01_DB::t('materials')." WHERE id=%d",(int)$jm['material_id']));
            }
            $wpdb->update(PK01_DB::t('job_materials'),[
                'returned_qty'=>$new_returned,'unit_cost'=>$unit_cost,'returned_value'=>round($new_returned*$unit_cost,2),'returned_at'=>self::now(),
                'notes'=>$notes!==''?sanitize_textarea_field($notes):$jm['notes']
            ],['id'=>$id]);
            $wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('materials')." SET stock=stock+%f WHERE id=%d",$ret,(int)$jm['material_id']));
            $wpdb->insert(PK01_DB::t('stock_transactions'),[
                'stock_type'=>'material','item_id'=>(int)$jm['material_id'],'material_id'=>(int)$jm['material_id'],
                'qty'=>$ret,'direction'=>'in','reference_type'=>'job_return','reference_id'=>$id,
                'notes'=>'Sisa bahan dikembalikan dari job','created_by'=>get_current_user_id(),'created_at'=>self::now()
            ]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Mutasi stok bahan kembali gagal.');
            $job=$wpdb->get_row($wpdb->prepare("SELECT j.job_no FROM ".PK01_DB::t('jobs')." j WHERE j.id=%d",(int)$jm['job_id']),ARRAY_A);
            $whdoc=self::document_number('warehouse_production_in');
            $wpdb->insert(PK01_DB::t('warehouse_documents'),[
                'doc_no'=>$whdoc,'doc_type'=>'production_in','direction'=>'in','tracking_no'=>'','courier_name'=>'','seller_name'=>'',
                'order_id'=>0,'shipment_id'=>0,'return_id'=>0,'reference_no'=>(string)($job['job_no']??('JM-'.$id)),'status'=>'received',
                'notes'=>'Sisa bahan diterima kembali dari Job Produksi ke Gudang.','created_by'=>get_current_user_id(),'created_at'=>self::now()
            ]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Tanda terima bahan kembali ke gudang gagal dibuat.');
            $wpdb->query('COMMIT');
            self::log('job_material_returned','production','job_material',(string)$id,null,['return_qty'=>$ret]); if(class_exists('PK01_Kernel')) PK01_Kernel::event('material_returned','production','job_material',$id,['return_qty'=>$ret]);
            return true;
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function record_production_result($job_id,$good_qty,$reject_qty=0,$approved=true,$manage_transaction=true) {
        global $wpdb;
        $job_id=(int)$job_id; $good=(float)$good_qty; $reject=(float)$reject_qty;
        if($job_id<=0||$good<0||$reject<0||($good+$reject)<=0) throw new Exception('Hasil produksi tidak valid.');
        if($manage_transaction) $wpdb->query('START TRANSACTION');
        try{
            $job=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('jobs')." WHERE id=%d FOR UPDATE",$job_id),ARRAY_A);
            $item=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('job_items')." WHERE job_id=%d ORDER BY id LIMIT 1",$job_id),ARRAY_A);
            if(!$job||!$item) throw new Exception('Job produksi atau detail SKU tidak ditemukan.');
            $already=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(good_qty+reject_qty),0) FROM ".PK01_DB::t('production_results')." WHERE job_id=%d",$job_id));
            if($already+$good+$reject>(float)$job['target_qty']+0.000001) throw new Exception('Total hasil melebihi target Job.');
            $wpdb->insert(PK01_DB::t('production_results'),[
                'job_id'=>$job_id,'good_qty'=>$good,'reject_qty'=>$reject,
                'status'=>$approved?'approved':'pending','approved'=>$approved?1:0,
                'production_code'=>'','batch_code'=>'','barcode_value'=>'','qr_payload'=>'','label_version'=>'1.0',
                'created_by'=>get_current_user_id(),'created_at'=>self::now()
            ]);
            $result_id=(int)$wpdb->insert_id;
            if(!$result_id) throw new Exception('Gagal menyimpan hasil produksi.');
            // Satu hasil produksi = satu batch resmi. Kode dibuat setelah ID hasil
            // tersedia sehingga unik dan dapat dicari/di-scan kembali.
            $day=date('ymd',current_time('timestamp'));
            $production_code='PRD-'.$day.'-J'.str_pad((string)$job_id,6,'0',STR_PAD_LEFT).'-R'.str_pad((string)$result_id,5,'0',STR_PAD_LEFT);
            $batch_code='BTH-'.$day.'-J'.str_pad((string)$job_id,6,'0',STR_PAD_LEFT).'-R'.str_pad((string)$result_id,5,'0',STR_PAD_LEFT);
            $qr_payload=add_query_arg(['pk01_production'=>$production_code,'pk01_batch'=>$batch_code],PK01_DB::page_url('production'));
            $wpdb->update(PK01_DB::t('production_results'),[
                'production_code'=>$production_code,'batch_code'=>$batch_code,'barcode_value'=>$production_code,'qr_payload'=>$qr_payload
            ],['id'=>$result_id]);
            if($approved && $good>0){
                $vid=(int)$item['variant_id'];
                $wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('product_variants')." SET stock=stock+%f WHERE id=%d",$good,$vid));
                $base=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".PK01_DB::t('production_units')." WHERE job_id=%d",$job_id));
                for($i=1;$i<=(int)floor($good);$i++){
                    $seq=$base+$i;
                    $cnc_code='CNC-'.$day.'-J'.str_pad((string)$job_id,6,'0',STR_PAD_LEFT).'-U'.str_pad((string)$seq,4,'0',STR_PAD_LEFT);
                    $unit_id=$cnc_code;
                    $unit_qr=add_query_arg(['pk01_production'=>$production_code,'pk01_batch'=>$batch_code,'pk01_unit'=>$cnc_code],PK01_DB::page_url('production'));
                    $wpdb->insert(PK01_DB::t('production_units'),[
                        'job_id'=>$job_id,'variant_id'=>$vid,'production_code'=>$production_code,'unit_no'=>(string)$seq,'unit_id'=>$unit_id,'cnc_code'=>$cnc_code,'qr_payload'=>$unit_qr,
                        'batch_no'=>$batch_code,'production_date'=>$job['production_date'],
                        'status'=>'approved','created_at'=>self::now()
                    ]);
                }
                $wpdb->insert(PK01_DB::t('stock_transactions'),[
                    'stock_type'=>'finished','item_id'=>$vid,'variant_id'=>$vid,'qty'=>$good,'direction'=>'in',
                    'reference_type'=>'production_result','reference_id'=>$result_id,
                    'reference_no'=>$job['job_no'],'notes'=>'Hasil produksi disetujui','created_by'=>get_current_user_id(),'created_at'=>self::now()
                ]);
            }
            $new_good=$already+$good;
            $new_status=$new_good+0.000001 >= (float)$job['target_qty'] ? 'completed' : 'in_progress';
            $wpdb->update(PK01_DB::t('jobs'),['status'=>$new_status,'updated_at'=>self::now()],['id'=>$job_id]);
            if($manage_transaction) $wpdb->query('COMMIT');
            self::log('production_result_recorded','production','jobs',(string)$job_id,null,['good_qty'=>$good,'reject_qty'=>$reject,'status'=>$new_status,'batch_code'=>$batch_code,'result_id'=>$result_id]);
            return ['ok'=>true,'job_id'=>$job_id,'result_id'=>$result_id,'production_code'=>$production_code,'batch_code'=>$batch_code,'barcode_value'=>$production_code,'qr_payload'=>$qr_payload,'good_qty'=>$good,'reject_qty'=>$reject,'status'=>$new_status];
        }catch(Throwable $e){if($manage_transaction) $wpdb->query('ROLLBACK');throw $e;}
    }

    /**
     * Komisi Sales Internal: dipisahkan dari komisi affiliate/seller.
     * Status pending tidak masuk beban; approved/ready/paid masuk beban akrual.
     * Kas hanya bergerak ketika status dibayar melalui pay_sales_commission().
     */
    public static function record_sales_commission($order_id, $employee_id, $base_amount, $rate, $status = 'pending', $reference_no = '') {
        global $wpdb;
        $order_id=(int)$order_id; $employee_id=(int)$employee_id;
        $base_amount=round((float)$base_amount,2); $rate=max(0,min(100,(float)$rate));
        if($order_id<=0||$employee_id<=0||$base_amount<=0) throw new Exception('Data komisi sales tidak valid.');
        $amount=round($base_amount*$rate/100,2);
        $status=in_array($status,['pending','approved','ready','paid','cancelled'],true)?$status:'pending';
        $t=PK01_DB::t('sales_commissions');
        self::guard_entry('sales_commission', (int)$order_id.'|'.(int)$employee_id, ['base_amount'=>$base_amount,'amount'=>$amount]);
        $wpdb->insert($t,[
            'order_id'=>$order_id,'employee_id'=>$employee_id,'base_amount'=>$base_amount,
            'commission_percent'=>$rate,'commission_amount'=>$amount,'status'=>$status,
            'reference_no'=>sanitize_text_field($reference_no),'created_at'=>self::now(),
            'approved_at'=>in_array($status,['approved','ready','paid'],true)?self::now():null,
            'paid_at'=>$status==='paid'?self::now():null
        ]);
        if(!$wpdb->insert_id) throw new Exception('Gagal menyimpan komisi sales.');
        self::log('sales_commission_recorded','finance','sales_commission',(string)$wpdb->insert_id,null,['order_id'=>$order_id,'amount'=>$amount,'status'=>$status]);
        return (int)$wpdb->insert_id;
    }

    public static function pay_sales_commission($commission_id, $amount = 0) {
        global $wpdb;
        $t=PK01_DB::t('sales_commissions');
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",(int)$commission_id),ARRAY_A);
        if(!$r) throw new Exception('Komisi sales tidak ditemukan.');
        if(!in_array($r['status'],['approved','ready','paid'],true)) throw new Exception('Komisi sales belum disetujui untuk dibayar.');
        if($r['status']==='paid') throw new Exception('Komisi sales sudah dibayarkan.');
        $amount=$amount>0?round((float)$amount,2):(float)$r['commission_amount'];
        if($amount<=0||$amount>(float)$r['commission_amount']+0.01) throw new Exception('Nominal pembayaran komisi tidak valid.');
        self::guard_entry('sales_commission_payment', (int)$commission_id.'|'.number_format($amount,2,'.',''), ['commission_id'=>(int)$commission_id,'amount'=>$amount]);
        self::cash('out',$amount,'Komisi Sales','sales_commission',(int)$commission_id,'Pembayaran komisi sales '.$r['reference_no'],'Kas Tunai Toko',$r['reference_no']);
        $wpdb->update($t,['status'=>'paid','paid_at'=>self::now(), 'approved_at'=>$r['approved_at']?:self::now()],['id'=>(int)$commission_id]);
        return $amount;
    }

    /**
     * 6. MITRA SELLER & AFILIASI (TERINTEGRASI LENGKAP)
     */
    public static function seller_register($name, $code, $phone = '', $email = '', $password = '', $commission_or_affiliate = 10, $source = 'self') {
        global $wpdb;
        $name  = sanitize_text_field($name);
        $code  = sanitize_user($code, true);
        $email = sanitize_email($email);
        $phone = sanitize_text_field($phone);
        $comm  = max(0, min(100, (float)$commission_or_affiliate));

        if ($name === '' || $code === '') throw new Exception('Nama dan kode seller wajib diisi.');
        if ($email !== '' && email_exists($email)) throw new Exception('Alamat email sudah terdaftar.');
        self::guard_entry('seller', 'code:'.$code, ['name'=>$name,'email'=>$email]);

        $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('sales_accounts') : $wpdb->prefix . 'pk01_sales_accounts';
        
        $user_id = 0;
        if ($email !== '' && $password !== '') {
            $login = sanitize_user(strtok($email, '@'), true) ?: 'seller_' . wp_rand(1000, 9999);
            $base = $login; $n = 1;
            while (username_exists($login)) { $login = $base . $n++; }
            $user_id = wp_create_user($login, $password, $email);
            if (is_wp_error($user_id)) throw new Exception($user_id->get_error_message());
            $u = new WP_User($user_id);
            $u->set_role('pk01_seller');
        }

        $token  = wp_generate_password(32, false, false);
        $status = ($source === 'self') ? 'pending' : 'approved';

        $wpdb->insert($t, [
            'code'                => $code,
            'name'                => $name,
            'type'                => 'seller',
            'phone'               => $phone,
            'email'               => $email,
            'commission_percent'  => $comm,
            'affiliate_percent'   => $comm,
            'registration_status' => $status,
            'portal_token'        => $token,
            'active'              => ($status === 'approved') ? 1 : 0,
            'user_id'             => $user_id ?: null,
            'created_at'          => self::now()
        ]);

        $seller_id = (int)$wpdb->insert_id;
        self::log('seller_registered', 'seller', 'sales_account', (string)$seller_id, null, ['source' => $source, 'status' => $status]);

        return [
            'seller_id'    => $seller_id,
            'user_id'      => $user_id,
            'status'       => $status,
            'portal_token' => $token,
            'code'         => $code
        ];
    }

    public static function seller_approve($seller_id, $approve = true) {
        global $wpdb;
        $id = (int)$seller_id;
        $t = PK01_DB::t('sales_accounts');
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d AND type = 'seller'", $id), ARRAY_A);
        if (!$s) throw new Exception('Mitra seller tidak ditemukan.');

        $status = $approve ? 'approved' : 'rejected';
        $wpdb->update($t, ['active' => $approve ? 1 : 0, 'registration_status' => $status], ['id' => $id]);

        if (!empty($s['user_id'])) {
            $u = new WP_User((int)$s['user_id']);
            if ($approve) $u->set_role('pk01_seller');
        }

        self::log('seller_registration_' . $status, 'seller', 'sales_account', (string)$id, null, ['status' => $status]);
        return true;
    }

    public static function seller_price($seller_id, $variant_id) {
        global $wpdb;
        $t = PK01_DB::t('seller_contract_prices');
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) {
            $x = $wpdb->get_var($wpdb->prepare("SELECT price FROM `{$t}` WHERE seller_account_id = %d AND variant_id = %d AND active = 1 LIMIT 1", (int)$seller_id, (int)$variant_id));
            if ($x !== null && (float)$x > 0) return (float)$x;
        }

        // Fallback: Gunakan harga acuan varian dikurangi diskon komisi seller
        $v = $wpdb->get_row($wpdb->prepare("SELECT price, hpp FROM " . PK01_DB::t('product_variants') . " WHERE id = %d", (int)$variant_id), ARRAY_A);
        $base_price = (float)($v['price'] ?? 0);
        if ($base_price <= 0) {
            $base_price = (float)($v['hpp'] ?? 0) * 1.3;
        }

        return round($base_price, 2);
    }

    /**
     * Penjualan marketplace Seller manual.
     * Harga selalu berasal dari harga internal PK01, bukan harga yang Seller pasang di marketplace.
     * Marketplace/order/resi hanya menjadi referensi transaksi.
     */
    /**
     * Normalisasi data produk Seller dari marketplace tanpa menjadikannya master PK01.
     * Hanya pencocokan yang deterministik/aman yang boleh otomatis; data ambigu harus
     * dikonfirmasi ke Variant PK01 oleh operator.
     */
    public static function match_seller_marketplace_product($seller_id, $marketplace, $seller_sku = '', $seller_product_name = '', $seller_model = '', $seller_size = '') {
        global $wpdb;
        $seller_id = absint($seller_id);
        $marketplace = sanitize_key($marketplace ?: 'marketplace');
        $seller_sku = sanitize_text_field($seller_sku);
        $seller_product_name = sanitize_text_field($seller_product_name);
        $seller_model = sanitize_text_field($seller_model);
        $seller_size = sanitize_text_field($seller_size);
        if ($seller_id <= 0) throw new Exception('Seller wajib dipilih.');
        if ($seller_sku === '' && $seller_product_name === '' && $seller_model === '' && $seller_size === '') {
            throw new Exception('Minimal isi SKU Seller atau nama/model produk Seller.');
        }

        $vt = PK01_DB::t('product_variants');
        $map = PK01_DB::t('seller_marketplace_items');
        $normalize = static function($v) {
            $v = strtolower(trim((string)$v));
            $v = preg_replace('/[^a-z0-9]+/i', '', $v);
            return (string)$v;
        };

        // Mapping Seller yang sudah pernah dikonfirmasi selalu menjadi prioritas.
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT smi.*, v.sku AS pk01_sku, v.name AS pk01_variant_name FROM `{$map}` smi LEFT JOIN `{$vt}` v ON v.id=smi.variant_id WHERE smi.seller_account_id=%d AND smi.marketplace=%s AND smi.variant_id>0 AND ((%s<>'' AND smi.seller_sku=%s) OR (%s='' AND smi.seller_sku='' AND smi.seller_product_name=%s AND smi.seller_model=%s AND smi.seller_size=%s)) ORDER BY smi.id DESC LIMIT 1",
            $seller_id,$marketplace,$seller_sku,$seller_sku,$seller_sku,$seller_product_name,$seller_model,$seller_size
        ), ARRAY_A);
        if ($existing && !empty($existing['variant_id'])) {
            return ['status'=>'matched','variant_id'=>(int)$existing['variant_id'],'method'=>'saved_mapping','confidence'=>100,'candidates'=>[]];
        }

        // SKU Seller sama persis dengan SKU PK01 = aman untuk auto-match.
        if ($seller_sku !== '') {
            $v = $wpdb->get_row($wpdb->prepare("SELECT id,sku,name,size FROM `{$vt}` WHERE status='active' AND sku=%s LIMIT 2", $seller_sku), ARRAY_A);
            if ($v) {
                return ['status'=>'matched','variant_id'=>(int)$v['id'],'method'=>'exact_pk01_sku','confidence'=>100,'candidates'=>[$v]];
            }
        }

        // Cari kandidat berdasarkan nama/model/ukuran yang dinormalisasi. Tidak auto pilih.
        $rows = $wpdb->get_results("SELECT id,sku,name,size FROM `{$vt}` WHERE status='active' ORDER BY name,sku LIMIT 5000", ARRAY_A) ?: [];
        $targetName=$normalize($seller_product_name); $targetModel=$normalize($seller_model); $targetSize=$normalize($seller_size);
        $candidates=[];
        foreach($rows as $v){
            $vn=$normalize($v['name']); $vs=$normalize($v['size']);
            $score=0;
            if($targetName!=='' && ($vn===$targetName || strpos($vn,$targetName)!==false || strpos($targetName,$vn)!==false)) $score+=60;
            if($targetModel!=='' && (strpos($vn,$targetModel)!==false || $vn===$targetModel)) $score+=25;
            if($targetSize!=='' && ($vs===$targetSize || strpos($vs,$targetSize)!==false || strpos($targetSize,$vs)!==false)) $score+=15;
            if($score>0) { $v['match_score']=$score; $candidates[]=$v; }
        }
        usort($candidates, static function($a,$b){ return ($b['match_score']??0)<=>($a['match_score']??0); });
        $candidates=array_slice($candidates,0,8);

        return ['status'=>'needs_confirmation','variant_id'=>0,'method'=>'candidate_search','confidence'=>(float)($candidates[0]['match_score']??0),'candidates'=>$candidates];
    }

    /**
     * Seller mengirim order marketplace ke antrean Kasir.
     * Tidak memotong stok, tidak membuat invoice, dan tidak menganggap order sudah dikirim.
     * Kasir wajib menerima/menjalankan fulfillment setelah memeriksa stok.
     */
    public static function seller_submit_marketplace_order($seller_id, $variant_id, $qty, $marketplace='', $marketplace_order_no='', $tracking_no='', $seller_sku='') {
        global $wpdb;
        $seller_id=absint($seller_id); $variant_id=absint($variant_id); $qty=max(0.0001,(float)$qty);
        $marketplace=sanitize_key($marketplace?:'marketplace'); $marketplace_order_no=sanitize_text_field($marketplace_order_no);
        $tracking_no=strtoupper(sanitize_text_field($tracking_no)); $seller_sku=sanitize_text_field($seller_sku);
        if(!$seller_id) throw new Exception('Seller wajib dipilih.');
        if($marketplace_order_no==='') throw new Exception('Nomor order marketplace wajib diisi.');
        if(!$variant_id) throw new Exception('Produk PK01 wajib dipilih agar barang tidak tertukar.');
        $seller=$wpdb->get_row($wpdb->prepare("SELECT id,name FROM `".PK01_DB::t('sales_accounts')."` WHERE id=%d AND type='seller' AND active=1 LIMIT 1",$seller_id),ARRAY_A);
        if(!$seller) throw new Exception('Seller tidak ditemukan atau tidak aktif.');
        $v=$wpdb->get_row($wpdb->prepare("SELECT id,sku,price FROM `".PK01_DB::t('product_variants')."` WHERE id=%d AND status='active' LIMIT 1",$variant_id),ARRAY_A);
        if(!$v) throw new Exception('SKU/varian PK01 tidak ditemukan atau tidak aktif.');
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `".PK01_DB::t('seller_orders')."` WHERE marketplace=%s AND marketplace_order_no=%s AND seller_account_id=%d LIMIT 1",$marketplace,$marketplace_order_no,$seller_id));
        if($existing) throw new Exception('Nomor order marketplace tersebut sudah pernah dikirim.');
        $price=self::seller_price($seller_id,$variant_id); $total=round($price*$qty,2); if($total<=0) throw new Exception('Harga Seller PK01 belum tersedia.');
        $no=self::document_number('seller_order'); $t=PK01_DB::t('seller_orders');
        $data=['order_no'=>$no,'seller_account_id'=>$seller_id,'status'=>'requested','subtotal'=>$total,'total'=>$total,'created_at'=>self::now(),'updated_at'=>self::now(),'marketplace'=>$marketplace,'marketplace_order_no'=>$marketplace_order_no,'tracking_no'=>$tracking_no,'marketplace_sale_at'=>self::now()];
        $cols=$wpdb->get_col("DESC `{$t}`",0); $data=array_intersect_key($data,array_flip($cols));
        $wpdb->query('START TRANSACTION');
        try{
            if(!$wpdb->insert($t,$data)) throw new Exception($wpdb->last_error?:'Order Seller gagal disimpan.');
            $oid=(int)$wpdb->insert_id; $toi=PK01_DB::t('seller_order_items'); $icols=$wpdb->get_col("DESC `{$toi}`",0);
            $idata=array_intersect_key(['order_id'=>$oid,'variant_id'=>$variant_id,'seller_product_name'=>'','seller_sku'=>$seller_sku?:$v['sku'],'seller_model'=>'','seller_size'=>'','qty'=>$qty,'unit_price'=>$price,'total'=>$total],array_flip($icols));
            if(!$wpdb->insert($toi,$idata)) throw new Exception($wpdb->last_error?:'Detail Order Seller gagal disimpan.');
            $mt=PK01_DB::t('seller_marketplace_items');
            $existing_map=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$mt}` WHERE seller_account_id=%d AND marketplace=%s AND seller_sku=%s LIMIT 1",$seller_id,$marketplace,$seller_sku?:$v['sku']));
            $map_data=['seller_account_id'=>$seller_id,'marketplace'=>$marketplace,'seller_sku'=>$seller_sku?:$v['sku'],'seller_product_name'=>'','seller_model'=>'','seller_size'=>'','variant_id'=>$variant_id,'match_status'=>'matched','match_method'=>'seller_catalog','confidence'=>100,'created_at'=>self::now(),'updated_at'=>self::now()];
            if($existing_map) $wpdb->update($mt,$map_data,['id'=>(int)$existing_map]); else $wpdb->insert($mt,$map_data);
            $wpdb->query('COMMIT');
            self::log('seller_marketplace_order_submitted','seller','seller_order',(string)$oid,null,['seller_id'=>$seller_id,'marketplace'=>$marketplace,'marketplace_order_no'=>$marketplace_order_no,'tracking_no'=>$tracking_no,'variant_id'=>$variant_id]);
            return ['order_id'=>$oid,'order_no'=>$no,'total'=>$total,'status'=>'requested','tracking_no'=>$tracking_no,'variant_id'=>$variant_id,'seller_sku'=>$seller_sku?:$v['sku']];
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function seller_create_marketplace_sale($seller_id, $variant_id, $qty, $marketplace = '', $marketplace_order_no = '', $tracking_no = '', $seller_sku = '', $seller_product_name = '', $seller_model = '', $seller_size = '') {
        global $wpdb;
        $seller_id=absint($seller_id); $variant_id=absint($variant_id); $qty=max(0.0001,(float)$qty);
        $marketplace=sanitize_key($marketplace?:'marketplace');
        $marketplace_order_no=sanitize_text_field($marketplace_order_no);
        $tracking_no=sanitize_text_field($tracking_no);
        $seller_sku=sanitize_text_field($seller_sku); $seller_product_name=sanitize_text_field($seller_product_name); $seller_model=sanitize_text_field($seller_model); $seller_size=sanitize_text_field($seller_size);
        if($seller_id<=0) throw new Exception('Seller wajib dipilih.');
        if($marketplace_order_no==='') throw new Exception('Nomor pesanan marketplace wajib diisi.');
        if($tracking_no==='') throw new Exception('Nomor resi wajib diisi.');
        if($seller_sku==='' && $seller_product_name==='' && $seller_model==='' && $seller_size==='') throw new Exception('Data produk Seller wajib diisi agar barang tidak tertukar.');
        if($variant_id<=0){
            $match=self::match_seller_marketplace_product($seller_id,$marketplace,$seller_sku,$seller_product_name,$seller_model,$seller_size);
            if(($match['status']??'')!=='matched') throw new Exception('Produk Seller belum dapat dipastikan ke SKU/Varian PK01. Pilih produk PK01 yang benar lalu simpan kembali.');
            $variant_id=(int)$match['variant_id'];
        }
        $seller=$wpdb->get_row($wpdb->prepare("SELECT id,name FROM `".PK01_DB::t('sales_accounts')."` WHERE id=%d AND type='seller' AND active=1 LIMIT 1",$seller_id),ARRAY_A);
        if(!$seller) throw new Exception('Seller tidak ditemukan atau tidak aktif.');
        $variant=$wpdb->get_row($wpdb->prepare("SELECT id,price,hpp,stock FROM `".PK01_DB::t('product_variants')."` WHERE id=%d LIMIT 1",$variant_id),ARRAY_A);
        if(!$variant) throw new Exception('Produk tidak ditemukan.');
        $price=self::seller_price($seller_id,$variant_id); $total=round($price*$qty,2);
        if($total<=0) throw new Exception('Harga internal produk belum tersedia.');
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `".PK01_DB::t('seller_orders')."` WHERE marketplace=%s AND marketplace_order_no=%s AND seller_account_id=%d LIMIT 1",$marketplace,$marketplace_order_no,$seller_id));
        if($existing) throw new Exception('Nomor pesanan marketplace tersebut sudah pernah dicatat untuk Seller ini.');
        $no=self::document_number('seller_order');
        $tso=PK01_DB::t('seller_orders'); $tcols=$wpdb->get_col("DESC `{$tso}`",0);
        $data=['order_no'=>$no,'seller_account_id'=>$seller_id,'status'=>'requested','subtotal'=>$total,'total'=>$total,'created_at'=>self::now(),'updated_at'=>self::now(),'marketplace'=>$marketplace,'marketplace_order_no'=>$marketplace_order_no,'tracking_no'=>$tracking_no,'marketplace_sale_at'=>self::now()];
        $data=array_intersect_key($data,array_flip($tcols));
        $wpdb->query('START TRANSACTION');
        try{
            if(!$wpdb->insert($tso,$data)) throw new Exception($wpdb->last_error?:'Penjualan marketplace Seller gagal disimpan.');
            $oid=(int)$wpdb->insert_id;
            $toi=PK01_DB::t('seller_order_items'); $icols=$wpdb->get_col("DESC `{$toi}`",0);
            $idata=array_intersect_key(['order_id'=>$oid,'variant_id'=>$variant_id,'seller_product_name'=>$seller_product_name,'seller_sku'=>$seller_sku,'seller_model'=>$seller_model,'seller_size'=>$seller_size,'qty'=>$qty,'unit_price'=>$price,'total'=>$total],array_flip($icols));
            if(!$wpdb->insert($toi,$idata)) throw new Exception($wpdb->last_error?:'Detail penjualan Seller gagal disimpan.');
            $map=self::match_seller_marketplace_product($seller_id,$marketplace,$seller_sku,$seller_product_name,$seller_model,$seller_size);
            $mt=PK01_DB::t('seller_marketplace_items');
            $wpdb->insert($mt,[
                'seller_account_id'=>$seller_id,'marketplace'=>$marketplace,'seller_sku'=>$seller_sku,'seller_product_name'=>$seller_product_name,'seller_model'=>$seller_model,'seller_size'=>$seller_size,'variant_id'=>$variant_id,'match_status'=>'matched','match_method'=>$map['method']??'confirmed','confidence'=>(float)($map['confidence']??100),'created_at'=>self::now(),'updated_at'=>self::now()
            ]);
            $wpdb->query('COMMIT');
            self::seller_fulfill_order($oid);
            return ['order_id'=>$oid,'order_no'=>$no,'total'=>$total,'seller_id'=>$seller_id,'marketplace'=>$marketplace,'marketplace_order_no'=>$marketplace_order_no,'tracking_no'=>$tracking_no,'seller_sku'=>$seller_sku,'seller_product_name'=>$seller_product_name,'seller_model'=>$seller_model,'seller_size'=>$seller_size];
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function seller_create_order($seller_id, $variant_id, $qty) {
        global $wpdb;
        $qty = max(1, (float)$qty);
        $t_sa = PK01_DB::t('sales_accounts');
        $seller = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t_sa}` WHERE id = %d AND active = 1", (int)$seller_id), ARRAY_A);
        if (!$seller) throw new Exception('Mitra seller tidak ditemukan atau nonaktif.');

        $price = self::seller_price($seller_id, $variant_id);
        $total = round($price * $qty, 2);

        $no = self::document_number('seller_order');

        $wpdb->query('START TRANSACTION');
        try {
            $wpdb->insert(PK01_DB::t('seller_orders'), [
                'order_no'          => $no,
                'seller_account_id' => (int)$seller_id,
                'status'            => 'requested',
                'subtotal'          => $total,
                'total'             => $total,
                'created_at'        => self::now()
            ]);
            $oid = (int)$wpdb->insert_id;

            $wpdb->insert(PK01_DB::t('seller_order_items'), [
                'order_id'   => $oid,
                'variant_id' => (int)$variant_id,
                'qty'        => $qty,
                'unit_price' => $price
            ]);

            $wpdb->query('COMMIT');
            self::log('seller_order_created', 'seller', 'seller_order', $no, null, ['total' => $total]);
            return ['order_id' => $oid, 'order_no' => $no, 'total' => $total];
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }
    }

    /**
     * Kasir menerima Order Seller. Cek stok dahulu; jika kurang, buat satu kebutuhan produksi/pembelian
     * dan tahan order tanpa memotong stok/AR. Ini adalah pintu resmi dari Dashboard Seller ke operasional.
     */
    public static function seller_accept_order($order_id) {
        global $wpdb;
        $order_id=(int)$order_id;
        $tso=PK01_DB::t('seller_orders');
        $o=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tso}` WHERE id=%d LIMIT 1",$order_id),ARRAY_A);
        if(!$o) throw new Exception('Order Seller tidak ditemukan.');
        if(in_array($o['status'],['fulfilled','cancelled'],true)) throw new Exception('Order Seller sudah tidak dapat diterima pada status ini.');
        if($o['status']!=='requested') throw new Exception('Order Seller sudah diterima sebelumnya dan menunggu pemenuhan.');
        $items=$wpdb->get_results($wpdb->prepare("SELECT * FROM `".PK01_DB::t('seller_order_items')."` WHERE order_id=%d",$order_id),ARRAY_A)?:[];
        if(empty($items)) throw new Exception('Order Seller tidak memiliki detail barang.');
        $production=[];$purchase=[];
        foreach($items as $it){
            $v=$wpdb->get_row($wpdb->prepare("SELECT id,sku,stock,supply_mode FROM `".PK01_DB::t('product_variants')."` WHERE id=%d LIMIT 1",(int)$it['variant_id']),ARRAY_A);
            if(!$v) throw new Exception('SKU PK01 pada Order Seller tidak ditemukan.');
            $available=(float)$v['stock']; $need=(float)$it['qty']; $short=max(0,$need-$available);
            if($short>0){ if(($v['supply_mode']??'production')==='purchase') $purchase[]=['variant_id'=>(int)$it['variant_id'],'qty'=>$short]; else $production[]=['variant_id'=>(int)$it['variant_id'],'qty'=>$short]; }
        }
        if($production || $purchase){
            foreach($production as $x){
                $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `".PK01_DB::t('jobs')."` WHERE source_order_id=%d AND source_type='seller_order' AND status NOT IN ('completed','cancelled') AND product_id=(SELECT product_id FROM `".PK01_DB::t('product_variants')."` WHERE id=%d)",$order_id,$x['variant_id']));
                if(!$exists) self::create_production_job('SELLER-'.$o['order_no'].'-'.$x['variant_id'],$x['variant_id'],$x['qty'],'','',current_time('Y-m-d'),'Kekurangan stok untuk Order Seller '.$o['order_no'].'.','high',$order_id,'seller_order');
            }
            foreach($purchase as $x){
                $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `".PK01_DB::t('finished_product_purchase_requests')."` WHERE source_order_id=%d AND variant_id=%d AND status NOT IN ('received','cancelled')",$order_id,$x['variant_id']));
                if(!$exists) self::create_finished_purchase_request($x['variant_id'],$x['qty'],$order_id,'Kekurangan stok untuk Order Seller '.$o['order_no'].'.');
            }
            $status=$production?'awaiting_production':'awaiting_purchase';
            if($production && $purchase) $status='awaiting_production';
            $wpdb->update($tso,['status'=>$status,'updated_at'=>self::now()],['id'=>$order_id]);
            self::log('seller_order_accepted_waiting_supply','seller','seller_order',(string)$order_id,null,['status'=>$status,'production'=>$production,'purchase'=>$purchase]);
            return ['ok'=>true,'production_required'=>!empty($production),'purchase_required'=>!empty($purchase),'shortage'=>array_sum(array_column(array_merge($production,$purchase),'qty')),'status'=>$status];
        }
        self::seller_fulfill_order($order_id);
        return ['ok'=>true,'production_required'=>false,'purchase_required'=>false,'shortage'=>0,'status'=>'fulfilled'];
    }

    public static function seller_fulfill_order($order_id) {
        global $wpdb;
        $t_so = PK01_DB::t('seller_orders');
        $o = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t_so}` WHERE id = %d", (int)$order_id), ARRAY_A);
        if (!$o || $o['status'] === 'fulfilled') throw new Exception('Pesanan seller tidak ditemukan atau sudah dipenuhi.');

        $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . PK01_DB::t('seller_order_items') . " WHERE order_id = %d", (int)$order_id), ARRAY_A) ?: [];
        if(empty($items)) throw new Exception('Order Seller tidak memiliki detail barang.');
        $last_seller_sale_id=0;

        self::guard_entry('seller_fulfillment', (int)$order_id, ['seller_id'=>(int)$o['seller_account_id']]);
        $wpdb->query('START TRANSACTION');
        try {
            foreach ($items as $it) {
                $available=(float)$wpdb->get_var($wpdb->prepare("SELECT stock FROM ".PK01_DB::t('product_variants')." WHERE id=%d FOR UPDATE",(int)$it['variant_id']));
                if($available+0.000001 < (float)$it['qty']) throw new Exception('Stok produk tidak mencukupi untuk memenuhi pesanan seller.');
                // Potong stok gudang satu kali dan catat mutasinya.
                $wpdb->query($wpdb->prepare(
                    "UPDATE " . PK01_DB::t('product_variants') . " SET stock = stock - %f, updated_at=%s WHERE id = %d",
                    (float)$it['qty'], self::now(), (int)$it['variant_id']
                ));
                $wpdb->insert(PK01_DB::t('stock_transactions'),[
                    'stock_type'=>'finished','item_id'=>(int)$it['variant_id'],'variant_id'=>(int)$it['variant_id'],
                    'qty'=>(float)$it['qty'],'direction'=>'out','reference_type'=>'seller_order',
                    'reference_id'=>(int)$order_id,'reference_no'=>$o['order_no'],
                    'notes'=>'Stok keluar untuk pesanan seller','created_by'=>get_current_user_id(),'created_at'=>self::now()
                ]);
                $v=$wpdb->get_row($wpdb->prepare("SELECT hpp FROM ".PK01_DB::t('product_variants')." WHERE id=%d",(int)$it['variant_id']),ARRAY_A);
                $wpdb->insert(PK01_DB::t('seller_sales'),[
                    'seller_account_id'=>(int)$o['seller_account_id'],'order_id'=>(int)$order_id,
                    'variant_id'=>(int)$it['variant_id'],'qty'=>(float)$it['qty'],'hpp'=>(float)($v['hpp']??0),
                    'unit_price'=>(float)$it['unit_price'],'total'=>(float)$it['unit_price']*(float)$it['qty'],'sold_at'=>self::now(),
                    'source_type'=>'seller_order','marketplace'=>$o['marketplace']??'','marketplace_order_no'=>$o['marketplace_order_no']??'','tracking_no'=>$o['tracking_no']??''
                ]);
                if($wpdb->last_error) throw new Exception($wpdb->last_error);
                $last_seller_sale_id=(int)$wpdb->insert_id;
            }

            // Penjualan Seller marketplace membawa resi yang sama ke modul Logistik sehingga
            // status pengiriman dan retur dapat dicari hanya dari resi/order marketplace.
            if(!empty($o['tracking_no'])){
                $has_ship=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `".PK01_DB::t('shipments')."` WHERE seller_sale_id=%d",$last_seller_sale_id));
                if(!$has_ship) self::create_shipment($o['marketplace']?:'marketplace',$o['tracking_no'],'','REG',0,$last_seller_sale_id);
            }

            // Setelah penjualan seller nyata tercatat, evaluasi target bonus aktif periode berjalan.
            $target_rows=$wpdb->get_col($wpdb->prepare("SELECT id FROM ".PK01_DB::t('seller_targets')." WHERE seller_account_id=%d AND status='active' AND period_key=%s",(int)$o['seller_account_id'],substr(self::now(),0,7)));
            foreach((array)$target_rows as $target_id){ self::evaluate_seller_target_bonus((int)$target_id); }

            // Invoice AR seller dibuat satu kali melalui Engine canonical.
            self::create_seller_invoice((int)$o['seller_account_id'],(float)$o['total'],'','Seller order '.$o['order_no'],(int)$order_id);
            $wpdb->update($t_so, ['status' => 'fulfilled'], ['id' => $order_id]);
            $wpdb->query('COMMIT');
            self::log('seller_order_fulfilled', 'seller', 'seller_order', (string)$order_id, null, ['status' => 'fulfilled']);
            return true;
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            if (class_exists('PK01_Duplicate_Guard')) PK01_Duplicate_Guard::release('seller_fulfillment',(int)$order_id);
            throw $e;
        }
    }

    /**
     * Setoran Kasir -> Keuangan.
     * CASH: hanya membuat dokumen pending; kas belum dipindahkan sampai Keuangan menerima.
     * TRANSFER: hanya bukti serah-terima/verifikasi jika pembayaran sudah tercatat di Buku Kas;
     * penerimaan tidak boleh membuat kas masuk kedua.
     */
    /** Akun kas per kasir agar 4/5+ kasir dapat direkonsiliasi terpisah. */
    public static function cashier_account($user_id=0){
        $uid=absint($user_id?:get_current_user_id());
        if($uid<=0) return 'Kas Tunai Toko';
        $u=get_userdata($uid);
        if(!$u || !in_array('pk01_kasir',(array)$u->roles,true)) return 'Kas Tunai Toko';
        $label=sanitize_text_field($u->display_name?:$u->user_login?:('User '.$uid));
        return 'Kasir - '.$label.' (#'.$uid.')';
    }

    public static function approve_cashier_deposit($deposit_id,$note=''){
        global $wpdb;
        $id=absint($deposit_id); $role=class_exists('PK01_Authorization')?PK01_Authorization::effective_role():'';
        if(!$id) throw new Exception('Setoran tidak valid.');
        if(get_current_user_id()<=0 || (!current_user_can('manage_options') && !in_array($role,['pk01_admin','pk01_owner','pk01_keuangan'],true))) throw new Exception('Hanya Keuangan/Admin yang dapat menyetujui setoran.');
        $t=PK01_DB::t('cashier_deposits'); $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$id),ARRAY_A);
        if(!$r) throw new Exception('Setoran kasir tidak ditemukan.');
        if(($r['status']??'')!=='submitted') throw new Exception('Setoran hanya dapat disetujui dari status Menunggu Persetujuan.');
        if((int)$r['cashier_user_id']===(int)get_current_user_id()) throw new Exception('Maker tidak boleh menyetujui setoran yang dibuat sendiri.');
        $ok=$wpdb->update($t,['status'=>'approved','approved_at'=>self::now(),'approved_by'=>get_current_user_id(),'approval_note'=>sanitize_textarea_field($note)],['id'=>$id]);
        if($ok===false) throw new Exception($wpdb->last_error?:'Persetujuan setoran gagal.');
        self::log('cashier_deposit_approved','finance','cashier_deposit',(string)$id,null,['amount'=>(float)$r['amount'],'approved_by'=>get_current_user_id()]);
        return true;
    }

    public static function submit_cashier_deposit($amount,$deposit_type='cash',$source_account='Kas Tunai Toko',$destination_account='Kas/Bank Keuangan',$payment_method='Kas Tunai',$reference_no='',$notes='',$seller_account_id=0,$invoice_id=0,$order_id=0){
        global $wpdb;
        $amount=round((float)$amount,2); $deposit_type=in_array($deposit_type,['cash','transfer'],true)?$deposit_type:'cash';
        $source_account=sanitize_text_field($source_account?:'Kas Tunai Toko'); $destination_account=sanitize_text_field($destination_account?:'Kas/Bank Keuangan');
        $payment_method=sanitize_text_field($payment_method?:($deposit_type==='cash'?'Kas Tunai':'Transfer Bank')); $reference_no=sanitize_text_field($reference_no); $notes=sanitize_textarea_field($notes);
        $seller_account_id=absint($seller_account_id); $invoice_id=absint($invoice_id); $order_id=absint($order_id);
        if($amount<=0) throw new Exception('Nominal setoran harus lebih besar dari Rp 0.');
        if($deposit_type==='cash' && class_exists('PK01_Authorization') && PK01_Authorization::effective_role()==='pk01_kasir') $source_account=self::cashier_account(get_current_user_id());
        if($source_account===$destination_account && $deposit_type==='cash') throw new Exception('Sumber dan tujuan kas tidak boleh sama.');
        $is_seller_payment=($seller_account_id>0 || $invoice_id>0);
        if($invoice_id>0){
            $it=PK01_DB::t('seller_invoices'); $inv=$wpdb->get_row($wpdb->prepare("SELECT id,seller_account_id,total FROM `{$it}` WHERE id=%d",$invoice_id),ARRAY_A);
            if(!$inv) throw new Exception('Invoice Seller tidak ditemukan.');
            if(!$seller_account_id) $seller_account_id=(int)$inv['seller_account_id'];
            if((int)$inv['seller_account_id']!==$seller_account_id) throw new Exception('Seller pada invoice tidak cocok dengan Seller setoran.');
            $is_seller_payment=true;
        }
        if($is_seller_payment){
            if($seller_account_id<=0) throw new Exception('Seller wajib dipilih untuk pembayaran Seller. Nomor invoice boleh dikosongkan.');
            if($deposit_type==='transfer' && $reference_no==='') throw new Exception('Transfer/QRIS Seller wajib memiliki referensi atau bukti transfer.');
            if($deposit_type==='transfer' && stripos($payment_method,'transfer')===false && stripos($payment_method,'qris')===false) throw new Exception('Metode transfer Seller harus Transfer Bank atau QRIS.');
            $it=PK01_DB::t('seller_invoices'); $pt=PK01_DB::t('seller_payments'); $cd=PK01_DB::t('cashier_deposits');
            $open_ar=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(i.total),0)-COALESCE((SELECT SUM(p.amount) FROM `{$pt}` p JOIN `{$it}` ii ON ii.id=p.invoice_id WHERE ii.seller_account_id=%d),0) FROM `{$it}` i WHERE i.seller_account_id=%d AND i.total>0",$seller_account_id,$seller_account_id));
            $pending=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(d.amount),0) FROM `{$cd}` d WHERE d.seller_account_id=%d AND d.status IN ('submitted','approved')",$seller_account_id));
            if($amount>$open_ar-$pending+0.01) throw new Exception('Nominal pembayaran melebihi total piutang Seller yang masih terbuka setelah memperhitungkan setoran yang masih menunggu persetujuan.');
            if($invoice_id>0){
                $inv_total=(float)$wpdb->get_var($wpdb->prepare("SELECT total FROM `{$it}` WHERE id=%d",$invoice_id));
                $inv_paid=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$pt}` WHERE invoice_id=%d",$invoice_id));
                $inv_pending=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$cd}` WHERE invoice_id=%d AND status IN ('submitted','approved')",$invoice_id));
                if($amount>max(0,$inv_total-$inv_paid-$inv_pending)+0.01) throw new Exception('Nominal melebihi sisa invoice yang dipilih setelah memperhitungkan setoran tertunda.');
            }
        } elseif($deposit_type==='transfer' && $reference_no==='') {
            throw new Exception('Setoran transfer wajib memiliki nomor referensi/bukti transfer.');
        }
        $t=PK01_DB::t('cashier_deposits'); if(!$t) throw new Exception('Tabel setoran kasir belum tersedia. Jalankan perbaikan database PK01.');
        $deposit_no=self::document_number('cashier_deposit','SETOR',6,'{PREFIX}/{YYYY}{MM}/{SEQ}');
        $wpdb->query('START TRANSACTION');
        try{
            if($reference_no!==''){
                $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE reference_no=%s AND deposit_type='transfer' LIMIT 1",$reference_no));
                if($exists) throw new Exception('Referensi transfer tersebut sudah pernah dipakai. Sistem menolak pembayaran ganda.');
            }
            $data=['deposit_no'=>$deposit_no,'cashier_user_id'=>get_current_user_id(),'seller_account_id'=>$seller_account_id,'invoice_id'=>$invoice_id,'order_id'=>$order_id,'deposit_type'=>$deposit_type,'source_account'=>$source_account,'destination_account'=>$destination_account,'amount'=>$amount,'payment_method'=>$payment_method,'reference_no'=>$reference_no,'notes'=>$notes,'status'=>'submitted','submitted_at'=>self::now(),'created_at'=>self::now()];
            $cols=$wpdb->get_col("DESC `{$t}`",0); $data=array_intersect_key($data,array_flip($cols));
            if(!$wpdb->insert($t,$data)) throw new Exception($wpdb->last_error?:'Setoran kasir gagal disimpan.');
            $id=(int)$wpdb->insert_id;
            // Uang tunai Seller secara fisik sudah berada di laci Kasir sejak pengajuan.
            // AR belum berubah. Jika ditolak, penerimaan fisik ini akan dibalik.
            if($deposit_type==='cash' && $seller_account_id>0){
                self::cash('in',$amount,'Penerimaan Tunai Seller','seller_cash_pending',$id,'Uang tunai Seller diterima Kasir; AR menunggu persetujuan Keuangan',$source_account,$deposit_no.'-SELLER-IN');
            }
            self::log('cashier_deposit_submitted','finance','cashier_deposit',(string)$id,null,['deposit_no'=>$deposit_no,'amount'=>$amount,'type'=>$deposit_type,'reference_no'=>$reference_no,'seller_account_id'=>$seller_account_id,'invoice_id'=>$invoice_id]);
            $wpdb->query('COMMIT'); return ['id'=>$id,'deposit_no'=>$deposit_no,'status'=>'submitted'];
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function receive_cashier_deposit($deposit_id,$destination_account='') {
        global $wpdb;
        $id=absint($deposit_id); if($id<=0) throw new Exception('Setoran tidak valid.');
        $t=PK01_DB::t('cashier_deposits'); $wpdb->query('START TRANSACTION');
        try{
            $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$r) throw new Exception('Setoran kasir tidak ditemukan.');
            if(($r['status']??'')!=='approved') throw new Exception('Setoran belum disetujui Keuangan.');
            if((int)($r['approved_by']??0)===(int)get_current_user_id()) throw new Exception('Checker yang menyetujui tidak boleh menjadi pembuku/receiver setoran yang sama.');
            $dest=sanitize_text_field($destination_account?:($r['destination_account']?:'Kas/Bank Keuangan')); $amount=round((float)$r['amount'],2); $type=sanitize_key($r['deposit_type']??'cash');
            if($type==='cash'){
                $source=sanitize_text_field($r['source_account']?:'Kas Tunai Toko'); if($source===$dest) throw new Exception('Sumber dan tujuan kas tidak boleh sama.');
                $balance=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN amount ELSE -amount END),0) FROM `".PK01_DB::t('cash_ledger')."` WHERE account=%s",$source));
                if($balance+0.01<$amount) throw new Exception('Saldo sumber kas tidak mencukupi.');
                $ref=$r['deposit_no']; self::cash('out',$amount,'Transfer Setoran Kasir','cashier_deposit_transfer',$id,'Setoran kasir diserahkan ke Keuangan',$source,$ref.'-OUT');
                if((int)($r['seller_account_id']??0)>0) self::allocate_seller_payment_from_deposit($r);
                self::cash('in',$amount,(int)($r['seller_account_id']??0)>0?'Penerimaan Pembayaran Seller':'Transfer Setoran Kasir','cashier_deposit_transfer',$id,(int)($r['seller_account_id']??0)>0?'Pembayaran tunai Seller diterima Keuangan':'Setoran kasir diterima Keuangan',$dest,$ref.'-IN');
            } elseif($type==='transfer'){
                if((int)($r['seller_account_id']??0)<=0) throw new Exception('Seller wajib tersedia untuk transfer.');
                self::allocate_seller_payment_from_deposit($r);
                self::cash('in',$amount,'Setoran Piutang Seller','cashier_deposit_transfer',$id,'Transfer Seller diterima Keuangan',$dest,$r['reference_no']?:$r['deposit_no']);
            } else throw new Exception('Jenis setoran tidak dikenali.');
            $upd=['status'=>'received','destination_account'=>$dest,'received_at'=>self::now(),'received_by'=>get_current_user_id()]; $cols=$wpdb->get_col("DESC `{$t}`",0); $upd=array_intersect_key($upd,array_flip($cols));
            if($wpdb->update($t,$upd,['id'=>$id])===false) throw new Exception($wpdb->last_error?:'Status setoran gagal diperbarui.');
            self::log('cashier_deposit_received','finance','cashier_deposit',(string)$id,null,['amount'=>$amount,'type'=>$type,'destination_account'=>$dest,'seller_account_id'=>(int)($r['seller_account_id']??0)]);
            $wpdb->query('COMMIT'); return true;
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    private static function allocate_seller_payment_from_deposit($deposit){
        global $wpdb;
        $id=absint($deposit['id']??0); $seller_id=absint($deposit['seller_account_id']??0); $amount=round((float)($deposit['amount']??0),2);
        if($id<=0||$seller_id<=0||$amount<=0) throw new Exception('Data pembayaran Seller tidak lengkap.');
        $tp=PK01_DB::t('seller_payments'); $ti=PK01_DB::t('seller_invoices');
        $already=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tp}` WHERE deposit_id=%d",$id));
        if($already>0.009) throw new Exception('Setoran Seller ini sudah pernah memotong AR. Sistem menolak potongan kedua.');
        $remaining=$amount; $invoice_id=absint($deposit['invoice_id']??0); $alloc=[];
        if($invoice_id>0){
            $done=self::finalize_seller_payment_to_invoice($invoice_id,$remaining,$deposit['payment_method']?:'Transfer Bank',$id,$deposit['reference_no']?:$deposit['deposit_no']);
            if($done>0){$alloc[]=['invoice_id'=>$invoice_id,'amount'=>$done];$remaining=round($remaining-$done,2);}
            if($remaining>0.009) throw new Exception('Nominal setoran melebihi sisa invoice yang dipilih.');
        }else{
            $invs=$wpdb->get_results($wpdb->prepare("SELECT i.id,i.total,COALESCE((SELECT SUM(p.amount) FROM `{$tp}` p WHERE p.invoice_id=i.id),0) paid FROM `{$ti}` i WHERE i.seller_account_id=%d AND i.total>0 ORDER BY (i.due_date IS NULL) ASC,i.due_date ASC,i.created_at ASC,i.id ASC FOR UPDATE",$seller_id),ARRAY_A)?:[];
            foreach($invs as $inv){
                if($remaining<=0.009) break; $due=max(0,(float)$inv['total']-(float)$inv['paid']); if($due<=0.009) continue;
                $apply=min($remaining,$due); $done=self::finalize_seller_payment_to_invoice((int)$inv['id'],$apply,$deposit['payment_method']?:'Transfer Bank',$id,$deposit['reference_no']?:$deposit['deposit_no']);
                if($done>0){$alloc[]=['invoice_id'=>(int)$inv['id'],'amount'=>$done];$remaining=round($remaining-$done,2);}
            }
            if($remaining>0.009) throw new Exception('Pembayaran melebihi seluruh piutang Seller yang terbuka. Sistem menolak kelebihan.');
        }
        $alloc_text=[]; foreach($alloc as $a){$ino=$wpdb->get_var($wpdb->prepare("SELECT invoice_no FROM `{$ti}` WHERE id=%d",$a['invoice_id']));$alloc_text[]=($ino?:('#'.$a['invoice_id'])).' Rp '.number_format($a['amount'],2,',','.');}
        $note=trim((string)($deposit['notes']??'')); $note.=($note?' | ':'').'Alokasi AR: '.implode(', ',$alloc_text);
        $cols=$wpdb->get_col("DESC `".PK01_DB::t('cashier_deposits')."`",0); if(in_array('notes',$cols,true)) $wpdb->update(PK01_DB::t('cashier_deposits'),['notes'=>sanitize_textarea_field($note)],['id'=>$id]);
        return $alloc;
    }

    public static function reject_cashier_deposit($deposit_id,$reason=''){
        global $wpdb; $id=absint($deposit_id); $reason=sanitize_textarea_field($reason);
        if($id<=0||$reason==='') throw new Exception('Alasan penolakan wajib diisi.');
        $t=PK01_DB::t('cashier_deposits'); $wpdb->query('START TRANSACTION');
        try{
            $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$r) throw new Exception('Setoran tidak ditemukan.'); if(!in_array(($r['status']??''),['submitted','approved'],true)) throw new Exception('Setoran sudah diproses.');
            if(($r['deposit_type']??'')==='cash' && (int)($r['seller_account_id']??0)>0){
                $source=sanitize_text_field($r['source_account']?:'Kas Tunai Toko'); $ref=$r['deposit_no'].'-SELLER-IN';
                $rev=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `".PK01_DB::t('cash_ledger')."` WHERE direction='out' AND reference_type='seller_cash_reversal' AND reference_no=%s",$ref));
                if($rev<=0.009) self::cash('out',(float)$r['amount'],'Pengembalian Tunai Seller','seller_cash_reversal',$id,'Pengembalian pembayaran tunai Seller karena setoran ditolak',$source,$ref);
            }
            $ok=$wpdb->update($t,['status'=>'rejected','rejected_at'=>self::now(),'rejected_by'=>get_current_user_id(),'rejection_reason'=>$reason],['id'=>$id]); if($ok===false) throw new Exception($wpdb->last_error?:'Setoran gagal ditolak.');
            self::log('cashier_deposit_rejected','finance','cashier_deposit',(string)$id,null,['reason'=>$reason]); $wpdb->query('COMMIT'); return true;
        }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    /**
     * Pembayaran Seller HARUS masuk melalui cashier_deposits (maker-checker).
     * Tidak ada lagi entry langsung dari menu Seller/Admin yang sekaligus memotong AR dan kas.
     */
    public static function seller_pay_balance($seller_id, $amount, $payment_method = 'Transfer Bank') {
        throw new Exception('Pembayaran Seller wajib melalui Setoran Kasir → Persetujuan Keuangan. Entry langsung dinonaktifkan untuk mencegah AR dan kas terpotong ganda.');
    }

    public static function seller_pay_invoice($invoice_id, $amount, $payment_method = 'Transfer Bank') {
        throw new Exception('Pembayaran Invoice Seller wajib melalui Setoran Kasir → Persetujuan Keuangan. Entry langsung dinonaktifkan untuk mencegah pembayaran ganda.');
    }

    /** Finalizer internal: hanya dipanggil setelah cashier_deposit berstatus approved. */
    private static function finalize_seller_payment_to_invoice($invoice_id, $amount, $payment_method='Transfer Bank', $deposit_id=0, $external_reference='') {
        global $wpdb;
        $invoice_id=absint($invoice_id); $amount=round((float)$amount,2); $deposit_id=absint($deposit_id);
        if($invoice_id<=0 || $amount<=0) throw new Exception('Alokasi pembayaran Seller tidak valid.');
        $ti=PK01_DB::t('seller_invoices'); $tp=PK01_DB::t('seller_payments');
        $inv=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$ti}` WHERE id=%d FOR UPDATE",$invoice_id),ARRAY_A);
        if(!$inv) throw new Exception('Invoice Seller tidak ditemukan saat pembukuan.');
        if($deposit_id>0){
            $already=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$tp}` WHERE deposit_id=%d AND invoice_id=%d LIMIT 1",$deposit_id,$invoice_id));
            if($already) return 0.0;
        }
        $paid=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tp}` WHERE invoice_id=%d",$invoice_id));
        $remain=max(0,(float)$inv['total']-$paid);
        if($remain<=0.009) return 0.0;
        if($amount>$remain+0.01) $amount=$remain;
        if($amount<=0) return 0.0;
        $natural=($deposit_id>0 ? 'deposit:'.$deposit_id.':invoice:'.$invoice_id : 'invoice:'.$invoice_id.':manual-blocked');
        self::guard_entry('seller_payment_allocation',$natural,['invoice_id'=>$invoice_id,'deposit_id'=>$deposit_id,'amount'=>$amount,'reference'=>$external_reference]);
        $cols=$wpdb->get_col("DESC `{$tp}`",0);
        $data=['invoice_id'=>$invoice_id,'order_id'=>(int)($inv['order_id']??0),'amount'=>$amount,'payment_method'=>sanitize_text_field($payment_method?:'Transfer Bank'),'paid_at'=>self::now(),'created_by'=>get_current_user_id(),'deposit_id'=>$deposit_id,'external_reference'=>sanitize_text_field($external_reference)];
        $data=array_intersect_key($data,array_flip($cols));
        if(!$wpdb->insert($tp,$data)) throw new Exception($wpdb->last_error?:'Pembayaran Seller gagal disimpan.');
        $new_paid=$paid+$amount; $new_status=($new_paid+0.01 >= (float)$inv['total'])?'paid':'partial';
        $wpdb->update($ti,['status'=>$new_status,'paid_at'=>$new_status==='paid'?self::now():null],['id'=>$invoice_id]);
        return $amount;
    }

    /**
     * Alokasi pembayaran KASIR ke AR Seller tanpa membuat kas masuk kedua.
     * Kas sudah dicatat oleh transaksi penjualan utama; method ini hanya
     * membuat/memperbarui invoice AR seller dan payment allocation-nya.
     */
    public static function apply_cashier_payment_to_seller_ar($order_id, $amount, $payment_method = 'Kas Tunai Toko') {
        global $wpdb;
        $order_id = (int)$order_id;
        $amount = round((float)$amount, 2);
        if ($order_id <= 0 || $amount < 0) throw new Exception('Referensi pembayaran seller tidak valid.');

        $orders = PK01_DB::t('sales_orders');
        $invoices = PK01_DB::t('seller_invoices');
        $payments = PK01_DB::t('seller_payments');
        $order = $wpdb->get_row($wpdb->prepare("SELECT id, seller_id, total_amount FROM `{$orders}` WHERE id=%d FOR UPDATE", $order_id), ARRAY_A);
        if (!$order || (int)$order['seller_id'] <= 0) return 0.0;

        $seller_id = (int)$order['seller_id'];
        $total = round((float)$order['total_amount'], 2);
        if ($total <= 0) return 0.0;

        // Satu invoice AR per cashier sale. Tidak boleh membuat invoice ganda.
        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$invoices}` WHERE order_id=%d AND seller_account_id=%d ORDER BY id ASC LIMIT 1 FOR UPDATE", $order_id, $seller_id), ARRAY_A);
        if (!$invoice) {
            $invoice_id = self::create_seller_invoice($seller_id, $total, '', 'AR dari transaksi kasir #'.$order_id, $order_id);
            $paid_before = 0.0;
            $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$invoices}` WHERE id=%d FOR UPDATE",$invoice_id),ARRAY_A);
        } else {
            $invoice_id = (int)$invoice['id'];
            $paid_before = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$payments}` WHERE invoice_id=%d", $invoice_id));
        }

        $remaining = max(0, $total - $paid_before);
        $apply = min($amount, $remaining);

        if ($apply > 0) {
            self::guard_entry(
                'seller_ar_cashier_payment',
                $order_id.'|'.$invoice_id.'|'.number_format($apply,2,'.',''),
                ['order_id'=>$order_id,'invoice_id'=>$invoice_id,'seller_id'=>$seller_id,'amount'=>$apply]
            );
            if (!$wpdb->insert($payments, [
                'invoice_id'     => $invoice_id,
                'order_id'       => $order_id,
                'amount'         => $apply,
                'payment_method' => sanitize_text_field($payment_method ?: 'Kas Tunai Toko'),
                'paid_at'        => self::now(),
                'created_by'     => get_current_user_id()
            ])) throw new Exception($wpdb->last_error ?: 'Gagal mencatat potongan AR seller.');
        }

        $new_paid = $paid_before + $apply;
        $new_status = ($new_paid + 0.01 >= $total) ? 'paid' : ($new_paid > 0 ? 'partial' : 'unpaid');
        $wpdb->update($invoices, [
            'status'  => $new_status,
            'paid_at' => $new_status === 'paid' ? self::now() : null
        ], ['id'=>$invoice_id]);

        self::log('seller_ar_reduced_by_cashier', 'finance', 'seller_invoice', (string)$invoice_id, ['remaining_before'=>max(0,$total-$paid_before)], ['order_id'=>$order_id,'seller_id'=>$seller_id,'applied'=>$apply,'remaining_after'=>max(0,$total-$new_paid),'payment_method'=>$payment_method]);
        return $apply;
    }

    public static function create_seller_invoice($seller_id, $total, $due_date = '', $notes = '', $order_id = 0, $invoice_no = '') {
        global $wpdb;
        $seller_id=absint($seller_id); $total=round((float)$total,2); $order_id=absint($order_id);
        if($seller_id<=0||$total<=0) throw new Exception('Seller dan nominal invoice wajib valid.');
        if($order_id<=0) throw new Exception('Tagihan Seller tidak boleh dibuat manual. Tagihan harus lahir dari penjualan/order Seller yang nyata.');
        $t=PK01_DB::t('seller_invoices');
        if($order_id>0){$existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE order_id=%d AND seller_account_id=%d LIMIT 1",$order_id,$seller_id));if($existing)return (int)$existing;}
        $invoice_no=$invoice_no?:self::document_number('seller_invoice');
        // Jika tanggal jatuh tempo tidak diberikan, gunakan termin Seller yang tersimpan.
        if (!$due_date) {
            $seller_term_days=(int)$wpdb->get_var($wpdb->prepare("SELECT payment_term_days FROM `".PK01_DB::t('sales_accounts')."` WHERE id=%d LIMIT 1",$seller_id));
            $due_date = $seller_term_days > 0 ? wp_date('Y-m-d', current_time('timestamp') + ($seller_term_days * DAY_IN_SECONDS)) : current_time('Y-m-d');
        }
        $cols=$wpdb->get_col("DESC `{$t}`",0);
        $data=['seller_account_id'=>$seller_id,'order_id'=>$order_id,'invoice_no'=>sanitize_text_field($invoice_no),'total'=>$total,'original_total'=>$total,'return_adjustment_total'=>0,'status'=>'unpaid','due_date'=>$due_date?sanitize_text_field($due_date):null,'notes'=>sanitize_textarea_field($notes),'created_at'=>self::now()];
        $data=array_intersect_key($data,array_flip($cols));
        self::guard_entry('seller_invoice',($order_id>0?'order:'.$order_id:'invoice:'.$invoice_no),$data);
        if(!$wpdb->insert($t,$data)) throw new Exception($wpdb->last_error?:'Invoice seller gagal dibuat.');
        return (int)$wpdb->insert_id;
    }

    public static function pay_seller_order_commission($order_id, $amount = 0, $payment_method = 'Transfer Bank') {
        global $wpdb;
        $order_id=absint($order_id); $t=PK01_DB::t('sales_orders');
        $o=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d FOR UPDATE",$order_id),ARRAY_A);
        if(!$o) throw new Exception('Pesanan komisi seller tidak ditemukan.');
        $due=max(0,(float)$o['commission']);
        $amount=$amount>0?round((float)$amount,2):$due;
        if($due<=0) throw new Exception('Pesanan ini tidak memiliki komisi seller.');
        if($amount>$due+0.01) throw new Exception('Nominal komisi melebihi hak seller.');
        if(($o['commission_status']??'')==='paid') throw new Exception('Komisi seller sudah dibayarkan.');
        self::guard_entry('seller_order_commission_payment',$order_id.'|'.number_format($amount,2,'.',''),['order_id'=>$order_id,'amount'=>$amount]);
        self::cash('out',$amount,'Komisi Penjualan Seller','seller_commission',$order_id,'Pencairan komisi seller order #'.$order_id,sanitize_text_field($payment_method?:'Transfer Bank'),'COMM-ORD-'.$order_id);
        $wpdb->update($t,['commission_status'=>'paid'],['id'=>$order_id]);
        self::log('seller_commission_paid','finance','sales_order',(string)$order_id,null,['amount'=>$amount]);
        return $amount;
    }

    /**
     * Catat settlement marketplace manual.
     * owner_type=company: uang benar-benar masuk rekening perusahaan -> masuk kas/settlement marketplace.
     * owner_type=seller: uang masuk rekening Seller -> hanya monitoring payout; tagihan berasal dari penjualan PK01, bukan payout.
     */
    public static function record_marketplace_payout($channel_id,$payout_date,$order_count,$gross,$deductions,$account_id='Rekening Bank Resmi',$status='completed',$notes='',$payout_no='',$owner_type='company',$seller_account_id=0) {
        global $wpdb;
        $channel_id=sanitize_key($channel_id?:'marketplace');
        $payout_date=sanitize_text_field($payout_date?:current_time('Y-m-d'));
        $order_count=max(1,absint($order_count));
        $gross=round((float)$gross,2); $deductions=max(0,round((float)$deductions,2)); $net=max(0,round($gross-$deductions,2));
        $owner_type=in_array($owner_type,['company','seller'],true)?$owner_type:'company';
        $seller_account_id=absint($seller_account_id);
        if($gross<=0||$deductions>$gross) throw new Exception('Nominal payout marketplace tidak valid.');
        if($owner_type==='seller' && $seller_account_id<=0) throw new Exception('Pilih Seller karena payout ini masuk ke rekening Seller.');
        if($owner_type==='seller'){
            $seller=$wpdb->get_row($wpdb->prepare("SELECT id,name,active FROM `".PK01_DB::t('sales_accounts')."` WHERE id=%d AND type='seller' LIMIT 1",$seller_account_id),ARRAY_A);
            if(!$seller || empty($seller['active'])) throw new Exception('Seller tidak ditemukan atau tidak aktif.');
        }
        $payout_no=sanitize_text_field($payout_no?:self::document_number('payout'));
        $t=PK01_DB::t('marketplace_payouts');
        $cols=$wpdb->get_col("DESC `{$t}`",0);
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE payout_no=%s LIMIT 1",$payout_no));
        if($existing) return (int)$existing;
        $wpdb->query('START TRANSACTION');
        try {
            self::guard_entry('marketplace_payout',$payout_no,['gross'=>$gross,'deductions'=>$deductions,'net'=>$net,'owner_type'=>$owner_type,'seller_account_id'=>$seller_account_id]);
            $data=['payout_no'=>$payout_no,'channel_id'=>$channel_id,'payout_date'=>$payout_date,'order_count'=>$order_count,'gross'=>$gross,'deductions'=>$deductions,'net_received'=>$net,'account_id'=>sanitize_text_field($account_id?:'Rekening Bank Resmi'),'status'=>sanitize_key($status?:'completed'),'notes'=>sanitize_textarea_field($notes),'created_by'=>get_current_user_id(),'created_at'=>$payout_date.' '.current_time('H:i:s'),'owner_type'=>$owner_type,'seller_account_id'=>$seller_account_id,'seller_invoice_id'=>0];
            $data=array_intersect_key($data,array_flip($cols));
            if(!$wpdb->insert($t,$data)) throw new Exception($wpdb->last_error?:'Payout marketplace gagal disimpan.');
            $id=(int)$wpdb->insert_id;
            if($status==='completed'){
                if($owner_type==='company'){
                    // Hanya settlement milik perusahaan yang masuk kas perusahaan.
                    if($net>0) self::cash('in',$net,'Payout Marketplace','marketplace_payout',$id,'Pencairan marketplace '.$payout_no,sanitize_text_field($account_id?:'Rekening Bank Resmi'),$payout_no);
                    // Fee marketplace adalah potongan dari dana yang diterima, bukan kas keluar kedua.
                    if($deductions>0){
                        $tc=PK01_DB::t('operational_costs');
                        $cc=$wpdb->get_col("DESC `{$tc}`",0);
                        $cost=['cost_date'=>$payout_date,'category'=>'Fee Layanan Marketplace','amount'=>$deductions,'payment_method'=>'Potongan Saldo '.ucfirst($channel_id),'reference_no'=>$payout_no,'description'=>'Potongan biaya marketplace '.$payout_no,'created_by'=>get_current_user_id(),'created_at'=>$payout_date.' '.current_time('H:i:s')];
                        $cost=array_intersect_key($cost,array_flip($cc));
                        if(!$wpdb->insert($tc,$cost)) throw new Exception($wpdb->last_error?:'Biaya marketplace gagal disinkronkan.');
                    }
                } else {
                    // Payout Seller hanya menjadi referensi bahwa marketplace Seller sudah mencairkan dana.
                    // TIDAK membuat tagihan berdasarkan payout. Tagihan sudah berasal dari penjualan PK01.
                    // TIDAK masuk kas perusahaan dan TIDAK mengurangi AR.
                }
            }
            $wpdb->query('COMMIT');
            self::log('marketplace_payout_recorded','marketplace','marketplace_payout',(string)$id,null,['gross'=>$gross,'deductions'=>$deductions,'net'=>$net,'owner_type'=>$owner_type,'seller_account_id'=>$seller_account_id]);
            return $id;
        } catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }

    public static function pay_affiliate_commission($commission_id, $amount = 0) {
        global $wpdb;
        $t=PK01_DB::t('seller_affiliate_ledger');
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",(int)$commission_id),ARRAY_A);
        if(!$r) throw new Exception('Komisi affiliate tidak ditemukan.');
        if($r['status']!=='ready') throw new Exception('Komisi affiliate belum siap dibayar.');
        $amount=$amount>0?round((float)$amount,2):(float)$r['commission_amount'];
        if($amount<=0||$amount>(float)$r['commission_amount']+0.01) throw new Exception('Nominal pembayaran komisi affiliate tidak valid.');
        self::guard_entry('affiliate_payment', (int)$commission_id.'|'.number_format($amount,2,'.',''), ['commission_id'=>(int)$commission_id,'amount'=>$amount]);
        self::cash('out',$amount,'Komisi Affiliate','affiliate_commission',(int)$commission_id,'Pembayaran komisi affiliate','Kas Tunai Toko','AFF-COM-'.$commission_id);
        $wpdb->update($t,['status'=>'paid','paid_at'=>self::now()],['id'=>(int)$commission_id]);
        return $amount;
    }

    /**
     * 7. PENGIRIMAN & LOGISTIK (JABAT TANGAN KE AFILIASI & PESANAN)
     */
    /**
     * Tandai pesanan sebagai selesai dipacking. Tidak membuat transaksi baru;
     * hanya memajukan status fulfillment order dan mencatat audit.
     */
    public static function mark_order_packed($order_id, $notes = '') {
        global $wpdb;
        $order_id = absint($order_id);
        if ($order_id <= 0) throw new Exception('Pesanan tidak valid.');
        $t = PK01_DB::t('sales_orders');
        $o = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d", $order_id), ARRAY_A);
        if (!$o) throw new Exception('Pesanan tidak ditemukan.');
        if (in_array(strtolower((string)$o['status']), ['cancelled','canceled','failed','refunded'], true)) throw new Exception('Pesanan dibatalkan/gagal/refund tidak dapat dipacking.');
        if (in_array(strtolower((string)$o['shipping_status']), ['shipped','delivered','returned'], true) || strtolower((string)$o['status']) === 'shipped') throw new Exception('Pesanan sudah dikirim atau selesai.');
        $payment = strtolower((string)($o['payment_status'] ?? ''));
        if ($payment !== 'paid') throw new Exception('Pesanan belum berstatus pembayaran LUNAS/PAID, sehingga belum dapat dipacking.');
        $updated = ['shipping_status'=>'packed'];
        if (!empty($notes)) $updated['notes'] = trim((string)$o['notes'] . (empty($o['notes'])?'':'\n') . 'Packing: ' . sanitize_textarea_field($notes));
        if (!$wpdb->update($t, $updated, ['id'=>$order_id])) {
            if ($wpdb->last_error) throw new Exception('Gagal memperbarui status packing: '.$wpdb->last_error);
        }
        self::log('order_packed','sales_orders','order',(string)$order_id,null,['order_no'=>$o['order_no']??'', 'notes'=>sanitize_textarea_field($notes)]);
        return true;
    }

    public static function create_shipment($source, $tracking_no, $courier = '', $service = '', $sale_id = 0, $seller_sale_id = 0, $recipient_name = '', $recipient_phone = '', $destination = '', $reporting_only = false) {
        global $wpdb;
        $tracking_no = strtoupper(sanitize_text_field(trim($tracking_no)));
        // AWB kurir boleh belum tersedia saat order marketplace baru masuk.
        // PK01 membuat identitas internal agar Gudang tetap dapat picking/scan.
        // Nomor internal baru dibuat setelah cek duplikasi agar retry tidak membakar sequence.
        $internal_no = '';
        $internal_barcode = '';

        $t = PK01_DB::t('shipments');
        $now = self::now();

        // Resi harus berasal dari transaksi nyata. Untuk Seller marketplace, seller_sale_id adalah sumbernya.
        if ($sale_id <= 0 && $seller_sale_id <= 0) throw new Exception('Pengiriman wajib terhubung ke order penjualan PK01.');
        $order = null;
        if ($sale_id > 0) {
            $t_so = PK01_DB::t('sales_orders');
            $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t_so}` WHERE id=%d", (int)$sale_id), ARRAY_A);
            if (!$order) throw new Exception('Order penjualan tidak ditemukan.');
            if (!$reporting_only && strtolower((string)($order['payment_status'] ?? '')) !== 'paid') throw new Exception('Order belum PAID sehingga belum boleh dibuatkan pengiriman.');
            if (!$reporting_only && !in_array(strtolower((string)($order['shipping_status'] ?? '')), ['packed','label_created'], true)) throw new Exception('Order belum selesai packing. Selesaikan packing sebelum membuat resi.');
            $source = sanitize_key($order['channel'] ?? ($source ?: 'website'));
            // Untuk mode laporan/resi (Kasir/Import), alamat tidak diperlukan.
            // Simpan hanya bila proses pengiriman memang memerlukannya.
            if (!$reporting_only) {
                $recipient_name = sanitize_text_field($order['customer_name'] ?? $recipient_name);
                $recipient_phone = sanitize_text_field($order['customer_phone'] ?? $recipient_phone);
                $destination = sanitize_textarea_field($order['shipping_address'] ?? $destination);
            }
        } else {
            $ss = PK01_DB::t('seller_sales');
            $seller_sale = $wpdb->get_row($wpdb->prepare("SELECT ss.*,so.marketplace,so.marketplace_order_no,so.tracking_no,sa.name seller_name FROM `{$ss}` ss LEFT JOIN `".PK01_DB::t('seller_orders')."` so ON so.id=ss.order_id LEFT JOIN `".PK01_DB::t('sales_accounts')."` sa ON sa.id=ss.seller_account_id WHERE ss.id=%d",(int)$seller_sale_id),ARRAY_A);
            if(!$seller_sale) throw new Exception('Penjualan Seller tidak ditemukan.');
            $source = sanitize_key($seller_sale['marketplace'] ?? ($source ?: 'marketplace'));
            $recipient_name = sanitize_text_field($recipient_name ?: ($seller_sale['seller_name'] ?? ''));
            $destination = sanitize_textarea_field($destination);
        }
        $existing = null;
        if ($tracking_no !== '') {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT id,sale_id,seller_sale_id FROM `{$t}` WHERE tracking_no=%s LIMIT 1", $tracking_no), ARRAY_A);
        }
        if ($existing) {
            $same_link = ((int)($existing['sale_id']??0) === (int)$sale_id && (int)($existing['seller_sale_id']??0) === (int)$seller_sale_id);
            if ($same_link) return (int)$existing['id'];
            throw new Exception('Nomor resi sudah terdaftar pada transaksi lain. Resi tidak boleh dipakai ganda.');
        }
        // Jika order sudah mempunyai shipment internal tanpa AWB, gunakan record itu.
        $existing_internal = null;
        if ($sale_id > 0) {
            $existing_internal = $wpdb->get_row($wpdb->prepare("SELECT id FROM `{$t}` WHERE sale_id=%d AND tracking_no='' ORDER BY id DESC LIMIT 1", (int)$sale_id), ARRAY_A);
        } elseif ($seller_sale_id > 0) {
            $existing_internal = $wpdb->get_row($wpdb->prepare("SELECT id FROM `{$t}` WHERE seller_sale_id=%d AND tracking_no='' ORDER BY id DESC LIMIT 1", (int)$seller_sale_id), ARRAY_A);
        }
        if ($existing_internal) return (int)$existing_internal['id'];

        $internal_no = self::document_number('shipment');
        $internal_barcode = 'PK01-' . preg_replace('/[^A-Z0-9]/', '', strtoupper($internal_no));

        $payload = [
            'source'          => $source,
            'sale_id'         => (int)$sale_id ?: null,
            'seller_sale_id'  => (int)$seller_sale_id ?: null,
            'tracking_no'     => $tracking_no,
            'internal_shipment_no' => $internal_no,
            'internal_barcode' => $internal_barcode,
            'courier'         => sanitize_key($courier),
            'service'         => sanitize_text_field($service ?: 'REG'),
            'tracking_verified' => 'unverified',
            'tracking_provider' => '',
            'tracking_verified_at' => null,
            'tracking_verification_note' => $reporting_only ? 'Dicatat dari Kasir/Import untuk laporan; menunggu verifikasi API atau event kurir.' : 'Resi dicatat PK01; menunggu event kurir.',
            'recipient_name'  => sanitize_text_field($recipient_name),
            'recipient_phone' => sanitize_text_field($recipient_phone),
            'destination'     => sanitize_textarea_field($destination),
            'status'          => 'on_process',
            'last_event_at'   => $now,
            'created_at'      => $now
        ];
        $cols = $wpdb->get_col("DESC `{$t}`", 0);
        $payload = array_intersect_key($payload, array_flip($cols));
        if (!$wpdb->insert($t, $payload)) {
            throw new Exception('Gagal membuat data pengiriman: '.($wpdb->last_error ?: 'unknown error'));
        }
        $shipment_id = (int)$wpdb->insert_id;
        if ($shipment_id <= 0) throw new Exception('Gagal membuat data pengiriman.');
        // Setiap shipment selalu memiliki jejak awal. Ini membuat laporan tetap akurat
        // walaupun kurir tidak menyediakan API; operator dapat melanjutkan milestone secara manual.
        self::add_tracking_event($shipment_id,'label_created','label_created',$tracking_no !== '' ? 'AWB kurir dicatat di PK01; shipment siap untuk proses Gudang.' : 'Identitas internal PK01 dibuat; AWB kurir belum tersedia.', '', $now, 'manual');

        // Pembuatan resi belum berarti barang keluar gudang. Order tetap menunggu
        // serah-terima fisik oleh Gudang ke kurir.
        if ($sale_id > 0) {
            $wpdb->update($t_so, [
                'shipping_status' => 'label_created',
                'tracking_no'     => $tracking_no,
                'courier'         => sanitize_key($courier)
            ], ['id' => $sale_id]);
        }

        self::log('shipment_created', 'shipments', 'shipment', (string)$shipment_id, null, ['tracking_no' => $tracking_no, 'courier' => $courier]);
        return $shipment_id;
    }

    /** Render barcode Code39 sederhana untuk scanner Gudang. Hanya untuk identitas internal PK01, bukan AWB kurir. */
    public static function internal_barcode_svg($code, $height = 52) {
        $patterns = [
            '0'=>'101001101101','1'=>'110100101011','2'=>'101100101011','3'=>'110110010101','4'=>'101001101011','5'=>'110100110101','6'=>'101100110101','7'=>'101001011011','8'=>'110100101101','9'=>'101100101101',
            'A'=>'110101001011','B'=>'101101001011','C'=>'110110100101','D'=>'101011001011','E'=>'110101100101','F'=>'101101100101','G'=>'101010011011','H'=>'110101001101','I'=>'101101001101','J'=>'101011001101',
            'K'=>'110101010011','L'=>'101101010011','M'=>'110110101001','N'=>'101011010011','O'=>'110101101001','P'=>'101101101001','Q'=>'101010110011','R'=>'110101011001','S'=>'101101011001','T'=>'101011011001',
            'U'=>'110010101011','V'=>'100110101011','W'=>'110011010101','X'=>'100101101011','Y'=>'110010110101','Z'=>'100110110101','-'=>'100101011011','.'=>'110010101101',' '=>'100110101101','$'=>'100100100101','/'=>'100100101001','+'=>'100101001001','%'=>'101001001001','*'=>'100101101101'
        ];
        $value='*'.strtoupper(preg_replace('/[^A-Z0-9\-\. \$\/\+%]/','',(string)$code)).'*';
        $x=4; $unit=2; $w=0; $rects='';
        foreach(str_split($value) as $ch){
            if(!isset($patterns[$ch])) continue;
            $pat=$patterns[$ch];
            foreach(str_split($pat) as $bit){ if($bit==='1') $rects.='<rect x="'.($x*$unit).'" y="0" width="'.$unit.'" height="'.$height.'" fill="#111827"/>'; $x++; }
            $x++; // inter-character gap
        }
        $w=$x*$unit+4;
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '.$w.' '.($height+18).'" width="100%" height="'.($height+18).'" role="img" aria-label="Barcode '.esc_attr($code).'">'.$rects.'<text x="'.($w/2).'" y="'.($height+14).'" text-anchor="middle" font-family="monospace" font-size="11">'.esc_html($code).'</text></svg>';
    }

    /** Cari shipment memakai AWB kurir ATAU barcode internal PK01. */
    public static function find_shipment_by_scan_code($code) {
        global $wpdb;
        $code = strtoupper(sanitize_text_field(trim((string)$code)));
        if ($code === '') return null;
        $t = PK01_DB::t('shipments');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE tracking_no=%s OR internal_shipment_no=%s OR internal_barcode=%s ORDER BY id DESC LIMIT 1", $code, $code, $code), ARRAY_A);
    }

    /** Ikat AWB resmi kurir ke shipment internal yang sudah dibuat. */
    public static function attach_courier_awb($shipment_id, $tracking_no, $courier = '', $service = '') {
        global $wpdb;
        $shipment_id=(int)$shipment_id;
        $tracking_no=strtoupper(sanitize_text_field(trim((string)$tracking_no)));
        if($shipment_id<=0 || $tracking_no==='') throw new Exception('Shipment internal dan AWB kurir wajib diisi.');
        $t=PK01_DB::t('shipments');
        $s=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$shipment_id),ARRAY_A);
        if(!$s) throw new Exception('Shipment internal tidak ditemukan.');
        $dup=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE tracking_no=%s AND id<>%d LIMIT 1",$tracking_no,$shipment_id));
        if($dup) throw new Exception('AWB kurir sudah terhubung ke shipment lain.');
        $data=['tracking_no'=>$tracking_no];
        if($courier!=='')$data['courier']=sanitize_key($courier);
        if($service!=='')$data['service']=sanitize_text_field($service);
        $wpdb->update($t,$data,['id'=>$shipment_id]);
        if(!empty($s['sale_id'])) $wpdb->update(PK01_DB::t('sales_orders'),['tracking_no'=>$tracking_no,'courier'=>sanitize_key($courier?:($s['courier']??''))],['id'=>(int)$s['sale_id']]);
        self::add_tracking_event($shipment_id,'label_created','awb_attached','AWB resmi kurir diikat ke identitas internal PK01.','',self::now(),'manual');
        if(class_exists('PK01_Shipping_Smart')) PK01_Shipping_Smart::verify_shipment($shipment_id);
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$shipment_id),ARRAY_A);
    }

    public static function add_tracking_event($shipment_id, $status, $event_code = '', $description = '', $location = '', $event_time = '', $source = 'manual') {
        global $wpdb;
        $t_s = PK01_DB::t('shipments');
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t_s}` WHERE id = %d", (int)$shipment_id), ARRAY_A);
        if (!$s) throw new Exception('Data pengiriman tidak ditemukan.');

        $now = self::now();
        $event_time = $event_time ?: $now;

        $t_e = PK01_DB::t('tracking_events');
        $wpdb->insert($t_e, [
            'shipment_id' => (int)$shipment_id,
            'status'      => sanitize_key($status),
            'event_code'  => sanitize_text_field($event_code),
            'description' => sanitize_textarea_field($description),
            'location'    => sanitize_text_field($location),
            'event_time'  => $event_time,
            'source'      => sanitize_key($source),
            'created_at'  => $now
        ]);

        // Update status master pengiriman
        $wpdb->update($t_s, [
            'status'        => $status,
            'last_event_at' => $event_time
        ], ['id' => $shipment_id]);

        // Sinkronisasi status pesanan dari milestone resmi/manual yang dicatat operator.
        if (!empty($s['sale_id'])) {
            $t_so = PK01_DB::t('sales_orders');
            $order_status = [
                'label_created'=>['status'=>'processing','shipping_status'=>'label_created'],
                'picked_up'=>['status'=>'shipped','shipping_status'=>'picked_up'],
                'in_transit'=>['status'=>'shipped','shipping_status'=>'in_transit'],
                'arrived'=>['status'=>'shipped','shipping_status'=>'arrived'],
                'out_for_delivery'=>['status'=>'shipped','shipping_status'=>'out_for_delivery'],
                'delivered'=>['status'=>'completed','shipping_status'=>'delivered'],
                'delivery_failed'=>['status'=>'shipped','shipping_status'=>'delivery_failed'],
                'return_to_sender'=>['status'=>'shipped','shipping_status'=>'return_to_sender'],
                'returned'=>['status'=>'returned','shipping_status'=>'returned'],
            ];
            if (isset($order_status[$status])) {
                $wpdb->update($t_so, $order_status[$status], ['id'=>(int)$s['sale_id']]);
            }
            if ($status === 'delivered' && class_exists('PK01_Affiliate') && method_exists('PK01_Affiliate', 'sync_commission_status')) {
                PK01_Affiliate::sync_commission_status((int)$s['sale_id']);
            }
        }
        self::log('tracking_event_recorded','shipping','shipment',(string)$shipment_id,null,[
            'status'=>$status,'event_code'=>$event_code,'source'=>$source,'event_time'=>$event_time,'location'=>$location
        ],'Milestone pengiriman dicatat di PK01');

        return true;
    }

    /**
     * 8. LAPORAN KEUANGAN RIIL (FINANCIAL REPORT ENGINE)
     */
    /**
     * Estimasi HPP berbasis data sistem.
     * Prinsip: volume besar tidak otomatis menurunkan harga bahan; penurunan
     * otomatis terutama berasal dari pembagian biaya tetap per unit dan,
     * bila tersedia, harga beli bahan aktual yang lebih rendah pada pembelian besar.
     * AI boleh memberi rekomendasi, tetapi angka akuntansi tetap berasal dari data transaksi.
     */
    /**
     * HPP aktual Job dari bahan yang benar-benar dipakai.
     * Bahan yang hanya diserahkan tetapi dikembalikan tidak masuk HPP; hanya used_qty.
     * Biaya bahan diambil dari unit_cost yang disnapshot saat issue, bukan harga master yang berubah belakangan.
     */
    public static function calculate_job_actual_hpp($job_id) {
        global $wpdb;
        $job_id=absint($job_id); if($job_id<=0) throw new Exception('Job tidak valid.');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT jm.*,m.name material_name,m.code material_code,m.unit material_unit FROM ".PK01_DB::t('job_materials')." jm JOIN ".PK01_DB::t('materials')." m ON m.id=jm.material_id WHERE jm.job_id=%d ORDER BY jm.id ASC",$job_id),ARRAY_A)?:[];
        $material_cost=0; $issued_value=0; $returned_value=0; $estimated=false; $items=[];
        foreach($rows as $r){
            $uc=(float)($r['unit_cost']??0);
            if($uc<=0){ $uc=(float)$wpdb->get_var($wpdb->prepare("SELECT cost FROM ".PK01_DB::t('materials')." WHERE id=%d",(int)$r['material_id'])); $estimated=true; }
            $used=(float)$r['used_qty']; $ret=(float)$r['returned_qty'];
            $cc=round($used*$uc,2); $iv=round((float)$r['issued_qty']*$uc,2); $rv=round($ret*$uc,2);
            $material_cost+=$cc; $issued_value+=$iv; $returned_value+=$rv;
            $items[]=['material_id'=>(int)$r['material_id'],'code'=>$r['material_code'],'name'=>$r['material_name'],'issued_qty'=>(float)$r['issued_qty'],'used_qty'=>$used,'returned_qty'=>$ret,'unit'=>$r['material_unit'],'unit_cost'=>round($uc,2),'consumed_cost'=>$cc];
        }
        $wage=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM ".PK01_DB::t('job_wages')." WHERE job_id=%d AND status NOT IN ('cancelled')",$job_id));
        $good=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(good_qty),0) FROM ".PK01_DB::t('production_results')." WHERE job_id=%d AND status='approved'",$job_id));
        $total=round($material_cost+$wage,2);
        return ['job_id'=>$job_id,'material_cost'=>round($material_cost,2),'labor_cost'=>round($wage,2),'hpp_total'=>round($total,2),'good_qty'=>$good,'hpp_per_good_unit'=>$good>0?round($total/$good,2):0,'issued_material_value'=>round($issued_value,2),'returned_material_value'=>round($returned_value,2),'data_quality'=>$estimated?'ESTIMATED_FOR_LEGACY_ROWS':'ACTUAL_ISSUE_COST','materials'=>$items];
    }

    public static function estimate_hpp_from_system($variant_id, $planned_qty = 1, $lookback_months = 12) {
        global $wpdb;
        $variant_id = absint($variant_id);
        $planned_qty = max(1, (float)$planned_qty);
        if ($variant_id <= 0) throw new Exception('Varian produk tidak valid.');

        $tv = PK01_DB::t('product_variants');
        $tc = PK01_DB::t('hpp_components');
        $tm = PK01_DB::t('materials');
        $tpo = PK01_DB::t('purchase_orders');
        $tpi = PK01_DB::t('purchase_order_items');
        $tjw = PK01_DB::t('job_wages');
        $tji = PK01_DB::t('job_items');
        $tpr = PK01_DB::t('production_results');
        $toc = PK01_DB::t('operational_costs');

        $v = $wpdb->get_row($wpdb->prepare("SELECT id,hpp,hpp_labor,hpp_overhead,hpp_packaging,hpp_other,hpp_basis_qty FROM `{$tv}` WHERE id=%d", $variant_id), ARRAY_A);
        if (!$v) throw new Exception('Varian produk tidak ditemukan.');

        $components = $wpdb->get_results($wpdb->prepare("SELECT material_id,component_name,qty,unit,unit_cost,waste_percent,component_type FROM `{$tc}` WHERE variant_id=%d ORDER BY id ASC", $variant_id), ARRAY_A) ?: [];
        $material_total = 0.0;
        $sources = [];
        foreach ($components as $c) {
            $qty = max(0,(float)$c['qty']);
            $waste = max(0,min(100,(float)$c['waste_percent']));
            $unit_cost = max(0,(float)$c['unit_cost']);
            $mid = absint($c['material_id']);
            if ($mid > 0 && $tm) {
                $master = (float)$wpdb->get_var($wpdb->prepare("SELECT cost FROM `{$tm}` WHERE id=%d",$mid));
                if ($master > 0) $unit_cost = $master;
                if ($tpo && $tpi) {
                    $since = date('Y-m-d', strtotime('-'.max(1,(int)$lookback_months).' months', current_time('timestamp')));
                    $hist = $wpdb->get_var($wpdb->prepare(
                        "SELECT SUM(pi.qty*pi.unit_cost)/NULLIF(SUM(pi.qty),0) FROM `{$tpi}` pi JOIN `{$tpo}` po ON po.id=pi.po_id WHERE pi.material_id=%d AND po.order_date >= %s AND po.status NOT IN ('cancelled','batal') AND pi.qty>0 AND pi.unit_cost>0",
                        $mid,$since
                    ));
                    if ((float)$hist > 0) {
                        $unit_cost = (float)$hist;
                        $sources[] = 'weighted_purchase_cost:material#'.$mid;
                    } else {
                        $sources[] = 'master_material_cost:material#'.$mid;
                    }
                }
            } else {
                $sources[] = 'saved_component_cost:'.($c['component_name'] ?: 'manual');
            }
            $material_total += $qty*$unit_cost*(1+$waste/100);
        }

        // Historical direct labor per good unit, only when enough linked production data exists.
        $labor_per_unit = 0.0;
        if ($tjw && $tji && $tpr) {
            $since = date('Y-m-d', strtotime('-'.max(1,(int)$lookback_months).' months', current_time('timestamp')));
            $labor_per_unit = (float)$wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(w.amount),0)/NULLIF(SUM(r.good_qty),0) FROM `{$tjw}` w JOIN `{$tpr}` r ON r.job_id=w.job_id WHERE w.status IN ('paid','approved','pending') AND r.status='approved' AND EXISTS (SELECT 1 FROM `{$tji}` ji WHERE ji.job_id=w.job_id AND ji.variant_id=%d) AND w.created_at >= %s",
                $variant_id,$since
            ));
        }
        if ($labor_per_unit <= 0) $labor_per_unit = ((float)($v['hpp_labor'] ?? 0)) / max(1,(float)($v['hpp_basis_qty'] ?? 1));
        $labor_total = $labor_per_unit*$planned_qty;

        // Fixed production overhead: allocate a fixed monthly/period amount across the planned batch.
        // We use the saved production-overhead baseline, not all company expenses.
        $saved_basis = max(1,(float)($v['hpp_basis_qty'] ?? 1));
        $saved_overhead = max(0,(float)($v['hpp_overhead'] ?? 0));
        $overhead_per_batch = $saved_overhead;
        if ($overhead_per_batch <= 0 && $toc) {
            $since = date('Y-m-d', strtotime('-'.max(1,(int)$lookback_months).' months', current_time('timestamp')));
            $avg_opex = (float)$wpdb->get_var($wpdb->prepare("SELECT AVG(x.total_cost) FROM (SELECT DATE_FORMAT(cost_date,'%%Y-%%m') m, SUM(amount) total_cost FROM `{$toc}` WHERE cost_date >= %s AND category IN ('Overhead Produksi','Produksi','Listrik Produksi','Sewa Produksi','Maintenance Produksi') GROUP BY DATE_FORMAT(cost_date,'%%Y-%%m')) x",$since));
            if ($avg_opex > 0) $overhead_per_batch = $avg_opex;
        }
        // Economies of scale: fixed overhead is spread over more units.
        $overhead_total = $overhead_per_batch;
        if ($saved_basis > 1 && $saved_overhead > 0) $overhead_total = ($saved_overhead/$saved_basis)*$planned_qty;

        $pack_per_unit = max(0,(float)($v['hpp_packaging'] ?? 0))/ $saved_basis;
        $other_per_unit = max(0,(float)($v['hpp_other'] ?? 0))/ $saved_basis;
        $packaging_total = $pack_per_unit*$planned_qty;
        $other_total = $other_per_unit*$planned_qty;
        $total = round($material_total+$labor_total+$overhead_total+$packaging_total+$other_total,2);
        $per_unit = round($total/$planned_qty,2);

        return [
            'variant_id'=>$variant_id,'planned_qty'=>$planned_qty,'material_cost'=>round($material_total,2),
            'labor_cost'=>round($labor_total,2),'overhead_cost'=>round($overhead_total,2),
            'packaging_cost'=>round($packaging_total,2),'other_cost'=>round($other_total,2),
            'hpp_total'=>$total,'hpp_per_unit'=>$per_unit,
            'source'=>implode(', ',array_unique($sources)) ?: 'saved_hpp_baseline',
            'assumptions'=>'Material memakai biaya aktual master/weighted purchase bila tersedia. Biaya tetap produksi dialokasikan ke volume batch. Volume besar tidak otomatis menurunkan material cost tanpa bukti harga beli lebih rendah.'
        ];
    }

    public static function financial_report($from = '', $to = '') {
        global $wpdb;
        $from = $from ? sanitize_text_field($from) : current_time('Y-m-01');
        $to   = $to ? sanitize_text_field($to) : current_time('Y-m-d');
        $start = $from . ' 00:00:00';
        $end   = $to . ' 23:59:59';

        // Laporan selalu membaca sumber transaksi yang sama dan memastikan GL telah direkonsiliasi.
        if (class_exists('PK01_Finance') && method_exists('PK01_Finance','sync')) { PK01_Finance::sync($from,$to); }
        $T = function($k) { return PK01_DB::t($k); };

        // 1. Penjualan Kotor (Company + Seller)
        $t_so = $T('sales_orders');
        $sales_company = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total_amount), 0) 
             FROM `{$t_so}` WHERE status NOT IN ('cancelled', 'batal', 'failed') AND created_at BETWEEN %s AND %s",
            $start, $end
        ));

        $t_ss = $T('seller_sales');
        $sales_seller = $t_ss ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM `{$t_ss}` WHERE sold_at BETWEEN %s AND %s",
            $start, $end
        )) : 0;

        $gross = $sales_company + $sales_seller;

        // 2. HPP Total. HPP dari barang yang diretur dibalik agar laba tidak tetap
        // terbebani atas unit yang kembali ke stok.
        $hpp_company = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(hpp * qty), 0) FROM `{$t_so}` WHERE status NOT IN ('cancelled', 'batal', 'failed') AND created_at BETWEEN %s AND %s",
            $start, $end
        ));
        $hpp_seller = $t_ss ? (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(hpp * qty), 0) FROM `{$t_ss}` WHERE sold_at BETWEEN %s AND %s", $start, $end)) : 0;
        $hpp_gross = $hpp_company + $hpp_seller;

        // 3. Retur Barang + pembalikan HPP barang yang kembali ke stok.
        $t_ret = $T('returns');
        $returns = $t_ret ? (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(refund_amount), 0) FROM `{$t_ret}` WHERE status = 'completed' AND created_at BETWEEN %s AND %s", $start, $end)) : 0;
        $t_ri = $T('return_items');
        $t_v = $T('product_variants');
        $return_hpp = ($t_ret && $t_ri && $t_v) ? (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(ri.qty * COALESCE(v.hpp,0)),0) FROM `{$t_ri}` ri JOIN `{$t_ret}` r ON r.id=ri.return_id LEFT JOIN `{$t_v}` v ON v.id=ri.variant_id WHERE r.status='completed' AND r.created_at BETWEEN %s AND %s", $start, $end)) : 0;
        $hpp = max(0, $hpp_gross - $return_hpp);

        // 4. Biaya Operasional (operational_costs)
        $t_oc = $T('operational_costs');
        $opex = $t_oc ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM `{$t_oc}` 
             WHERE category NOT IN ('Gaji & Upah', 'Gaji Karyawan', 'Upah Pekerjaan') 
             AND ((cost_date BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s))",
            $from, $to, $start, $end
        )) : 0;

        // 5. Gaji Karyawan (payroll)
        $t_pay = $T('payroll');
        $payroll = $t_pay ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CASE WHEN COALESCE(gross_amount,0)>0 THEN gross_amount ELSE amount END), 0) FROM `{$t_pay}` 
             WHERE status = 'paid' 
             AND ((paid_at BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s))",
            $from, $to, $start, $end
        )) : 0;
        // Beban payroll akrual mencakup payroll paid + pending yang dibuat pada periode, tanpa menggandakan pembayaran.
        $payroll_accrued = $t_pay ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CASE WHEN COALESCE(gross_amount,0)>0 THEN gross_amount ELSE amount END),0) FROM `{$t_pay}` WHERE created_at BETWEEN %s AND %s", $start,$end
        )) : 0;
        // Upah Job terpisah dari payroll bulanan, tetapi tetap merupakan beban tenaga kerja.
        $t_jw = $T('job_wages');
        $job_wages = $t_jw ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount),0) FROM `{$t_jw}` WHERE status='paid' AND ((paid_at BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s))",
            $from, $to, $start, $end
        )) : 0;

        // Jika tabel payroll kosong, ambil dari pos Gaji di tabel biaya usaha
        if ($payroll <= 0 && $t_pay && $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$t_pay}` WHERE status = 'paid' AND ((paid_at BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s))", $from, $to, $start, $end)) == 0 && $t_oc) {
            $payroll = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(amount), 0) FROM `{$t_oc}` 
                 WHERE category IN ('Gaji & Upah', 'Gaji Karyawan') 
                 AND ((cost_date BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s))",
                $from, $to, $start, $end
            ));
        }

        // 6. Komisi Afiliasi
        $t_aff = $T('seller_affiliate_ledger');
        $affiliate = $t_aff ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(commission_amount), 0) FROM `{$t_aff}` WHERE status IN ('ready','approved','paid') AND created_at BETWEEN %s AND %s",
            $start, $end
        )) : 0;
        $t_sc = $T('sales_commissions');
        $sales_commission = $t_sc ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(commission_amount),0) FROM `{$t_sc}` WHERE status IN ('approved','ready','paid') AND created_at BETWEEN %s AND %s",
            $start,$end
        )) : 0;
        $t_mp = $T('marketplace_deductions');
        $marketplace_fees = $t_mp ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount),0) FROM `{$t_mp}` WHERE created_at BETWEEN %s AND %s",
            $start,$end
        )) : 0;
        $t_sb = $T('seller_bonus_ledger');
        $seller_target_bonus = $t_sb ? (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(bonus_amount),0) FROM `{$t_sb}` WHERE status IN ('earned','paid') AND created_at BETWEEN %s AND %s",
            $start,$end
        )) : 0;

        // 7. Penilaian persediaan & penyusutan aset: biaya non-kas yang mengurangi laba, bukan kas.
        $t_dep=$T('asset_depreciation'); $depreciation=$t_dep ? (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(depreciation_amount),0) FROM `{$t_dep}` WHERE period_key BETWEEN %s AND %s",substr($from,0,7),substr($to,0,7))) : 0;
        $t_iv=$T('inventory_valuation_adjustments'); $inventory_write_down=$t_iv ? (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$t_iv}` WHERE adjustment_type='write_down' AND status='approved' AND created_at BETWEEN %s AND %s",$start,$end)) : 0;
        $selling_expenses = $affiliate + $sales_commission + $marketplace_fees + $seller_target_bonus;
        $net_sales    = $gross - $returns;
        $gross_profit = $net_sales - $hpp - $selling_expenses;
        $net_profit   = $gross_profit - $opex - $payroll - $job_wages - $depreciation - $inventory_write_down;
        $net_profit_accrual = $gross_profit - $opex - $payroll_accrued - $job_wages - $depreciation - $inventory_write_down;
        $margin       = ($gross > 0) ? round(($net_profit / $gross) * 100, 2) : 0;
        $margin_accrual = ($gross > 0) ? round(($net_profit_accrual / $gross) * 100, 2) : 0;

        // 8. Arus Kas (cash_ledger)
        $t_cl = $T('cash_ledger');
        $cash_in  = $t_cl ? (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM `{$t_cl}` WHERE direction = 'in' AND reference_type <> 'cashier_deposit_transfer' AND created_at BETWEEN %s AND %s", $start, $end)) : 0;
        $cash_out = $t_cl ? (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM `{$t_cl}` WHERE direction = 'out' AND reference_type <> 'cashier_deposit_transfer' AND created_at BETWEEN %s AND %s", $start, $end)) : 0;

        return [
            'from'                 => $from,
            'to'                   => $to,
            'gross_sales'          => round($gross, 2),
            'sales_company'        => round($sales_company, 2),
            'sales_seller'         => round($sales_seller, 2),
            'returns'              => round($returns, 2),
            'return_hpp'           => round($return_hpp, 2),
            'net_sales'            => round($net_sales, 2),
            'hpp'                  => round($hpp, 2),
            'marketplace_fees'     => round($marketplace_fees, 2),
            'sales_commission'    => round($sales_commission, 2),
            'affiliate_commission' => round($affiliate, 2),
            'seller_target_bonus'  => round($seller_target_bonus, 2),
            'gross_profit'         => round($gross_profit, 2),
            'operational_cost'     => round($opex, 2),
            'payroll'              => round($payroll, 2),
            'payroll_accrued'      => round($payroll_accrued, 2),
            'job_wages'           => round($job_wages, 2),
            'depreciation'        => round($depreciation, 2),
            'inventory_write_down'=> round($inventory_write_down, 2),
            'net_profit'           => round($net_profit, 2),
            'net_profit_accrual'   => round($net_profit_accrual, 2),
            'margin'               => $margin,
            'margin_accrual'       => $margin_accrual,
            'cash_in'              => round($cash_in, 2),
            'cash_out'             => round($cash_out, 2),
            'cash_balance'         => self::cash_balance(),
            'seller_ar'             => self::seller_ar_summary($from,$to),
            'integrity_issues'      => self::financial_integrity($from,$to)
        ];
    }

    /**
     * Ringkasan laba periode dan laba yang belum dibagikan.
     * Semua angka berasal dari financial_report(), tanpa input manual laba.
     */
    public static function profit_period_summary($from = '', $to = '') {
        $from = $from ?: self::first_financial_date();
        $to   = $to ?: current_time('Y-m-d');
        return self::financial_report($from, $to);
    }

    public static function first_financial_date() {
        global $wpdb;
        $candidates = [];
        foreach (['sales_orders','operational_costs','payroll','cash_ledger','capital_transactions','stock_transactions'] as $key) {
            $t = PK01_DB::t($key);
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) continue;
            $d = $wpdb->get_var("SELECT MIN(DATE(created_at)) FROM `{$t}` WHERE created_at IS NOT NULL");
            if ($d) $candidates[] = $d;
        }
        return $candidates ? min($candidates) : current_time('Y-m-01');
    }

    /**
     * Laba bersih kumulatif yang benar-benar belum dialokasikan kepada pemilik.
     * Pembagian laba bukan biaya dan tidak mengurangi laba; hanya alokasi ekuitas.
     */
    public static function undistributed_profit($to = '') {
        global $wpdb;
        $to = $to ?: current_time('Y-m-d');
        $report = self::financial_report(self::first_financial_date(), $to);
        $earned = max(0, (float)($report['net_profit'] ?? 0));
        $td = PK01_DB::t('profit_distributions');
        $allocated = 0;
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $td)) === $td) {
            $allocated = (float)$wpdb->get_var("SELECT COALESCE(SUM(distributable_profit),0) FROM `{$td}` WHERE status IN ('approved','paid') AND period_end <= '" . esc_sql($to) . "'");
        }
        return round(max(0, $earned - $allocated), 2);
    }

    /**
     * Posisi laba investor bersifat signed.
     * Positif = hak laba yang masih bisa dibayar.
     * Negatif = bon/advance laba yang harus dipotong dari laba investor berikutnya.
     *
     * Profit advance sengaja disimpan sebagai transaksi investor, bukan biaya usaha
     * dan bukan pengurang laba perusahaan.
     */
    public static function investor_profit_position($investor_id, $to = '') {
        global $wpdb;
        $investor_id=(int)$investor_id;
        if ($investor_id<=0) return 0.0;
        $ti=PK01_DB::t('investors');
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$ti)) !== $ti) return 0.0;
        $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$ti}` WHERE id=%d AND status='active'",$investor_id));
        if (!$exists) return 0.0;
        $td=PK01_DB::t('profit_distribution_items');
        $tt=PK01_DB::t('investor_transactions');
        $allocated=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(allocated_amount),0) FROM `{$td}` WHERE investor_id=%d AND beneficiary_type='investor'",$investor_id));
        $paid=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tt}` WHERE investor_id=%d AND transaction_type IN ('profit_draw','profit_paid')",$investor_id));
        $advance=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tt}` WHERE investor_id=%d AND transaction_type='profit_advance'",$investor_id));
        return round($allocated-$paid-$advance,2);
    }

    /** Hak laba investor yang benar-benar dapat ditarik saat ini. */
    public static function investor_profit_entitlement($investor_id, $to = '') {
        return round(max(0,self::investor_profit_position($investor_id,$to)),2);
    }

    /** Sisa bon/advance laba investor yang akan otomatis meng-offset laba berikutnya. */
    public static function investor_profit_advance_balance($investor_id, $to = '') {
        return round(max(0,-self::investor_profit_position($investor_id,$to)),2);
    }

    public static function owner_profit_entitlement($owner_id, $to = '') {
        global $wpdb;
        $owner_id=(int)$owner_id;
        if ($owner_id<=0) return 0;
        $owner= $wpdb->get_row($wpdb->prepare("SELECT share_percent FROM `".PK01_DB::t('company_owners')."` WHERE id=%d AND status='active'", $owner_id));
        if (!$owner) return 0;
        $td=PK01_DB::t('profit_distribution_items');
        $allocated=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(allocated_amount),0) FROM `{$td}` WHERE owner_id=%d AND beneficiary_type='owner'",$owner_id));
        $withdrawn=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `".PK01_DB::t('owner_transactions')."` WHERE owner_id=%d AND transaction_type IN ('profit_draw','owner_advance')",$owner_id));
        // Laba yang belum dibuatkan distribusi belum menjadi hak nominal pemilik.
        // Hak pemilik hanya berasal dari snapshot persentase pada distribusi yang sudah dibuat.
        $available_from_distributions=max(0,$allocated-$withdrawn);
        return round($available_from_distributions,2);
    }

    /** Ringkasan AR Seller canonical dari seller_invoices - seller_payments. */
    public static function seller_ar_summary($from='',$to='') {
        global $wpdb; $ti=PK01_DB::t('seller_invoices'); $tp=PK01_DB::t('seller_payments');
        if(!$ti||!$tp) return ['period_invoiced'=>0,'period_paid'=>0,'period_net'=>0,'outstanding'=>0,'invoice_count'=>0];
        $from=$from?:self::first_financial_date(); $to=$to?:current_time('Y-m-d'); $start=$from.' 00:00:00'; $end=$to.' 23:59:59';
        $invoiced=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM `{$ti}` WHERE created_at BETWEEN %s AND %s",$start,$end));
        $paid=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tp}` WHERE paid_at BETWEEN %s AND %s",$start,$end));
        $all_invoiced=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM `{$ti}` WHERE created_at<=%s",$end));
        $all_paid=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tp}` WHERE paid_at<=%s",$end));
        $count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$ti}` WHERE created_at BETWEEN %s AND %s",$start,$end));
        return ['period_invoiced'=>round($invoiced,2),'period_paid'=>round($paid,2),'period_net'=>round($invoiced-$paid,2),'outstanding'=>round(max(0,$all_invoiced-$all_paid),2),'invoice_count'=>$count];
    }

    /** Rekonsiliasi angka kritis agar dashboard tidak diam-diam berbeda dengan ledger. */
    public static function financial_integrity($from='',$to='') {
        global $wpdb; $issues=[]; $from=$from?:self::first_financial_date(); $to=$to?:current_time('Y-m-d'); $start=$from.' 00:00:00'; $end=$to.' 23:59:59';
        $cash=PK01_DB::t('cash_ledger'); $journal=PK01_DB::t('journal_entries'); $jl=PK01_DB::t('journal_lines');
        if($cash && $journal && $jl){
            $cash_net=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN amount ELSE -amount END),0) FROM `{$cash}` WHERE created_at BETWEEN %s AND %s",$start,$end));
            $gl_cash=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(debit-credit),0) FROM `{$jl}` l JOIN `{$journal}` j ON j.id=l.journal_entry_id WHERE l.account_code='1100' AND j.entry_date BETWEEN %s AND %s",$from,$to));
            if(abs($cash_net-$gl_cash)>0.01) $issues[]=['type'=>'cash_gl_mismatch','cash'=>$cash_net,'gl'=>$gl_cash,'difference'=>round($cash_net-$gl_cash,2)];
        }
        $so=PK01_DB::t('sales_orders');
        if($so){$bad=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$so}` WHERE created_at BETWEEN %s AND %s AND paid_amount>total_amount+0.01",$start,$end));if($bad)$issues[]=['type'=>'sales_paid_exceeds_total','count'=>$bad];}
        $si=PK01_DB::t('seller_invoices'); $sp=PK01_DB::t('seller_payments');
        if($si&&$sp){$bad=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$si}` i WHERE (SELECT COALESCE(SUM(amount),0) FROM `{$sp}` p WHERE p.invoice_id=i.id)>i.total+0.01");if($bad)$issues[]=['type'=>'seller_payment_exceeds_invoice','count'=>$bad];}
        return $issues;
    }

    /**
     * 9. ROWS PROVIDER UNTUK UNIVERSAL TABLE ENGINE (tampilan-data-modul.php)
     */
    public static function module_rows($key) {
        global $wpdb;
        $T = function($k) { return PK01_DB::t($k); };

        switch ($key) {
            case 'materials':
                $rows = $wpdb->get_results("SELECT m.id, m.code, m.name, m.unit, m.cost, m.stock, m.min_stock, COALESCE(s.name, '—') AS supplier, m.created_at FROM " . $T('materials') . " m LEFT JOIN " . $T('suppliers') . " s ON s.id = m.supplier_id ORDER BY m.id DESC LIMIT 200", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'code', 'name', 'unit', 'cost', 'stock', 'min_stock', 'supplier', 'created_at']];

            case 'sales':
                $rows = $wpdb->get_results("SELECT so.id, so.order_no, COALESCE(so.invoice_no, so.order_no) AS invoice_no, COALESCE(so.customer_name, '—') AS customer, COALESCE(so.channel, 'website') AS channel, so.status, COALESCE(so.payment_status, 'unpaid') AS payment_status, COALESCE(so.shipping_status, 'pending') AS shipping_status, COALESCE(so.total_amount, so.gross, 0) AS total_amount, so.created_at FROM " . $T('sales_orders') . " so ORDER BY so.id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'order_no', 'invoice_no', 'customer', 'channel', 'status', 'payment_status', 'shipping_status', 'total_amount', 'created_at']];

            case 'operational_costs':
                $rows = $wpdb->get_results("SELECT id, cost_date, category, amount, payment_method, reference_no, description FROM " . $T('operational_costs') . " ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'cost_date', 'category', 'amount', 'payment_method', 'reference_no', 'description']];

            case 'cash':
                $rows = $wpdb->get_results("SELECT id, direction, amount, account, category, reference_no, description, created_at FROM " . $T('cash_ledger') . " ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'direction', 'amount', 'account', 'category', 'reference_no', 'description', 'created_at']];

            case 'payroll':
                $rows = $wpdb->get_results("SELECT id, employee_id, name, period, amount, payment_method, status, paid_at FROM " . $T('payroll') . " ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'employee_id', 'name', 'period', 'amount', 'payment_method', 'status', 'paid_at']];

            case 'pricing':
                $t_prc = $T('pricing');
                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_prc)) === $t_prc) {
                    $rows = $wpdb->get_results("SELECT id, sku, name, hpp, price, margin_percent, status, valid_from, approved_by FROM `{$t_prc}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                    return ['rows' => $rows, 'columns' => ['id', 'sku', 'name', 'hpp', 'price', 'margin_percent', 'status', 'valid_from', 'approved_by']];
                }
                break;

            case 'marketplace':
                $rows = $wpdb->get_results("SELECT id, payout_no, channel_id, payout_date, order_count, gross, deductions, net_received, account_id, status FROM " . $T('marketplace_payouts') . " ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'payout_no', 'channel_id', 'payout_date', 'order_count', 'gross', 'deductions', 'net_received', 'account_id', 'status']];

            case 'shipments':
                $rows = $wpdb->get_results("SELECT id, tracking_no, source, courier, service, recipient_name, destination, status, last_event_at FROM " . $T('shipments') . " ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'tracking_no', 'source', 'courier', 'service', 'recipient_name', 'destination', 'status', 'last_event_at']];

            case 'logs':
                $t_l = class_exists('PK01_Audit') ? PK01_Audit::table() : $T('activity_logs');
                $rows = $wpdb->get_results("SELECT id, timestamp, user_name, action, module, entity, transaction_id, level FROM `{$t_l}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                return ['rows' => $rows, 'columns' => ['id', 'timestamp', 'user_name', 'action', 'module', 'entity', 'transaction_id', 'level']];
        }

        // Default query untuk modul sederhana
        $t = $T($key);
        if ($t && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) {
            $cols = $wpdb->get_col("DESC `{$t}`", 0) ?: [];
            $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
            return ['rows' => $rows, 'columns' => $cols];
        }

        return ['rows' => [], 'columns' => []];
    }
}
