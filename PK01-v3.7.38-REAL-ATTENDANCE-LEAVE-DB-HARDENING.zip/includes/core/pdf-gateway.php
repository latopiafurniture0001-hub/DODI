<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 PDF & Dokumen Gateway
 * Satu pintu untuk semua dokumen resmi. Sumber data tetap Business Engine/DB PK01.
 */
if (!function_exists('pk01_pdf_load_fpdf')) {
    /**
     * Memuat FPDF dari satu pintu Core PK01.
     * Prioritas folder /fpdf/ sebagai library canonical PK01, lalu fallback
     * ke folder library lama agar update tetap backward compatible.
     */
    function pk01_pdf_load_fpdf() {
        static $done = false;
        if ($done) return class_exists('FPDF', false);
        $done = true;

        if (class_exists('FPDF', false)) return true;

        $candidates = [
            // Canonical FPDF library for PK01. All official PDFs must use this file.
            PK01_DIR . 'fpdf/fpdf.php',
            PK01_DIR . 'pdf/src/Fpdf/Fpdf.php',
            PK01_DIR . 'pdf/autoload.php',
            PK01_DIR . 'pdf/vendor/autoload.php',
            PK01_DIR . 'koperasi-modul-fpdf/fpdf.php',
            PK01_DIR . 'koperasi-modul-fpdf/src/Fpdf/Fpdf.php',
            PK01_DIR . 'koperasi-modul-fpdf/autoload.php',
            PK01_DIR . 'koperasi-modul-fpdf/vendor/autoload.php',
            PK01_DIR . 'includes/fpdf/fpdf.php',
            PK01_DIR . 'includes/libraries/fpdf/fpdf.php',
        ];

        foreach ($candidates as $file) {
            if (!is_readable($file)) continue;

            $font_dir = dirname($file) . '/font/';
            if (!defined('FPDF_FONTPATH') && is_dir($font_dir)) {
                define('FPDF_FONTPATH', $font_dir);
            }

            require_once $file;
            if (class_exists('FPDF', false)) {
                if (!defined('PK01_FPDF_PATH')) define('PK01_FPDF_PATH', $file);
                return true;
            }
        }

        return false;
    }
}


pk01_pdf_load_fpdf();
if (class_exists('FPDF') && !class_exists('PK01_PDF')) {
    class PK01_PDF extends FPDF {
        public function Header() {
            // Professional light-green document band; individual documents can still draw their own header.
            $this->SetFillColor(232, 247, 238);
            $this->Rect(0, 0, 210, 7, 'F');
        }
        public function Footer() {
            $this->SetY(-17);
            $this->SetDrawColor(190, 220, 201);
            $this->Line(10, $this->GetY(), 200, $this->GetY());
            $this->SetFont('Arial','',7);
            $id = function_exists('pk01_pdf_identity') ? pk01_pdf_identity() : ['nama'=>'PK01'];
            $this->SetTextColor(70,90,75);
            $contact = array_filter([$id['telepon'] ?? '', $id['email'] ?? '', $id['website'] ?? '']);
            $footer = ($id['nama'] ?? 'PK01').' • Dokumen resmi sistem PK01';
            if ($contact) $footer .= ' • '.implode(' | ', $contact);
            $this->Cell(0,4,pk01_pdf_text($footer),0,1,'L');
            $v = $GLOBALS['pk01_pdf_validation'] ?? null;
            if (is_array($v) && !empty($v['url'])) {
                $qr = function_exists('pk01_pdf_qr_file') ? pk01_pdf_qr_file($v['url']) : '';
                if ($qr && is_readable($qr)) $this->Image($qr,184,278,12,12);
                $this->SetX(10);
                $this->Cell(168,4,pk01_pdf_text('Validasi QR: '.($v['label'] ?? 'Dokumen PK01')),0,0,'L');
                $this->Cell(20,4,'Halaman '.$this->PageNo(),0,0,'R');
            } else {
                $this->Cell(0,4,'Halaman '.$this->PageNo(),0,0,'R');
            }
        }
    }
}

if (!function_exists('pk01_pdf_validation_url')) {
    function pk01_pdf_validation_url($doc,$id=0,$number='') {
        $doc=sanitize_key($doc); $id=(int)$id; $number=sanitize_text_field((string)$number);
        $payload = $doc.'|'.$id.'|'.$number;
        $sig = hash_hmac('sha256',$payload,wp_salt('auth'));
        return add_query_arg(['pk01_doc_validate'=>$doc,'id'=>$id,'no'=>$number,'sig'=>$sig],home_url('/'));
    }
}
if (!function_exists('pk01_pdf_validation_page')) {
    function pk01_pdf_validation_page() {
        if (!isset($_GET['pk01_doc_validate'])) return;
        $doc=sanitize_key($_GET['pk01_doc_validate']); $id=(int)($_GET['id']??0); $number=sanitize_text_field(wp_unslash($_GET['no']??'')); $sig=sanitize_text_field(wp_unslash($_GET['sig']??''));
        $payload=$doc.'|'.$id.'|'.$number; $valid=hash_equals(hash_hmac('sha256',$payload,wp_salt('auth')),$sig);
        $db_ok=true; $stored_no=$number;
        if($valid && $id>0){
            global $wpdb;
            $map=['penjualan'=>['sales_orders',['invoice_no','order_no']],'produksi'=>['jobs',['job_no']],'label-produksi'=>['jobs',['job_no']],'label-thermal'=>['jobs',['job_no']],
                'retur'=>['returns',['return_no']],'retur-terima'=>['warehouse_documents',['doc_no']],'penerimaan'=>['goods_receipts',['receipt_no']],'penerimaan-supplier'=>['goods_receipts',['receipt_no']],
                'serah-terima-kurir'=>['warehouse_documents',['doc_no']],'pengiriman'=>['shipments',['tracking_no']],'upah-job'=>['job_wages',['reference_no']],'biaya-operasional'=>['operational_costs',['receipt_no','reference_no']],
                'slip-gaji'=>['payroll',['reference_no']],'penerimaan-laba'=>['owner_transactions',['reference_no']],'pembelian'=>['purchase_orders',['po_no']],'payout'=>['marketplace_payouts',['payout_no']]];
            if($doc==='penerimaan-supplier'){
                // Supplier-in dapat berasal dari Goods Receipt (canonical) atau
                // dokumen Gudang lama. Validasi harus mengikuti sumber ID yang benar.
                $gr_table=PK01_DB::t('goods_receipts');
                $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$gr_table}` WHERE id=%d LIMIT 1",$id),ARRAY_A);
                if($row){
                    $stored_no=(string)($row['receipt_no']??'');
                } else {
                    $wd_table=PK01_DB::t('warehouse_documents');
                    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$wd_table}` WHERE id=%d AND doc_type='supplier_in' LIMIT 1",$id),ARRAY_A);
                    $stored_no=(string)($row['doc_no']??'');
                }
                $db_ok=(bool)$row;
                if($db_ok && $number!=='' && $stored_no!=='' && !hash_equals($stored_no,$number)) $db_ok=false;
            } elseif(isset($map[$doc])){
                $table=PK01_DB::t($map[$doc][0]); $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE id=%d LIMIT 1",$id),ARRAY_A);
                $db_ok=(bool)$row; if($row){$stored_no=''; foreach($map[$doc][1] as $k){if(isset($row[$k])&&trim((string)$row[$k])!==''){$stored_no=(string)$row[$k];break;}} if($number!=='' && $stored_no!=='' && !hash_equals($stored_no,$number)) $db_ok=false;}
            }
        }
        $valid=$valid && $db_ok; status_header($valid?200:403); nocache_headers();
        $name=function_exists('pk01_pdf_identity') ? pk01_pdf_identity()['nama'] : get_bloginfo('name');
        wp_die($valid ? '<div style="font-family:Arial;max-width:650px;margin:60px auto;padding:32px;border:1px solid #b9dec5;border-radius:14px;background:#e8f7ee"><h1 style="color:#146b3a">✓ Dokumen Terverifikasi</h1><p><b>'.esc_html($name).'</b></p><p>Nomor dan referensi dokumen cocok dengan data PK01 yang tersimpan.</p><p>Jenis: <b>'.esc_html($doc).'</b><br>Nomor: <b>'.esc_html($number?:$stored_no?:'-').'</b><br>ID transaksi: <b>#'.(int)$id.'</b></p><p style="font-size:12px">QR ini ditandatangani server PK01 dan tidak valid jika parameter nomor, ID, atau tanda tangan diubah.</p></div>' : 'Validasi dokumen PK01 gagal atau data dokumen tidak cocok.', $valid?'Dokumen PK01 Terverifikasi':'Validasi Gagal', ['response'=>$valid?200:403,'back_link'=>true]);
    }
}
add_action('template_redirect','pk01_pdf_validation_page',1);

if (!function_exists('pk01_pdf_prepare_validation')) {
    function pk01_pdf_prepare_validation($doc,$id=0,$number='') {
        $doc=sanitize_key($doc); $id=(int)$id; $number=sanitize_text_field((string)$number);
        $GLOBALS['pk01_pdf_validation']=['url'=>pk01_pdf_validation_url($doc,$id,$number),'label'=>$doc.($number?' • '.$number:'')];
        return $GLOBALS['pk01_pdf_validation'];
    }
}

if (!function_exists('pk01_pdf_available')) {
    function pk01_pdf_available() {
        return pk01_pdf_load_fpdf();
    }
}

function pk01_pdf_text($text) {
    $text = (string)$text;
    $text = preg_replace('/[\x{10000}-\x{10FFFF}]/u', '', $text);
    if (function_exists('iconv')) {
        $v = @iconv('UTF-8', 'windows-1252//TRANSLIT//IGNORE', $text);
        if ($v !== false) return $v;
    }
    return function_exists('utf8_decode') ? utf8_decode($text) : $text;
}
function pk01_pdf_money($n) { return class_exists('PK01_Settings') ? PK01_Settings::money($n) : 'Rp ' . number_format((float)$n, 0, ',', '.'); }
function pk01_pdf_product_payload($product_code,$sku,$production_date='',$batch_no='',$unit_id='') {
    $base=home_url('/');
    $args=['pk01_produk'=>(string)$sku];
    if($production_date) $args['tgl_produksi']=(string)$production_date;
    if($batch_no) $args['pk01_batch']=(string)$batch_no;
    if($unit_id) $args['pk01_unit']=(string)$unit_id;
    $url=add_query_arg($args,$base);
    return $url;
}
function pk01_pdf_code39_safe($code,$max=40){
    $code=strtoupper(preg_replace('/[^A-Z0-9. \-\$\/\+\%]/','',(string)$code));
    return substr($code,0,$max);
}
function pk01_pdf_identity() {
    if (class_exists('PK01_Settings') && method_exists('PK01_Settings', 'identity')) {
        $i = PK01_Settings::identity();
        return [
            'nama' => $i['name'] ?? get_bloginfo('name'),
            'legal_name' => $i['legal_name'] ?? '',
            'tagline' => $i['tagline'] ?? '',
            'owner' => $i['owner'] ?? '',
            'alamat' => $i['address'] ?? '',
            'telepon' => $i['phone'] ?? '',
            'whatsapp' => $i['whatsapp'] ?? '',
            'email' => $i['email'] ?? get_option('admin_email'),
            'website' => $i['website'] ?? home_url('/'),
            'nib' => $i['nib'] ?? '',
            'npwp' => $i['npwp'] ?? '',
            'logo' => $i['logo'] ?? '',
            'stamp' => $i['stamp'] ?? '',
            'signee_name' => $i['signee_name'] ?? '',
            'signee_position' => $i['signee_position'] ?? '',
            'bank_name' => $i['bank_name'] ?? '',
            'bank_account_number' => $i['bank_account_number'] ?? '',
            'bank_account_name' => $i['bank_account_name'] ?? '',
            'invoice_terms' => $i['invoice_terms'] ?? '',
        ];
    }
    $s = (array)get_option('pk01_settings', []);
    return [
        'nama' => sanitize_text_field($s['company_name'] ?? get_bloginfo('name')),
        'legal_name' => sanitize_text_field($s['company_legal_name'] ?? ''),
        'tagline' => sanitize_text_field($s['company_tagline'] ?? ''),
        'owner' => sanitize_text_field($s['company_owner'] ?? ''),
        'alamat' => sanitize_text_field($s['company_address'] ?? ''),
        'telepon' => sanitize_text_field($s['company_phone'] ?? ''),
        'whatsapp' => sanitize_text_field($s['company_whatsapp'] ?? ''),
        'email' => sanitize_email($s['company_email'] ?? get_option('admin_email')),
        'website' => esc_url_raw($s['company_website'] ?? home_url('/')),
        'nib' => sanitize_text_field($s['company_nib'] ?? ''),
        'npwp' => sanitize_text_field($s['company_npwp'] ?? ''),
        'logo' => esc_url_raw($s['company_logo'] ?? ''),
        'stamp' => esc_url_raw($s['company_stamp'] ?? ''),
        'signee_name' => sanitize_text_field($s['signee_name'] ?? ''),
        'signee_position' => sanitize_text_field($s['signee_position'] ?? ''),
        'bank_name' => sanitize_text_field($s['bank_name'] ?? ''),
        'bank_account_number' => sanitize_text_field($s['bank_account_number'] ?? ''),
        'bank_account_name' => sanitize_text_field($s['bank_account_name'] ?? ''),
        'invoice_terms' => (string)($s['invoice_terms'] ?? ''),
    ];
}

if (!function_exists('pk01_pdf_document_number')) {
    /**
     * Ambil nomor dokumen yang SUDAH tersimpan pada transaksi. Fungsi ini tidak
     * menaikkan sequence, sehingga cetak ulang tidak pernah membuat nomor baru.
     */
    function pk01_pdf_document_number($row, array $keys = [], $fallback = '-') {
        $row = is_array($row) ? $row : [];
        foreach ($keys as $key) {
            if (isset($row[$key]) && trim((string)$row[$key]) !== '') return (string)$row[$key];
        }
        return (string)$fallback;
    }
}

if (!function_exists('pk01_pdf_doc_footer_note')) {
    function pk01_pdf_doc_footer_note(FPDF $pdf, $text) {
        $pdf->Ln(5);
        $pdf->SetFont('Arial','I',7.5);
        $pdf->SetTextColor(90,100,95);
        $pdf->MultiCell(0,4,pk01_pdf_text($text));
        $pdf->SetTextColor(0,0,0);
    }
}

if (!function_exists('pk01_pdf_logo_path')) {
    function pk01_pdf_logo_path($url='') {
        $url = (string)$url;
        if ($url === '') return '';
        $attachment_id = function_exists('attachment_url_to_postid') ? attachment_url_to_postid($url) : 0;
        if ($attachment_id) {
            $file = get_attached_file($attachment_id);
            if ($file && is_readable($file)) return $file;
        }
        $upload = wp_upload_dir();
        if (!empty($upload['baseurl']) && !empty($upload['basedir']) && strpos($url, $upload['baseurl']) === 0) {
            $file = $upload['basedir'] . substr($url, strlen($upload['baseurl']));
            if (is_readable($file)) return $file;
        }
        return '';
    }
}
function pk01_pdf_barcode39(FPDF $pdf, $code, $x, $y, $w=80, $h=18) {
    // Barcode Code 39: ringan, dapat digambar langsung oleh FPDF tanpa library tambahan.
    $patterns=['0'=>'nnnwwnwnn','1'=>'wnnwnnnnw','2'=>'nnwwnnnnw','3'=>'wnwwnnnnn','4'=>'nnnwwnnnw','5'=>'wnnwwnnnn','6'=>'nnwwwnnnn','7'=>'nnnwnnwnw','8'=>'wnnwnnwnn','9'=>'nnwwnnwnn','A'=>'wnnnnwnnw','B'=>'nnwnnwnnw','C'=>'wnwnnwnnn','D'=>'nnnnwwnnw','E'=>'wnnnwwnnn','F'=>'nnwnwwnnn','G'=>'nnnnnwwnw','H'=>'wnnnnwwnn','I'=>'nnwnnwwnn','J'=>'nnnnwwwnn','K'=>'wnnnnnnww','L'=>'nnwnnnnww','M'=>'wnwnnnnwn','N'=>'nnnnwnnww','O'=>'wnnnwnnwn','P'=>'nnwnwnnwn','Q'=>'nnnnnnwww','R'=>'wnnnnnwwn','S'=>'nnwnnnwwn','T'=>'nnnnwnwwn','U'=>'wwnnnnnnw','V'=>'nwwnnnnnw','W'=>'wwwnnnnnn','X'=>'nwnnwnnnw','Y'=>'wwnnwnnnn','Z'=>'nwwnwnnnn','-'=>'nwnnnnwnw','.'=>'wwnnnnwnn',' '=>'nwwnnnwnn','$'=>'nwnwnwnnn','/'=>'nwnwnnnwn','+'=>'nwnnnwnwn','%'=>'nnnwnwnwn','*'=>'nwnnwnwnn'];
    $code=strtoupper(preg_replace('/[^A-Z0-9. \-\$\/\+\%]/','',(string)$code)); if($code==='')return;
    $full='*'.$code.'*'; $modules=0; foreach(str_split($full) as $ch){$pat=$patterns[$ch]??$patterns[' ']; for($i=0;$i<strlen($pat);$i++)$modules+=($pat[$i]==='w'?3:1); $modules+=1;}
    $unit=$w/max(1,$modules); $x0=$x;
    foreach(str_split($full) as $ch){$pat=$patterns[$ch]??$patterns[' ']; for($i=0;$i<strlen($pat);$i++){ $bar=$pat[$i]; $ww=$unit*($bar==='w'?3:1); if($i%2===0)$pdf->Rect($x,$y,$ww,$h,'F'); $x+=$ww; } $x+=$unit; }
    $pdf->SetFont('Arial','',7); $pdf->SetXY($x0,$y+$h+1); $pdf->Cell($w,4,pk01_pdf_text($code),0,0,'C');
}
if (!function_exists('pk01_pdf_barcode128')) {
    // Nama lama dipertahankan agar modul lama tidak rusak. Implementasinya Code 39.
    function pk01_pdf_barcode128(FPDF $pdf, $code, $x, $y, $w=80, $h=18) {
        return pk01_pdf_barcode39($pdf, $code, $x, $y, $w, $h);
    }
}

function pk01_pdf_qr_file($data) {
    // QR dibuat saat dokumen dicetak dan disimpan di uploads/pk01. QR bukan sumber data;
    // barcode tetap menjadi fallback bila layanan QR eksternal tidak tersedia.
    $data = rawurlencode((string)$data);
    $upload = wp_upload_dir();
    if (!empty($upload['basedir']) && wp_mkdir_p($upload['basedir'].'/pk01')) {
        $file = trailingslashit($upload['basedir']).'pk01/qr-'.md5($data).'.png';
        if (is_readable($file)) return $file;
        $url = 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&margin=4&data='.$data;
        $r = wp_remote_get($url,['timeout'=>6,'redirection'=>2]);
        if (!is_wp_error($r) && wp_remote_retrieve_response_code($r)===200) {
            $body=wp_remote_retrieve_body($r);
            if ($body && substr($body,0,8)==="\x89PNG\r\n\x1a\n") { @file_put_contents($file,$body); return is_readable($file)?$file:''; }
        }
    }
    return '';
}
function pk01_pdf_header(FPDF $pdf,$title,$number='') {
    $id=pk01_pdf_identity();
    $logo = pk01_pdf_logo_path($id['logo'] ?? '');
    $textX = 10;
    if ($logo) {
        try { $pdf->Image($logo,10,11,28,20); $textX=43; } catch (Throwable $e) { $textX=10; }
    }
    $pdf->SetXY($textX,10);
    $pdf->SetFont('Arial','B',15); $pdf->Cell(157,7,pk01_pdf_text($id['nama']),0,1);
    if (!empty($id['legal_name']) && $id['legal_name'] !== $id['nama']) { $pdf->SetX($textX); $pdf->SetFont('Arial','B',9); $pdf->Cell(157,5,pk01_pdf_text($id['legal_name']),0,1); }
    if (!empty($id['tagline'])) { $pdf->SetX($textX); $pdf->SetFont('Arial','I',7.5); $pdf->Cell(157,4,pk01_pdf_text($id['tagline']),0,1); }
    $pdf->SetX($textX); $pdf->SetFont('Arial','B',11); $pdf->Cell(157,7,pk01_pdf_text($title),0,1);
    $meta=[];
    if (!empty($id['alamat'])) $meta[]=$id['alamat'];
    $contact=array_filter([$id['telepon'] ? 'Telp '.$id['telepon'] : '', $id['whatsapp'] ? 'WA '.$id['whatsapp'] : '', $id['email'] ? $id['email'] : '', $id['website'] ? $id['website'] : '']);
    if ($contact) $meta[] = implode(' | ', $contact);
    $legal=array_filter([$id['nib'] ? 'NIB '.$id['nib'] : '', $id['npwp'] ? 'NPWP '.$id['npwp'] : '']);
    if ($legal) $meta[] = implode(' | ', $legal);
    $pdf->SetX($textX); $pdf->SetFont('Arial','',7.5);
    foreach ($meta as $line) { $pdf->Cell(157,4.5,pk01_pdf_text($line),0,1); }
    $pdf->SetX($textX); $pdf->Cell(157,4.5,pk01_pdf_text(($number?'No. '.$number.' | ':'').'Tanggal '.current_time('d-m-Y H:i')),0,1);
    $pdf->SetY(max(38,$pdf->GetY()+2)); $pdf->Line(10,$pdf->GetY(),200,$pdf->GetY()); $pdf->Ln(4);
}
function pk01_pdf_emit($title,$filename) {
    $pdf = class_exists('PK01_PDF') ? new PK01_PDF('P','mm','A4') : new FPDF('P','mm','A4'); $pdf->SetMargins(10,10,10); $pdf->SetAutoPageBreak(true,15); $pdf->SetTitle(pk01_pdf_text($title)); $pdf->SetAuthor(pk01_pdf_text(pk01_pdf_identity()['nama'])); $pdf->AddPage();
    return [$pdf, $filename];
}
function pk01_pdf_installation_section(FPDF $pdf, $product_name='Wall Decor', $sku='') {
    $pdf->AddPage();
    pk01_pdf_header($pdf,'PETUNJUK PEMASANGAN WALL DECOR',$sku ?: 'PETUNJUK-PEMASANGAN');
    $pdf->SetFont('Arial','B',12); $pdf->Cell(0,7,pk01_pdf_text($product_name),0,1);
    $pdf->SetFont('Arial','',9);
    $pdf->MultiCell(0,5,pk01_pdf_text('Panduan pemasangan standar PK01. Gunakan alat dan pengikat yang sesuai dengan jenis dinding, ukuran produk, dan beban produk. Jika kondisi dinding meragukan, minta bantuan teknisi.'));
    $pdf->Ln(3);
    $steps=[
      ['1. PERIKSA PRODUK','Pastikan produk, titik gantung belakang, baut/pengikat, dan aksesori dalam kondisi baik sebelum pemasangan.'],
      ['2. TENTUKAN POSISI','Tempatkan produk pada posisi yang diinginkan. Gunakan meteran dan waterpass agar posisi lurus dan proporsional.'],
      ['3. TANDAI TITIK BOR','Tandai titik lubang pada dinding berdasarkan titik gantung di bagian belakang produk. Pastikan area aman dari kabel listrik atau pipa tersembunyi.'],
      ['4. BOR DINDING','Gunakan mata bor yang sesuai dengan jenis dinding. Bor tegak lurus pada titik yang sudah ditandai dan gunakan kedalaman secukupnya.'],
      ['5. PASANG FISHER / ANCHOR','Gunakan fisher atau anchor yang sesuai dengan material dinding dan kapasitas beban.'],
      ['6. PASANG BAUT','Pasang baut pada titik pengikat. Kencangkan secukupnya agar kuat tanpa merusak produk atau dinding.'],
      ['7. PASANG WALL DECOR','Pasang bagian belakang Wall Decor pada baut/titik gantung. Pastikan seluruh titik gantung masuk dengan benar dan produk tidak goyang.'],
      ['8. CEK AKHIR','Periksa kembali kerataan, kestabilan, dan kekuatan semua titik pengikat sebelum produk ditinggalkan.'],
    ];
    foreach($steps as $st){ $pdf->SetFont('Arial','B',9); $pdf->Cell(0,6,pk01_pdf_text($st[0]),0,1); $pdf->SetFont('Arial','',8.5); $pdf->MultiCell(0,4.5,pk01_pdf_text($st[1])); $pdf->Ln(1.5); }
    $pdf->Ln(2); $pdf->SetFont('Arial','B',9); $pdf->Cell(0,6,pk01_pdf_text('CATATAN KESELAMATAN'),0,1); $pdf->SetFont('Arial','',8.5);
    $pdf->MultiCell(0,4.5,pk01_pdf_text('Jangan mengebor sebelum memastikan area aman dari kabel listrik dan pipa. Gunakan perlengkapan keselamatan kerja. Untuk gypsum, bata ringan, beton, atau material khusus, gunakan sistem anchor yang memang diperuntukkan untuk material tersebut. Kapasitas beban mengikuti konstruksi produk dan kemampuan pengikat/dinding di lokasi pemasangan.'));
    $pdf->Ln(3); $pdf->SetFont('Arial','I',8); $pdf->MultiCell(0,4.5,pk01_pdf_text('Dokumen ini dibuat dari data produk PK01. Simpan bersama produk untuk memudahkan pemasangan, servis, dan identifikasi.'));
}
function pk01_pdf_print_installation($id) {
    global $wpdb; if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    $r=$wpdb->get_row($wpdb->prepare('SELECT v.*,p.name product_name,p.code product_code FROM '.PK01_DB::t('product_variants').' v JOIN '.PK01_DB::t('products').' p ON p.id=v.product_id WHERE v.id=%d',$id),ARRAY_A); if(!$r) wp_die('Produk tidak ditemukan.');
    [$pdf,$fn]=pk01_pdf_emit('Petunjuk Pemasangan','petunjuk-pemasangan-'.sanitize_file_name($r['sku']).'.pdf'); pk01_pdf_installation_section($pdf,$r['product_name'].' — '.$r['name'],$r['sku']);
    $qr=pk01_pdf_qr_file(pk01_pdf_product_payload($r['product_code']??'', $r['sku'], '', '', '')); if($qr){$pdf->SetY(235);$pdf->SetFont('Arial','B',8);$pdf->Cell(0,5,pk01_pdf_text('SCAN QR PRODUK'),0,1,'C');$pdf->Image($qr,87,241,36,36);} $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_product($id) {
    global $wpdb; if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    if(!$id) $id=(int)$wpdb->get_var('SELECT id FROM '.PK01_DB::t('products').' ORDER BY id DESC LIMIT 1');
    $r=$wpdb->get_row($wpdb->prepare('SELECT p.*,v.id variant_id,v.sku,v.name variant_name,v.size,v.material,v.finishing,v.hpp FROM '.PK01_DB::t('products').' p JOIN '.PK01_DB::t('product_variants').' v ON v.product_id=p.id WHERE p.id=%d ORDER BY v.id LIMIT 1',$id),ARRAY_A); if(!$r) wp_die('Produk tidak ditemukan.');
    [$pdf,$fn]=pk01_pdf_emit('Kartu Produk','kartu-produk-'.$id.'.pdf'); pk01_pdf_header($pdf,'KARTU PRODUK',$r['code']); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,7,pk01_pdf_text($r['name']),0,1); $pdf->SetFont('Arial','',9); foreach([['SKU',$r['sku']],['Ukuran',$r['size']],['Bahan',$r['material']],['Finishing',$r['finishing']],['HPP',pk01_pdf_money($r['hpp'])]] as $x){$pdf->Cell(42,6,pk01_pdf_text($x[0]),1);$pdf->Cell(100,6,pk01_pdf_text($x[1]),1,1);} pk01_pdf_barcode128($pdf,$r['sku'],55,$pdf->GetY()+5,100,20); $qr=pk01_pdf_qr_file(pk01_pdf_product_payload($r['code'],$r['sku'])); if($qr) $pdf->Image($qr,160,55,30,30); pk01_pdf_installation_section($pdf,$r['name'].' — '.$r['variant_name'],$r['sku']); $pdf->Output('I',$fn); exit;
}
function pk01_pdf_print_production($id) {
    global $wpdb; if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    $j=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PK01_DB::t('jobs').' WHERE id=%d',$id),ARRAY_A); if(!$j) wp_die('Batch produksi tidak ditemukan.');
    $items=$wpdb->get_results($wpdb->prepare('SELECT ji.qty,v.id variant_id,v.sku,v.name,v.hpp,p.code product_code,p.name product_name FROM '.PK01_DB::t('job_items').' ji JOIN '.PK01_DB::t('product_variants').' v ON v.id=ji.variant_id JOIN '.PK01_DB::t('products').' p ON p.id=v.product_id WHERE ji.job_id=%d',$id),ARRAY_A)?:[];
    [$pdf,$fn]=pk01_pdf_emit('Batch Produksi','batch-produksi-'.$id.'.pdf');
    pk01_pdf_header($pdf,'KARTU BATCH PRODUKSI',$j['job_no']);
    $pdf->SetFont('Arial','',9);
    foreach([['Produk',($items[0]['product_name']??'—').' — '.($items[0]['name']??'—')],['Kode Produk',$items[0]['product_code']??'—'],['SKU',$items[0]['sku']??'—'],['Tanggal Produksi',$j['production_date']??date('Y-m-d')],['Lokasi',$j['location']],['Target',$j['target_qty'].' pcs'],['Deadline',$j['deadline']?:'—'],['Status',$j['status']]] as $x){$pdf->Cell(42,6,pk01_pdf_text($x[0]),1);$pdf->Cell(148,6,pk01_pdf_text($x[1]),1,1);}
    $pdf->Ln(5); $pdf->SetFont('Arial','B',8); foreach(['SKU'=>32,'Produk'=>68,'Qty'=>25,'HPP'=>32,'Status'=>33] as $h=>$w)$pdf->Cell($w,7,pk01_pdf_text($h),1,0,'C'); $pdf->Ln(); $pdf->SetFont('Arial','',8);
    foreach($items as $x){$pdf->Cell(32,7,pk01_pdf_text($x['sku']),1);$pdf->Cell(68,7,pk01_pdf_text($x['name']),1);$pdf->Cell(25,7,number_format($x['qty'],0,',','.'),1,0,'R');$pdf->Cell(32,7,pk01_pdf_money($x['hpp']),1,0,'R');$pdf->Cell(33,7,pk01_pdf_text('PRODUKSI'),1,1,'C');}
    $pdf->Ln(6); $first=$items[0]??null;
    if($first){
        $barcode=pk01_pdf_code39_safe(($first['product_code']?:$first['sku']).'-'.str_replace('-','',$j['production_date']??date('Y-m-d')).'-'.$j['job_no']);
        pk01_pdf_barcode128($pdf,$barcode,20,$pdf->GetY(),120,20);
        $qr=pk01_pdf_qr_file(pk01_pdf_product_payload($first['product_code'],$first['sku'],$j['production_date']??'', $j['job_no']));
        if($qr) $pdf->Image($qr,155,$pdf->GetY()-2,32,32);
        $pdf->SetY($pdf->GetY()+29); $pdf->SetFont('Arial','B',8); $pdf->Cell(0,5,pk01_pdf_text('QR IDENTITAS PRODUK / BATCH'),0,1);
        $pdf->SetFont('Arial','',7.5); $pdf->MultiCell(0,4,pk01_pdf_text('QR berisi identitas Produk, SKU, tanggal produksi, dan nomor batch. QR ini bukan QRIS pembayaran.'));
    }
    $pdf->SetFont('Arial','B',9); $pdf->Cell(0,6,pk01_pdf_text('PETUNJUK PELAKSANAAN PRODUKSI'),0,1); $pdf->SetFont('Arial','',8.5);
    $pdf->MultiCell(0,4.5,pk01_pdf_text('Gunakan kartu ini sebagai identitas batch. Pastikan SKU dan tanggal produksi sesuai sebelum produksi dimulai. Setelah hasil produksi disetujui, setiap unit baik mendapatkan nomor unit yang dapat dicetak sebagai label produk.'));
    $pdf->Output('I',$fn); exit;
}
function pk01_pdf_print_production_thermal($id) {
    global $wpdb; if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    $j=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PK01_DB::t('jobs').' WHERE id=%d',$id),ARRAY_A); if(!$j) wp_die('Job produksi tidak ditemukan.');
    $rows=$wpdb->get_results($wpdb->prepare('SELECT u.*,v.sku,v.name variant_name,v.material,v.finishing,p.code product_code,p.name product_name,p.product_length,p.product_width,p.product_height,p.product_thickness,p.dimension_unit FROM '.PK01_DB::t('production_units').' u JOIN '.PK01_DB::t('product_variants').' v ON v.id=u.variant_id JOIN '.PK01_DB::t('products').' p ON p.id=v.product_id WHERE u.job_id=%d ORDER BY u.unit_no',$id),ARRAY_A)?:[];
    if(!$rows) wp_die('Belum ada unit hasil produksi yang dapat dicetak.');
    pk01_pdf_prepare_validation('label-thermal',$id,$j['job_no']??'');
    $pdf=new FPDF('P','mm',[58,78]); $pdf->SetMargins(4,4,4); $pdf->SetAutoPageBreak(false); $pdf->SetTitle(pk01_pdf_text('Label Produksi Thermal')); $pdf->SetAuthor(pk01_pdf_text(pk01_pdf_identity()['nama']));
    foreach($rows as $r){
        $pdf->AddPage(); $pdf->SetTextColor(0,0,0); $pdf->SetFont('Arial','B',8); $pdf->Cell(50,4,pk01_pdf_text('PK01 • HASIL PRODUKSI'),0,1,'C');
        $pdf->SetFont('Arial','B',8.5); $pdf->MultiCell(50,4.2,pk01_pdf_text($r['product_name'].' — '.$r['variant_name']),0,'C');
        $size=trim(($r['product_length']??'').' × '.($r['product_width']??'').' × '.($r['product_height']??'').' '.($r['dimension_unit']??'')); if((float)($r['product_thickness']??0)>0)$size.=' | T '.$r['product_thickness'].' '.($r['dimension_unit']??'');
        $pdf->SetFont('Arial','',6.7); $pdf->Cell(50,3.8,pk01_pdf_text('Ukuran: '.$size),0,1,'C');
        $pdf->Cell(50,3.8,pk01_pdf_text('SKU: '.($r['sku']?:'-').' | Job: '.$j['job_no']),0,1,'C');
        $pdf->Cell(50,3.8,pk01_pdf_text('Produksi: '.($r['production_date']?:$j['production_date']?:date('Y-m-d'))),0,1,'C');
        $pdf->Ln(1); $pdf->SetFont('Arial','B',8); $pdf->Cell(50,4,pk01_pdf_text('KODE CNC'),0,1,'C');
        pk01_pdf_barcode39($pdf,$r['cnc_code']?:$r['unit_id'],5,$pdf->GetY(),48,12);
        $pdf->SetY($pdf->GetY()+18); $pdf->SetFont('Arial','B',8); $pdf->Cell(50,4,pk01_pdf_text($r['cnc_code']?:$r['unit_id']),0,1,'C');
        $qr=pk01_pdf_qr_file($r['qr_payload']?:pk01_pdf_product_payload($r['product_code'],$r['sku'],$r['production_date']??$j['production_date']??'', $r['batch_no'],$r['cnc_code']?:$r['unit_id']));
        if($qr && is_readable($qr)) $pdf->Image($qr,19,$pdf->GetY()+1,20,20);
        $v=$GLOBALS['pk01_pdf_validation']??null; if(is_array($v)&&!empty($v['url'])){ $vq=pk01_pdf_qr_file($v['url']); if($vq&&is_readable($vq)){try{$pdf->Image($vq,4,60,10,10);}catch(Throwable $e){}} }
        $pdf->SetY($pdf->GetY()+22); $pdf->SetFont('Arial','',6.2); $pdf->Cell(50,3.5,pk01_pdf_text('Batch: '.($r['batch_no']?:'-')),0,1,'C');
        $pdf->Cell(50,3.5,pk01_pdf_text('Produksi: '.($r['production_code']?:'-')),0,1,'C');
        $pdf->Cell(50,3.5,pk01_pdf_text('SCAN = IDENTITAS PRODUK PK01'),0,1,'C');
    }
    $pdf->Output('I','label-produksi-thermal-'.$id.'.pdf'); exit;
}

function pk01_pdf_print_production_labels($id) {
    global $wpdb; if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    $j=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PK01_DB::t('jobs').' WHERE id=%d',$id),ARRAY_A); if(!$j) wp_die('Batch produksi tidak ditemukan.');
    $rows=$wpdb->get_results($wpdb->prepare('SELECT u.*,v.sku,v.name variant_name,p.code product_code,p.name product_name FROM '.PK01_DB::t('production_units').' u JOIN '.PK01_DB::t('product_variants').' v ON v.id=u.variant_id JOIN '.PK01_DB::t('products').' p ON p.id=v.product_id WHERE u.job_id=%d ORDER BY u.unit_no',$id),ARRAY_A)?:[];
    if(!$rows){ wp_die('Belum ada unit produk yang disetujui untuk batch ini. Simpan hasil produksi terlebih dahulu.'); }
    [$pdf,$fn]=pk01_pdf_emit('Label Produk Produksi','label-produk-'.$id.'.pdf');
    pk01_pdf_header($pdf,'LABEL PRODUK HASIL PRODUKSI',$j['job_no']);
    $pdf->SetFont('Arial','',8); $pdf->Cell(0,5,pk01_pdf_text('Produksi '.($j['production_date']??date('Y-m-d'))),0,1); $pdf->Ln(3);
    $count=0;
    foreach($rows as $r){
        if($count>0 && $count%4===0) $pdf->AddPage();
        $slot=$count%4; $x=10+($slot%2)*95; $y=30+floor($slot/2)*125;
        $pdf->SetDrawColor(180,185,190); $pdf->Rect($x,$y,88,112,'D');
        $pdf->SetXY($x+5,$y+5); $pdf->SetFont('Arial','B',10); $pdf->MultiCell(78,5,pk01_pdf_text($r['product_name'].' — '.$r['variant_name']),0,'L');
        $pdf->SetFont('Arial','',7.5); $pdf->SetX($x+5); $pdf->Cell(78,5,pk01_pdf_text('Kode: '.$r['product_code'].' | SKU: '.$r['sku']),0,1);
        $pdf->SetX($x+5); $pdf->Cell(78,5,pk01_pdf_text('Tanggal produksi: '.($r['production_date']??$j['production_date']??date('Y-m-d'))),0,1);
        $pdf->SetX($x+5); $pdf->Cell(78,5,pk01_pdf_text('Batch: '.$r['batch_no'].' | Unit: '.$r['unit_no']),0,1);
        $barcode=pk01_pdf_code39_safe($r['unit_id']); pk01_pdf_barcode128($pdf,$barcode,$x+6,$y+31,76,17);
        $qr=pk01_pdf_qr_file(pk01_pdf_product_payload($r['product_code'],$r['sku'],$r['production_date']??$j['production_date']??'', $r['batch_no'],$r['unit_id']));
        if($qr) $pdf->Image($qr,$x+27,$y+59,34,34);
        $pdf->SetXY($x+5,$y+96); $pdf->SetFont('Arial','B',7); $pdf->Cell(78,4,pk01_pdf_text('SCAN QR UNTUK IDENTITAS PRODUK'),0,1,'C');
        $pdf->SetFont('Arial','',6.5); $pdf->Cell(78,4,pk01_pdf_text('PK01 • Produk asli • '.$r['unit_id']),0,1,'C');
        $count++;
    }
    $pdf->Output('I',$fn); exit;
}


if (!function_exists('pk01_pdf_footer')) {
    function pk01_pdf_footer(FPDF $pdf) {
        $pdf->SetY(-14);
        $pdf->SetFont('Arial','',7);
        $pdf->SetTextColor(100,110,120);
        $pdf->Cell(95,5,pk01_pdf_text('Dokumen resmi PK01 • Dicetak '.current_time('d-m-Y H:i')),0,0,'L');
        $pdf->Cell(95,5,pk01_pdf_text('Halaman '.$pdf->PageNo()),0,0,'R');
        $pdf->SetTextColor(0,0,0);
    }
}
if (!function_exists('pk01_pdf_receipt_signature')) {
    function pk01_pdf_receipt_signature(FPDF $pdf, $received_by='') {
        $id = pk01_pdf_identity();
        $name = $received_by ?: ($id['signee_name'] ?? '');
        $position = $id['signee_position'] ?? '';
        $stamp = pk01_pdf_logo_path($id['stamp'] ?? '');
        $y = $pdf->GetY()+8;
        $pdf->SetY($y);
        $pdf->SetFont('Arial','',8);
        $pdf->Cell(95,5,pk01_pdf_text('Diterima oleh,'),0,0,'C');
        $pdf->Cell(95,5,pk01_pdf_text('Disetujui / Diverifikasi,'),0,1,'C');
        if ($stamp) { try { $pdf->Image($stamp,145,$pdf->GetY()+1,28,20); } catch (Throwable $e) {} }
        $pdf->Ln(22);
        $pdf->SetFont('Arial','B',8);
        $pdf->Cell(95,5,pk01_pdf_text($name ?: '________________'),0,0,'C');
        $pdf->Cell(95,5,pk01_pdf_text($id['signee_name'] ?: '________________'),0,1,'C');
        $pdf->SetFont('Arial','',7);
        $pdf->Cell(95,4,pk01_pdf_text($position ?: 'Petugas'),0,0,'C');
        $pdf->Cell(95,4,pk01_pdf_text($id['signee_position'] ?: 'Penanggung Jawab'),0,1,'C');
    }
}
function pk01_pdf_resolve_goods_receipt($id=0) {
    global $wpdb;
    $id=(int)$id;
    if($id<=0) return null;
    $tgr=PK01_DB::t('goods_receipts');
    $twd=PK01_DB::t('warehouse_documents');
    $tpo=PK01_DB::t('purchase_orders');
    $ts=PK01_DB::t('suppliers');
    $tm=PK01_DB::t('materials');

    // Canonical source: Goods Receipt transaction.
    $r=$wpdb->get_row($wpdb->prepare(
        "SELECT gr.*, po.po_no, s.name supplier_name, s.phone supplier_phone, s.address supplier_address,
                m.name material_name, m.code material_code, m.unit material_unit,
                wd.doc_no AS warehouse_doc_no
         FROM {$tgr} gr
         LEFT JOIN {$tpo} po ON po.id=gr.po_id
         LEFT JOIN {$ts} s ON s.id=po.supplier_id
         LEFT JOIN {$tm} m ON m.id=gr.material_id
         LEFT JOIN {$twd} wd ON wd.reference_no=gr.receipt_no AND wd.doc_type='supplier_in'
         WHERE gr.id=%d LIMIT 1", $id), ARRAY_A);
    if($r) {
        $r['_source_type']='goods_receipt';
        $r['_source_id']=$id;
        return $r;
    }

    // Legacy compatibility: a supplier-in warehouse document may be passed by its own ID.
    $w=$wpdb->get_row($wpdb->prepare(
        "SELECT wd.*, po.po_no, s.name supplier_name, s.phone supplier_phone, s.address supplier_address,
                gr.id AS goods_receipt_id, gr.receipt_no, gr.qty, gr.received_at, gr.received_by, gr.notes AS gr_notes,
                m.name material_name, m.code material_code, m.unit material_unit
         FROM {$twd} wd
         LEFT JOIN {$tgr} gr ON gr.receipt_no=wd.reference_no
         LEFT JOIN {$tpo} po ON po.id=gr.po_id
         LEFT JOIN {$ts} s ON s.id=po.supplier_id
         LEFT JOIN {$tm} m ON m.id=gr.material_id
         WHERE wd.id=%d AND wd.doc_type='supplier_in' LIMIT 1", $id), ARRAY_A);
    if(!$w) return null;
    $w['_source_type']='warehouse_document';
    $w['_source_id']=$id;
    if(empty($w['receipt_no'])) $w['receipt_no']=$w['reference_no']??'';
    if(empty($w['received_at'])) $w['received_at']=$w['created_at']??'';
    if(empty($w['received_by'])) $w['received_by']=$w['created_by']??0;
    if(empty($w['notes'])) $w['notes']=$w['gr_notes']??'';
    return $w;
}

function pk01_pdf_print_goods_receipt($id=0) {
    global $wpdb;
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id;

    // Individual print: resolve both canonical GR and legacy supplier-in documents.
    if($id>0) {
        $r=pk01_pdf_resolve_goods_receipt($id);
        if(!$r) wp_die('Bukti penerimaan tidak ditemukan atau belum tersimpan sebagai dokumen Gudang PK01.',404);
        $validation_doc=($r['_source_type']??'goods_receipt')==='goods_receipt' ? 'penerimaan' : 'penerimaan-supplier';
        $validation_no=$r['receipt_no'] ?: ($r['doc_no']??$r['reference_no']??'');
        pk01_pdf_prepare_validation($validation_doc,$id,$validation_no);
        [$pdf,$fn]=pk01_pdf_emit('Bukti Penerimaan Barang','bukti-penerimaan-'.$id.'.pdf');
        $display_no=$r['receipt_no'] ?: ($r['doc_no']??$r['reference_no']??'-');
        pk01_pdf_header($pdf,'BUKTI PENERIMAAN BARANG',$display_no);
        $pdf->SetFont('Arial','B',10); $pdf->Cell(95,7,pk01_pdf_text('DATA PEMASOK'),0,0); $pdf->Cell(95,7,pk01_pdf_text('DATA PENERIMAAN'),0,1);
        $pdf->SetFont('Arial','',8);
        $left=[['Pemasok',$r['supplier_name']?:($r['seller_name']??'-')],['Telepon',$r['supplier_phone']??'-'],['Alamat',$r['supplier_address']??'-']];
        $right=[['No. PO',$r['po_no']?:'-'],['No. Bukti',$display_no],['No. Gudang',$r['warehouse_doc_no']??($r['doc_no']??'-')],['Tanggal',$r['received_at']?:($r['created_at']??'-')],['Petugas',get_userdata((int)($r['received_by']??$r['created_by']??0)) ? get_userdata((int)($r['received_by']??$r['created_by']??0))->display_name : '-']];
        $max=max(count($left),count($right));
        for($i=0;$i<$max;$i++){ $a=$left[$i]??['','']; $b=$right[$i]??['','']; $pdf->Cell(24,6,pk01_pdf_text($a[0]),1); $pdf->Cell(71,6,pk01_pdf_text($a[1]),1); $pdf->Cell(24,6,pk01_pdf_text($b[0]),1); $pdf->Cell(71,6,pk01_pdf_text($b[1]),1,1); }
        $pdf->Ln(6); $pdf->SetFont('Arial','B',9); $pdf->Cell(30,7,pk01_pdf_text('Kode Bahan'),1); $pdf->Cell(75,7,pk01_pdf_text('Nama Bahan'),1); $pdf->Cell(30,7,pk01_pdf_text('Jumlah'),1); $pdf->Cell(55,7,pk01_pdf_text('Catatan'),1,1,'C');
        $pdf->SetFont('Arial','',9);
        $qty=(float)($r['qty']??0); $unit=$r['material_unit']??'';
        $qty_text=($r['_source_type']??'')==='warehouse_document' && $qty<=0 ? '—' : rtrim(rtrim(number_format($qty,4,',','.'),'0'),',').' '.$unit;
        $pdf->Cell(30,9,pk01_pdf_text($r['material_code']?:'-'),1); $pdf->Cell(75,9,pk01_pdf_text($r['material_name']?:'Belum tersedia pada GR'),1); $pdf->Cell(30,9,pk01_pdf_text($qty_text),1,0,'R'); $pdf->Cell(55,9,pk01_pdf_text(mb_strimwidth((string)($r['notes']??''),0,32,'...')),1,1);
        $pdf->Ln(8); $pdf->SetFont('Arial','B',9); $pdf->Cell(0,6,pk01_pdf_text('PERNYATAAN PENERIMAAN'),0,1); $pdf->SetFont('Arial','',8.5);
        $statement=($r['_source_type']??'')==='goods_receipt'
            ? 'Barang di atas telah diterima dan dicatat sebagai penerimaan gudang berdasarkan nomor PO, pemasok, dan transaksi Goods Receipt PK01. Kuantitas pada dokumen ini berasal langsung dari database dan menjadi dasar mutasi stok bahan.'
            : 'Dokumen supplier-in ini tercatat pada Gudang PK01. Data Goods Receipt detail belum ditemukan pada database sehingga dokumen tidak mengarang kuantitas atau bahan; lakukan sinkronisasi penerimaan sebelum menjadikannya dasar mutasi stok.';
        $pdf->MultiCell(0,5,pk01_pdf_text($statement));
        pk01_pdf_receipt_signature($pdf, get_userdata((int)($r['received_by']??$r['created_by']??0)) ? get_userdata((int)($r['received_by']??$r['created_by']??0))->display_name : 'Petugas Gudang');
        pk01_pdf_doc_footer_note($pdf,'Dokumen ini diterbitkan melalui PK01 PDF Gateway menggunakan FPDF canonical. QR pada footer memvalidasi referensi dokumen terhadap server PK01. Cetak ulang tidak membuat transaksi baru.');
        $pdf->Output('I',$fn); exit;
    }

    // Daftar cetak: hanya sumber transaksi nyata, tanpa nomor dummy.
    $tgr=PK01_DB::t('goods_receipts');
    $rows=$wpdb->get_results("SELECT gr.*, po.po_no, s.name supplier_name, m.name material_name, m.unit material_unit
        FROM {$tgr} gr LEFT JOIN ".PK01_DB::t('purchase_orders')." po ON po.id=gr.po_id
        LEFT JOIN ".PK01_DB::t('suppliers')." s ON s.id=po.supplier_id
        LEFT JOIN ".PK01_DB::t('materials')." m ON m.id=gr.material_id
        ORDER BY gr.id DESC LIMIT 100",ARRAY_A)?:[];
    [$pdf,$fn]=pk01_pdf_emit('Bukti Penerimaan Barang','daftar-bukti-penerimaan.pdf');
    pk01_pdf_prepare_validation('penerimaan',0,'DAFTAR-GR');
    pk01_pdf_header($pdf,'DAFTAR BUKTI PENERIMAAN BARANG','DAFTAR-GR');
    if(!$rows){$pdf->SetFont('Arial','',10);$pdf->Cell(0,8,pk01_pdf_text('Belum ada transaksi Goods Receipt tersimpan.'),0,1);$pdf->Output('I',$fn);exit;}
    $headers=['No. Bukti','No. PO','Pemasok','Bahan','Qty','Tanggal']; $widths=[28,28,42,43,18,31];
    $pdf->SetFont('Arial','B',7); foreach($headers as $i=>$h)$pdf->Cell($widths[$i],7,pk01_pdf_text($h),1,0,'C'); $pdf->Ln(); $pdf->SetFont('Arial','',7);
    foreach($rows as $r){$vals=[$r['receipt_no'],$r['po_no']?:'-',$r['supplier_name']?:'-',$r['material_name']?:'-',rtrim(rtrim(number_format((float)$r['qty'],4,'.',''),'0'),'.').' '.($r['material_unit']??''),$r['received_at']]; foreach($vals as $i=>$v)$pdf->Cell($widths[$i],6,pk01_pdf_text(mb_strimwidth((string)$v,0,24,'...')),1,0,$i===4?'R':'L'); $pdf->Ln();}
    $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_finance() {
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $from=sanitize_text_field($_GET['from']??date('Y-m-01'));$to=sanitize_text_field($_GET['to']??date('Y-m-d'));$r=PK01_Engine::financial_report($from,$to); [$pdf,$fn]=pk01_pdf_emit('Laporan Keuangan Usaha','laporan-keuangan-'.$from.'-'.$to.'.pdf'); pk01_pdf_header($pdf,'LAPORAN KEUANGAN USAHA',$from.' s/d '.$to);
    $rows=[['Penjualan Bersih',$r['net_sales']],['HPP',$r['hpp']],['Komisi Sales + Affiliate',$r['sales_commission']+$r['affiliate_commission']],['Fee Marketplace',$r['marketplace_fees']],['Bonus Target Seller/Marketing',$r['seller_target_bonus']??0],['Laba Kotor',$r['gross_profit']],['Biaya Operasional',$r['operational_cost']],['Beban Payroll Gross',$r['payroll']],['Upah Job',$r['job_wages']],['Penyusutan',$r['depreciation']],['Penurunan Nilai Persediaan',$r['inventory_write_down']],['Laba Bersih Terukur',$r['net_profit']],['Laba Bersih Akrual Payroll',$r['net_profit_accrual']??$r['net_profit']],['Kas Saat Ini',$r['cash_balance']]];
    $pdf->SetFont('Arial','',9); foreach($rows as $x){$pdf->Cell(95,7,pk01_pdf_text($x[0]),1);$pdf->Cell(95,7,pk01_pdf_money($x[1]),1,1,'R');} $pdf->Ln(5); $pdf->SetFont('Arial','I',8); $pdf->MultiCell(0,5,pk01_pdf_text('Laporan ini dihitung dari transaksi nyata PK01. Laba terukur berbasis pembayaran, sedangkan laba akrual memperhitungkan payroll yang telah dibukukan pada periode. Kas bukan laba.')); $pdf->Output('I',$fn); exit;
}


if (!function_exists('pk01_pdf_audit_print')) {
    function pk01_pdf_audit_print($doc, $id=0, $status='SUCCESS', $reason='') {
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit','write')) {
            PK01_Audit::write('document_print', 'documents', $doc, (string)$id, null,
                ['document'=>$doc,'record_id'=>(int)$id,'status'=>$status], $reason,
                $status === 'SUCCESS' ? 'SUCCESS' : 'ERROR', 'pdf');
        }
    }
}
if (!function_exists('pk01_pdf_validate_sales_invoice')) {
    function pk01_pdf_validate_sales_invoice(array $r, array $items) {
        $errors=[];
        if (empty($r['order_no']) && empty($r['invoice_no'])) $errors[]='Nomor order/invoice tidak tersedia.';
        if (empty($r['customer_name'])) $errors[]='Nama pelanggan belum tersedia.';
        if ((float)($r['price'] ?? 0) <= 0) $errors[]='Harga jual tidak valid (harus lebih besar dari 0).';
        if ((float)($r['qty'] ?? 0) <= 0) $errors[]='Kuantitas invoice tidak valid.';
        if ((float)($r['total_amount'] ?? 0) <= 0) $errors[]='Total invoice tidak valid.';
        $header_total=round((float)($r['qty'] ?? 0)*(float)($r['price'] ?? 0),2);
        $stored_total=round((float)($r['total_amount'] ?? 0),2);
        if (abs($header_total-$stored_total)>0.01) $errors[]='Total invoice tidak sama dengan Qty × Harga.';
        if ($items) {
            $item_total=0;
            foreach($items as $it){
                $q=(float)($it['qty']??0); $u=(float)($it['unit_price']??0); $t=(float)($it['total']??0);
                if($q<=0 || $u<=0 || $t<0) $errors[]='Ada item invoice dengan qty/harga tidak valid.';
                if(abs(round($q*$u,2)-round($t,2))>0.01) $errors[]='Ada item invoice dengan total tidak sesuai Qty × Harga.';
                $item_total += $t;
            }
            if(abs(round($item_total,2)-$stored_total)>0.01) $errors[]='Total item invoice tidak sama dengan total invoice.';
        }
        return array_values(array_unique($errors));
    }
}
if (!function_exists('pk01_pdf_section_title')) {
    function pk01_pdf_section_title(FPDF $pdf, $title) {
        $pdf->SetFillColor(242,247,244); $pdf->SetDrawColor(210,224,215);
        $pdf->SetFont('Arial','B',9); $pdf->Cell(190,7,pk01_pdf_text($title),1,1,'L',true);
        $pdf->SetFont('Arial','',8);
    }
}
if (!function_exists('pk01_pdf_kv_grid')) {
    function pk01_pdf_kv_grid(FPDF $pdf, array $rows) {
        $pdf->SetFont('Arial','',8.5);
        foreach($rows as $x){
            $label=(string)($x[0]??''); $value=(string)($x[1]??'-');
            $pdf->SetFillColor(248,250,249); $pdf->Cell(48,6,pk01_pdf_text($label),1,0,'L',true);
            $pdf->Cell(142,6,pk01_pdf_text($value?:'-'),1,1,'L');
        }
    }
}

function pk01_pdf_print_sales_invoice($id=0) {
    global $wpdb;
    if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id;
    if($id<=0) wp_die('Referensi invoice tidak valid.',400);
    $to=PK01_DB::t('sales_orders'); $tv=PK01_DB::t('product_variants'); $ti=PK01_DB::t('sales_order_items');
    $r=$wpdb->get_row($wpdb->prepare("SELECT o.*,v.sku AS variant_sku,v.name AS variant_name FROM {$to} o LEFT JOIN {$tv} v ON v.id=o.variant_id WHERE o.id=%d",$id),ARRAY_A);
    if(!$r){ pk01_pdf_audit_print('penjualan',$id,'ERROR','invoice_not_found'); wp_die('Invoice penjualan tidak ditemukan.'); }
    $items=$wpdb->get_results($wpdb->prepare("SELECT i.*,v.sku FROM {$ti} i LEFT JOIN {$tv} v ON v.id=i.variant_id WHERE i.order_id=%d ORDER BY i.id ASC",$id),ARRAY_A)?:[];
    if(!$items){
        // Backward-compatible fallback untuk record lama yang belum mempunyai baris item.
        $items=[['sku'=>$r['variant_sku']??'','product_name'=>$r['product_name']??($r['variant_name']??''),'qty'=>$r['qty']??0,'unit_price'=>$r['price']??0,'hpp'=>$r['hpp']??0,'total'=>$r['total_amount']??0]];
    }
    $errors=pk01_pdf_validate_sales_invoice($r,$items);
    if($errors){
        pk01_pdf_audit_print('penjualan',$id,'ERROR','invoice_validation_failed: '.implode(' | ',$errors));
        wp_die('<strong>Invoice tidak dapat dicetak.</strong><br>'.esc_html(implode(' ',$errors)).'<br><small>Perbaiki record melalui modul Penjualan PK01. Proses cetak tidak mengubah data.</small>','Validasi Invoice',['response'=>422,'back_link'=>true]);
    }
    pk01_pdf_audit_print('penjualan',$id,'SUCCESS','reprint');
    [$pdf,$fn]=pk01_pdf_emit('Invoice Penjualan','invoice-penjualan-'.$id.'.pdf');
    $number=$r['invoice_no']?:$r['order_no'];
    pk01_pdf_header($pdf,'INVOICE PENJUALAN',$number);

    pk01_pdf_section_title($pdf,'IDENTITAS TRANSAKSI');
    pk01_pdf_kv_grid($pdf,[
        ['No. Order',$r['order_no']?:'-'],['No. Invoice',$number?:'-'],
        ['Tanggal Transaksi',$r['created_at']?:'-'],['Pelanggan',$r['customer_name']?:'-'],
        ['Telepon',$r['customer_phone']?:'-'],['Alamat Pengiriman',$r['shipping_address']?:'-'],
        ['Kanal',$r['channel']?:'-'],['Status Pembayaran',strtoupper($r['payment_status']?:'unpaid')],
        ['Metode Pembayaran',$r['payment_method']?:'-'],['Status Pesanan',strtoupper($r['status']?:'-')],
        ['Status Pengiriman',strtoupper($r['shipping_status']?:'-')],['Nomor Resi',$r['tracking_no']?:'-']
    ]);

    $pdf->Ln(5); pk01_pdf_section_title($pdf,'RINCIAN PRODUK');
    $widths=[25,68,22,34,41];
    $heads=['SKU','Produk','Qty','Harga Satuan','Total'];
    $pdf->SetFont('Arial','B',8); foreach($heads as $i=>$h)$pdf->Cell($widths[$i],7,pk01_pdf_text($h),1,0,'C'); $pdf->Ln();
    $pdf->SetFont('Arial','',8);
    foreach($items as $it){
        $pdf->Cell(25,7,pk01_pdf_text($it['sku']??$r['variant_sku']??'-'),1);
        $pdf->Cell(68,7,pk01_pdf_text(mb_strimwidth((string)($it['product_name']??''),0,36,'...')),1);
        $pdf->Cell(22,7,number_format((float)$it['qty'],2,',','.'),1,0,'R');
        $pdf->Cell(34,7,pk01_pdf_money($it['unit_price']),1,0,'R');
        $pdf->Cell(41,7,pk01_pdf_money($it['total']),1,1,'R');
    }

    $total=(float)$r['total_amount']; $paid=(float)($r['paid_amount']??0); $balance=max(0,$total-$paid);
    $pdf->Ln(4); $pdf->SetFont('Arial','B',9);
    $pdf->Cell(149,7,pk01_pdf_text('TOTAL TAGIHAN'),1); $pdf->Cell(41,7,pk01_pdf_money($total),1,1,'R');
    $pdf->SetFont('Arial','',8.5);
    $pdf->Cell(149,6,pk01_pdf_text('TELAH DIBAYAR'),1); $pdf->Cell(41,6,pk01_pdf_money($paid),1,1,'R');
    $pdf->SetFont('Arial','B',9);
    $pdf->Cell(149,7,pk01_pdf_text('SISA TAGIHAN'),1); $pdf->Cell(41,7,pk01_pdf_money($balance),1,1,'R');

    $identity = pk01_pdf_identity();
    if (!empty($identity['bank_name']) || !empty($identity['bank_account_number']) || !empty($identity['bank_account_name'])) {
        $pdf->Ln(5); pk01_pdf_section_title($pdf,'INFORMASI PEMBAYARAN');
        $bank = trim(($identity['bank_name'] ?: '') . ($identity['bank_account_number'] ? ' • Rek. '.$identity['bank_account_number'] : '') . ($identity['bank_account_name'] ? ' • a.n. '.$identity['bank_account_name'] : ''));
        $pdf->SetFont('Arial','',8.5); $pdf->MultiCell(0,5,pk01_pdf_text($bank ?: 'Informasi rekening belum diatur pada Pengaturan Sentral.'));
    }
    if (!empty($identity['invoice_terms'])) {
        $pdf->Ln(3); pk01_pdf_section_title($pdf,'SYARAT & KETENTUAN');
        $pdf->SetFont('Arial','',8); $pdf->MultiCell(0,4.5,pk01_pdf_text($identity['invoice_terms']));
    }
    $pdf->Ln(5); pk01_pdf_section_title($pdf,'VALIDASI DOKUMEN');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(0,4.5,pk01_pdf_text('Dokumen ini dibentuk dari record transaksi PK01. Validasi internal memastikan Qty × Harga = Total, total item sesuai total invoice, dan harga/kuantitas bernilai valid. Cetak ulang tidak membuat order, payment, mutasi stok, komisi, atau transaksi keuangan baru.'));
    $pdf->Ln(3);
    $pdf->SetFont('Arial','I',7.5); $pdf->MultiCell(0,4,pk01_pdf_text('Jika dokumen lama tidak lolos validasi, PK01 sengaja memblokir pencetakan agar kesalahan data tidak ditutupi oleh PDF. Perbaiki sumber transaksi, lalu cetak ulang.'));
    $pdf->Output('I',$fn); exit;
}
function pk01_pdf_print_finance_ledger($from='',$to='') {
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $from=sanitize_text_field($from?:($_GET['from']??date('Y-m-01')));$to=sanitize_text_field($to?:($_GET['to']??date('Y-m-d')));
    $rows=class_exists('PK01_Finance')?PK01_Finance::ledger($from,$to):[];
    [$pdf,$fn]=pk01_pdf_emit('General Ledger','general-ledger-'.$from.'-'.$to.'.pdf');pk01_pdf_header($pdf,'GENERAL LEDGER',$from.' s/d '.$to);
    if(!$rows){$pdf->SetFont('Arial','',9);$pdf->Cell(0,8,pk01_pdf_text('Tidak ada jurnal pada periode ini.'),0,1);$pdf->Output('I',$fn);exit;}
    $pdf->SetFont('Arial','B',7);foreach([['Tanggal',22],['No. Jurnal',30],['Akun',52],['Debit',28],['Kredit',28],['Sumber',30]] as $h)$pdf->Cell($h[1],7,pk01_pdf_text($h[0]),1,0,'C');$pdf->Ln();$pdf->SetFont('Arial','',7);
    foreach($rows as $r){$pdf->Cell(22,6,pk01_pdf_text($r['entry_date']),1);$pdf->Cell(30,6,pk01_pdf_text($r['entry_no']),1);$pdf->Cell(52,6,pk01_pdf_text(mb_strimwidth($r['account_code'].' '.$r['account_name'],0,34,'…')),1);$pdf->Cell(28,6,pk01_pdf_money($r['debit']),1,0,'R');$pdf->Cell(28,6,pk01_pdf_money($r['credit']),1,0,'R');$pdf->Cell(30,6,pk01_pdf_text(mb_strimwidth($r['source_type'].' #'.$r['source_id'],0,20,'…')),1,1);}
    $pdf->Output('I',$fn);exit;
}
function pk01_pdf_print_list_from_query($title,$filename,$headers,$rows) {
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); [$pdf,$fn]=pk01_pdf_emit($title,$filename);pk01_pdf_header($pdf,$title,'PK01');
    if(!$rows){$pdf->SetFont('Arial','',9);$pdf->Cell(0,8,pk01_pdf_text('Belum ada data.'),0,1);$pdf->Output('I',$fn);exit;}
    $money=['amount','total_amount','refund_amount','total','rate','nominal','debit','credit','hpp','unit_price'];
    $count=max(1,count($headers)); $w=190/$count;
    $render_header=function() use($pdf,$headers,$w){$pdf->SetFont('Arial','B',7);foreach($headers as $h=>$label)$pdf->Cell($w,7,pk01_pdf_text($label),1,0,'C');$pdf->Ln();$pdf->SetFont('Arial','',7);};
    $render_header();
    foreach($rows as $r){
        if($pdf->GetY()>265){$pdf->AddPage();pk01_pdf_header($pdf,$title,'PK01');$render_header();}
        foreach($headers as $h=>$label){$v=$r[$h]??'';$is_money=in_array($h,$money,true);if($is_money)$v=pk01_pdf_money($v);$pdf->Cell($w,6,pk01_pdf_text(mb_strimwidth((string)$v,0,28,'...')),1,0,$is_money?'R':'L');}$pdf->Ln();
    }
    $pdf->Output('I',$fn);exit;
}

function pk01_pdf_print_job_wage_slip($id=0) {
    global $wpdb;
    if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id; if($id<=0) wp_die('Referensi upah job tidak valid.',400);
    $tw=PK01_DB::t('job_wages'); $te=PK01_DB::t('employees'); $tj=PK01_DB::t('jobs');
    $w=$wpdb->get_row($wpdb->prepare("SELECT w.*,e.code employee_code,e.name employee_name,e.position,e.division,j.job_no FROM {$tw} w LEFT JOIN {$te} e ON e.id=w.employee_id LEFT JOIN {$tj} j ON j.id=w.job_id WHERE w.id=%d",$id),ARRAY_A);
    if(!$w) wp_die('Data upah job tidak ditemukan.');
    $slip_no=$w['slip_no']?:'UPAH-'.$w['id'];
    $rows=$wpdb->get_results($wpdb->prepare("SELECT w.*,j.job_no FROM {$tw} w LEFT JOIN {$tj} j ON j.id=w.job_id WHERE w.employee_id=%d AND ((w.slip_no<>'' AND w.slip_no=%s) OR (w.slip_no IS NULL OR w.slip_no='') AND w.id=%d) ORDER BY w.id ASC",(int)$w['employee_id'],$slip_no,$id),ARRAY_A)?:[$w];
    [$pdf,$fn]=pk01_pdf_emit('Slip Upah Job','slip-upah-job-'.$id.'.pdf');
    pk01_pdf_header($pdf,'SLIP UPAH PEKERJAAN / JOB',$slip_no);
    pk01_pdf_section_title($pdf,'IDENTITAS PEKERJA');
    pk01_pdf_kv_grid($pdf,[['Nama', $w['employee_name']?:'-'],['Kode Karyawan',$w['employee_code']?:'-'],['Jabatan',$w['position']?:'-'],['Divisi',$w['division']?:'-'],['Tanggal Pembayaran',$w['paid_at']?:'-'],['Metode',$w['payment_method']?:'-'],['Status',strtoupper($w['status']?:'-')]]);
    $pdf->Ln(5); pk01_pdf_section_title($pdf,'RINCIAN PEKERJAAN');
    $pdf->SetFont('Arial','B',8); foreach([['Job',35],['Pekerjaan',75],['Qty',20],['Tarif',30],['Nominal',30]] as $h)$pdf->Cell($h[1],7,pk01_pdf_text($h[0]),1,0,'C'); $pdf->Ln();
    $pdf->SetFont('Arial','',8); $total=0;
    foreach($rows as $r){$amt=(float)$r['amount'];$total+=$amt;$pdf->Cell(35,7,pk01_pdf_text($r['job_no']?:'JOB-'.$r['job_id']),1);$pdf->Cell(75,7,pk01_pdf_text(mb_strimwidth((string)$r['job_detail'],0,34,'...')),1);$pdf->Cell(20,7,number_format((float)$r['qty'],2,',','.').' '.($r['unit']?:''),1,0,'R');$pdf->Cell(30,7,pk01_pdf_money($r['rate']),1,0,'R');$pdf->Cell(30,7,pk01_pdf_money($amt),1,1,'R');}
    $pdf->SetFont('Arial','B',9);$pdf->Cell(160,8,pk01_pdf_text('TOTAL DITERIMA'),1);$pdf->Cell(30,8,pk01_pdf_money($total),1,1,'R');
    pk01_pdf_doc_footer_note($pdf,'Nomor slip berasal dari transaksi Upah Job PK01. Cetak ulang hanya membaca data yang sudah dibukukan dan tidak membayar ulang pekerjaan.');
    $pdf->Ln(14);$pdf->SetFont('Arial','',8);$pdf->Cell(95,5,pk01_pdf_text('Penerima'),0,0,'C');$pdf->Cell(95,5,pk01_pdf_text('Penanggung Jawab'),0,1,'C');$pdf->Ln(18);$pdf->Cell(95,5,pk01_pdf_text($w['employee_name']?:'________________'),0,0,'C');$pdf->Cell(95,5,pk01_pdf_text('________________________'),0,1,'C');
    $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_business_doc($doc,$id=0) {
    global $wpdb;$id=(int)$id;
    switch($doc){
      case 'penjualan': return pk01_pdf_print_sales_invoice($id);
      case 'general-ledger': return pk01_pdf_print_finance_ledger();
      case 'upah-job': return pk01_pdf_print_job_wage_slip($id);
      case 'biaya-operasional': return pk01_pdf_print_expense_receipt($id);
      case 'bonus-target': $r=$wpdb->get_results($wpdb->prepare('SELECT sb.id,sb.period_key,sb.sales_amount,sb.target_amount,sb.bonus_amount,sb.status,sb.reference_no,s.name seller_name,s.code seller_code FROM '.PK01_DB::t('seller_bonus_ledger').' sb LEFT JOIN '.PK01_DB::t('sales_accounts').' s ON s.id=sb.seller_account_id WHERE sb.id=%d',$id),ARRAY_A); return pk01_pdf_print_list_from_query('Bonus Target Penjualan','bonus-target-'.$id.'.pdf',['id'=>'ID','seller_code'=>'Kode','seller_name'=>'Peserta','period_key'=>'Periode','sales_amount'=>'Penjualan','target_amount'=>'Target','bonus_amount'=>'Bonus','status'=>'Status','reference_no'=>'Referensi'],$r);
      case 'pengiriman': $r=$wpdb->get_results($wpdb->prepare('SELECT id,tracking_no,courier,service,recipient_name,status,created_at FROM '.PK01_DB::t('shipments').' WHERE id=%d',$id),ARRAY_A); return pk01_pdf_print_list_from_query('Dokumen Pengiriman','pengiriman-'.$id.'.pdf',['id'=>'ID','tracking_no'=>'Resi','courier'=>'Kurir','service'=>'Layanan','recipient_name'=>'Penerima','status'=>'Status','created_at'=>'Dibuat'],$r);
      case 'karyawan': $r=$wpdb->get_results($wpdb->prepare('SELECT id,code,name,position,division,status FROM '.PK01_DB::t('employees').' WHERE id=%d',$id),ARRAY_A); return pk01_pdf_print_list_from_query('Data Karyawan','karyawan-'.$id.'.pdf',['id'=>'ID','code'=>'Kode','name'=>'Nama','position'=>'Jabatan','division'=>'Divisi','status'=>'Status'],$r);
    }
    wp_die('Dokumen tidak dikenali.',400);
}


function pk01_pdf_print_return_receipts($id=0) {
    global $wpdb;
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id; if($id<=0) wp_die('Referensi retur tidak valid.',400);
    $tr=PK01_DB::t('returns'); $tri=PK01_DB::t('return_items'); $tv=PK01_DB::t('product_variants'); $tsa=PK01_DB::t('sales_accounts'); $twd=PK01_DB::t('warehouse_documents');
    $r=$wpdb->get_row($wpdb->prepare("SELECT r.*,COALESCE(sa.name,'') seller_name FROM {$tr} r LEFT JOIN {$tsa} sa ON sa.id=r.seller_account_id WHERE r.id=%d",$id),ARRAY_A);
    if(!$r) wp_die('Data retur tidak ditemukan.');
    $item=$wpdb->get_row($wpdb->prepare("SELECT ri.*,v.sku,v.name product_name FROM {$tri} ri LEFT JOIN {$tv} v ON v.id=ri.variant_id WHERE ri.return_id=%d ORDER BY ri.id ASC LIMIT 1",$id),ARRAY_A) ?: [];
    $docs=$wpdb->get_results($wpdb->prepare("SELECT doc_no,copy_type,created_at FROM {$twd} WHERE return_id=%d AND doc_type='return_in' ORDER BY id ASC",$id),ARRAY_A) ?: [];
    $warehouse_no=''; $courier_no='';
    foreach($docs as $d){ if(($d['copy_type']??'')==='courier') $courier_no=$d['doc_no']; else $warehouse_no=$d['doc_no']; }
    $warehouse_no=$warehouse_no?:($docs[0]['doc_no']??''); $courier_no=$courier_no?:$warehouse_no;
    $base_no=$warehouse_no?:($r['return_no']??'-');
    [$pdf,$fn]=pk01_pdf_emit('Tanda Terima Retur','tanda-terima-retur-'.$id.'.pdf');
    // Page 1: internal cashier / warehouse copy
    pk01_pdf_header($pdf,'TANDA TERIMA RETUR FISIK — INTERNAL',$base_no.'-K');
    pk01_pdf_section_title($pdf,'IDENTITAS RETUR');
    pk01_pdf_kv_grid($pdf,[
        ['No. Retur',$r['return_no']?:'-'],['No. Dokumen Gudang',$warehouse_no?:'-'],
        ['Tanggal Diterima',$r['warehouse_received_at']?:($r['accepted_at']?:$r['updated_at']?:$r['created_at']?:'-')],
        ['Seller / Pemilik',$r['seller_name']?:'Umum / Toko'],['Nomor Resi',$r['tracking_no']?:'-'],
        ['Kurir / Ekspedisi',$r['courier_name']?:'-'],['Status Fisik',strtoupper(str_replace('_',' ',$r['status']?:'-'))],
        ['Status QC',strtoupper(str_replace('_',' ',$r['qc_status']?:'-'))]
    ]);
    $pdf->Ln(5); pk01_pdf_section_title($pdf,'BARANG RETUR');
    $pdf->SetFont('Arial','B',8); foreach([['SKU',35],['Barang',95],['Qty',25],['Satuan',35]] as $h)$pdf->Cell($h[1],7,pk01_pdf_text($h[0]),1,0,'C'); $pdf->Ln();
    $pdf->SetFont('Arial','',8); $pdf->Cell(35,8,pk01_pdf_text($item['sku']??'-'),1); $pdf->Cell(95,8,pk01_pdf_text($item['product_name']??($r['product_name']??'Barang Retur')),1); $pdf->Cell(25,8,number_format((float)($item['qty']??$r['qty']??0),2,',','.'),1,0,'R'); $pdf->Cell(35,8,'pcs',1,1,'C');
    $pdf->Ln(5); pk01_pdf_section_title($pdf,'REKONSILIASI SELLER / KEUANGAN');
    pk01_pdf_kv_grid($pdf,[['Potongan AR Seller',pk01_pdf_money($r['seller_adjustment_amount']??$r['refund_amount']??0)],['Status AR',strtoupper(str_replace('_',' ',$r['seller_ar_adjustment_status']??'-'))],['Alasan Retur',$r['reason']?:'-']]);
    pk01_pdf_receipt_signature($pdf,'Petugas Gudang');
    pk01_pdf_doc_footer_note($pdf,'Salinan internal untuk Gudang/Kasir/Finance. Data berasal langsung dari retur PK01 dan tidak membuat transaksi baru saat dicetak ulang.');
    // Page 2: courier copy without seller financial data
    $pdf->AddPage();
    pk01_pdf_header($pdf,'BUKTI SERAH TERIMA RETUR — SALINAN KURIR',$courier_no.'-C');
    pk01_pdf_section_title($pdf,'DATA SERAH TERIMA FISIK');
    pk01_pdf_kv_grid($pdf,[
        ['No. Dokumen',$courier_no?:'-'],['No. Retur',$r['return_no']?:'-'],['Nomor Resi',$r['tracking_no']?:'-'],
        ['Ekspedisi / Kurir',$r['courier_name']?:'-'],['Tanggal Diterima',$r['warehouse_received_at']?:($r['accepted_at']?:$r['created_at']?:'-')],
        ['Jumlah Diterima',number_format((float)($item['qty']??$r['qty']??0),2,',','.').' pcs'],['Kondisi Paket','Diterima Gudang']
    ]);
    $pdf->Ln(8); pk01_pdf_section_title($pdf,'KETERANGAN'); $pdf->SetFont('Arial','',9); $pdf->MultiCell(0,5,pk01_pdf_text('Bukti ini hanya mencatat serah-terima fisik paket retur. Informasi Seller dan nilai finansial sengaja tidak dicantumkan pada salinan kurir.'));
    $pdf->Ln(18); $pdf->SetFont('Arial','',8); $pdf->Cell(95,5,pk01_pdf_text('Diterima Gudang'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('Diserahkan Kurir'),0,1,'C'); $pdf->Ln(18); $pdf->Cell(95,5,pk01_pdf_text('________________________'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('________________________'),0,1,'C');
    pk01_pdf_doc_footer_note($pdf,'Salinan kurir. Dokumen dibuat dari record penerimaan retur PK01; cetak ulang tidak mengubah status atau stok.');
    $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_expense_receipt($id=0) {
    global $wpdb;
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id; if($id<=0) wp_die('Referensi pengeluaran tidak valid.',400);
    $t=PK01_DB::t('operational_costs'); $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id),ARRAY_A);
    if(!$r) wp_die('Dokumen pengeluaran tidak ditemukan.');
    [$pdf,$fn]=pk01_pdf_emit('Tanda Terima Pengeluaran Kas','tanda-terima-pengeluaran-'.$id.'.pdf');
    $no=$r['receipt_no']?:($r['reference_no']?:'-');
    pk01_pdf_header($pdf,'TANDA TERIMA PENGELUARAN KAS',$no);
    pk01_pdf_section_title($pdf,'DETAIL TRANSAKSI');
    pk01_pdf_kv_grid($pdf,[['No. Dokumen',$no],['Tanggal',$r['cost_date']?:$r['created_at']?:'-'],['Kategori',$r['category']?:'-'],['Nominal',pk01_pdf_money($r['amount'])],['Metode Pembayaran',$r['payment_method']?:'-'],['No. Referensi',$r['reference_no']?:'-'],['Penerima',$r['recipient_name']?:'-'],['Status',strtoupper(str_replace('_',' ',$r['status']?:'-'))]]);
    $pdf->Ln(5); pk01_pdf_section_title($pdf,'KETERANGAN'); $pdf->SetFont('Arial','',9); $pdf->MultiCell(0,5,pk01_pdf_text($r['description']?:'-'));
    $pdf->Ln(15); $pdf->SetFont('Arial','',8); $pdf->Cell(95,5,pk01_pdf_text('Penyetuju'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('Penerima'),0,1,'C'); $pdf->Ln(18);
    $a=$r['approved_by']?get_userdata((int)$r['approved_by']):null; $rc=$r['recipient_confirmed_by']?get_userdata((int)$r['recipient_confirmed_by']):null;
    $pdf->Cell(95,5,pk01_pdf_text($a?$a->display_name:'________________________'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text($rc?$rc->display_name:($r['recipient_name']?:'________________________')),0,1,'C');
    pk01_pdf_doc_footer_note($pdf,'Dokumen diterbitkan dari database PK01. Cetak ulang bersifat read-only dan tidak membuat transaksi kas baru.');
    $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_warehouse_handover($id=0) {
    global $wpdb;
    if (!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id; if($id<=0) wp_die('Referensi tanda terima tidak valid.',400);
    $t=PK01_DB::t('warehouse_documents'); $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d AND doc_type='outbound_courier'",$id),ARRAY_A);
    if(!$r) wp_die('Dokumen serah-terima gudang tidak ditemukan.');
    $ship=PK01_DB::t('shipments'); $s=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$ship} WHERE id=%d",(int)$r['shipment_id']),ARRAY_A)?:[];
    [$pdf,$fn]=pk01_pdf_emit('Tanda Terima Gudang ke Kurir','tanda-terima-kurir-'.$id.'.pdf'); pk01_pdf_header($pdf,'TANDA TERIMA SERAH TERIMA BARANG',$r['doc_no']?:'-');
    pk01_pdf_section_title($pdf,'SERAH TERIMA FISIK');
    pk01_pdf_kv_grid($pdf,[['No. Dokumen',$r['doc_no']?:'-'],['Nomor Resi',$r['tracking_no']?:($s['tracking_no']??'-')],['Ekspedisi / Kurir',$r['courier_name']?:($s['courier']??'-')],['Penerima',$s['recipient_name']??'-'],['Seller',$r['seller_name']?:'-'],['Status',strtoupper(str_replace('_',' ',$r['status']?:'-'))],['Waktu',$r['created_at']?:'-']]);
    $pdf->Ln(8); pk01_pdf_section_title($pdf,'PERNYATAAN'); $pdf->SetFont('Arial','',9); $pdf->MultiCell(0,5,pk01_pdf_text('Barang telah diserahterimakan secara fisik dari Gudang kepada kurir berdasarkan nomor resi di atas. Dokumen ini tidak melakukan pemotongan stok kedua kali.'));
    $pdf->Ln(20); $pdf->SetFont('Arial','',8); $pdf->Cell(95,5,pk01_pdf_text('Petugas Gudang'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('Kurir / Driver'),0,1,'C'); $pdf->Ln(20); $pdf->Cell(95,5,pk01_pdf_text('________________________'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('________________________'),0,1,'C');
    pk01_pdf_doc_footer_note($pdf,'Dokumen serah-terima resmi PK01. Nomor dokumen berasal dari record Gudang dan tetap sama pada cetak ulang.');
    $pdf->Output('I',$fn); exit;
}


function pk01_pdf_print_closing($id=0) {
    global $wpdb;
    if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.');
    $id=(int)$id; if($id<=0) wp_die('Referensi penutupan periode tidak valid.',400);
    $t=PK01_DB::t('closings');
    $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",$id),ARRAY_A);
    if(!$r) wp_die('Bukti penutupan periode tidak ditemukan.');
    $number=$r['reference_no']??($r['period_code']??'-');
    [$pdf,$fn]=pk01_pdf_emit('Bukti Penutupan Periode','penutupan-periode-'.$id.'.pdf');
    pk01_pdf_header($pdf,'BUKTI PENUTUPAN PERIODE',$number);
    pk01_pdf_section_title($pdf,'RINGKASAN PERIODE');
    $preferred=['period_code','period_name','total_revenue','total_expense','net_profit','cash_balance','bank_balance','status','created_at'];
    $labels=['period_code'=>'Kode Periode','period_name'=>'Periode','total_revenue'=>'Pendapatan','total_expense'=>'Total Beban','net_profit'=>'Laba / Rugi Bersih','cash_balance'=>'Kas Akhir','bank_balance'=>'Bank Akhir','status'=>'Status','created_at'=>'Dibuat'];
    $rows=[]; foreach($preferred as $k){ if(array_key_exists($k,$r)) $rows[]=[ $labels[$k]??ucwords(str_replace('_',' ',$k)), in_array($k,['total_revenue','total_expense','net_profit','cash_balance','bank_balance'],true)?pk01_pdf_money($r[$k]):$r[$k] ]; }
    pk01_pdf_kv_grid($pdf,$rows);
    pk01_pdf_doc_footer_note($pdf,'Bukti penutupan periode diambil langsung dari tabel closing PK01. Cetak ulang tidak membuka periode dan tidak membuat transaksi baru.');
    $pdf->Ln(18); $pdf->SetFont('Arial','',8); $pdf->Cell(95,5,pk01_pdf_text('Dibuat / Ditutup Oleh'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('Verifikasi'),0,1,'C'); $pdf->Ln(20); $pdf->Cell(95,5,pk01_pdf_text('________________________'),0,0,'C'); $pdf->Cell(95,5,pk01_pdf_text('________________________'),0,1,'C');
    $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_simple($doc) {
    global $wpdb; if(!pk01_pdf_load_fpdf())wp_die('Mesin PDF FPDF belum tersedia.');
    $map=[
      'stok'=>['LAPORAN STOK','SELECT v.sku,v.name,COALESCE(SUM(CASE WHEN st.stock_type="finished" AND st.direction="in" THEN st.qty WHEN st.stock_type="finished" AND st.direction="out" THEN -st.qty ELSE 0 END),0) stok FROM '.PK01_DB::t('product_variants').' v LEFT JOIN '.PK01_DB::t('stock_transactions').' st ON st.item_id=v.id GROUP BY v.id ORDER BY v.name','Stok'],
      'pembelian'=>['DAFTAR PEMBELIAN','SELECT po_no,status,total,created_at FROM '.PK01_DB::t('purchase_orders').' ORDER BY id DESC LIMIT 100','Pembelian'],
      'retur'=>['DAFTAR RETUR','SELECT return_no,source,status,reason,refund_amount,created_at FROM '.PK01_DB::t('returns').' ORDER BY id DESC LIMIT 100','Retur'],
      'seller'=>['DAFTAR STOK SELLER','SELECT COALESCE(sa.name,"-") seller,v.sku,v.name,ss.qty FROM '.PK01_DB::t('seller_stock').' ss LEFT JOIN '.PK01_DB::t('sales_accounts').' sa ON sa.id=ss.seller_account_id LEFT JOIN '.PK01_DB::t('product_variants').' v ON v.id=ss.variant_id ORDER BY sa.name,v.name LIMIT 100','Seller'],
      'kas'=>['BUKU KAS USAHA','SELECT direction,category,amount,description,created_at FROM '.PK01_DB::t('cash_ledger').' ORDER BY id DESC LIMIT 100','Kas Usaha']
    ];
    if(!isset($map[$doc]))wp_die('Dokumen tidak tersedia.'); [$title,$sql,$label]=$map[$doc]; $rows=$wpdb->get_results($sql,ARRAY_A)?:[]; [$pdf,$fn]=pk01_pdf_emit($label,'laporan-'.sanitize_file_name($doc).'.pdf'); pk01_pdf_header($pdf,$title,'PK01-'.strtoupper($doc));
    if(!$rows){$pdf->SetFont('Arial','',10);$pdf->Cell(0,8,pk01_pdf_text('Belum ada data.'),0,1);$pdf->Output('I',$fn);exit;}
    $headers=array_keys($rows[0]); $widths=[]; $totalW=190; $each=$totalW/max(1,count($headers)); foreach($headers as $h){$widths[]=$each;}
    $pdf->SetFont('Arial','B',7); foreach($headers as $i=>$h)$pdf->Cell($widths[$i],7,pk01_pdf_text(ucwords(str_replace('_',' ',$h))),1,0,'C');$pdf->Ln();$pdf->SetFont('Arial','',7);
    foreach($rows as $r){foreach($headers as $i=>$h){$v=$r[$h]??''; if(in_array($h,['amount','total','refund_amount'],true))$v=pk01_pdf_money($v); $pdf->Cell($widths[$i],6,pk01_pdf_text(mb_strimwidth((string)$v,0,28,'…')),1,0,in_array($h,['amount','total','refund_amount','qty','stok'],true)?'R':'L');}$pdf->Ln();}
    $pdf->Output('I',$fn);exit;
}

function pk01_pdf_print_payroll_slip($id=0) {
    global $wpdb; if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    $tp=PK01_DB::t('payroll'); $te=PK01_DB::t('employees'); $tw=PK01_DB::t('job_wages'); $tj=PK01_DB::t('jobs');
    $p=$wpdb->get_row($wpdb->prepare("SELECT p.*,e.code employee_code,e.name employee_master,e.position,e.division FROM {$tp} p LEFT JOIN {$te} e ON e.id=p.employee_id WHERE p.id=%d",$id),ARRAY_A);
    if(!$p) wp_die('Slip gaji tidak ditemukan.');
    $name=$p['name']?:$p['employee_master']?:'Karyawan';
    $wages=$wpdb->get_results($wpdb->prepare("SELECT w.*,j.job_no FROM {$tw} w LEFT JOIN {$tj} j ON j.id=w.job_id WHERE w.employee_id=%d AND w.period_key=%s ORDER BY w.id ASC",(int)$p['employee_id'],(string)$p['period']),ARRAY_A)?:[];
    $job_total=0; foreach($wages as $w)$job_total+=(float)$w['amount']; $salary=(float)$p['amount']; $gross=(float)($p['gross_amount']??$salary); $deduction=(float)($p['deduction_amount']??0);
    $components=PK01_DB::t('payroll_components'); $comp_rows=$wpdb->get_results($wpdb->prepare("SELECT component_name,component_type,amount FROM `{$components}` WHERE payroll_id=%d ORDER BY component_type DESC,id",$id),ARRAY_A)?:[];
    $total=$salary+$job_total;
    [$pdf,$fn]=pk01_pdf_emit('Slip Gaji & Upah','slip-gaji-upah-'.$id.'.pdf'); pk01_pdf_header($pdf,'SLIP GAJI & UPAH',$p['reference_no']?:'PAY-'.$id);
    $pdf->SetFont('Arial','',9); foreach([['Nama Karyawan',$name],['Kode Karyawan',$p['employee_code']?:'-'],['Jabatan',$p['position']?:'-'],['Divisi',$p['division']?:'-'],['Periode',$p['period']],['Status Pembayaran',strtoupper($p['status'])]] as $x){$pdf->Cell(42,6,pk01_pdf_text($x[0]),1);$pdf->Cell(148,6,pk01_pdf_text($x[1]),1,1);}
    $pdf->Ln(5); $pdf->SetFont('Arial','B',9); $pdf->Cell(10,7,pk01_pdf_text('#'),1);$pdf->Cell(70,7,pk01_pdf_text('Komponen'),1);$pdf->Cell(55,7,pk01_pdf_text('Rincian'),1);$pdf->Cell(55,7,pk01_pdf_text('Nominal'),1,1,'C');$pdf->SetFont('Arial','',8);
    $i=1;
    if($comp_rows){ foreach($comp_rows as $c){ $pdf->Cell(10,7,$i++,1);$pdf->Cell(70,7,pk01_pdf_text(($c['component_type']==='deduction'?'Potongan: ':'').$c['component_name']),1);$pdf->Cell(55,7,pk01_pdf_text('Payroll '.$p['period']),1);$pdf->Cell(55,7,pk01_pdf_money($c['amount']),1,1,'R'); } } else { $pdf->Cell(10,7,$i++,1);$pdf->Cell(70,7,pk01_pdf_text('Gaji/Payroll'),1);$pdf->Cell(55,7,pk01_pdf_text($p['description']?:'Gaji periode '.$p['period']),1);$pdf->Cell(55,7,pk01_pdf_money($salary),1,1,'R'); }
    foreach($wages as $w){$pdf->Cell(10,7,$i++,1);$pdf->Cell(70,7,pk01_pdf_text('Upah Job'),1);$pdf->Cell(55,7,pk01_pdf_text(($w['job_no']?:'JOB-'.$w['job_id']).' — '.$w['job_detail'].' ('.number_format((float)$w['qty'],2,',','.').' '.$w['unit'].' × '.pk01_pdf_money($w['rate']).')'),1);$pdf->Cell(55,7,pk01_pdf_money($w['amount']),1,1,'R');}
    $pdf->SetFont('Arial','B',9);$pdf->Cell(135,7,pk01_pdf_text('GROSS KOMPENSASI PAYROLL'),1);$pdf->Cell(55,7,pk01_pdf_money($gross),1,1,'R');
    if($deduction>0){$pdf->Cell(135,7,pk01_pdf_text('TOTAL POTONGAN'),1);$pdf->Cell(55,7,pk01_pdf_money($deduction),1,1,'R');}
    $pdf->Cell(135,8,pk01_pdf_text('TOTAL DITERIMA + UPAH JOB'),1);$pdf->Cell(55,8,pk01_pdf_money($total),1,1,'R');
    $pdf->Ln(5);$pdf->SetFont('Arial','',8);$pdf->MultiCell(0,4.5,pk01_pdf_text('Slip ini memisahkan gaji reguler dan upah pekerjaan/job. Rincian Job diambil langsung dari data Job Produksi dan tabel Upah Job PK01. Slip tidak membuat transaksi kas baru.'));
    $pdf->Ln(12);$pdf->SetFont('Arial','',8);$pdf->Cell(95,5,pk01_pdf_text('Karyawan'),0,0,'C');$pdf->Cell(95,5,pk01_pdf_text('Penanggung Jawab'),0,1,'C');$pdf->Ln(15);$pdf->Cell(95,5,pk01_pdf_text($name),0,0,'C');$pdf->Cell(95,5,pk01_pdf_text('________________________'),0,1,'C');
    $pdf->Output('I',$fn); exit;
}

function pk01_pdf_print_owner_profit_receipt($id=0) {
    global $wpdb; if(!pk01_pdf_load_fpdf()) wp_die('Mesin PDF FPDF belum tersedia.'); $id=(int)$id;
    $tt=PK01_DB::t('owner_transactions');$to=PK01_DB::t('company_owners');
    $r=$wpdb->get_row($wpdb->prepare("SELECT t.*,o.name owner_name,o.share_percent FROM {$tt} t LEFT JOIN {$to} o ON o.id=t.owner_id WHERE t.id=%d",$id),ARRAY_A); if(!$r) wp_die('Penerimaan laba pemilik tidak ditemukan.');
    [$pdf,$fn]=pk01_pdf_emit('Bukti Penerimaan Laba Pemilik','bukti-penerimaan-laba-'.$id.'.pdf'); pk01_pdf_header($pdf,'BUKTI PENERIMAAN LABA PEMILIK',$r['reference_no']?:'-');
    foreach([['Penerima',$r['owner_name']?:'-'],['Porsi Saham Master',number_format((float)$r['share_percent'],2,',','.').'%'],['Jenis Transaksi',$r['transaction_type']==='owner_advance'?'Bon/Uang Muka Pemilik':'Penarikan Laba'],['Periode',$r['period_key']?:'-'],['Tanggal',$r['created_at']],['Nominal Diterima',pk01_pdf_money($r['amount'])],['Keterangan',$r['description']?:'-']] as $x){$pdf->SetFont('Arial','',9);$pdf->Cell(50,7,pk01_pdf_text($x[0]),1);$pdf->Cell(140,7,pk01_pdf_text($x[1]),1,1);}
    $pdf->Ln(7);$pdf->SetFont('Arial','',8.5);$pdf->MultiCell(0,5,pk01_pdf_text('Dokumen ini adalah bukti penerimaan/penarikan oleh pemilik. Penarikan laba atau bon pemilik bukan biaya operasional dan tidak mengurangi laba perusahaan untuk kedua kalinya; transaksi hanya mengurangi kas serta hak pemilik yang tersedia sesuai pencatatan PK01.'));
    $pdf->Ln(15);$pdf->SetFont('Arial','',8);$pdf->Cell(95,5,pk01_pdf_text('Penerima'),0,0,'C');$pdf->Cell(95,5,pk01_pdf_text('Pemberi/Penanggung Jawab'),0,1,'C');$pdf->Ln(15);$pdf->Cell(95,5,pk01_pdf_text($r['owner_name']?:'________________'),0,0,'C');$pdf->Cell(95,5,pk01_pdf_text('________________________'),0,1,'C');$pdf->Output('I',$fn);exit;
}

function pk01_pdf_print_router() {
    $doc=sanitize_key($_GET['doc']??''); $id=(int)($_GET['id']??0);
    $number='';
    if($id>0){
        global $wpdb;
        $lookup=['penjualan'=>['sales_orders',['invoice_no','order_no']],'produksi'=>['jobs',['job_no']],'label-produksi'=>['jobs',['job_no']],'label-thermal'=>['jobs',['job_no']],
            'retur'=>['returns',['return_no']],'retur-terima'=>['warehouse_documents',['doc_no']],'penerimaan'=>['goods_receipts',['receipt_no']],'penerimaan-supplier'=>['goods_receipts',['receipt_no']],
            'serah-terima-kurir'=>['warehouse_documents',['doc_no']],'pembelian'=>['purchase_orders',['po_no']],'pengiriman'=>['shipments',['tracking_no']],'upah-job'=>['job_wages',['reference_no']],
            'biaya-operasional'=>['operational_costs',['receipt_no','reference_no']],'slip-gaji'=>['payroll',['reference_no']],'penerimaan-laba'=>['owner_transactions',['reference_no']],'payout'=>['marketplace_payouts',['payout_no']]];
        if(isset($lookup[$doc])){ $table=PK01_DB::t($lookup[$doc][0]); $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE id=%d LIMIT 1",$id),ARRAY_A); if($row){foreach($lookup[$doc][1] as $k){if(isset($row[$k])&&trim((string)$row[$k])!==''){$number=(string)$row[$k];break;}}} }
    }
    $GLOBALS['pk01_pdf_validation'] = ['url'=>pk01_pdf_validation_url($doc,$id,$number), 'label'=>$doc.($number?' • '.$number:'')];
    if (!is_user_logged_in() || !current_user_can('pk01_access_operational')) wp_die('Anda tidak memiliki akses mencetak dokumen PK01.',403);
    $doc=sanitize_key($_GET['doc']??'');$id=(int)($_GET['id']??0);
    $doc_module_map=['penjualan'=>'sales_hub','laporan-keuangan'=>'finance_reports','closing'=>'finance_reports','produk'=>'products','produksi'=>'production_hub','pemasangan'=>'production_hub','label-produksi'=>'production_hub','label-thermal'=>'production_hub','keuangan'=>'finance_reports','general-ledger'=>'general_ledger','upah-job'=>'job_wages','biaya-operasional'=>'operational_costs','pengiriman'=>'shipping_hub','karyawan'=>'employees','bonus-target'=>'seller','penerimaan'=>'purchasing_hub','slip-gaji'=>'payroll','penerimaan-laba'=>'owner_dashboard','stok'=>'inventory','pembelian'=>'purchasing_hub','retur'=>'returns','retur-terima'=>'returns','seller'=>'seller','kas'=>'cash','penerimaan-supplier'=>'purchasing_hub','serah-terima-kurir'=>'shipping_hub'];
    $print_module=$doc_module_map[$doc]??'';
    if ($print_module && class_exists('PK01_Authorization') && !PK01_Authorization::can_action($print_module,'print')) wp_die('Anda tidak memiliki izin mencetak dokumen ini.',403);
    if (function_exists('pk01_pdf_audit_print') && $doc !== 'penjualan') pk01_pdf_audit_print($doc,$id,'SUCCESS','reprint');
    if($doc==='produk') pk01_pdf_print_product($id); if($doc==='produksi') pk01_pdf_print_production($id); if($doc==='pemasangan') pk01_pdf_print_installation($id); if($doc==='label-produksi') pk01_pdf_print_production_labels($id); if($doc==='label-thermal') pk01_pdf_print_production_thermal($id); if($doc==='keuangan' || $doc==='laporan-keuangan') pk01_pdf_print_finance(); if($doc==='closing') pk01_pdf_print_closing($id); if($doc==='general-ledger') pk01_pdf_print_finance_ledger(); if($doc==='penjualan') pk01_pdf_print_sales_invoice($id); if($doc==='upah-job' || $doc==='biaya-operasional' || $doc==='bonus-target' || $doc==='pengiriman' || $doc==='karyawan') pk01_pdf_print_business_doc($doc,$id); if($doc==='penerimaan' || $doc==='penerimaan-supplier') pk01_pdf_print_goods_receipt($id); if($doc==='retur-terima') pk01_pdf_print_return_receipts($id); if($doc==='serah-terima-kurir') pk01_pdf_print_warehouse_handover($id); if($doc==='slip-gaji') pk01_pdf_print_payroll_slip($id); if($doc==='penerimaan-laba') pk01_pdf_print_owner_profit_receipt($id); if(in_array($doc,['stok','pembelian','retur','seller','kas'],true)) pk01_pdf_print_simple($doc); wp_die('Jenis dokumen tidak dikenali.',400);
}
// Registered by pdf-loader.php so FPDF is loaded lazily only for PDF requests.
add_action('admin_post_nopriv_pk01_print',function(){wp_die('Login diperlukan.',403);});
function pk01_print_url($doc,$id=0,$args=[]) { return add_query_arg(array_merge(['action'=>'pk01_print','doc'=>$doc,'id'=>(int)$id],$args),admin_url('admin-post.php')); }
