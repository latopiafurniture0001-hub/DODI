<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Frontend Controller (Ultra-Stable & Safe)
 * Menangani tampilan dashboard tanpa merusak query WooCommerce, 
 * anti-crash, dan dilengkapi pelindung error mandiri.
 */
class PK01_Frontend {

    public static function init() {
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets'], 20);
        add_filter('template_include',   [__CLASS__, 'template_loader'], 999);
        add_action('init',               [__CLASS__, 'caps']);
        add_filter('body_class',         [__CLASS__, 'body_class']);
        add_action('template_redirect',  [__CLASS__, 'auth_guard'], 1);
        add_filter('show_admin_bar',     [__CLASS__, 'control_admin_bar']);
        // Semua akun operasional masuk langsung ke portal PK01 setelah autentikasi.
        add_filter('login_redirect',      [__CLASS__, 'login_redirect'], 20, 3);
        // Kompatibilitas bila form login WooCommerce dipakai di storefront.
        add_filter('woocommerce_login_redirect', [__CLASS__, 'woocommerce_login_redirect'], 20, 2);
    }

    private static function get_plugin_dir() {
        if (defined('PK01_DIR')) {
            return trailingslashit(PK01_DIR);
        }
        return trailingslashit(plugin_dir_path(dirname(__FILE__)));
    }

    public static function body_class($classes) {
        if (is_string($classes)) $classes = explode(' ', $classes);
        if (!is_array($classes)) $classes = [];

        if (self::is_dashboard()) {
            $classes[] = 'pk01-dashboard-page';
            $classes[] = 'pk01-app-fullscreen';
        }

        return array_values(array_unique(array_filter($classes)));
    }

    public static function caps() {
        $roles = ['administrator', 'shop_manager', 'editor', 'pk01_admin', 'pk01_owner', 'pk01_investor', 'pk01_employee', 'pk01_seller', 'pk01_gudang', 'pk01_produksi', 'pk01_kasir', 'pk01_keuangan', 'pk01_hr', 'pk01_logistik', 'pk01_packing'];
        foreach ($roles as $role) {
            $r = get_role($role);
            if ($r && empty($r->capabilities['pk01_access_operational'])) {
                $r->add_cap('pk01_access_operational');
            }
        }
    }

    /**
     * Deteksi Presisi Dashboard (Tanpa Merusak Objek WP_Query)
     */
    public static function is_dashboard() {
        if (is_admin()) return false;

        // Cek jika ada parameter pk01_view
        if (isset($_GET['pk01_view']) && sanitize_key($_GET['pk01_view']) !== '') {
            return true;
        }

        // Cek URI request
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        if (strpos($uri, 'dashboard-operasional') !== false) {
            return true;
        }

        $dash_id = (int) get_option('pk01_dashboard_page_id', 0);
        if ($dash_id > 0 && is_page($dash_id)) {
            return true;
        }

        if (is_page('dashboard-operasional')) {
            return true;
        }

        return false;
    }

    public static function auth_guard() {
        if (!self::is_dashboard()) return;

        $view = sanitize_key($_GET['pk01_view'] ?? '');
        if (in_array($view, ['tracking_public', 'lacak_resi', 'seller_register', 'daftar_seller'], true)) {
            return;
        }

        if (!is_user_logged_in()) {
            $target = !empty($_SERVER['REQUEST_URI']) ? home_url($_SERVER['REQUEST_URI']) : home_url('/dashboard-operasional/');
            wp_safe_redirect(class_exists('PK01_Login') ? PK01_Login::url($target) : wp_login_url($target));
            exit;
        }
    }

    public static function control_admin_bar($show) {
        // Dashboard PK01 adalah aplikasi frontend mandiri. Jangan tampilkan
        // WordPress Admin Bar pada role apa pun, termasuk Administrator dan mode preview.
        return self::is_dashboard() ? false : $show;
    }

    /**
     * Portal login terpusat: user PK01 tidak perlu masuk ke wp-admin terlebih dahulu.
     * Redirect hanya berlaku untuk role yang memang terdaftar sebagai role operasional
     * PK01/WooCommerce; role WordPress lain tetap mengikuti perilaku WordPress.
     */
    public static function login_redirect($redirect_to, $requested_redirect_to, $user) {
        if (!($user instanceof WP_User) || empty($user->ID)) return $redirect_to;

        $roles = array_map('sanitize_key', (array) $user->roles);
        $pk01_roles = [
            'shop_manager','editor','pk01_admin','pk01_owner','pk01_investor',
            'pk01_gudang','pk01_produksi','pk01_kasir','pk01_keuangan','pk01_hr',
            'pk01_logistik','pk01_packing','pk01_employee','pk01_seller'
        ];
        if (!array_intersect($roles, $pk01_roles) && !in_array('administrator', $roles, true)) {
            return $redirect_to;
        }

        // Jika login berasal dari tombol "buka modul" / halaman yang dilindungi,
        // pertahankan tujuan internal yang aman. Jika tidak ada tujuan eksplisit,
        // arahkan otomatis berdasarkan role ke workspace PK01 yang tepat.
        $requested = self::safe_redirect($requested_redirect_to ?: $redirect_to);
        if ($requested && self::is_internal_pk01_url($requested)) return $requested;

        return self::role_dashboard_url($user);
    }

    public static function woocommerce_login_redirect($redirect, $user) {
        return self::login_redirect($redirect, $redirect, $user);
    }

    /**
     * URL landing role. Role tetap berasal dari akun WordPress; PK01 hanya
     * menentukan workspace plugin yang paling relevan setelah login.
     */
    public static function role_dashboard_url($user = null) {
        if (!$user) $user = wp_get_current_user();
        $page_id = (int) get_option('pk01_portal_page_id', 0);
        if (!$page_id || get_post_status($page_id) !== 'publish') {
            $page_id = (int) get_option('pk01_dashboard_page_id', 0);
        }
        $base = ($page_id && get_post_status($page_id) === 'publish')
            ? get_permalink($page_id)
            : home_url('/pk01-portal/');

        $view = self::role_landing_view($user);
        return add_query_arg('pk01_view', $view, $base);
    }

    /** Role -> workspace plugin. Tidak membuat sistem login/role kedua. */
    public static function role_landing_view($user = null) {
        if (!$user) $user = wp_get_current_user();
        $roles = array_map('sanitize_key', (array) $user->roles);
        $priority = [
            'pk01_seller'    => 'seller_portal',
            'pk01_employee'  => 'job_karyawan',
            'pk01_produksi'  => 'production_hub',
            'pk01_gudang'    => 'inventory',
            'pk01_kasir'     => 'sales_hub',
            'pk01_keuangan'  => 'finance_hub',
            'pk01_hr'        => 'attendance',
            'pk01_logistik'  => 'shipping_hub',
            'pk01_security'  => 'security',
            'pk01_packing'   => 'shipping_hub',
            'pk01_admin'     => 'dashboard',
            'pk01_owner'     => 'dashboard',
            'pk01_investor'  => 'dashboard',
            'shop_manager'   => 'dashboard',
            'editor'         => 'dashboard',
            'administrator'  => 'dashboard',
        ];
        foreach ($priority as $role => $view) {
            if (in_array($role, $roles, true)) return $view;
        }
        return 'dashboard';
    }

    private static function is_internal_pk01_url($url) {
        $home_host = wp_parse_url(home_url('/'), PHP_URL_HOST);
        $target_host = wp_parse_url($url, PHP_URL_HOST);
        if (!$target_host || !$home_host || strtolower($target_host) !== strtolower($home_host)) return false;
        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        return strpos($path, '/dashboard-operasional') !== false
            || strpos($path, '/pk01-portal') !== false
            || strpos($path, '/pk01-login') !== false;
    }

    public static function assets() {
        if (!self::is_dashboard()) return;

        $ver = defined('PK01_VERSION') ? PK01_VERSION : '2.4.0';
        $raw_url = defined('PK01_URL') ? PK01_URL : plugin_dir_url(__FILE__);
        $url = trailingslashit($raw_url);

        wp_enqueue_style('pk01-frontend', $url . 'assets/frontend.css', [], $ver);
        wp_enqueue_script('pk01-frontend-shell', $url . 'assets/frontend.js', ['jquery'], $ver, true);

        wp_localize_script('pk01-frontend-shell', 'pk01_app', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => esc_url_raw(rest_url('pk01/v2/')),
            'nonce'    => wp_create_nonce('pk01_store'),
            'home_url' => home_url('/')
        ]);
    }

    /**
     * Loader Template Mandiri (Menangkap Segala Error PHP)
     */
    public static function template_loader($template) {
        if (!self::is_dashboard()) {
            return $template;
        }

        // Jalankan Header Anti-Cache
        if (!headers_sent()) {
            nocache_headers();
        }
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }

        // Render Langsung Antarmuka SaaS Terisolasi
        self::render_dashboard_view();
        exit;
    }

    /**
     * Mesin Render Antarmuka SaaS Bebas Eror
     */
    public static function render_dashboard_view() {
        ?><!doctype html>
        <html <?php language_attributes(); ?> style="margin-top:0 !important; height:100%;">
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            <title>Dashboard Operasional — <?php bloginfo('name'); ?></title>
            <?php wp_head(); ?>
            <style>
                html, body { min-height: 100%; margin: 0 !important; padding: 0; background-color: #f8fafc; color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
                html { margin-top: 0 !important; }
                #wpadminbar { display: none !important; }
                .pk01-viewport-root { min-height: 100vh; display: flex; flex-direction: column; }
                .pk01-viewport-content { flex: 1; width: 100%; max-width: none; margin: 0; padding: 0; box-sizing: border-box; }
                .pk01-op-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); margin-bottom: 20px; }
                .pk01-op-card-head h2 { margin: 4px 0 6px 0; font-size: 22px; font-weight: 800; color: #0f172a; }
                .pk01-op-card-head p { margin: 0; color: #64748b; font-size: 13px; }
                .pk01-op-eyebrow { font-size: 11px; font-weight: 700; color: #2563eb; text-transform: uppercase; letter-spacing: 0.5px; }
                .pk01-op-button { background: #2563eb; color: #fff; border: none; border-radius: 6px; padding: 8px 16px; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-block; font-size: 13px; }
                .pk01-op-button:hover { background: #1d4ed8; color: #fff; }
                .pk01-op-button.is-small { padding: 4px 10px; font-size: 12px; }
                .pk01-op-notice { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 13px; }
                .pk01-op-notice.is-success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
                .pk01-op-notice.is-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
                .pk01-op-notice.is-warning { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
                .pk01-op-form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; margin-top: 14px; }
                .pk01-op-form-grid label { display: flex; flex-direction: column; font-size: 13px; font-weight: 600; color: #334155; gap: 4px; }
                .pk01-op-form-grid input, .pk01-op-form-grid select, .pk01-op-form-grid textarea { padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px; background: #fff; }
                @media (max-width: 768px) { .pk01-op-form-grid { grid-template-columns: 1fr; } }
            </style>
        </head>
        <body <?php body_class('pk01-dashboard-page pk01-app-fullscreen'); ?>>
        <?php wp_body_open(); ?>
        <div class="pk01-viewport-root">
            <div class="pk01-viewport-content">
                <?php
                if (class_exists('PK01_Authorization') && method_exists('PK01_Authorization', 'render_preview_banner')) {
                    PK01_Authorization::render_preview_banner();
                }
                if (class_exists('PK01_Smart_Plugin') && method_exists('PK01_Smart_Plugin', 'dashboard_notice')) {
                    echo PK01_Smart_Plugin::dashboard_notice();
                }

                // Gunakan renderer aplikasi PK01 yang sama dengan seluruh navigasi resmi.
                // Ini memastikan sidebar, role menu, authorization, dan routing tidak bercabang.
                if (shortcode_exists('pk01_operasional')) {
                    echo do_shortcode('[pk01_operasional]');
                } else {
                    echo '<div class="pk01-op-card"><h2>PK01 belum siap</h2><p>Renderer aplikasi belum terdaftar. Muat ulang halaman setelah plugin aktif.</p></div>';
                }
                ?>
            </div>
        </div>
        <?php wp_footer(); ?>
        </body>
        </html>
        <?php
    }

    /**
     * Dispatcher Modul Aman (Jika Terjadi Error di Salah Satu File, Ditampilkan Detailnya)
     */
    public static function dispatch_view() {
        $view = sanitize_key($_GET['pk01_view'] ?? 'dashboard');

        if ($view === 'seller') $view = 'sellers';
        if ($view === 'employee') $view = 'employees';
        if ($view === 'cost') $view = 'operational_costs';

        $dir = self::get_plugin_dir() . 'includes/';

        $file_map = [
            'dashboard'         => 'modules/admin/dashboard-role/tampilan-dashboard-role.php',
            'attendance'        => 'modules/hr/attendance/tampilan-absensi.php',
            'administration'    => 'modules/admin/administration/tampilan-administrasi.php',
            'security'          => 'modules/security/dashboard/tampilan-security.php',
            'customer_service'  => 'modules/customer-service/dashboard/tampilan-customer-service.php',
            'sellers'           => 'modules/seller/register/tampilan-daftar-seller.php',
            'employees'         => 'modules/hr/employees/tampilan-karyawan.php',
            'materials'         => 'modules/inventory/materials/tampilan-bahan.php',
            'operational_costs' => 'modules/finance/operational-costs/tampilan-biaya-usaha.php',
            'cash'              => 'modules/finance/cash/tampilan-kas.php',
            'sales'             => 'modules/sales/cashier/tampilan-penjualan.php',
            'pricing'           => 'modules/sales/pricing/tampilan-harga-jual.php',
            'shipments'         => 'modules/logistics/shipping/tampilan-pengiriman.php',
            'marketplace'       => 'modules/marketplace/reconciliation/tampilan-marketplace.php',
            'finance'           => 'modules/finance/overview/tampilan-keuangan.php',
            'settings'          => 'modules/admin/settings/tampilan-pengaturan.php',
            'system'            => 'modules/admin/settings/tampilan-pengaturan.php',
            'ai'                => 'modules/ai/assistant/tampilan-asisten-ai.php',
            'ai_assistant'      => 'modules/ai/assistant/tampilan-asisten-ai.php',
            'ai_center'         => 'modules/ai/center/tampilan-ai-center.php',
            'logs'              => 'modules/admin/activity/tampilan-aktivitas.php',
            'master_data'       => 'modules/admin/master-data/tampilan-master-data.php',
            'tracking_public'   => 'modules/logistics/tracking/tampilan-lacak-resi.php',
            'seller_register'   => 'modules/seller/register/tampilan-daftar-seller.php',
        ];

        $candidates = $file_map[$view] ?? [$file_map['dashboard']];
        $found = false;

        foreach ($candidates as $file) {
            $filepath = $dir . ltrim($file, '/');
            if (file_exists($filepath)) {
                $found = true;
                try {
                    include $filepath;
                } catch (Throwable $e) {
                    echo '<div class="pk01-op-card" style="border-left: 4px solid #dc2626;">';
                    echo '<h3 style="color:#b91c1c; margin-top:0;">⚠️ Modul Terkendala (File Ada Kode Terputus)</h3>';
                    echo '<p style="color:#334155; font-size:13px;">File: <code>' . esc_html($file) . '</code></p>';
                    echo '<div style="background:#fef2f2; border:1px solid #fecaca; color:#991b1b; padding:10px 14px; border-radius:6px; font-family:monospace; font-size:12px; margin:10px 0;">';
                    echo esc_html($e->getMessage()) . '<br><small>Baris: ' . (int)$e->getLine() . '</small>';
                    echo '</div>';
                    echo '<a href="' . esc_url(remove_query_arg('pk01_view')) . '" class="pk01-op-button is-small">Kembali ke Dashboard</a>';
                    echo '</div>';
                }
                break;
            }
        }

        if (!$found) {
            echo '<div class="pk01-op-card" style="text-align:center; padding:40px 20px;">';
            echo '<h2 style="color:#0f172a;">Modul ' . esc_html(ucfirst($view)) . ' Belum Tersedia</h2>';
            echo '<p style="color:#64748b; font-size:13px;">File <code>includes/' . esc_html($candidates[0]) . '</code> belum diunggah di server.</p>';
            echo '<a href="' . esc_url(remove_query_arg('pk01_view')) . '" class="pk01-op-button">Kembali ke Dashboard Utama</a>';
            echo '</div>';
        }
    }
}

