<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Central Login
 *
 * Satu pintu autentikasi frontend untuk seluruh dashboard/portal PK01.
 * Tidak menggunakan form wp-login.php sebagai halaman login pengguna.
 */
class PK01_Login {

    public static function init() {
        add_shortcode('pk01_login', [__CLASS__, 'shortcode']);
        add_filter('login_url', [__CLASS__, 'filter_login_url'], 20, 3);
        add_action('login_init', [__CLASS__, 'redirect_wp_login_page'], 1);
    }

    public static function url($redirect_to = '') {
        $id = (int) get_option('pk01_login_page_id', 0);
        if ($id && get_post_status($id) === 'publish') {
            $url = get_permalink($id);
        } else {
            $url = home_url('/pk01-login/');
        }
        if ($redirect_to !== '') {
            $url = add_query_arg('redirect_to', self::safe_redirect($redirect_to), $url);
        }
        return $url;
    }

    public static function filter_login_url($login_url, $redirect = '', $force_reauth = false) {
        return self::url($redirect);
    }

    /**
     * Semua akses langsung ke wp-login.php?action=login diarahkan ke login PK01.
     * Halaman autentikasi WordPress tidak menjadi UI login operasional.
     * Endpoint logout tetap dibiarkan WordPress menangani sesi agar kompatibel.
     */
    public static function redirect_wp_login_page() {
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'login';
        if ($action !== 'login') return;
        if (is_user_logged_in()) {
            wp_safe_redirect(self::url());
            exit;
        }

        $redirect = isset($_REQUEST['redirect_to']) ? wp_unslash($_REQUEST['redirect_to']) : '';
        wp_safe_redirect(self::url($redirect));
        exit;
    }

    private static function safe_redirect($url) {
        $url = is_string($url) ? trim($url) : '';
        if ($url === '') return '';
        $validated = wp_validate_redirect($url, '');
        return $validated ? $validated : '';
    }

    public static function shortcode() {
        if (is_user_logged_in()) {
            return '<div class="pk01-login-shell"><div class="pk01-login-card"><div class="pk01-login-brand">PK01</div><h1>Anda sudah masuk</h1><p>Sesi Anda sudah aktif. Silakan lanjut ke Dashboard Operasional.</p><a class="pk01-login-btn" href="' . esc_url(class_exists('PK01_Frontend') ? PK01_Frontend::role_dashboard_url(wp_get_current_user()) : home_url('/pk01-portal/')) . '">Masuk ke Dashboard</a></div></div>';
        }

        $error = '';
        $redirect = isset($_REQUEST['redirect_to']) ? self::safe_redirect(wp_unslash($_REQUEST['redirect_to'])) : '';
        if ($redirect === '') {
            $redirect = class_exists('PK01_Frontend') ? PK01_Frontend::role_dashboard_url() : home_url('/pk01-portal/');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_login_submit'])) {
            $nonce = isset($_POST['pk01_login_nonce']) ? sanitize_text_field(wp_unslash($_POST['pk01_login_nonce'])) : '';
            if (!wp_verify_nonce($nonce, 'pk01_login')) {
                $error = 'Sesi keamanan tidak valid. Silakan muat ulang halaman dan coba lagi.';
            } else {
                $username = isset($_POST['log']) ? sanitize_user(wp_unslash($_POST['log'])) : '';
                $password = isset($_POST['pwd']) ? (string) wp_unslash($_POST['pwd']) : '';
                $remember = !empty($_POST['rememberme']);

                if ($username === '' || $password === '') {
                    $error = 'Username/email dan password wajib diisi.';
                } else {
                    $creds = [
                        'user_login'    => $username,
                        'user_password' => $password,
                        'remember'      => $remember,
                    ];
                    $user = wp_signon($creds, is_ssl());
                    if (is_wp_error($user)) {
                        $error = 'Username/email atau password tidak benar.';
                    } else {
                        wp_set_current_user($user->ID);
                        wp_set_auth_cookie($user->ID, $remember, is_ssl());
                        if (class_exists('PK01_Audit')) {
                            PK01_Audit::info('login', 'pk01_login', 'Pengguna masuk melalui Portal Login PK01', 'user', (string) $user->ID);
                        }
                        $target = class_exists('PK01_Frontend')
                            ? PK01_Frontend::login_redirect($redirect, $redirect, $user)
                            : $redirect;
                        if (!$target) $target = home_url('/pk01-portal/');
                        wp_safe_redirect($target);
                        exit;
                    }
                }
            }
        }

        ob_start();
        ?>
        <style>
            .pk01-login-shell{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:30px 18px;background:linear-gradient(135deg,#f8fafc,#eef2ff);box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
            .pk01-login-card{width:100%;max-width:430px;background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:34px;box-shadow:0 20px 50px rgba(15,23,42,.10);box-sizing:border-box}
            .pk01-login-brand{width:46px;height:46px;border-radius:13px;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;letter-spacing:-.5px;margin-bottom:18px}
            .pk01-login-card h1{margin:0 0 7px;font-size:25px;color:#0f172a}.pk01-login-card p{margin:0 0 22px;color:#64748b;font-size:13px;line-height:1.55}
            .pk01-login-error{padding:12px 14px;border-radius:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;font-size:13px;margin-bottom:16px}
            .pk01-login-field{display:flex;flex-direction:column;gap:6px;margin-bottom:15px}.pk01-login-field label{font-size:12px;font-weight:700;color:#334155}.pk01-login-field input{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:9px;padding:11px 12px;font-size:14px;outline:none}.pk01-login-field input:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.10)}
            .pk01-login-options{display:flex;align-items:center;justify-content:space-between;margin:2px 0 18px;font-size:12px;color:#64748b}.pk01-login-options label{display:flex;gap:7px;align-items:center}.pk01-login-btn{display:block;width:100%;box-sizing:border-box;text-align:center;background:#2563eb;color:#fff;text-decoration:none;border:0;border-radius:9px;padding:12px 16px;font-size:14px;font-weight:800;cursor:pointer}.pk01-login-btn:hover{background:#1d4ed8;color:#fff}.pk01-login-foot{text-align:center;margin-top:18px;font-size:11px;color:#94a3b8}
        </style>
        <div class="pk01-login-shell">
            <div class="pk01-login-card">
                <div class="pk01-login-brand">PK</div>
                <h1>Masuk ke PK01</h1>
                <p>Gunakan akun operasional Anda untuk membuka Dashboard PK01. Anda tidak perlu masuk melalui WordPress Admin.</p>
                <?php if ($error): ?><div class="pk01-login-error"><?php echo esc_html($error); ?></div><?php endif; ?>
                <form method="post" action="<?php echo esc_url(self::url($redirect)); ?>" autocomplete="on">
                    <?php wp_nonce_field('pk01_login', 'pk01_login_nonce'); ?>
                    <input type="hidden" name="pk01_login_submit" value="1">
                    <div class="pk01-login-field"><label for="pk01-login-user">Username / Email</label><input id="pk01-login-user" type="text" name="log" autocomplete="username" required autofocus></div>
                    <div class="pk01-login-field"><label for="pk01-login-pass">Password</label><input id="pk01-login-pass" type="password" name="pwd" autocomplete="current-password" required></div>
                    <div class="pk01-login-options"><label><input type="checkbox" name="rememberme" value="forever"> Ingat saya</label><span>PK01 Business OS</span></div>
                    <button class="pk01-login-btn" type="submit">Masuk ke Dashboard</button>
                </form>
                <div class="pk01-login-foot">Autentikasi menggunakan akun WordPress yang sama, tetapi seluruh UI login pengguna dikelola oleh PK01.</div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
