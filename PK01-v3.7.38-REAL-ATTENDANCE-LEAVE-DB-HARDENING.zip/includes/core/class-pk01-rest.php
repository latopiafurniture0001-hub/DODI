<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise REST API Gateway Controller
 * Menangani komunikasi data nirsentuh (Headless API), integrasi aplikasi mobile,
 * webhook ekspedisi otomatis, dan antarmuka kecerdasan buatan (AI).
 */
class PK01_REST {

    /**
     * Inisialisasi Hook REST API
     */
    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    /**
     * SISTEM OTORISASI DUA JALUR (COOKIE NONCE & BEARER API TOKEN)
     * Memungkinkan aplikasi mobile atau server eksternal mengakses API secara legal.
     */
    public static function authorize($module, $action = 'view', $request = null) {
        // Administrator role-preview adalah MODE LIHAT SAJA. Pemeriksaan ini
        // dilakukan sebelum Bearer Token agar preview tidak pernah menjadi
        // pintu mutasi melalui endpoint REST.
        if (class_exists('PK01_Authorization') && method_exists('PK01_Authorization', 'is_read_only_preview') && PK01_Authorization::is_read_only_preview()) {
            $action = strtolower(sanitize_key((string)$action));
            if (!in_array($action, ['view', 'read', 'print', 'download', 'track'], true)) {
                return false;
            }
        }

        // 1. Cek Autentikasi Bearer Token (Untuk Mobile App & External Gateway)
        $auth_header = '';
        if ($request instanceof WP_REST_Request) {
            $auth_header = $request->get_header('authorization') ?: '';
        } elseif (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth_header = $_SERVER['HTTP_AUTHORIZATION'];
        }

        if (!empty($auth_header)) {
            $token = trim(str_replace('Bearer', '', $auth_header));
            $saved_token = get_option('pk01_central_api_token', '');

            // Jika token API cocok, izinkan akses operasional penuh
            if (!empty($saved_token) && hash_equals($saved_token, $token)) {
                return true;
            }
        }

        // 2. Cek Berdasarkan Hak Akses Pengguna Login WordPress
        if (is_user_logged_in()) {
            if (class_exists('PK01_Authorization') && method_exists('PK01_Authorization', 'can_action')) {
                return PK01_Authorization::can_action($module, $action);
            }
            return current_user_can('manage_options');
        }

        return false;
    }

    /**
     * REGISTRASI SELURUH ENDPOINT REST API PK01
     */
    public static function routes() {

        // =====================================================================
        // 1. DASHBOARD, TELEMETRI & APLIKASI MOBILE
        // =====================================================================

        // Ringkasan Keuangan & Stok
        register_rest_route('pk01/v1', '/dashboard', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_dashboard'],
            'permission_callback' => function($r) { return self::authorize('dashboard', 'view', $r); }
        ]);

        // Telemetri Pintar untuk Monitoring
        register_rest_route('pk01/v1', '/dashboard/smart', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_smart_dashboard'],
            'permission_callback' => function($r) { return self::authorize('dashboard', 'view', $r); }
        ]);

        // Status Khusus Aplikasi Mobile
        register_rest_route('pk01/v1', '/mobile/status', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_mobile_status'],
            'permission_callback' => function($r) { return self::authorize('dashboard', 'view', $r); }
        ]);

        // Perintah Cepat Mobile (Voice / Chat Command via AI)
        register_rest_route('pk01/v1', '/mobile/command', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'post_mobile_command'],
            'permission_callback' => function($r) { return self::authorize('ai_assistant', 'view', $r); }
        ]);

        // =====================================================================
        // 2. KEUANGAN, KAS & BIAYA USAHA
        // =====================================================================

        // Saldo Kas Riil
        register_rest_route('pk01/v1', '/cash/balance', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_cash_balance'],
            'permission_callback' => function($r) { return self::authorize('cash', 'view', $r); }
        ]);

        // Laporan Laba Rugi Berdasarkan Rentang Tanggal
        register_rest_route('pk01/v1', '/finance/report', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_finance_report'],
            'permission_callback' => function($r) { return self::authorize('finance', 'view', $r); }
        ]);

        // =====================================================================
        // 3. GUDANG & MATERIAL KRITIS
        // =====================================================================

        // Daftar Bahan Baku yang Berada di Bawah Batas Minimum
        register_rest_route('pk01/v1', '/materials/critical', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_critical_materials'],
            'permission_callback' => function($r) { return self::authorize('materials', 'view', $r); }
        ]);

        // =====================================================================
        // 4. PENJUALAN & TRANSAKSI KASIR POS
        // =====================================================================

        // Buat Pesanan Baru via REST API (Diproteksi Idempotency)
        register_rest_route('pk01/v1', '/sales/create', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'post_create_sale'],
            'permission_callback' => function($r) { return self::authorize('sales', 'create', $r); }
        ]);

        // =====================================================================
        // 5. INTEGRASI E-COMMERCE & PENJUAL OFFLINE
        // =====================================================================
        register_rest_route('pk01/v2', '/theme/order', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'post_theme_order'],
            'permission_callback' => function($r) { return self::authorize('sales', 'create', $r); }
        ]);
        register_rest_route('pk01/v2', '/seller/offline-sale', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'post_seller_offline_sale'],
            'permission_callback' => function($r) { return self::authorize('seller', 'create', $r); }
        ]);

        // =====================================================================
        // 6. ASISTEN KECERDASAN BUATAN (AI GATEWAY)
        // =====================================================================

        register_rest_route('pk01/v1', '/ai/ask', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'post_ai_ask'],
            'permission_callback' => function($r) { return self::authorize('ai_assistant', 'view', $r); }
        ]);

        // =====================================================================
        // 6. PENCARIAN PRODUK TERINTEGRASI (SKU / KODE / NAMA)
        register_rest_route('pk01/v1', '/lookup/product', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'lookup_product'],
            'permission_callback' => function($r) { return self::lookup_product_permission(); }
        ]);
        register_rest_route('pk01/v1', '/production/batch/(?P<code>[A-Za-z0-9\-]+)', [
            'methods' => 'GET', 'callback' => [__CLASS__, 'lookup_batch'],
            'permission_callback' => function($r) { return self::lookup_product_permission(); }
        ]);

        // =====================================================================
        // 7. LOGISTIK & WEBHOOK EKSPEDISI RESMI
        // =====================================================================

        // Lacak Resi Tertentu secara Langsung
        register_rest_route('pk01/v1', '/production/identity/(?P<code>[A-Za-z0-9._\-]+)', [
            'methods' => 'GET', 'callback' => [__CLASS__, 'lookup_production_identity'], 'permission_callback' => [__CLASS__, 'lookup_product_permission']
        ]);

        register_rest_route('pk01/v1', '/shipping/track', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'get_shipping_track'],
            'permission_callback' => '__return_true' // Publik dapat melacak nomor resi
        ]);

        // Webhook Penerima Pembaruan Otomatis dari Ekspedisi (Binderbyte / Biteship)
        register_rest_route('pk01/v1', '/shipping/webhook', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'handle_shipping_webhook'],
            'permission_callback' => '__return_true' // Terbuka untuk menerima postback dari server kurir
        ]);
    }

    // =========================================================================
    // CALLBACK LOGIKA OPERASIONAL SETIAP ROUTE
    // =========================================================================

    public static function get_dashboard() {
        $data = class_exists('PK01_Engine') ? PK01_Engine::dashboard() : [];
        return rest_ensure_response($data);
    }

    public static function get_smart_dashboard() {
        $data = class_exists('PK01_Engine') ? PK01_Engine::smart_dashboard() : [];
        return rest_ensure_response($data);
    }

    public static function get_mobile_status() {
        $dashboard_data = class_exists('PK01_Engine') ? PK01_Engine::smart_dashboard() : [];
        $ai_status      = class_exists('PK01_AI') ? PK01_AI::status() : ['enabled' => false];

        return rest_ensure_response([
            'ok'        => true,
            'timestamp' => current_time('mysql'),
            'data'      => $dashboard_data,
            'ai'        => $ai_status
        ]);
    }

    public static function post_theme_order($request) {
        if (!class_exists('PK01_Theme_Integration')) return new WP_Error('integration_unavailable','Theme integration belum tersedia.',['status'=>503]);
        $p = $request->get_json_params() ?: [];
        try {
            $items = is_array($p['items'] ?? null) ? $p['items'] : [];
            $customer = is_array($p['customer'] ?? null) ? $p['customer'] : [];
            return rest_ensure_response(PK01_Theme_Integration::create_order($items, $customer));
        } catch (Throwable $e) {
            return new WP_Error('pk01_theme_order_error', $e->getMessage(), ['status'=>400]);
        }
    }

    public static function post_seller_offline_sale($request) {
        if (!class_exists('PK01_Theme_Integration')) return new WP_Error('integration_unavailable','Seller integration belum tersedia.',['status'=>503]);
        $p = $request->get_json_params() ?: [];
        try {
            $seller_id=(int)($p['seller_id']??0); $variant_id=(int)($p['variant_id']??0); $qty=(float)($p['qty']??0);
            return rest_ensure_response(PK01_Theme_Integration::create_offline_seller_sale($seller_id,$variant_id,$qty,$p));
        } catch (Throwable $e) {
            return new WP_Error('pk01_seller_offline_sale_error', $e->getMessage(), ['status'=>400]);
        }
    }

    public static function post_mobile_command($request) {
        $question = sanitize_textarea_field($request->get_param('question') ?? '');
        $session  = sanitize_key($request->get_param('session') ?? 'mobile-' . get_current_user_id());

        if (empty($question)) {
            return new WP_Error('empty_command', 'Perintah suara atau teks tidak boleh kosong.', ['status' => 400]);
        }

        if (!class_exists('PK01_AI')) {
            return new WP_Error('no_ai', 'Modul AI belum terpasang di server.', ['status' => 500]);
        }

        $res = PK01_AI::ask($question, $session, ['mobile' => true]);
        return rest_ensure_response($res);
    }

    public static function get_cash_balance() {
        $balance = class_exists('PK01_Engine') ? PK01_Engine::cash_balance() : 0;
        return rest_ensure_response([
            'balance'        => (float)$balance,
            'balance_format' => 'Rp ' . number_format((float)$balance, 0, ',', '.'),
            'timestamp'      => current_time('mysql')
        ]);
    }

    public static function get_finance_report($request) {
        $from = sanitize_text_field($request->get_param('from') ?? current_time('Y-m-01'));
        $to   = sanitize_text_field($request->get_param('to') ?? current_time('Y-m-d'));

        if (!class_exists('PK01_Engine') || !method_exists('PK01_Engine', 'financial_report')) {
            return new WP_Error('unavailable', 'Engine laporan keuangan belum siap.', ['status' => 500]);
        }

        $report = PK01_Engine::financial_report($from, $to);
        return rest_ensure_response($report);
    }

    public static function get_critical_materials() {
        global $wpdb;
        $t_mat = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('materials') : $wpdb->prefix . 'pk01_materials';

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_mat)) !== $t_mat) {
            return rest_ensure_response([]);
        }

        $critical = $wpdb->get_results(
            "SELECT id, code, name, unit, cost, stock, min_stock 
             FROM `{$t_mat}` 
             WHERE stock <= min_stock 
             ORDER BY stock ASC LIMIT 50", 
            ARRAY_A
        ) ?: [];

        return rest_ensure_response([
            'count'     => count($critical),
            'materials' => $critical
        ]);
    }

    public static function post_create_sale($request) {
        $params = $request->get_json_params() ?: $request->get_body_params();

        // Validasi Kunci Idempotensi (Mencegah Dobel Checkout POS)
        $idem_key = $request->get_header('Idempotency-Key') ?: ($params['idempotency_key'] ?? '');

        if (class_exists('PK01_Idempotency')) {
            $execution = PK01_Idempotency::run('rest_create_sale', $params, function() use ($params) {
                return self::execute_sale_creation($params);
            });

            if (!empty($execution['success'])) {
                return rest_ensure_response($execution['data']);
            }
            return new WP_Error('sale_failed', $execution['message'] ?? 'Gagal membuat pesanan.', ['status' => 409]);
        }

        $res = self::execute_sale_creation($params);
        return rest_ensure_response($res);
    }

    private static function execute_sale_creation($params) {
        global $wpdb;
        $t_so = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('sales_orders') : $wpdb->prefix . 'pk01_sales_orders';

        $customer_name = sanitize_text_field($params['customer_name'] ?? 'Pelanggan POS');
        $total_amount  = (float)($params['total_amount'] ?? 0);
        $order_no      = class_exists('PK01_Engine') ? PK01_Engine::document_number('invoice', get_option('pk01_invoice_prefix','INV'), absint(get_option('pk01_invoice_digits',5)), get_option('pk01_invoice_pattern','{PREFIX}/{YYYY}{MM}/{SEQ}')) : 'INV/' . current_time('Ym') . '/' . wp_rand(10000,99999);

        if ($total_amount <= 0) {
            throw new Exception('Nominal transaksi harus lebih dari Rp 0.');
        }

        $wpdb->insert($t_so, [
            'order_no'         => $order_no,
            'invoice_no'       => $order_no,
            'channel'          => sanitize_key($params['channel'] ?? 'pos'),
            'customer_name'    => $customer_name,
            'customer_phone'   => sanitize_text_field($params['customer_phone'] ?? ''),
            'total_amount'     => $total_amount,
            'gross'            => $total_amount,
            'net'              => $total_amount,
            'status'           => 'processing',
            'payment_status'   => sanitize_key($params['payment_status'] ?? 'paid'),
            'created_at'       => current_time('mysql')
        ]);

        return [
            'order_id' => (int)$wpdb->insert_id,
            'order_no' => $order_no,
            'total'    => $total_amount
        ];
    }

    public static function post_ai_ask($request) {
        $question = sanitize_textarea_field($request->get_param('question') ?? '');
        if (empty($question)) {
            return new WP_Error('empty_question', 'Pertanyaan belum diisi.', ['status' => 400]);
        }

        if (!class_exists('PK01_AI')) {
            return new WP_Error('ai_missing', 'Engine AI belum aktif.', ['status' => 500]);
        }

        $ans = PK01_AI::ask($question);
        return rest_ensure_response($ans);
    }

    public static function lookup_product_permission() {
        if (!is_user_logged_in()) return false;
        if (!class_exists('PK01_Authorization')) return current_user_can('read');
        foreach (['products','sales','shipments','production','materials','seller'] as $module) {
            if (PK01_Authorization::can($module)) return true;
        }
        return false;
    }

    public static function lookup_product($request) {
        global $wpdb;
        $q = sanitize_text_field($request->get_param('q') ?? '');
        if (strlen($q) < 2) return new WP_Error('short_query','Masukkan minimal 2 karakter.', ['status'=>400]);
        $pt=PK01_DB::t('products'); $vt=PK01_DB::t('product_variants');
        $like='%'.$wpdb->esc_like($q).'%';
        $rows=$wpdb->get_results($wpdb->prepare("SELECT p.id product_id,p.code product_code,p.name product_name,p.image_id,v.id variant_id,v.sku,v.name variant_name,v.size,v.material,v.finishing,COALESCE(v.stock,0) stock FROM `$pt` p INNER JOIN `$vt` v ON v.product_id=p.id WHERE p.status='active' AND v.status='active' AND (p.code LIKE %s OR p.name LIKE %s OR v.sku LIKE %s OR v.name LIKE %s) ORDER BY p.name ASC,v.id ASC LIMIT 20",$like,$like,$like,$like),ARRAY_A)?:[];
        $out=[]; foreach($rows as $r){ $out[]=['product_id'=>(int)$r['product_id'],'product_code'=>$r['product_code'],'product_name'=>$r['product_name'],'variant_id'=>(int)$r['variant_id'],'sku'=>$r['sku'],'variant_name'=>$r['variant_name'],'size'=>$r['size'],'material'=>$r['material'],'finishing'=>$r['finishing'],'stock'=>max(0,(float)$r['stock']),'image'=>!empty($r['image_id'])?wp_get_attachment_image_url((int)$r['image_id'],'thumbnail'):'' ]; }
        return rest_ensure_response(['ok'=>true,'query'=>$q,'count'=>count($out),'items'=>$out]);
    }

    public static function lookup_production_identity($request) {
        global $wpdb;
        $code=sanitize_text_field($request['code']??'');
        if($code==='') return new WP_Error('empty_code','Kode produksi/CNC wajib diisi.',['status'=>400]);
        $pr=PK01_DB::t('production_results'); $pu=PK01_DB::t('production_units'); $jt=PK01_DB::t('jobs'); $jit=PK01_DB::t('job_items'); $vt=PK01_DB::t('product_variants'); $pt=PK01_DB::t('products');
        $r=$wpdb->get_row($wpdb->prepare("SELECT pr.production_code,pr.batch_code,pr.barcode_value,pr.qr_payload,pr.good_qty,pr.reject_qty,pr.status,j.id job_id,j.job_no,j.production_date,p.name product_name,v.sku,v.name variant_name,v.material,v.finishing,p.product_length,p.product_width,p.product_height,p.product_thickness,p.dimension_unit FROM `$pr` pr JOIN `$jt` j ON j.id=pr.job_id LEFT JOIN `$jit` ji ON ji.job_id=j.id LEFT JOIN `$vt` v ON v.id=ji.variant_id LEFT JOIN `$pt` p ON p.id=v.product_id WHERE pr.production_code=%s OR pr.batch_code=%s OR pr.barcode_value=%s LIMIT 1",$code,$code,$code),ARRAY_A);
        if($r){
            return rest_ensure_response(['ok'=>true,'type'=>'production_result','production_code'=>$r['production_code'],'batch_code'=>$r['batch_code'],'job_id'=>(int)$r['job_id'],'job_no'=>$r['job_no'],'product_name'=>$r['product_name']??'','variant_name'=>$r['variant_name']??'','sku'=>$r['sku']??'','material'=>$r['material']??'','finishing'=>$r['finishing']??'','size'=>trim(($r['product_length']??'').' × '.($r['product_width']??'').' × '.($r['product_height']??'').' '.($r['dimension_unit']??'')),'thickness'=>$r['product_thickness']??'','production_date'=>$r['production_date']??'','good_qty'=>(float)$r['good_qty'],'reject_qty'=>(float)$r['reject_qty'],'status'=>$r['status'],'qr_payload'=>$r['qr_payload']??'']);
        }
        $u=$wpdb->get_row($wpdb->prepare("SELECT u.production_code,u.cnc_code,u.unit_no,u.unit_id,u.batch_no,u.production_date,u.qr_payload,u.status,j.id job_id,j.job_no,p.name product_name,v.sku,v.name variant_name,v.material,v.finishing,p.product_length,p.product_width,p.product_height,p.product_thickness,p.dimension_unit FROM `$pu` u JOIN `$jt` j ON j.id=u.job_id LEFT JOIN `$vt` v ON v.id=u.variant_id LEFT JOIN `$pt` p ON p.id=v.product_id WHERE u.cnc_code=%s OR u.unit_id=%s LIMIT 1",$code,$code),ARRAY_A);
        if(!$u) return new WP_Error('production_not_found','Kode produksi/CNC tidak ditemukan.',['status'=>404]);
        return rest_ensure_response(['ok'=>true,'type'=>'cnc_unit','cnc_code'=>$u['cnc_code']?:$u['unit_id'],'production_code'=>$u['production_code'],'batch_code'=>$u['batch_no'],'unit_no'=>$u['unit_no'],'job_id'=>(int)$u['job_id'],'job_no'=>$u['job_no'],'product_name'=>$u['product_name']??'','variant_name'=>$u['variant_name']??'','sku'=>$u['sku']??'','material'=>$u['material']??'','finishing'=>$u['finishing']??'','size'=>trim(($u['product_length']??'').' × '.($u['product_width']??'').' × '.($u['product_height']??'').' '.($u['dimension_unit']??'')),'thickness'=>$u['product_thickness']??'','production_date'=>$u['production_date']??'','status'=>$u['status'],'qr_payload'=>$u['qr_payload']??'']);
    }

    public static function lookup_batch($request) {
        global $wpdb; $code=sanitize_text_field($request['code']??'');
        if($code==='') return new WP_Error('empty_batch','Kode batch wajib diisi.',['status'=>400]);
        $pr=PK01_DB::t('production_results'); $jt=PK01_DB::t('jobs'); $jit=PK01_DB::t('job_items'); $vt=PK01_DB::t('product_variants'); $pt=PK01_DB::t('products');
        $r=$wpdb->get_row($wpdb->prepare("SELECT pr.*,j.job_no,p.name product_name,v.sku FROM `$pr` pr JOIN `$jt` j ON j.id=pr.job_id LEFT JOIN `$jit` ji ON ji.job_id=j.id LEFT JOIN `$vt` v ON v.id=ji.variant_id LEFT JOIN `$pt` p ON p.id=v.product_id WHERE pr.batch_code=%s LIMIT 1",$code),ARRAY_A);
        if(!$r) return new WP_Error('batch_not_found','Batch tidak ditemukan.',['status'=>404]);
        return rest_ensure_response(['ok'=>true,'batch_code'=>$r['batch_code'],'job_id'=>(int)$r['job_id'],'job_no'=>$r['job_no'],'product_name'=>$r['product_name']??'','sku'=>$r['sku']??'','good_qty'=>(float)$r['good_qty'],'reject_qty'=>(float)$r['reject_qty'],'status'=>$r['status'],'qr_payload'=>$r['qr_payload']??'']);
    }

    public static function get_shipping_track($request) {
        $courier = sanitize_key($request->get_param('courier') ?? '');
        $waybill = strtoupper(sanitize_text_field(trim($request->get_param('waybill') ?? '')));

        if (empty($waybill)) {
            return new WP_Error('empty_waybill', 'Nomor resi wajib diisi.', ['status' => 400]);
        }

        if (class_exists('PK01_Shipping_Engine')) {
            $res = PK01_Shipping_Engine::track($courier ?: 'auto', $waybill);
            return rest_ensure_response($res);
        }

        return new WP_Error('engine_missing', 'Engine pelacakan belum tersedia.', ['status' => 500]);
    }

    /**
     * HANDLER WEBHOOK EKSPEDISI RESMI (POSTBACK OTOMATIS)
     */
    public static function handle_shipping_webhook($request) {
        if (class_exists('PK01_Shipping_Smart')) return PK01_Shipping_Smart::webhook($request);
        return new WP_Error('shipping_engine_missing','Engine tracking PK01 belum tersedia.',['status'=>500]);
    }
}

// Endpoint REST diinisialisasi oleh pk01-operasional.php saat plugins_loaded.
// Jangan mendaftarkan hook dua kali saat file dimuat ulang oleh integrasi lain.