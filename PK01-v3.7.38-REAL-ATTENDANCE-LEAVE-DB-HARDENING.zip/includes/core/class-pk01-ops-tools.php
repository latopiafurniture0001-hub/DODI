<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Universal Operational Search & Scan Hub.
 * Satu UI untuk pencarian produk/resi dan scan barcode/QR pada seluruh dashboard.
 */
class PK01_Ops_Tools {
    public static function init() {}

    public static function render() {
        if (!is_user_logged_in()) return '';
        $rest = esc_url_raw(rest_url('pk01/v1/'));
        $nonce = wp_create_nonce('wp_rest');
        ob_start(); ?>
        <section class="pk01-ops-command" data-rest-base="<?php echo esc_attr($rest); ?>" data-rest-nonce="<?php echo esc_attr($nonce); ?>">
          <div class="pk01-ops-command-head">
            <div>
              <span class="pk01-op-eyebrow">PK01 QUICK CONTROL</span>
              <h2>Pencarian & Scan Operasional</h2>
              <p>Cari produk, SKU, kode batch, atau nomor resi dari satu tempat. Kamera dapat membaca barcode/QR tanpa mengetik ulang.</p>
            </div>
            <div class="pk01-ops-command-status"><span class="pk01-status-dot"></span><span>Database PK01</span></div>
          </div>
          <div class="pk01-ops-command-grid">
            <div class="pk01-lookup-panel">
              <div class="pk01-lookup-tabs" role="tablist">
                <button type="button" class="is-active" data-lookup="product">Produk</button>
                <button type="button" data-lookup="resi">Resi</button>
                <button type="button" data-lookup="batch">Batch / Job</button>
              </div>
              <div class="pk01-lookup-row">
                <input type="search" class="pk01-universal-search" autocomplete="off" placeholder="Cari SKU, kode produk, nama produk...">
                <button type="button" class="pk01-op-button pk01-lookup-submit">Cari</button>
                <button type="button" class="pk01-op-button is-secondary pk01-open-scanner">📷 Scan</button>
              </div>
              <div class="pk01-lookup-hint">Tip: scan barcode/QR pada label produk atau masukkan nomor resi secara manual.</div>
              <div class="pk01-lookup-results" aria-live="polite"></div>
            </div>
            <div class="pk01-scanner-panel" hidden>
              <div class="pk01-scanner-head"><strong>Scanner Kamera</strong><button type="button" class="pk01-scanner-close">Tutup</button></div>
              <video class="pk01-scanner-video" playsinline muted></video>
              <div class="pk01-scanner-frame">Arahkan barcode / QR ke dalam area ini</div>
              <div class="pk01-scanner-note">Scanner memakai BarcodeDetector bawaan browser bila tersedia. Jika browser tidak mendukung kamera, gunakan input manual.</div>
            </div>
          </div>
        </section>
        <?php return ob_get_clean();
    }
}
