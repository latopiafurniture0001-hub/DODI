<?php
if (!defined('ABSPATH')) exit;
/**
 * Stable integration contract for the Masterpiece Commerce Theme.
 * The theme never touches PK01 tables directly; all business data/actions stay here.
 */
class PK01_Theme_Integration {
 public const API_VERSION='1.1';
 public static function init(){
  add_filter('pk01_theme_integration_manifest',[__CLASS__,'manifest']);
  add_filter('pk01_theme_product_service',[__CLASS__,'product_service']);
  add_filter('pk01_theme_order_service',[__CLASS__,'order_service']);
  add_filter('pk01_theme_customer_service',[__CLASS__,'customer_service']);
  add_filter('pk01_theme_tracking_service',[__CLASS__,'tracking_service']);
  add_filter('pk01_theme_affiliate_service',[__CLASS__,'affiliate_service']);
  add_filter('pk01_theme_inventory_service',[__CLASS__,'inventory_service']);
  add_filter('pk01_theme_pricing_service',[__CLASS__,'pricing_service']);
  add_filter('pk01_theme_product_write_service',[__CLASS__,'product_write_service']);
  add_action('rest_api_init',[__CLASS__,'register_rest_routes']);
 }
 public static function manifest($m=[]){return array_merge(['connected'=>true,'plugin'=>'PK01 Operasional Usaha','plugin_version'=>defined('PK01_VERSION')?PK01_VERSION:'','api_version'=>self::API_VERSION,'min_theme_version'=>'1.2.0','source_of_truth'=>true,'data_policy'=>'Theme storefront MUST use PK01 services/API and MUST NOT read or write PK01 tables directly.','management_policy'=>'Product/master changes are executed by PK01 Engine with RBAC + audit.','capabilities'=>['products','variants','pricing','inventory','orders','customers','seller','marketplace','finance','cash','payroll','closing','ai','returns','shipments','tracking','product_write','inventory_read']],$m);}
 public static function product_service($service=[]){
  return ['get_products'=>function($args=[]){$r=PK01_Ecommerce::products();return $r instanceof WP_REST_Response?$r->get_data():$r;},'get_product'=>function($sku){$r=PK01_Ecommerce::product_by_sku(new WP_REST_Request('GET','/pk01/v2/store/product/'.rawurlencode($sku)));return $r instanceof WP_REST_Response?$r->get_data():$r;}]+$service;
 }

 public static function inventory_service($service=[]){
  return array_merge(['get_stock'=>[__CLASS__,'get_stock']],$service);
 }
 public static function pricing_service($service=[]){
  return array_merge(['get_price'=>[__CLASS__,'get_price']],$service);
 }
 public static function product_write_service($service=[]){
  return array_merge(['create'=>[__CLASS__,'create_product'],'update'=>[__CLASS__,'update_product']],$service);
 }
 public static function get_stock($variant_id=0){
  global $wpdb; $vid=(int)$variant_id; if($vid<=0) return null;
  $t=PK01_DB::t('product_variants');
  $v=$wpdb->get_row($wpdb->prepare("SELECT id,sku,stock,status,updated_at FROM `{$t}` WHERE id=%d",$vid),ARRAY_A);
  if(!$v) return null;
  return ['variant_id'=>(int)$v['id'],'sku'=>$v['sku'],'stock'=>(float)$v['stock'],'status'=>$v['status'],'updated_at'=>$v['updated_at']];
 }
 public static function get_price($variant_id=0){
  $vid=(int)$variant_id; if($vid<=0) return null;
  global $wpdb; $t=PK01_DB::t('product_variants');
  $v=$wpdb->get_row($wpdb->prepare("SELECT id,sku,price,hpp,status FROM `{$t}` WHERE id=%d",$vid),ARRAY_A);
  if(!$v) return null;
  $price=(float)PK01_Ecommerce::price_for_variant_public($vid);
  return ['variant_id'=>$vid,'sku'=>$v['sku'],'price'=>$price,'hpp'=>(float)$v['hpp'],'status'=>$v['status']];
 }
 public static function create_product($payload=[]){
  if(!self::can_manage_master()) throw new Exception('Tidak berwenang mengelola master produk.');
  $payload=is_array($payload)?$payload:[]; $product=$payload['product']??$payload;
  $variant=$payload['variant']??[]; $gallery=$payload['gallery_ids']??[];
  $pid=PK01_Engine::create_product($product['code']??'', $product['name']??'', $product['notes']??'', $product['description']??'', $product);
  try{
   if(!empty($variant)) PK01_Engine::create_variant($pid,$variant['sku']??'', $variant['name']??($product['name']??''), $variant['size']??'', $variant['material']??'', $variant['finishing']??($product['finishing']??''), (float)($variant['hpp']??0),(float)($variant['price']??0),(float)($variant['stock']??0));
   foreach(array_filter(array_map('intval',(array)$gallery)) as $aid) PK01_Engine::add_product_image($pid,$aid,((int)$aid===(int)($product['image_id']??0))?'main':'additional');
  }catch(Throwable $e){
   // Do not delete the created master automatically; preserve audit/data and surface the real error.
   throw $e;
  }
  $result=['product_id'=>$pid,'message'=>'Produk dibuat melalui PK01 Business Engine.']; do_action('pk01_theme_product_changed',$result,'create'); return $result;
 }
 public static function update_product($payload=[]){
  if(!self::can_manage_master()) throw new Exception('Tidak berwenang mengelola master produk.');
  $payload=is_array($payload)?$payload:[]; $pid=(int)($payload['product_id']??0);
  if($pid<=0) throw new Exception('Product ID wajib diisi.');
  PK01_Engine::update_product($pid,$payload['product']??[]);
  if(!empty($payload['variant_id'])) PK01_Engine::update_variant((int)$payload['variant_id'],$payload['variant']??[]);
  foreach(array_filter(array_map('intval',(array)($payload['gallery_ids']??[]))) as $aid) PK01_Engine::add_product_image($pid,$aid,((int)$aid===(int)($payload['product']['image_id']??0))?'main':'additional');
  $result=['product_id'=>$pid,'message'=>'Produk diperbarui melalui PK01 Business Engine.']; do_action('pk01_theme_product_changed',$result,'update'); return $result;
 }
 private static function can_manage_master(){
  return is_user_logged_in() && class_exists('PK01_Authorization') && PK01_Authorization::can_action('master_data','create');
 }
 public static function create_offline_seller_sale($seller_id,$variant_id,$qty,$meta=[]){
  global $wpdb;
  $seller_id=(int)$seller_id; $variant_id=(int)$variant_id; $qty=(float)$qty;
  if($seller_id<=0||$variant_id<=0||$qty<=0) throw new Exception('Seller, SKU/varian, dan qty wajib diisi.');
  $sa=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('sales_accounts')." WHERE id=%d AND type='seller' AND active=1",$seller_id),ARRAY_A);
  if(!$sa) throw new Exception('Mitra seller tidak ditemukan atau nonaktif.');
  $v=$wpdb->get_row($wpdb->prepare("SELECT id,sku,name,hpp,price,stock,status FROM ".PK01_DB::t('product_variants')." WHERE id=%d AND status='active'",$variant_id),ARRAY_A);
  if(!$v) throw new Exception('Varian produk tidak ditemukan atau tidak aktif.');
  $stock=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty ELSE -qty END),0) FROM ".PK01_DB::t('stock_transactions')." WHERE stock_type='finished' AND item_id=%d",$variant_id));
  if($stock<$qty) throw new Exception('Stok pusat tidak mencukupi untuk penjualan offline seller. Tersedia: '.rtrim(rtrim(number_format($stock,4,'.',''),'0'),'.'));
  $price=self::get_price($variant_id); if($price<=0) $price=(float)$v['price']; if($price<=0) throw new Exception('Harga produk belum aktif.');
  $total=round($price*$qty,2); $no=PK01_Engine::document_number('seller_order');
  $wpdb->query('START TRANSACTION');
  try{
   $wpdb->insert(PK01_DB::t('seller_orders'),['order_no'=>$no,'seller_account_id'=>$seller_id,'status'=>'fulfilled','subtotal'=>$total,'total'=>$total,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);
   $oid=(int)$wpdb->insert_id;
   $wpdb->insert(PK01_DB::t('seller_order_items'),['order_id'=>$oid,'variant_id'=>$variant_id,'qty'=>$qty,'unit_price'=>$price,'total'=>$total]);
   $updated=$wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('product_variants')." SET stock=stock-%f, updated_at=%s WHERE id=%d AND stock>=%f",$qty,current_time('mysql'),$variant_id,$qty));
   if($updated!==1) throw new Exception('Stok berubah saat pencatatan penjualan offline.');
   $wpdb->insert(PK01_DB::t('stock_transactions'),['stock_type'=>'finished','item_id'=>$variant_id,'variant_id'=>$variant_id,'qty'=>$qty,'direction'=>'out','reference_type'=>'seller_offline_sale','reference_id'=>$oid,'reference_no'=>$no,'notes'=>'Penjualan offline oleh mitra seller','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
   $wpdb->insert(PK01_DB::t('seller_sales'),['seller_account_id'=>$seller_id,'order_id'=>$oid,'variant_id'=>$variant_id,'qty'=>$qty,'hpp'=>(float)$v['hpp'],'unit_price'=>$price,'total'=>$total,'sold_at'=>current_time('mysql')]);
   if(class_exists('PK01_Audit')) PK01_Audit::log('seller_offline_sale','seller','seller_order',(string)$oid,null,['seller_id'=>$seller_id,'variant_id'=>$variant_id,'qty'=>$qty,'total'=>$total,'source'=>'offline']);
   $wpdb->query('COMMIT');
   return ['ok'=>true,'sale_id'=>$oid,'order_no'=>$no,'seller_id'=>$seller_id,'variant_id'=>$variant_id,'qty'=>$qty,'unit_price'=>$price,'total'=>$total,'channel'=>'seller_offline','message'=>'Penjualan offline seller tercatat dan stok pusat terpotong otomatis.'];
  }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
 }

 public static function register_rest_routes(){
  register_rest_route('pk01/v2','/theme/manifest',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>function(){return rest_ensure_response(self::manifest([]));}]);
  register_rest_route('pk01/v2','/theme/stock/(?P<variant_id>\d+)',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>function($r){return rest_ensure_response(self::get_stock((int)$r['variant_id']));}]);
  register_rest_route('pk01/v2','/theme/price/(?P<variant_id>\d+)',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>function($r){return rest_ensure_response(self::get_price((int)$r['variant_id']));}]);
  register_rest_route('pk01/v2','/theme/product',['methods'=>'POST','permission_callback'=>[__CLASS__,'rest_write_permission'],'callback'=>function($r){try{return rest_ensure_response(self::create_product($r->get_json_params()?:[]));}catch(Throwable $e){return new WP_Error('pk01_product_write_error',$e->getMessage(),['status'=>400]);}}]);
  register_rest_route('pk01/v2','/theme/product/(?P<product_id>\d+)',['methods'=>'PUT','permission_callback'=>[__CLASS__,'rest_write_permission'],'callback'=>function($r){try{$p=$r->get_json_params()?:[];$p['product_id']=(int)$r['product_id'];return rest_ensure_response(self::update_product($p));}catch(Throwable $e){return new WP_Error('pk01_product_update_error',$e->getMessage(),['status'=>400]);}}]);
 }
 public static function rest_write_permission($request){
  return self::can_manage_master() && wp_verify_nonce((string)$request->get_header('X-WP-Nonce'),'wp_rest');
 }

 public static function order_service($service=[]){return array_merge(['create'=>[__CLASS__,'create_order'],'get'=>[__CLASS__,'get_order']],$service);}
 public static function customer_service($service=[]){return array_merge(['find_or_create'=>[__CLASS__,'find_or_create_customer']],$service);}
 public static function tracking_service($service=[]){return array_merge(['track'=>[__CLASS__,'track_tracking']],$service);}
 public static function track_tracking($tracking_no){ $local=PK01_Engine::get_shipment_by_tracking($tracking_no); if(!$local)return null; $last=!empty($local['last_event_at'])?strtotime($local['last_event_at']):0; if($last && (time()-$last)<600)return $local; if(class_exists('PK01_Shipping_Smart')){ $fresh=PK01_Shipping_Smart::sync_tracking_no($tracking_no); if($fresh)return $fresh; } return $local; }
 public static function affiliate_service($service=[]){return array_merge(['available'=>false],$service);}
 public static function find_or_create_customer($name,$phone='',$email=''){
  global $wpdb;$t=PK01_DB::t('customers');$phone=sanitize_text_field($phone);$email=sanitize_email($email);$name=sanitize_text_field($name);
  $where=$email?$wpdb->prepare('email=%s',$email):($phone?$wpdb->prepare('phone=%s',$phone):'');
  $id=$where?(int)$wpdb->get_var("SELECT id FROM $t WHERE $where LIMIT 1"):0;
  if($id){$wpdb->update($t,['name'=>$name?:null,'phone'=>$phone?:null,'email'=>$email?:null,'updated_at'=>current_time('mysql')],['id'=>$id]);return $id;}
  $wpdb->insert($t,['name'=>$name?:'Customer','phone'=>$phone?:null,'email'=>$email?:null,'user_id'=>get_current_user_id()?:null,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);return (int)$wpdb->insert_id;
 }
 public static function create_order($items,$customer=[]){
  if(!is_array($items)||!$items)throw new Exception('Keranjang kosong.');
  global $wpdb;$items=array_values($items);$customer=is_array($customer)?$customer:[];
  $channel=(int)$wpdb->get_var("SELECT id FROM ".PK01_DB::t('channels')." WHERE code='website' LIMIT 1");
  if(!$channel){$wpdb->insert(PK01_DB::t('channels'),['code'=>'website','name'=>'Website','status'=>'active','created_at'=>current_time('mysql')]);$channel=(int)$wpdb->insert_id;}
  $validated=[];$gross=0;$hpp=0;
  foreach($items as $it){$vid=(int)($it['variant_id']??0);$qty=(float)($it['qty']??0);if($vid<=0||$qty<=0)throw new Exception('Item keranjang tidak valid.');$v=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('product_variants')." WHERE id=%d AND status='active'",$vid),ARRAY_A);if(!$v)throw new Exception('Varian tidak ditemukan.');$stock=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty ELSE -qty END),0) FROM ".PK01_DB::t('stock_transactions')." WHERE stock_type='finished' AND item_id=%d",$vid));if($stock<$qty)throw new Exception('Stok tidak mencukupi untuk SKU '.$v['sku'].'. Tersedia: '.rtrim(rtrim(number_format($stock,4,'.',''),'0'),'.'));$price=(float)PK01_Ecommerce::price_for_variant_public($vid);if($price<=0)throw new Exception('Harga belum aktif untuk SKU '.$v['sku'].'.');$validated[]=['v'=>$v,'vid'=>$vid,'qty'=>$qty,'price'=>$price,'stock'=>$stock];$gross+=round($price*$qty,2);$hpp+=round((float)$v['hpp']*$qty,2);}
  $customer_id=self::find_or_create_customer($customer['name']??'',$customer['phone']??'',$customer['email']??'');$no=class_exists('PK01_Engine')?PK01_Engine::document_number('invoice',get_option('pk01_invoice_prefix','INV'),absint(get_option('pk01_invoice_digits',5)),get_option('pk01_invoice_pattern','{PREFIX}/{YYYY}{MM}/{SEQ}')):'INV/'.current_time('Ym').'/'.wp_rand(10000,99999);
  $wpdb->query('START TRANSACTION');try{
   $sale=['order_no'=>$no,'invoice_no'=>$no,'channel_id'=>$channel,'status'=>'processing','gross'=>$gross,'net'=>$gross,'hpp'=>$hpp,'created_at'=>current_time('mysql')];
   $cols=$wpdb->get_col("SHOW COLUMNS FROM ".PK01_DB::t('sales_orders'),0);if(in_array('customer_id',$cols,true))$sale['customer_id']=$customer_id;if(in_array('customer_name',$cols,true))$sale['customer_name']=sanitize_text_field($customer['name']??'');if(in_array('customer_phone',$cols,true))$sale['customer_phone']=sanitize_text_field($customer['phone']??'');
   if(!$wpdb->insert(PK01_DB::t('sales_orders'),$sale))throw new Exception('Gagal membuat pesanan.');$sid=(int)$wpdb->insert_id; if(class_exists('PK01_Affiliate')){ try{ PK01_Affiliate::attribute_order($sid); }catch(Throwable $affiliate_error){ /* atribusi tidak boleh menggagalkan order; dicatat jika audit tersedia */ if(class_exists('PK01_Audit')){try{PK01_Audit::log('affiliate_attribution_error','affiliate','sales_order',(string)$sid,null,['message'=>$affiliate_error->getMessage()]);}catch(Throwable $e){}} } }
   foreach($validated as $x){
    if(!$wpdb->insert(PK01_DB::t('sales_order_items'),['order_id'=>$sid,'variant_id'=>$x['vid'],'product_name'=>$x['v']['name'],'qty'=>$x['qty'],'unit_price'=>$x['price'],'hpp'=>(float)$x['v']['hpp'],'total'=>round($x['qty']*$x['price'],2)])) throw new Exception('Gagal menyimpan item pesanan: '.($wpdb->last_error?:'database error'));
    $updated=$wpdb->query($wpdb->prepare("UPDATE ".PK01_DB::t('product_variants')." SET stock=stock-%f, updated_at=%s WHERE id=%d AND stock>=%f",$x['qty'],current_time('mysql'),$x['vid'],$x['qty']));
    if($updated!==1) throw new Exception('Stok berubah saat checkout. Silakan ulangi.');
    if(!$wpdb->insert(PK01_DB::t('stock_transactions'),['stock_type'=>'finished','item_id'=>$x['vid'],'variant_id'=>$x['vid'],'qty'=>$x['qty'],'direction'=>'out','reference_type'=>'website_sale','reference_id'=>$sid,'reference_no'=>$no,'notes'=>'Penjualan website','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')])) throw new Exception('Gagal mencatat mutasi stok: '.($wpdb->last_error?:'database error'));
   }
   $wpdb->insert(PK01_DB::t('activity_logs'),['timestamp'=>current_time('mysql'),'user_id'=>get_current_user_id(),'action'=>'website_order_created','module'=>'sales','entity'=>'sales_order','transaction_id'=>$no,'after_data'=>wp_json_encode(['sale_id'=>$sid,'customer_id'=>$customer_id,'customer'=>$customer]),'level'=>'info']);$wpdb->query('COMMIT');return ['order_id'=>$sid,'order_no'=>$no,'total'=>$gross,'customer_id'=>$customer_id,'message'=>'Pesanan berhasil dibuat.'];
  }catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
 }
 public static function get_order($id){global $wpdb;$o=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PK01_DB::t('sales_orders')." WHERE id=%d",(int)$id),ARRAY_A);return $o?:null;}
}
