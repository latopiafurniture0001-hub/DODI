<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Idempotency & Concurrency Lock Engine
 * Mencegah duplikasi transaksi ganda (Double Spend / Double Checkout / Replay Attack),
 * mengelola penguncian atomik database (Race Condition Guard), dan verifikasi integritas muatan.
 */
class PK01_Idempotency {

    const LOCK_TIMEOUT_SECONDS = 60; // Batas toleransi proses sebelum dianggap timeout/stale
    private static $table_verified = false;

    /**
     * Inisialisasi Hook Aman
     */
    public static function init() {
        // Jalankan pembersihan saat WordPress sudah siap (init hook)
        add_action('init', [__CLASS__, 'maybe_cleanup'], 99);
    }

    public static function maybe_cleanup() {
        if (wp_rand(1, 100) === 1) {
            self::cleanup_expired();
        }
    }

    /**
     * Dapatkan Nama Tabel Database Idempotency Secara Aman (Anti-String Kosong)
     */
    private static function table() {
        global $wpdb;
        $prefix = (isset($wpdb->prefix) && is_string($wpdb->prefix) && $wpdb->prefix !== '') ? $wpdb->prefix : 'wp_';

        $table_name = '';
        if (class_exists('PK01_DB') && method_exists('PK01_DB', 't')) {
            $table_name = PK01_DB::t('idempotency_keys');
        }

        // JIKA KOSONG, GUNAKAN FALLBACK LENGKAP (JANGAN BIARKAN KOSONG!)
        if (empty($table_name)) {
            $table_name = $prefix . 'pk01_idempotency_keys';
        }

        // Cek pembuatan tabel sekali saja di memori (Hemat Kueri)
        if (!self::$table_verified && !empty($wpdb) && is_object($wpdb)) {
            $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));
            if ($exists !== $table_name) {
                self::ensure_schema($table_name);
            }
            self::$table_verified = true;
        }

        return $table_name;
    }

    /**
     * Buat Skema Tabel Khusus Penguncian Atomik (Sintaks Standar dbDelta)
     */
    private static function ensure_schema($table_name) {
        global $wpdb;
        if (empty($wpdb) || !is_object($wpdb)) return;

        $charset_collate = $wpdb->get_charset_collate();
        
        // Aturan Wajib dbDelta: PRIMARY KEY wajib diikuti DUA SPASI
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            idempotency_key varchar(64) NOT NULL,
            action varchar(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            request_hash varchar(64) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'processing',
            response_code int(11) NOT NULL DEFAULT 200,
            response_data longtext,
            locked_until datetime NOT NULL,
            expires_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY idx_key (idempotency_key),
            KEY idx_expires (expires_at),
            KEY idx_status (status)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        PK01_DB::dbDelta_safe($sql);
    }

    /**
     * Ekstrak Kunci Idempotensi dari Header HTTP / Request Body
     */
    public static function request_key($provided = '') {
        $provided = sanitize_text_field((string)$provided);
        if (!empty($provided)) return $provided;

        $headers = [
            'HTTP_IDEMPOTENCY_KEY',
            'HTTP_X_IDEMPOTENCY_KEY',
            'HTTP_X_PK01_IDEMPOTENCY_KEY'
        ];

        foreach ($headers as $h) {
            if (!empty($_SERVER[$h])) {
                return sanitize_text_field(trim($_SERVER[$h]));
            }
        }

        if (!empty($_POST['idempotency_key'])) {
            return sanitize_text_field(trim($_POST['idempotency_key']));
        }
        if (!empty($_GET['idempotency_key'])) {
            return sanitize_text_field(trim($_GET['idempotency_key']));
        }

        return '';
    }

    /**
     * Buat Kunci Enkripsi Deterministik (Aman dari Eror Pluggable)
     */
    public static function key($action, $parts = []) {
        $u = function_exists('get_current_user_id') ? get_current_user_id() : 0;
        $clean_action = sanitize_key($action);
        $payload_string = wp_json_encode($parts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return hash('sha256', $clean_action . '|' . $u . '|' . $payload_string);
    }

    private static function payload_hash($payload) {
        return hash('sha256', wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    /**
     * 1. KUNCI PROSES SECARA ATOMIK
     */
    public static function begin($key, $ttl = 86400, $payload = [], $action = 'general') {
        global $wpdb;

        if (empty($wpdb) || !is_object($wpdb)) {
            return ['ok' => true, 'replay' => false, 'status' => 'bypassed'];
        }

        $key = sanitize_text_field(trim($key));
        if (empty($key)) {
            return ['ok' => true, 'replay' => false, 'status' => 'bypassed'];
        }

        $table = self::table();
        $now = current_time('mysql');
        $user_id = function_exists('get_current_user_id') ? get_current_user_id() : 0;
        $req_hash = self::payload_hash($payload);
        $ttl = max(300, (int)$ttl);
        $expires_at = date('Y-m-d H:i:s', time() + $ttl);
        $locked_until = date('Y-m-d H:i:s', time() + self::LOCK_TIMEOUT_SECONDS);

        // Cek Apakah Kunci Sudah Ada
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE idempotency_key = %s LIMIT 1",
            $key
        ), ARRAY_A);

        if ($existing) {
            // Verifikasi Integritas Muatan
            if (!empty($existing['request_hash']) && !hash_equals($existing['request_hash'], $req_hash)) {
                return [
                    'ok'      => false,
                    'replay'  => false,
                    'status'  => 'mismatch',
                    'message' => 'Kunci Idempotensi ini sudah digunakan sebelumnya untuk transaksi dengan parameter berbeda.'
                ];
            }

            // Jika Proses Sudah Selesai (Replay Hasil)
            if ($existing['status'] === 'done') {
                $saved_result = json_decode($existing['response_data'], true);

                if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'info')) {
                    PK01_Audit::info('idempotency_replay', 'system', "Replay hasil transaksi untuk kunci {$key}", 'idempotency', $key);
                }

                return [
                    'ok'      => true,
                    'replay'  => true,
                    'status'  => 'done',
                    'code'    => (int)$existing['response_code'],
                    'result'  => $saved_result !== null ? $saved_result : $existing['response_data']
                ];
            }

            // Jika Proses Masih Berjalan
            if ($existing['status'] === 'processing') {
                if (strtotime($existing['locked_until']) < time()) {
                    // Dobrak Kunci Basi Akibat Server Crash
                    $wpdb->update($table, [
                        'status'       => 'processing',
                        'locked_until' => $locked_until,
                        'user_id'      => $user_id
                    ], ['id' => $existing['id']]);

                    return [
                        'ok'     => true,
                        'replay' => false,
                        'status' => 'lock_acquired',
                        'token'  => $key
                    ];
                }

                return [
                    'ok'      => false,
                    'replay'  => false,
                    'status'  => 'locked',
                    'message' => 'Transaksi serupa sedang dalam antrean pemrosesan oleh sistem. Harap tunggu sesaat.'
                ];
            }
        }

        // Insert Atomik Kunci Baru
        $inserted = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO `{$table}` 
             (idempotency_key, action, user_id, request_hash, status, locked_until, expires_at, created_at) 
             VALUES (%s, %s, %d, %s, 'processing', %s, %s, %s)",
            $key, sanitize_key($action), $user_id, $req_hash, $locked_until, $expires_at, $now
        ));

        if ($inserted === 1) {
            return [
                'ok'     => true,
                'replay' => false,
                'status' => 'lock_acquired',
                'token'  => $key
            ];
        }

        return [
            'ok'      => false,
            'replay'  => false,
            'status'  => 'locked',
            'message' => 'Bentrok konkurensi: Permintaan sedang dieksekusi bersamaan.'
        ];
    }

    /**
     * 2. SELESAIKAN PROSES & SIMPAN HASIL RESMI
     */
    public static function finish($guard, $result, $response_code = 200, $ttl = 86400) {
        global $wpdb;
        if (empty($wpdb) || !is_object($wpdb)) return;

        $key = is_array($guard) ? ($guard['token'] ?? '') : (string)$guard;
        if (empty($key)) return;

        $table = self::table();
        $ttl = max(300, (int)$ttl);
        $expires_at = date('Y-m-d H:i:s', time() + $ttl);

        $json_data = (is_array($result) || is_object($result)) 
            ? wp_json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) 
            : (string)$result;

        $wpdb->update($table, [
            'status'        => 'done',
            'response_code' => (int)$response_code,
            'response_data' => $json_data,
            'expires_at'    => $expires_at
        ], ['idempotency_key' => $key]);
    }

    /**
     * 3. BATALKAN KUNCI JIKA ROLLBACK
     */
    public static function forget($guard) {
        global $wpdb;
        if (empty($wpdb) || !is_object($wpdb)) return;

        $key = is_array($guard) ? ($guard['token'] ?? '') : (string)$guard;
        if (empty($key)) return;

        $table = self::table();
        $wpdb->delete($table, ['idempotency_key' => $key]);
    }

    /**
     * 4. TANDAI GAGAL AGAR DAPAT DICOBA ULANG
     */
    public static function fail($guard, $error_message = '') {
        global $wpdb;
        if (empty($wpdb) || !is_object($wpdb)) return;

        $key = is_array($guard) ? ($guard['token'] ?? '') : (string)$guard;
        if (empty($key)) return;

        $table = self::table();
        $wpdb->update($table, [
            'status'        => 'failed',
            'response_data' => wp_json_encode(['error' => $error_message], JSON_UNESCAPED_UNICODE),
            'expires_at'    => current_time('mysql')
        ], ['idempotency_key' => $key]);
    }

    /**
     * 5. HIGHER-ORDER WRAPPER OTOMATIS (RUN CLOSURE)
     */
    public static function run($action, $payload, callable $callback, $ttl = 86400) {
        $provided_key = self::request_key();
        $idempotency_key = !empty($provided_key) ? $provided_key : self::key($action, $payload);

        $guard = self::begin($idempotency_key, $ttl, $payload, $action);

        if (!empty($guard['replay']) && ($guard['status'] ?? '') === 'done') {
            return [
                'success' => true,
                'replay'  => true,
                'data'    => $guard['result']
            ];
        }

        if (empty($guard['ok'])) {
            return [
                'success' => false,
                'replay'  => false,
                'status'  => $guard['status'] ?? 'error',
                'message' => $guard['message'] ?? 'Permintaan terduplikasi atau sedang berlangsung.'
            ];
        }

        try {
            $execution_result = call_user_func($callback);

            if (is_wp_error($execution_result)) {
                self::forget($guard);
                return [
                    'success' => false,
                    'replay'  => false,
                    'status'  => 'error',
                    'message' => $execution_result->get_error_message()
                ];
            }

            self::finish($guard, $execution_result, 200, $ttl);

            return [
                'success' => true,
                'replay'  => false,
                'data'    => $execution_result
            ];
        } catch (Throwable $e) {
            self::forget($guard);
            return [
                'success' => false,
                'replay'  => false,
                'status'  => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Pembersihan Otomatis Kunci Kedaluwarsa
     */
    public static function cleanup_expired() {
        global $wpdb;
        if (empty($wpdb) || !is_object($wpdb)) return;

        $prefix = isset($wpdb->prefix) ? $wpdb->prefix : 'wp_';
        $table = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
            ? PK01_DB::t('idempotency_keys') 
            : $prefix . 'pk01_idempotency_keys';

        if (empty($table)) {
            $table = $prefix . 'pk01_idempotency_keys';
        }

        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($exists === $table) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM `{$table}` WHERE expires_at < %s",
                current_time('mysql')
            ));
        }
    }
}

// Inisialisasi Engine Idempotensi
