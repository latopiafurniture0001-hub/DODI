<?php
if (!defined('ABSPATH')) exit;
/**
 * PK01 Product Master — single source-of-truth import service.
 * One CSV import updates products + variants only. It never invents images,
 * stock movements, marketplace rows or production data.
 */
class PK01_Product_Master {
    public static function csv_headers() {
        return ['code','name','sku','description','category','brand','material','finishing','size','hpp','price','opening_stock','length','width','height','thickness','weight','dimension_unit','weight_unit','cnc_required','prema_required','image_id'];
    }

    public static function export_template() {
        if (!current_user_can('manage_options')) wp_die('Tidak berwenang.');
        check_admin_referer('pk01_product_master_template');
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="pk01-product-master-template.csv"');
        $out=fopen('php://output','w');
        fputcsv($out,self::csv_headers());
        fclose($out); exit;
    }

    private static function value($row,$key,$default='') { return array_key_exists($key,$row) ? trim((string)$row[$key]) : $default; }
    private static function num($v) { return (float)str_replace([',',' '],['.',''],trim((string)$v)); }

    public static function import_csv($file) {
        if (!is_array($file) || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) throw new Exception('File CSV Product Master belum dipilih.');
        if (!empty($file['error'])) throw new Exception('Upload CSV gagal.');
        $ext=strtolower(pathinfo((string)$file['name'],PATHINFO_EXTENSION)); if($ext!=='csv') throw new Exception('Product Master hanya menerima CSV.');
        if ((int)$file['size'] > 10*1024*1024) throw new Exception('CSV terlalu besar. Maksimal 10 MB.');
        $fh=fopen($file['tmp_name'],'rb'); if(!$fh) throw new Exception('CSV tidak dapat dibaca.');
        $first=fgets($fh); if($first===false){fclose($fh);throw new Exception('CSV kosong.');}
        $delimiter=(substr_count($first,';')>substr_count($first,','))?';':','; rewind($fh);
        $headers=fgetcsv($fh,0,$delimiter); $headers=array_map(function($h){return sanitize_key(trim((string)$h));},(array)$headers);
        $required=['code','name','sku']; foreach($required as $r) if(!in_array($r,$headers,true)){fclose($fh);throw new Exception('Kolom wajib tidak ada: '.$r);}
        $rows=[];$line=1; while(($data=fgetcsv($fh,0,$delimiter))!==false){$line++; if(count(array_filter($data,'strlen'))===0)continue; $row=[];foreach($headers as $i=>$h)$row[$h]=isset($data[$i])?$data[$i]:'';$row['_line']=$line;$rows[]=$row;}
        fclose($fh);
        if(!$rows) throw new Exception('CSV tidak memiliki data produk.');
        global $wpdb; $pt=PK01_DB::t('products'); $vt=PK01_DB::t('product_variants');
        $pcols=$wpdb->get_col("SHOW COLUMNS FROM `{$pt}`",0); $vcols=$wpdb->get_col("SHOW COLUMNS FROM `{$vt}`",0);
        $created=0;$updated=0;$variants=0;$errors=[];
        foreach($rows as $row){
            try{
                $code=sanitize_text_field(self::value($row,'code'));$name=sanitize_text_field(self::value($row,'name'));$sku=sanitize_text_field(self::value($row,'sku'));
                if($code===''||$name===''||$sku==='') throw new Exception('code, name, sku wajib.');
                $desc=sanitize_textarea_field(self::value($row,'description')); $category=sanitize_text_field(self::value($row,'category'));$brand=sanitize_text_field(self::value($row,'brand'));
                $existing=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$pt}` WHERE code=%s LIMIT 1",$code));
                if(!$existing) $existing=(int)$wpdb->get_var($wpdb->prepare("SELECT p.id FROM `{$pt}` p INNER JOIN `{$vt}` v ON v.product_id=p.id WHERE v.sku=%s LIMIT 1",$sku));
                $image_id=absint(self::value($row,'image_id')); $cnc=!empty(self::num(self::value($row,'cnc_required')))?1:0; $prema=!empty(self::num(self::value($row,'prema_required')))?1:0;
                $pdata=['code'=>$code,'name'=>$name,'slug'=>sanitize_title($name),'updated_at'=>current_time('mysql')];
                foreach(['description'=>$desc,'category'=>$category,'brand'=>$brand,'image_id'=>$image_id,'cnc_required'=>$cnc,'prema_required'=>$prema,'product_length'=>self::num(self::value($row,'length')),'product_width'=>self::num(self::value($row,'width')),'product_height'=>self::num(self::value($row,'height')),'product_thickness'=>self::num(self::value($row,'thickness')),'product_weight'=>self::num(self::value($row,'weight')),'dimension_unit'=>sanitize_text_field(self::value($row,'dimension_unit','cm')),'weight_unit'=>sanitize_text_field(self::value($row,'weight_unit','kg'))] as $k=>$val){if(in_array($k,$pcols,true))$pdata[$k]=$val;}
                $ready=($image_id>0 && $desc!=='' && self::num(self::value($row,'price'))>0);
                if(in_array('status',$pcols,true))$pdata['status']=$ready?'active':'draft';
                if($existing){$wpdb->update($pt,$pdata,['id'=>$existing]);$pid=$existing;$updated++;}
                else{$pdata['created_at']=current_time('mysql');if(!$wpdb->insert($pt,$pdata))throw new Exception($wpdb->last_error?:'Gagal membuat produk.');$pid=(int)$wpdb->insert_id;$created++;}
                $vid=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$vt}` WHERE sku=%s LIMIT 1",$sku));
                $vdata=['product_id'=>$pid,'sku'=>$sku,'name'=>sanitize_text_field(self::value($row,'variant_name',$name)),'size'=>sanitize_text_field(self::value($row,'size')),'material'=>sanitize_text_field(self::value($row,'material')),'finishing'=>sanitize_text_field(self::value($row,'finishing')),'hpp'=>max(0,self::num(self::value($row,'hpp'))),'price'=>max(0,self::num(self::value($row,'price'))),'updated_at'=>current_time('mysql')];
                foreach($vdata as $k=>$val)if(!in_array($k,$vcols,true))unset($vdata[$k]);
                if($vid){$wpdb->update($vt,$vdata,['id'=>$vid]);$variants++;}
                else{$vdata['status']='active';$vdata['created_at']=current_time('mysql');if(!isset($vdata['stock'])&&in_array('stock',$vcols,true))$vdata['stock']=0;if(!$wpdb->insert($vt,$vdata))throw new Exception($wpdb->last_error?:'Gagal membuat SKU.');$vid=(int)$wpdb->insert_id;$variants++;}
                $opening=max(0,self::num(self::value($row,'opening_stock')));
                if($opening>0 && class_exists('PK01_Engine') && method_exists('PK01_Engine','adjust_stock')){
                    // Idempotent import: opening stock is applied only when this SKU has no stock transaction yet.
                    $st=PK01_DB::t('stock_transactions');$has=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$st}` WHERE stock_type='finished' AND item_id=%d AND reference LIKE %s",$vid,'%Product Master CSV%'.$sku.'%'));
                    if(!$has)PK01_Engine::adjust_stock('finished',$vid,$opening,'Stok awal Product Master CSV '.$sku);
                }
            }catch(Throwable $e){$errors[]='Baris '.(int)$row['_line'].': '.$e->getMessage();}
        }
        if(!$created && !$updated && !$variants) throw new Exception('Tidak ada baris CSV yang berhasil diproses. '.implode(' | ',array_slice($errors,0,5)));
        return ['created'=>$created,'updated'=>$updated,'variants'=>$variants,'errors'=>$errors,'total'=>count($rows)];
    }
}
