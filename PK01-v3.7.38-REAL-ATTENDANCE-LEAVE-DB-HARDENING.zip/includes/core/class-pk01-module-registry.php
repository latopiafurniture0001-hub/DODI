<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Module Registry 2.1 (Hardened & Bug-Free)
 * Peta arsitektur terpusat, pengatur dependensi antar-modul, katalog kapabilitas,
 * dan penyedia navigasi dinamis yang kebal terhadap eror $wpdb.
 */
class PK01_Module_Registry {

    private static $table_cache = null;

    public static function init() {}

    /**
     * 1. KATALOG LENGKAP ARSITEKTUR SELURUH MODUL SISTEM PK01
     */
    public static function all() {
        return [
            'domain_core' => [
                'label'=>'PK01 Domain Coordinator', 'group'=>'system', 'icon'=>'settings', 'table'=>null,
                'depends'=>['sales','seller','inventory','production','purchase','hr','finance'], 'nav_hidden'=>true,
                'description'=>'Satu pintu koordinasi transaksi, konteks role, rekonsiliasi dan integritas data lintas modul.'
            ],
            // ================= HUB UTAMA / DASHBOARD =================
            'owner_dashboard' => [
                'label'       => 'Dashboard Pemilik / Owner',
                'group'       => 'utama',
                'icon'        => 'bank',
                'table'       => null,
                'depends'     => ['sales', 'cash', 'finance_hub', 'seller'],
                'description' => 'Control Tower pemilik untuk pendapatan, penjualan, kas, biaya, laba, komisi, dan risiko bisnis.'
            ],
            'security' => [
                'label'=>'Security & CCTV', 'group'=>'utama', 'icon'=>'shield', 'table'=>['security_visitors','security_visitor_visits','security_vehicles','security_goods','security_incidents','security_cctv_cameras'],
                'depends'=>['shipments','sales','inventory'], 'nav_hidden'=>true, 'description'=>'Operasional Security tetap aktif di backend/API; dashboard khusus disembunyikan agar navigasi tidak penuh. Akses operasional dapat dipanggil dari alur kerja yang membutuhkan security.'
            ],
            'customer_service' => [
                'label'=>'Customer Service & Komunikasi', 'group'=>'utama', 'icon'=>'user', 'table'=>['cs_tickets','cs_messages'],
                'depends'=>[], 'nav_hidden'=>false, 'description'=>'Pusat layanan terpisah untuk pelanggan, WhatsApp, seller, dan komplain marketplace; data komunikasi dikelola sebagai satu antrean layanan.'
            ],
            'communications' => [
                'label'=>'Komunikasi Operasional','group'=>'utama','icon'=>'message','table'=>['chat_rooms','chat_participants','chat_messages'],
                'depends'=>['sales','seller','production'],'nav_hidden'=>false,'description'=>'Chat berbasis Job nyata antara Seller, Kasir, Produksi, CNC, Prema, Gudang, dan peran lain yang menjadi peserta Job.'
            ],
            'attendance' => [
                'label'=>'Absensi & Cuti Karyawan','group'=>'utama','icon'=>'clock','table'=>['attendance_devices','attendance_records','leave_types','leave_balances','leave_requests','attendance_import_logs'],
                'depends'=>['employees','payroll'],'nav_hidden'=>false,'description'=>'Workspace HR untuk presensi nyata, perangkat absensi, rekonsiliasi kehadiran, pengajuan/persetujuan cuti, dan saldo cuti. Bukan halaman WordPress Admin.'
            ],
            'administration' => [
                'label'=>'Administrasi','group'=>'utama','icon'=>'settings','table'=>null,'depends'=>['employees','attendance','security'],'nav_hidden'=>true,'description'=>'Fungsi administrasi tidak memakai dashboard terpisah. Pekerjaan diarahkan ke modul kerja terkait dan dapat dibantu Asisten AI berdasarkan hak akses pengguna.'
            ],
            'dashboard' => [
                'label'       => 'Beranda Operasional',
                'group'       => 'utama',
                'icon'        => 'home',
                'table'       => null,
                'depends'     => [],
                'description' => 'Pusat komando dan ringkasan eksekutif seluruh data bisnis.'
            ],
            'documents' => [
                'label'       => 'Dokumen & Cetak Ulang',
                'group'       => 'utama',
                'icon'        => 'receipt',
                'table'       => null,
                'depends'     => ['sales','finance_reports','production'],
                'nav_hidden'  => false,
                'description' => 'Pusat dokumen untuk membuka kembali dan mencetak ulang dokumen dari data PK01 yang tersimpan.'
            ],
            'master_data' => [
                'label'       => 'Master Data Terpusat',
                'group'       => 'utama',
                'icon'        => 'database',
                'table'       => null,
                'depends'     => [],
                'description' => 'Satu pintu pengelolaan data Karyawan, Bahan, Produk, Pemasok, dan Pelanggan.'
            ],
            'sales_hub' => [
                'label'       => 'Penjualan & Kasir',
                'group'       => 'utama',
                'icon'        => 'receipt',
                'table'       => null,
                'depends'     => ['sales'],
                'description' => 'Kasir hanya membukukan penjualan dan pembayaran. Order nyata otomatis menjadi antrean fulfillment; status packing, resi, kirim, sampai retur dipantau dari data yang sama.'
            ],
            'inventory' => [
                'label'       => 'Gudang & Pintu Barang',
                'group'       => 'utama',
                'icon'        => 'layers',
                'table'       => null,
                'depends'     => ['materials', 'products'],
                'description' => 'Satu pintu fisik barang. PO, order, produksi, resi, retur, stok, dan tanda terima saling terhubung; gudang memproses fisik, bukan membuat data transaksi bayangan.'
            ],
            'purchasing_hub' => [
                'label'       => 'Pembelian & Pemasok',
                'group'       => 'utama',
                'icon'        => 'cart',
                'table'       => null,
                'depends'     => ['purchase', 'suppliers'],
                'description' => 'PO pembelian bahan dan hubungan pemasok dalam satu alur pembelian.'
            ],
            'production_hub' => [
                'label'       => 'Lantai Produksi',
                'group'       => 'utama',
                'icon'        => 'factory',
                'table'       => null,
                'depends'     => ['production'],
                'description' => 'Pengelolaan Surat Perintah Kerja (SPK) dan hasil perakitan produk.'
            ],
            'production_flow' => [
                'label'       => 'Manajemen Produksi',
                'group'       => 'utama',
                'icon'        => 'factory',
                'table'       => ['jobs','job_materials','stock_transactions','production_results'],
                'depends'     => ['production','materials','inventory','finance_hub'],
                'nav_hidden'  => false,
                'description' => 'Pusat alur bahan dan hasil produksi: bahan masuk, bahan keluar ke Job, hasil jadi, retur/sisa, serta nilai produksi yang belum dibayar.'
            ],
            'shipping_hub' => [
                'label'       => 'Logistik & Ekspedisi',
                'group'       => 'utama',
                'icon'        => 'truck',
                'table'       => null,
                'depends'     => ['shipments', 'sales'],
                'description' => 'Penerbitan nomor resi dan pelacakan kurir Indonesia real-time.'
            ],
            'hr' => [
                'label'       => 'SDM & Tenaga Kerja',
                'group'       => 'utama',
                'icon'        => 'user',
                'table'       => null,
                'depends'     => ['employees', 'production'],
                'description' => 'Data karyawan, tarif borongan per job, dan penggajian payroll.'
            ],
            'finance_hub' => [
                'label'       => 'Akuntansi & Keuangan',
                'group'       => 'utama',
                'icon'        => 'bank',
                'table'       => null,
                'depends'     => ['cash', 'sales', 'finance_reports'],
                'description' => 'Pusat keuangan, laporan per periode, General Ledger, dan kontrol tutup buku.'
            ],

            // ================= PRODUK & GUDANG MATERIAL =================
            'products' => [
                'label'       => 'Master Produk & SKU',
                'group'       => 'produk',
                'icon'        => 'box',
                'table'       => 'products',
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'materials' => [
                'label'       => 'Bahan Baku Gudang',
                'group'       => 'produk',
                'icon'        => 'layers',
                'table'       => 'materials',
                'depends'     => [],
                'nav_hidden'  => true,
                'description' => 'Pencatatan stok fisik, batas minimum, dan harga beli material pabrik.'
            ],
            'stock' => [
                'label'       => 'Kartu Mutasi Stok',
                'group'       => 'produk',
                'icon'        => 'archive',
                'table'       => 'stock_transactions',
                'depends'     => ['products'],
                'nav_hidden'  => true
            ],
            'cnc_dashboard' => [
                'label'=>'Dashboard Operator CNC','group'=>'produk','icon'=>'factory','table'=>['jobs','job_assignments','cnc_gcode_library'],'depends'=>['production','products'],'nav_hidden'=>false,
                'description'=>'Workspace operator CNC: hanya Job tahap CNC yang ditugaskan, status G-code Master, spesifikasi ukuran/material/tool, dan komunikasi Job.'
            ],
            'cnc_library' => [
                'label'       => 'Database G-code CNC',
                'group'       => 'produk',
                'icon'        => 'factory',
                'table'       => 'cnc_gcode_library',
                'depends'     => ['production','products'],
                'nav_hidden'  => true,
                'description' => 'Master G-code CNC per produk/varian untuk dipilih berdasarkan Job dan diberikan manual kepada operator CNC.'
            ],
            'production' => [
                'label'       => 'Job Produksi (SPK)',
                'group'       => 'produk',
                'icon'        => 'factory',
                'table'       => 'jobs',
                'depends'     => ['products', 'materials'],
                'nav_hidden'  => true
            ],

            // ================= PEMBELIAN & VENDOR =================
            'purchase' => [
                'label'       => 'Pembelian Bahan (PO)',
                'group'       => 'pembelian',
                'icon'        => 'cart',
                'table'       => 'purchase_orders',
                'depends'     => ['suppliers', 'materials'],
                'nav_hidden'  => true
            ],
            'suppliers' => [
                'label'       => 'Pemasok (Supplier)',
                'group'       => 'pembelian',
                'icon'        => 'truck',
                'table'       => 'suppliers',
                'depends'     => [],
                'nav_hidden'  => true
            ],

            // ================= PENJUALAN & EKSPEDISI =================
            'sales' => [
                'label'       => 'Faktur Penjualan',
                'group'       => 'penjualan',
                'icon'        => 'receipt',
                'table'       => ['sales_orders', 'orders'],
                'depends'     => ['products', 'customers'],
                'nav_hidden'  => true
            ],
            'customers' => [
                'label'       => 'Data Pelanggan',
                'group'       => 'penjualan',
                'icon'        => 'users',
                'table'       => 'customers',
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'returns' => [
                'label'       => 'Penerimaan Retur Gudang',
                'group'       => 'gudang',
                'icon'        => 'rotate',
                'table'       => 'returns',
                'depends'     => ['sales'],
                'nav_hidden'  => true
            ],
            'warehouse_outbound' => [
                'label' => 'Kirim Barang Gudang', 'group'=>'gudang', 'icon'=>'truck', 'table'=>'warehouse_documents', 'depends'=>['shipments','sales'], 'nav_hidden'=>true,
                'description'=>'Serah-terima fisik barang dari Gudang kepada kurir. Satu resi satu tanda terima; status SHIPPED hanya setelah serah-terima fisik.'
            ],
            'warehouse_supplier_inbound' => [
                'label' => 'Terima Barang Supplier', 'group'=>'gudang', 'icon'=>'download', 'table'=>'goods_receipts', 'depends'=>['purchase','suppliers','materials'], 'nav_hidden'=>true,
                'description'=>'Penerimaan fisik bahan dari Supplier berdasarkan PO/data nyata. Penerimaan dan stok menggunakan Engine PK01 yang sama.'
            ],
            'warehouse_returns' => [
                'label' => 'Retur Gudang', 'group'=>'gudang', 'icon'=>'rotate', 'table'=>'returns', 'depends'=>['sales','returns'], 'nav_hidden'=>true,
                'description'=>'Pendaftaran, scan penerimaan retur, tanda terima dan QC dalam satu folder canonical Gudang/Retur.'
            ],

            'packing' => [
                'label'       => 'Packing & Pesanan Siap Packing',
                'group'       => 'penjualan',
                'icon'        => 'box',
                'table'       => 'sales_orders',
                'depends'     => ['sales', 'shipments'],
                'nav_hidden'  => false,
                'description' => 'Setiap order PAID yang siap secara stok otomatis menjadi pekerjaan packing. Tidak ada order packing yang dibuat manual terpisah dari penjualan.',
            ],
            'shipments' => [
                'label'       => 'Pengiriman & Resi',
                'group'       => 'penjualan',
                'icon'        => 'truck',
                'table'       => 'shipments',
                'depends'     => ['sales'],
                'nav_hidden'  => true
            ],
            'marketplace' => [
                'label'       => 'Rekonsiliasi Marketplace',
                'group'       => 'penjualan',
                'icon'        => 'store',
                'table'       => 'marketplace_payouts',
                'depends'     => ['cash'],
                'nav_hidden'  => true
            ],

            // ================= MITRA SELLER & AFILIASI =================
            'seller' => [
                'label'       => 'Master Mitra Seller',
                'group'       => 'utama',
                'icon'        => 'handshake',
                'table'       => ['sales_accounts', 'sellers'],
                'depends'     => [],
                'nav_hidden'  => true,
                'description' => 'Data mitra seller tetap tersedia dan dikelola dari pusat Penjualan; tidak menjadi menu sidebar terpisah.'
            ],
            'seller_affiliate' => [
                'label'       => 'Afiliasi & Komisi Seller',
                'group'       => 'penjualan',
                'icon'        => 'share',
                'table'       => 'affiliate_links',
                'depends'     => ['seller'],
                'nav_hidden'  => true
            ],
            'seller_portal' => [
                'label'       => 'Portal Mandiri Seller',
                'group'       => 'penjualan',
                'icon'        => 'user',
                'table'       => ['sales_accounts', 'sellers'],
                'depends'     => ['seller'],
                'nav_hidden'  => true
            ],

            // ================= SDM & TENAGA KERJA =================
            'employees' => [
                'label'       => 'Data Karyawan & Upah',
                'group'       => 'sdm',
                'icon'        => 'user',
                'table'       => 'employees',
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'job_karyawan' => [
                'label'       => 'Pekerjaan Saya',
                'group'       => 'sdm',
                'icon'        => 'clipboard',
                'table'       => 'job_assignments',
                'depends'     => ['production', 'employees'],
                'nav_hidden'  => true
            ],
            'job_wages' => [
                'label' => 'Upah Pekerjaan / Job', 'group' => 'sdm', 'icon' => 'receipt',
                'table' => 'job_wages', 'depends' => ['jobs','employees'], 'nav_hidden' => true,
                'description' => 'Upah borongan/pekerjaan yang dihitung dari Job Produksi, terpisah dari gaji bulanan.'
            ],
            'payroll' => [
                'label'       => 'Gaji & Payroll',
                'group'       => 'sdm',
                'icon'        => 'wallet',
                'table'       => 'payroll',
                'depends'     => ['employees', 'cash'],
                'nav_hidden'  => true
            ],

            // ================= KEUANGAN & PERBENDAHARAAN =================
            'cash' => [
                'label'       => 'Buku Kas Perusahaan',
                'group'       => 'keuangan',
                'icon'        => 'bank',
                'table'       => 'cash_ledger',
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'operational_costs' => [
                'label'       => 'Biaya Usaha Operasional',
                'group'       => 'keuangan',
                'icon'        => 'coins',
                'table'       => 'operational_costs',
                'depends'     => ['cash'],
                'nav_hidden'  => true
            ],
            'finance_reports' => [
                'label' => 'Laporan Keuangan per Periode', 'group' => 'keuangan', 'icon' => 'chart',
                'table' => ['financial_periods','journal_entries','journal_lines'], 'depends' => ['finance'], 'nav_hidden' => false,
                'description' => 'Laporan per periode, General Ledger, neraca saldo, dan status tutup buku dari transaksi nyata PK01.'
            ],
            'general_ledger' => [
                'label' => 'General Ledger', 'group' => 'keuangan', 'icon' => 'book',
                'table' => ['journal_entries','journal_lines'], 'depends' => ['finance_reports'], 'nav_hidden' => true
            ],
            'job_role_engine' => [
                'label' => 'Peran Pekerjaan & Penugasan AI', 'group' => 'sdm', 'icon' => 'users',
                'table' => ['job_role_catalog','employee_job_roles','job_assignments'], 'depends' => ['employees','production'], 'nav_hidden' => true
            ],
            'finance' => [
                'label'       => 'Laporan Laba Rugi Riil',
                'group'       => 'keuangan',
                'icon'        => 'chart',
                'table'       => null,
                'depends'     => ['cash', 'sales'],
                'nav_hidden'  => true
            ],
            'capital' => [
                'label'       => 'Modal Usaha',
                'group'       => 'keuangan',
                'icon'        => 'capital',
                'table'       => 'capital_transactions',
                'depends'     => ['cash'],
                'nav_hidden'  => true
            ],
            'capital_owners' => [
                'label' => 'Modal & Pemilik', 'group' => 'keuangan', 'icon' => 'capital',
                'table' => ['capital_transactions','company_owners','owner_transactions','profit_distributions'], 'depends' => ['cash'], 'nav_hidden' => true
            ],
            'assets_inventory' => [
                'label' => 'Aset & Belanja Investasi', 'group' => 'keuangan', 'icon' => 'capital',
                'table' => 'fixed_assets', 'depends' => ['cash'], 'nav_hidden' => false,
                'description' => 'Pencatatan pembelian aset dan penyusutan tahunan per aset.'
            ],
            'inventory_input' => [
                'label' => 'Input Inventori & Aset', 'group' => 'produk', 'icon' => 'box',
                'table' => ['stock_adjustments','fixed_assets'], 'depends' => ['materials'], 'nav_hidden' => true
            ],
            'inventory_valuation' => [
                'label' => 'Penilaian Persediaan', 'group' => 'produk', 'icon' => 'chart',
                'table' => 'inventory_valuation_adjustments', 'depends' => ['materials'], 'nav_hidden' => true
            ],
            'profit_sharing' => [
                'label' => 'Bagi Hasil Pemilik', 'group' => 'keuangan', 'icon' => 'coins',
                'table' => ['company_owners','profit_distributions','profit_distribution_items','owner_transactions'], 'depends' => ['finance','cash'], 'nav_hidden' => true
            ],
            'pricing' => [
                'label'       => 'Penetapan Harga Jual',
                'group'       => 'keuangan',
                'icon'        => 'tag',
                'table'       => ['pricing', 'product_prices'],
                'depends'     => ['products'],
                'nav_hidden'  => true
            ],
            'closing' => [
                'label'       => 'Tutup Buku Periode',
                'group'       => 'keuangan',
                'icon'        => 'lock',
                'table'       => 'closings',
                'depends'     => ['cash', 'sales'],
                'nav_hidden'  => true
            ],

            // ================= KECERDASAN BUATAN (AI) =================
            'ai_center' => [
                'label'       => 'AI Control Center',
                'group'       => 'ai',
                'icon'        => 'spark',
                'table'       => ['ai_logs'],
                'depends'     => ['ai_assistant','dashboard'],
            ],
            'ai_assistant' => [
                'label'       => 'Asisten AI PK01',
                'group'       => 'ai',
                'icon'        => 'spark',
                'table'       => ['ai_logs', 'ai_conversations'],
                'depends'     => ['dashboard']
            ],

            // ================= SISTEM, AUDIT & CADANGAN =================
            'logs' => [
                'label'       => 'Audit Trail Aktivitas',
                'group'       => 'sistem',
                'icon'        => 'activity',
                'table'       => ['activity_logs', 'logs'],
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'backup' => [
                'label'       => 'Cadangan Database (Backup)',
                'group'       => 'sistem',
                'icon'        => 'shield',
                'table'       => null,
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'system' => [
                'label'       => 'Pengaturan Sentral',
                'group'       => 'sistem',
                'icon'        => 'settings',
                'table'       => null,
                'depends'     => []
            ],

            // ================= MODUL PUBLIK / EKSTERNAL =================
            'tracking_public' => [
                'label'       => 'Lacak Resi Publik',
                'group'       => 'eksternal',
                'icon'        => 'search',
                'table'       => 'shipments',
                'depends'     => [],
                'nav_hidden'  => true
            ],
            'seller_register' => [
                'label'       => 'Pendaftaran Seller',
                'group'       => 'eksternal',
                'icon'        => 'user-plus',
                'table'       => ['sales_accounts', 'sellers'],
                'depends'     => [],
                'nav_hidden'  => true
            ]
        ];
    }

    public static function get($key) {
        $all = self::all();
        return $all[$key] ?? null;
    }

    public static function view_keys() {
        return array_keys(self::all());
    }

    /**
     * Dapatkan Prefix Tabel Database dengan Aman (Anti-Null WPDB)
     */
    /**
     * Canonical physical view location for every UI module.
     * Role folders are the source of truth; each module contains one canonical original UI file.
     */
    public static function view_path($key) {
        $map = [
            'dashboard' => 'modules/admin/dashboard-role/tampilan-dashboard-role.php',
            'administration' => 'modules/admin/administration/tampilan-administrasi.php',
            'security' => 'modules/security/dashboard/tampilan-security.php',
            'customer_service' => 'modules/customer-service/dashboard/tampilan-customer-service.php',
            'communications' => 'modules/production/core/tampilan-komunikasi-operasional.php',
            'owner_dashboard' => 'modules/owner/dashboard-owner/tampilan-dashboard-owner.php',
            'master_data' => 'modules/admin/master-data/tampilan-master-data.php',
            'users' => 'modules/admin/users/tampilan-pengguna.php',
            'documents' => 'modules/admin/documents/tampilan-dokumen.php',
            'logs' => 'modules/admin/activity/tampilan-aktivitas.php',
            'system' => 'modules/admin/settings/tampilan-pengaturan.php',
            'cash' => 'modules/finance/cash/tampilan-kas.php',
            'finance' => 'modules/finance/overview/tampilan-keuangan.php',
            'finance_reports' => 'modules/finance/reports/tampilan-laporan-keuangan.php',
            'closing' => 'modules/finance/closing/tampilan-tutup-periode.php',
            'operational_costs' => 'modules/finance/operational-costs/tampilan-biaya-usaha.php',
            'capital' => 'modules/finance/capital/tampilan-modal.php',
            'capital_owners' => 'modules/owner/capital/tampilan-modal-pemilik.php',
            'profit_sharing' => 'modules/owner/capital/tampilan-modal-pemilik.php',
            'products' => 'modules/inventory/products/tampilan-produk.php',
            'materials' => 'modules/inventory/materials/tampilan-bahan.php',
            'stock' => 'modules/inventory/stock/tampilan-stok.php',
            'inventory_input' => 'modules/inventory/management/tampilan-inventory-management.php',
            'inventory_valuation' => 'modules/inventory/management/tampilan-inventory-management.php',
            'assets_inventory' => 'modules/inventory/assets/tampilan-aset-inventory.php',
            'warehouse' => 'modules/warehouse/dashboard/tampilan-gudang.php',
            'warehouse_outbound' => 'modules/warehouse/outbound/tampilan-kirim-barang.php',
            'warehouse_supplier_inbound' => 'modules/warehouse/inbound-supplier/tampilan-terima-supplier.php',
            'purchase' => 'modules/purchasing/purchase-orders/tampilan-pembelian.php',
            'suppliers' => 'modules/purchasing/suppliers/tampilan-pemasok.php',
            'sales' => 'modules/sales/cashier/tampilan-penjualan.php',
            'customers' => 'modules/sales/customers/tampilan-pelanggan.php',
            'returns' => 'modules/warehouse/returns/tampilan-retur.php',
            'warehouse_returns' => 'modules/warehouse/returns/tampilan-retur.php',
            'pricing' => 'modules/sales/pricing/tampilan-harga-jual.php',
            'seller' => 'modules/seller/management/tampilan-penjual.php',
            'seller_portal' => 'modules/seller/portal/tampilan-portal-penjual.php',
            'seller_register' => 'modules/seller/register/tampilan-daftar-seller.php',
            'production' => 'modules/production/jobs/tampilan-produksi.php',
            'cnc_dashboard' => 'modules/production/cnc-library/tampilan-dashboard-cnc.php',
            'job_karyawan' => 'modules/production/employee-jobs/tampilan-penerimaan-job-karyawan.php',
            'job_wages' => 'modules/production/job-wages/tampilan-upah-job.php',
            'attendance' => 'modules/hr/attendance/tampilan-absensi.php',
            'employees' => 'modules/hr/employees/tampilan-karyawan.php',
            'payroll' => 'modules/hr/payroll/tampilan-gaji.php',
            'shipments' => 'modules/logistics/shipping/tampilan-pengiriman.php',
            'packing' => 'modules/logistics/packing/tampilan-packing.php',
            'tracking_public' => 'modules/logistics/tracking/tampilan-lacak-resi.php',
            'marketplace' => 'modules/marketplace/reconciliation/tampilan-marketplace.php',
            'ai_assistant' => 'modules/ai/assistant/tampilan-asisten-ai.php',
            'ai_center' => 'modules/ai/center/tampilan-ai-center.php',
        ];
        $relative = $map[$key] ?? '';
        if (!$relative) return '';
        $path = trailingslashit(PK01_DIR) . 'includes/' . ltrim($relative, '/');
        return is_readable($path) ? $path : '';
    }

    private static function get_table_prefix() {
        global $wpdb;
        if (isset($wpdb->prefix) && is_string($wpdb->prefix) && $wpdb->prefix !== '') {
            return $wpdb->prefix;
        }
        return 'wp_';
    }

    /**
     * Cache Daftar Seluruh Tabel Database Sekali Jalan (Aman & Super Cepat)
     */
    private static function load_tables_cache() {
        if (self::$table_cache === null) {
            global $wpdb;
            if (!isset($wpdb) || !is_object($wpdb) || !method_exists($wpdb, 'get_col')) {
                return [];
            }
            $raw_tables = $wpdb->get_col("SHOW TABLES") ?: [];
            // Normalisasi huruf kecil untuk kompatibilitas server Linux Hostinger
            self::$table_cache = array_map('strtolower', (array)$raw_tables);
        }
        return self::$table_cache;
    }

    /**
     * Reset Cache Jika Diperlukan
     */
    public static function reset_cache() {
        self::$table_cache = null;
    }

    /**
     * 2. CEK KETERSEDIAAN FISIK MODUL DI SERVER (BEBAS EROR)
     * Menggunakan pengecekan tabel aman dan multi-fallback resolver.
     */
    public static function is_available($key) {
        $key = sanitize_key((string)$key);

        // Hub virtual selalu siap
        $virtual_hubs = [
            'dashboard', 'customer_service', 'administration', 'security', 'system', 'master_data', 'inventory', 'purchasing',
            'sales_hub', 'production_hub', 'shipping_hub', 'hr', 'finance_hub',
            'finance', 'backup'
        ];
        if (in_array($key, $virtual_hubs, true)) return true;

        $m = self::get($key);
        if (!$m) return false;

        // Modul tanpa tabel database wajib dianggap siap
        if (empty($m['table'])) return true;

        $existing_tables = self::load_tables_cache();
        $target_tables = (array)$m['table'];
        $prefix = self::get_table_prefix();

        // Cek apakah salah satu tabel kandidat tersedia di database
        foreach ($target_tables as $t_candidate) {
            $t_candidate = sanitize_key((string)$t_candidate);
            $full_table_name = '';

            // 1. Coba melalui PK01_DB jika ada dan menghasilkan nama tabel
            if (class_exists('PK01_DB') && method_exists('PK01_DB', 't')) {
                $full_table_name = PK01_DB::t($t_candidate);
            }

            // 2. Jika kosong, buat nama tabel secara manual dengan prefix yang aman
            if (empty($full_table_name)) {
                $full_table_name = $prefix . 'pk01_' . $t_candidate;
            }

            // 3. Cocokkan dengan daftar tabel (Case-Insensitive)
            if (in_array(strtolower($full_table_name), $existing_tables, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 3. VALIDASI RANTAI DEPENDENSI ANTAR-MODUL
     */
    public static function dependencies_ok($key) {
        $m = self::get($key);
        if (!$m) return false;

        foreach ($m['depends'] as $dep_key) {
            if (!self::is_available($dep_key)) {
                return false;
            }
        }

        return true;
    }

    /**
     * 4. DIAGNOSTIK KESEHATAN MENYELURUH (1 KUERI DATABASE RINGAN)
     */
    public static function health() {
        self::load_tables_cache(); // Cache seluruh tabel dalam 1 kueri
        $report = [];

        foreach (self::all() as $key => $mod) {
            $is_avail = self::is_available($key);
            $dep_status = [];

            foreach ($mod['depends'] as $dep) {
                $dep_status[$dep] = self::is_available($dep);
            }

            $is_ready = $is_avail && !in_array(false, $dep_status, true);

            $report[$key] = [
                'label'        => $mod['label'],
                'group'        => $mod['group'] ?? 'umum',
                'available'    => $is_avail,
                'dependencies' => $dep_status,
                'ready'        => $is_ready
            ];
        }

        return $report;
    }

    /**
     * 5. GENERATOR NAVIGASI DINAMIS BERBASIS HAK AKSES PERAN
     */
    public static function get_authorized_menu($role = '') {
        $menu_tree = [];

        foreach (self::all() as $key => $item) {
            // Lewati modul tersembunyi
            if (!empty($item['nav_hidden'])) continue;

            // Validasi Otorisasi jika pengguna login
            if (class_exists('PK01_Authorization') && method_exists('PK01_Authorization', 'can')) {
                if (!PK01_Authorization::can($key)) continue;
            }

            // Validasi Ketersediaan Fisik di Database
            if (!self::is_available($key)) continue;

            $grp = $item['group'] ?? 'lainnya';
            $menu_tree[$grp][$key] = $item;
        }

        return $menu_tree;
    }
}

// Inisialisasi Registry Modul PK01
