<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Canonical Data Contract.
 * Semua modul yang perlu menghubungkan produk/SKU harus memakai master PK01,
 * bukan membuat katalog lokal. Helper ini read-only dan tidak membuat data.
 */
class PK01_Master_Contract {
    public static function product_table(){ return class_exists('PK01_DB') ? PK01_DB::t('products') : ''; }
    public static function variant_table(){ return class_exists('PK01_DB') ? PK01_DB::t('product_variants') : ''; }

    public static function variant_by_sku($sku){
        global $wpdb; $sku=sanitize_text_field($sku); if($sku==='') return null;
        $t=self::variant_table(); $pt=self::product_table(); if(!$t||!$pt) return null;
        return $wpdb->get_row($wpdb->prepare("SELECT v.*,p.code AS product_code,p.name AS product_name,p.status AS product_status,p.cnc_required,p.prema_required FROM `{$t}` v INNER JOIN `{$pt}` p ON p.id=v.product_id WHERE v.sku=%s LIMIT 1",$sku),ARRAY_A);
    }
    public static function variant($id){
        global $wpdb; $id=absint($id); if(!$id) return null; $t=self::variant_table();$pt=self::product_table();if(!$t||!$pt)return null;
        return $wpdb->get_row($wpdb->prepare("SELECT v.*,p.code AS product_code,p.name AS product_name,p.status AS product_status,p.cnc_required,p.prema_required FROM `{$t}` v INNER JOIN `{$pt}` p ON p.id=v.product_id WHERE v.id=%d LIMIT 1",$id),ARRAY_A);
    }
    public static function assert_variant_product($variant_id,$product_id){
        $v=self::variant($variant_id); if(!$v || (int)$v['product_id']!==absint($product_id)) throw new Exception('SKU/Variant tidak terhubung dengan Product Master yang dipilih.');
        return $v;
    }
    public static function product_routing($variant_id){
        $v=self::variant($variant_id); if(!$v) return [];
        return ['cnc'=>!empty($v['cnc_required']),'prema'=>!empty($v['prema_required']),'product_id'=>(int)$v['product_id'],'variant_id'=>(int)$v['id'],'sku'=>(string)$v['sku']];
    }
    public static function source_health(){
        global $wpdb; $pt=self::product_table();$vt=self::variant_table();
        return ['product_master'=>($pt && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$pt))===$pt),'variant_master'=>($vt && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$vt))===$vt),'commerce_service'=>class_exists('PK01_Ecommerce'),'marketplace_adapter'=>class_exists('PK01_Marketplace_Catalog'),'source_of_truth'=>'PK01 Product Master / Product Variant'];
    }
}
