<?php
if (!defined('ABSPATH')) exit;

class PK01_Shortcodes {

    public static function init() {
        $tags = [
            'pk01_operasional'       => 'app',
            'pk01_dashboard'         => 'app',
            'pk01_cash'              => 'cash',
            'pk01_finance'           => 'finance',
            'pk01_products'          => 'products',
            'pk01_materials'         => 'materials',
            'pk01_bahan'             => 'materials',
            'pk01_stock'             => 'stock',
            'pk01_sales'             => 'sales',
            'pk01_customers'         => 'customers',
            'pk01_production'        => 'production',
            'pk01_jobs'              => 'production',
            'pk01_purchase'          => 'purchase',
            'pk01_seller'            => 'seller',
            'pk01_seller_portal'     => 'seller_portal',
            'pk01_seller_affiliate'  => 'seller_affiliate',
            'pk01_returns'           => 'returns',
            'pk01_operational_costs' => 'operational_costs',
            'pk01_payroll'           => 'payroll',
            'pk01_job_wages'         => 'job_wages',
            'pk01_assets_inventory'  => 'assets_inventory',
            'pk01_closing'           => 'closing',
            /* Nama teknis (kompatibilitas lama) */
            'pk01_marketplace'       => 'marketplace',
            'pk01_employees'         => 'employees',
            'pk01_pricing'           => 'pricing',
            'pk01_capital'           => 'capital',
            'pk01_logs'              => 'logs',
            'pk01_system'            => 'system',
            'pk01_data_control'      => 'data_control',
            'pk01_users'             => 'users',
            'pk01_documents'         => 'documents',

            /* Nama Bahasa Indonesia — lebih mudah dipahami saat mengembangkan PK01 */
            'pk01_penjualan_marketplace' => 'marketplace',
            'pk01_karyawan'             => 'employees',
            'pk01_penerimaan_job_karyawan' => 'job_karyawan',
            'pk01_harga_jual'            => 'pricing',
            'pk01_modal_usaha'           => 'capital',
            'pk01_upah_job'              => 'job_wages',
            'pk01_aset_inventory'        => 'assets_inventory',
            'pk01_aktivitas'             => 'logs',
            'pk01_pengaturan_sistem'     => 'system',
            'pk01_pemasok'              => 'suppliers',
            'pk01_pengiriman'           => 'shipments',
            'pk01_job_karyawan'         => 'job_karyawan',
            'pk01_asisten_ai'           => 'ai_assistant',
            'pk01_ai_control_center'    => 'ai_center',
            'pk01_daftar_seller'         => 'seller_register',
            'pk01_lacak_resi'           => 'tracking_public',
            'pk01_login'                => 'login',
            'pk01_customer_service'    => 'customer_service',
            'pk01_komunikasi' => 'communications',
            'pk01_dashboard_cnc' => 'cnc_dashboard',
            'pk01_administration'      => 'administration',
            'pk01_security'            => 'security'
        ];
        foreach ($tags as $tag => $method) {
            if (method_exists(__CLASS__, $method)) add_shortcode($tag, [__CLASS__, $method]);
        }
    }

    public static function frontend_url_public($view = 'dashboard') {
        $raw_view = sanitize_key($view ?: 'dashboard');
        if (in_array($raw_view, ['attendance','leave','cuti'], true) && class_exists('PK01_DB')) {
            PK01_DB::ensure_pages();
            $attendance_id = (int) get_option('pk01_attendance_page_id', 0);
            if ($attendance_id && get_post_status($attendance_id) === 'publish') {
                return add_query_arg('pk01_view', 'attendance', get_permalink($attendance_id));
            }
        }
        // URL alias harus menunjuk ke renderer nyata, bukan ke view yang tidak mempunyai method.
        $aliases = [
            'orders'=>'sales_hub','order'=>'sales_hub','sellers'=>'seller',
            'cost'=>'operational_costs','costs'=>'operational_costs',
            'purchase'=>'purchasing_hub','purchases'=>'purchasing_hub',
            'shipping'=>'shipping_hub','shipments_list'=>'shipping_hub','pack'=>'packing','packer'=>'packing','warehouse_returns'=>'warehouse','warehouse_outbound'=>'warehouse','warehouse_supplier_inbound'=>'warehouse',
            'stock'=>'inventory','finance'=>'finance_hub','production'=>'production_hub', 'cnc_library'=>'production_hub','cnc'=>'cnc_dashboard','communication'=>'communications','chat'=>'communications','production_management'=>'production_flow','production_flow'=>'production_flow'
        ];
        $view = $aliases[$view] ?? $view;

        // Dashboard lama tetap menjadi fallback kompatibilitas; portal baru adalah landing utama.
        if (class_exists('PK01_DB') && method_exists('PK01_DB', 'portal_url')) {
            $portal = PK01_DB::portal_url($view);
            if (!empty($portal)) return $portal;
        }
        $id = (int)get_option('pk01_dashboard_page_id', 0);
        $url = ($id && get_post_status($id) === 'publish') ? get_permalink($id) : '';
        // Jangan fallback ke homepage WordPress. Pulihkan halaman dashboard PK01.
        if (!$url || untrailingslashit((string)wp_parse_url($url, PHP_URL_PATH)) === '') {
            if (class_exists('PK01_DB') && method_exists('PK01_DB', 'ensure_pages')) {
                $id = (int)PK01_DB::ensure_pages();
                if ($id && get_post_status($id) === 'publish') $url = get_permalink($id);
            }
        }
        if (!$url) $url = home_url('/dashboard-operasional/');
        return add_query_arg('pk01_view', $view, $url);
    }

    public static function app() {
        $view = sanitize_key($_GET['pk01_view'] ?? 'dashboard');
        $legacy_tab = sanitize_key($_GET['pk01_tab'] ?? '');
        // Retur fisik adalah domain Gudang. Jika ada URL lama dari Penjualan/Pengiriman
        // yang masih membuka tab retur, arahkan renderer ke modul Gudang tanpa membuat
        // salinan proses retur di Kasir/Logistik.
        if (in_array($view, ['sales_hub','shipping_hub'], true) && $legacy_tab === 'returns') {
            $view = 'returns';
        }
        if ($view === 'returns' && class_exists('PK01_Authorization') && PK01_Authorization::effective_role() === 'pk01_kasir') { $view = 'inventory'; }
        // Alias navigasi ramah pengguna harus diarahkan ke renderer/hub yang benar.
        // Sebelumnya `orders` tidak memiliki renderer sendiri sehingga link quick-action
        // dapat kembali ke dashboard tanpa pernah membuka daftar pesanan.
        $view_aliases = [
            'orders'=>'sales_hub', 'order'=>'sales_hub',
            'sellers'=>'seller', 'seller_list'=>'seller',
            'cost'=>'operational_costs', 'costs'=>'operational_costs',
            'purchase'=>'purchasing_hub', 'purchases'=>'purchasing_hub',
            'shipping'=>'shipping_hub', 'shipments_list'=>'shipping_hub',
            'stock'=>'inventory', 'products_list'=>'inventory',
            'finance'=>'finance_hub', 'production'=>'production_hub', 'attendance'=>'attendance','leave'=>'attendance','cuti'=>'attendance', 'cnc_library'=>'production_hub', 'cnc'=>'cnc_dashboard','chat'=>'communications','communication'=>'communications',
        ];
        if (isset($view_aliases[$view])) $view = $view_aliases[$view];

        // Seller nyata dan preview Seller harus selalu masuk ke workspace dashboard.
        // Modul `seller` adalah pusat manajemen Seller untuk Admin, bukan halaman kerja Seller.
        if ($view === 'seller' && class_exists('PK01_Authorization') && PK01_Authorization::effective_role() === 'pk01_seller') {
            $view = 'dashboard';
        }

        // Administrator role preview harus menampilkan dashboard internal role yang
        // dipreview. Portal seller adalah halaman publik berbasis token, bukan layar
        // preview admin. Mencegah preview seller jatuh ke "Tautan Mitra Tidak Valid".
        if ($view === 'seller_portal' && class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview()) {
            $view = 'dashboard';
        }

        if ($view === 'seller_portal') return self::seller_portal();
        if ($view === 'seller_affiliate') return self::seller_affiliate();
        if ($view === 'seller_register') return self::seller_register();
        if ($view === 'tracking_public') return self::tracking_public();
        if ($view === 'customer_service') return self::customer_service();
        if ($view === 'security') return self::security();

        if (!is_user_logged_in()) {
            return '<div class="pk01-op-card" style="max-width:480px;margin:60px auto;text-align:center;"><h2>Login Diperlukan</h2><p>Silakan login terlebih dahulu untuk membuka sistem operasional.</p><a class="pk01-op-button" href="' . esc_url(class_exists('PK01_Login') ? PK01_Login::url(self::frontend_url_public($view)) : wp_login_url(self::frontend_url_public($view))) . '">Masuk Sekarang</a></div>';
        }

        $all = PK01_Module_Registry::all();
        $title = $all[$view]['label'] ?? 'Operasional';
        $preview_role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
        $preview_role_label = class_exists('PK01_Engine') ? PK01_Engine::role_label($preview_role) : $preview_role;
        $preview_mode = class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview();
        // Pusat Pratinjau adalah QA tampilan saja. Jangan izinkan POST mutasi bahkan
        // jika view lama memiliki pemeriksaan capability Administrator.
        if ($preview_mode && $_SERVER['REQUEST_METHOD'] === 'POST') {
            return '<div class="pk01-op-card pk01-readonly-preview-block" style="max-width:680px;margin:40px auto;text-align:center"><h2>Pratinjau Hanya untuk Melihat</h2><p>Administrator sedang memeriksa dashboard. Perubahan data, transaksi, dan aksi mutasi dinonaktifkan pada mode pratinjau.</p><a class="pk01-op-button" href="'.esc_url(remove_query_arg('pk01_role_preview')).'">Kembali ke Dashboard Administrator</a></div>';
        }
        if (class_exists('PK01_Authorization') && !PK01_Authorization::can($view)) {
            return '<div class="pk01-op-card" style="max-width:680px;margin:60px auto;text-align:center;"><h2>Akses terbatas</h2><p>Role Anda belum diberi akses ke menu ini. Hubungi admin usaha.</p><a class="pk01-op-button" href="'.esc_url(self::frontend_url_public('dashboard')).'">Kembali ke Dashboard</a></div>';
        }

        // Audit akses menu nyata per pengguna. Ini hanya mencatat kunjungan modul, bukan membuat data bisnis baru.
        if (class_exists('PK01_Audit') && get_current_user_id() > 0) {
            PK01_Audit::info('module_view', $view, 'Pengguna membuka modul ' . $title, 'user', (string)get_current_user_id());
        }

        // ATURAN UI BARU: hanya Dashboard Administrator ASLI yang memakai sidebar.
        // Semua dashboard pekerjaan (Kasir, Seller, Gudang, Produksi, Keuangan,
        // Pekerja, Logistik, dll.) memakai satu layar penuh dengan menu tindakan
        // yang relevan di dalam dashboard. Mode preview Administrator diperlakukan
        // seperti role yang sedang dilihat, sehingga preview tidak memunculkan
        // sidebar Administrator maupun sidebar role lain.
        $show_sidebar = (self::effective_admin_dashboard_role() === 'administrator' && !$preview_mode);

        ob_start(); ?>
        <div class="pk01-op-app <?php echo $show_sidebar ? 'pk01-has-sidebar' : 'pk01-no-sidebar'; ?><?php echo $preview_mode ? ' pk01-readonly-preview' : ''; ?>" data-sidebar="<?php echo esc_attr($preview_mode ? $preview_role : ($show_sidebar ? 'administrator' : 'user')); ?>" data-pk01-readonly-preview="<?php echo $preview_mode ? '1' : '0'; ?>">
            <?php if ($preview_mode): ?>
            <style>
                .pk01-readonly-preview form button[type=submit],
                .pk01-readonly-preview form input[type=submit],
                .pk01-readonly-preview form input[type=button],
                .pk01-readonly-preview form select,
                .pk01-readonly-preview form textarea,
                .pk01-readonly-preview form input:not([type=hidden]):not([type=search]):not([type=submit]):not([type=button]) { opacity:.72; }
                .pk01-readonly-preview form { position:relative; }
                .pk01-readonly-preview .pk01-preview-mutation-note { display:block!important; }
            </style>
            <script>document.addEventListener('DOMContentLoaded',function(){var root=document.querySelector('.pk01-readonly-preview');if(!root)return;root.addEventListener('submit',function(e){e.preventDefault();e.stopPropagation();alert('Mode Pratinjau Administrator: perubahan data dinonaktifkan.');},true);root.addEventListener('click',function(e){var b=e.target.closest('button,[type=submit],[data-mutating]');if(b && !b.closest('a')){e.preventDefault();e.stopPropagation();alert('Mode Pratinjau Administrator: aksi perubahan dinonaktifkan.');}},true);});</script>
            <?php endif; ?>
            <?php if ($show_sidebar): ?>
            <div class="pk01-mobile-top">
                <button type="button" class="pk01-menu-toggle" aria-expanded="false">☰ <span>Menu</span></button>
                <strong>PK01 Business OS</strong>
            </div>
            <?php endif; ?>
            <div class="pk01-op-layout">
                <?php if ($show_sidebar) echo self::nav(); ?>
                <section class="pk01-op-workspace">
                    <header class="pk01-op-topbar">
                        <div><?php if($preview_mode): ?><span class="pk01-preview-banner">Lihat Dashboard Berdasarkan Peran: <?php echo esc_html($preview_role_label); ?></span><?php endif; ?>
                            <span class="pk01-op-eyebrow">ENTERPRISE SYSTEM</span>
                            <strong><?php echo esc_html($title); ?></strong>
                        </div>
                        <div class="pk01-top-status">
                            <?php if (!$show_sidebar): ?>
                                <a href="<?php echo esc_url(self::frontend_url_public('dashboard')); ?>" class="pk01-top-chat" title="Kembali ke Beranda">⌂ Beranda</a>
                                <a href="<?php echo esc_url(wp_logout_url(self::frontend_url_public('dashboard'))); ?>" class="pk01-top-chat pk01-top-logout" title="Keluar dari akun">↪ Keluar</a>
                            <?php endif; ?>
                            <a href="<?php echo esc_url(self::frontend_url_public('communications')); ?>" class="pk01-top-chat" title="Komunikasi Operasional">💬 Chat</a> <a href="<?php echo esc_url(self::frontend_url_public('ai_assistant')); ?>" class="pk01-top-chat" title="Asisten AI">✨ AI</a> <i></i> Terhubung ke Database PK01
                        </div>
                    </header>
                    <main class="pk01-op-main">
                        <?php
                        if (method_exists(__CLASS__, $view)) {
                            echo call_user_func([__CLASS__, $view]);
                        } else {
                            echo self::dashboard();
                        }
                        ?>
                    </main>
                </section>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function nav_icon($name) {
        $icons = [
            'home'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10.8 12 3l9 7.8v8.7a1.5 1.5 0 0 1-1.5 1.5h-5.2v-6h-4.6v6H4.5A1.5 1.5 0 0 1 3 19.5z"/><path d="M8 21v-6.1h8V21"/></svg>',
            'box'       => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m4.5 7.8 7.5 4.3 7.5-4.3M12 12.1V21"/></svg>',
            'factory'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21V10l6 3V9l6 3V7l6 3v11z"/><path d="M7 17h2m2 0h2m2 0h2M7 20h2m2 0h2m2 0h2"/></svg>',
            'layers'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/></svg>',
            'cart'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.1 10.1a2 2 0 0 0 2 1.6h7.8a2 2 0 0 0 1.9-1.4L20 8H6"/><circle cx="10" cy="20" r="1.2"/><circle cx="18" cy="20" r="1.2"/></svg>',
            'truck'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z"/><circle cx="7" cy="19" r="1.5"/><circle cx="18" cy="19" r="1.5"/></svg>',
            'receipt'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12v18l-3-1.7L12 21l-3-1.7L6 21z"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>',
            'users'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0M16 6.5a2.5 2.5 0 0 1 0 5M16 15a5 5 0 0 1 4.5 5"/></svg>',
            'handshake' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 11 4-4h4l2 2 2-2h3l4 4-3 3-2-2-4 4-2-2-2 2-3-3z"/><path d="m8 7 3 3m5-3-3 3"/></svg>',
            'user-plus' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0M18 8v6m-3-3h6"/></svg>',
            'user'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.2"/><path d="M5 21a7 7 0 0 1 14 0"/></svg>',
            'rotate'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.2 9a7 7 0 0 1 12.2-2M17.8 15a7 7 0 0 1-12.2 2"/></svg>',
            'store'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10v10h16V10M3 10l2-6h14l2 6M8 20v-6h8v6"/><path d="M3 10a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/></svg>',
            'wallet'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h15a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6z"/><path d="M2 8V6a2 2 0 0 1 2-2h12M16 13h5"/><circle cx="16" cy="13" r="1"/></svg>',
            'coins'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="4"/><path d="M13 10a4 4 0 1 0 1 6M9 6v4m-2-2h4M14 18h7"/></svg>',
            'bank'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 9 9-5 9 5M4 9h16M6 10v8m4-8v8m4-8v8m4-8v8M3 20h18"/></svg>',
            'chart'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 19V5M4 19h17"/><path d="m7 15 3-4 3 2 5-7"/></svg>',            'book'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22z"/><path d="M4 5.5v14M8 7h8M8 11h8M8 15h6"/></svg>',

            'capital'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M14.5 8.5c-.7-.6-1.6-.9-2.6-.9-1.7 0-3 .8-3 2 0 3.1 6.1 1.3 6.1 4.3 0 1.3-1.2 2.2-3.1 2.2-1.1 0-2.2-.4-3-1.1M12 6v12"/></svg>',
            'tag'       => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5v6l10 10 8-8L11 3H5a2 2 0 0 0-2 2z"/><circle cx="7" cy="7" r="1.2"/></svg>',
            'lock'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></svg>',
            'spark'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5zM19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7z"/></svg>',
            'activity'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12h4l2-6 4 12 2-6h6"/></svg>',
            'message'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v11H8l-4 4z"/><path d="M8 9h8M8 12h5"/></svg>',
            'settings'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"/><path d="M4.9 5.1 7 7.2M17 7l2.1-2.1M4.9 18.9 7 16.8M17 17l2.1 2.1M3 12H1m22 0h-2M12 3V1m0 22v-2"/></svg>',
        ];
        return $icons[$name] ?? $icons['box'];
    }

    /**
     * Menentukan apakah pengguna sedang berada pada dashboard Administrator.
     * Hanya Administrator WordPress yang memakai sidebar legacy.
     */
    private static function effective_admin_dashboard_role() {
        if (!is_user_logged_in()) return '';
        $role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
        return sanitize_key($role);
    }

    private static function nav() {
        $reg = PK01_Module_Registry::all();
        $current = sanitize_key($_GET['pk01_view'] ?? 'dashboard');
        $role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : 'administrator';
        $role_label = class_exists('PK01_Engine') ? PK01_Engine::role_label($role) : ucfirst(str_replace('_',' ', $role));

        // Menu dashboard/Hub yang benar-benar terlihat per pekerjaan.
        $allowed = class_exists('PK01_Authorization')
            ? PK01_Authorization::role_navigation()
            : ['dashboard','sales_hub','inventory','production_hub','purchasing_hub','shipping_hub','hr','finance_hub','seller','ai_assistant','system'];

        $o = '<aside class="pk01-op-sidebar" data-role="' . esc_attr($role) . '">';
        $o .= '<div class="pk01-side-brand"><div class="pk01-brand-mark">PK</div><div><span>BUSINESS OPERATING SYSTEM</span><strong>PK01 Operasional</strong></div></div>';
        $o .= '<div class="pk01-side-role"><span class="pk01-side-role-dot"></span><div><small>AKUN AKTIF</small><strong>' . esc_html($role_label) . '</strong></div></div>';
        $o .= '<div class="pk01-side-scroll">';
        $last_group = '';
        $show_hidden_for_admin = class_exists('PK01_Authorization')
            && in_array(PK01_Authorization::effective_role(), ['administrator','pk01_admin'], true)
            && !PK01_Authorization::is_role_preview();
        // Urutan sidebar ditentukan oleh domain kerja agar stabil dan rapi.
        $nav_priority = ['utama'=>10,'produk'=>20,'pembelian'=>30,'penjualan'=>40,'sdm'=>50,'keuangan'=>60,'ai'=>70,'sistem'=>80,'eksternal'=>90];
        usort($allowed, function($a, $b) use ($reg, $nav_priority) {
            $ga = $nav_priority[sanitize_key($reg[$a]['group'] ?? 'lainnya')] ?? 999;
            $gb = $nav_priority[sanitize_key($reg[$b]['group'] ?? 'lainnya')] ?? 999;
            return $ga === $gb ? strnatcasecmp((string)($reg[$a]['label'] ?? $a), (string)($reg[$b]['label'] ?? $b)) : ($ga <=> $gb);
        });
        foreach ($allowed as $k) {
            if (!isset($reg[$k])) continue;
            $m = $reg[$k];
            if (!empty($m['nav_hidden'])) continue;
            // Hanya tampilkan menu yang juga lolos authorization.
            if (class_exists('PK01_Authorization') && !PK01_Authorization::can($k)) continue;
            $group = sanitize_key($m['group'] ?? 'utama');
            if ($group !== $last_group) {
                $group_labels = [
                    'utama'=>'UTAMA','produk'=>'PRODUK & PRODUKSI','pembelian'=>'PEMBELIAN','penjualan'=>'PENJUALAN','sdm'=>'SDM & PEKERJAAN','keuangan'=>'KEUANGAN','ai'=>'AI & BANTUAN','sistem'=>'SISTEM'
                ];
                $o .= '<div class="pk01-side-group-title">' . esc_html($group_labels[$group] ?? strtoupper($group)) . '</div>';
                $last_group = $group;
            }
            $act = $current === $k ? ' is-active' : '';
            $icon = self::nav_icon($m['icon'] ?? 'box');
            $o .= '<a class="pk01-side-link' . $act . '" href="' . esc_url(self::frontend_url_public($k)) . '" aria-current="' . ($current === $k ? 'page' : 'false') . '" title="' . esc_attr($m['label']) . '"><span class="pk01-side-icon">' . $icon . '</span><span class="pk01-side-label">' . esc_html($m['label']) . '</span></a>';
        }
        $o .= '</div>';
        $current_user = wp_get_current_user();
        $display_name = $current_user ? ($current_user->display_name ?: $current_user->user_login) : 'Pengguna';
        $logout_url = wp_logout_url(self::frontend_url_public('dashboard'));
        $o .= '<div class="pk01-side-user-card"><div class="pk01-side-user-avatar">' . esc_html(strtoupper(substr($display_name,0,1))) . '</div><div class="pk01-side-user-meta"><strong>' . esc_html($display_name) . '</strong><span>' . esc_html($role_label) . '</span></div></div>';
        $o .= '<div class="pk01-side-footer"><a href="' . esc_url(home_url('/')) . '"><span class="pk01-side-icon">' . self::nav_icon('home') . '</span><span>Lihat Website</span></a><a href="' . esc_url($logout_url) . '"><span class="pk01-side-icon">' . self::nav_icon('lock') . '</span><span>Keluar</span></a></div>';
        $o .= '</aside>';
        return $o;
    }

    /*
     * =============================================================
     * PANDUAN SHORTCODE PK01 — BAHASA INDONESIA
     * =============================================================
     *
     * pk01_penjualan_marketplace : menampilkan penjualan dari marketplace.
     * pk01_karyawan              : menampilkan data karyawan usaha.
     * pk01_harga_jual            : mengatur/menampilkan harga jual produk.
     * pk01_modal_usaha            : mencatat dan menampilkan modal usaha.
     * pk01_aktivitas              : menampilkan riwayat aktivitas/audit.
     * pk01_pengaturan_sistem      : menampilkan pengaturan sistem PK01.
     *
     * Alias Bahasa Indonesia memanggil renderer yang sama dengan nama teknis.
     * Jangan membuat renderer/database baru hanya untuk alias shortcode.
     */

    /**
     * Renderer modul: setiap shortcode mempunyai file tampilan sendiri.
     * File tampilan tidak menyimpan logika transaksi inti; transaksi tetap melalui Engine.
     */
    private static function render_file($file_or_key) {
        /*
         * SECURITY BOUNDARY: setiap renderer wajib melewati Authorization Engine.
         * Ini mencegah shortcode/URL langsung membuka dashboard milik role lain.
         * Administrator nyata boleh melihat semua; role preview mengikuti role yang
         * sedang disimulasikan dan tetap read-only melalui PK01_Authorization.
         */
        $access_key = sanitize_key((string)$file_or_key);
        if (is_user_logged_in() && class_exists('PK01_Authorization')) {
            $dashboard_keys = ['dashboard','owner_dashboard','warehouse','production','packing','seller_affiliate','job_karyawan','customer_service','security'];
            $dashboard_alias = [
                'warehouse_dashboard'=>'warehouse',
                'warehouse_outbound'=>'warehouse_outbound',
                'warehouse_returns'=>'warehouse_returns',
                'warehouse_supplier_inbound'=>'warehouse_supplier_inbound',
                'seller_portal'=>'seller_portal',
            ];
            $auth_key = $dashboard_alias[$access_key] ?? $access_key;
            $allowed = in_array($auth_key, $dashboard_keys, true)
                ? PK01_Authorization::can_navigate($auth_key)
                : PK01_Authorization::can_action($auth_key, 'view');
            if (!$allowed) {
                $label = class_exists('PK01_Module_Registry') && isset(PK01_Module_Registry::all()[$auth_key]['label'])
                    ? PK01_Module_Registry::all()[$auth_key]['label'] : 'modul ini';
                return '<div class="pk01-op-card" style="max-width:680px;margin:40px auto;text-align:center"><h2>Akses terbatas</h2><p>Anda tidak memiliki otorisasi untuk membuka '.esc_html($label).'. Silakan kembali ke Dashboard Anda.</p><a class="pk01-op-button" href="'.esc_url(self::frontend_url_public('dashboard')).'">Kembali ke Dashboard</a></div>';
            }
        }
        $path = '';
        if (class_exists('PK01_Module_Registry') && method_exists('PK01_Module_Registry', 'view_path')) {
            $path = PK01_Module_Registry::view_path($file_or_key);
        }
        // Compatibility fallback for non-registry internal renderers.
        if (!$path) {
            $path = PK01_DIR . 'includes/' . ltrim((string)$file_or_key, '/');
        }
        if (!is_readable($path)) {
            return '<div class="pk01-op-notice is-error">Tampilan modul belum tersedia.</div>';
        }
        ob_start();
        include $path;
        return ob_get_clean();
    }

    public static function login(){ return class_exists('PK01_Login') ? PK01_Login::shortcode() : '<div class="pk01-op-notice is-error">Login PK01 belum tersedia.</div>'; }
    public static function master_data(){ return self::render_file('master_data'); }
    public static function administration(){ return self::render_file('administration'); }
    public static function users(){ return self::render_file('users'); }
    public static function documents(){ return self::render_file('documents'); }
    public static function dashboard(){
        // Satu Dashboard Engine untuk seluruh role. Profil, KPI, menu tindakan,
        // dan data yang ditampilkan ditentukan oleh effective_role() di view
        // dashboard-role. Jangan mengarahkan role ke modul transaksi langsung;
        // modul tersebut tetap dibuka dari action/menu dashboard.
        $tools = class_exists('PK01_Ops_Tools') ? PK01_Ops_Tools::render() : '';
        return $tools . self::render_file('dashboard');
    }

    public static function production_flow(){
        if (!class_exists('PK01_Authorization') || !PK01_Authorization::can('production_flow')) {
            return '<div class="pk01-op-card" style="max-width:680px;margin:40px auto;text-align:center"><h2>Akses terbatas</h2><p>Menu Manajemen Produksi hanya untuk Produksi, Gudang, Admin, dan pengguna yang diberi izin.</p></div>';
        }
        global $wpdb;
        $T = function($k){ return PK01_DB::t($k); };
        $jobs=$T('jobs'); $jm=$T('job_materials'); $st=$T('stock_transactions'); $pr=$T('production_results'); $mat=$T('materials'); $cl=$T('cash_ledger');
        $today=current_time('Y-m-d'); $month=current_time('Y-m');
        $q=function($sql,$default=0)use($wpdb){$v=$wpdb->get_var($sql);return $v===null?$default:$v;};
        $rp=function($v){return 'Rp '.number_format((float)$v,0,',','.');};
        $material_in=(float)$q("SELECT COALESCE(SUM(qty),0) FROM `{$st}` WHERE stock_type='material' AND direction='in' AND DATE(created_at) BETWEEN '{$month}-01' AND '{$today}' AND reference_type IN ('inventory_receipt','job_return')");
        $material_out=(float)$q("SELECT COALESCE(SUM(issued_qty),0) FROM `{$jm}` WHERE DATE(created_at) BETWEEN '{$month}-01' AND '{$today}'");
        $material_used=(float)$q("SELECT COALESCE(SUM(used_qty),0) FROM `{$jm}` WHERE DATE(created_at) BETWEEN '{$month}-01' AND '{$today}'");
        $material_return=(float)$q("SELECT COALESCE(SUM(returned_qty),0) FROM `{$jm}` WHERE DATE(created_at) BETWEEN '{$month}-01' AND '{$today}'");
        $finished_in=(float)$q("SELECT COALESCE(SUM(good_qty),0) FROM `{$pr}` WHERE approved=1 AND status='approved' AND DATE(created_at) BETWEEN '{$month}-01' AND '{$today}'");
        $reject=(float)$q("SELECT COALESCE(SUM(reject_qty),0) FROM `{$pr}` WHERE DATE(created_at) BETWEEN '{$month}-01' AND '{$today}'");
        $active_jobs=(int)$q("SELECT COUNT(*) FROM `{$jobs}` WHERE status IN ('planned','assigned','in_progress')");
        $pending_jobs=(int)$q("SELECT COUNT(*) FROM `{$jobs}` WHERE status IN ('planned','assigned')");
        $material_value=(float)$q("SELECT COALESCE(SUM(stock*cost),0) FROM `{$mat}`");
        // Nilai pembelian material yang sudah diterima tetapi belum dibayar: receipt tanpa cash-out terkait.
        $unpaid_value=0.0;
        if($st && $cl){
            $rows=$wpdb->get_results("SELECT st.id,COALESCE(st.total_value,st.qty*st.unit_cost) value FROM `{$st}` st WHERE st.reference_type='inventory_receipt' AND st.direction='in' AND st.created_at BETWEEN '{$month}-01 00:00:00' AND '{$today} 23:59:59'",ARRAY_A)?:[];
            foreach($rows as $r){$paid=(float)$q($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$cl}` WHERE reference_type='inventory_receipt' AND reference_id=%d AND direction='out'",(int)$r['id']));$unpaid_value+=max(0,(float)$r['value']-$paid);}
        }
        $jobs_recent=$wpdb->get_results("SELECT j.id,j.job_no,j.target_qty,j.status,COALESCE(SUM(jm.issued_qty),0) issued_qty,COALESCE(SUM(jm.used_qty),0) used_qty,COALESCE(SUM(jm.returned_qty),0) returned_qty,COALESCE(SUM(pr.good_qty),0) good_qty,COALESCE(SUM(pr.reject_qty),0) reject_qty FROM `{$jobs}` j LEFT JOIN `{$jm}` jm ON jm.job_id=j.id LEFT JOIN `{$pr}` pr ON pr.job_id=j.id GROUP BY j.id ORDER BY j.id DESC LIMIT 12",ARRAY_A)?:[];
        $url=function($v){return esc_url(PK01_Shortcodes::frontend_url_public($v));};
        ob_start(); ?>
        <div class="pk01-op-card pk01-prod-flow">
          <div class="pk01-prod-hero"><div><span class="pk01-op-eyebrow">PRODUCTION CONTROL</span><h2>Manajemen Produksi</h2><p>Satu halaman untuk memahami <strong>barang masuk → barang keluar → dipakai → kembali → barang jadi</strong>. User tidak perlu memahami jurnal akuntansi.</p></div><div class="pk01-prod-hero-actions"><a class="pk01-op-button" href="<?php echo $url('production_hub'); ?>">Buka Job Produksi</a><a class="pk01-op-button is-secondary" href="<?php echo $url('inventory'); ?>">Buka Gudang</a></div></div>
          <div class="pk01-prod-kpis">
            <div><small>BAHAN MASUK</small><strong><?php echo esc_html(number_format($material_in,2,',','.')); ?></strong><span>ke gudang / kembali dari job</span></div>
            <div><small>BAHAN KELUAR KE JOB</small><strong><?php echo esc_html(number_format($material_out,2,',','.')); ?></strong><span>diserahkan ke produksi</span></div>
            <div><small>BAHAN TERPAKAI</small><strong><?php echo esc_html(number_format($material_used,2,',','.')); ?></strong><span>benar-benar dipakai</span></div>
            <div><small>BARANG JADI MASUK</small><strong><?php echo esc_html(number_format($finished_in,2,',','.')); ?></strong><span>hasil baik yang disetujui</span></div>
          </div>
          <div class="pk01-prod-flowline">
            <div class="pk01-flow-step"><b>1</b><strong>Bahan masuk</strong><span>Gudang menerima bahan dari pembelian.</span></div><div class="pk01-flow-arrow">→</div>
            <div class="pk01-flow-step"><b>2</b><strong>Bahan keluar</strong><span>Gudang menyerahkan bahan ke Job.</span></div><div class="pk01-flow-arrow">→</div>
            <div class="pk01-flow-step"><b>3</b><strong>Produksi</strong><span>Pekerja memakai bahan dan mencatat hasil.</span></div><div class="pk01-flow-arrow">→</div>
            <div class="pk01-flow-step"><b>4</b><strong>Barang jadi</strong><span>Hasil baik masuk stok barang jadi.</span></div>
          </div>
          <div class="pk01-prod-grid">
            <section class="pk01-prod-panel"><div class="pk01-prod-panel-head"><div><span class="pk01-op-eyebrow">PINTU MASUK</span><h3>Yang masuk ke produksi</h3></div></div><ul><li><b>Bahan baku masuk:</b> stok gudang bertambah.</li><li><b>Sisa bahan kembali:</b> stok gudang bertambah lagi.</li><li><b>Barang jadi:</b> hasil baik masuk stok produk.</li></ul><div class="pk01-prod-number"><span>Nilai stok bahan saat ini</span><strong><?php echo esc_html($rp($material_value)); ?></strong></div></section>
            <section class="pk01-prod-panel"><div class="pk01-prod-panel-head"><div><span class="pk01-op-eyebrow">PINTU KELUAR</span><h3>Yang keluar dari produksi</h3></div></div><ul><li><b>Bahan keluar ke Job:</b> stok gudang berkurang.</li><li><b>Bahan terpakai:</b> menjadi HPP Job.</li><li><b>Rusak/reject:</b> dicatat terpisah agar tidak dianggap barang jadi.</li></ul><div class="pk01-prod-number is-warn"><span>Pembelian bahan diterima tapi belum dibayar</span><strong><?php echo esc_html($rp($unpaid_value)); ?></strong></div></section>
          </div>
          <div class="pk01-prod-grid">
            <section class="pk01-prod-panel"><span class="pk01-op-eyebrow">STATUS HARI INI / PERIODE</span><h3>Ringkasan yang mudah dibaca</h3><div class="pk01-prod-mini-grid"><div><small>Job aktif</small><strong><?php echo (int)$active_jobs; ?></strong></div><div><small>Belum selesai</small><strong><?php echo (int)$pending_jobs; ?></strong></div><div><small>Bahan kembali</small><strong><?php echo esc_html(number_format($material_return,2,',','.')); ?></strong></div><div><small>Reject</small><strong><?php echo esc_html(number_format($reject,2,',','.')); ?></strong></div></div></section>
            <section class="pk01-prod-panel"><span class="pk01-op-eyebrow">ATURAN SEDERHANA</span><h3>PK01 tidak mencampur barang dengan uang</h3><p>Pergerakan bahan dan hasil dicatat di <b>Produksi/Gudang</b>. Uang yang benar-benar dibayar dicatat di <b>Keuangan → Pusat Uang</b>. Jika bahan sudah diterima tetapi belum dibayar, tampil sebagai <b>Belum Dibayar</b> dan belum mengurangi kas.</p><div class="pk01-prod-links"><a href="<?php echo $url('finance_hub'); ?>">💰 Keuangan</a><a href="<?php echo $url('cash'); ?>">💳 Pusat Kas</a><a href="<?php echo $url('purchasing_hub'); ?>">🛒 Pembelian</a></div></section>
          </div>
          <section class="pk01-prod-panel" style="margin-top:18px"><div class="pk01-prod-panel-head"><div><span class="pk01-op-eyebrow">JOB TERBARU</span><h3>Pelacakan bahan → hasil</h3></div></div><div style="overflow:auto"><table class="pk01-prod-table"><thead><tr><th>Job</th><th>Status</th><th>Bahan Keluar</th><th>Terpakai</th><th>Kembali</th><th>Barang Jadi</th><th>Reject</th></tr></thead><tbody><?php foreach($jobs_recent as $r): ?><tr><td><b><?php echo esc_html($r['job_no']); ?></b></td><td><?php echo esc_html($r['status']); ?></td><td><?php echo esc_html(number_format((float)$r['issued_qty'],2,',','.')); ?></td><td><?php echo esc_html(number_format((float)$r['used_qty'],2,',','.')); ?></td><td><?php echo esc_html(number_format((float)$r['returned_qty'],2,',','.')); ?></td><td><?php echo esc_html(number_format((float)$r['good_qty'],2,',','.')); ?></td><td><?php echo esc_html(number_format((float)$r['reject_qty'],2,',','.')); ?></td></tr><?php endforeach; if(!$jobs_recent): ?><tr><td colspan="7">Belum ada Job Produksi.</td></tr><?php endif; ?></tbody></table></div></section>
        </div>
        <style>
        .pk01-prod-hero{display:flex;justify-content:space-between;gap:20px;align-items:center;padding:24px;border-radius:18px;background:linear-gradient(135deg,#0f172a,#1e293b);color:#fff}.pk01-prod-hero h2{margin:4px 0 6px;color:#fff}.pk01-prod-hero p{margin:0;color:#cbd5e1;max-width:820px}.pk01-prod-hero-actions{display:flex;gap:8px;flex-wrap:wrap}.pk01-prod-hero .is-secondary{background:#fff;color:#0f172a}.pk01-prod-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.pk01-prod-kpis>div,.pk01-prod-panel{border:1px solid #e2e8f0;border-radius:16px;background:#fff;padding:18px}.pk01-prod-kpis small,.pk01-prod-panel .pk01-op-eyebrow{font-size:10px;font-weight:800;letter-spacing:.08em;color:#64748b}.pk01-prod-kpis strong{display:block;font-size:24px;margin:7px 0 3px;color:#0f172a}.pk01-prod-kpis span{font-size:12px;color:#64748b}.pk01-prod-flowline{display:grid;grid-template-columns:1fr auto 1fr auto 1fr auto 1fr;gap:10px;align-items:stretch;margin:18px 0}.pk01-flow-step{padding:16px;border-radius:14px;background:#f8fafc;border:1px solid #e2e8f0}.pk01-flow-step b{display:grid;place-items:center;width:28px;height:28px;border-radius:50%;background:#0f172a;color:#fff;margin-bottom:8px}.pk01-flow-step strong{display:block}.pk01-flow-step span{font-size:12px;color:#64748b}.pk01-flow-arrow{display:grid;place-items:center;font-size:24px;color:#94a3b8}.pk01-prod-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px}.pk01-prod-panel h3{margin:5px 0 10px}.pk01-prod-panel ul{margin:0 0 14px;padding-left:20px;color:#475569;line-height:1.8}.pk01-prod-number{padding:13px;border-radius:12px;background:#f1f5f9}.pk01-prod-number span{display:block;font-size:12px;color:#64748b}.pk01-prod-number strong{font-size:20px}.pk01-prod-number.is-warn{background:#fff7ed}.pk01-prod-mini-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.pk01-prod-mini-grid div{padding:12px;background:#f8fafc;border-radius:12px}.pk01-prod-mini-grid small{display:block;color:#64748b}.pk01-prod-mini-grid strong{font-size:20px}.pk01-prod-links{display:flex;gap:8px;flex-wrap:wrap}.pk01-prod-links a{padding:9px 12px;border:1px solid #e2e8f0;border-radius:10px;text-decoration:none}.pk01-prod-table{width:100%;border-collapse:collapse;font-size:13px}.pk01-prod-table th,.pk01-prod-table td{padding:10px;border-bottom:1px solid #e2e8f0;text-align:left;white-space:nowrap}.pk01-prod-table th{background:#f8fafc}.pk01-prod-flow *{box-sizing:border-box}@media(max-width:900px){.pk01-prod-kpis{grid-template-columns:repeat(2,1fr)}.pk01-prod-flowline{grid-template-columns:1fr}.pk01-flow-arrow{transform:rotate(90deg)}.pk01-prod-grid{grid-template-columns:1fr}.pk01-prod-mini-grid{grid-template-columns:repeat(2,1fr)}.pk01-prod-hero{align-items:flex-start;flex-direction:column}}@media(max-width:560px){.pk01-prod-kpis{grid-template-columns:1fr}.pk01-prod-mini-grid{grid-template-columns:1fr 1fr}}
        </style>
        <?php return ob_get_clean();
    }

    public static function security(){ return self::render_file('security'); }

    public static function customer_service(){ return self::render_file('customer_service'); }

    public static function owner_dashboard(){ return self::render_file('owner_dashboard'); }
    public static function cash(){ return self::render_file('cash'); }
    public static function finance(){ return self::render_file('finance'); }
    public static function finance_reports(){ return self::render_file('finance_reports'); }
    public static function products(){ return self::render_file('products'); }
    public static function materials(){ return self::render_file('materials'); }
    public static function stock(){ return self::render_file('stock'); }
    public static function production(){ return self::render_file('production'); }
    public static function purchase(){ return self::render_file('purchase'); }
    public static function seller(){ return self::render_file('seller'); }
    public static function seller_affiliate() {
        if (is_user_logged_in() && class_exists('PK01_Authorization') && !PK01_Authorization::can_action('seller_affiliate', 'view')) {
            return '<div class="pk01-op-card" style="max-width:680px;margin:40px auto;text-align:center"><h2>Akses terbatas</h2><p>Anda tidak memiliki otorisasi untuk membuka Dashboard Seller.</p></div>';
        }
        if (!class_exists('PK01_Affiliate')) return '<div class="pk01-op-card"><h2>Affiliate Seller</h2><p>Modul belum tersedia.</p></div>';
        $seller=PK01_Affiliate::seller_account();
        if(!$seller && !current_user_can('manage_options')) return '<div class="pk01-op-card"><h2>Affiliate Seller</h2><p>Akun Seller aktif belum ditemukan.</p></div>';
        $seller_id=$seller?(int)$seller['id']:0;
        if(current_user_can('manage_options') && isset($_GET['pk01_seller_id'])) $seller_id=(int)$_GET['pk01_seller_id'];
        if(!$seller_id) return '<div class="pk01-op-card"><h2>Affiliate Seller</h2><p>Pilih akun Seller terlebih dahulu.</p></div>';
        global $wpdb; $stats=PK01_Affiliate::seller_stats($seller_id);
        $vt=PK01_DB::t('product_variants'); $pt=PK01_DB::t('products'); $lt=PK01_DB::t('affiliate_links');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT v.id variant_id,v.sku,p.id product_id,p.code,p.name,p.product_description,p.description,p.image_id,l.id link_id,l.affiliate_code,l.clicks FROM $vt v INNER JOIN $pt p ON p.id=v.product_id LEFT JOIN $lt l ON l.variant_id=v.id AND l.seller_account_id=%d WHERE v.status='active' AND p.status='active' ORDER BY p.name ASC,v.id DESC LIMIT 100",$seller_id),ARRAY_A)?:[];
        $notice='';
        if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_aff_action'])){
            if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_aff_nonce']??'')),'pk01_affiliate_action')) $notice='<div class="pk01-op-notice is-error">Sesi tidak valid. Silakan muat ulang halaman.</div>';
            else try{
                $variant=(int)($_POST['variant_id']??0);$action=sanitize_key($_POST['pk01_aff_action']);
                if($action==='link'){$l=PK01_Affiliate::link($seller_id,$variant);$ch=sanitize_key($_POST['channel']??'facebook');$campaign=sanitize_text_field($_POST['campaign']??'');$u=PK01_Affiliate::url($l,$ch,$campaign);$notice='<div class="pk01-op-notice is-success"><strong>Link promosi siap.</strong><div style="margin-top:8px;word-break:break-all"><code>'.esc_html($u).'</code></div><div class="pk01-aff-share" data-url="'.esc_attr($u).'" data-name="'.esc_attr('Promosi '.$l['affiliate_code']).'"><button type="button" class="pk01-op-button is-small pk01-aff-copy">Salin Link</button><a class="pk01-op-button is-small" target="_blank" rel="noopener" href="'.esc_url('https://www.facebook.com/sharer/sharer.php?u='.rawurlencode($u)).'">Bagikan ke Facebook</a><a class="pk01-op-button is-small" target="_blank" rel="noopener" href="'.esc_url('https://wa.me/?text='.rawurlencode($u)).'">Bagikan ke WhatsApp</a></div></div>';}
                if($action==='export'){$market=sanitize_key($_POST['marketplace']??'');$format=sanitize_key($_POST['format']??'csv');$r=PK01_Affiliate::export_package($seller_id,$variant,$market,$format);$notice='<div class="pk01-op-notice is-success">Paket data berhasil dibuat. <a href="'.esc_url($r['url']).'" target="_blank" rel="noopener">Buka file</a></div>';}
            }catch(Throwable $e){$notice='<div class="pk01-op-notice is-error">'.esc_html($e->getMessage()).'</div>';}
        }
        $orders=PK01_Affiliate::seller_orders($seller_id,20);$commissions=PK01_Affiliate::seller_commissions($seller_id,20);
        ob_start(); ?>
        <div class="pk01-op-card pk01-affiliate-center">
          <div class="pk01-op-card-head"><span class="pk01-op-eyebrow">SELLER</span><h2>Promosi Produk & Komisi</h2><p>Pilih produk, bagikan link, lalu pantau pesanan dan komisi Anda. Barang disiapkan dan dikirim oleh tim perusahaan.</p></div>
          <?php echo $notice; ?>
          <div class="pk01-dashboard-kpi-grid pk01-aff-kpis">
            <div class="pk01-kpi"><small>Produk</small><strong><?php echo number_format($stats['products']); ?></strong></div>
            <div class="pk01-kpi"><small>Klik</small><strong><?php echo number_format($stats['clicks']); ?></strong></div>
            <div class="pk01-kpi"><small>Kunjungan</small><strong><?php echo number_format($stats['visits']); ?></strong></div>
            <div class="pk01-kpi"><small>Pesanan</small><strong><?php echo number_format($stats['orders']); ?></strong></div>
            <div class="pk01-kpi"><small>Penjualan</small><strong>Rp <?php echo number_format($stats['sales'],0,',','.'); ?></strong></div>
            <div class="pk01-kpi"><small>Komisi</small><strong>Rp <?php echo number_format($stats['commission_pending']+$stats['commission_ready']+$stats['commission_paid'],0,',','.'); ?></strong></div>
          </div>
          <div class="pk01-section-title"><h3>Produk yang Bisa Anda Promosikan</h3><p>Pilih tempat berbagi dan sistem membuat link untuk Anda.</p></div>
          <?php if(!$rows): ?><div class="pk01-op-empty">Belum ada produk yang bisa dipromosikan.</div><?php else: foreach($rows as $r): ?>
            <div class="pk01-aff-product">
              <div class="pk01-aff-product-main">
                <?php if(!empty($r['image_id'])){ $img=wp_get_attachment_image_url((int)$r['image_id'],'medium'); if($img) echo '<img src="'.esc_url($img).'" alt="'.esc_attr($r['name']).'">'; } ?>
                <div><strong><?php echo esc_html($r['name']); ?></strong><div class="pk01-aff-meta">SKU <?php echo esc_html($r['sku']?:$r['code']); ?> · <?php echo $r['link_id']?'Link sudah ada':'Belum ada link'; ?> · <?php echo number_format((int)$r['clicks']); ?> klik</div></div>
              </div>
              <form method="post" class="pk01-aff-actions">
                <?php wp_nonce_field('pk01_affiliate_action','pk01_aff_nonce'); ?><input type="hidden" name="variant_id" value="<?php echo (int)$r['variant_id']; ?>">
                <select name="channel" aria-label="Tempat berbagi"><option value="facebook">Facebook</option><option value="whatsapp">WhatsApp</option><option value="instagram">Instagram</option><option value="tiktok">TikTok</option><option value="youtube">YouTube</option><option value="website">Website</option><option value="lainnya">Lainnya</option></select>
                <input name="campaign" placeholder="Nama promosi (opsional)">
                <button class="pk01-op-button" name="pk01_aff_action" value="link" type="submit"><?php echo $r['link_id']?'Bagikan Produk':'Buat Link Promosi'; ?></button>
              </form>
            </div>
          <?php endforeach; endif; ?>
          <div class="pk01-section-title"><h3>Pesanan dari Link Anda</h3></div>
          <?php if(!$orders): ?><div class="pk01-op-empty">Belum ada pesanan dari link Anda.</div><?php else: ?><div class="pk01-op-table-wrap"><table><thead><tr><th>Pesanan</th><th>Status</th><th>Pengiriman</th><th>Penjualan</th><th>Komisi</th></tr></thead><tbody><?php foreach($orders as $o): ?><tr><td><b><?php echo esc_html($o['order_no']); ?></b><br><small><?php echo esc_html(ucfirst($o['affiliate_channel']?:'Website')); ?></small></td><td><?php echo esc_html($o['status']?:'Diproses'); ?></td><td><?php echo esc_html($o['shipping_status']?:'Belum dikirim'); ?></td><td>Rp <?php echo number_format((float)$o['gross'],0,',','.'); ?></td><td>Rp <?php echo number_format((float)$o['affiliate_commission_amount'],0,',','.'); ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
          <div class="pk01-section-title"><h3>Riwayat Komisi</h3></div>
          <?php if(!$commissions): ?><div class="pk01-op-empty">Belum ada komisi.</div><?php else: ?><div class="pk01-op-table-wrap"><table><thead><tr><th>Pesanan</th><th>Nilai</th><th>Status</th><th>Tanggal</th></tr></thead><tbody><?php foreach($commissions as $c): ?><tr><td><?php echo esc_html($c['order_no']?:'—'); ?></td><td>Rp <?php echo number_format((float)$c['commission_amount'],0,',','.'); ?></td><td><?php $st=$c['status']==='pending'||$c['status']==='accrued'?'MENUNGGU':($c['status']==='ready'||$c['status']==='approved'?'SIAP DIBAYAR':($c['status']==='paid'?'SUDAH DIBAYAR':'DIBATALKAN')); echo esc_html($st); ?></td><td><?php echo esc_html($c['created_at']?:'—'); ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
        </div>
        <script>(function(){document.querySelectorAll('.pk01-aff-copy').forEach(function(b){b.addEventListener('click',function(){var u=b.closest('.pk01-aff-share').dataset.url;navigator.clipboard?navigator.clipboard.writeText(u).then(function(){b.textContent='Link Tersalin';}):window.prompt('Salin link ini:',u);});});})();</script>
        <?php return ob_get_clean();
    }

    public static function seller_portal(){ return self::render_file('seller_portal'); }
    public static function returns(){ return self::render_file('returns'); }
    public static function sales(){ return self::render_file('sales'); }
    public static function customers(){ return self::render_file('customers'); }
    public static function suppliers(){ return self::render_file('suppliers'); }
    public static function shipments(){ return self::render_file('shipments'); }
    public static function marketplace(){ return self::render_file('marketplace'); }
    public static function employees(){ return self::render_file('employees'); }
    public static function attendance(){ return self::render_file('attendance'); }
    public static function job_karyawan(){ return self::render_file('job_karyawan'); }
    public static function packing(){ return self::render_file('packing'); }
    public static function payroll(){ return self::render_file('payroll'); }
    public static function job_wages(){ return self::render_file('job_wages'); }
    public static function assets_inventory(){ return self::render_file('assets_inventory'); }
    public static function operational_costs(){ return self::render_file('operational_costs'); }
    public static function capital(){ return self::render_file('capital'); }
    public static function capital_owners(){ return self::render_file('capital_owners'); }
    public static function profit_sharing(){ return self::render_file('capital_owners'); }
    public static function inventory_input(){ return self::render_file('inventory_input'); }
    public static function inventory_valuation(){ return self::render_file('inventory_input'); }
    public static function pricing(){ return self::render_file('pricing'); }
    public static function closing(){ return self::render_file('closing'); }
    public static function logs(){ return self::render_file('logs'); }
    public static function system(){ return self::render_file('system'); }
    public static function data_control(){ return class_exists('PK01_Governance') ? PK01_Governance::render_control_center() : '<div class="pk01-op-notice is-error">Governance belum tersedia.</div>'; }
    public static function ai_assistant(){ return self::render_file('ai_assistant'); }
    public static function ai_center(){ return self::render_file('ai_center'); }
    public static function cnc_library(){
        return class_exists('PK01_CNC_Library') ? PK01_CNC_Library::render() : '<div class="pk01-op-card"><h3>Database G-code belum aktif</h3><p>Modul CNC Library belum termuat.</p></div>';
    }

    public static function production_hub(){ 
        $tabs = [
            'production'=>['label'=>'Produksi','method'=>'production'],
            'cnc_library'=>['label'=>'Database G-code CNC','method'=>'cnc_library'],
            'job_karyawan'=>['label'=>'Pekerjaan Tim','method'=>'job_karyawan'],
            'products'=>['label'=>'Produk','method'=>'products'],
            'materials'=>['label'=>'Bahan Baku','method'=>'materials'],
        ];
        $requested=sanitize_key($_GET['pk01_tab']??'');
        $active=$requested && isset($tabs[$requested]) ? $requested : 'production';
        $base=self::frontend_url_public('production_hub');
        ob_start();
        echo '<section class="pk01-consolidated-hub" data-hub="production_hub">';
        echo '<div class="pk01-op-card"><div class="pk01-op-card-head"><span class="pk01-op-eyebrow">PK01 TERINTEGRASI</span><h2>Produksi</h2><p>Satu alur produksi. Job dibuat di sini; penugasan dan penerimaan pekerja memakai data Job yang sama, bukan membuat Job baru.</p></div><nav class="pk01-hub-tabs" aria-label="Produksi">';
        echo '<div class="pk01-simple-flow"><div><b>1. Pesanan masuk</b><span>→ Job dibuat</span></div><div><b>2. Siapkan bahan</b><span>→ Barang/bahan tersedia</span></div><div><b>3. Kerjakan</b><span>→ Dikerjakan tim / CNC</span></div><div><b>4. Periksa</b><span>→ Catat baik & rusak</span></div><div><b>5. Selesai</b><span>→ Produk siap dikirim</span></div></div>';
        foreach($tabs as $key=>$tab){
            if(class_exists('PK01_Authorization') && !PK01_Authorization::can($key)) continue;
            $url=add_query_arg(['pk01_view'=>'production_hub','pk01_tab'=>$key],$base);
            echo '<a class="pk01-op-button is-small '.($active===$key?'is-active':'').'" href="'.esc_url($url).'">'.esc_html($tab['label']).'</a>';
        }
        echo '</nav></div>';
        if(class_exists('PK01_Authorization') && !PK01_Authorization::can($active)){
            echo '<div class="pk01-op-card"><div class="pk01-op-empty">Anda tidak memiliki izin untuk membuka bagian ini.</div></div>';
        } elseif(method_exists(__CLASS__,$tabs[$active]['method'])) {
            echo '<div class="pk01-consolidated-content">'.call_user_func([__CLASS__,$tabs[$active]['method']]).'</div>';
        }
        echo '</section>';
        return ob_get_clean();
    }


    /**
     * Smart Menu Consolidation: satu shell UI untuk domain yang memiliki
     * hubungan data/proses kuat. Logic transaksi tetap berada pada renderer/Engine lama.
     */
    private static function consolidated_hub($hub) {
        $configs = [
            'inventory' => [
                'title'=>'Gudang & Stok',
                'tabs'=>[
                    'stock'=>['label'=>'Stok','method'=>'stock'],
                    'products'=>['label'=>'Produk','method'=>'products'],
                    'materials'=>['label'=>'Bahan Baku','method'=>'materials'],
                    'warehouse'=>['label'=>'📦 Gudang & Tanda Terima','method'=>'warehouse'],
                ],
            ],
            'purchasing' => [
                'title'=>'Pembelian',
                'tabs'=>[
                    'purchase'=>['label'=>'Pembelian / PO','method'=>'purchase'],
                    'suppliers'=>['label'=>'Pemasok','method'=>'suppliers'],
                ],
            ],
            'sales_hub' => [
                'title'=>'Penjualan',
                'tabs'=>[
                    'sales'=>['label'=>'Penjualan','method'=>'sales'],
                    'marketplace'=>['label'=>'Marketplace','method'=>'marketplace'],
                    'customers'=>['label'=>'Pelanggan','method'=>'customers'],
                    'seller'=>['label'=>'Mitra Seller','method'=>'seller'],
                ],
            ],
            'shipping_hub' => [
                'title'=>'Pengiriman',
                'tabs'=>[
                    'shipments'=>['label'=>'Pengiriman & Resi','method'=>'shipments'],
                    'sales'=>['label'=>'Pesanan Siap Kirim','method'=>'sales'],
                ],
            ],
            'hr' => [
                'title'=>'SDM',
                'tabs'=>[
                    'employees'=>['label'=>'Karyawan','method'=>'employees'],
                    'payroll'=>['label'=>'Gaji','method'=>'payroll'],
                    'job_wages'=>['label'=>'Upah Pekerjaan','method'=>'job_wages'],
                    'assets_inventory'=>['label'=>'Aset & Inventori','method'=>'assets_inventory'],
                ],
            ],
            'finance_hub' => [
                'title'=>'Keuangan',
                'tabs'=>[
                    'finance'=>['label'=>'Ringkasan Keuangan','method'=>'finance'],
                    'finance_reports'=>['label'=>'Laporan Keuangan','method'=>'finance_reports'],
                    'cash'=>['label'=>'Uang Usaha','method'=>'cash'],
                    'operational_costs'=>['label'=>'Biaya Usaha','method'=>'operational_costs'],
                    'capital_owners'=>['label'=>'Modal Awal & Pemilik','method'=>'capital_owners'],
                    'profit_sharing'=>['label'=>'Bagi Hasil Pemilik','method'=>'profit_sharing'],
                    'pricing'=>['label'=>'Harga Jual','method'=>'pricing'],
                    'closing'=>['label'=>'Tutup Periode','method'=>'closing'],
                ],
            ],
        ];
        $cfg=$configs[$hub]??null;
        if(!$cfg) return '';
        $requested=sanitize_key($_GET['pk01_tab']??'');
        $active=$requested && isset($cfg['tabs'][$requested]) ? $requested : array_key_first($cfg['tabs']);
        $base=self::frontend_url_public($hub);
        ob_start();
        ?>
        <section class="pk01-consolidated-hub" data-hub="<?php echo esc_attr($hub); ?>">
            <div class="pk01-op-card">
                <div class="pk01-op-card-head">
                    <span class="pk01-op-eyebrow">PK01 TERINTEGRASI</span>
                    <h2><?php echo esc_html($cfg['title']); ?></h2>
                    <p>Fungsi yang saling berkaitan disatukan dalam satu menu. Data dan business logic tetap menggunakan engine PK01 yang sama.</p>
                </div>
                <?php if($hub === 'finance_hub'): ?>
                <div class="pk01-simple-flow pk01-finance-simple-flow">
                    <div><b>1. Uang masuk</b><span>Penjualan / modal</span></div>
                    <div><b>2. Uang tersedia</b><span>Kas / bank</span></div>
                    <div><b>3. Bayar kebutuhan</b><span>Bahan, operasional, gaji</span></div>
                    <div><b>4. Catat pembayaran</b><span>Kasir / bank</span></div>
                    <div><b>5. Lihat hasil</b><span>Masuk − keluar = sisa</span></div>
                </div>
                <div class="pk01-op-card pk01-simple-explain">
                    <strong>Intinya:</strong> jangan pikirkan debit/kredit. Tanyakan saja <b>uang masuk dari mana, uang keluar untuk apa, siapa yang menerima, dan berapa sisa uang usaha.</b>
                </div>
                <?php endif; ?>
                <nav class="pk01-hub-tabs" aria-label="<?php echo esc_attr($cfg['title']); ?>">
                    <?php foreach($cfg['tabs'] as $key=>$tab):
                        if(class_exists('PK01_Authorization') && !PK01_Authorization::can($key)) continue;
                        $url=add_query_arg(['pk01_view'=>$hub,'pk01_tab'=>$key],$base);
                    ?>
                        <a class="pk01-op-button is-small <?php echo $active===$key?'is-active':''; ?>" href="<?php echo esc_url($url); ?>"><?php echo esc_html($tab['label']); ?></a>
                    <?php endforeach; ?>
                </nav>
            </div>
            <?php
            $tab=$cfg['tabs'][$active];
            if(class_exists('PK01_Authorization') && !PK01_Authorization::can($active)):
            ?>
                <div class="pk01-op-card"><div class="pk01-op-empty">Anda tidak memiliki izin untuk membuka bagian ini.</div></div>
            <?php else:
                echo '<div class="pk01-consolidated-content">';
                if(method_exists(__CLASS__,$tab['method'])) echo call_user_func([__CLASS__,$tab['method']]);
                echo '</div>';
            endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function inventory(){ return self::consolidated_hub('inventory'); }
    public static function warehouse(){
        $tabs=['warehouse'=>['label'=>'Dashboard Gudang','method'=>'warehouse_dashboard'],'warehouse_returns'=>['label'=>'↩️ Retur','method'=>'warehouse_returns'],'warehouse_outbound'=>['label'=>'📤 Kirim Barang','method'=>'warehouse_outbound'],'warehouse_supplier_inbound'=>['label'=>'📥 Terima Supplier','method'=>'warehouse_supplier_inbound']];
        $requested=sanitize_key($_GET['pk01_tab']??''); $active=isset($tabs[$requested])?$requested:'warehouse'; $base=self::frontend_url_public('warehouse');
        ob_start(); echo '<section class="pk01-consolidated-hub" data-hub="warehouse"><div class="pk01-op-card"><div class="pk01-op-card-head"><span class="pk01-op-eyebrow">PK01 TERINTEGRASI</span><h2>Gudang & Pintu Barang</h2><p>Satu domain Gudang, tetapi setiap pekerjaan fisik memiliki folder/menu coding terpisah agar mudah dirawat.</p></div><nav class="pk01-hub-tabs" aria-label="Gudang">';
        foreach($tabs as $key=>$tab){ if(class_exists('PK01_Authorization') && !PK01_Authorization::can('warehouse')) continue; $url=add_query_arg(['pk01_view'=>'warehouse','pk01_tab'=>$key],$base); echo '<a class="pk01-op-button is-small '.($active===$key?'is-active':'').'" href="'.esc_url($url).'">'.esc_html($tab['label']).'</a>'; }
        echo '</nav></div><div class="pk01-consolidated-content">'.call_user_func([__CLASS__,$tabs[$active]['method']]).'</div></section>'; return ob_get_clean();
    }
    public static function warehouse_dashboard(){ return self::render_file('warehouse'); }
    public static function warehouse_returns(){ return self::render_file('warehouse_returns'); }
    public static function warehouse_outbound(){ return self::render_file('warehouse_outbound'); }
    public static function warehouse_supplier_inbound(){ return self::render_file('warehouse_supplier_inbound'); }
    public static function purchasing(){ return self::consolidated_hub('purchasing'); }
    public static function sales_hub(){ return self::consolidated_hub('sales_hub'); }
    public static function shipping_hub(){ return self::consolidated_hub('shipping_hub'); }
    public static function hr(){ return self::consolidated_hub('hr'); }
    public static function finance_hub(){ return self::consolidated_hub('finance_hub'); }

    public static function ai_mobile(){
        if(class_exists('PK01_Authorization') && !PK01_Authorization::can_action('ai_assistant','view')) return '<div class="pk01-op-card"><h2>Akses terbatas</h2><p>Anda tidak memiliki hak akses ke Asisten AI.</p></div>';
        $nonce=wp_create_nonce('wp_rest'); $rest=esc_url_raw(rest_url('pk01/v1/mobile/command')); $status=class_exists('PK01_AI')?PK01_AI::status():['available'=>false,'message'=>'AI belum tersedia.'];
        ob_start(); ?>
        <section class="pk01-ai-mobile" data-endpoint="<?php echo esc_attr($rest); ?>" data-nonce="<?php echo esc_attr($nonce); ?>">
          <div class="pk01-op-card"><span class="pk01-op-eyebrow">PK01 AI OPERATIONAL CONTROL</span><h2>Asisten Operasional</h2><p>Gunakan dari HP untuk memantau kondisi usaha tanpa membuka Dashboard. Data tetap mengikuti hak akses Anda.</p><div class="pk01-ai-mobile-status"><strong><?php echo !empty($status['available'])?'● AI Aktif':'● Mode Sistem'; ?></strong><span><?php echo esc_html($status['message']); ?></span></div></div>
          <div class="pk01-ai-mobile-priority" id="pk01-ai-mobile-priority"><div class="pk01-op-card"><h3>Prioritas Sekarang</h3><div class="pk01-op-empty">Memuat kondisi operasional…</div></div></div>
          <div class="pk01-op-card"><h3>Tanya PK01</h3><div class="pk01-ai-mobile-quick"><button type="button" data-q="Bagaimana kondisi perusahaan hari ini?">Kondisi hari ini</button><button type="button" data-q="Ada produksi yang terlambat?">Produksi terlambat</button><button type="button" data-q="Ada stok bahan yang kritis?">Stok kritis</button><button type="button" data-q="Pesanan mana yang belum dikirim?">Pesanan & pengiriman</button><button type="button" data-q="Bagaimana kesehatan database?">Kesehatan data</button></div><div class="pk01-ai-mobile-chat" id="pk01-ai-mobile-chat" aria-live="polite"></div><form id="pk01-ai-mobile-form"><textarea id="pk01-ai-mobile-input" rows="3" placeholder="Contoh: Bagaimana kondisi produksi hari ini?"></textarea><button class="pk01-op-button" type="submit">Tanya PK01</button></form></div>
        </section>
        <script>(function(){const root=document.querySelector('.pk01-ai-mobile');if(!root)return;const chat=document.getElementById('pk01-ai-mobile-chat'),input=document.getElementById('pk01-ai-mobile-input'),form=document.getElementById('pk01-ai-mobile-form'),pri=document.getElementById('pk01-ai-mobile-priority');async function status(){try{const r=await fetch('<?php echo esc_js(rest_url('pk01/v1/mobile/status')); ?>',{credentials:'same-origin'});const j=await r.json(),p=(j.data&&j.data.operations&&j.data.operations.priority)||[];pri.innerHTML='<div class="pk01-op-card"><h3>Prioritas Sekarang</h3>'+(p.length?p.slice(0,5).map(x=>'<div class="pk01-ai-priority-row"><b>'+x.severity+'</b><span>'+x.title+'</span><strong>'+x.count+'</strong></div>').join(''):'<div class="pk01-op-empty">Tidak ada prioritas yang terdeteksi dari data saat ini.</div>')+'</div>'}catch(e){pri.innerHTML='<div class="pk01-op-card"><h3>Prioritas Sekarang</h3><div class="pk01-op-empty">Status belum dapat dimuat.</div></div>';}}async function ask(q){q=(q||'').trim();if(!q)return;chat.insertAdjacentHTML('beforeend','<div class="pk01-ai-msg is-user">'+q.replace(/[&<>]/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[s]))+'</div>');input.value='';chat.insertAdjacentHTML('beforeend','<div class="pk01-ai-msg is-ai">Memeriksa data PK01…</div>');const el=chat.lastElementChild;try{const r=await fetch(root.dataset.endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':root.dataset.nonce},body:JSON.stringify({question:q,session:'mobile-'+Date.now()})});const j=await r.json();el.textContent=(j.message||'Tidak ada respons.');}catch(e){el.textContent='Koneksi belum tersedia. Sistem utama tetap dapat digunakan.';}}form.addEventListener('submit',e=>{e.preventDefault();ask(input.value)});root.querySelectorAll('[data-q]').forEach(b=>b.addEventListener('click',()=>ask(b.dataset.q)));status();})();</script>
        <?php return ob_get_clean();
    }

    public static function communications(){ return self::render_file('communications'); }
    public static function cnc_dashboard(){ return self::render_file('cnc_dashboard'); }

    public static function seller_register(){ return self::render_file('seller_register'); }
    public static function tracking_public(){ return self::render_file('tracking_public'); }

}
