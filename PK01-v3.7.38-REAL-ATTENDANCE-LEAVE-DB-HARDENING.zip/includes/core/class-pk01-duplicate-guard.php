<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Duplicate Entry Guard.
 * Menjaga satu sumber transaksi agar submit ulang/replay tidak membuat record bisnis kedua.
 * Guard ini tidak menghapus data lama dan tidak menganggap record identik selalu salah;
 * hanya natural key yang didefinisikan modul yang dikunci.
 */
class PK01_Duplicate_Guard {
    public static function init() {}

    public static function claim($domain, $natural_key, $payload = []) {
        global $wpdb;
        $domain = sanitize_key((string)$domain);
        $natural_key = substr(sanitize_text_field((string)$natural_key), 0, 190);
        if ($domain === '' || $natural_key === '') return true;
        $t = PK01_DB::t('entry_guards');
        if (!$t) return true;
        $hash = hash('sha256', $domain.'|'.$natural_key);
        $now = current_time('mysql');
        $ok = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO `{$t}` (domain_key,natural_key,natural_hash,payload_json,created_by,created_at) VALUES (%s,%s,%s,%s,%d,%s)",
            $domain,$natural_key,$hash,wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),get_current_user_id(),$now
        ));
        if ($ok === 1) return true;
        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM `{$t}` WHERE natural_hash=%s LIMIT 1",$hash),ARRAY_A);
        $id = (int)($existing['id'] ?? 0);
        if (class_exists('PK01_Audit')) PK01_Audit::info('duplicate_entry_blocked','system','entry_guard',(string)$id,'Input/transaksi duplikat ditolak',['domain'=>$domain,'natural_key'=>$natural_key]);
        throw new Exception('Data sudah pernah dicatat. Sistem menolak input duplikat agar laporan, stok, kas, komisi, dan upah tidak berlipat.');
    }

    public static function release($domain,$natural_key) {
        global $wpdb;
        $t=PK01_DB::t('entry_guards'); if(!$t) return;
        $hash=hash('sha256',sanitize_key((string)$domain).'|'.substr(sanitize_text_field((string)$natural_key),0,190));
        $wpdb->delete($t,['natural_hash'=>$hash],['%s']);
    }
}
