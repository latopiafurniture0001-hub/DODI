<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Backup, Restore & Disaster Recovery Engine
 * Menangani pencadangan database terisolasi, restorasi aman tanpa merusak WP Core, 
 * kompresi ZIP ber-manifest, dan pembersihan siklus retensi otomatis.
 */
class PK01_Backup {

    /**
     * Inisialisasi Hook Jadwal Cron & Pembersihan Otomatis
     */
    public static function init() {
        // Jadwal Backup Otomatis via WP-Cron
        add_action('pk01_scheduled_backup_event', [__CLASS__, 'run_scheduled_backup']);
        
        // Daftarkan event jika fitur backup aktif di pengaturan
        if (!wp_next_scheduled('pk01_scheduled_backup_event')) {
            wp_schedule_event(time(), 'daily', 'pk01_scheduled_backup_event');
        }
    }

    /**
     * Dapatkan Direktori Penyimpanan Backup Aman
     */
    public static function get_backup_dir() {
        $uploads = wp_upload_dir();
        $dir = trailingslashit($uploads['basedir']) . 'pk01-backups/';

        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
            // Proteksi Directory Listing & Akses Ilegal via .htaccess
            @file_put_contents($dir . '.htaccess', "Order Deny,Allow\nDeny from all\n");
            @file_put_contents($dir . 'index.php', "<?php // Silence is golden.");
        }

        return $dir;
    }

    /**
     * Deteksi Seluruh Tabel Database yang Dimiliki Sistem PK01
     */
    public static function get_tables_to_backup() {
        global $wpdb;
        $prefix = $wpdb->prefix . 'pk01_';
        $tables = $wpdb->get_col($wpdb->prepare("SHOW TABLES LIKE %s", $prefix . '%')) ?: [];

        // Tambahkan tabel khusus jika menggunakan penamaan manual
        $extra_tables = [
            $wpdb->prefix . 'pk01_settings',
            $wpdb->prefix . 'pk01_activity_logs',
            $wpdb->prefix . 'pk01_logs'
        ];

        foreach ($extra_tables as $ext) {
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $ext)) === $ext) {
                if (!in_array($ext, $tables, true)) {
                    $tables[] = $ext;
                }
            }
        }

        return array_unique($tables);
    }

    /**
     * GENERATOR UTAMA: BUAT FILE CADANGAN DATABASE (.ZIP)
     */
    public static function generate($is_auto = false) {
        global $wpdb;

        if (!class_exists('ZipArchive')) {
            return new WP_Error('no_zip', 'Ekstensi PHP ZipArchive tidak aktif pada server hosting.');
        }

        $tables = self::get_tables_to_backup();
        if (empty($tables)) {
            return new WP_Error('empty_db', 'Tidak ada tabel data operasional PK01 yang ditemukan untuk dicadangkan.');
        }

        $dir = self::get_backup_dir();
        $timestamp = current_time('Y-m-d_His');
        $backup_code = wp_generate_password(6, false, false);
        $zip_filename = "PK01_Backup_{$timestamp}_{$backup_code}.zip";
        $zip_path = $dir . $zip_filename;

        // Folder Sementara untuk Dump
        $temp_dir = $dir . 'temp_' . $backup_code . '/';
        wp_mkdir_p($temp_dir);

        $sql_file = $temp_dir . 'database_pk01.sql';
        $fh = fopen($sql_file, 'wb');
        if (!$fh) {
            return new WP_Error('fs_error', 'Gagal membuat file penampung SQL sementara di server.');
        }

        // Header SQL Dump Aman
        fwrite($fh, "-- PK01 Enterprise Database Backup Dump\n");
        fwrite($fh, "-- Tanggal Dibuat: " . current_time('mysql') . " WIB\n");
        fwrite($fh, "-- Domain: " . home_url() . "\n");
        fwrite($fh, "-- Engine Version: " . (defined('PK01_VERSION') ? PK01_VERSION : '2.0.0') . "\n\n");
        fwrite($fh, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($fh, "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n");
        fwrite($fh, "SET NAMES utf8mb4;\n\n");

        $table_counts = [];

        // Dump Setiap Tabel PK01 secara Berurutan
        foreach ($tables as $table) {
            // 1. Ambil Skema Tabel (CREATE TABLE)
            $create_stmt = $wpdb->get_row("SHOW CREATE TABLE `{$table}`", ARRAY_N);
            if (!empty($create_stmt[1])) {
                fwrite($fh, "DROP TABLE IF EXISTS `{$table}`;\n");
                fwrite($fh, $create_stmt[1] . ";\n\n");
            }

            // 2. Dump Data Baris dengan Sistem Chunking (Mencegah Memory Exhaustion)
            $total_rows = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$table}`");
            $table_counts[$table] = $total_rows;

            $chunk_size = 500;
            $offset = 0;

            while ($offset < $total_rows) {
                $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM `{$table}` LIMIT %d OFFSET %d", $chunk_size, $offset), ARRAY_A);
                if (!empty($rows)) {
                    foreach ($rows as $row) {
                        $keys = array_map(function($k) { return "`" . esc_sql($k) . "`"; }, array_keys($row));
                        $vals = array_map(function($v) use ($wpdb) {
                            if ($v === null) return 'NULL';
                            return "'" . esc_sql($v) . "'";
                        }, array_values($row));

                        fwrite($fh, "INSERT INTO `{$table}` (" . implode(',', $keys) . ") VALUES (" . implode(',', $vals) . ");\n");
                    }
                }
                $offset += $chunk_size;
            }

            fwrite($fh, "\n");
        }

        fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fh);

        // 3. Tulis Metadata Manifest JSON
        $manifest = [
            'software'     => 'PK01 Operational Engine',
            'version'      => defined('PK01_VERSION') ? PK01_VERSION : '2.0.0',
            'created_at'   => current_time('mysql'),
            'type'         => $is_auto ? 'automatic' : 'manual',
            'created_by'   => get_current_user_id(),
            'site_url'     => home_url(),
            'table_prefix' => $wpdb->prefix,
            'table_counts' => $table_counts
        ];
        @file_put_contents($temp_dir . 'manifest.json', wp_json_encode($manifest, JSON_PRETTY_PRINT));

        // 4. Kompresi Menjadi File ZIP
        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            self::cleanup_temp($temp_dir);
            return new WP_Error('zip_error', 'Gagal membungkus file ke dalam arsip ZIP.');
        }

        $zip->addFile($sql_file, 'database_pk01.sql');
        $zip->addFile($temp_dir . 'manifest.json', 'manifest.json');
        $zip->close();

        // Bersihkan File Sementara
        self::cleanup_temp($temp_dir);

        $filesize = file_exists($zip_path) ? filesize($zip_path) : 0;

        // Jabat Tangan ke Audit Trail
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
            PK01_Audit::write('backup_created', 'backup', 'snapshot', $zip_filename, null, [
                'type'   => $is_auto ? 'Otomatis' : 'Manual',
                'size'   => size_format($filesize),
                'tables' => count($tables)
            ], 'Cadangan basis data berhasil dibuat.', 'SUCCESS');
        }

        // Jalankan Pembersihan Retensi Lama
        self::enforce_retention_policy();

        return [
            'success'   => true,
            'filename'  => $zip_filename,
            'path'      => $zip_path,
            'size'      => $filesize,
            'size_fmt'  => size_format($filesize),
            'tables'    => count($tables),
            'created_at'=> $timestamp
        ];
    }

    /**
     * RESTORASI AMAN: PULIHKAN BASIS DATA DARI FILE ZIP (.ZIP)
     */
    public static function restore($zip_file_path) {
        global $wpdb;

        if (!current_user_can('manage_options')) {
            return new WP_Error('forbidden', 'Anda tidak memiliki hak otorisasi untuk memulihkan database.');
        }

        if (!file_exists($zip_file_path)) {
            return new WP_Error('not_found', 'File arsip cadangan tidak ditemukan di server.');
        }

        if (!class_exists('ZipArchive')) {
            return new WP_Error('no_zip', 'Ekstensi PHP ZipArchive tidak aktif.');
        }

        $dir = self::get_backup_dir();
        $temp_restore_dir = $dir . 'restore_' . wp_generate_password(6, false, false) . '/';
        wp_mkdir_p($temp_restore_dir);

        $zip = new ZipArchive();
        if ($zip->open($zip_file_path) !== true) {
            self::cleanup_temp($temp_restore_dir);
            return new WP_Error('bad_zip', 'File ZIP cadangan rusak atau tidak valid.');
        }

        $zip->extractTo($temp_restore_dir);
        $zip->close();

        // 1. Validasi Manifest
        $manifest_file = $temp_restore_dir . 'manifest.json';
        if (!file_exists($manifest_file)) {
            self::cleanup_temp($temp_restore_dir);
            return new WP_Error('invalid_backup', 'File arsip bukan cadangan resmi PK01 (manifest.json tidak ditemukan).');
        }

        $sql_file = $temp_restore_dir . 'database_pk01.sql';
        if (!file_exists($sql_file)) {
            self::cleanup_temp($temp_restore_dir);
            return new WP_Error('missing_sql', 'File SQL database tidak ditemukan dalam arsip cadangan.');
        }

        // 2. Eksekusi Restorasi SQL dengan Aman
        $wpdb->query("SET FOREIGN_KEY_CHECKS=0;");
        $wpdb->query("SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';");

        $sql_content = file_get_contents($sql_file);
        $statements = explode(";\n", $sql_content);

        $success_count = 0;
        foreach ($statements as $stmt) {
            $trimmed = trim($stmt);
            if (!empty($trimmed) && !strpos($trimmed, '--') === 0) {
                $res = $wpdb->query($trimmed);
                if ($res !== false) {
                    $success_count++;
                }
            }
        }

        $wpdb->query("SET FOREIGN_KEY_CHECKS=1;");

        // Bersihkan Folder Restore
        self::cleanup_temp($temp_restore_dir);

        // Jabat Tangan ke Audit Trail
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
            PK01_Audit::write('backup_restored', 'backup', 'database', basename($zip_file_path), null, null, 'Pemulihan data operasional selesai dijalankan.', 'SUCCESS');
        }

        return [
            'success'    => true,
            'message'    => "Basis data PK01 berhasil dipulihkan ({$success_count} pernyataan query dieksekusi).",
            'restored_at'=> current_time('mysql')
        ];
    }

    /**
     * Dapatkan Daftar Seluruh File Backup yang Tersimpan
     */
    public static function list_backups() {
        $dir = self::get_backup_dir();
        $files = glob($dir . 'PK01_Backup_*.zip') ?: [];
        $list = [];

        foreach ($files as $file) {
            $filename = basename($file);
            $size = filesize($file);
            $date = date('Y-m-d H:i:s', filemtime($file));

            $list[] = [
                'filename' => $filename,
                'path'     => $file,
                'size'     => size_format($size),
                'bytes'    => $size,
                'date'     => $date,
                'date_fmt' => date_i18n('d F Y, H:i', strtotime($date))
            ];
        }

        // Urutkan dari yang paling baru
        usort($list, function($a, $b) {
            return strtotime($b['date']) <=> strtotime($a['date']);
        });

        return $list;
    }

    /**
     * Hapus Satu File Backup Spesifik
     */
    public static function delete_backup($filename) {
        $filename = sanitize_file_name($filename);
        $dir = self::get_backup_dir();
        $path = $dir . $filename;

        if (file_exists($path) && substr($filename, -4) === '.zip') {
            @unlink($path);

            if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
                PK01_Audit::write('backup_deleted', 'backup', 'file', $filename, null, null, 'File cadangan dihapus oleh admin.', 'SUCCESS');
            }
            return true;
        }

        return false;
    }

    /**
     * Eksekusi Otomatis Berdasarkan Batas Retensi Hari
     */
    public static function enforce_retention_policy() {
        $central_settings = (array) get_option('pk01_settings', []);
        $retention_days = max(7, min(365, (int)($central_settings['backup_retention'] ?? 30)));

        $backups = self::list_backups();
        $threshold = time() - ($retention_days * DAY_IN_SECONDS);

        foreach ($backups as $b) {
            if (strtotime($b['date']) < $threshold) {
                @unlink($b['path']);
            }
        }
    }

    /**
     * Eksekusi Terjadwal via WP-Cron
     */
    public static function run_scheduled_backup() {
        $central_settings = (array) get_option('pk01_settings', []);
        $auto_enabled = !empty($central_settings['backup_auto_enabled']);

        if ($auto_enabled) {
            self::generate(true);
        }
    }

    /**
     * Helper Hapus Folder Sementara
     */
    private static function cleanup_temp($dir) {
        if (!is_dir($dir)) return;
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            if (is_dir($path)) {
                self::cleanup_temp($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }
}

// Inisialisasi Engine Backup
