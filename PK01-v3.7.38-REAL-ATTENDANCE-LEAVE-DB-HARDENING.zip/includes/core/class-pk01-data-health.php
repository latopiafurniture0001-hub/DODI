<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Data Health & Integrity Diagnostic Engine
 * Pengawas kesehatan struktur database, konsistensi relasi data (Foreign Keys), 
 * audit integritas finansial, serta pemulihan skema aman otomatis (Safe dbDelta Repair).
 */
class PK01_Data_Health {

    public static function init() {}

    /**
     * 1. SPESIFIKASI LENGKAP STRUKTUR TABEL SISTEM PK01
     * Mencakup seluruh kolom wajib di setiap modul operasional.
     */
    public static function table_specs() {
        return array(
            // Produk & Katalog
            'products'                 => array('id', 'code', 'name', 'status', 'category', 'created_at', 'updated_at'),
            'product_variants'         => array('id', 'product_id', 'sku', 'name', 'hpp', 'price', 'status', 'created_at'),
            'product_gallery'          => array('id', 'product_id', 'attachment_id'),
            'pricing'                  => array('id', 'sku', 'name', 'hpp', 'price', 'margin_percent', 'status', 'valid_from'),

            // Gudang & Material
            'materials'                => array('id', 'code', 'name', 'unit', 'cost', 'stock', 'min_stock', 'supplier_id'),
            'suppliers'                => array('id', 'code', 'name', 'status'),
            'purchase_orders'          => array('id', 'po_no', 'supplier_id', 'status', 'total'),
            'purchase_order_items'     => array('id', 'po_id', 'material_id', 'qty', 'unit_cost'),
            'stock_transactions'       => array('id', 'stock_type', 'item_id', 'qty', 'direction', 'created_at'),

            // Manufaktur & Job Produksi
            'jobs'                     => array('id', 'job_no', 'deadline', 'status', 'target_qty', 'product_id', 'production_date', 'priority', 'instructions', 'spec_snapshot'),
            'job_items'                => array('id', 'job_id', 'variant_id', 'qty'),
            'job_assignments'          => array('id', 'job_id', 'employee_id', 'status'),
            'job_materials'            => array('id', 'job_id', 'material_id', 'issued_qty', 'used_qty'),
            'production_results'       => array('id', 'production_code', 'job_id', 'good_qty', 'reject_qty', 'status'),
            'job_completion_reports'=> array('id', 'assignment_id', 'job_id', 'employee_id', 'good_qty', 'reject_qty', 'photo_ids'),
            'job_wage_payments'    => array('id', 'job_wage_id', 'amount', 'paid_at'),

            // SDM & Penggajian
            'employees'                => array('id', 'code', 'name', 'position', 'division', 'pay_type', 'rate', 'status'),
            'employee_piece_rates'     => array('id', 'employee_id', 'job_name', 'rate', 'unit'),
            'payroll'                  => array('id', 'employee_id', 'period', 'amount', 'status', 'paid_at'),

            // Penjualan, Kasir & Marketplace
            'sales_orders'             => array('id', 'order_no', 'invoice_no', 'channel', 'customer_name', 'variant_id', 'qty', 'price', 'hpp', 'total_amount', 'payment_status', 'paid_amount', 'deposit_amount', 'status', 'shipping_status', 'tracking_no', 'created_at'),
            'marketplace_payouts'      => array('id', 'payout_no', 'channel_id', 'payout_date', 'gross', 'deductions', 'net_received', 'status'),
            
            // Mitra Seller & Afiliasi
            'sales_accounts'           => array('id', 'code', 'name', 'type', 'commission_percent', 'affiliate_percent', 'active'),
            'seller_orders'            => array('id', 'order_no', 'seller_account_id', 'status'),
            'seller_invoices'          => array('id', 'seller_account_id', 'total', 'status'),
            'seller_payments'          => array('id', 'invoice_id', 'amount', 'paid_at'),
            'seller_affiliate_ledger'  => array('id', 'seller_account_id', 'order_id', 'commission_amount', 'status'),
            'affiliate_links'          => array('id', 'seller_account_id', 'variant_id', 'affiliate_code', 'clicks', 'active'),
            'affiliate_attributions'   => array('id', 'affiliate_link_id', 'visit_key', 'status'),

            // Keuangan & Buku Kas
            'operational_costs'        => array('id', 'category', 'amount', 'cost_date'),
            'cash_ledger'              => array('id', 'direction', 'amount', 'account', 'category', 'created_at'),

            // Logistik & Pengiriman
            'shipments'                => array('id', 'tracking_no', 'courier', 'status', 'recipient_name', 'destination'),
            'goods_receipts'            => array('id', 'receipt_no', 'po_id', 'material_id', 'qty', 'received_at'),
            'job_items'                 => array('id', 'job_id', 'variant_id', 'qty'),
            'job_assignments'           => array('id', 'job_id', 'employee_id', 'status'),
            'job_materials'             => array('id', 'job_id', 'material_id', 'issued_qty', 'used_qty', 'returned_qty'),
            'production_results'        => array('id', 'job_id', 'good_qty', 'reject_qty', 'status'),
            'job_completion_reports' => array('id', 'assignment_id', 'job_id', 'employee_id', 'good_qty', 'reject_qty', 'photo_ids'),
            'job_wage_payments'      => array('id', 'job_wage_id', 'amount', 'paid_at'),
            'production_units'          => array('id', 'job_id', 'variant_id', 'production_code', 'unit_no', 'unit_id', 'cnc_code', 'batch_no', 'status'),
            'customers'                 => array('id', 'code', 'name', 'phone', 'email', 'status'),
            'sales_order_items'         => array('id', 'order_id', 'variant_id', 'qty', 'unit_price', 'hpp', 'total'),
            'purchase_orders'           => array('id', 'po_no', 'supplier_id', 'status', 'total', 'payment_status'),
            'purchase_order_items'      => array('id', 'po_id', 'material_id', 'qty', 'unit_cost'),
            'stock_transactions'        => array('id', 'stock_type', 'item_id', 'qty', 'direction', 'reference_type', 'created_at'),
            'seller_orders'             => array('id', 'order_no', 'seller_account_id', 'status', 'total'),
            'seller_order_items'        => array('id', 'order_id', 'variant_id', 'qty', 'unit_price'),
            'seller_invoices'           => array('id', 'seller_account_id', 'total', 'status'),
            'seller_payments'           => array('id', 'invoice_id', 'amount', 'paid_at'),
            'seller_sales'              => array('id', 'seller_account_id', 'order_id', 'qty', 'hpp', 'total', 'sold_at'),
            'affiliate_links'           => array('id', 'seller_account_id', 'variant_id', 'affiliate_code', 'clicks', 'active'),
            'affiliate_attributions'    => array('id', 'affiliate_link_id', 'visit_key', 'order_id', 'status'),
            'returns'                   => array('id', 'return_no', 'order_id', 'refund_amount', 'status', 'created_at'),
            'return_items'              => array('id', 'return_id', 'variant_id', 'qty'),
            'tracking_events'           => array('id', 'shipment_id', 'status', 'event_time'),
            'shipment_alerts'           => array('id', 'shipment_id', 'alert_type', 'status'),
            'capital_transactions'      => array('id', 'amount', 'source', 'created_at'),
            'idempotency_keys'          => array('id', 'idempotency_key', 'action', 'request_hash', 'status', 'expires_at'),

            // Audit Trail & Logs
            'activity_logs'            => array('id', 'action', 'module', 'level', 'timestamp')
        );
    }

    private static function issue($module, $type, $severity, $message, $data = array(), $repair = null) {
        return array(
            'module'   => $module,
            'type'     => $type,
            'severity' => strtoupper($severity), // CRITICAL, HIGH, MEDIUM, LOW, INFO
            'message'  => $message,
            'data'     => $data,
            'repair'   => $repair
        );
    }

    /**
     * 2. PEMERIKSAAN KESEHATAN MENYELURUH (COMPREHENSIVE HEALTH CHECK)
     */
    public static function check() {
        global $wpdb;
        
        $issues  = array();
        $checked = 0;
        $healthy = 0;

        // Ambil daftar seluruh tabel di database sekali jalan untuk hemat memori
        $existing_tables = $wpdb->get_col("SHOW TABLES") ?: array();

        // A. PEMERIKSAAN TABEL & KOLOM FISIK
        foreach (self::table_specs() as $key => $columns) {
            $table = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
            $checked++;

            if (!in_array($table, $existing_tables, true)) {
                $issues[] = self::issue('database', 'missing_table', 'CRITICAL', "Tabel database `{$table}` belum terpasang di database.", array('table' => $table), 'schema');
                continue;
            }

            $actual_cols = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0) ?: array();
            $missing = array_values(array_diff($columns, $actual_cols));

            if (!empty($missing)) {
                $issues[] = self::issue($key, 'missing_column', 'HIGH', "Kolom penting pada tabel `{$table}` belum lengkap.", array('table' => $table, 'columns' => $missing), 'schema');
            } else {
                $healthy++;
            }
        }

        // B. PEMERIKSAAN DATA WAJIB KOSONG (MISSING REQUIRED DATA)
        $required_checks = array(
            array('products', 'code', 'Produk tanpa kode', 'HIGH'),
            array('products', 'name', 'Produk tanpa nama barang', 'MEDIUM'),
            array('materials', 'name', 'Bahan baku tanpa nama', 'HIGH'),
            array('jobs', 'job_no', 'Job produksi tanpa nomor SPK', 'HIGH'),
            array('employees', 'name', 'Karyawan tanpa nama lengkap', 'MEDIUM'),
            array('sales_orders', 'order_no', 'Pesanan tanpa nomor faktur', 'HIGH'),
        );

        foreach ($required_checks as $rc) {
            $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($rc[0]) : $wpdb->prefix . 'pk01_' . $rc[0];
            if (!in_array($t, $existing_tables, true)) continue;

            $cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}` WHERE `{$rc[1]}` IS NULL OR TRIM(`{$rc[1]}`) = ''");
            if ($cnt > 0) {
                $issues[] = self::issue($rc[0], 'missing_required', $rc[3], "Ditemukan {$cnt} data pada {$rc[2]}.", array('column' => $rc[1], 'count' => $cnt));
            }
        }

        // C. PEMERIKSAAN DATA DUPLIKAT (DUPLICATE DETECTOR)
        $dupe_checks = array(
            array('products', 'code', 'Kode Produk (Harus Unik)'),
            array('product_variants', 'sku', 'Kode SKU Varian'),
            array('jobs', 'job_no', 'Nomor SPK Produksi'),
            array('sales_orders', 'order_no', 'Nomor Faktur Pesanan'),
            array('employees', 'code', 'Kode Karyawan'),
        );

        foreach ($dupe_checks as $dc) {
            $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($dc[0]) : $wpdb->prefix . 'pk01_' . $dc[0];
            if (!in_array($t, $existing_tables, true)) continue;

            $dupes = $wpdb->get_results("SELECT `{$dc[1]}` AS val, COUNT(*) AS cnt FROM `{$t}` WHERE `{$dc[1]}` IS NOT NULL AND `{$dc[1]}` != '' GROUP BY `{$dc[1]}` HAVING COUNT(*) > 1 LIMIT 10", ARRAY_A);
            if (!empty($dupes)) {
                $issues[] = self::issue($dc[0], 'duplicate', 'HIGH', "Terdapat duplikasi data pada {$dc[2]}.", array('column' => $dc[1], 'samples' => $dupes));
            }
        }

        // D. PEMERIKSAAN DATA YATIM PIATU (ORPHAN FOREIGN KEYS)
        $orphan_specs = array(
            array('product_variants', 'product_id', 'products', 'id', 'HIGH', 'Varian SKU mengarah ke induk produk yang sudah dihapus.'),
            array('employee_piece_rates', 'employee_id', 'employees', 'id', 'MEDIUM', 'Tarif borongan mengarah ke karyawan yang tidak terdaftar.'),
            array('job_items', 'job_id', 'jobs', 'id', 'HIGH', 'Rincian barang pekerjaan mengarah ke SPK yang tidak ada.'),
            array('job_assignments', 'employee_id', 'employees', 'id', 'MEDIUM', 'Penugasan job mengarah ke karyawan yang tidak ada.'),
            array('seller_orders', 'seller_account_id', 'sales_accounts', 'id', 'HIGH', 'Pesanan seller mengarah ke akun mitra yang tidak ada.'),
            array('seller_invoices', 'seller_account_id', 'sales_accounts', 'id', 'HIGH', 'Tagihan piutang mengarah ke akun seller yang tidak ada.'),
            array('seller_payments', 'invoice_id', 'seller_invoices', 'id', 'HIGH', 'Pembayaran setoran mengarah ke invoice yang tidak ada.'),
            array('seller_affiliate_ledger', 'order_id', 'sales_orders', 'id', 'HIGH', 'Catatan komisi afiliasi mengarah ke pesanan yang tidak ditemukan.')
        );

        foreach ($orphan_specs as $os) {
            $child_t  = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($os[0]) : $wpdb->prefix . 'pk01_' . $os[0];
            $parent_t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($os[2]) : $wpdb->prefix . 'pk01_' . $os[2];

            if (!in_array($child_t, $existing_tables, true) || !in_array($parent_t, $existing_tables, true)) continue;

            $orphan_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$child_t}` c LEFT JOIN `{$parent_t}` p ON p.`{$os[3]}` = c.`{$os[1]}` WHERE c.`{$os[1]}` IS NOT NULL AND c.`{$os[1]}` != 0 AND p.`{$os[3]}` IS NULL");
            if ($orphan_count > 0) {
                $issues[] = self::issue($os[0], 'orphan', $os[4], $os[5], array('count' => $orphan_count, 'column' => $os[1], 'parent' => $os[2]));
            }
        }

        // E. AUDIT INTEGRITAS BISNIS & ANOMALI KEUANGAN (ANTI-LEAKAGE CHECKS)
        
        // 1. Cek Produk Dijual di Bawah HPP (Potensi Kerugian Margin)
        $t_pv = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_variants') : $wpdb->prefix . 'pk01_product_variants';
        if (in_array($t_pv, $existing_tables, true)) {
            $loss_items = $wpdb->get_results("SELECT sku, name, hpp, price FROM `{$t_pv}` WHERE price > 0 AND price < hpp LIMIT 5", ARRAY_A);
            if (!empty($loss_items)) {
                $issues[] = self::issue('pricing', 'business_rule', 'MEDIUM', 'Ditemukan varian produk yang dijual di bawah modal HPP (Potensi Kerugian).', array('items' => $loss_items));
            }
        }

        // 2. Cek Komisi Afiliasi Aktif pada Pesanan yang Dibatalkan
        $t_led = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('seller_affiliate_ledger') : $wpdb->prefix . 'pk01_seller_affiliate_ledger';
        $t_ord = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('sales_orders') : $wpdb->prefix . 'pk01_sales_orders';
        if (in_array($t_led, $existing_tables, true) && in_array($t_ord, $existing_tables, true)) {
            $leaks = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_led}` l JOIN `{$t_ord}` o ON o.id = l.order_id WHERE l.status IN ('ready', 'paid') AND o.status IN ('cancelled', 'batal', 'failed')");
            if ($leaks > 0) {
                $issues[] = self::issue('affiliate', 'financial_leak', 'CRITICAL', "Ditemukan {$leaks} catatan komisi yang berstatus Aktif/Cair padahal status pesanan telah Dibatalkan.", array('count' => $leaks));
            }
        }

        // 3. Cek Mutasi Kas Bernilai Nol atau Minus
        $t_csh = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('cash_ledger') : $wpdb->prefix . 'pk01_cash_ledger';
        if (in_array($t_csh, $existing_tables, true)) {
            $invalid_cash = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_csh}` WHERE amount <= 0");
            if ($invalid_cash > 0) {
                $issues[] = self::issue('cash', 'data_anomaly', 'HIGH', "Ditemukan {$invalid_cash} transaksi buku kas bernilai Rp 0 atau minus.", array('count' => $invalid_cash));
            }
        }

        // 4. Cek Stok Material Gudang Bernilai Negatif
        $t_mat = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('materials') : $wpdb->prefix . 'pk01_materials';
        if (in_array($t_mat, $existing_tables, true)) {
            $negative_stock = $wpdb->get_results("SELECT code, name, stock FROM `{$t_mat}` WHERE stock < 0 LIMIT 5", ARRAY_A);
            if (!empty($negative_stock)) {
                $issues[] = self::issue('materials', 'inventory_anomaly', 'HIGH', 'Ditemukan stok bahan baku gudang bernilai negatif (Stok Minus).', array('samples' => $negative_stock));
            }
        }

        // F. KALKULASI SKOR KESEHATAN SISTEM (0 - 100%)
        $critical = $high = $medium = $low = 0;
        foreach ($issues as $issue_item) {
            $sev = strtolower($issue_item['severity']);
            if (isset($$sev)) {
                $$sev++;
            }
        }

        $penalty = ($critical * 30) + ($high * 10) + ($medium * 4) + ($low * 1);
        $score   = max(0, 100 - min(100, $penalty));

        $status = 'SEHAT';
        if ($critical > 0) {
            $status = 'BERMASALAH';
        } elseif (($high > 0 || $medium > 0)) {
            $status = 'PERLU PERHATIAN';
        }

        return array(
            'status'         => $status,
            'score'          => $score,
            'checked_at'     => current_time('mysql'),
            'tables_checked' => $checked,
            'tables_healthy' => $healthy,
            'issues'         => $issues,
            'summary'        => array(
                'critical' => $critical,
                'high'     => $high,
                'medium'   => $medium,
                'low'      => $low,
                'total'    => count($issues)
            )
        );
    }

    /**
     * Ringkasan kelengkapan DATA NYATA untuk Control Tower/Settings.
     * Tidak membuat, mengubah, atau mengisi data bisnis. Hanya menghitung baris
     * yang sudah lengkap menurut field operasional minimum yang relevan.
     */
    public static function data_completeness() {
        global $wpdb;
        $groups = array(
            'products' => array('label'=>'Produk Master','table'=>'products','required'=>array('code','name','status')),
            'variants' => array('label'=>'SKU/Varian','table'=>'product_variants','required'=>array('product_id','sku','name','status')),
            'materials' => array('label'=>'Bahan Baku','table'=>'materials','required'=>array('code','name','stock')),
            'employees' => array('label'=>'Karyawan','table'=>'employees','required'=>array('code','name','status')),
            'sellers' => array('label'=>'Mitra Seller','table'=>'sales_accounts','required'=>array('code','name','type','active')),
            'sales' => array('label'=>'Transaksi Penjualan','table'=>'sales_orders','required'=>array('order_no','variant_id','qty','total_amount','status')),
            'jobs' => array('label'=>'Job Produksi','table'=>'jobs','required'=>array('job_no','product_id','target_qty','status')),
            'cash' => array('label'=>'Mutasi Keuangan/Kas','table'=>'cash_ledger','required'=>array('direction','amount','created_at')),
        );
        $out=array();
        foreach($groups as $key=>$g){
            $table=class_exists('PK01_DB')&&method_exists('PK01_DB','t')?PK01_DB::t($g['table']):$wpdb->prefix.'pk01_'.$g['table'];
            $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))===$table;
            if(!$exists){ $out[$key]=array_merge($g,array('exists'=>false,'total'=>0,'complete'=>0,'incomplete'=>0,'percent'=>0)); continue; }
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$table}`",0)?:array();
            $required=array_values(array_intersect($g['required'],$cols));
            $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$table}`");
            if(!$required){ $complete=$total; }
            else {
                $checks=array();
                foreach($required as $c){
                    $checks[]="(`{$c}` IS NOT NULL AND TRIM(CAST(`{$c}` AS CHAR)) <> '' AND NOT (CAST(`{$c}` AS DECIMAL(30,6)) = 0 AND `{$c}` IN ('qty','total_amount','amount','target_qty','product_id')) )";
                }
                // Angka nol dapat sah pada beberapa tabel (mis. stock), sehingga untuk
                // kelengkapan kita hanya mensyaratkan NULL/string kosong; validasi bisnis
                // seperti nominal minus/nol ditangani check().
                $checks=array();
                foreach($required as $c){
                    $checks[]="(`{$c}` IS NOT NULL AND TRIM(CAST(`{$c}` AS CHAR)) <> '')";
                }
                $complete=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE ".implode(' AND ',$checks));
            }
            $incomplete=max(0,$total-$complete);
            $out[$key]=array_merge($g,array('exists'=>true,'total'=>$total,'complete'=>$complete,'incomplete'=>$incomplete,'percent'=>$total>0?round(($complete/$total)*100,1):100));
        }
        $sales_table=class_exists('PK01_DB')&&method_exists('PK01_DB','t')?PK01_DB::t('sales_orders'):$wpdb->prefix.'pk01_sales_orders';
        $jobs_table=class_exists('PK01_DB')&&method_exists('PK01_DB','t')?PK01_DB::t('jobs'):$wpdb->prefix.'pk01_jobs';
        $sales_total=$sales_valid=$sales_cancelled=0;
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$sales_table))===$sales_table){
            $sales_total=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$sales_table}`");
            $sales_valid=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$sales_table}` WHERE status NOT IN ('cancelled','batal','failed','refunded')");
            $sales_cancelled=max(0,$sales_total-$sales_valid);
        }
        $jobs_total=$jobs_active=$jobs_finished=0;
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$jobs_table))===$jobs_table){
            $jobs_total=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$jobs_table}`");
            $jobs_active=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$jobs_table}` WHERE status IN ('planned','assigned','in_progress','processing')");
            $jobs_finished=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$jobs_table}` WHERE status IN ('completed','selesai','closed')");
        }
        return array('groups'=>$out,'sales_total'=>$sales_total,'sales_valid'=>$sales_valid,'sales_cancelled'=>$sales_cancelled,'jobs_total'=>$jobs_total,'jobs_active'=>$jobs_active,'jobs_finished'=>$jobs_finished,'generated_at'=>current_time('mysql'));
    }

    public static function operational_snapshot() {
        $c=self::data_completeness();
        $r=self::last_result();
        $complete=0; $total=0;
        foreach((array)($c['groups']??array()) as $g){ $total+=(int)($g['total']??0); $complete+=(int)($g['complete']??0); }
        $c['rows_total']=$total; $c['rows_complete']=$complete; $c['rows_incomplete']=max(0,$total-$complete);
        $c['completeness_percent']=$total>0?round(($complete/$total)*100,1):100;
        $c['health_status']=$r['status']??'BELUM DIPERIKSA'; $c['health_score']=$r['score']??null;
        return $c;
    }

    /**
     * 3. PEMULIHAN SKEMA AMAN OTOMATIS (SAFE REPAIR ENGINE)
     * Menjalankan dbDelta untuk melengkapi tabel dan kolom tanpa menghapus data yang ada.
     */
    public static function repair_schema() {
        global $wpdb;
        
        if (!current_user_can('manage_options')) {
            return new WP_Error('forbidden', 'Anda tidak memiliki hak akses administrator untuk memperbaiki skema.');
        }

        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $queries = array();

        // 1. Skema Tabel-Tabel Inti PK01
        $queries[] = "CREATE TABLE `" . (class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('cash_ledger') : $wpdb->prefix . 'pk01_cash_ledger') . "` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `direction` varchar(10) NOT NULL DEFAULT 'in',
            `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
            `account` varchar(100) NOT NULL DEFAULT 'Kas Tunai Toko',
            `category` varchar(100) NOT NULL DEFAULT 'Operasional',
            `reference_no` varchar(100) DEFAULT '',
            `description` text DEFAULT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) {$charset_collate};";

        $queries[] = "CREATE TABLE `" . (class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('shipments') : $wpdb->prefix . 'pk01_shipments') . "` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `source` varchar(50) NOT NULL DEFAULT 'website',
            `tracking_no` varchar(100) NOT NULL,
            `courier` varchar(50) NOT NULL,
            `service` varchar(50) DEFAULT 'REG',
            `sale_id` bigint(20) unsigned DEFAULT 0,
            `recipient_name` varchar(150) NOT NULL,
            `recipient_phone` varchar(50) DEFAULT '',
            `destination` text NOT NULL,
            `status` varchar(50) NOT NULL DEFAULT 'on_process',
            `last_event_at` datetime DEFAULT NULL,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) {$charset_collate};";

        $queries[] = "CREATE TABLE `" . (class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('marketplace_payouts') : $wpdb->prefix . 'pk01_marketplace_payouts') . "` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `payout_no` varchar(100) NOT NULL,
            `channel_id` varchar(50) NOT NULL DEFAULT 'shopee',
            `payout_date` date NOT NULL,
            `order_count` int(11) NOT NULL DEFAULT 1,
            `gross` decimal(15,2) NOT NULL DEFAULT 0.00,
            `deductions` decimal(15,2) NOT NULL DEFAULT 0.00,
            `net_received` decimal(15,2) NOT NULL DEFAULT 0.00,
            `account_id` varchar(100) NOT NULL DEFAULT 'BCA Resmi',
            `status` varchar(50) NOT NULL DEFAULT 'completed',
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) {$charset_collate};";

        foreach ($queries as $sql) {
            PK01_DB::dbDelta_safe($sql);
        }

        // Catat aksi ke Audit Log
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
            PK01_Audit::write('schema_repaired', 'system', 'database', '', null, null, 'Perbaikan otomatis struktur skema tabel PK01 berhasil dijalankan.', 'SUCCESS');
        }

        // Jalankan pemeriksaan ulang pasca-perbaikan
        $recheck = self::check();
        self::save_result($recheck);

        return $recheck;
    }

    public static function save_result($result) {
        update_option('pk01_health_last_result', $result, false);
        return $result;
    }

    public static function last_result() {
        $r = get_option('pk01_health_last_result', null);
        return is_array($r) ? $r : null;
    }
}

// Inisialisasi Engine Kesehatan Data
