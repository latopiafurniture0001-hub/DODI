<?php
if (!defined('ABSPATH')) exit;
if (!function_exists('pk01_load_pdf_gateway')) {
  function pk01_load_pdf_gateway() {
    static $loaded=false;
    if ($loaded) return true;
    $loaded=true;
    $file=PK01_DIR.'includes/core/pdf-gateway.php';
    if (!is_readable($file)) return false;
    require_once $file;
    return true;
  }
}
add_action('admin_post_pk01_print', function(){
  if (pk01_load_pdf_gateway() && function_exists('pk01_pdf_print_router')) pk01_pdf_print_router();
}, 1);
