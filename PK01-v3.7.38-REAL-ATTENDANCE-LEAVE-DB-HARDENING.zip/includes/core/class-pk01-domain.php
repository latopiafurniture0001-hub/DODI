<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Domain Coordinator 1.0
 *
 * Satu pintu lintas modul/role. UI tidak memiliki aturan akuntansi sendiri;
 * transaksi bisnis dikerjakan oleh Engine, sedangkan coordinator menjaga
 * konteks modul, transaksi DB, idempotensi dan rekonsiliasi.
 */
class PK01_Domain {
    private static $booted = false;

    public static function init() { self::$booted = true; }

    public static function table($key) {
        return class_exists('PK01_DB') ? PK01_DB::t($key) : '';
    }

    public static function table_exists($key) {
        global $wpdb;
        $t = self::table($key);
        return $t && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t;
    }

    public static function columns($key) {
        global $wpdb;
        $t = self::table($key);
        if (!$t || $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) return [];
        return $wpdb->get_col("SHOW COLUMNS FROM `{$t}`", 0) ?: [];
    }

    /** Jalankan unit kerja tanpa merusak transaksi luar yang sedang aktif. */
    public static function transaction(callable $callback) {
        global $wpdb;
        $active = (int)$wpdb->get_var('SELECT @@in_transaction');
        if ($active) return call_user_func($callback);
        $wpdb->query('START TRANSACTION');
        try {
            $result = call_user_func($callback);
            $wpdb->query('COMMIT');
            return $result;
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }
    }

    public static function safe_insert($table_key, array $data) {
        global $wpdb;
        $t = self::table($table_key);
        if (!$t) throw new Exception('Tabel PK01 tidak tersedia: '.$table_key);
        $cols = self::columns($table_key);
        if ($cols) $data = array_intersect_key($data, array_flip($cols));
        if (!$wpdb->insert($t, $data)) throw new Exception($wpdb->last_error ?: 'Gagal menyimpan data '.$table_key.'.');
        return (int)$wpdb->insert_id;
    }

    public static function module_context($module, $role = '') {
        $module = sanitize_key($module);
        $role = sanitize_key($role ?: (class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : ''));
        $map = [
            'sales'=>['domain'=>'commercial','writes'=>['sales_orders','sales_order_items','seller_sales'],'reads'=>['products','product_variants','customers','sales_accounts','shipments']],
            'seller'=>['domain'=>'partner','writes'=>['seller_orders','seller_order_items','seller_sales','seller_invoices','seller_payments'],'reads'=>['sales_accounts','product_variants','sales_orders','shipments']],
            'cash'=>['domain'=>'finance','writes'=>['cash_ledger'],'reads'=>['sales_orders','operational_costs','payroll','job_wages','seller_payments']],
            'finance'=>['domain'=>'finance','writes'=>['journal_entries','journal_lines','financial_periods'],'reads'=>['cash_ledger','sales_orders','operational_costs','payroll','job_wages','seller_invoices','seller_payments','marketplace_payouts']],
            'production'=>['domain'=>'production','writes'=>['jobs','job_assignments','job_materials','production_results','production_units'],'reads'=>['products','product_variants','materials','employees','job_wages']],
            'inventory'=>['domain'=>'inventory','writes'=>['materials','product_variants','stock_transactions'],'reads'=>['purchase_orders','goods_receipts','jobs','sales_orders','returns']],
            'purchase'=>['domain'=>'procurement','writes'=>['purchase_orders','purchase_order_items','goods_receipts'],'reads'=>['materials','suppliers','stock_transactions','cash_ledger']],
            'hr'=>['domain'=>'people','writes'=>['employees','payroll','payroll_components','employee_compensation_rules'],'reads'=>['job_wages']],
            'logistics'=>['domain'=>'logistics','writes'=>['shipments','tracking_events'],'reads'=>['sales_orders','seller_sales','seller_orders']],
        ];
        $ctx = $map[$module] ?? ['domain'=>'operational','writes'=>[],'reads'=>[]];
        $ctx['module']=$module; $ctx['role']=$role; return $ctx;
    }

    /** Satu panggilan setelah transaksi bisnis agar semua read-model/report melihat data yang sama. */
    public static function reconcile($from = '', $to = '') {
        $result = ['finance'=>null,'seller_ar'=>null,'issues'=>[]];
        if (class_exists('PK01_Finance')) $result['finance'] = PK01_Finance::sync($from, $to);
        if (class_exists('PK01_Engine') && method_exists('PK01_Engine','financial_integrity')) {
            $result['issues'] = PK01_Engine::financial_integrity($from, $to);
        }
        if (class_exists('PK01_Engine') && method_exists('PK01_Engine','seller_ar_summary')) {
            $result['seller_ar'] = PK01_Engine::seller_ar_summary($from, $to);
        }
        return $result;
    }
}
