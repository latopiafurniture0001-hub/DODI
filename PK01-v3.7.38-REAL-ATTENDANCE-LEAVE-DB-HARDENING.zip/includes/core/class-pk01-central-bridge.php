<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Central Control Bridge & Integration Gateway
 * Menjembatani plugin PK01 Operasional dengan PK01 Central / Eksternal Dashboard,
 * menyediakan telemetri real-time, pengawasan kesehatan sistem, REST API, dan Event Bus.
 */
class PK01_Central_Bridge {

    /**
     * Inisialisasi Hook & Filter Integrasi
     */
    public static function init() {
        add_filter('pk01_central_manifest', [__CLASS__, 'manifest']);
        add_filter('pk01_central_snapshot', [__CLASS__, 'snapshot']);
        add_filter('pk01_central_health',   [__CLASS__, 'health']);

        // Buka Endpoint REST API untuk Pemantauan Telemetri Jarak Jauh
        add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);

        // Event Listener Internal
        add_action('pk01_central_event', [__CLASS__, 'handle_dispatched_event'], 10, 1);
    }

    /**
     * 1. MANIFEST KEMAMPUAN SISTEM OPERASIONAL (CAPABILITIES MATRIX)
     */
    public static function manifest($plugins = []) {
        $plugins['pk01-operasional'] = [
            'id'              => 'pk01-operasional',
            'name'            => 'PK01 Operasional Usaha & Manufaktur',
            'version'         => defined('PK01_VERSION') ? PK01_VERSION : '2.4.0',
            'type'            => 'operational',
            'api_version'     => '2.0',
            'status'          => 'active',
            'source_of_truth' => true,
            'integration'     => 'native',
            'capabilities'    => [
                'products', 'variants', 'hpp', 'pricing', 'orders', 'sales_pos',
                'production_jobs', 'materials_inventory', 'suppliers', 'customers',
                'sellers', 'affiliate_tracking', 'marketplace_settlement',
                'operational_costs', 'cash_ledger', 'payroll', 'shipping_tracker',
                'disaster_recovery_backup', 'ai_assistant', 'forensic_audit'
            ],
            'endpoints'       => [
                'telemetry' => rest_url('pk01/v1/telemetry'),
                'health'    => rest_url('pk01/v1/health')
            ],
            'server_specs'    => [
                'php_version'   => PHP_VERSION,
                'wp_version'    => get_bloginfo('version'),
                'memory_limit'  => ini_get('memory_limit'),
                'max_exec_time' => ini_get('max_execution_time') . 's'
            ]
        ];
        return $plugins;
    }

    /**
     * 2. SNAPSHOT OPERASIONAL RIIL (REAL BUSINESS TELEMETRY)
     * Menghimpun angka statistik fakta dari seluruh modul database tanpa data palsu.
     */
    public static function snapshot($snapshots = []) {
        global $wpdb;

        $cur_month = current_time('Y-m');

        // Helper Tabel
        $tbl = function($k) use ($wpdb) {
            $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
            return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) ? $t : false;
        };

        $t_orders  = $tbl('sales_orders') ?: $tbl('orders');
        $t_costs   = $tbl('operational_costs');
        $t_cash    = $tbl('cash_ledger');
        $t_mat     = $tbl('materials');
        $t_jobs    = $tbl('jobs') ?: $tbl('production_jobs');
        $t_ship    = $tbl('shipments');
        $t_sellers = $tbl('sales_accounts') ?: $tbl('sellers');

        // Kueri Ringkasan Bisnis
        $omzet = $t_orders ? (float) $wpdb->get_var($wpdb->prepare("SELECT SUM(total_amount) FROM `{$t_orders}` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal')", $cur_month)) : 0;
        $biaya = $t_costs ? (float) $wpdb->get_var($wpdb->prepare("SELECT SUM(amount) FROM `{$t_costs}` WHERE DATE_FORMAT(cost_date, '%%Y-%%m') = %s", $cur_month)) : 0;
        $saldo = $t_cash ? (float) $wpdb->get_var("SELECT SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END) FROM `{$t_cash}`") : 0;
        $mat_kritis = $t_mat ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_mat}` WHERE stock <= min_stock") : 0;
        $job_aktif = $t_jobs ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_jobs}` WHERE status NOT IN ('completed', 'selesai', 'cancelled')") : 0;
        $ship_aktif = $t_ship ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_ship}` WHERE status IN ('on_process', 'dikirim')") : 0;
        $seller_pending = $t_sellers ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_sellers}` WHERE registration_status = 'pending'") : 0;

        $telemetry_data = [
            'financial' => [
                'monthly_omzet'     => $omzet,
                'monthly_expense'   => $biaya,
                'net_profit_est'    => $omzet - $biaya,
                'real_cash_balance' => $saldo,
                'currency'          => 'IDR'
            ],
            'operations' => [
                'critical_materials' => $mat_kritis,
                'active_jobs'        => $job_aktif,
                'active_shipments'   => $ship_aktif,
                'pending_sellers'    => $seller_pending
            ],
            'contract_status' => self::verify_contract()
        ];

        $snapshots['pk01-operasional'] = [
            'plugin_id'    => 'pk01-operasional',
            'generated_at' => current_time('mysql'),
            'status'       => 'online',
            'data'         => $telemetry_data
        ];

        return $snapshots;
    }

    /**
     * 3. PENGAWAS KESEHATAN FISIK SISTEM (REAL DIAGNOSTIC HEALTH CHECK)
     * Menguji database riil, status folder upload, dan dependensi server.
     */
    public static function health($health = []) {
        global $wpdb;

        $issues = [];
        $tables_checked = 0;

        // Cek Tabel Kritis
        $critical_tables = [
            'materials', 'operational_costs', 'cash_ledger', 'sales_accounts',
            'activity_logs', 'product_variants'
        ];

        foreach ($critical_tables as $tbl_key) {
            $tables_checked++;
            $t_name = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($tbl_key) : $wpdb->prefix . 'pk01_' . $tbl_key;
            $exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_name)) === $t_name);
            if (!$exists) {
                $issues[] = "Tabel kritis `{$t_name}` belum terpasang di database.";
            }
        }

        // Cek Folder Backup & Upload
        $uploads = wp_upload_dir();
        if (!wp_is_writable($uploads['basedir'])) {
            $issues[] = "Direktori WordPress Uploads tidak dapat ditulisi (Read-Only).";
        }

        // Cek Ekstensi Server Kritis
        if (!class_exists('ZipArchive')) {
            $issues[] = "Ekstensi PHP ZipArchive tidak aktif (Backup & Export terganggu).";
        }
        if (!function_exists('curl_version')) {
            $issues[] = "Ekstensi PHP cURL tidak aktif (API Ekspedisi & AI terganggu).";
        }

        // Tentukan Status Riil
        $status = 'HEALTHY';
        if (count($issues) > 2) {
            $status = 'CRITICAL';
        } elseif (count($issues) > 0) {
            $status = 'WARNING';
        }

        $health['pk01-operasional'] = [
            'plugin_id'      => 'pk01-operasional',
            'status'         => $status,
            'score'          => max(0, 100 - (count($issues) * 20)),
            'checked_at'     => current_time('mysql'),
            'tables_checked' => $tables_checked,
            'issues_count'   => count($issues),
            'issues'         => $issues,
            'version'        => defined('PK01_VERSION') ? PK01_VERSION : '2.4.0'
        ];

        return $health;
    }

    /**
     * 4. DAFTARKAN ROUTE REST API UNTUK AKSES TELEMETRI PUSAT (API GATEWAY)
     */
    public static function register_rest_routes() {
        register_rest_route('pk01/v1', '/telemetry', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'rest_telemetry_callback'],
            'permission_callback' => [__CLASS__, 'rest_permission_check']
        ]);

        register_rest_route('pk01/v1', '/health', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'rest_health_callback'],
            'permission_callback' => [__CLASS__, 'rest_permission_check']
        ]);
    }

    /**
     * Proteksi Autentikasi REST API (Bearer Token / Manage Options)
     */
    public static function rest_permission_check($request) {
        if (current_user_can('manage_options')) return true;

        $auth_header = $request->get_header('Authorization');
        $saved_secret = get_option('pk01_central_api_token', '');

        if (!empty($saved_secret) && !empty($auth_header)) {
            $token = trim(str_replace('Bearer', '', $auth_header));
            return hash_equals($saved_secret, $token);
        }

        return false;
    }

    public static function rest_telemetry_callback() {
        $snap = self::snapshot([]);
        return rest_ensure_response($snap['pk01-operasional'] ?? []);
    }

    public static function rest_health_callback() {
        $hl = self::health([]);
        return rest_ensure_response($hl['pk01-operasional'] ?? []);
    }

    /**
     * 5. EVENT BUS DISPATCHER (PENGIRIM EVENT AKTIF KE AUDIT & WEBHOOK)
     */
    public static function emit($event, $payload = []) {
        $event_data = [
            'source'     => 'pk01-operasional',
            'event'      => sanitize_key($event),
            'payload'    => $payload,
            'created_at' => current_time('mysql')
        ];

        // Jalankan Action Lokal
        do_action('pk01_central_event', $event_data);

        // Jika Pengaturan Webhook URL Pusat Diaktifkan, Kirim Async HTTP Post
        $webhook_url = get_option('pk01_central_webhook_url', '');
        if (!empty($webhook_url) && filter_var($webhook_url, FILTER_VALIDATE_URL)) {
            wp_remote_post($webhook_url, [
                'timeout'   => 5,
                'blocking'  => false, // Non-blocking agar proses kasir/order tidak lambat
                'headers'   => [
                    'Content-Type' => 'application/json',
                    'X-PK01-Event' => sanitize_key($event)
                ],
                'body'      => wp_json_encode($event_data)
            ]);
        }
    }

    /**
     * Listener Internal Saat Ada Event Baru Dipancarkan
     */
    public static function handle_dispatched_event($event_data) {
        // Otomatis sinkronkan event penting ke Audit Log jika relevan
        $ev = $event_data['event'] ?? '';
        if (strpos($ev, 'security_') === 0 || strpos($ev, 'system_') === 0) {
            if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'write')) {
                PK01_Audit::write(
                    $ev,
                    'bridge',
                    'event_bus',
                    '',
                    null,
                    $event_data['payload'] ?? null,
                    'Event dipancarkan melalui PK01_Central_Bridge',
                    'SUCCESS',
                    'bridge'
                );
            }
        }
    }

    /**
     * 6. KONTRAK INTEGRASI & PEMERIKSAAN KELENGKAPAN KELAS INTI
     */
    public static function contract() {
        return [
            'settings'                     => 'PK01_Settings',
            'engine'                       => 'PK01_Engine',
            'database'                     => 'PK01_DB',
            'audit'                        => 'PK01_Audit',
            'backup'                       => 'PK01_Backup',
            'authorization'                => 'PK01_Authorization',
            'ai'                           => 'PK01_AI',
            'real_data_only'               => true,
            'single_settings_source'       => true,
            'modules_must_use_shared_engine'=> true
        ];
    }

    /**
     * Verifikasi Kesiapan Seluruh Kelas Arsitektur Inti di Memori Server
     */
    public static function verify_contract() {
        $contracts = self::contract();
        $report = [];
        $all_ok = true;

        foreach ($contracts as $key => $class_name) {
            if (is_string($class_name)) {
                $is_loaded = class_exists($class_name);
                $report[$key] = [
                    'class'  => $class_name,
                    'loaded' => $is_loaded
                ];
                if (!$is_loaded) $all_ok = false;
            }
        }

        return [
            'compliant' => $all_ok,
            'details'   => $report
        ];
    }

    /**
     * Helper Konfigurasi Cepat
     */
    public static function config($key, $default = null) {
        return class_exists('PK01_Settings') ? PK01_Settings::get($key, $default) : $default;
    }

    public static function settings_group($group) {
        return class_exists('PK01_Settings') ? PK01_Settings::get_group($group) : [];
    }
}

// Inisialisasi Bridge PK01
