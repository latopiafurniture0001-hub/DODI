<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Application Kernel 1.0
 * Fondasi aplikasi: request context, command boundary, domain events,
 * invariant checks, transaction helper, dan health metadata.
 * Tidak menggantikan Engine lama; menjadi lapisan pengaman di depannya.
 */
class PK01_Kernel {
    private static $request_id = '';
    private static $booted = false;

    public static function init() {
        if (self::$booted) return;
        self::$booted = true;
        self::$request_id = self::make_request_id();
        add_action('shutdown', [__CLASS__, 'shutdown'], 999);
    }

    public static function request_id() {
        if (!self::$request_id) self::$request_id = self::make_request_id();
        return self::$request_id;
    }

    private static function make_request_id() {
        return substr(hash('sha256', wp_generate_uuid4() . '|' . microtime(true)), 0, 32);
    }

    public static function actor() {
        $uid = get_current_user_id();
        $u = $uid ? get_userdata($uid) : null;
        return [
            'user_id' => (int)$uid,
            'login' => $u ? (string)$u->user_login : '',
            'role' => ($u && !empty($u->roles)) ? (string)$u->roles[0] : 'system',
        ];
    }

    public static function command($name, $module, callable $handler, $args = [], $permission = '', $idempotency_key = '') {
        $name = sanitize_key($name); $module = sanitize_key($module);
        if ($permission && class_exists('PK01_Authorization') && !PK01_Authorization::can_action($module, $permission)) {
            self::event('command_denied', $module, 'command', $name, ['permission'=>$permission]);
            throw new Exception('Anda tidak memiliki izin untuk menjalankan tindakan ini.');
        }
        if ($idempotency_key && class_exists('PK01_Idempotency')) {
            $guard = PK01_Idempotency::begin($idempotency_key, 86400, $args, $name);
            if (empty($guard['ok'])) throw new Exception($guard['message'] ?? 'Permintaan sedang diproses.');
            if (!empty($guard['replay'])) return $guard['result'];
        }
        $started = microtime(true);
        try {
            $result = call_user_func($handler, $args);
            self::event('command_completed', $module, 'command', $name, [
                'duration_ms'=>round((microtime(true)-$started)*1000,2),
            ]);
            if ($idempotency_key && class_exists('PK01_Idempotency')) PK01_Idempotency::finish($idempotency_key, $result, 200);
            return $result;
        } catch (Throwable $e) {
            self::event('command_failed', $module, 'command', $name, [
                'duration_ms'=>round((microtime(true)-$started)*1000,2), 'error'=>substr($e->getMessage(),0,300)
            ], 'ERROR');
            if ($idempotency_key && class_exists('PK01_Idempotency')) PK01_Idempotency::fail($idempotency_key, $e->getMessage());
            throw $e;
        }
    }

    public static function transaction(callable $callback) {
        global $wpdb;
        $wpdb->query('START TRANSACTION');
        try {
            $result = call_user_func($callback);
            $wpdb->query('COMMIT');
            return $result;
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }
    }

    public static function assert_positive($value, $label) {
        if ((float)$value <= 0) throw new Exception($label . ' harus lebih besar dari 0.');
        return true;
    }

    public static function assert_nonnegative($value, $label) {
        if ((float)$value < 0) throw new Exception($label . ' tidak boleh negatif.');
        return true;
    }

    public static function event($type, $module, $entity_type = '', $entity_id = '', $payload = [], $level = 'INFO') {
        global $wpdb;
        $table = class_exists('PK01_DB') ? PK01_DB::t('system_events') : '';
        if (!$table) return false;
        $data = [
            'event_type'=>sanitize_key($type), 'module'=>sanitize_key($module),
            'entity_type'=>sanitize_key($entity_type), 'entity_id'=>sanitize_text_field((string)$entity_id),
            'request_id'=>self::request_id(), 'user_id'=>get_current_user_id(),
            'level'=>sanitize_key(strtolower($level)),
            'payload_json'=>wp_json_encode(class_exists('PK01_Audit') ? PK01_Audit::scrub($payload) : $payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            'created_at'=>current_time('mysql')
        ];
        return (bool)$wpdb->insert($table, $data);
    }

    public static function health() {
        global $wpdb;
        $tables = ['products','materials','jobs','sales_orders','cash_ledger','activity_logs'];
        $missing=[];
        foreach ($tables as $key) {
            $t=PK01_DB::t($key);
            if (!$t || $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t)) !== $t) $missing[]=$key;
        }
        return [
            'kernel'=>'1.0','version'=>defined('PK01_VERSION')?PK01_VERSION:'',
            'request_id'=>self::request_id(),'database_ok'=>empty($missing),'missing_tables'=>$missing,
            'actor'=>self::actor()
        ];
    }

    public static function shutdown() {
        // Hanya metadata internal; tidak menulis data bisnis pada shutdown.
    }
}
