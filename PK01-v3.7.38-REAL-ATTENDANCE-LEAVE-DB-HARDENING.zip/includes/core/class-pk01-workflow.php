<?php
if (!defined('ABSPATH')) exit;

/** PK01 Workflow Guard: aturan transisi lintas modul tanpa mengganti Engine lama. */
class PK01_Workflow {
    public static function init() {}
    private static $maps = [
        'job_assignment' => [
            'assigned'=>['assigned','accepted','returned'],
            'accepted'=>['accepted','in_progress','returned'],
            'in_progress'=>['in_progress','completed','returned'],
            'completed'=>['completed'], 'returned'=>['returned','assigned']
        ],
        'job' => [
            'draft'=>['draft','assigned','cancelled'],
            'assigned'=>['assigned','in_progress','completed','cancelled'],
            'in_progress'=>['in_progress','completed','cancelled'],
            'completed'=>['completed'], 'cancelled'=>['cancelled']
        ],
        'wage' => [
            'pending'=>['pending','partial','paid','cancelled'],
            'partial'=>['partial','paid'], 'paid'=>['paid'], 'cancelled'=>['cancelled']
        ],
        'order' => [
            'pending'=>['pending','processing','cancelled'],
            'processing'=>['processing','ready_packing','cancelled'],
            'ready_packing'=>['ready_packing','packed'],
            'ready_to_pack'=>['ready_to_pack','packing','packed'],
            'packed'=>['packed','label_created','shipped'], 'shipped'=>['shipped','delivered'],
            'delivered'=>['delivered'], 'cancelled'=>['cancelled']
        ],
        'packing' => ['ready_to_pack'=>['ready_to_pack','packing','packed'],'ready_packing'=>['ready_packing','packing','packed'],'packing'=>['packing','packed'],'packed'=>['packed']],
        'shipment' => ['pending'=>['pending','label_created','shipped','cancelled'],'label_created'=>['label_created','shipped','cancelled'],'on_process'=>['on_process','shipped','delivered','returned'],'shipped'=>['shipped','delivered','returned'],'delivered'=>['delivered'],'cancelled'=>['cancelled'],'returned'=>['returned']],
    ];

    public static function can_transition($entity, $from, $to) {
        $entity=sanitize_key($entity); $from=sanitize_key($from); $to=sanitize_key($to);
        if ($from === $to) return true;
        return isset(self::$maps[$entity][$from]) && in_array($to, self::$maps[$entity][$from], true);
    }

    public static function assert_transition($entity, $from, $to) {
        if (!self::can_transition($entity,$from,$to)) {
            throw new Exception(sprintf('Transisi %s dari %s ke %s tidak diizinkan.', $entity, $from ?: '(kosong)', $to));
        }
        return true;
    }

    public static function map($entity) { return self::$maps[sanitize_key($entity)] ?? []; }
}
