<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Audit & Forensic Security Engine
 * Perekam jejak audit terpusat, pengawas integritas transaksi, dan pelindung kepatuhan sistem.
 */
class PK01_Audit {

    /**
     * Inisialisasi Hook Pengawas Keamanan Otomatis
     */
    public static function init() {
        // 1. Audit Keamanan Login WordPress
        add_action('wp_login', [__CLASS__, 'hook_user_login'], 10, 2);
        add_action('wp_login_failed', [__CLASS__, 'hook_user_login_failed'], 10, 1);
        add_action('wp_logout', [__CLASS__, 'hook_user_logout'], 10, 1);

        // 2. Audit Perubahan Peran / Hak Akses Pengguna
        add_action('set_user_role', [__CLASS__, 'hook_role_changed'], 10, 3);

        return true;
    }

    /**
     * Deteksi Nama Tabel Database (Mendukung activity_logs & logs)
     */
    public static function table() {
        global $wpdb;
        
        if (class_exists('PK01_DB') && method_exists('PK01_DB', 't')) {
            $t1 = PK01_DB::t('activity_logs');
            if ($t1 && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t1)) === $t1) return $t1;
            
            $t2 = PK01_DB::t('activity_logs');
            if ($t2 && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t2)) === $t2) return $t2;
        }

        $default = $wpdb->prefix . 'pk01_activity_logs';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $default)) === $default) return $default;

        $fallback = $wpdb->prefix . 'pk01_activity_logs';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $fallback)) === $fallback) return $fallback;

        // Buat tabel jika belum tersedia
        self::ensure_schema($default);
        return $default;
    }

    /**
     * Pastikan Skema Tabel Forensik Lengkap
     */
    private static function ensure_schema($table_name) {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE `{$table_name}` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `user_id` bigint(20) unsigned DEFAULT 0,
            `user_name` varchar(100) DEFAULT '',
            `user_role` varchar(50) DEFAULT '',
            `action` varchar(100) NOT NULL,
            `module` varchar(50) NOT NULL,
            `entity` varchar(100) DEFAULT '',
            `transaction_id` varchar(100) DEFAULT '',
            `before_data` longtext DEFAULT NULL,
            `after_data` longtext DEFAULT NULL,
            `diff_data` text DEFAULT NULL,
            `reason` text DEFAULT NULL,
            `level` varchar(20) NOT NULL DEFAULT 'info',
            `source` varchar(50) NOT NULL DEFAULT 'engine',
            `ip_address` varchar(45) DEFAULT '',
            `user_agent` varchar(255) DEFAULT '',
            `request_uri` varchar(255) DEFAULT '',
            PRIMARY KEY (`id`),
            KEY `action` (`action`),
            KEY `module` (`module`),
            KEY `level` (`level`),
            KEY `timestamp` (`timestamp`)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        PK01_DB::dbDelta_safe($sql);
    }

    /**
     * Sensor Nilai Rahasia (Kata Sandi, API Key, Token, Kredensial)
     */
    public static function scrub($value) {
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                $key = strtolower((string)$k);
                if (preg_match('/(pass|password|pwd|secret|token|api[_-]?key|auth|authorization|credential|cookie|pin|cvv)/i', $key)) {
                    $out[$k] = '[REDACTED]';
                } else {
                    $out[$k] = self::scrub($v);
                }
            }
            return $out;
        } elseif (is_string($value) && (strlen($value) > 300)) {
            // Potong teks string yang terlalu masif agar hemat penyimpanan
            return mb_strimwidth($value, 0, 300, '...');
        }
        return $value;
    }

    /**
     * Kalkulator Perubahan Data (Menghitung Apa yang Berubah)
     */
    private static function calculate_diff($before, $after) {
        if (!is_array($before) || !is_array($after)) return null;

        $diff = [];
        foreach ($after as $key => $new_val) {
            if (!array_key_exists($key, $before)) {
                $diff[$key] = ['old' => null, 'new' => $new_val];
            } elseif ($before[$key] !== $new_val) {
                $diff[$key] = ['old' => $before[$key], 'new' => $new_val];
            }
        }

        return !empty($diff) ? $diff : null;
    }

    /**
     * Ambil Alamat IP Klien Secara Riil (Mendukung Proxy & Cloudflare)
     */
    private static function get_client_ip() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($parts[0]);
        }
        return sanitize_text_field(substr($ip, 0, 45));
    }

    /**
     * TULIS CATATAN AUDIT UTAMA (METODE CORE WRITE)
     */
    public static function write($action, $module, $entity = '', $record_id = '', $before = null, $after = null, $reason = '', $status = 'SUCCESS', $source = 'engine', $error = '') {
        global $wpdb;

        $tbl = self::table();
        if (!$tbl) return false;

        $before_clean = self::scrub($before);
        $after_clean  = self::scrub($after);
        $diff         = self::calculate_diff($before_clean, $after_clean);

        // Identifikasi Pengguna Riil
        $user_id   = get_current_user_id();
        $user_name = 'Sistem / Anonim';
        $user_role = 'tamu';

        if ($user_id > 0) {
            $u = get_userdata($user_id);
            if ($u) {
                $user_name = $u->display_name . ' (@' . $u->user_login . ')';
                $user_role = !empty($u->roles) ? $u->roles[0] : 'user';
            }
        }

        // Tentukan Tingkat Log (Level)
        $level = 'info';
        $status_upper = strtoupper((string)$status);
        if ($status_upper === 'ERROR' || !empty($error)) {
            $level = 'error';
        } elseif ($status_upper === 'WARN' || $status_upper === 'WARNING') {
            $level = 'warning';
        } elseif ($status_upper === 'SECURITY') {
            $level = 'security';
        }

        $payload = [
            'timestamp'      => current_time('mysql'),
            'user_id'        => $user_id,
            'user_name'      => sanitize_text_field($user_name),
            'user_role'      => sanitize_key($user_role),
            'action'         => sanitize_key($action),
            'module'         => sanitize_key($module),
            'entity'         => sanitize_text_field($entity),
            'transaction_id' => (string)$record_id,
            'before_data'    => $before_clean !== null ? wp_json_encode($before_clean, JSON_UNESCAPED_UNICODE) : null,
            'after_data'     => $after_clean !== null ? wp_json_encode($after_clean, JSON_UNESCAPED_UNICODE) : null,
            'diff_data'      => $diff !== null ? wp_json_encode($diff, JSON_UNESCAPED_UNICODE) : null,
            'reason'         => sanitize_textarea_field($error ? $reason . ' [Error: ' . $error . ']' : $reason),
            'level'          => $level,
            'source'         => sanitize_key($source),
            'ip_address'     => self::get_client_ip(),
            'user_agent'     => substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
            'request_uri'    => substr(sanitize_text_field($_SERVER['REQUEST_URI'] ?? ''), 0, 250),
        ];

        // Filter payload terhadap kolom yang benar-benar ada di tabel (Anti SQL Error)
        $existing_cols = $wpdb->get_col("DESC `{$tbl}`", 0);
        if (!empty($existing_cols)) {
            $payload = array_intersect_key($payload, array_flip($existing_cols));
        }

        $ok = $wpdb->insert($tbl, $payload);

        if (!$ok && function_exists('error_log') && defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[PK01 Audit Error] Write failed: ' . ($wpdb->last_error ?: 'Unknown'));
        }

        // Jabat Tangan ke Central Bridge jika tersedia
        if (class_exists('PK01_Central_Bridge') && method_exists('PK01_Central_Bridge', 'emit')) {
            PK01_Central_Bridge::emit('audit_' . $action, [
                'module'         => $module,
                'entity'         => $entity,
                'transaction_id' => $record_id,
                'status'         => $status,
                'source'         => $source,
            ]);
        }

        return (bool)$ok;
    }

    /**
     * ALIAS KOMPATIBEL: PK01_Audit::log()
     * Memastikan pemanggilan dari modul lain (seperti Affiliate / Sales) berjalan mulus
     */
    public static function log($action, $module, $entity = '', $record_id = '', $before = null, $after = null, $reason = '', $status = 'SUCCESS') {
        return self::write($action, $module, $entity, $record_id, $before, $after, $reason, $status);
    }

    /**
     * Catat Informasi Standar
     */
    public static function info($action, $module, $message = '', $entity = '', $record_id = '') {
        return self::write($action, $module, $entity, $record_id, null, null, $message, 'SUCCESS');
    }

    /**
     * Catat Peringatan (Warning)
     */
    public static function warn($action, $module, $message = '', $entity = '', $record_id = '') {
        return self::write($action, $module, $entity, $record_id, null, null, $message, 'WARNING');
    }

    /**
     * Catat Kegagalan / Error
     */
    public static function error($action, $module, $error_message = '', $entity = '', $record_id = '') {
        return self::write($action, $module, $entity, $record_id, null, null, '', 'ERROR', 'engine', $error_message);
    }

    /**
     * Catat Peristiwa Keamanan (Security Audit)
     */
    public static function security($action, $message = '', $entity = '', $record_id = '') {
        return self::write($action, 'security', $entity, $record_id, null, null, $message, 'SECURITY', 'auth');
    }

    /**
     * KUERI PENELUSURAN AUDIT TRAIL LENGKAP
     */
    public static function query($args = []) {
        global $wpdb;
        $t = self::table();
        if (!$t) return [];

        $where = ['1=1'];
        $params = [];

        if (!empty($args['user_id'])) {
            $where[] = "user_id = %d";
            $params[] = (int)$args['user_id'];
        }
        if (!empty($args['action'])) {
            $where[] = "action = %s";
            $params[] = sanitize_key($args['action']);
        }
        if (!empty($args['module'])) {
            $where[] = "module = %s";
            $params[] = sanitize_key($args['module']);
        }
        if (!empty($args['level'])) {
            $where[] = "level = %s";
            $params[] = sanitize_key($args['level']);
        }
        if (!empty($args['entity'])) {
            $where[] = "entity LIKE %s";
            $params[] = '%' . $wpdb->esc_like(sanitize_text_field($args['entity'])) . '%';
        }
        if (!empty($args['from'])) {
            $where[] = "timestamp >= %s";
            $params[] = sanitize_text_field($args['from']) . ' 00:00:00';
        }
        if (!empty($args['to'])) {
            $where[] = "timestamp <= %s";
            $params[] = sanitize_text_field($args['to']) . ' 23:59:59';
        }
        if (!empty($args['search'])) {
            $where[] = "(reason LIKE %s OR transaction_id LIKE %s OR user_name LIKE %s)";
            $s = '%' . $wpdb->esc_like(sanitize_text_field($args['search'])) . '%';
            $params[] = $s;
            $params[] = $s;
            $params[] = $s;
        }

        $limit  = max(1, min(1000, (int)($args['limit'] ?? 100)));
        $offset = max(0, (int)($args['offset'] ?? 0));

        $sql = "SELECT * FROM `{$t}` WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT {$limit} OFFSET {$offset}";

        return !empty($params) ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
    }

    /**
     * Hitung Statistik Audit Riil
     */
    public static function stats() {
        global $wpdb;
        $t = self::table();
        $today = current_time('Y-m-d');

        $stats = [
            'total_today'    => 0,
            'security_today' => 0,
            'errors_today'   => 0,
            'total_all'      => 0
        ];

        if ($t) {
            $stats['total_today'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$t}` WHERE DATE(timestamp) = %s", $today));
            $stats['security_today'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$t}` WHERE level = 'security' AND DATE(timestamp) = %s", $today));
            $stats['errors_today'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$t}` WHERE level = 'error' AND DATE(timestamp) = %s", $today));
            $stats['total_all'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}`");
        }

        return $stats;
    }

    /**
     * Pembersihan Log Usang (Maintenance Retention Purge)
     */
    public static function purge($days = 90) {
        global $wpdb;
        $t = self::table();
        $days = max(15, (int)$days);

        if (!$t) return 0;

        return (int) $wpdb->query($wpdb->prepare(
            "DELETE FROM `{$t}` WHERE timestamp < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    // =========================================================================
    // HOOKS OTOMATIS SISTEM KEAMANAN WORDPRESS
    // =========================================================================

    public static function hook_user_login($user_login, $user) {
        self::security('user_login', "Pengguna {$user_login} berhasil masuk ke sistem.", 'auth_session', (string)$user->ID);
    }

    public static function hook_user_login_failed($username) {
        self::security('user_login_failed', "Percobaan login gagal untuk username: {$username}", 'auth_attempt', $username);
    }

    /**
     * Audit logout WordPress.
     *
     * Penting: hook ini harus benar-benar tersedia karena init() mendaftarkan
     * callback wp_logout. Sebelumnya callback didaftarkan tetapi method-nya
     * tidak ada, sehingga WordPress memicu critical error saat tombol Keluar
     * ditekan.
     */
    public static function hook_user_logout($user_id = 0) {
        $user_id = (int) $user_id;
        $u = $user_id > 0 ? get_userdata($user_id) : false;
        $name = $u ? ($u->display_name ?: $u->user_login) : ('ID #' . $user_id);

        self::security(
            'user_logout',
            "Pengguna {$name} keluar dari sistem.",
            'auth_session',
            (string) $user_id
        );
    }

    public static function hook_role_changed($user_id, $role, $old_roles) {
        $u = get_userdata($user_id);
        $name = $u ? $u->display_name : 'ID #' . $user_id;
        $old = !empty($old_roles) ? implode(', ', $old_roles) : 'none';
        self::security('role_changed', "Perubahan wewenang pengguna {$name}: [{$old}] -> [{$role}]", 'user_privilege', (string)$user_id);
    }
}

// Inisialisasi Engine Audit
