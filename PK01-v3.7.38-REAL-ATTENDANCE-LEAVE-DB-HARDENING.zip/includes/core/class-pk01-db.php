<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Database Engine & Migration Manager
 * Mengelola pendefinisian seluruh tabel sistem, registrasi laman resmi, 
 * eksekusi dbDelta, dan migrasi kolom aman lintas versi.
 */
class PK01_DB {

    public static $tables = [];

    /**
     * Inisialisasi Nama Tabel Berdasarkan Prefix Database WordPress
     */
    public static function init() {
        global $wpdb;
        $p = $wpdb->prefix . 'pk01_';

        $table_keys = [
            'products', 'product_gallery', 'product_variants', 'pricing', 'hpp_components', 'customers',
            'materials', 'suppliers', 'purchase_orders', 'purchase_order_items', 'goods_receipts',
            'stock_transactions', 'jobs', 'job_items', 'job_assignments', 'job_materials',
            'production_results', 'production_units', 'job_completion_reports', 'job_wages', 'job_wage_payments', 'employees', 'employee_piece_rates', 'employee_compensation_rules', 'payroll', 'payroll_components',
            'operational_costs', 'channels', 'sales_accounts', 'price_rules', 'product_prices',
            'sales_orders', 'sales_order_items', 'marketplace_deductions', 'marketplace_payouts',
            'seller_stock', 'seller_sales', 'seller_invoices', 'seller_payments', 'seller_credit_ledger',
            'seller_contract_prices', 'seller_orders', 'seller_order_items', 'seller_marketplace_items', 'seller_affiliate_ledger', 'seller_targets', 'seller_bonus_ledger',
            'affiliate_links', 'affiliate_attributions', 'marketplace_mappings', 'marketplace_exports',
            'cash_ledger', 'financial_periods', 'journal_entries', 'journal_lines', 'capital_transactions', 'company_owners', 'owner_transactions', 'investors', 'investor_transactions', 'profit_distributions', 'profit_distribution_items', 'fixed_assets', 'asset_depreciation', 'inventory_valuation_adjustments', 'closings', 'stock_adjustments', 'document_sequences',
            'activity_logs', 'system_events', 'job_role_catalog', 'employee_job_roles', 'idempotency_keys', 'entry_guards', 'ai_logs', 'sales_commissions', 'test_runs', 'test_entities', 'test_sequence_snapshots', 'ai_approvals', 'ai_conversations', 'returns',
            'return_items', 'warehouse_documents', 'shipments', 'tracking_events', 'shipment_alerts', 'backup_history', 'security_visitors', 'security_visitor_visits', 'security_vehicles', 'security_goods', 'security_incidents', 'security_cctv_cameras', 'attendance_devices', 'attendance_records', 'leave_types', 'leave_balances', 'leave_requests', 'attendance_import_logs', 'hpp_calculation_snapshots', 'cs_tickets', 'cs_messages', 'chat_rooms', 'chat_participants', 'chat_messages', 'customer_chat_threads', 'customer_chat_messages', 'cnc_gcode_library'
        ];

        foreach ($table_keys as $key) {
            self::$tables[$key] = $p . $key;
        }
        // Alias legacy names to the canonical tables so old operational modules
        // never silently write to a different/non-existent ledger.
        self::$tables['logs'] = self::$tables['activity_logs'];
        self::$tables['orders'] = self::$tables['sales_orders'];
        self::$tables['variants'] = self::$tables['product_variants'];
        self::$tables['sellers'] = self::$tables['sales_accounts'];
        self::$tables['transactions'] = self::$tables['cash_ledger'];
    }

    /**
     * Helper Pemanggil Nama Tabel Lengkap: PK01_DB::t('materials')
     */
    public static function t($k) {
        if (empty(self::$tables)) {
            self::init();
        }
        return self::$tables[$k] ?? '';
    }

    /**
     * dbDelta aman untuk schema PK01.
     * WordPress dbDelta mengharuskan deklarasi index berada pada baris sendiri
     * dan memiliki whitespace yang dapat diparse. Schema lama PK01 memiliki
     * beberapa deklarasi index inline seperti PRIMARY KEY(id), KEY foo(id),
     * yang memicu warning Undefined array key di wp-admin/includes/upgrade.php.
     */
    public static function dbDelta_safe($sql) {
        if (!function_exists('dbDelta')) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }
        $sql = trim((string)$sql);
        if ($sql === '') return [];

        // dbDelta adalah parser berbasis teks. Normalisasi komentar, newline,
        // field dan index agar seluruh schema PK01 konsisten walaupun berasal
        // dari legacy migration yang menulis beberapa definisi dalam satu baris.
        $sql = preg_replace('/\r\n?/', "\n", $sql);
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        $sql = preg_replace('/^[ \t]*(?:\/\/|#).*$/m', '', $sql);
        $sql = preg_replace('/\n[ \t]*\n+/', "\n", $sql);

        // Pecah isi CREATE TABLE pada koma level-atas saja. Koma di dalam
        // DECIMAL(...), KEY(...,...) atau string tidak boleh ikut terpecah.
        $open = strpos($sql, '(');
        if ($open !== false) {
            $depth = 0; $quote = ''; $body_end = -1;
            $len = strlen($sql);
            for ($i=$open; $i<$len; $i++) {
                $ch = $sql[$i];
                if ($quote !== '') {
                    if ($ch === $quote && ($i === 0 || $sql[$i-1] !== '\\')) $quote = '';
                    continue;
                }
                if ($ch === "'" || $ch === '"' || $ch === '`') { $quote = $ch; continue; }
                if ($ch === '(') $depth++;
                elseif ($ch === ')') { $depth--; if ($depth === 0) { $body_end = $i; break; } }
            }
            if ($body_end > $open) {
                $body = substr($sql, $open + 1, $body_end - $open - 1);
                $parts = []; $buf = ''; $depth = 0; $quote = ''; $blen = strlen($body);
                for ($i=0; $i<$blen; $i++) {
                    $ch = $body[$i];
                    if ($quote !== '') {
                        $buf .= $ch;
                        if ($ch === $quote && ($i === 0 || $body[$i-1] !== '\\')) $quote = '';
                        continue;
                    }
                    if ($ch === "'" || $ch === '"' || $ch === '`') { $quote = $ch; $buf .= $ch; continue; }
                    if ($ch === '(') $depth++;
                    elseif ($ch === ')') $depth--;
                    if ($ch === ',' && $depth === 0) { $parts[] = trim($buf); $buf = ''; continue; }
                    $buf .= $ch;
                }
                if (trim($buf) !== '') $parts[] = trim($buf);
                $formatted = [];
                foreach ($parts as $part) {
                    $part = trim(preg_replace('/\s+/', ' ', $part));
                    if ($part === '') continue;
                    $part = preg_replace('/^PRIMARY\s+KEY\s*\(/i', 'PRIMARY KEY  (', $part);
                    $part = preg_replace('/^UNIQUE\s+(?:KEY|INDEX)\s+(`?[A-Za-z0-9_]+`?)\s*\(/i', 'UNIQUE KEY $1 (', $part);
                    $part = preg_replace('/^FULLTEXT\s+(?:KEY|INDEX)\s+(`?[A-Za-z0-9_]+`?)\s*\(/i', 'FULLTEXT KEY $1 (', $part);
                    $part = preg_replace('/^SPATIAL\s+(?:KEY|INDEX)\s+(`?[A-Za-z0-9_]+`?)\s*\(/i', 'SPATIAL KEY $1 (', $part);
                    $part = preg_replace('/^INDEX\s+(`?[A-Za-z0-9_]+`?)\s*\(/i', 'KEY $1 (', $part);
                    $part = preg_replace('/^KEY\s+(`?[A-Za-z0-9_]+`?)\s*\(/i', 'KEY $1 (', $part);
                    $formatted[] = '    ' . $part;
                }
                $head = rtrim(substr($sql, 0, $open + 1));
                $tail = ltrim(substr($sql, $body_end));
                $sql = $head . "\n" . implode(",\n", $formatted) . "\n" . $tail;
            }
        }
        $sql = preg_replace('/\n[ \t]*\n+/', "\n", $sql);
        return dbDelta($sql);
    }

    /**
     * Eksekusi Aktivasi Plugin
     */
    public static function activate() {
        self::init();
        self::install();
        self::ensure_pages();
        if (function_exists('flush_rewrite_rules')) {
            flush_rewrite_rules(false);
        }
    }

    /**
     * Dapatkan URL Laman Dashboard Utama
     */
    public static function page_url($view = '') {
        $id = (int) get_option('pk01_dashboard_page_id', 0);
        $url = ($id && get_post_status($id) === 'publish') ? get_permalink($id) : home_url('/dashboard-operasional/');
        return $view ? add_query_arg('pk01_view', $view, $url) : $url;
    }

    /**
     * URL portal PK01 yang selalu mengikuti domain aktif WordPress.
     * Tidak menyimpan hostname/domain secara hard-code sehingga aman saat migrasi hosting/domain.
     */
    public static function portal_url($view = 'dashboard') {
        $view = sanitize_key($view ?: 'dashboard');
        $id = (int) get_option('pk01_portal_page_id', 0);
        if (!$id || get_post_status($id) !== 'publish') {
            self::ensure_pages();
            $id = (int) get_option('pk01_portal_page_id', 0);
        }

        // Jangan pernah mengarahkan launcher PK01 ke homepage WordPress biasa.
        // Jika option portal rusak/menunjuk ke halaman depan, cari halaman PK01
        // berdasarkan slug/shortcode lalu pulihkan option-nya.
        $url = '';
        if ($id && get_post_status($id) === 'publish') {
            $url = get_permalink($id);
            $path = (string) wp_parse_url($url, PHP_URL_PATH);
            if (untrailingslashit($path) === '' || untrailingslashit($path) === '/') {
                $id = 0;
            }
        }
        if (!$id) {
            $existing = get_page_by_path('pk01-portal', OBJECT, 'page');
            if ($existing && get_post_status($existing->ID) === 'publish') {
                $id = (int) $existing->ID;
            }
        }
        if (!$id) {
            $found = get_posts([
                'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 1,
                's' => '[pk01_operasional]'
            ]);
            if (!empty($found[0])) $id = (int) $found[0]->ID;
        }
        if ($id) {
            update_option('pk01_portal_page_id', $id, false);
            $url = get_permalink($id);
        }
        if (!$url || untrailingslashit((string) wp_parse_url($url, PHP_URL_PATH)) === '') {
            // Last safe fallback. The frontend controller recognizes this path.
            $url = home_url('/pk01-portal/');
        }
        return $view ? add_query_arg('pk01_view', $view, $url) : $url;
    }

    /**
     * Registrasi Otomatis Laman-Laman Resmi Sistem PK01 Bebas 404
     */
    public static function ensure_pages() {
        $map = [
            // Portal adalah landing page kanonis PK01. ID/URL diperbaiki otomatis
            // jika database dipindahkan atau halaman terhapus.
            'login'            => ['pk01_login_page_id', 'pk01-login', 'Login PK01', '[pk01_login]'],
            'portal'           => ['pk01_portal_page_id', 'pk01-portal', 'PK01 Portal', '[pk01_operasional]'],
            'dashboard'        => ['pk01_dashboard_page_id', 'dashboard-operasional', 'Dashboard Operasional', '[pk01_operasional]'],
            'products'         => ['pk01_products_page_id', 'produk-operasional', 'Produk & SKU', '[pk01_products]'],
            'materials'        => ['pk01_materials_page_id', 'bahan-baku-operasional', 'Bahan Baku', '[pk01_materials]'],
            'production'       => ['pk01_production_page_id', 'produksi-operasional', 'Produksi', '[pk01_production]'],
            'stock'            => ['pk01_stock_page_id', 'stok-operasional', 'Stok', '[pk01_stock]'],
            'purchase'         => ['pk01_purchase_page_id', 'pembelian-operasional', 'Pembelian / PO', '[pk01_purchase]'],
            'suppliers'        => ['pk01_suppliers_page_id', 'pemasok-operasional', 'Pemasok', '[pk01_pemasok]'],
            'sales'            => ['pk01_sales_page_id', 'penjualan-operasional', 'Penjualan', '[pk01_sales]'],
            'customers'        => ['pk01_customers_page_id', 'pelanggan-operasional', 'Pelanggan', '[pk01_customers]'],
            'seller'           => ['pk01_seller_page_id', 'stok-seller-operasional', 'Stok Seller', '[pk01_seller]'],
            'seller_portal'    => ['pk01_seller_portal_page_id', 'dashboard-seller-operasional', 'Dashboard Seller', '[pk01_seller_portal]'],
            'seller_affiliate' => ['pk01_seller_affiliate_page_id', 'affiliate-seller-operasional', 'Affiliate Seller', '[pk01_seller_affiliate]'],
            'returns'          => ['pk01_returns_page_id', 'retur-operasional', 'Retur', '[pk01_returns]'],
            'shipments'        => ['pk01_shipments_page_id', 'pengiriman-operasional', 'Pengiriman & Resi', '[pk01_pengiriman]'],
            'marketplace'      => ['pk01_marketplace_page_id', 'marketplace-operasional', 'Penjualan Marketplace', '[pk01_marketplace]'],
            'employees'        => ['pk01_employees_page_id', 'karyawan-operasional', 'Karyawan', '[pk01_karyawan]'],
            'attendance'       => ['pk01_attendance_page_id', 'absensi-cuti-karyawan', 'Absensi & Cuti Karyawan', '[pk01_operasional]'],
            'payroll'          => ['pk01_payroll_page_id', 'gaji-karyawan-operasional', 'Gaji Karyawan', '[pk01_payroll]'],
            'job_wages'        => ['pk01_job_wages_page_id', 'upah-job-operasional', 'Upah Pekerjaan / Job', '[pk01_job_wages]'],
            'assets_inventory'=> ['pk01_assets_inventory_page_id', 'aset-inventory-operasional', 'Aset & Inventori', '[pk01_assets_inventory]'],
            'operational_costs'=> ['pk01_operational_costs_page_id', 'biaya-usaha-operasional', 'Biaya Usaha', '[pk01_operational_costs]'],
            'cash'             => ['pk01_cash_page_id', 'uang-usaha-operasional', 'Uang Usaha', '[pk01_cash]'],
            'finance'          => ['pk01_finance_page_id', 'keuangan-operasional', 'Laporan Keuangan', '[pk01_finance]'],
            'administration'   => ['pk01_administration_page_id', 'administrasi-operasional', 'Dashboard Administrasi', '[pk01_administrasi]'],
            'pricing'          => ['pk01_pricing_page_id', 'harga-jual-operasional', 'Harga Jual', '[pk01_harga_jual]'],
            'ai_assistant'     => ['pk01_ai_page_id', 'ai-operasional', 'Asisten AI', '[pk01_asisten_ai]'],
            'logs'             => ['pk01_logs_page_id', 'aktivitas-operasional', 'Aktivitas', '[pk01_aktivitas]'],
            'system'           => ['pk01_system_page_id', 'pengaturan-sistem', 'Pengaturan Sistem', '[pk01_pengaturan_sistem]'],
            'seller_register'  => ['pk01_seller_register_page_id', 'daftar-seller', 'Daftar Seller', '[pk01_daftar_seller]'],
            'tracking_public'  => ['pk01_tracking_public_page_id', 'lacak-resi', 'Lacak Resi', '[pk01_lacak_resi]'],
        ];

        $first_id = 0;
        foreach ($map as $key => $pg) {
            list($opt, $slug, $title, $content) = $pg;
            $id = (int) get_option($opt, 0);

            if ($id && get_post_status($id) !== 'publish') {
                $id = 0;
            }

            if (!$id) {
                $existing = get_page_by_path($slug, OBJECT, 'page');
                $id = $existing ? (int) $existing->ID : 0;
            }

            if (!$id) {
                $created = wp_insert_post([
                    'post_title'     => $title,
                    'post_name'      => $slug,
                    'post_content'   => $content,
                    'post_status'    => 'publish',
                    'post_type'      => 'page',
                    'comment_status' => 'closed',
                    'ping_status'    => 'closed'
                ], true);

                if (!is_wp_error($created)) {
                    $id = (int) $created;
                }
            }

            if ($id) {
                update_option($opt, $id, false);
                if (!$first_id) $first_id = $id;
            }
        }

        update_option('pk01_pages_schema_version', '3.6.0', false);
        $dash_id = (int) get_option('pk01_dashboard_page_id', 0);
        return ($dash_id && get_post_status($dash_id) === 'publish') ? $dash_id : $first_id;
    }

    /**
     * Pastikan tabel aset tetap tersedia tanpa memaksa seluruh schema PK01 diproses.
     * Dipakai oleh modul Aset ketika instalasi lama belum menjalankan schema 3.6+.
     */
    public static function ensure_fixed_asset_tables() {
        global $wpdb;
        self::init();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $fa = self::t('fixed_assets');
        $ad = self::t('asset_depreciation');
        self::dbDelta_safe("CREATE TABLE {$fa} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            asset_code varchar(80) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            category varchar(80) NOT NULL DEFAULT 'Alat Kerja',
            purchase_date date NOT NULL,
            purchase_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            residual_value decimal(18,2) NOT NULL DEFAULT 0.00,
            useful_life_months int unsigned NOT NULL DEFAULT 1,
            annual_rate decimal(8,4) NOT NULL DEFAULT 0.0000,
            payment_method varchar(100) NOT NULL DEFAULT 'Transfer Bank',
            notes text DEFAULT NULL,
            status varchar(30) NOT NULL DEFAULT 'active',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY asset_code (asset_code),
            KEY status (status)
        ) {$c};");
        self::dbDelta_safe("CREATE TABLE {$ad} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            asset_id bigint(20) unsigned NOT NULL,
            period_key varchar(7) NOT NULL,
            depreciation_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            accumulated_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'posted',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY asset_period (asset_id,period_key),
            KEY period_key (period_key)
        ) {$c};");
        return ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $fa)) === $fa);
    }

    /**
     * INSTALASI STRUKTUR DATABASE LENGKAP MENGGUNAKAN DBDELTA
     */
    public static function install() {
        global $wpdb;
        self::init();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $q = [];

        // 1. Master Produk & Varian
        $q[] = "CREATE TABLE " . self::t('products') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(64) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            slug varchar(190) DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'active',
            cnc_required tinyint(1) NOT NULL DEFAULT 0,
            prema_required tinyint(1) NOT NULL DEFAULT 0,
            supply_mode varchar(20) NOT NULL DEFAULT 'production',
            notes text DEFAULT NULL,
            image_id bigint(20) unsigned DEFAULT NULL,
            category varchar(100) DEFAULT '',
            brand varchar(100) DEFAULT '',
            description longtext DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY code (code),
            KEY status (status)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('product_variants') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            product_id bigint(20) unsigned NOT NULL,
            sku varchar(80) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            size varchar(100) DEFAULT '',
            material varchar(190) DEFAULT '',
            finishing varchar(190) DEFAULT '',
            hpp decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_material decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_labor decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_overhead decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_packaging decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_other decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_basis_qty decimal(18,4) NOT NULL DEFAULT 1.0000,
            hpp_method varchar(30) NOT NULL DEFAULT 'full_cost',
            price decimal(18,2) NOT NULL DEFAULT 0.00,
            stock decimal(18,4) NOT NULL DEFAULT 0.0000,
            supply_mode varchar(20) NOT NULL DEFAULT 'production',
            supplier_id bigint(20) unsigned DEFAULT 0,
            external_product_code varchar(120) NOT NULL DEFAULT '',
            purchase_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY product_id (product_id),
            KEY sku (sku)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('hpp_components') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            variant_id bigint(20) unsigned NOT NULL,
            component_type varchar(30) NOT NULL DEFAULT 'material',
            material_id bigint(20) unsigned DEFAULT 0,
            component_name varchar(190) NOT NULL DEFAULT '',
            qty decimal(18,6) NOT NULL DEFAULT 0.000000,
            unit varchar(30) NOT NULL DEFAULT 'pcs',
            unit_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            waste_percent decimal(8,4) NOT NULL DEFAULT 0.0000,
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            notes text DEFAULT NULL,
            owner_type varchar(20) NOT NULL DEFAULT 'company',
            seller_account_id bigint(20) unsigned DEFAULT 0,
            seller_invoice_id bigint(20) unsigned DEFAULT 0,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY variant_id (variant_id), KEY component_type (component_type), KEY material_id (material_id)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('hpp_calculation_snapshots') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            variant_id bigint(20) unsigned NOT NULL,
            calculation_mode varchar(30) NOT NULL DEFAULT 'manual',
            planned_qty decimal(18,4) NOT NULL DEFAULT 1.0000,
            material_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            labor_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            overhead_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            packaging_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            other_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_total decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp_per_unit decimal(18,2) NOT NULL DEFAULT 0.00,
            data_source text DEFAULT NULL,
            assumptions text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY variant_id (variant_id), KEY calculation_mode (calculation_mode), KEY created_at (created_at)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('pricing') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            variant_id bigint(20) unsigned DEFAULT 0,
            sku varchar(100) NOT NULL DEFAULT '',
            name varchar(255) NOT NULL DEFAULT '',
            hpp decimal(15,2) NOT NULL DEFAULT 0.00,
            price decimal(15,2) NOT NULL DEFAULT 0.00,
            margin_percent decimal(6,2) NOT NULL DEFAULT 0.00,
            target_markup_percent decimal(6,2) NOT NULL DEFAULT 0.00,
            fee_percent decimal(6,2) NOT NULL DEFAULT 0.00,
            selling_cost_fixed decimal(15,2) NOT NULL DEFAULT 0.00,
            channel varchar(50) NOT NULL DEFAULT 'direct',
            price_source varchar(30) NOT NULL DEFAULT 'manual',
            ai_recommendation text DEFAULT NULL,
            status varchar(50) NOT NULL DEFAULT 'approved',
            valid_from date NOT NULL,
            valid_to date DEFAULT NULL,
            approved_by varchar(150) DEFAULT '',
            description text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY sku (sku),
            KEY status (status)
        ) $c;";

        // 2. Master Bahan Baku Gudang
        $q[] = "CREATE TABLE " . self::t('materials') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(64) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            unit varchar(30) NOT NULL DEFAULT 'pcs',
            cost decimal(18,2) NOT NULL DEFAULT 0.00,
            stock decimal(18,4) NOT NULL DEFAULT 0.0000,
            min_stock decimal(18,4) NOT NULL DEFAULT 0.0000,
            supplier_id bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY code (code),
            KEY supplier_id (supplier_id)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('suppliers') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(64) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            contact varchar(190) DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY code (code)
        ) $c;";

        // 3. SDM, Karyawan, Borongan & Payroll
        $q[] = "CREATE TABLE " . self::t('employees') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(64) NOT NULL DEFAULT '',
            user_id bigint(20) unsigned DEFAULT 0,
            name varchar(190) NOT NULL DEFAULT '',
            position varchar(100) DEFAULT '',
            division varchar(100) DEFAULT '',
            pay_type varchar(30) NOT NULL DEFAULT 'monthly',
            rate decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY code (code),
            KEY user_id (user_id)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('employee_piece_rates') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            employee_id bigint(20) unsigned NOT NULL,
            job_name varchar(255) NOT NULL DEFAULT '',
            rate decimal(15,2) NOT NULL DEFAULT 0.00,
            unit varchar(50) NOT NULL DEFAULT 'pcs',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY employee_id (employee_id)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('payroll') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            employee_id bigint(20) unsigned NOT NULL,
            name varchar(190) DEFAULT '',
            period varchar(20) NOT NULL DEFAULT '',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            gross_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            deduction_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_method varchar(100) DEFAULT 'Transfer Bank',
            reference_no varchar(100) DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'paid',
            paid_at date DEFAULT NULL,
            description text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY employee_id (employee_id),
            KEY period (period)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('employee_compensation_rules') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            employee_id bigint(20) unsigned NOT NULL,
            component_code varchar(60) NOT NULL,
            component_name varchar(190) NOT NULL,
            component_type varchar(20) NOT NULL DEFAULT 'earning',
            calculation_type varchar(30) NOT NULL DEFAULT 'fixed_monthly',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            active tinyint(1) NOT NULL DEFAULT 1,
            start_period varchar(7) DEFAULT NULL,
            end_period varchar(7) DEFAULT NULL,
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY(id), UNIQUE KEY employee_component(employee_id,component_code), KEY employee_id(employee_id), KEY active(active)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('payroll_components') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            payroll_id bigint(20) unsigned NOT NULL,
            component_code varchar(60) NOT NULL,
            component_name varchar(190) NOT NULL,
            component_type varchar(20) NOT NULL DEFAULT 'earning',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            source_type varchar(50) DEFAULT 'manual',
            source_id bigint(20) unsigned DEFAULT 0,
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY payroll_component(payroll_id,component_code), KEY payroll_id(payroll_id), KEY component_type(component_type)
        ) $c;";

        // 4. Penjualan & Kasir (Orders)
        $q[] = "CREATE TABLE " . self::t('sales_orders') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_no varchar(100) NOT NULL DEFAULT '',
            invoice_no varchar(100) DEFAULT '',
            channel varchar(50) NOT NULL DEFAULT 'website',
            seller_id bigint(20) unsigned DEFAULT 0,
            customer_name varchar(255) NOT NULL DEFAULT '',
            customer_phone varchar(50) DEFAULT '',
            shipping_address text DEFAULT NULL,
            variant_id bigint(20) unsigned DEFAULT 0,
            product_name varchar(255) DEFAULT '',
            qty decimal(10,2) NOT NULL DEFAULT 1.00,
            price decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp decimal(18,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            commission decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_method varchar(100) DEFAULT 'Transfer Bank',
            payment_status varchar(30) NOT NULL DEFAULT 'unpaid',
            paid_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            affiliate_link_id bigint(20) unsigned DEFAULT 0,
            affiliate_seller_id bigint(20) unsigned DEFAULT 0,
            status varchar(40) NOT NULL DEFAULT 'processing',
            shipping_status varchar(40) NOT NULL DEFAULT 'pending',
            tracking_no varchar(120) DEFAULT '',
            notes text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY order_no (order_no),
            KEY status (status),
            KEY seller_id (seller_id)
        ) $c;";

        // 4B. Penomoran Dokumen Terpusat (anti bentrok antar modul)
        $q[] = "CREATE TABLE " . self::t('document_sequences') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            doc_type varchar(50) NOT NULL,
            period_key varchar(20) NOT NULL,
            last_seq bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY doc_period (doc_type, period_key)
        ) $c;";

        // 5. Keuangan & Buku Kas (Cash Ledger & Biaya Usaha)
        $q[] = "CREATE TABLE " . self::t('cash_ledger') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            direction varchar(10) NOT NULL DEFAULT 'in',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            account varchar(100) NOT NULL DEFAULT 'Kas Tunai Toko',
            category varchar(100) NOT NULL DEFAULT 'Operasional',
            reference_type varchar(50) DEFAULT 'manual',
            reference_id bigint(20) unsigned DEFAULT 0,
            reference_no varchar(100) DEFAULT '',
            description text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY direction (direction),
            KEY category (category)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('operational_costs') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            cost_date date NOT NULL,
            category varchar(100) NOT NULL DEFAULT 'Operasional Toko',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_method varchar(100) DEFAULT 'Kas Tunai',
            reference_no varchar(100) DEFAULT '',
            description text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            status varchar(30) NOT NULL DEFAULT 'pending_approval',
            requested_by bigint(20) unsigned DEFAULT 0,
            approved_by bigint(20) unsigned DEFAULT 0,
            approved_at datetime DEFAULT NULL,
            paid_by bigint(20) unsigned DEFAULT 0,
            paid_at datetime DEFAULT NULL,
            recipient_name varchar(160) DEFAULT '',
            recipient_user_id bigint(20) unsigned DEFAULT 0,
            receipt_no varchar(100) DEFAULT '',
            recipient_confirmed_at datetime DEFAULT NULL,
            recipient_confirmed_by bigint(20) unsigned DEFAULT 0,
            PRIMARY KEY  (id),
            KEY cost_date (cost_date),
            KEY category (category),
            KEY status (status),
            KEY requested_by (requested_by),
            KEY approved_by (approved_by),
            KEY recipient_user_id (recipient_user_id)
        ) $c;";

        // 5B. Akuntansi periode & General Ledger. Sumber data tetap transaksi PK01.
        $q[] = "CREATE TABLE " . self::t('financial_periods') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            period_key varchar(7) NOT NULL,
            date_from date NOT NULL,
            date_to date NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'open',
            closed_by bigint(20) unsigned DEFAULT 0,
            closed_at datetime DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY period_key(period_key), KEY status(status)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('journal_entries') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            entry_no varchar(100) NOT NULL DEFAULT '',
            entry_date date NOT NULL,
            period_key varchar(7) NOT NULL,
            source_type varchar(60) NOT NULL DEFAULT 'manual',
            source_id bigint(20) unsigned DEFAULT 0,
            source_key varchar(160) NOT NULL DEFAULT '',
            description text DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'posted',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY source_key(source_key), KEY entry_date(entry_date), KEY period_key(period_key), KEY source(source_type,source_id)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('journal_lines') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            journal_entry_id bigint(20) unsigned NOT NULL,
            account_code varchar(30) NOT NULL DEFAULT '',
            account_name varchar(190) NOT NULL DEFAULT '',
            debit decimal(18,2) NOT NULL DEFAULT 0.00,
            credit decimal(18,2) NOT NULL DEFAULT 0.00,
            memo varchar(255) DEFAULT '',
            PRIMARY KEY(id), KEY journal_entry_id(journal_entry_id), KEY account_code(account_code)
        ) $c;";

        // 6. Mitra Seller & Afiliasi
        $q[] = "CREATE TABLE " . self::t('sales_accounts') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT 0,
            code varchar(64) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            type varchar(30) NOT NULL DEFAULT 'seller',
            phone varchar(80) DEFAULT '',
            email varchar(190) DEFAULT '',
            commission_percent decimal(8,4) NOT NULL DEFAULT 10.0000,
            affiliate_percent decimal(8,4) NOT NULL DEFAULT 5.0000,
            registration_status varchar(30) NOT NULL DEFAULT 'approved',
            portal_token varchar(120) DEFAULT '',
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY code (code),
            KEY type (type),
            KEY active (active)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('seller_affiliate_ledger') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            order_id bigint(20) unsigned DEFAULT 0,
            affiliate_link_id bigint(20) unsigned DEFAULT 0,
            base_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            commission_percent decimal(8,4) NOT NULL DEFAULT 0.0000,
            commission_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'pending',
            created_at datetime NOT NULL,
            paid_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY seller_account_id (seller_account_id),
            KEY order_id (order_id),
            KEY status (status)
        ) $c;";

        $q[] = "CREATE TABLE " . self::t('seller_targets') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            participant_type varchar(20) NOT NULL DEFAULT 'seller',
            period_key varchar(7) NOT NULL,
            target_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            bonus_type varchar(20) NOT NULL DEFAULT 'fixed',
            bonus_value decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(20) NOT NULL DEFAULT 'active',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY(id), UNIQUE KEY participant_period(seller_account_id,participant_type,period_key), KEY status(status)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('seller_bonus_ledger') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            target_id bigint(20) unsigned NOT NULL,
            seller_account_id bigint(20) unsigned NOT NULL,
            period_key varchar(7) NOT NULL,
            sales_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            target_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            bonus_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(20) NOT NULL DEFAULT 'earned',
            paid_at datetime DEFAULT NULL,
            reference_no varchar(100) DEFAULT '',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY target_once(target_id), KEY seller_account_id(seller_account_id), KEY period_key(period_key), KEY status(status)
        ) $c;";

        // 7. Pengiriman & Resi Logistik
        $q[] = "CREATE TABLE " . self::t('shipments') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source varchar(50) NOT NULL DEFAULT 'website',
            tracking_no varchar(120) NOT NULL DEFAULT '',
            internal_shipment_no varchar(100) NOT NULL DEFAULT '',
            internal_barcode varchar(120) NOT NULL DEFAULT '',
            courier varchar(50) NOT NULL DEFAULT '',
            service varchar(50) DEFAULT 'REG',
            tracking_verified varchar(20) NOT NULL DEFAULT 'unverified',
            tracking_provider varchar(50) DEFAULT '',
            tracking_verified_at datetime DEFAULT NULL,
            tracking_verification_note text DEFAULT NULL,
            sale_id bigint(20) unsigned DEFAULT 0,
            seller_sale_id bigint(20) unsigned DEFAULT 0,
            recipient_name varchar(190) DEFAULT '',
            recipient_phone varchar(80) DEFAULT '',
            destination text DEFAULT NULL,
            status varchar(40) NOT NULL DEFAULT 'on_process',
            last_event_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY tracking_no (tracking_no),
            KEY internal_shipment_no (internal_shipment_no),
            KEY internal_barcode (internal_barcode),
            KEY sale_id (sale_id),
            KEY seller_sale_id (seller_sale_id),
            KEY status (status)
        ) $c;";

        // 8. Rekonsiliasi Marketplace
        $q[] = "CREATE TABLE " . self::t('marketplace_payouts') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            payout_no varchar(100) NOT NULL DEFAULT '',
            channel_id varchar(50) NOT NULL DEFAULT 'shopee',
            payout_date date NOT NULL,
            order_count int(11) NOT NULL DEFAULT 1,
            gross decimal(18,2) NOT NULL DEFAULT 0.00,
            deductions decimal(18,2) NOT NULL DEFAULT 0.00,
            net_received decimal(18,2) NOT NULL DEFAULT 0.00,
            account_id varchar(100) DEFAULT 'BCA Resmi',
            status varchar(30) NOT NULL DEFAULT 'completed',
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY payout_no (payout_no),
            KEY channel_id (channel_id),
            KEY payout_date (payout_date)
        ) $c;";

        // 9. Job Produksi & SPK
        $q[] = "CREATE TABLE " . self::t('jobs') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_no varchar(80) NOT NULL DEFAULT '',
            location varchar(100) DEFAULT '',
            deadline date DEFAULT NULL,
            status varchar(40) NOT NULL DEFAULT 'planned',
            target_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            product_id bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY job_no (job_no),
            KEY status (status)
        ) $c;";

        // 10A. Event Ledger aplikasi: jejak domain immutable-ish untuk korelasi proses.
        $q[] = "CREATE TABLE " . self::t('system_events') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(80) NOT NULL DEFAULT '',
            module varchar(50) NOT NULL DEFAULT '',
            entity_type varchar(80) NOT NULL DEFAULT '',
            entity_id varchar(100) NOT NULL DEFAULT '',
            request_id varchar(64) NOT NULL DEFAULT '',
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            level varchar(20) NOT NULL DEFAULT 'info',
            payload_json longtext DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY event_type (event_type),
            KEY module (module),
            KEY entity (entity_type,entity_id),
            KEY request_id (request_id),
            KEY created_at (created_at)
        ) $c;";

        // 10. Audit Trail & Jejak Aktivitas Forensik
        $q[] = "CREATE TABLE " . self::t('activity_logs') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            timestamp datetime NOT NULL,
            user_id bigint(20) unsigned DEFAULT 0,
            user_name varchar(100) DEFAULT '',
            user_role varchar(50) DEFAULT '',
            action varchar(100) NOT NULL DEFAULT '',
            module varchar(80) NOT NULL DEFAULT '',
            entity varchar(100) DEFAULT '',
            transaction_id varchar(100) DEFAULT '',
            before_data longtext DEFAULT NULL,
            after_data longtext DEFAULT NULL,
            diff_data text DEFAULT NULL,
            reason text DEFAULT NULL,
            level varchar(20) NOT NULL DEFAULT 'info',
            source varchar(50) NOT NULL DEFAULT 'engine',
            ip_address varchar(45) DEFAULT '',
            user_agent varchar(255) DEFAULT '',
            PRIMARY KEY  (id),
            KEY action (action),
            KEY module (module),
            KEY level (level),
            KEY timestamp (timestamp)
        ) $c;";

        // 3.6.52 Security: gate, visitor identity, vehicles, goods and CCTV registry.
        $q[] = "CREATE TABLE " . self::t('security_visitors') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, visitor_no varchar(40) NOT NULL, name varchar(190) NOT NULL, nik varchar(32) DEFAULT '', phone varchar(50) DEFAULT '', address text DEFAULT NULL, company varchar(190) DEFAULT '', notes text DEFAULT NULL, ktp_file varchar(255) DEFAULT '', ktp_uploaded_at datetime DEFAULT NULL, created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY visitor_no(visitor_no), KEY nik(nik), KEY name(name)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('security_visitor_visits') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, visitor_id bigint(20) unsigned NOT NULL, purpose varchar(190) DEFAULT '', host_name varchar(190) DEFAULT '', vehicle_plate varchar(30) DEFAULT '', carried_items text DEFAULT NULL, cctv_camera_id bigint(20) unsigned DEFAULT 0, checkin_at datetime NOT NULL, checkout_at datetime DEFAULT NULL, status varchar(30) NOT NULL DEFAULT 'inside', created_by bigint(20) unsigned DEFAULT 0, created_at datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id), KEY visitor_id(visitor_id), KEY status(status), KEY checkin_at(checkin_at)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('security_vehicles') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, plate varchar(30) NOT NULL, driver_name varchar(190) DEFAULT '', company varchar(190) DEFAULT '', purpose varchar(190) DEFAULT '', checkin_at datetime DEFAULT NULL, checkout_at datetime DEFAULT NULL, status varchar(30) NOT NULL DEFAULT 'inside', created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), KEY plate(plate), KEY status(status)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('security_goods') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, security_code varchar(50) NOT NULL, direction varchar(10) NOT NULL DEFAULT 'in', reference_no varchar(100) DEFAULT '', description varchar(255) NOT NULL, qty decimal(18,4) NOT NULL DEFAULT 0, verified_qty decimal(18,4) NOT NULL DEFAULT 0, unit varchar(30) DEFAULT 'pcs', vehicle_plate varchar(30) DEFAULT '', driver_name varchar(190) DEFAULT '', status varchar(30) NOT NULL DEFAULT 'pending', checkin_at datetime DEFAULT NULL, checkout_at datetime DEFAULT NULL, verified_by bigint(20) unsigned DEFAULT 0, verified_at datetime DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY security_code(security_code), KEY direction(direction), KEY status(status), KEY reference_no(reference_no)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('security_incidents') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, incident_code varchar(50) NOT NULL, category varchar(40) NOT NULL DEFAULT 'other', title varchar(190) NOT NULL, location varchar(190) DEFAULT '', description text DEFAULT NULL, cctv_camera_id bigint(20) unsigned DEFAULT 0, status varchar(30) NOT NULL DEFAULT 'open', created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, resolved_at datetime DEFAULT NULL, resolved_by bigint(20) unsigned DEFAULT 0, PRIMARY KEY(id), UNIQUE KEY incident_code(incident_code), KEY status(status), KEY category(category)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('security_cctv_cameras') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL, location varchar(190) DEFAULT '', device_type varchar(30) NOT NULL DEFAULT 'ip_camera', protocol varchar(30) NOT NULL DEFAULT 'onvif', channel varchar(50) DEFAULT '', stream_url text, source_endpoint varchar(255) DEFAULT '', username varchar(190) DEFAULT '', secret_ref varchar(190) DEFAULT '', status varchar(30) NOT NULL DEFAULT 'configured', last_checked_at datetime DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), KEY location(location), KEY device_type(device_type), KEY status(status)
        ) $c;";

        // 3.6.58 Central communication tables: CS and DODI chat share the same PK01 database.
        $q[] = "CREATE TABLE " . self::t('cs_tickets') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, ticket_no varchar(40) NOT NULL, channel varchar(30) NOT NULL DEFAULT 'customer', subject varchar(180) NOT NULL, status varchar(20) NOT NULL DEFAULT 'open', priority varchar(20) NOT NULL DEFAULT 'normal', customer_user_id bigint(20) unsigned NOT NULL DEFAULT 0, seller_user_id bigint(20) unsigned NOT NULL DEFAULT 0, assigned_user_id bigint(20) unsigned NOT NULL DEFAULT 0, order_ref varchar(80) NOT NULL DEFAULT '', created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY ticket_no(ticket_no), KEY status(status), KEY customer_user_id(customer_user_id), KEY seller_user_id(seller_user_id)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('cs_messages') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, ticket_id bigint(20) unsigned NOT NULL, sender_id bigint(20) unsigned NOT NULL, message longtext NOT NULL, created_at datetime NOT NULL, PRIMARY KEY(id), KEY ticket_created(ticket_id,created_at)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('chat_rooms') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, room_key varchar(180) NOT NULL, room_type varchar(40) NOT NULL DEFAULT 'production_job', title varchar(180) NOT NULL, job_id bigint(20) unsigned NULL, created_by bigint(20) unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY room_key(room_key), KEY job_id(job_id)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('chat_participants') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, room_id bigint(20) unsigned NOT NULL, user_id bigint(20) unsigned NOT NULL, last_read_id bigint(20) unsigned NOT NULL DEFAULT 0, joined_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY room_user(room_id,user_id), KEY user_id(user_id)
        ) $c;";
        $q[] = "CREATE TABLE " . self::t('chat_messages') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, room_id bigint(20) unsigned NOT NULL, sender_id bigint(20) unsigned NOT NULL, message longtext NOT NULL, reply_to bigint(20) unsigned NULL, created_at datetime NOT NULL, PRIMARY KEY(id), KEY room_created(room_id,created_at), KEY sender_id(sender_id)
        ) $c;";

        // CNC G-code Master Library: satu sumber file CNC per produk/varian.
        $q[] = "CREATE TABLE " . self::t('cnc_gcode_library') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(80) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            product_id bigint(20) unsigned NOT NULL DEFAULT 0,
            variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
            material varchar(120) NOT NULL DEFAULT '',
            machine_profile varchar(120) NOT NULL DEFAULT '',
            tool_profile varchar(120) NOT NULL DEFAULT '',
            width decimal(18,4) NOT NULL DEFAULT 0,
            height decimal(18,4) NOT NULL DEFAULT 0,
            depth decimal(18,4) NOT NULL DEFAULT 0,
            version varchar(40) NOT NULL DEFAULT '1.0',
            status varchar(20) NOT NULL DEFAULT 'active',
            attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            file_name varchar(255) NOT NULL DEFAULT '',
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY(id), UNIQUE KEY code(code), KEY product_id(product_id), KEY variant_id(variant_id), KEY status(status), KEY material(material)
        ) $c;";

        // Setoran Kasir -> Keuangan: kontrol serah-terima dana nyata.
        // Untuk CASH, perpindahan kas baru dibukukan saat Keuangan menerima.
        // Untuk TRANSFER, ini hanya bukti/verifikasi jika pembayaran sudah masuk Buku Kas.
        $q[] = "CREATE TABLE " . self::t('cashier_deposits') . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            deposit_no varchar(100) NOT NULL DEFAULT '',
            cashier_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            seller_account_id bigint(20) unsigned NOT NULL DEFAULT 0,
            invoice_id bigint(20) unsigned NOT NULL DEFAULT 0,
            order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            deposit_type varchar(30) NOT NULL DEFAULT 'cash',
            source_account varchar(100) NOT NULL DEFAULT 'Kas Tunai Toko',
            destination_account varchar(100) NOT NULL DEFAULT 'Kas/Bank Keuangan',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_method varchar(80) NOT NULL DEFAULT 'Kas Tunai',
            reference_no varchar(100) NOT NULL DEFAULT '',
            notes text DEFAULT NULL,
            status varchar(30) NOT NULL DEFAULT 'submitted',
            submitted_at datetime NOT NULL,
            received_at datetime DEFAULT NULL,
            received_by bigint(20) unsigned DEFAULT 0,
            approved_at datetime DEFAULT NULL,
            approved_by bigint(20) unsigned DEFAULT 0,
            approval_note text DEFAULT NULL,
            rejected_at datetime DEFAULT NULL,
            rejected_by bigint(20) unsigned DEFAULT 0,
            rejection_reason text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY deposit_no(deposit_no), KEY cashier_user_id(cashier_user_id), KEY seller_account_id(seller_account_id), KEY invoice_id(invoice_id), KEY order_id(order_id), KEY status(status), KEY deposit_type(deposit_type), KEY reference_no(reference_no)
        ) $c;";

        // Eksekusi Semua Skema Baru melalui dbDelta Resmi
        foreach ($q as $statement) {
            self::dbDelta_safe($statement);
        }

        // =========================================================================
        // MIGRATOR KOLOM AMAN: JAMIN TIDAK ADA DATA LAMA YANG HILANG
        // =========================================================================

        // Migrasi Master Produk: brand menjadi data katalog resmi, bukan postmeta WordPress.
        $prod = self::t('products');
        if ($prod && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $prod)) === $prod) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$prod}`", 0);
            if (!in_array('brand', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$prod}` ADD COLUMN `brand` VARCHAR(100) DEFAULT '' AFTER `category`");
            }
        }

        // Migrasi sales_accounts: termin pembayaran Seller menjadi master data tunggal.
        $sa = self::t('sales_accounts');
        if ($sa && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $sa)) === $sa) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$sa}`", 0);
            $add_cols = [
                'payment_term_days'  => "INT NOT NULL DEFAULT 0 AFTER affiliate_percent",
                'payment_term_label' => "VARCHAR(80) NOT NULL DEFAULT 'Langsung / COD' AFTER payment_term_days"
            ];
            foreach ($add_cols as $col => $definition) {
                if (!in_array($col, $cols, true)) {
                    $wpdb->query("ALTER TABLE `{$sa}` ADD COLUMN `{$col}` {$definition}");
                }
            }
        }

        // Migrasi sales_orders
        $so = self::t('sales_orders');
        if ($so && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $so)) === $so) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$so}`", 0);
            $add_cols = [
                'total_amount'     => "DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER price",
                'shipping_address' => "TEXT DEFAULT NULL AFTER customer_phone",
                'variant_id'       => "BIGINT UNSIGNED DEFAULT 0 AFTER shipping_address",
                'product_name'     => "VARCHAR(255) DEFAULT '' AFTER variant_id",
                'qty'              => "DECIMAL(10,2) NOT NULL DEFAULT 1.00 AFTER product_name",
                'price'            => "DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER qty",
                'hpp'              => "DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER price",
                'commission'       => "DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER total_amount",
                'payment_method'   => "VARCHAR(100) DEFAULT 'Transfer Bank' AFTER commission",
                'notes'            => "TEXT DEFAULT NULL AFTER shipping_status"
            ];
            foreach ($add_cols as $c_name => $c_def) {
                if (!in_array($c_name, $cols, true)) {
                    $wpdb->query("ALTER TABLE `{$so}` ADD `{$c_name}` {$c_def}");
                }
            }
        }

        // Migrasi cash_ledger
        $cl = self::t('cash_ledger');
        if ($cl && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $cl)) === $cl) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$cl}`", 0);
            if (!in_array('account', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$cl}` ADD `account` VARCHAR(100) NOT NULL DEFAULT 'Kas Tunai Toko' AFTER amount");
            }
            if (!in_array('reference_no', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$cl}` ADD `reference_no` VARCHAR(100) DEFAULT '' AFTER reference_id");
            }
            if (!in_array('created_by', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$cl}` ADD `created_by` BIGINT UNSIGNED DEFAULT 0 AFTER description");
            }
        }

        // Migrasi setoran Kasir -> Keuangan. Dokumen ini tidak membuat pendapatan baru.
        $cd = self::t('cashier_deposits');
        if (!$cd || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $cd)) !== $cd) {
            $c2 = $wpdb->get_charset_collate();
            self::dbDelta_safe("CREATE TABLE " . self::t('cashier_deposits') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, deposit_no varchar(100) NOT NULL DEFAULT '', cashier_user_id bigint(20) unsigned NOT NULL DEFAULT 0, seller_account_id bigint(20) unsigned NOT NULL DEFAULT 0, invoice_id bigint(20) unsigned NOT NULL DEFAULT 0, order_id bigint(20) unsigned NOT NULL DEFAULT 0, deposit_type varchar(30) NOT NULL DEFAULT 'cash', source_account varchar(100) NOT NULL DEFAULT 'Kas Tunai Toko', destination_account varchar(100) NOT NULL DEFAULT 'Kas/Bank Keuangan', amount decimal(18,2) NOT NULL DEFAULT 0.00, payment_method varchar(80) NOT NULL DEFAULT 'Kas Tunai', reference_no varchar(100) NOT NULL DEFAULT '', notes text DEFAULT NULL, status varchar(30) NOT NULL DEFAULT 'submitted', submitted_at datetime NOT NULL, received_at datetime DEFAULT NULL, received_by bigint(20) unsigned DEFAULT 0, approved_at datetime DEFAULT NULL, approved_by bigint(20) unsigned DEFAULT 0, approval_note text DEFAULT NULL, rejected_at datetime DEFAULT NULL, rejected_by bigint(20) unsigned DEFAULT 0, rejection_reason text DEFAULT NULL, created_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY deposit_no(deposit_no), KEY cashier_user_id(cashier_user_id), KEY seller_account_id(seller_account_id), KEY invoice_id(invoice_id), KEY order_id(order_id), KEY status(status), KEY deposit_type(deposit_type), KEY reference_no(reference_no)
            ) $c2;");
        }

        // Migrasi approval setoran Kasir (maker-checker).
        $cd = self::t('cashier_deposits');
        if ($cd && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $cd)) === $cd) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$cd}`", 0);
            $adds = [
                'approved_at'   => "DATETIME DEFAULT NULL AFTER status",
                'approved_by'   => "BIGINT UNSIGNED DEFAULT 0 AFTER approved_at",
                'approval_note' => "TEXT DEFAULT NULL AFTER approved_by"
            ];
            foreach ($adds as $col=>$def) if (!in_array($col,$cols,true)) $wpdb->query("ALTER TABLE `{$cd}` ADD COLUMN `{$col}` {$def}");
        }

        // Migrasi operational_costs
        $oc = self::t('operational_costs');
        if ($oc && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $oc)) === $oc) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$oc}`", 0);
            if (!in_array('cost_date', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$oc}` ADD `cost_date` DATE NOT NULL AFTER id");
                $wpdb->query("UPDATE `{$oc}` SET cost_date = DATE(created_at) WHERE cost_date = '0000-00-00' OR cost_date IS NULL");
            }
            if (!in_array('payment_method', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$oc}` ADD `payment_method` VARCHAR(100) DEFAULT 'Kas Tunai' AFTER amount");
            }
            if (!in_array('reference_no', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$oc}` ADD `reference_no` VARCHAR(100) DEFAULT '' AFTER payment_method");
            }
            if (!in_array('created_by', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$oc}` ADD `created_by` BIGINT UNSIGNED DEFAULT 0 AFTER description");
            }
            $migrations = [
                'status'=>"VARCHAR(30) NOT NULL DEFAULT 'pending_approval' AFTER created_at",
                'requested_by'=>"BIGINT UNSIGNED DEFAULT 0 AFTER status",
                'approved_by'=>"BIGINT UNSIGNED DEFAULT 0 AFTER requested_by",
                'approved_at'=>"DATETIME DEFAULT NULL AFTER approved_by",
                'paid_by'=>"BIGINT UNSIGNED DEFAULT 0 AFTER approved_at",
                'paid_at'=>"DATETIME DEFAULT NULL AFTER paid_by",
                'recipient_name'=>"VARCHAR(160) DEFAULT '' AFTER paid_at",
                'recipient_user_id'=>"BIGINT UNSIGNED DEFAULT 0 AFTER recipient_name",
                'receipt_no'=>"VARCHAR(100) DEFAULT '' AFTER recipient_user_id",
                'recipient_confirmed_at'=>"DATETIME DEFAULT NULL AFTER receipt_no",
                'recipient_confirmed_by'=>"BIGINT UNSIGNED DEFAULT 0 AFTER recipient_confirmed_at"
            ];
            foreach($migrations as $cn=>$cd){ if(!in_array($cn,$cols,true)) $wpdb->query("ALTER TABLE `{$oc}` ADD `{$cn}` {$cd}"); }
            // Data lama sudah benar-benar dibukukan oleh versi sebelumnya. Tandai sebagai paid agar tidak diproses ulang.
            $wpdb->query("UPDATE `{$oc}` SET status='paid' WHERE (status IS NULL OR status='')");
        }

        // Migrasi master karyawan untuk integrasi mesin fingerprint/absensi.
        $emp = self::t('employees');
        if ($emp && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $emp)) === $emp) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$emp}`", 0);
            if (!in_array('biometric_id', $cols, true)) $wpdb->query("ALTER TABLE `{$emp}` ADD `biometric_id` VARCHAR(128) DEFAULT '' AFTER user_id");
            if (!in_array('work_start', $cols, true)) $wpdb->query("ALTER TABLE `{$emp}` ADD `work_start` TIME DEFAULT NULL AFTER rate");
            if (!in_array('work_end', $cols, true)) $wpdb->query("ALTER TABLE `{$emp}` ADD `work_end` TIME DEFAULT NULL AFTER work_start");
            if (!in_array('work_days', $cols, true)) $wpdb->query("ALTER TABLE `{$emp}` ADD `work_days` VARCHAR(100) DEFAULT '1,2,3,4,5,6' AFTER work_end");
        }

        // Migrasi payroll
        $pr = self::t('payroll');
        if ($pr && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $pr)) === $pr) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$pr}`", 0);
            if (!in_array('name', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$pr}` ADD `name` VARCHAR(190) DEFAULT '' AFTER employee_id");
            }
            if (!in_array('payment_method', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$pr}` ADD `payment_method` VARCHAR(100) DEFAULT 'Transfer Bank' AFTER amount");
            }
            if (!in_array('description', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$pr}` ADD `description` TEXT DEFAULT NULL AFTER paid_at");
            }
        }

        // Migrasi modal pemilik
        $ct = self::t('capital_transactions');
        if ($ct && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $ct)) === $ct) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$ct}`", 0);
            if (!in_array('owner_id',$cols,true)) $wpdb->query("ALTER TABLE `{$ct}` ADD `owner_id` BIGINT UNSIGNED DEFAULT 0 AFTER amount");
            if (!in_array('capital_type',$cols,true)) $wpdb->query("ALTER TABLE `{$ct}` ADD `capital_type` VARCHAR(30) NOT NULL DEFAULT 'initial_capital' AFTER owner_id");
        }

        // Migrasi marketplace_payouts
        $mp = self::t('marketplace_payouts');
        if ($mp && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $mp)) === $mp) {
            $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$mp}`", 0);
            if (!in_array('account_id', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$mp}` ADD `account_id` VARCHAR(100) DEFAULT 'BCA Resmi' AFTER net_received");
            }
            if (!in_array('notes', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$mp}` ADD `notes` TEXT DEFAULT NULL AFTER status");
            }
            if (!in_array('created_by', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$mp}` ADD `created_by` BIGINT UNSIGNED DEFAULT 0 AFTER notes");
            }
            if (!in_array('owner_type', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$mp}` ADD `owner_type` VARCHAR(20) NOT NULL DEFAULT 'company' AFTER notes");
            }
            if (!in_array('seller_account_id', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$mp}` ADD `seller_account_id` BIGINT UNSIGNED DEFAULT 0 AFTER owner_type");
            }
            if (!in_array('seller_invoice_id', $cols, true)) {
                $wpdb->query("ALTER TABLE `{$mp}` ADD `seller_invoice_id` BIGINT UNSIGNED DEFAULT 0 AFTER seller_account_id");
            }
        }


        // =========================================================================
        // SKEMA OPERASIONAL LENGKAP
        // Versi sebelumnya hanya membuat sebagian tabel, sementara modul produksi,
        // stok, seller, retur, marketplace dan AI sudah memanggil tabel lain.
        // Semua tabel di bawah dibuat via dbDelta agar aman terhadap data lama.
        // =========================================================================
        // Schema SDM: absensi multi-perangkat + cuti terintegrasi.
        $attendance_sql = [
            "CREATE TABLE " . self::t('attendance_devices') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, device_code varchar(80) NOT NULL DEFAULT '', name varchar(190) NOT NULL DEFAULT '', device_type varchar(40) NOT NULL DEFAULT 'fingerprint', vendor varchar(100) DEFAULT '', model varchar(100) DEFAULT '', endpoint varchar(255) DEFAULT '', secret_hash varchar(255) DEFAULT '', status varchar(30) NOT NULL DEFAULT 'active', last_seen_at datetime DEFAULT NULL, created_at datetime NOT NULL, updated_at datetime DEFAULT NULL, PRIMARY KEY(id), UNIQUE KEY device_code(device_code), KEY status(status)
            ) $c;",
            "CREATE TABLE " . self::t('attendance_records') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, employee_id bigint(20) unsigned NOT NULL DEFAULT 0, employee_code varchar(64) NOT NULL DEFAULT '', biometric_id varchar(128) NOT NULL DEFAULT '', device_id bigint(20) unsigned NOT NULL DEFAULT 0, punch_type varchar(20) NOT NULL DEFAULT 'auto', punch_at datetime NOT NULL, work_date date NOT NULL, source varchar(40) NOT NULL DEFAULT 'device', raw_reference varchar(190) DEFAULT '', status varchar(30) NOT NULL DEFAULT 'accepted', late_minutes int NOT NULL DEFAULT 0, notes text DEFAULT NULL, created_at datetime NOT NULL, PRIMARY KEY(id), KEY employee_id(employee_id), KEY employee_code(employee_code), KEY biometric_id(biometric_id), KEY work_date(work_date), KEY punch_at(punch_at), KEY device_id(device_id)
            ) $c;",
            "CREATE TABLE " . self::t('leave_types') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, code varchar(40) NOT NULL DEFAULT '', name varchar(100) NOT NULL DEFAULT '', annual_days decimal(8,2) NOT NULL DEFAULT 0, requires_approval tinyint(1) NOT NULL DEFAULT 1, paid tinyint(1) NOT NULL DEFAULT 1, active tinyint(1) NOT NULL DEFAULT 1, created_at datetime NOT NULL, updated_at datetime DEFAULT NULL, PRIMARY KEY(id), UNIQUE KEY code(code)
            ) $c;",
            "CREATE TABLE " . self::t('leave_balances') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, employee_id bigint(20) unsigned NOT NULL, leave_type_id bigint(20) unsigned NOT NULL, year smallint NOT NULL, entitlement decimal(8,2) NOT NULL DEFAULT 0, carryover decimal(8,2) NOT NULL DEFAULT 0, adjustment decimal(8,2) NOT NULL DEFAULT 0, used_days decimal(8,2) NOT NULL DEFAULT 0, notes text DEFAULT NULL, created_at datetime NOT NULL, updated_at datetime DEFAULT NULL, PRIMARY KEY(id), UNIQUE KEY employee_leave_year(employee_id,leave_type_id,year), KEY employee_id(employee_id), KEY year(year)
            ) $c;",
            "CREATE TABLE " . self::t('leave_requests') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, request_no varchar(64) NOT NULL DEFAULT '', employee_id bigint(20) unsigned NOT NULL, leave_type_id bigint(20) unsigned NOT NULL, start_date date NOT NULL, end_date date NOT NULL, days decimal(8,2) NOT NULL DEFAULT 0, reason text DEFAULT NULL, attachment_id bigint(20) unsigned DEFAULT 0, status varchar(30) NOT NULL DEFAULT 'pending', approved_by bigint(20) unsigned DEFAULT 0, approved_at datetime DEFAULT NULL, created_at datetime NOT NULL, updated_at datetime DEFAULT NULL, PRIMARY KEY(id), UNIQUE KEY request_no(request_no), KEY employee_id(employee_id), KEY status(status), KEY dates(start_date,end_date)
            ) $c;",
            "CREATE TABLE " . self::t('attendance_import_logs') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT, device_id bigint(20) unsigned DEFAULT 0, source varchar(40) NOT NULL DEFAULT 'api', file_name varchar(190) DEFAULT '', rows_received int NOT NULL DEFAULT 0, rows_accepted int NOT NULL DEFAULT 0, rows_rejected int NOT NULL DEFAULT 0, error_summary text DEFAULT NULL, imported_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), KEY device_id(device_id), KEY created_at(created_at)
            ) $c;"
        ];
        foreach($attendance_sql as $sql) self::dbDelta_safe($sql);

        self::install_operational_schema($c);

        // Catat Versi Terkini Database
        update_option('pk01_db_version', '3.6.0');
        self::ensure_pages();
    }

    public static function install_operational_schema($charset_collate = '') {
        global $wpdb;
        if (!$charset_collate) $charset_collate = $wpdb->get_charset_collate();
        self::init();

        $schemas = [];

        $schemas['product_gallery'] = "CREATE TABLE ".self::t('product_gallery')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            product_id bigint(20) unsigned NOT NULL,
            attachment_id bigint(20) unsigned NOT NULL,
            sort_order int(11) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY product_id (product_id), KEY attachment_id (attachment_id)
        ) $charset_collate;";

        $schemas['customers'] = "CREATE TABLE ".self::t('customers')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(64) NOT NULL DEFAULT '',
            name varchar(190) NOT NULL DEFAULT '',
            phone varchar(80) DEFAULT '',
            email varchar(190) DEFAULT '',
            address text DEFAULT NULL,
            user_id bigint(20) unsigned DEFAULT 0,
            status varchar(30) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY code (code), KEY phone (phone), KEY status (status)
        ) $charset_collate;";

        $schemas['purchase_orders'] = "CREATE TABLE ".self::t('purchase_orders')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            po_no varchar(100) NOT NULL DEFAULT '',
            supplier_id bigint(20) unsigned DEFAULT 0,
            order_date date DEFAULT NULL,
            status varchar(30) NOT NULL DEFAULT 'draft',
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            paid_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_status varchar(30) NOT NULL DEFAULT 'unpaid',
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY po_no (po_no), KEY supplier_id (supplier_id), KEY status (status)
        ) $charset_collate;";

        $schemas['purchase_order_items'] = "CREATE TABLE ".self::t('purchase_order_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            po_id bigint(20) unsigned NOT NULL,
            material_id bigint(20) unsigned NOT NULL,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            unit_cost decimal(18,2) NOT NULL DEFAULT 0.00,
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            PRIMARY KEY (id), KEY po_id (po_id), KEY material_id (material_id)
        ) $charset_collate;";

        $schemas['goods_receipts'] = "CREATE TABLE ".self::t('goods_receipts')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            receipt_no varchar(100) NOT NULL DEFAULT '',
            po_id bigint(20) unsigned DEFAULT 0,
            material_id bigint(20) unsigned DEFAULT 0,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            received_at datetime NOT NULL,
            received_by bigint(20) unsigned DEFAULT 0,
            notes text DEFAULT NULL,
            PRIMARY KEY (id), KEY receipt_no (receipt_no), KEY po_id (po_id), KEY material_id (material_id)
        ) $charset_collate;";

        $schemas['stock_transactions'] = "CREATE TABLE ".self::t('stock_transactions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            stock_type varchar(30) NOT NULL DEFAULT 'material',
            item_id bigint(20) unsigned NOT NULL DEFAULT 0,
            variant_id bigint(20) unsigned DEFAULT 0,
            material_id bigint(20) unsigned DEFAULT 0,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            direction varchar(10) NOT NULL DEFAULT 'in',
            reference_type varchar(50) NOT NULL DEFAULT 'manual',
            reference_id bigint(20) unsigned DEFAULT 0,
            reference_no varchar(100) DEFAULT '',
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY item_id (item_id), KEY variant_id (variant_id), KEY material_id (material_id),
            KEY reference_type (reference_type), KEY created_at (created_at)
        ) $charset_collate;";

        // Marketplace mapping/export adalah struktur konfigurasi/riwayat integrasi.
        // Tidak berisi data transaksi contoh dan tidak membuat produk marketplace otomatis.
        $schemas['marketplace_mappings'] = "CREATE TABLE ".self::t('marketplace_mappings')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            marketplace varchar(40) NOT NULL DEFAULT '',
            variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
            external_product_id varchar(190) NOT NULL DEFAULT '',
            external_sku varchar(190) NOT NULL DEFAULT '',
            external_title varchar(255) DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'active',
            metadata longtext DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY marketplace_variant (marketplace,variant_id),
            KEY external_product_id (external_product_id),
            KEY external_sku (external_sku),
            KEY status (status)
        ) $charset_collate;";

        $schemas['marketplace_exports'] = "CREATE TABLE ".self::t('marketplace_exports')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            marketplace varchar(40) NOT NULL DEFAULT '',
            export_type varchar(40) NOT NULL DEFAULT 'catalog',
            file_name varchar(190) DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'created',
            row_count int unsigned NOT NULL DEFAULT 0,
            file_path text DEFAULT NULL,
            error_message text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY marketplace (marketplace),
            KEY export_type (export_type),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

        $schemas['job_items'] = "CREATE TABLE ".self::t('job_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned NOT NULL,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            unit varchar(30) NOT NULL DEFAULT 'pcs',
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY job_id (job_id), KEY variant_id (variant_id)
        ) $charset_collate;";

        $schemas['job_role_catalog'] = "CREATE TABLE ".self::t('job_role_catalog')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            role_code varchar(60) NOT NULL,
            role_name varchar(190) NOT NULL,
            domain varchar(60) NOT NULL DEFAULT 'operasional',
            keywords text DEFAULT NULL,
            required_permissions text DEFAULT NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY role_code(role_code), KEY domain(domain), KEY active(active)
        ) $charset_collate;";
        $schemas['employee_job_roles'] = "CREATE TABLE ".self::t('employee_job_roles')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            employee_id bigint(20) unsigned NOT NULL,
            role_code varchar(60) NOT NULL,
            skill_level varchar(30) NOT NULL DEFAULT 'normal',
            active tinyint(1) NOT NULL DEFAULT 1,
            source varchar(30) NOT NULL DEFAULT 'manual',
            confidence decimal(6,4) NOT NULL DEFAULT 0.0000,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY(id), UNIQUE KEY employee_role(employee_id,role_code), KEY employee_id(employee_id), KEY role_code(role_code)
        ) $charset_collate;";
        $schemas['job_assignments'] = "CREATE TABLE ".self::t('job_assignments')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_id bigint(20) unsigned NOT NULL,
            employee_id bigint(20) unsigned NOT NULL,
            status varchar(30) NOT NULL DEFAULT 'assigned',
            notes text DEFAULT NULL,
            assigned_at datetime NOT NULL,
            accepted_at datetime DEFAULT NULL,
            started_at datetime DEFAULT NULL,
            completed_at datetime DEFAULT NULL,
            returned_at datetime DEFAULT NULL,
            assigned_by bigint(20) unsigned DEFAULT 0,
            PRIMARY KEY (id), KEY job_id (job_id), KEY employee_id (employee_id), KEY status (status), KEY assigned_by (assigned_by)
        ) $charset_collate;";

        $schemas['job_materials'] = "CREATE TABLE ".self::t('job_materials')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_id bigint(20) unsigned NOT NULL,
            material_id bigint(20) unsigned NOT NULL,
            issued_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            used_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            returned_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            issued_at datetime NOT NULL,
            used_at datetime DEFAULT NULL,
            returned_at datetime DEFAULT NULL,
            notes text DEFAULT NULL,
            PRIMARY KEY (id), KEY job_id (job_id), KEY material_id (material_id)
        ) $charset_collate;";

        $schemas['production_results'] = "CREATE TABLE ".self::t('production_results')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_id bigint(20) unsigned NOT NULL,
            good_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            reject_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            status varchar(30) NOT NULL DEFAULT 'approved',
            approved tinyint(1) NOT NULL DEFAULT 1,
            batch_code varchar(120) NOT NULL DEFAULT '',
            barcode_value varchar(120) NOT NULL DEFAULT '',
            qr_payload longtext DEFAULT NULL,
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY job_id (job_id), KEY status (status)
        ) $charset_collate;";
        $schemas['job_completion_reports'] = "CREATE TABLE ".self::t('job_completion_reports')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, assignment_id bigint(20) unsigned NOT NULL, job_id bigint(20) unsigned NOT NULL, employee_id bigint(20) unsigned NOT NULL,
            good_qty decimal(18,4) NOT NULL DEFAULT 0.0000, reject_qty decimal(18,4) NOT NULL DEFAULT 0.0000, photo_ids longtext DEFAULT NULL, notes longtext DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, updated_at datetime DEFAULT NULL,
            PRIMARY KEY(id), KEY assignment_id(assignment_id), KEY job_id(job_id), KEY employee_id(employee_id)
        ) $charset_collate;";

        $schemas['production_units'] = "CREATE TABLE ".self::t('production_units')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            job_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned NOT NULL,
            unit_no varchar(100) NOT NULL DEFAULT '',
            unit_id varchar(120) NOT NULL DEFAULT '',
            batch_no varchar(100) NOT NULL DEFAULT '',
            production_date date DEFAULT NULL,
            status varchar(30) NOT NULL DEFAULT 'approved',
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY job_id (job_id), KEY variant_id (variant_id), KEY unit_no (unit_no), KEY unit_id (unit_id)
        ) $charset_collate;";

        $schemas['job_wages'] = "CREATE TABLE ".self::t('job_wages')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, job_id bigint(20) unsigned NOT NULL, employee_id bigint(20) unsigned NOT NULL,
            payroll_id bigint(20) unsigned DEFAULT 0, job_detail varchar(255) NOT NULL DEFAULT '', qty decimal(18,4) NOT NULL DEFAULT 1.0000,
            unit varchar(40) NOT NULL DEFAULT 'job', rate decimal(18,2) NOT NULL DEFAULT 0.00, amount decimal(18,2) NOT NULL DEFAULT 0.00,
            period_key varchar(7) NOT NULL DEFAULT '', status varchar(30) NOT NULL DEFAULT 'pending', payment_method varchar(100) DEFAULT 'Transfer Bank',
            paid_at date DEFAULT NULL, reference_no varchar(100) DEFAULT '', notes text DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY job_id(job_id), KEY employee_id(employee_id), KEY payroll_id(payroll_id), KEY period_key(period_key), KEY status(status)
        ) $charset_collate;";
        $schemas['job_wage_payments'] = "CREATE TABLE ".self::t('job_wage_payments')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, job_wage_id bigint(20) unsigned NOT NULL, amount decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_method varchar(100) DEFAULT 'Transfer Bank', reference_no varchar(100) DEFAULT '', paid_at datetime NOT NULL, notes text DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0,
            PRIMARY KEY(id), KEY job_wage_id(job_wage_id), KEY paid_at(paid_at)
        ) $charset_collate;";
        $schemas['channels'] = "CREATE TABLE ".self::t('channels')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(50) NOT NULL DEFAULT '',
            name varchar(100) NOT NULL DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY code (code), KEY status (status)
        ) $charset_collate;";

        $schemas['sales_order_items'] = "CREATE TABLE ".self::t('sales_order_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned DEFAULT 0,
            product_name varchar(255) DEFAULT '',
            qty decimal(10,2) NOT NULL DEFAULT 1.00,
            unit_price decimal(18,2) NOT NULL DEFAULT 0.00,
            hpp decimal(18,2) NOT NULL DEFAULT 0.00,
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            PRIMARY KEY (id), KEY order_id (order_id), KEY variant_id (variant_id)
        ) $charset_collate;";

        $schemas['marketplace_deductions'] = "CREATE TABLE ".self::t('marketplace_deductions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            payout_id bigint(20) unsigned NOT NULL,
            type varchar(80) NOT NULL DEFAULT 'fee',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            description text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY payout_id (payout_id)
        ) $charset_collate;";

        $schemas['seller_stock'] = "CREATE TABLE ".self::t('seller_stock')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned NOT NULL,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            reserved_qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY seller_variant (seller_account_id,variant_id), KEY variant_id (variant_id)
        ) $charset_collate;";

        $schemas['seller_orders'] = "CREATE TABLE ".self::t('seller_orders')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_no varchar(100) NOT NULL DEFAULT '',
            seller_account_id bigint(20) unsigned NOT NULL,
            status varchar(30) NOT NULL DEFAULT 'requested',
            subtotal decimal(18,2) NOT NULL DEFAULT 0.00,
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            marketplace varchar(50) DEFAULT '',
            marketplace_order_no varchar(120) DEFAULT '',
            tracking_no varchar(120) DEFAULT '',
            marketplace_sale_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY order_no (order_no), KEY seller_account_id (seller_account_id), KEY status (status)
        ) $charset_collate;";

        $schemas['seller_order_items'] = "CREATE TABLE ".self::t('seller_order_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned NOT NULL,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            unit_price decimal(18,2) NOT NULL DEFAULT 0.00,
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            PRIMARY KEY (id), KEY order_id (order_id), KEY variant_id (variant_id)
        ) $charset_collate;";

        $schemas['finished_product_purchase_requests'] = "CREATE TABLE ".self::t('finished_product_purchase_requests')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_no varchar(100) NOT NULL DEFAULT '', variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
            supplier_id bigint(20) unsigned DEFAULT 0, qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            source_order_id bigint(20) unsigned DEFAULT 0, status varchar(30) NOT NULL DEFAULT 'requested',
            notes text DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY request_no (request_no), KEY variant_id (variant_id), KEY supplier_id (supplier_id), KEY source_order_id (source_order_id), KEY status (status)
        ) $charset_collate;";

        $schemas['finished_product_purchases'] = "CREATE TABLE ".self::t('finished_product_purchases')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            purchase_no varchar(100) NOT NULL DEFAULT '', supplier_id bigint(20) unsigned DEFAULT 0,
            variant_id bigint(20) unsigned NOT NULL DEFAULT 0, qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            unit_cost decimal(18,2) NOT NULL DEFAULT 0.00, total decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'received', received_at datetime NOT NULL,
            notes text DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY purchase_no (purchase_no), KEY supplier_id (supplier_id), KEY variant_id (variant_id), KEY status (status)
        ) $charset_collate;";

        $schemas['seller_marketplace_items'] = "CREATE TABLE ".self::t('seller_marketplace_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            marketplace varchar(50) NOT NULL DEFAULT '',
            seller_sku varchar(120) NOT NULL DEFAULT '',
            seller_product_name varchar(190) NOT NULL DEFAULT '',
            seller_model varchar(120) NOT NULL DEFAULT '',
            seller_size varchar(120) NOT NULL DEFAULT '',
            variant_id bigint(20) unsigned NOT NULL DEFAULT 0,
            match_status varchar(30) NOT NULL DEFAULT 'pending',
            match_method varchar(40) NOT NULL DEFAULT '',
            confidence decimal(5,2) NOT NULL DEFAULT 0.00,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY seller_account_id (seller_account_id),
            KEY marketplace (marketplace),
            KEY seller_sku (seller_sku),
            KEY variant_id (variant_id),
            KEY match_status (match_status)
        ) $charset_collate;";

        $schemas['seller_sales'] = "CREATE TABLE ".self::t('seller_sales')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            order_id bigint(20) unsigned DEFAULT 0,
            variant_id bigint(20) unsigned DEFAULT 0,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            hpp decimal(18,2) NOT NULL DEFAULT 0.00,
            unit_price decimal(18,2) NOT NULL DEFAULT 0.00,
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            sold_at datetime NOT NULL,
            marketplace varchar(50) DEFAULT '',
            marketplace_order_no varchar(120) DEFAULT '',
            tracking_no varchar(120) DEFAULT '',
            source_type varchar(30) NOT NULL DEFAULT 'seller_order',
            return_id bigint(20) unsigned DEFAULT 0,
            commission_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'pending',
            PRIMARY KEY (id), KEY seller_account_id (seller_account_id), KEY order_id (order_id), KEY sold_at (sold_at)
        ) $charset_collate;";

        $schemas['seller_invoices'] = "CREATE TABLE ".self::t('seller_invoices')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            order_id bigint(20) unsigned DEFAULT 0,
            invoice_no varchar(100) DEFAULT '',
            total decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'unpaid',
            due_date date DEFAULT NULL,
            paid_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY seller_account_id (seller_account_id), KEY status (status)
        ) $charset_collate;";

        $schemas['seller_payments'] = "CREATE TABLE ".self::t('seller_payments')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            invoice_id bigint(20) unsigned NOT NULL,
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            payment_method varchar(80) DEFAULT 'Transfer Bank',
            paid_at datetime NOT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            deposit_id bigint(20) unsigned DEFAULT 0,
            external_reference varchar(120) DEFAULT '',
            PRIMARY KEY (id), KEY invoice_id (invoice_id), KEY paid_at (paid_at), KEY deposit_id (deposit_id)
        ) $charset_collate;";

        $schemas['seller_credit_ledger'] = "CREATE TABLE ".self::t('seller_credit_ledger')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            return_id bigint(20) unsigned DEFAULT 0,
            invoice_id bigint(20) unsigned DEFAULT 0,
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(20) NOT NULL DEFAULT 'available',
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            used_at datetime DEFAULT NULL,
            PRIMARY KEY(id), KEY seller_account_id(seller_account_id), KEY return_id(return_id), KEY invoice_id(invoice_id), KEY status(status)
        ) $charset_collate;";

        $schemas['seller_contract_prices'] = "CREATE TABLE ".self::t('seller_contract_prices')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned NOT NULL,
            price decimal(18,2) NOT NULL DEFAULT 0.00,
            active tinyint(1) NOT NULL DEFAULT 1,
            valid_from date DEFAULT NULL,
            valid_to date DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY seller_variant (seller_account_id,variant_id), KEY active (active)
        ) $charset_collate;";

        $schemas['affiliate_links'] = "CREATE TABLE ".self::t('affiliate_links')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_account_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned DEFAULT 0,
            affiliate_code varchar(100) NOT NULL DEFAULT '',
            clicks int(11) NOT NULL DEFAULT 0,
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY affiliate_code (affiliate_code), KEY seller_account_id (seller_account_id), KEY active (active)
        ) $charset_collate;";

        $schemas['affiliate_attributions'] = "CREATE TABLE ".self::t('affiliate_attributions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            affiliate_link_id bigint(20) unsigned NOT NULL,
            visit_key varchar(120) NOT NULL DEFAULT '',
            order_id bigint(20) unsigned DEFAULT 0,
            status varchar(30) NOT NULL DEFAULT 'pending',
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY affiliate_link_id (affiliate_link_id), KEY visit_key (visit_key), KEY order_id (order_id)
        ) $charset_collate;";

        $schemas['product_prices'] = "CREATE TABLE ".self::t('product_prices')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            variant_id bigint(20) unsigned NOT NULL,
            channel_id varchar(50) NOT NULL DEFAULT 'website',
            price decimal(18,2) NOT NULL DEFAULT 0.00,
            active tinyint(1) NOT NULL DEFAULT 1,
            valid_from date DEFAULT NULL,
            valid_to date DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY variant_id (variant_id), KEY channel_id (channel_id), KEY active (active)
        ) $charset_collate;";

        $schemas['price_rules'] = "CREATE TABLE ".self::t('price_rules')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(190) NOT NULL DEFAULT '',
            rule_type varchar(50) NOT NULL DEFAULT 'discount',
            value decimal(18,4) NOT NULL DEFAULT 0.0000,
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY active (active)
        ) $charset_collate;";

        $schemas['capital_transactions'] = "CREATE TABLE ".self::t('capital_transactions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            reference_no varchar(100) NOT NULL DEFAULT '',
            owner_id bigint(20) unsigned DEFAULT 0, investor_id bigint(20) unsigned DEFAULT 0, capital_type varchar(30) NOT NULL DEFAULT 'initial_capital',
            source varchar(190) DEFAULT '',
            description text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        $schemas['stock_adjustments'] = "CREATE TABLE ".self::t('stock_adjustments')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            stock_type varchar(30) NOT NULL DEFAULT 'material',
            item_id bigint(20) unsigned NOT NULL DEFAULT 0,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            direction varchar(10) NOT NULL DEFAULT 'in',
            reason varchar(190) DEFAULT '',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY stock_type (stock_type), KEY item_id (item_id)
        ) $charset_collate;";

        $schemas['returns'] = "CREATE TABLE ".self::t('returns')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            return_no varchar(100) NOT NULL DEFAULT '',
            order_id bigint(20) unsigned DEFAULT 0,
            seller_order_id bigint(20) unsigned DEFAULT 0,
            customer_name varchar(190) DEFAULT '',
            refund_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'pending',
            reason text DEFAULT NULL,
            created_at datetime NOT NULL,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY return_no (return_no), KEY order_id (order_id), KEY status (status)
        ) $charset_collate;";

        $schemas['return_items'] = "CREATE TABLE ".self::t('return_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            return_id bigint(20) unsigned NOT NULL,
            variant_id bigint(20) unsigned DEFAULT 0,
            qty decimal(18,4) NOT NULL DEFAULT 0.0000,
            condition_status varchar(30) NOT NULL DEFAULT 'good',
            PRIMARY KEY (id), KEY return_id (return_id), KEY variant_id (variant_id)
        ) $charset_collate;";

        $schemas['warehouse_documents'] = "CREATE TABLE ".self::t('warehouse_documents')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            doc_no varchar(100) NOT NULL DEFAULT '',
            doc_type varchar(40) NOT NULL DEFAULT 'outbound_courier',
            direction varchar(10) NOT NULL DEFAULT 'out',
            tracking_no varchar(120) DEFAULT '',
            internal_shipment_no varchar(100) DEFAULT '',
            courier_name varchar(100) DEFAULT '',
            seller_name varchar(190) DEFAULT '',
            order_id bigint(20) unsigned DEFAULT 0,
            shipment_id bigint(20) unsigned DEFAULT 0,
            return_id bigint(20) unsigned DEFAULT 0,
            reference_no varchar(120) DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'completed',
            notes text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY doc_no(doc_no), KEY doc_type(doc_type), KEY tracking_no(tracking_no), KEY shipment_id(shipment_id), KEY return_id(return_id), KEY created_at(created_at)
        ) $charset_collate;";

        $schemas['tracking_events'] = "CREATE TABLE ".self::t('tracking_events')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            shipment_id bigint(20) unsigned NOT NULL,
            status varchar(50) NOT NULL DEFAULT '',
            event_code varchar(80) DEFAULT '',
            description text DEFAULT NULL,
            location varchar(190) DEFAULT '',
            event_time datetime DEFAULT NULL,
            source varchar(50) DEFAULT 'manual',
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY shipment_id (shipment_id), KEY event_time (event_time)
        ) $charset_collate;";

        $schemas['shipment_alerts'] = "CREATE TABLE ".self::t('shipment_alerts')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            shipment_id bigint(20) unsigned NOT NULL,
            alert_type varchar(50) NOT NULL DEFAULT '',
            message text DEFAULT NULL,
            status varchar(30) NOT NULL DEFAULT 'open',
            created_at datetime NOT NULL,
            resolved_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY shipment_id (shipment_id), KEY status (status)
        ) $charset_collate;";

        $schemas['ai_logs'] = "CREATE TABLE ".self::t('ai_logs')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT 0,
            action varchar(100) NOT NULL DEFAULT '',
            prompt longtext,
            response longtext,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY user_id (user_id), KEY action (action)
        ) $charset_collate;";

        $schemas['ai_conversations'] = "CREATE TABLE ".self::t('ai_conversations')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT 0,
            title varchar(190) DEFAULT '',
            messages longtext,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY user_id (user_id)
        ) $charset_collate;";

        $schemas['ai_approvals'] = "CREATE TABLE ".self::t('ai_approvals')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT 0,
            action varchar(100) NOT NULL DEFAULT '',
            payload longtext,
            status varchar(30) NOT NULL DEFAULT 'pending',
            created_at datetime NOT NULL,
            approved_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY status (status)
        ) $charset_collate;";

        $schemas['entry_guards'] = "CREATE TABLE ".self::t('entry_guards')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            domain_key varchar(64) NOT NULL,
            natural_key varchar(190) NOT NULL,
            natural_hash char(64) NOT NULL,
            payload_json longtext DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY natural_hash(natural_hash), KEY domain_key(domain_key), KEY created_at(created_at)
        ) $charset_collate;";

        $schemas['idempotency_keys'] = "CREATE TABLE ".self::t('idempotency_keys')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            idempotency_key varchar(64) NOT NULL,
            action varchar(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            request_hash varchar(64) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'processing',
            response_code int(11) NOT NULL DEFAULT 200,
            response_data longtext,
            locked_until datetime NOT NULL,
            expires_at date DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY idempotency_key (idempotency_key), KEY action (action), KEY user_id (user_id)
        ) $charset_collate;";

        $schemas['backup_history'] = "CREATE TABLE ".self::t('backup_history')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            file_name varchar(255) NOT NULL DEFAULT '',
            file_path text,
            status varchar(30) NOT NULL DEFAULT 'completed',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        $schemas['sales_commissions'] = "CREATE TABLE ".self::t('sales_commissions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            employee_id bigint(20) unsigned NOT NULL DEFAULT 0,
            base_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            commission_percent decimal(8,4) NOT NULL DEFAULT 0.0000,
            commission_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            status varchar(30) NOT NULL DEFAULT 'pending',
            reference_no varchar(100) DEFAULT '',
            created_at datetime NOT NULL,
            approved_at datetime DEFAULT NULL,
            paid_at datetime DEFAULT NULL,
            PRIMARY KEY (id), KEY order_id (order_id), KEY employee_id (employee_id), KEY status (status)
        ) $charset_collate;";

        $schemas['test_runs'] = "CREATE TABLE ".self::t('test_runs')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            run_code varchar(80) NOT NULL, label varchar(190) NOT NULL DEFAULT '', status varchar(30) NOT NULL DEFAULT 'active',
            created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, completed_at datetime DEFAULT NULL,
            expected_json longtext DEFAULT NULL, actual_json longtext DEFAULT NULL, assertions_json longtext DEFAULT NULL, passed tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id), UNIQUE KEY run_code (run_code), KEY status (status)
        ) $charset_collate;";
        $schemas['test_entities'] = "CREATE TABLE ".self::t('test_entities')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, run_id bigint(20) unsigned NOT NULL, table_name varchar(100) NOT NULL,
            row_id bigint(20) unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY (id), KEY run_id (run_id), KEY table_row (table_name,row_id)
        ) $charset_collate;";
        $schemas['test_sequence_snapshots'] = "CREATE TABLE ".self::t('test_sequence_snapshots')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, run_id bigint(20) unsigned NOT NULL, doc_type varchar(50) NOT NULL,
            period_key varchar(20) NOT NULL, sequence_id bigint(20) unsigned DEFAULT 0, last_seq bigint(20) unsigned DEFAULT 0,
            PRIMARY KEY (id), KEY run_id (run_id), KEY doc_type (doc_type)
        ) $charset_collate;";

        // 3.6 Ownership, Fixed Assets & Inventory Valuation
        $schemas['company_owners'] = "CREATE TABLE ".self::t('company_owners')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL DEFAULT '',
            share_percent decimal(8,4) NOT NULL DEFAULT 0.0000, status varchar(20) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL, PRIMARY KEY (id), KEY status (status)
        ) $charset_collate;";
        $schemas['owner_transactions'] = "CREATE TABLE ".self::t('owner_transactions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, owner_id bigint(20) unsigned NOT NULL,
            transaction_type varchar(40) NOT NULL DEFAULT 'profit_draw', amount decimal(18,2) NOT NULL DEFAULT 0.00,
            period_key varchar(20) DEFAULT '', reference_no varchar(100) DEFAULT '', description text DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), KEY owner_id(owner_id), KEY transaction_type(transaction_type)
        ) $charset_collate;";
        $schemas['investors'] = "CREATE TABLE ".self::t('investors')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL DEFAULT '',
            investment_reference varchar(100) DEFAULT '', contact varchar(100) DEFAULT '', notes text DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'active', created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY status(status)
        ) $charset_collate;";
        $schemas['investor_transactions'] = "CREATE TABLE ".self::t('investor_transactions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, investor_id bigint(20) unsigned NOT NULL,
            transaction_type varchar(40) NOT NULL DEFAULT 'investment_in', amount decimal(18,2) NOT NULL DEFAULT 0.00,
            reference_no varchar(100) DEFAULT '', description text DEFAULT NULL, created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY investor_id(investor_id), KEY transaction_type(transaction_type)
        ) $charset_collate;";
        $schemas['profit_distributions'] = "CREATE TABLE ".self::t('profit_distributions')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, period_end date NOT NULL, profit_base decimal(18,2) NOT NULL DEFAULT 0.00,
            distributable_profit decimal(18,2) NOT NULL DEFAULT 0.00, status varchar(30) NOT NULL DEFAULT 'draft', created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY period_end(period_end), KEY status(status)
        ) $charset_collate;";
        $schemas['profit_distribution_items'] = "CREATE TABLE ".self::t('profit_distribution_items')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, distribution_id bigint(20) unsigned NOT NULL, owner_id bigint(20) unsigned DEFAULT 0, investor_id bigint(20) unsigned DEFAULT 0,
            beneficiary_type varchar(20) NOT NULL DEFAULT 'owner', share_percent decimal(8,4) NOT NULL DEFAULT 0.0000, allocated_amount decimal(18,2) NOT NULL DEFAULT 0.00, withdrawn_amount decimal(18,2) NOT NULL DEFAULT 0.00, created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY distribution_id(distribution_id), KEY owner_id(owner_id), KEY investor_id(investor_id), KEY beneficiary_type(beneficiary_type)
        ) $charset_collate;";
        $schemas['fixed_assets'] = "CREATE TABLE ".self::t('fixed_assets')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, asset_code varchar(80) NOT NULL DEFAULT '', name varchar(190) NOT NULL DEFAULT '', category varchar(80) NOT NULL DEFAULT 'Alat Kerja', purchase_date date NOT NULL,
            purchase_cost decimal(18,2) NOT NULL DEFAULT 0.00, residual_value decimal(18,2) NOT NULL DEFAULT 0.00, useful_life_months int unsigned NOT NULL DEFAULT 1, annual_rate decimal(8,4) NOT NULL DEFAULT 0.0000,
            payment_method varchar(100) NOT NULL DEFAULT 'Transfer Bank', notes text DEFAULT NULL, status varchar(30) NOT NULL DEFAULT 'active', created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY asset_code(asset_code), KEY status(status)
        ) $charset_collate;";
        $schemas['asset_depreciation'] = "CREATE TABLE ".self::t('asset_depreciation')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, asset_id bigint(20) unsigned NOT NULL, period_key varchar(7) NOT NULL, depreciation_amount decimal(18,2) NOT NULL DEFAULT 0.00,
            accumulated_amount decimal(18,2) NOT NULL DEFAULT 0.00, status varchar(30) NOT NULL DEFAULT 'posted', created_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY asset_period(asset_id,period_key), KEY period_key(period_key)
        ) $charset_collate;";
        $schemas['inventory_valuation_adjustments'] = "CREATE TABLE ".self::t('inventory_valuation_adjustments')." (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT, item_type varchar(30) NOT NULL DEFAULT 'material', item_id bigint(20) unsigned NOT NULL DEFAULT 0, adjustment_type varchar(30) NOT NULL DEFAULT 'write_down',
            amount decimal(18,2) NOT NULL DEFAULT 0.00, reason varchar(255) DEFAULT '', status varchar(30) NOT NULL DEFAULT 'approved', created_by bigint(20) unsigned DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), KEY item(item_type,item_id), KEY status(status)
        ) $charset_collate;";

        // 3.6.2/3.6.6 migrations: profit beneficiaries can be owners OR investors.
        $cap=self::t('capital_transactions');
        if ($cap && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$cap)) === $cap) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$cap}`",0);
            if (!in_array('investor_id',$cols,true)) $wpdb->query("ALTER TABLE `{$cap}` ADD investor_id BIGINT UNSIGNED DEFAULT 0 AFTER owner_id");
        }
        $distItems=self::t('profit_distribution_items');
        if ($distItems && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$distItems)) === $distItems) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$distItems}`",0);
            if (!in_array('investor_id',$cols,true)) $wpdb->query("ALTER TABLE `{$distItems}` ADD investor_id BIGINT UNSIGNED DEFAULT 0 AFTER owner_id");
            if (!in_array('beneficiary_type',$cols,true)) $wpdb->query("ALTER TABLE `{$distItems}` ADD beneficiary_type VARCHAR(20) NOT NULL DEFAULT 'owner' AFTER investor_id");
        }
        // 3.6.6 investor tables are created by dbDelta below.

        // 3.6.4 migrations: job wages and fixed-asset category/rate.
        foreach ([self::t('job_wages')] as $jw) {
            if ($jw && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jw)) === $jw) {
                $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$jw}`",0);
                if (!in_array('payroll_id',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD payroll_id BIGINT UNSIGNED DEFAULT 0 AFTER employee_id");
                if (!in_array('period_key',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD period_key VARCHAR(7) NOT NULL DEFAULT '' AFTER amount");
                if (!in_array('payment_method',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD payment_method VARCHAR(100) DEFAULT 'Transfer Bank'");
                if (!in_array('paid_at',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD paid_at DATE DEFAULT NULL");
                if (!in_array('reference_no',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD reference_no VARCHAR(100) DEFAULT ''");
                if (!in_array('notes',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD notes TEXT DEFAULT NULL");
                if (!in_array('created_by',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD created_by BIGINT UNSIGNED DEFAULT 0");
                if (!in_array('status',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD status VARCHAR(30) NOT NULL DEFAULT 'pending'");
            }
        }
        // 3.6.26 migrations: trace actual material consumption into job-level HPP.
        $jm=self::t('job_materials');
        if ($jm && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jm)) === $jm) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$jm}`",0);
            if (!in_array('unit_cost',$cols,true)) $wpdb->query("ALTER TABLE `{$jm}` ADD unit_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER returned_qty");
            if (!in_array('issued_value',$cols,true)) $wpdb->query("ALTER TABLE `{$jm}` ADD issued_value DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER unit_cost");
            if (!in_array('consumed_cost',$cols,true)) $wpdb->query("ALTER TABLE `{$jm}` ADD consumed_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER issued_value");
            if (!in_array('returned_value',$cols,true)) $wpdb->query("ALTER TABLE `{$jm}` ADD returned_value DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER consumed_cost");
        }

        // 3.6.25 migrations: worker completion evidence and partial job-wage payments.
        $jw=self::t('job_wages');
        if ($jw && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $jw)) === $jw) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$jw}`",0);
            if (!in_array('paid_amount',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD paid_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER amount");
            if (!in_array('balance_amount',$cols,true)) $wpdb->query("ALTER TABLE `{$jw}` ADD balance_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER paid_amount");
            $wpdb->query("UPDATE `{$jw}` SET paid_amount=amount, balance_amount=0 WHERE status='paid' AND paid_amount=0");
            $wpdb->query("UPDATE `{$jw}` SET balance_amount=GREATEST(amount-COALESCE(paid_amount,0),0) WHERE status IN ('pending','partial','paid')");
        }
        $payroll_table=self::t('payroll');
        if ($payroll_table && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$payroll_table))===$payroll_table) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$payroll_table}`",0);
            if (!in_array('gross_amount',$cols,true)) $wpdb->query("ALTER TABLE `{$payroll_table}` ADD gross_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER amount");
            if (!in_array('deduction_amount',$cols,true)) $wpdb->query("ALTER TABLE `{$payroll_table}` ADD deduction_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER gross_amount");
            if (!in_array('reference_no',$cols,true)) $wpdb->query("ALTER TABLE `{$payroll_table}` ADD reference_no VARCHAR(100) NOT NULL DEFAULT '' AFTER payment_method");
            $wpdb->query("UPDATE `{$payroll_table}` SET gross_amount=amount WHERE gross_amount=0 AND amount>0");
            $wpdb->query("UPDATE `{$payroll_table}` SET reference_no=CONCAT('PAY/OLD/',id) WHERE reference_no=''");
        }

        $cap_table=self::t('capital_transactions');
        if ($cap_table && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$cap_table))===$cap_table) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$cap_table}`",0);
            if (!in_array('reference_no',$cols,true)) $wpdb->query("ALTER TABLE `{$cap_table}` ADD reference_no VARCHAR(100) NOT NULL DEFAULT '' AFTER amount");
            $wpdb->query("UPDATE `{$cap_table}` SET reference_no=CONCAT('CAP/OLD/',id) WHERE reference_no=''");
        }

        $fa=self::t('fixed_assets');
        if ($fa && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$fa))===$fa) {
            $cols=$wpdb->get_col("SHOW COLUMNS FROM `{$fa}`",0);
            if (!in_array('category',$cols,true)) $wpdb->query("ALTER TABLE `{$fa}` ADD category VARCHAR(80) NOT NULL DEFAULT 'Alat Kerja' AFTER name");
            if (!in_array('annual_rate',$cols,true)) $wpdb->query("ALTER TABLE `{$fa}` ADD annual_rate DECIMAL(8,4) NOT NULL DEFAULT 0.0000 AFTER useful_life_months");
        }

        foreach ($schemas as $sql) {
            self::dbDelta_safe($sql);
        }

        // Master role pekerjaan nyata: bukan transaksi/dummy; menjadi kamus penugasan AI.
        $jrc=self::t('job_role_catalog');
        if ($jrc && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$jrc)) === $jrc) {
            $roles=[
                ['produksi_perakitan','Produksi / Perakitan','produksi','produksi,perakitan,rakit,assembly'],
                ['finishing','Finishing','produksi','finishing,cat,coating,sanding'],
                ['qc','Quality Control','produksi','qc,quality,cek,pemeriksaan'],
                ['gudang','Gudang / Warehouse','logistik','gudang,warehouse,material,stok'],
                ['packing','Packing','logistik','packing,kemas,pengemasan'],
                ['logistik','Logistik / Pengiriman','logistik','logistik,kirim,delivery,ekspedisi'],
                ['sales','Sales / Penjualan','komersial','sales,penjualan,customer'],
                ['kasir','Kasir','keuangan','kasir,pembayaran,pos'],
                ['keuangan','Keuangan','keuangan','finance,keuangan,akuntansi'],
                ['sdm','SDM / HR','manajemen','hr,sdm,karyawan,payroll'],
                ['admin_operasional','Admin Operasional','manajemen','admin,administrasi,operasional'],
                ['cnc','Operator CNC','produksi','cnc,router,operator cnc,mesin cnc'],
                ['prema','Prema / Finishing','produksi','prema,finishing,cat,coating,sanding']
            ];
            foreach($roles as $r){
                $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$jrc}` WHERE role_code=%s",$r[0]));
                if(!$exists) $wpdb->insert($jrc,['role_code'=>$r[0],'role_name'=>$r[1],'domain'=>$r[2],'keywords'=>$r[3],'required_permissions'=>'','active'=>1,'created_at'=>current_time('mysql')]);
            }
        }


        // Existing master tables evolved after 3.3.x; add fields used by the
        // production/job snapshot without dropping legacy data.
        $column_map = [
            'shipments' => [
                'tracking_verified' => "varchar(20) NOT NULL DEFAULT 'unverified' AFTER service",
                'tracking_provider' => "varchar(50) DEFAULT '' AFTER tracking_verified",
                'tracking_verified_at' => "datetime DEFAULT NULL AFTER tracking_provider",
                'tracking_verification_note' => "text DEFAULT NULL AFTER tracking_verified_at",
            ],
            'investors' => [
                'bank_name'=>"varchar(120) DEFAULT '' AFTER contact",
                'account_name'=>"varchar(190) DEFAULT '' AFTER bank_name",
                'account_number'=>"varchar(80) DEFAULT '' AFTER account_name"
            ],
            'activity_logs' => [
                'request_id'=>"varchar(64) DEFAULT '' AFTER id"
            ],
            'sales_commissions' => [
                'reference_no'=>"varchar(100) DEFAULT '' AFTER commission_amount"
            ],
            'test_runs' => [
                'expected_json'=>"longtext DEFAULT NULL AFTER completed_at",
                'actual_json'=>"longtext DEFAULT NULL AFTER expected_json",
                'assertions_json'=>"longtext DEFAULT NULL AFTER actual_json",
                'passed'=>"tinyint(1) NOT NULL DEFAULT 0 AFTER assertions_json"
            ],
            'product_variants' => [
                'supply_mode'=>"varchar(20) NOT NULL DEFAULT 'production' AFTER status",
                'prema_required'=>"tinyint(1) NOT NULL DEFAULT 0 AFTER cnc_required",
                'supplier_id'=>"bigint(20) unsigned DEFAULT 0 AFTER supply_mode",
                'external_product_code'=>"varchar(120) NOT NULL DEFAULT '' AFTER supplier_id",
                'purchase_cost'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER external_product_code",
                'hpp_material'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER hpp",
                'hpp_labor'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER hpp_material",
                'hpp_overhead'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER hpp_labor",
                'hpp_packaging'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER hpp_overhead",
                'hpp_other'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER hpp_packaging",
                'hpp_basis_qty'=>"decimal(18,4) NOT NULL DEFAULT 1.0000 AFTER hpp_other",
                'hpp_method'=>"varchar(30) NOT NULL DEFAULT 'full_cost' AFTER hpp_basis_qty"
            ],
            'products' => [
                'supply_mode'=>"varchar(20) NOT NULL DEFAULT 'production' AFTER status",
                'prema_required'=>"tinyint(1) NOT NULL DEFAULT 0 AFTER cnc_required",
                'technical_drawing_id'=>"bigint(20) unsigned DEFAULT 0 AFTER image_id",
                'cnc_file_id'=>"bigint(20) unsigned DEFAULT 0 AFTER technical_drawing_id",
                'product_length'=>"decimal(18,4) DEFAULT 0 AFTER description",
                'product_width'=>"decimal(18,4) DEFAULT 0 AFTER product_length",
                'product_height'=>"decimal(18,4) DEFAULT 0 AFTER product_width",
                'product_thickness'=>"decimal(18,4) DEFAULT 0 AFTER product_height",
                'dimension_unit'=>"varchar(20) DEFAULT 'cm' AFTER product_thickness",
                'finishing'=>"varchar(190) DEFAULT '' AFTER dimension_unit",
                'color'=>"varchar(100) DEFAULT '' AFTER finishing",
                'product_description'=>"longtext DEFAULT NULL AFTER color",
                'production_notes'=>"longtext DEFAULT NULL AFTER product_description",
                'production_instructions'=>"longtext DEFAULT NULL AFTER production_notes",
                'product_weight'=>"decimal(18,4) DEFAULT 0 AFTER production_instructions",
                'weight_unit'=>"varchar(20) DEFAULT 'kg' AFTER product_weight",
                'spec_status'=>"varchar(30) NOT NULL DEFAULT 'draft' AFTER weight_unit"
            ],
            'seller_orders' => [
                'marketplace' => "varchar(50) DEFAULT '' AFTER total",
                'marketplace_order_no' => "varchar(120) DEFAULT '' AFTER marketplace",
                'tracking_no' => "varchar(120) DEFAULT '' AFTER marketplace_order_no",
                'marketplace_sale_at' => "datetime DEFAULT NULL AFTER tracking_no"
            ],
            'seller_order_items' => [
                'seller_product_name' => "varchar(190) DEFAULT '' AFTER variant_id",
                'seller_sku' => "varchar(120) DEFAULT '' AFTER seller_product_name",
                'seller_model' => "varchar(120) DEFAULT '' AFTER seller_sku",
                'seller_size' => "varchar(120) DEFAULT '' AFTER seller_model"
            ],
            'seller_sales' => [
                'marketplace' => "varchar(50) DEFAULT '' AFTER sold_at",
                'marketplace_order_no' => "varchar(120) DEFAULT '' AFTER marketplace",
                'tracking_no' => "varchar(120) DEFAULT '' AFTER marketplace_order_no"
            ],
            'jobs' => [
                'source_order_id'=>"bigint(20) unsigned DEFAULT 0 AFTER product_id",
                'source_type'=>"varchar(30) NOT NULL DEFAULT 'manual' AFTER source_order_id",
                'production_date'=>"date DEFAULT NULL AFTER location",
                'priority'=>"varchar(20) NOT NULL DEFAULT 'normal' AFTER status",
                'instructions'=>"longtext DEFAULT NULL AFTER priority",
                'spec_snapshot'=>"longtext DEFAULT NULL AFTER instructions",
                'created_by'=>"bigint(20) unsigned DEFAULT 0 AFTER product_id"
            ],
            'production_results' => [
                'production_code'=>"varchar(120) NOT NULL DEFAULT '' AFTER id",
                'label_version'=>"varchar(20) NOT NULL DEFAULT '1.0' AFTER qr_payload"
            ],
            'production_units' => [
                'production_code'=>"varchar(120) NOT NULL DEFAULT '' AFTER variant_id",
                'cnc_code'=>"varchar(120) NOT NULL DEFAULT '' AFTER unit_id",
                'qr_payload'=>"longtext DEFAULT NULL AFTER cnc_code"
            ],
            'sales_orders' => [
                'invoice_no'=>"varchar(100) DEFAULT '' AFTER order_no",
                'payment_status'=>"varchar(30) NOT NULL DEFAULT 'unpaid' AFTER payment_method",
                'paid_amount'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER payment_status",
                'deposit_amount'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER paid_amount",
                'commission_status'=>"varchar(30) NOT NULL DEFAULT 'none' AFTER commission",
                'paid_at'=>"datetime DEFAULT NULL AFTER deposit_amount",
                'channel_id'=>"BIGINT(20) unsigned DEFAULT 0 AFTER channel",
                'gross'=>"DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER total_amount",
                'net'=>"DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER gross"
            ],
            'seller_sales' => [
                'commission_amount'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER total",
                'status'=>"varchar(30) NOT NULL DEFAULT 'pending' AFTER commission_amount",
                'source_type'=>"varchar(30) NOT NULL DEFAULT 'seller_order' AFTER status",
                'return_id'=>"bigint(20) unsigned DEFAULT 0 AFTER source_type"
            ],
            'stock_transactions' => [
                'unit_cost'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER qty",
                'total_value'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER unit_cost"
            ],
            'seller_invoices' => [
                'invoice_no'=>"varchar(100) DEFAULT '' AFTER order_id",
                'original_total'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER total",
                'return_adjustment_total'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER original_total",
                'last_return_at'=>"datetime DEFAULT NULL AFTER paid_at"
            ],
            'seller_payments' => [
                'order_id'=>"bigint(20) unsigned DEFAULT 0 AFTER invoice_id",
                'payment_method'=>"varchar(80) DEFAULT 'Transfer Bank' AFTER amount",
                'created_by'=>"bigint(20) unsigned DEFAULT 0 AFTER paid_at",
                'deposit_id'=>"bigint(20) unsigned DEFAULT 0 AFTER created_by",
                'external_reference'=>"varchar(120) DEFAULT '' AFTER deposit_id"
            ],
            'seller_affiliate_ledger' => [
                'reference_type'=>"varchar(50) DEFAULT 'affiliate' AFTER order_id",
                'paid_at'=>"datetime DEFAULT NULL AFTER created_at"
            ],
            'job_assignments' => [
                'role_code'=>"varchar(60) NOT NULL DEFAULT '' AFTER employee_id",
                'assignment_source'=>"varchar(30) NOT NULL DEFAULT 'manual' AFTER role_code",
                'ai_confidence'=>"decimal(6,4) NOT NULL DEFAULT 0.0000 AFTER assignment_source",
                'assigned_by'=>"bigint(20) unsigned DEFAULT 0 AFTER returned_at"
            ],
            'shipments' => [
                'seller_sale_id'=>"bigint(20) unsigned DEFAULT 0 AFTER sale_id",
                'internal_shipment_no'=>"varchar(100) NOT NULL DEFAULT '' AFTER tracking_no",
                'internal_barcode'=>"varchar(120) NOT NULL DEFAULT '' AFTER internal_shipment_no"
            ],
            'warehouse_documents' => [
                'internal_shipment_no'=>"varchar(100) DEFAULT '' AFTER tracking_no",
                'copy_type'=>"varchar(20) NOT NULL DEFAULT 'single' AFTER doc_type",
                'source_doc_no'=>"varchar(100) DEFAULT '' AFTER doc_no"
            ],
            'returns' => [
                'seller_order_id'=>"bigint(20) unsigned DEFAULT 0 AFTER order_id",
                'tracking_no'=>"varchar(120) DEFAULT '' AFTER order_id",
                'courier_name'=>"varchar(100) DEFAULT '' AFTER tracking_no",
                'seller_name'=>"varchar(190) DEFAULT '' AFTER courier_name",
                'seller_account_id'=>"bigint(20) unsigned DEFAULT 0 AFTER seller_name",
                'seller_unit_amount'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER seller_account_id",
                'seller_adjustment_amount'=>"decimal(18,2) NOT NULL DEFAULT 0.00 AFTER seller_unit_amount",
                'seller_ar_adjustment_status'=>"varchar(30) NOT NULL DEFAULT 'pending' AFTER seller_adjustment_amount",
                'seller_ar_adjusted_at'=>"datetime DEFAULT NULL AFTER seller_ar_adjustment_status",
                'accepted_at'=>"datetime DEFAULT NULL AFTER warehouse_received_by",
                'warehouse_received_at'=>"datetime DEFAULT NULL AFTER status",
                'warehouse_received_by'=>"bigint(20) unsigned DEFAULT 0 AFTER warehouse_received_at",
                'qc_status'=>"varchar(30) NOT NULL DEFAULT 'waiting' AFTER warehouse_received_by"
            ]
        ];
        foreach ($column_map as $key => $cols) {
            $table = self::t($key);
            if (!$table || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$table)) !== $table) continue;
            $existing = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`",0);
            foreach ($cols as $name => $definition) {
                if (!in_array($name,$existing,true)) {
                    $wpdb->query("ALTER TABLE `{$table}` ADD `{$name}` {$definition}");
                }
            }
        }

        // Backfill identitas produksi untuk data lama: tidak membuat transaksi baru,
        // hanya mengisi kode identitas dari ID/tanggal yang sudah ada.
        $pr = self::t('production_results'); $pu = self::t('production_units'); $jt = self::t('jobs');
        if ($pr && $jt && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$pr)) === $pr && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$jt)) === $jt) {
            $old_results=$wpdb->get_results("SELECT id,job_id,production_code,batch_code,created_at,qr_payload FROM `{$pr}` WHERE production_code='' OR production_code IS NULL",ARRAY_A)?:[];
            foreach($old_results as $row){
                $day=''; $ts=strtotime((string)$row['created_at']); if($ts) $day=date('ymd',$ts); if($day==='') $day=date('ymd',current_time('timestamp'));
                $pc='PRD-'.$day.'-J'.str_pad((string)$row['job_id'],6,'0',STR_PAD_LEFT).'-R'.str_pad((string)$row['id'],5,'0',STR_PAD_LEFT);
                $batch=$row['batch_code']?:'BTH-'.$day.'-J'.str_pad((string)$row['job_id'],6,'0',STR_PAD_LEFT).'-R'.str_pad((string)$row['id'],5,'0',STR_PAD_LEFT);
                $qr=add_query_arg(['pk01_production'=>$pc,'pk01_batch'=>$batch],self::page_url('production'));
                $wpdb->update($pr,['production_code'=>$pc,'batch_code'=>$batch,'barcode_value'=>$pc,'qr_payload'=>$qr],['id'=>(int)$row['id']]);
            }
        }
        if ($pu && $jt && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$pu)) === $pu && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$jt)) === $jt) {
            $old_units=$wpdb->get_results("SELECT u.id,u.job_id,u.production_code,u.cnc_code,u.unit_id,u.unit_no,u.batch_no,u.production_date FROM `{$pu}` u WHERE u.cnc_code='' OR u.cnc_code IS NULL",ARRAY_A)?:[];
            foreach($old_units as $row){
                $day=''; $ts=strtotime((string)$row['production_date']); if($ts) $day=date('ymd',$ts); if($day==='') $day=date('ymd',current_time('timestamp'));
                $seq=max(1,(int)$row['unit_no']);
                $cnc='CNC-'.$day.'-J'.str_pad((string)$row['job_id'],6,'0',STR_PAD_LEFT).'-U'.str_pad((string)$seq,4,'0',STR_PAD_LEFT);
                $pc=(string)$row['production_code']; if($pc===''){
                    $pc=(string)$wpdb->get_var($wpdb->prepare("SELECT production_code FROM `{$pr}` WHERE job_id=%d AND batch_code=%s ORDER BY id DESC LIMIT 1",(int)$row['job_id'],(string)$row['batch_no']));
                }
                if($pc==='') $pc='PRD-'.$day.'-J'.str_pad((string)$row['job_id'],6,'0',STR_PAD_LEFT).'-R00000';
                $qr=add_query_arg(['pk01_production'=>$pc,'pk01_batch'=>(string)$row['batch_no'],'pk01_unit'=>$cnc],self::page_url('production'));
                $wpdb->update($pu,['production_code'=>$pc,'cnc_code'=>$cnc,'unit_id'=>$cnc,'qr_payload'=>$qr],['id'=>(int)$row['id']]);
            }
        }

        // Backfill sumber seller_sales: transaksi kasir tidak boleh diposting sebagai revenue seller kedua.
        $ss=self::t('seller_sales'); $so=self::t('sales_orders');
        if($ss && $so && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$ss))===$ss && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$so))===$so){
            $wpdb->query("UPDATE `{$ss}` ss JOIN `{$so}` so ON so.id=ss.order_id SET ss.source_type='cashier_sale' WHERE ss.source_type='seller_order' AND ss.order_id>0");
        }

        // Backfill nomor dokumen legacy: invoice_no harus selalu identik dengan order_no lama.
        $so = self::t('sales_orders');
        if ($so && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$so)) === $so) {
            $wpdb->query("UPDATE `{$so}` SET invoice_no=order_no WHERE (invoice_no IS NULL OR invoice_no='') AND order_no<>''");
        }
        if ($so && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$so)) === $so) {
            $has_idx = $wpdb->get_var("SHOW INDEX FROM `{$so}` WHERE Key_name='invoice_no_idx'");
            if (!$has_idx) $wpdb->query("ALTER TABLE `{$so}` ADD INDEX `invoice_no_idx` (`invoice_no`)");
        }
        $si = self::t('seller_invoices');
        if ($si && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$si)) === $si) {
            $rows = $wpdb->get_results("SELECT id FROM `{$si}` WHERE invoice_no IS NULL OR invoice_no='' ORDER BY id ASC", ARRAY_A) ?: [];
            foreach ($rows as $r) {
                $num = self::t('seller_invoices') ? 'SINV-'.str_pad((string)((int)$r['id']),5,'0',STR_PAD_LEFT) : '';
                if ($num) $wpdb->update($si,['invoice_no'=>$num],['id'=>(int)$r['id']]);
            }
        }
    }

}
