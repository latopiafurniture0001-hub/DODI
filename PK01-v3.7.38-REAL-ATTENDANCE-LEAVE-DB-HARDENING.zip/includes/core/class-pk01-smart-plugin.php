<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Smart Plugin
 * Self-healing infrastructure + real-data synchronization health.
 * Never creates business/demo/dummy transactions.
 */
class PK01_Smart_Plugin {
    const CRON = 'pk01_smart_sync_event';
    const VERSION = '1.0.0';

    public static function init() {
        add_action('init', [__CLASS__, 'runtime_guard'], 2);
        add_action(self::CRON, [__CLASS__, 'scheduled_sync']);
        add_filter('cron_schedules', [__CLASS__, 'cron_schedules']);
        add_action('admin_notices', [__CLASS__, 'admin_notice']);
        if (!wp_next_scheduled(self::CRON)) {
            wp_schedule_event(time() + 120, 'pk01_15min', self::CRON);
        }
    }

    public static function cron_schedules($schedules) {
        if (!isset($schedules['pk01_15min'])) {
            $schedules['pk01_15min'] = [
                'interval' => 900,
                'display'  => 'PK01 setiap 15 menit',
            ];
        }
        return $schedules;
    }

    /**
     * Jalur otomatis yang ringan. Hanya memperbaiki jika benar-benar ada
     * tabel/laman PK01 yang hilang. Tidak membuat data bisnis contoh.
     */
    public static function runtime_guard() {
        if (get_transient('pk01_smart_runtime_lock')) return;
        set_transient('pk01_smart_runtime_lock', 1, 30);

        $health = [
            'schema_repaired' => false,
            'pages_repaired'  => false,
            'schema_missing'  => [],
            'pages_missing'   => [],
            'finance'         => null,
            'errors'          => [],
            'checked_at'      => current_time('mysql'),
        ];

        try {
            if (class_exists('PK01_DB')) {
                PK01_DB::init();
                $missing = self::missing_tables();
                $health['schema_missing'] = $missing;
                if ($missing && (is_user_logged_in() || wp_doing_cron())) {
                    PK01_DB::install();
                    $health['schema_repaired'] = true;
                    $missing_after = self::missing_tables();
                    $health['schema_missing'] = $missing_after;
                    if ($missing_after) {
                        $health['errors'][] = 'Masih ada tabel PK01 yang belum tersedia: ' . implode(', ', $missing_after);
                    }
                }
            }
        } catch (Throwable $e) {
            $health['errors'][] = 'Perbaikan database: ' . substr($e->getMessage(), 0, 300);
        }

        try {
            if (class_exists('PK01_DB')) {
                $pages_missing = self::missing_pages();
                $health['pages_missing'] = $pages_missing;
                if ($pages_missing && (is_user_logged_in() || wp_doing_cron())) {
                    PK01_DB::ensure_pages();
                    $health['pages_repaired'] = true;
                    $pages_after = self::missing_pages();
                    $health['pages_missing'] = $pages_after;
                    if ($pages_after) {
                        $health['errors'][] = 'Masih ada laman PK01 yang belum tersedia: ' . implode(', ', $pages_after);
                    }
                }
            }
        } catch (Throwable $e) {
            $health['errors'][] = 'Perbaikan laman: ' . substr($e->getMessage(), 0, 300);
        }

        // Sinkronisasi GL hanya dari transaksi nyata dan idempotent.
        // Tidak dijalankan pada setiap request untuk menjaga performa.
        $last = (int) get_option('pk01_smart_finance_sync_at', 0);
        if ($last <= (time() - 600) && class_exists('PK01_Finance') && empty($health['schema_missing'])) {
            try {
                $health['finance'] = PK01_Finance::sync();
                update_option('pk01_smart_finance_sync_at', time(), false);
                update_option('pk01_smart_finance_sync_result', $health['finance'], false);
                if (!empty($health['finance']['errors'])) {
                    $health['errors'][] = 'Sinkronisasi Keuangan belum selesai: ' . implode(' | ', array_slice((array)$health['finance']['errors'], 0, 3));
                }
            } catch (Throwable $e) {
                $health['errors'][] = 'Sinkronisasi Keuangan: ' . substr($e->getMessage(), 0, 300);
            }
        } else {
            $health['finance'] = get_option('pk01_smart_finance_sync_result', null);
        }

        update_option('pk01_smart_health', $health, false);
    }

    public static function scheduled_sync() {
        // Cron berjalan tanpa user. Jika schema belum lengkap, repair dulu.
        try {
            if (class_exists('PK01_DB')) {
                PK01_DB::init();
                if (self::missing_tables()) PK01_DB::install();
                if (self::missing_pages()) PK01_DB::ensure_pages();
            }
            if (class_exists('PK01_Finance')) {
                $result = PK01_Finance::sync();
                update_option('pk01_smart_finance_sync_at', time(), false);
                update_option('pk01_smart_finance_sync_result', $result, false);
                if (!empty($result['errors'])) {
                    $h = (array)get_option('pk01_smart_health', []);
                    $h['errors'] = array_values(array_unique(array_merge((array)($h['errors'] ?? []), ['Sinkronisasi Keuangan belum selesai: ' . implode(' | ', array_slice((array)$result['errors'], 0, 3))])));
                    $h['finance'] = $result;
                    $h['checked_at'] = current_time('mysql');
                    update_option('pk01_smart_health', $h, false);
                }
            }
        } catch (Throwable $e) {
            $h = (array)get_option('pk01_smart_health', []);
            $h['errors'] = array_values(array_unique(array_merge((array)($h['errors'] ?? []), ['Smart Sync: ' . substr($e->getMessage(), 0, 300)])));
            $h['checked_at'] = current_time('mysql');
            update_option('pk01_smart_health', $h, false);
        }
    }

    public static function expected_tables() {
        if (!class_exists('PK01_DB')) return [];
        PK01_DB::init();
        $tables = isset(PK01_DB::$tables) && is_array(PK01_DB::$tables) ? PK01_DB::$tables : [];
        return array_values(array_unique(array_filter($tables, function($t) {
            return is_string($t) && strpos($t, 'pk01_') !== false;
        })));
    }

    public static function missing_tables() {
        global $wpdb;
        $expected = self::expected_tables();
        if (!$expected) return [];
        $pattern = $wpdb->prefix . 'pk01_%';
        $rows = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $pattern));
        $existing = array_fill_keys(array_map('strval', (array)$rows), true);
        $missing = [];
        foreach ($expected as $table) {
            if (empty($existing[$table])) $missing[] = preg_replace('/^'.preg_quote($wpdb->prefix . 'pk01_', '/').'/i', '', $table);
        }
        return $missing;
    }

    public static function required_pages() {
        return [
            'pk01_login_page_id','pk01_portal_page_id','pk01_dashboard_page_id','pk01_products_page_id',
            'pk01_materials_page_id','pk01_production_page_id','pk01_stock_page_id','pk01_purchase_page_id',
            'pk01_suppliers_page_id','pk01_sales_page_id','pk01_customers_page_id','pk01_seller_page_id',
            'pk01_seller_portal_page_id','pk01_seller_affiliate_page_id','pk01_returns_page_id','pk01_shipments_page_id',
            'pk01_marketplace_page_id','pk01_employees_page_id','pk01_attendance_page_id','pk01_payroll_page_id','pk01_job_wages_page_id',
            'pk01_assets_inventory_page_id','pk01_operational_costs_page_id','pk01_cash_page_id','pk01_finance_page_id',
            'pk01_administration_page_id','pk01_pricing_page_id','pk01_ai_page_id','pk01_logs_page_id','pk01_system_page_id',
            'pk01_seller_register_page_id','pk01_tracking_public_page_id'
        ];
    }

    public static function missing_pages() {
        $missing = [];
        foreach (self::required_pages() as $opt) {
            $id = (int)get_option($opt, 0);
            if (!$id || get_post_status($id) !== 'publish') $missing[] = $opt;
        }
        return $missing;
    }

    public static function status() {
        $h = (array)get_option('pk01_smart_health', []);
        $h['schema_missing'] = self::missing_tables();
        $h['pages_missing'] = self::missing_pages();
        $h['finance_last_sync'] = (int)get_option('pk01_smart_finance_sync_at', 0);
        $h['finance_last_result'] = get_option('pk01_smart_finance_sync_result', null);
        return $h;
    }

    public static function dashboard_notice() {
        if (!is_user_logged_in()) return '';
        if (class_exists('PK01_Authorization') && method_exists('PK01_Authorization', 'is_role_preview') && PK01_Authorization::is_role_preview()) return '';
        if (!current_user_can('manage_options')) return '';
        $h = self::status();
        $items = [];
        if (!empty($h['schema_missing'])) $items[] = 'Database: ' . implode(', ', array_slice($h['schema_missing'], 0, 5));
        if (!empty($h['pages_missing'])) $items[] = 'Laman: ' . count($h['pages_missing']) . ' belum tersedia';
        $fr = isset($h['finance_last_result']) && is_array($h['finance_last_result']) ? $h['finance_last_result'] : [];
        if (!empty($fr['errors'])) $items[] = 'Keuangan belum sinkron';
        if (!empty($h['errors'])) $items[] = implode(' | ', array_slice((array)$h['errors'], 0, 2));
        if (!$items) return '';
        return '<div class="pk01-op-notice is-warning" style="margin:16px 24px;"><strong>⚙️ PK01 Smart System:</strong> ' . esc_html(implode(' • ', array_unique($items))) . '. Sistem sedang memeriksa/memulihkan struktur dan sinkronisasi dari data nyata. Tidak ada data dummy yang dibuat.</div>';
    }

    public static function admin_notice() {
        if (!current_user_can('manage_options')) return;
        $h = self::status();
        $problems = [];
        if (!empty($h['schema_missing'])) $problems[] = 'Database: ' . implode(', ', array_slice($h['schema_missing'], 0, 5));
        if (!empty($h['pages_missing'])) $problems[] = 'Laman: ' . count($h['pages_missing']) . ' belum tersedia';
        $fr = isset($h['finance_last_result']) && is_array($h['finance_last_result']) ? $h['finance_last_result'] : [];
        if (!empty($fr['errors'])) $problems[] = 'Keuangan belum sinkron: ' . implode(' | ', array_slice((array)$fr['errors'], 0, 2));
        if (!empty($h['errors'])) $problems[] = implode(' | ', array_slice((array)$h['errors'], 0, 2));
        $problems = array_values(array_unique(array_filter($problems)));
        if (!$problems) {
            if (!empty($h['schema_repaired']) || !empty($h['pages_repaired'])) {
                echo '<div class="notice notice-success"><p><strong>PK01 Smart System:</strong> struktur sistem diperiksa dan yang hilang sudah dipulihkan otomatis. Tidak ada data bisnis dummy yang dibuat.</p></div>';
            }
            return;
        }
        echo '<div class="notice notice-warning"><p><strong>PK01 Smart System — perlu perhatian:</strong> ' . esc_html(implode(' • ', $problems)) . '. Sistem tidak membuat data transaksi contoh. Perbaikan otomatis hanya membuat struktur/laman yang benar-benar hilang.</p></div>';
    }
}
