<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Data Governance 1.0
 * Central guard for corrections/deletions, mutation audit, and admin control center.
 * Existing business engines remain the source of truth.
 */
class PK01_Governance {
    private static $booted = false;

    public static function init() {
        if (self::$booted) return;
        self::$booted = true;
        add_action('init', [__CLASS__, 'guard_mutation_request'], 1);
        add_action('wp_loaded', [__CLASS__, 'audit_mutation_request'], 99);
    }

    public static function is_admin() {
        return is_user_logged_in() && current_user_can('manage_options') && !(
            class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview()
        );
    }

    public static function require_admin($reason='Tindakan koreksi data') {
        if (!self::is_admin()) {
            if (function_exists('PK01_Audit::write')) {
                PK01_Audit::write('blocked_admin_mutation','security','request','',null,['reason'=>$reason],$reason,'SECURITY','governance');
            }
            wp_die('Hanya Administrator yang boleh melakukan koreksi atau penghapusan data PK01.',403);
        }
        return true;
    }

    private static function post_action() {
        foreach ($_POST as $k=>$v) {
            if (preg_match('/^pk01_.*_action$/', (string)$k) && is_scalar($v)) return sanitize_key($v);
            if (preg_match('/^pk01_.*_(delete|remove|purge|edit|update|correct)$/', (string)$k)) return sanitize_key(preg_replace('/^pk01_.*_/', '', (string)$k));
        }
        if (isset($_POST['action']) && is_scalar($_POST['action'])) return sanitize_key($_POST['action']);
        return '';
    }

    private static function is_mutating_action($action) {
        return in_array($action, ['delete','remove','purge','purge_all','destroy','erase','correct','rollback','reverse','adjust'], true);
    }

    private static function has_existing_record_marker() {
        foreach (['id','edit_id','emp_id','seller_id','asset_id','wage_id','job_id','return_id','order_id','shipment_id','product_id','variant_id','customer_id','supplier_id','investor_id','owner_id','distribution_id'] as $k) {
            if (isset($_POST[$k]) && absint($_POST[$k]) > 0) return true;
        }
        return false;
    }

    public static function guard_mutation_request() {
        if (empty($_POST) || !is_user_logged_in()) return;
        $action = self::post_action();
        if (self::is_mutating_action($action)) self::require_admin('Tindakan '.$action);

        // Existing-record edits submitted through generic "save" handlers are admin-only.
        if ($action === 'save' && self::has_existing_record_marker()) {
            self::require_admin('Edit data transaksi/master yang sudah tersimpan');
        }
        // Explicit edit/update handlers are always administrator-only.
        if (in_array($action,['edit','update'],true)) self::require_admin('Edit data');
    }

    public static function audit_mutation_request() {
        if (empty($_POST) || !is_user_logged_in() || !class_exists('PK01_Audit')) return;
        $action = self::post_action();
        if (!$action) return;
        $mutating = self::is_mutating_action($action) || in_array($action,['save','create','add_owner','add_investor','capital','investor_investment','distribute','withdraw_owner','withdraw_investor','pay','receipt','result','assign','issue','qc','return_material','asset','depreciate','write_down','adjust','status'],true);
        if (!$mutating) return;
        $payload = $_POST;
        unset($payload['_wp_http_referer']);
        PK01_Audit::write(
            'request_'.$action,
            'governance',
            'mutation_request',
            self::record_marker(),
            null,
            $payload,
            'Jejak permintaan perubahan data; detail transaksi utama dicatat oleh engine modul masing-masing.',
            'SUCCESS',
            'governance'
        );
    }

    private static function record_marker() {
        foreach (['id','edit_id','emp_id','seller_id','asset_id','wage_id','job_id','return_id','order_id','shipment_id','product_id','variant_id','customer_id','supplier_id','investor_id','owner_id','distribution_id'] as $k) {
            if (isset($_POST[$k]) && absint($_POST[$k]) > 0) return (string)absint($_POST[$k]);
        }
        return '';
    }

    public static function render_control_center() {
        self::require_admin('Membuka Data Control & Audit');
        global $wpdb;
        $t = PK01_DB::t('activity_logs');
        $rows = $wpdb->get_results("SELECT id,timestamp,user_name,user_role,action,module,entity,transaction_id,reason,level,source FROM {$t} ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        ob_start(); ?>
        <section class="pk01-op-card pk01-data-module">
            <div class="pk01-op-card-head"><span class="pk01-op-eyebrow">ADMIN • DATA GOVERNANCE</span><h2>Data Control & Audit</h2><p>Hanya Administrator dapat melakukan koreksi, edit transaksi tersimpan, atau penghapusan. Pengguna operasional tetap bekerja sesuai role tanpa akses destructive mutation.</p></div>
            <div class="pk01-op-grid-3">
                <div><b>Aturan Koreksi</b><h3>ADMIN ONLY</h3><small>Edit data tersimpan dan hapus dibatasi Administrator.</small></div>
                <div><b>Audit Trail</b><h3><?php echo number_format(count($rows)); ?></h3><small>100 aktivitas terakhir ditampilkan.</small></div>
                <div><b>Prinsip Data</b><h3>1 SOURCE</h3><small>Engine transaksi tetap menjadi sumber kebenaran.</small></div>
            </div>
            <div class="pk01-op-table-wrap" style="margin-top:16px"><table><thead><tr><th>Waktu</th><th>User</th><th>Aksi</th><th>Modul</th><th>Record</th><th>Level</th><th>Keterangan</th></tr></thead><tbody>
            <?php if(!$rows): ?><tr><td colspan="7" class="pk01-op-empty">Belum ada aktivitas.</td></tr><?php else: foreach($rows as $r): ?><tr><td><?php echo esc_html($r['timestamp']); ?></td><td><?php echo esc_html($r['user_name']); ?><br><small><?php echo esc_html($r['user_role']); ?></small></td><td><b><?php echo esc_html($r['action']); ?></b></td><td><?php echo esc_html($r['module']); ?></td><td><?php echo esc_html($r['entity'].' #'.$r['transaction_id']); ?></td><td><?php echo esc_html(strtoupper($r['level'])); ?></td><td><?php echo esc_html($r['reason']); ?></td></tr><?php endforeach; endif; ?></tbody></table></div>
            <div class="pk01-op-notice" style="margin-top:14px"><b>Catatan keamanan:</b> penghapusan transaksi finansial tidak boleh dilakukan secara bebas karena dapat merusak rekonsiliasi. Untuk transaksi yang sudah memengaruhi kas/stok/HPP, gunakan koreksi/reversal yang disediakan engine dan tetap tercatat di Audit Trail.</div>
        </section>
        <?php return ob_get_clean();
    }
}
