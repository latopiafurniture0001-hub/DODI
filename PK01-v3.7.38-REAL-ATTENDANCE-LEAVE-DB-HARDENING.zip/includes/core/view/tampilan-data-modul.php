<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('pk01_tampilkan_data_modul')) {
function pk01_tampilkan_data_modul($key, $title, $eyebrow = 'DATA USAHA', $description = 'Data dibaca langsung dari database PK01 secara real-time.') {
    $data = class_exists('PK01_Engine') ? PK01_Engine::module_rows($key) : ['rows' => [], 'columns' => []];
    $rows = $data['rows'] ?? [];
    $columns = $data['columns'] ?? [];

    $labels = [
        'id'                => 'ID',
        'code'              => 'Kode',
        'name'              => 'Nama',
        'position'          => 'Jabatan',
        'division'          => 'Bagian',
        'pay_type'          => 'Sistem Gaji',
        'rate'              => 'Tarif',
        'status'            => 'Status',
        'created_at'        => 'Waktu Dibuat',
        'updated_at'        => 'Terakhir Update',
        'employee_id'       => 'Karyawan',
        'period'            => 'Periode',
        'qty'               => 'Jumlah',
        'amount'            => 'Nominal',
        'paid_at'           => 'Tgl Bayar',
        'category'          => 'Kategori',
        'is_hpp'            => 'Masuk HPP',
        'description'       => 'Keterangan',
        'direction'         => 'Arus Kas',
        'reference_type'    => 'Tipe Ref',
        'reference_id'      => 'ID Ref',
        'source'            => 'Sumber',
        'channel_id'        => 'Channel ID',
        'payout_no'         => 'No. Payout',
        'payout_date'       => 'Tgl Payout',
        'order_count'       => 'Pesanan',
        'gross'             => 'Omzet Kotor',
        'deductions'        => 'Potongan',
        'net_received'      => 'Dana Diterima',
        'variant_id'        => 'ID Varian',
        'sku'               => 'SKU',
        'variant'           => 'Produk / Varian',
        'seller'            => 'Mitra Seller',
        'customer'          => 'Pelanggan',
        'channel'           => 'Saluran Penjualan',
        'payment_status'    => 'Status Bayar',
        'shipping_status'   => 'Status Kirim',
        'tracking_no'       => 'No. Resi',
        'fee'               => 'Biaya Fee',
        'commission'        => 'Komisi',
        'net'               => 'Nilai Bersih',
        'hpp'               => 'HPP',
        'estimated_profit'  => 'Estimasi Laba',
        'return_lines'      => 'Item Retur',
        'paid'              => 'Lunas',
        'source_ref_id'     => 'Referensi',
        'reason'            => 'Alasan',
        'settlement_type'   => 'Penyelesaian',
        'settlement_status' => 'Status Selesai',
        'refund_amount'     => 'Pengembalian',
        'condition_status'  => 'Kondisi Barang',
        'job_no'            => 'No. Job / Batch',
        'location'          => 'Lokasi Gudang',
        'deadline'          => 'Tenggat Waktu',
        'target_qty'        => 'Target',
        'good_qty'          => 'Kondisi Baik',
        'reject_qty'        => 'Rusak / Afkir',
        'raw_stock'         => 'Stok Bahan',
        'finished_stock'    => 'Stok Barang Jadi',
        'seller_stock'      => 'Stok Seller',
        'sales'             => 'Penjualan',
        'operational_cost'  => 'Biaya Operasional',
        'marketplace_fee'   => 'Fee Marketplace',
        'profit'            => 'Laba Bersih',
        'cash_ending'       => 'Saldo Kas',
        'action'            => 'Aktivitas',
        'module'            => 'Modul',
        'entity'            => 'Objek',
        'transaction_id'    => 'ID Transaksi',
        'timestamp'         => 'Waktu Catat',
        'level'             => 'Tingkat',
        'user_id'           => 'User',
        'price'             => 'Harga Satuan',
        'valid_from'        => 'Mulai Berlaku',
        'valid_to'          => 'Selesai Berlaku',
        'approved_by'       => 'Penyetuju',
        'account_id'        => 'Akun Kas'
    ];

    $money_keys = [
        'amount', 'rate', 'gross', 'deductions', 'net_received', 'fee', 
        'commission', 'net', 'hpp', 'estimated_profit', 'refund_amount', 
        'price', 'sales', 'operational_cost', 'marketplace_fee', 'profit', 'cash_ending'
    ];

    $code_keys = ['id', 'code', 'sku', 'job_no', 'tracking_no', 'payout_no', 'order_no', 'reference_id'];
    $status_keys = ['status', 'payment_status', 'shipping_status', 'settlement_status', 'condition_status', 'direction', 'level'];

    // Hitung Akumulasi Finansial Otomatis Jika Ada Kolom Uang Utama
    $primary_money_col = null;
    foreach (['amount', 'gross', 'net', 'sales', 'profit', 'operational_cost', 'cash_ending'] as $scol) {
        if (in_array($scol, $columns, true)) {
            $primary_money_col = $scol;
            break;
        }
    }

    $total_nominal_sum = 0;
    if ($primary_money_col) {
        foreach ($rows as $r) {
            $total_nominal_sum += (float) ($r[$primary_money_col] ?? 0);
        }
    }

    $module_uid = 'mod_' . preg_replace('/[^a-zA-Z0-9_]/', '', $key) . '_' . wp_rand(100, 999);
    ?>

    <section class="pk01-op-card pk01-data-module" id="<?php echo esc_attr($module_uid); ?>" data-module="<?php echo esc_attr($key); ?>" style="margin-bottom:24px;">
        <!-- HEADER -->
        <div class="pk01-op-card-head" style="margin-bottom:16px;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px;">
                <div>
                    <span class="pk01-op-eyebrow"><?php echo esc_html($eyebrow); ?></span>
                    <h2 style="margin:4px 0 6px 0; font-size:20px; font-weight:700; color:#0f172a;"><?php echo esc_html($title); ?></h2>
                    <p style="color:#64748b; font-size:13px; margin:0;"><?php echo esc_html($description); ?></p>
                </div>
                <!-- BADGE STATUS LIVE -->
                <div>
                    <span style="font-size:12px; background:#f1f5f9; border:1px solid #e2e8f0; padding:5px 10px; border-radius:20px; color:#475569; font-weight:600;">
                        Modul: <code style="color:#2563eb;"><?php echo esc_html($key); ?></code>
                    </span>
                </div>
            </div>
        </div>

        <!-- SUMMARY STATISTIK PRO -->
        <div class="pk01-pro-summary-grid">
            <div class="pk01-pro-kpi-card">
                <span class="pk01-pro-kpi-label">Total Baris Data</span>
                <div class="pk01-pro-kpi-val"><span class="pk01-count-filtered"><?php echo number_format(count($rows), 0, ',', '.'); ?></span> <small style="font-size:12px; font-weight:normal; color:#64748b;">Record</small></div>
            </div>
            
            <?php if ($primary_money_col): ?>
            <div class="pk01-pro-kpi-card" style="border-left-color:#10b981;">
                <span class="pk01-pro-kpi-label">Akumulasi <?php echo esc_html($labels[$primary_money_col] ?? 'Nominal'); ?></span>
                <div class="pk01-pro-kpi-val" style="color:#047857;">
                    <?php echo class_exists('PK01_Settings') ? PK01_Settings::money($total_nominal_sum) : 'Rp ' . number_format($total_nominal_sum, 0, ',', '.'); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- TOOLBAR PRO: LIVE SEARCH & EXPORT CSV -->
        <?php if (!empty($rows) && !empty($columns)): ?>
        <div class="pk01-pro-toolbar">
            <div class="pk01-search-wrapper">
                <span class="pk01-search-icon">🔍</span>
                <input type="search" class="pk01-pro-search-input" placeholder="Ketik untuk filter cepat data..." aria-label="Cari data">
            </div>
            <div class="pk01-toolbar-actions">
                <button type="button" class="pk01-btn-export-csv" title="Unduh data dalam format CSV">
                    📥 Ekspor CSV
                </button>
            </div>
        </div>
        <?php endif; ?>

        <!-- TABEL DATA WRAPPER -->
        <div class="pk01-op-table-wrap pk01-pro-table-container">
            <?php if (!$rows || !$columns): ?>
                <div class="pk01-op-empty" style="text-align:center; padding:36px 16px; color:#94a3b8;">
                    <div style="font-size:28px; margin-bottom:8px;">📁</div>
                    <div style="font-weight:600; font-size:14px; color:#475569;">Belum ada data <?php echo esc_html(strtolower($title)); ?>.</div>
                    <div style="font-size:12px;">Data akan otomatis terisi seiring berjalannya transaksi operasional.</div>
                </div>
            <?php else: ?>
                <table class="pk01-op-table pk01-pro-table">
                    <thead>
                        <tr>
                            <?php foreach ($columns as $col): 
                                $align = in_array($col, $money_keys, true) || in_array($col, ['qty', 'target_qty', 'good_qty', 'reject_qty', 'order_count'], true) ? 'right' : (in_array($col, $status_keys, true) ? 'center' : 'left');
                            ?>
                                <th style="text-align:<?php echo esc_attr($align); ?>;">
                                    <?php echo esc_html($labels[$col] ?? ucwords(str_replace('_', ' ', $col))); ?>
                                </th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($columns as $col): 
                                    $raw = $row[$col] ?? '—';
                                    $align = in_array($col, $money_keys, true) || in_array($col, ['qty', 'target_qty', 'good_qty', 'reject_qty', 'order_count'], true) ? 'right' : (in_array($col, $status_keys, true) ? 'center' : 'left');
                                    
                                    // FORMATTING NILAI KOLOM
                                    if (in_array($col, $money_keys, true)) {
                                        $val = class_exists('PK01_Settings') ? PK01_Settings::money($raw) : 'Rp ' . number_format((float)$raw, 0, ',', '.');
                                        echo '<td style="text-align:right; font-weight:600; font-variant-numeric:tabular-nums;">' . esc_html($val) . '</td>';
                                    } elseif ($col === 'is_hpp') {
                                        $is_yes = ((int)$raw === 1);
                                        echo '<td style="text-align:center;"><span class="pk01-badge ' . ($is_yes ? 'badge-green' : 'badge-gray') . '">' . ($is_yes ? 'Ya' : 'Tidak') . '</span></td>';
                                    } elseif (in_array($col, $status_keys, true)) {
                                        // Badge Status Otomatis
                                        $st = strtolower(trim((string)$raw));
                                        $badge_class = 'badge-gray';
                                        if (in_array($st, ['active', 'paid', 'completed', 'selesai', 'lunas', 'in', 'masuk', 'sukses', 'success', 'approved', 'baik'], true)) {
                                            $badge_class = 'badge-green';
                                        } elseif (in_array($st, ['pending', 'process', 'processing', 'waiting', 'menunggu', 'draft'], true)) {
                                            $badge_class = 'badge-yellow';
                                        } elseif (in_array($st, ['cancelled', 'batal', 'failed', 'gagal', 'reject', 'rejected', 'rusak', 'out', 'keluar', 'unpaid'], true)) {
                                            $badge_class = 'badge-red';
                                        }
                                        echo '<td style="text-align:center;"><span class="pk01-badge ' . esc_attr($badge_class) . '">' . esc_html(ucfirst((string)$raw)) . '</span></td>';
                                    } elseif (in_array($col, $code_keys, true)) {
                                        echo '<td style="text-align:' . esc_attr($align) . ';"><span class="pk01-pro-code">' . esc_html((string)$raw) . '</span></td>';
                                    } elseif (is_numeric($raw) && in_array($col, ['qty', 'target_qty', 'good_qty', 'reject_qty', 'order_count', 'transactions', 'variants', 'active_variants', 'return_lines'], true)) {
                                        echo '<td style="text-align:right; font-weight:600;">' . esc_html(number_format((float)$raw, 0, ',', '.')) . '</td>';
                                    } else {
                                        $full_text = (string)$raw;
                                        $short = mb_strimwidth($full_text, 0, 50, '…');
                                        echo '<td style="text-align:' . esc_attr($align) . ';" title="' . esc_attr($full_text) . '">' . esc_html($short) . '</td>';
                                    }
                                endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </section>

    <!-- STYLES & JS PENDUKUNG -->
    <style>
    .pk01-pro-summary-grid {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-bottom: 16px;
    }
    .pk01-pro-kpi-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-left: 4px solid #3b82f6;
        padding: 10px 16px;
        border-radius: 6px;
        min-width: 180px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    }
    .pk01-pro-kpi-label {
        font-size: 11px;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .pk01-pro-kpi-val {
        font-size: 18px;
        font-weight: 800;
        color: #0f172a;
        margin-top: 2px;
    }
    .pk01-pro-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 12px;
    }
    .pk01-search-wrapper {
        position: relative;
        flex: 1;
        max-width: 320px;
    }
    .pk01-search-icon {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 13px;
        color: #94a3b8;
    }
    .pk01-pro-search-input {
        width: 100%;
        padding: 7px 10px 7px 32px;
        font-size: 13px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        background: #ffffff;
        outline: none;
        transition: border 0.2s;
    }
    .pk01-pro-search-input:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 2px rgba(37,99,235,0.1);
    }
    .pk01-btn-export-csv {
        background: #ffffff;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        padding: 7px 12px;
        font-size: 12px;
        font-weight: 600;
        color: #334155;
        cursor: pointer;
        transition: all 0.2s;
    }
    .pk01-btn-export-csv:hover {
        background: #f8fafc;
        border-color: #94a3b8;
    }
    .pk01-pro-table-container {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        overflow: auto;
        max-height: 520px;
        background: #ffffff;
    }
    .pk01-pro-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }
    .pk01-pro-table thead th {
        position: sticky;
        top: 0;
        background: #f8fafc;
        padding: 10px 12px;
        color: #475569;
        font-weight: 700;
        border-bottom: 2px solid #e2e8f0;
        z-index: 2;
        white-space: nowrap;
    }
    .pk01-pro-table tbody td {
        padding: 9px 12px;
        border-bottom: 1px solid #f1f5f9;
        color: #1e293b;
        white-space: nowrap;
    }
    .pk01-pro-table tbody tr:hover {
        background-color: #f8fafc;
    }
    .pk01-pro-code {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        background: #f1f5f9;
        padding: 2px 6px;
        border-radius: 4px;
        color: #334155;
        border: 1px solid #e2e8f0;
    }
    .pk01-badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        line-height: 1.4;
    }
    .badge-green { background: #dcfce7; color: #15803d; }
    .badge-yellow { background: #fef3c7; color: #b45309; }
    .badge-red { background: #fee2e2; color: #b91c1c; }
    .badge-gray { background: #f1f5f9; color: #475569; }
    </style>

    <script>
    (function() {
        var root = document.getElementById('<?php echo esc_js($module_uid); ?>');
        if (!root) return;

        var searchInput = root.querySelector('.pk01-pro-search-input');
        var exportBtn = root.querySelector('.pk01-btn-export-csv');
        var table = root.querySelector('.pk01-pro-table');
        var countFiltered = root.querySelector('.pk01-count-filtered');

        // PENCARIAN INSTAN (LIVE SEARCH)
        if (searchInput && table) {
            searchInput.addEventListener('input', function() {
                var query = this.value.toLowerCase().trim();
                var rows = table.querySelectorAll('tbody tr');
                var visibleCount = 0;

                rows.forEach(function(row) {
                    var text = row.innerText.toLowerCase();
                    if (text.indexOf(query) > -1) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });

                if (countFiltered) {
                    countFiltered.textContent = visibleCount;
                }
            });
        }

        // EKSPOR KE FORMAT CSV
        if (exportBtn && table) {
            exportBtn.addEventListener('click', function() {
                var csv = [];
                var rows = table.querySelectorAll('tr');

                rows.forEach(function(row) {
                    if (row.style.display === 'none') return; // Hanya ekspor data yang tampak
                    var cols = row.querySelectorAll('th, td');
                    var rowData = [];
                    cols.forEach(function(col) {
                        var text = col.innerText.replace(/"/g, '""').trim();
                        rowData.push('"' + text + '"');
                    });
                    csv.push(rowData.join(','));
                });

                var csvContent = "\uFEFF" + csv.join("\r\n");
                var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                var link = document.createElement("a");
                var filename = 'PK01_<?php echo esc_js($key); ?>_' + new Date().toISOString().slice(0,10) + '.csv';

                link.href = URL.createObjectURL(blob);
                link.setAttribute("download", filename);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });
        }
    })();
    </script>
    <?php
}
}