<?php
/**
 * PK01 Central Settings Service
 * IMPORTANT: this file is a service class only. The settings UI lives in
 * includes/modules/admin/settings/tampilan-pengaturan.php and must never execute during plugin load.
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('PK01_Settings', false)) {
class PK01_Settings {
    private static $cache = null;

    public static function init() { return true; }

    private static function defaults() {
        // Tidak ada identitas bisnis, rekening, NPWP, alamat, atau angka legal dummy.
        // Sumber kebenaran tetap pengaturan PK01; fallback hanya data WordPress yang memang nyata.
        return [
            'company_name' => get_bloginfo('name'),
            'company_legal_name' => '', 'company_tagline' => '', 'company_owner' => '',
            'company_address' => '', 'company_city' => '', 'company_province' => '', 'company_postcode' => '',
            'company_phone' => '', 'company_whatsapp' => '',
            'company_email' => get_option('admin_email'), 'company_website' => home_url('/'),
            'company_nib' => '', 'company_npwp' => '', 'company_logo' => '', 'company_stamp' => '',
            'signee_name' => '', 'signee_position' => '',
            'bank_name' => '', 'bank_account_number' => '', 'bank_account_name' => '',
            'invoice_terms' => '',
            'invoice_prefix' => 'INV', 'invoice_digits' => 5, 'invoice_sequence' => 1, 'invoice_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'po_prefix' => 'PO', 'po_digits' => 5, 'po_sequence' => 1, 'po_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'delivery_prefix' => 'SJ', 'delivery_digits' => 5, 'delivery_sequence' => 1, 'delivery_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'payment_prefix' => 'KK', 'payment_digits' => 5, 'payment_sequence' => 1, 'payment_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'seller_prefix' => 'SLR', 'seller_digits' => 4, 'seller_sequence' => 1, 'seller_pattern' => '{PREFIX}-{YY}-{SEQ}',
            'seller_order_prefix' => 'SEL', 'seller_order_digits' => 5, 'seller_order_sequence' => 1, 'seller_order_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'seller_invoice_prefix' => 'SINV', 'seller_invoice_digits' => 5, 'seller_invoice_sequence' => 1, 'seller_invoice_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'sales_prefix' => 'SO', 'sales_digits' => 5, 'sales_sequence' => 1, 'sales_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'job_prefix' => 'SPK', 'job_digits' => 5, 'job_sequence' => 1, 'job_pattern' => '{PREFIX}/{YYYY}/{SEQ}',
            'production_prefix' => 'PROD', 'production_digits' => 5, 'production_sequence' => 1, 'production_pattern' => '{PREFIX}/{YYYY}/{SEQ}',
            'payroll_prefix' => 'PAY', 'payroll_digits' => 5, 'payroll_sequence' => 1, 'payroll_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'payout_prefix' => 'WD', 'payout_digits' => 4, 'payout_sequence' => 1, 'payout_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'employee_prefix' => 'KRY', 'employee_digits' => 3, 'employee_sequence' => 1, 'employee_pattern' => '{PREFIX}-{SEQ}',
            'material_prefix' => 'MAT', 'material_digits' => 4, 'material_sequence' => 1, 'material_pattern' => '{PREFIX}-{SEQ}',
            'return_prefix' => 'RET', 'return_digits' => 4, 'return_sequence' => 1, 'return_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'shipment_prefix' => 'SHP', 'shipment_digits' => 5, 'shipment_sequence' => 1, 'shipment_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'stock_adjustment_prefix' => 'ADJ', 'stock_adjustment_digits' => 4, 'stock_adjustment_sequence' => 1, 'stock_adjustment_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'project_prefix' => 'PRJ', 'project_digits' => 4, 'project_sequence' => 1, 'project_pattern' => '{PREFIX}/{YYYY}/{SEQ}',
            'goods_receipt_prefix' => 'GR', 'goods_receipt_digits' => 5, 'goods_receipt_sequence' => 1, 'goods_receipt_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'warehouse_supplier_prefix' => 'WGR', 'warehouse_supplier_digits' => 5, 'warehouse_supplier_sequence' => 1, 'warehouse_supplier_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'warehouse_return_prefix' => 'WRT', 'warehouse_return_digits' => 5, 'warehouse_return_sequence' => 1, 'warehouse_return_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'warehouse_return_courier_prefix' => 'WRTC', 'warehouse_return_courier_digits' => 5, 'warehouse_return_courier_sequence' => 1, 'warehouse_return_courier_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'warehouse_handover_prefix' => 'WHD', 'warehouse_handover_digits' => 5, 'warehouse_handover_sequence' => 1, 'warehouse_handover_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'warehouse_production_out_prefix' => 'WPO', 'warehouse_production_out_digits' => 5, 'warehouse_production_out_sequence' => 1, 'warehouse_production_out_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'warehouse_production_in_prefix' => 'WPI', 'warehouse_production_in_digits' => 5, 'warehouse_production_in_sequence' => 1, 'warehouse_production_in_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'journal_prefix' => 'JNL', 'journal_digits' => 6, 'journal_sequence' => 1, 'journal_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'expense_prefix' => 'BKK', 'expense_digits' => 5, 'expense_sequence' => 1, 'expense_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'capital_prefix' => 'CAP', 'capital_digits' => 5, 'capital_sequence' => 1, 'capital_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'closing_prefix' => 'CLOSE', 'closing_digits' => 5, 'closing_sequence' => 1, 'closing_pattern' => '{PREFIX}/{YYYY}/{SEQ}',
            'owner_receipt_prefix' => 'OWN', 'owner_receipt_digits' => 5, 'owner_receipt_sequence' => 1, 'owner_receipt_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'security_visitor_prefix' => 'VIS', 'security_visitor_digits' => 5, 'security_visitor_sequence' => 1, 'security_visitor_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'security_gate_prefix' => 'SEC-G', 'security_gate_digits' => 5, 'security_gate_sequence' => 1, 'security_gate_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'security_incident_prefix' => 'INC', 'security_incident_digits' => 5, 'security_incident_sequence' => 1, 'security_incident_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'seller_bonus_prefix' => 'BON', 'seller_bonus_digits' => 5, 'seller_bonus_sequence' => 1, 'seller_bonus_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
            'cs_ticket_prefix' => 'CS', 'cs_ticket_digits' => 5, 'cs_ticket_sequence' => 1, 'cs_ticket_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
        ];
    }

    public static function get($key = null, $default = null) {
        if (self::$cache === null) {
            $saved = get_option('pk01_settings', []);
            self::$cache = wp_parse_args(is_array($saved) ? $saved : [], self::defaults());
        }
        if ($key === null || $key === '') return self::$cache;
        return array_key_exists($key, self::$cache) ? self::$cache[$key] : $default;
    }

    /** Canonical registry: every official PK01 number has one configurable prefix/digits/sequence/pattern. */
    public static function document_registry() {
        return [
            'invoice'=>['label'=>'Invoice Penjualan','key'=>'invoice'], 'po'=>['label'=>'Purchase Order','key'=>'po'],
            'delivery'=>['label'=>'Surat Jalan','key'=>'delivery'], 'payment'=>['label'=>'Kuitansi Kas Keluar','key'=>'payment'],
            'seller'=>['label'=>'Kode Seller','key'=>'seller'], 'seller_order'=>['label'=>'Order Seller','key'=>'seller_order'], 'seller_invoice'=>['label'=>'Invoice Seller','key'=>'seller_invoice'],
            'sales'=>['label'=>'Sales Order','key'=>'sales'], 'job'=>['label'=>'SPK / Job Produksi','key'=>'job'], 'production'=>['label'=>'Batch Produksi','key'=>'production'],
            'payroll'=>['label'=>'Slip Payroll','key'=>'payroll'], 'payout'=>['label'=>'Pencairan Seller / Marketplace','key'=>'payout'],
            'employee'=>['label'=>'Kode Karyawan','key'=>'employee'], 'material'=>['label'=>'Kode Bahan','key'=>'material'], 'return'=>['label'=>'Nota Retur','key'=>'return'],
            'shipment'=>['label'=>'Manifest Pengiriman','key'=>'shipment'], 'stock_adjustment'=>['label'=>'Penyesuaian Stok','key'=>'stock_adjustment'], 'project'=>['label'=>'Proyek','key'=>'project'],
            'goods_receipt'=>['label'=>'Bukti Penerimaan Barang (GR)','key'=>'goods_receipt'], 'warehouse_supplier'=>['label'=>'Tanda Terima Gudang ← Supplier','key'=>'warehouse_supplier'],
            'warehouse_return'=>['label'=>'Tanda Terima Retur – Gudang','key'=>'warehouse_return'], 'warehouse_return_courier'=>['label'=>'Tanda Terima Retur – Kurir','key'=>'warehouse_return_courier'],
            'warehouse_handover'=>['label'=>'Tanda Terima Gudang → Kurir','key'=>'warehouse_handover'], 'warehouse_production_out'=>['label'=>'Tanda Terima Gudang → Produksi','key'=>'warehouse_production_out'],
            'warehouse_production_in'=>['label'=>'Tanda Terima Produksi → Gudang','key'=>'warehouse_production_in'], 'journal'=>['label'=>'Jurnal Akuntansi','key'=>'journal'],
            'expense'=>['label'=>'Tanda Terima Pengeluaran','key'=>'expense'], 'capital'=>['label'=>'Transaksi Modal','key'=>'capital'], 'closing'=>['label'=>'Penutupan Periode','key'=>'closing'],
            'owner_receipt'=>['label'=>'Penerimaan / Penarikan Pemilik','key'=>'owner_receipt'], 'security_visitor'=>['label'=>'Nomor Tamu / Visitor','key'=>'security_visitor'],
            'security_gate'=>['label'=>'Kode Gate Security','key'=>'security_gate'], 'security_incident'=>['label'=>'Nomor Insiden Security','key'=>'security_incident'], 'seller_bonus'=>['label'=>'Nomor Bonus Seller','key'=>'seller_bonus'], 'cs_ticket'=>['label'=>'Tiket Customer Service','key'=>'cs_ticket'],
        ];
    }
    public static function document_setting_keys() {
        $keys=[]; foreach(self::document_registry() as $d){$k=$d['key']; foreach(['prefix','digits','sequence','pattern'] as $s) $keys[]=$k.'_'.$s;} return $keys;
    }
    public static function document_config($type) {
        $reg=self::document_registry(); $d=$reg[$type]??null; if(!$d) return null; $k=$d['key'];
        return ['type'=>$type,'key'=>$k,'label'=>$d['label'],'prefix'=>self::get($k.'_prefix','DOC'),'digits'=>max(1,(int)self::get($k.'_digits',5)),'sequence'=>max(1,(int)self::get($k.'_sequence',1)),'pattern'=>self::get($k.'_pattern','{PREFIX}/{YYYY}{MM}/{SEQ}')];
    }

    public static function get_group($group) {
        $all = self::get();
        $groups = [
            'general' => ['company_name','company_legal_name','company_tagline','company_owner','company_address','company_city','company_province','company_postcode','company_phone','company_whatsapp','company_email','company_website','company_nib','company_npwp','company_logo','company_stamp','signee_name','signee_position','bank_name','bank_account_number','bank_account_name'],
            'documents' => array_merge(self::document_setting_keys(), ['invoice_terms']),
            'integration' => ['shipping','ai'],
            'backup' => ['backup'],
            'access' => ['access'],
            'ai' => ['ai'],
        ];
        $keys = $groups[$group] ?? [];
        if (!$keys) return [];
        $out = [];
        foreach ($keys as $key) if (array_key_exists($key, $all)) $out[$key] = $all[$key];
        return $out;
    }

    public static function update_group($group, $values) {
        $current = self::get();
        if (!is_array($values)) return $current;
        // Groups may contain nested configuration (e.g. shipping/ai).
        foreach ($values as $k => $v) $current[$k] = $v;
        update_option('pk01_settings', $current, false);
        self::$cache = $current;
        return $current;
    }

    public static function shipping() {
        $integration = self::get('integration', []);
        if (is_array($integration) && isset($integration['shipping'])) return (array)$integration['shipping'];
        $shipping = self::get('shipping', []);
        return is_array($shipping) ? $shipping : [];
    }

    public static function identity() {
        $s = self::get();
        $parts = array_filter([
            trim((string)($s['company_address'] ?? '')),
            trim((string)($s['company_city'] ?? '')),
            trim((string)($s['company_province'] ?? '')),
            trim((string)($s['company_postcode'] ?? '')),
        ]);
        return [
            'name' => sanitize_text_field((string)($s['company_name'] ?? get_bloginfo('name'))),
            'legal_name' => sanitize_text_field((string)($s['company_legal_name'] ?? '')),
            'tagline' => sanitize_text_field((string)($s['company_tagline'] ?? '')),
            'owner' => sanitize_text_field((string)($s['company_owner'] ?? '')),
            'address' => implode(', ', $parts),
            'phone' => sanitize_text_field((string)($s['company_phone'] ?? '')),
            'whatsapp' => sanitize_text_field((string)($s['company_whatsapp'] ?? '')),
            'email' => sanitize_email((string)($s['company_email'] ?? get_option('admin_email'))),
            'website' => esc_url_raw((string)($s['company_website'] ?? home_url('/'))),
            'nib' => sanitize_text_field((string)($s['company_nib'] ?? '')),
            'npwp' => sanitize_text_field((string)($s['company_npwp'] ?? '')),
            'logo' => esc_url_raw((string)($s['company_logo'] ?? '')),
            'stamp' => esc_url_raw((string)($s['company_stamp'] ?? '')),
            'signee_name' => sanitize_text_field((string)($s['signee_name'] ?? '')),
            'signee_position' => sanitize_text_field((string)($s['signee_position'] ?? '')),
            'bank_name' => sanitize_text_field((string)($s['bank_name'] ?? '')),
            'bank_account_number' => sanitize_text_field((string)($s['bank_account_number'] ?? '')),
            'bank_account_name' => sanitize_text_field((string)($s['bank_account_name'] ?? '')),
            'invoice_terms' => (string)($s['invoice_terms'] ?? ''),
        ];
    }

    public static function money($amount) {
        return 'Rp ' . number_format((float)$amount, 0, ',', '.');
    }
}
}
