<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage   = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('customers') || PK01_Authorization::can('sales')));

$action = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('customers')
    : add_query_arg('pk01_view', 'customers', home_url('/'));

$notice = '';

// Helper Nama Tabel
$tbl_customers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('customers') 
    : $wpdb->prefix . 'pk01_customers';

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_customers)) === $tbl_customers);

// 2. LOGIKA BARU: EKSPOR DATA PELANGGAN KE CSV (CRM / BROADCAST WHATSAPP)
if (isset($_POST['pk01_export_customers_csv']) && check_admin_referer('pk01_export_customers_nonce')) {
    if ($can_manage && $table_exists) {
        $export_rows = $wpdb->get_results(
            "SELECT c.*, u.user_login, u.display_name 
             FROM `{$tbl_customers}` c 
             LEFT JOIN `{$wpdb->users}` u ON u.ID = c.user_id 
             ORDER BY c.id DESC", 
            ARRAY_A
        );
        if (!empty($export_rows)) {
            $filename = 'pk01-data-pelanggan-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID', 'Nama Pelanggan', 'No. WhatsApp / Telepon', 'Email', 'Akun WordPress', 'Waktu Dibuat']);
            foreach ($export_rows as $r) {
                fputcsv($out, [
                    $r['id'],
                    $r['name'],
                    $r['phone'],
                    $r['email'],
                    $r['display_name'] ?: ($r['user_login'] ?: '-'),
                    $r['created_at'] ?? '-'
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. PROSES SIMPAN / UPDATE PELANGGAN (LOGIKA LAMA UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_customer_save'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_customer_nonce'] ?? '')), 'pk01_customer_save')) {
        $notice = '<div class="pk01-cus-alert is-error">⚠️ Sesi keamanan tidak valid atau telah kedaluwarsa.</div>';
    } else {
        try {
            $id      = (int)($_POST['id'] ?? 0);
            $name    = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
            $phone   = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
            $email   = sanitize_email(wp_unslash($_POST['email'] ?? ''));
            $user_id = absint($_POST['user_id'] ?? 0);

            if (empty($name)) {
                throw new Exception('Nama lengkap pelanggan wajib diisi.');
            }

            PK01_Engine::save_customer($id, $name, $phone, $email, $user_id);
            $notice = '<div class="pk01-cus-alert is-success">✅ Data pelanggan <strong>' . esc_html($name) . '</strong> berhasil disimpan.</div>';
            $_POST = [];
        } catch (Throwable $e) {
            $notice = '<div class="pk01-cus-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 4. AMBIL DATA EDIT & DAFTAR PELANGGAN REAL DARI DATABASE
$edit_id = (int)($_GET['edit_id'] ?? 0);
$edit    = ($edit_id && $table_exists) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_customers}` WHERE id = %d", $edit_id), ARRAY_A) : null;

$rows = [];
if ($table_exists) {
    $rows = $wpdb->get_results(
        "SELECT c.*, u.display_name, u.user_login 
         FROM `{$tbl_customers}` c 
         LEFT JOIN `{$wpdb->users}` u ON u.ID = c.user_id 
         ORDER BY c.id DESC LIMIT 150", 
        ARRAY_A
    ) ?: [];
}

// 5. HITUNG METRIK REAL CRM DATABASE
$total_customers = count($rows);
$with_phone      = 0;
$with_email      = 0;
$linked_users    = 0;

foreach ($rows as $r) {
    if (!empty($r['phone'])) $with_phone++;
    if (!empty($r['email'])) $with_email++;
    if (!empty($r['user_id'])) $linked_users++;
}

// Ambil User WordPress untuk Dropdown Tautan Akun
$wp_users = get_users(['fields' => ['ID', 'user_login', 'display_name'], 'number' => 100, 'orderby' => 'display_name', 'order' => 'ASC']);

// Helper URL WhatsApp Resmi
function pk01_format_wa_url($phone) {
    $clean = preg_replace('/[^0-9]/', '', $phone);
    if (substr($clean, 0, 1) === '0') {
        $clean = '62' . substr($clean, 1);
    } elseif (substr($clean, 0, 2) !== '62') {
        $clean = '62' . $clean;
    }
    return 'https://wa.me/' . $clean;
}
?>

<style>
:root {
    --pk-cus-navy: #0f172a;
    --pk-cus-border: #e2e8f0;
    --pk-cus-blue: #2563eb;
    --pk-cus-green: #059669;
    --pk-cus-amber: #d97706;
    --pk-cus-purple: #7c3aed;
    --pk-cus-muted: #64748b;
}

.pk01-customer-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-customer-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-cus-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-cus-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-cus-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-cus-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-cus-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-cus-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-cus-blue); }
.pk01-kpi-card.c-green::before  { background: var(--pk-cus-green); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-cus-amber); }
.pk01-kpi-card.c-purple::before { background: var(--pk-cus-purple); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--pk-cus-muted);
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: var(--pk-cus-muted);
}

/* Split Form & Sidebar */
.pk01-cus-split {
    display: grid;
    grid-template-columns: 1.4fr 0.9fr;
    gap: 20px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 960px) {
    .pk01-cus-split { grid-template-columns: 1fr; }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-cus-border);
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: var(--pk-cus-blue);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Table Style */
.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-cus-border);
    border-radius: 12px;
}
.pk01-cus-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-cus-table th {
    background: #f8fafc;
    padding: 11px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-cus-border);
}
.pk01-cus-table td {
    padding: 11px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-cus-table tr:hover td { background: #fbfcfe; }

/* Action Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-wa {
    background: #25d366;
    color: #ffffff !important;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-btn-wa:hover { background: #1ebc57; }

.pk01-cus-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-cus-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-cus-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-customer-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-cus-hero">
        <div>
            <span class="pk01-cus-eyebrow">CUSTOMER RELATIONS &bull; CRM REPOSITORY</span>
            <h1>Direktori &amp; Master Data Pelanggan</h1>
            <p>
                Satu master data pelanggan terpadu yang menjadi acuan otomatis bagi faktur penjualan, rekonsiliasi piutang dagang, 
                surat jalan pengiriman, dan riwayat repeat order.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_customers_nonce'); ?>
                <input type="hidden" name="pk01_export_customers_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Data Pelanggan (.CSV)
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-cus-kpis">
        <div class="pk01-kpi-card c-blue">
            <small>Total Pelanggan Terdaftar</small>
            <strong><?php echo number_format($total_customers); ?> <span style="font-size:13px;font-weight:normal;">Kontak</span></strong>
            <span>Master kontak tersimpan</span>
        </div>

        <div class="pk01-kpi-card c-green">
            <small>Memiliki No. WhatsApp</small>
            <strong style="color:#059669;"><?php echo number_format($with_phone); ?> <span style="font-size:13px;font-weight:normal;">Nomor</span></strong>
            <span>Siap follow-up / broadcast</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Tercatat Alamat Email</small>
            <strong style="color:#d97706;"><?php echo number_format($with_email); ?> <span style="font-size:13px;font-weight:normal;">Email</span></strong>
            <span>Tersinkron untuk invoice digital</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Akun WordPress Tertaut</small>
            <strong style="color:#7c3aed;"><?php echo number_format($linked_users); ?> <span style="font-size:13px;font-weight:normal;">User</span></strong>
            <span>Terhubung ke akun login pembeli</span>
        </div>
    </div>

    <!-- 3. SPLIT FORM INPUT & PANDUAN INTEGRASI -->
    <div class="pk01-cus-split">
        
        <!-- Form Input Pelanggan -->
        <div class="pk01-surface">
            <div class="pk01-surface-head">
                <h3><?php echo $edit ? '✏️ Edit Pelanggan: ' . esc_html($edit['name']) : '➕ Tambah Pelanggan Baru'; ?></h3>
                <?php if ($edit): ?>
                    <a href="<?php echo esc_url($action); ?>" style="font-size:12px; color:#dc2626; text-decoration:none; font-weight:700;">✕ Batal Edit</a>
                <?php endif; ?>
            </div>

            <form method="post" action="<?php echo esc_url($action); ?>">
                <?php echo wp_nonce_field('pk01_customer_save', 'pk01_customer_nonce', true, false); ?>
                <input type="hidden" name="pk01_customer_save" value="1">
                <input type="hidden" name="id" value="<?php echo (int)($edit['id'] ?? 0); ?>">

                <div class="pk01-form-grid">
                    <div class="pk01-field-item" style="grid-column: span 2;">
                        <label>Nama Lengkap Pelanggan / Perusahaan <span style="color:#dc2626;">*</span></label>
                        <input type="text" name="name" class="pk01-input" required value="<?php echo esc_attr($edit['name'] ?? ''); ?>" placeholder="Contoh: Ibu Rina / PT Maju Mandiri">
                    </div>

                    <div class="pk01-field-item">
                        <label>No. WhatsApp Aktif</label>
                        <input type="tel" name="phone" id="input_cus_phone" class="pk01-input" value="<?php echo esc_attr($edit['phone'] ?? ''); ?>" placeholder="Contoh: 08123456789">
                        <span id="wa_preview_hint" style="font-size:11px;color:#64748b;margin-top:2px;"></span>
                    </div>

                    <div class="pk01-field-item">
                        <label>Alamat Email</label>
                        <input type="email" name="email" class="pk01-input" value="<?php echo esc_attr($edit['email'] ?? ''); ?>" placeholder="pelanggan@domain.com">
                    </div>

                    <div class="pk01-field-item" style="grid-column: span 2;">
                        <label>Tautkan Akun WordPress Pembeli (Opsional)</label>
                        <select name="user_id" class="pk01-input">
                            <option value="0">— Tanpa Akun WordPress —</option>
                            <?php foreach ($wp_users as $u): ?>
                                <option value="<?php echo (int)$u->ID; ?>" <?php selected((int)($edit['user_id'] ?? 0), (int)$u->ID); ?>>
                                    <?php echo esc_html($u->display_name . ' (@' . $u->user_login . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div style="margin-top:16px; display:flex; gap:10px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        <?php echo $edit ? '💾 Simpan Perubahan Pelanggan' : '💾 Tambah Pelanggan'; ?>
                    </button>
                    <?php if ($edit): ?>
                        <a class="pk01-btn pk01-btn-export" href="<?php echo esc_url($action); ?>">Batal</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Box Panduan Master Terpadu -->
        <div class="pk01-surface" style="background:#f8fafc;">
            <div class="pk01-surface-head">
                <h3>💡 Master Terintegrasi Otomatis</h3>
            </div>
            <p style="font-size:13px; color:#475569; line-height:1.6; margin:0 0 14px 0;">
                Data kontak pelanggan di sini dipakai bersama oleh seluruh alur transaksi bisnis di PK01:
            </p>
            <div style="background:#ffffff; border:1px solid #cbd5e1; border-radius:8px; padding:14px; font-size:13px; margin-bottom:12px;">
                <ul style="margin:0; padding-left:18px; line-height:1.6; color:#1e293b;">
                    <li><b>Penjualan Kasir:</b> Auto-fill nama dan no WA saat membuat pesanan.</li>
                    <li><b>Pengiriman:</b> Nama penerima otomatis tercetak di surat jalan &amp; resi.</li>
                    <li><b>Invoice &amp; Piutang:</b> Riwayat faktur terpusat per kontak pelanggan.</li>
                </ul>
            </div>
            <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0;">
                ℹ️ Cukup perbarui kontak di menu ini sekali, dan seluruh dokumen pesanan yang memuat pelanggan ini otomatis tersinkronisasi.
            </p>
        </div>

    </div>

    <!-- 4. TOOLBAR PENCARIAN -->
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
        <h3 style="margin:0; font-size:17px; font-weight:800; color:#0f172a;">Daftar Pelanggan Terdaftar</h3>
        <input type="search" id="pk01-search-customer" class="pk01-input" placeholder="🔍 Cari nama, WA, email..." style="width:260px;">
    </div>

    <!-- 5. TABEL DATA PELANGGAN -->
    <div class="pk01-table-wrap">
        <table id="pk01-table-customers" class="pk01-cus-table">
            <thead>
                <tr>
                    <th style="width:70px;">ID</th>
                    <th>Nama Pelanggan</th>
                    <th>No. WhatsApp / Telepon</th>
                    <th>Alamat Email</th>
                    <th>Akun Tertaut</th>
                    <th style="text-align:center;width:160px;">Aksi Cepat</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($rows)): ?>
                    <?php foreach ($rows as $r): 
                        $has_phone = !empty($r['phone']);
                        $wa_link = $has_phone ? pk01_format_wa_url($r['phone']) : '#';
                    ?>
                    <tr>
                        <td style="font-family:monospace;font-weight:700;color:#64748b;">#<?php echo esc_html($r['id']); ?></td>
                        <td><strong style="color:#0f172a;"><?php echo esc_html($r['name']); ?></strong></td>
                        <td>
                            <?php if ($has_phone): ?>
                                <span style="font-family:monospace; font-weight:600;"><?php echo esc_html($r['phone']); ?></span>
                            <?php else: ?>
                                <span style="color:#94a3b8;">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($r['email'])): ?>
                                <a href="mailto:<?php echo esc_attr($r['email']); ?>" style="color:#2563eb;text-decoration:none;">
                                    <?php echo esc_html($r['email']); ?>
                                </a>
                            <?php else: ?>
                                <span style="color:#94a3b8;">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($r['display_name'])): ?>
                                <span style="background:#f1f5f9;padding:3px 8px;border-radius:4px;font-size:12px;font-weight:600;border:1px solid #e2e8f0;">
                                    @<?php echo esc_html($r['display_name']); ?>
                                </span>
                            <?php else: ?>
                                <span style="color:#94a3b8;">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center;">
                            <div style="display:inline-flex; gap:6px; align-items:center;">
                                <?php if ($has_phone): ?>
                                    <a class="pk01-btn-wa" target="_blank" href="<?php echo esc_url($wa_link); ?>" title="Buka Chat WhatsApp">
                                        💬 WA
                                    </a>
                                <?php endif; ?>
                                <a class="pk01-btn pk01-btn-export" href="<?php echo esc_url(add_query_arg('edit_id', (int)$r['id'], $action)); ?>" style="padding:4px 10px; font-size:12px;">
                                    ✏️ Edit
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:36px; color:#94a3b8;">
                            Belum ada kontak pelanggan yang tersimpan di sistem.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. LIVE WHATSAPP FORMATTER HINT
    var phoneInput = document.getElementById('input_cus_phone');
    var hint = document.getElementById('wa_preview_hint');

    if (phoneInput && hint) {
        phoneInput.addEventListener('input', function() {
            var val = this.value.replace(/[^0-9]/g, '');
            if (val.length > 5) {
                if (val.substr(0, 1) === '0') val = '62' + val.substr(1);
                hint.textContent = 'Preview Tautan: https://wa.me/' + val;
            } else {
                hint.textContent = '';
            }
        });
    }

    // 2. LIVE SEARCH PELANGGAN
    var searchInput = document.getElementById('pk01-search-customer');
    var table       = document.getElementById('pk01-table-customers');

    if (searchInput && table) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            var rows   = table.querySelectorAll('tbody tr');

            rows.forEach(function(row) {
                var text = row.innerText.toLowerCase();
                row.style.display = (text.indexOf(filter) > -1) ? '' : 'none';
            });
        });
    }
});
</script>