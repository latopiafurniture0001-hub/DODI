<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_month = current_time('Y-m');

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('sales') || PK01_Authorization::can('orders') || PK01_Authorization::can('pos')));

// 2. DETEKSI TABEL-TABEL TERKAIT SECARA DINAMIS
$get_table = function($key) use ($wpdb) {
    $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
};

$tbl_orders       = $get_table('sales_orders') ?: ($get_table('orders') ?: $wpdb->prefix . 'pk01_sales_orders');
$tbl_variants     = $get_table('product_variants') ?: ($get_table('variants') ?: $wpdb->prefix . 'pk01_variants');
$tbl_sellers      = $get_table('sales_accounts') ?: ($get_table('sellers') ?: $wpdb->prefix . 'pk01_sellers');
$tbl_seller_sales = $get_table('seller_sales');
$tbl_customers    = $get_table('customers');
$tbl_stock_tx     = $get_table('stock_transactions');
$tbl_ledger       = $get_table('cash_ledger');
$tbl_logs         = $get_table('logs') ?: ($get_table('activity_logs') ?: $wpdb->prefix . 'pk01_activity_logs');

// ORDER SELLER DARI DASHBOARD: Kasir adalah pintu penerimaan. Stok/AR belum berubah sampai diterima.
$seller_order_notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_accept_seller_order']) && $can_manage) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_seller_order_nonce'] ?? '')), 'pk01_accept_seller_order')) {
        $seller_order_notice = '<div class="pk01-op-notice is-error">Sesi tidak valid.</div>';
    } else {
        try {
            $oid = absint($_POST['seller_order_id'] ?? 0);
            if (!$oid) throw new Exception('Order Seller tidak valid.');
            $result = PK01_Engine::seller_accept_order($oid);
            if (!empty($result['production_required'])) {
                $seller_order_notice = '<div class="pk01-op-notice is-success">Order Seller diterima Kasir. Stok belum dipotong karena kurang; sistem sudah membuat Order Produksi untuk kekurangan <strong>'.esc_html((string)$result['shortage']).'</strong> unit.</div>';
            } elseif (!empty($result['purchase_required'])) {
                $seller_order_notice = '<div class="pk01-op-notice is-success">Order Seller diterima Kasir. Stok belum dipotong karena kurang; sistem sudah membuat Permintaan Pembelian Produk Jadi.</div>';
            } else {
                $seller_order_notice = '<div class="pk01-op-notice is-success">Order Seller diterima Kasir dan diteruskan ke Gudang. Stok dipotong sesuai SKU PK01.</div>';
            }
        } catch (Throwable $e) {
            $seller_order_notice = '<div class="pk01-op-notice is-error">Order belum bisa diterima: '.esc_html($e->getMessage()).'. Jika stok kurang, buat Order Produksi/Pembelian dari alur Kasir.</div>';
        }
    }
}

// DISPATCH JOB PRODUKSI DARI KASIR: satu Job dapat memiliki beberapa tahap
// nyata (mis. CNC + Prema). Mesin tidak dijalankan otomatis; file G-code hanya
// disiapkan dari Master Library dan diberikan manual kepada operator.
$production_dispatch_notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_cashier_dispatch_job']) && $can_manage) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_cashier_dispatch_nonce'] ?? '')), 'pk01_cashier_dispatch_job')) {
        $production_dispatch_notice = '<div class="pk01-op-notice is-error">Sesi tidak valid.</div>';
    } else {
        try {
            $dispatch_job_id = absint($_POST['job_id'] ?? 0);
            if (!$dispatch_job_id) throw new Exception('Job Produksi tidak valid.');
            $dispatch = PK01_Engine::auto_dispatch_production_job($dispatch_job_id);
            $parts=[];
            foreach (($dispatch['stages'] ?? []) as $stage=>$info) {
                $label=$stage==='cnc'?'CNC':'Prema';
                if (($info['status']??'')==='assigned') $parts[]=$label.' → '.($info['employee_name']??'Pekerja');
                else $parts[]=$label.' → '.($info['reason']??'Belum dapat ditugaskan');
            }
            $production_dispatch_notice = '<div class="pk01-op-notice is-success"><strong>Job '.$dispatch_job_id.' diproses.</strong> '.esc_html(implode(' | ',$parts)).'</div>';
        } catch (Throwable $e) {
            $production_dispatch_notice = '<div class="pk01-op-notice is-error">Job belum dapat dikirim: '.esc_html($e->getMessage()).'</div>';
        }
    }
}

// Lanjutkan pemenuhan order Seller setelah produksi/pembelian menambah stok.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_resume_seller_order']) && $can_manage) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_resume_seller_order_nonce'] ?? '')), 'pk01_resume_seller_order')) {
        $seller_order_notice = '<div class="pk01-op-notice is-error">Sesi tidak valid.</div>';
    } else {
        try {
            $oid = absint($_POST['seller_order_id'] ?? 0);
            if (!$oid) throw new Exception('Order Seller tidak valid.');
            PK01_Engine::seller_fulfill_order($oid);
            $seller_order_notice = '<div class="pk01-op-notice is-success">Order Seller berhasil dilanjutkan setelah stok tersedia dan diteruskan ke Gudang.</div>';
        } catch (Throwable $e) {
            $seller_order_notice = '<div class="pk01-op-notice is-error">Order belum bisa dilanjutkan: '.esc_html($e->getMessage()).'</div>';
        }
    }
}
$seller_pending_orders = [];
if ($can_manage && class_exists('PK01_DB')) {
    $tso=PK01_DB::t('seller_orders'); $toi=PK01_DB::t('seller_order_items'); $tsa=PK01_DB::t('sales_accounts'); $tv=PK01_DB::t('product_variants'); $tp=PK01_DB::t('products');
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$tso)) === $tso) {
        $seller_pending_orders=$wpdb->get_results("SELECT so.*,sa.name seller_name,GROUP_CONCAT(CONCAT(v.sku,' × ',soi.qty,' | ',p.name,' | ',COALESCE(v.size,'')) SEPARATOR ' || ') item_summary FROM `{$tso}` so JOIN `{$tsa}` sa ON sa.id=so.seller_account_id LEFT JOIN `{$toi}` soi ON soi.order_id=so.id LEFT JOIN `{$tv}` v ON v.id=soi.variant_id LEFT JOIN `{$tp}` p ON p.id=v.product_id WHERE so.status IN ('requested','awaiting_production','awaiting_purchase') GROUP BY so.id ORDER BY so.id DESC LIMIT 50",ARRAY_A)?:[];
    }
}


// 3. EKSPOR TRANSAKSI PENJUALAN KE CSV
if (isset($_POST['pk01_export_sales_csv']) && check_admin_referer('pk01_export_sales_nonce')) {
    if ($can_manage) {
        $export_orders = $wpdb->get_results(
            "SELECT order_no, channel, customer_name, customer_phone, product_name, qty, price, total_amount, paid_amount, payment_method, payment_status, status, created_at 
             FROM `{$tbl_orders}` ORDER BY id DESC LIMIT 5000",
            ARRAY_A
        );
        if (!empty($export_orders)) {
            $filename = 'pk01-penjualan-orders-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['No. Order/Invoice', 'Channel Penjualan', 'Nama Pelanggan', 'No. WhatsApp', 'Produk', 'Qty', 'Harga Satuan', 'Total Penjualan', 'Sudah Dibayar', 'Metode Bayar', 'Status Bayar', 'Status Order', 'Waktu Transaksi']);
            foreach ($export_orders as $row) {
                fputcsv($out, [
                    $row['order_no'],
                    ucfirst($row['channel']),
                    $row['customer_name'],
                    $row['customer_phone'],
                    $row['product_name'],
                    $row['qty'],
                    $row['price'],
                    $row['total_amount'],
                    $row['paid_amount'],
                    $row['payment_method'],
                    strtoupper($row['payment_status']),
                    strtoupper($row['status']),
                    $row['created_at']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. IMPORT RESI MASSAL DARI CSV (PELAPORAN/GUDANG SAJA)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_import_resi_csv']) && $can_manage) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_resi_import_nonce']??'')),'pk01_resi_import_action')) {
        $notice='<div class="pk01-sal-alert is-error">⚠️ Sesi keamanan kedaluwarsa.</div>';
    } elseif (empty($_FILES['pk01_resi_file']['tmp_name']) || !is_uploaded_file($_FILES['pk01_resi_file']['tmp_name'])) {
        $notice='<div class="pk01-sal-alert is-error">⚠️ File CSV belum dipilih.</div>';
    } else {
        try {
            $fh=fopen($_FILES['pk01_resi_file']['tmp_name'],'r'); if(!$fh) throw new Exception('File tidak dapat dibaca.');
            $header=fgetcsv($fh,0,','); if(!$header) throw new Exception('CSV kosong. Wajib ada kolom resi. Kolom order_no opsional bila resi sudah tersimpan pada order.');
            $header=array_map(function($v){$v=preg_replace('/^\xEF\xBB\xBF/','',(string)$v);return strtolower(trim(str_replace([' ','-','/'],'_',$v)));},$header);
            if(!in_array('resi',$header,true) && !in_array('tracking_no',$header,true)) throw new Exception('Kolom wajib: resi atau tracking_no. Kolom opsional: order_no, courier, service.');
            $idx=array_flip($header); $ok=0;$skip=0;$errors=[];$line=1;
            while(($row=fgetcsv($fh,0,','))!==false){
                $line++; if(count(array_filter($row,fn($v)=>trim((string)$v)!==''))===0)continue;
                $resi=strtoupper(sanitize_text_field($row[$idx['resi']??$idx['tracking_no']??-1]??''));
                $order_no=sanitize_text_field($row[$idx['order_no']??-1]??'');
                $courier=sanitize_key($row[$idx['courier']??-1]??'');
                $service=sanitize_text_field($row[$idx['service']??-1]??'REG');
                if($resi===''){ $errors[]="Baris {$line}: resi kosong."; continue; }

                // Resi adalah kunci pengiriman. Jika order_no diberikan, gunakan sebagai pengikat tambahan.
                $order=null;
                if($order_no!=='') $order=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_orders}` WHERE order_no=%s OR invoice_no=%s LIMIT 1",$order_no,$order_no),ARRAY_A);
                if(!$order){
                    $order=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_orders}` WHERE tracking_no=%s ORDER BY id DESC LIMIT 1",$resi),ARRAY_A);
                }
                if(!$order){ $errors[]="Baris {$line}: resi {$resi} belum dapat dihubungkan ke order PK01. Masukkan order terlebih dahulu atau isi order_no."; continue; }

                $existing=$wpdb->get_row($wpdb->prepare("SELECT id,sale_id,seller_sale_id FROM ".PK01_DB::t('shipments')." WHERE tracking_no=%s LIMIT 1",$resi),ARRAY_A);
                if($existing){
                    $same=((int)($existing['sale_id']??0)===(int)$order['id']);
                    if($same){$skip++;continue;}
                    $errors[]="Baris {$line}: AWB {$resi} sudah terhubung ke transaksi lain."; continue;
                }
                if($courier==='') $courier=sanitize_key($order['courier']??'');
                $sid=PK01_Engine::create_shipment($order['channel']?:'website',$resi,$courier,$service,(int)$order['id'],0,'','','',true);
                if($sid && class_exists('PK01_Shipping_Smart')) PK01_Shipping_Smart::verify_shipment($sid);
                $ok++;
            }
            fclose($fh);
            $notice='<div class="pk01-sal-alert is-success">✅ Import selesai: <b>'.$ok.'</b> resi baru, <b>'.$skip.'</b> sudah tercatat. Resi hanya membuat/memperbarui record Pengiriman, Gudang, Tracking, dan Laporan — <b>tidak membuat tagihan atau pembayaran</b>.</div>';
            if($errors)$notice.='<div class="pk01-sal-alert is-error" style="margin-top:8px;white-space:pre-line">'.esc_html(implode("\n",array_slice($errors,0,30))).'</div>';
        } catch(Throwable $e){$notice='<div class="pk01-sal-alert is-error">❌ Import gagal: '.esc_html($e->getMessage()).'</div>';}
    }
}

// 4A. MODEL BARU DARI KASIR: KASIR ADALAH PEMBERI ORDER PRODUKSI
// Model baru wajib memiliki identitas teknis sebelum boleh menjadi SKU PK01.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_create_sale'])) {
    // Dijalankan di dalam handler penjualan di bawah. Bagian ini hanya menyiapkan flag;
    // pembuatan model dilakukan sebelum create_sale agar transaksi tetap satu pintu.
}

// 4. PROSES INPUT TRANSAKSI PENJUALAN — SATU PINTU MELALUI PK01_Engine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_create_sale'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_sale_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_sale_create_action')) {
        $notice = '<div class="pk01-sal-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        $clean_num = function($val) { return (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)$val)); };
        $payload = [
            'channel'=>sanitize_key($_POST['sale_channel'] ?? 'website'), 'seller_id'=>absint($_POST['sale_seller_id'] ?? 0),
            'customer_name'=>sanitize_text_field(wp_unslash($_POST['sale_customer_name'] ?? '')), 'customer_phone'=>sanitize_text_field(wp_unslash($_POST['sale_customer_phone'] ?? '')),
            'shipping_address'=>sanitize_textarea_field(wp_unslash($_POST['sale_shipping_address'] ?? '')), 'variant_id'=>absint($_POST['sale_variant_id'] ?? 0),
            'qty'=>max(1,$clean_num($_POST['sale_qty'] ?? 1)), 'price'=>$clean_num($_POST['sale_price'] ?? 0),
            'payment_method'=>sanitize_text_field(wp_unslash($_POST['sale_payment_method'] ?? 'Transfer Bank')), 'payment_status'=>sanitize_key($_POST['sale_payment_status'] ?? 'paid'),
            'paid_amount'=>$clean_num($_POST['sale_paid_amount'] ?? 0), 'status'=>sanitize_key($_POST['sale_status'] ?? 'processing'), 'tracking_no'=>strtoupper(sanitize_text_field(wp_unslash($_POST['sale_tracking_no'] ?? ''))), 'courier'=>sanitize_key($_POST['sale_courier'] ?? ''), 'shipping_service'=>sanitize_text_field(wp_unslash($_POST['sale_shipping_service'] ?? 'REG')),
            'notes'=>sanitize_textarea_field(wp_unslash($_POST['sale_notes'] ?? ''))
        ];
        if (!in_array($payload['payment_status'], ['unpaid','partial','paid'], true)) $payload['payment_status']='paid';
        try {
            if (!class_exists('PK01_Engine') || !method_exists('PK01_Engine','create_sale')) throw new Exception('Mesin transaksi penjualan PK01 tidak tersedia.');

            // Single source of truth: Kasir tidak lagi membuat Product Master baru.
            // Produk/SKU baru wajib dibuat di Master Data -> Produk & SKU terlebih dahulu,
            // lalu dipilih di transaksi. Ini mencegah duplikasi produk antar modul.
            if (!empty($_POST['sale_is_new_model'])) {
                throw new Exception('Produk/SKU baru harus dibuat terlebih dahulu di Master Data → Produk & SKU. Kasir hanya memilih SKU yang sudah ada di Product Master.');
            } else {
                $notice_model='';
            }
            $result=PK01_Engine::create_sale($payload);
            $order_no=$result['order_no']; $total_amount=(float)$result['total']; $payment_status=$result['payment_status']; $shipment_id=(int)($result['shipment_id']??0);
            $customer_name=$payload['customer_name']; $customer_phone=$payload['customer_phone'];
            $clean_wa_phone=preg_replace('/[^0-9]/','',(string)$customer_phone); if(strpos($clean_wa_phone,'0')===0)$clean_wa_phone='62'.substr($clean_wa_phone,1);
            $wa_msg=rawurlencode("Halo Kak {$customer_name}, terima kasih telah berbelanja! Pesanan Anda telah resmi terdaftar dengan No. Invoice: *{$order_no}*, Total: *Rp ".number_format($total_amount,0,',','.')."* (".strtoupper($payment_status)."). Kami akan segera memproses pesanan Anda.");
            $wa_btn=!empty($clean_wa_phone)?' <a href="https://wa.me/'.$clean_wa_phone.'?text='.$wa_msg.'" target="_blank" class="pk01-btn pk01-btn-wa" style="margin-left:8px;padding:4px 10px;font-size:12px;">💬 Kirim Nota via WhatsApp</a>':'';
            $notice='<div class="pk01-sal-alert is-success">✅ Transaksi penjualan <strong>'.esc_html($order_no).'</strong> senilai <b>Rp '.number_format($total_amount,0,',','.').'</b> berhasil dibukukan. Penjualan tersimpan di database PK01 dan otomatis masuk antrean pekerjaan fulfillment sesuai status pembayaran/stok.'.($notice_model??'').$wa_btn.'</div>';
            $_POST=[];
        } catch(Throwable $e) { $notice='<div class="pk01-sal-alert is-error">❌ Gagal membukukan penjualan: '.esc_html($e->getMessage()).'</div>'; }
    }
}


// 4B. SETORAN KASIR -> KEUANGAN. Setoran cash menunggu penerimaan Keuangan;
// transfer Seller hanya menjadi bukti jika pembayaran sudah tercatat di invoice.
$cashier_deposit_notice='';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_cashier_deposit_submit']) && $can_manage) {
    if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_cashier_deposit_nonce']??'')),'pk01_cashier_deposit_submit')){
        $cashier_deposit_notice='<div class="pk01-op-notice is-error">Sesi setoran tidak valid.</div>';
    } else {
        try{
            $type=sanitize_key($_POST['deposit_type']??'cash');
            $amount=(float)preg_replace('/[^0-9.]/','',str_replace(',','.',(string)($_POST['deposit_amount']??0)));
            $source=sanitize_text_field(wp_unslash($_POST['deposit_source_account']??'Kas Tunai Toko'));
            $dest=sanitize_text_field(wp_unslash($_POST['deposit_destination_account']??'Kas/Bank Keuangan'));
            $method=sanitize_text_field(wp_unslash($_POST['deposit_payment_method']??($type==='cash'?'Kas Tunai':'Transfer Bank')));
            $ref=sanitize_text_field(wp_unslash($_POST['deposit_reference_no']??''));
            $notes=sanitize_textarea_field(wp_unslash($_POST['deposit_notes']??''));
            $seller_id=absint($_POST['deposit_seller_id']??0); $invoice_id=absint($_POST['deposit_invoice_id']??0); $order_id=absint($_POST['deposit_order_id']??0);
            $r=PK01_Engine::submit_cashier_deposit($amount,$type,$source,$dest,$method,$ref,$notes,$seller_id,$invoice_id,$order_id);
            $cashier_deposit_notice='<div class="pk01-op-notice is-success">✅ Setoran <b>'.esc_html($r['deposit_no']).'</b> dibuat dan menunggu penerimaan Keuangan. '.($type==='cash'?'Kas belum dipindahkan sampai Keuangan menerima.':'Transfer tidak membukukan kas kedua; Keuangan hanya mengonfirmasi bukti.').'</div>';
        }catch(Throwable $e){$cashier_deposit_notice='<div class="pk01-op-notice is-error">❌ Setoran belum dicatat: '.esc_html($e->getMessage()).'</div>';}
    }
}

// 4B. PEMBAYARAN SELLER — satu pintu Kasir berdasarkan RESI atau SELLER.
// Pembayaran hanya melunasi invoice Seller yang sudah lahir dari order nyata.
$seller_payment_notice = '';
$seller_payment_results = [];
$seller_payment_query = sanitize_text_field(wp_unslash($_GET['seller_payment_q'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_seller_payment'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_seller_payment_nonce'] ?? '')), 'pk01_seller_payment_action')) {
        $seller_payment_notice = '<div class="pk01-sal-alert is-error">⚠️ Sesi pembayaran tidak valid.</div>';
    } elseif (!$can_manage) {
        $seller_payment_notice = '<div class="pk01-sal-alert is-error">Anda tidak memiliki izin memproses pembayaran Seller.</div>';
    } else {
        try {
            $invoice_id = absint($_POST['seller_invoice_id'] ?? 0);
            $amount = (float)preg_replace('/[^0-9.]/','',str_replace(',','.',(string)($_POST['seller_payment_amount'] ?? 0)));
            $method = sanitize_text_field(wp_unslash($_POST['seller_payment_method'] ?? 'Transfer Bank'));
            if ($invoice_id <= 0 || $amount <= 0) throw new Exception('Tagihan dan nominal pembayaran wajib diisi.');
            if(stripos($method,'transfer')===false && stripos($method,'qris')===false) throw new Exception('Pembayaran Seller melalui menu ini harus berupa transfer/QRIS agar dapat diverifikasi Keuangan. Untuk kas tunai gunakan setoran Kasir.');
            $r=PK01_Engine::submit_cashier_deposit($amount,'transfer','Bank Seller / Bukti Transfer','Kas/Bank Keuangan',$method,sanitize_text_field(wp_unslash($_POST['seller_payment_reference']??'')), 'Pembayaran Seller menunggu persetujuan Keuangan.',absint($_POST['seller_account_id']??0),$invoice_id,absint($_POST['seller_order_id']??0));
            $seller_payment_notice = '<div class="pk01-sal-alert is-success">📨 Permintaan pembayaran Seller <b>'.esc_html($r['deposit_no']).'</b> sebesar <b>Rp '.number_format($amount,0,',','.').'</b> dikirim ke Keuangan untuk verifikasi dan persetujuan. Invoice belum dilunasi sebelum diterima Keuangan.</div>';
        } catch (Throwable $e) {
            $seller_payment_notice = '<div class="pk01-sal-alert is-error">❌ Pembayaran belum dicatat: '.esc_html($e->getMessage()).'</div>';
        }
    }
}

// Pencarian dapat memakai nomor RESI/AWB, nomor invoice/order, kode/nama Seller.
if ($can_manage && class_exists('PK01_DB')) {
    $ti = PK01_DB::t('seller_invoices');
    $tp = PK01_DB::t('seller_payments');
    $tsa = PK01_DB::t('sales_accounts');
    $tso = PK01_DB::t('seller_orders');
    $tship = PK01_DB::t('shipments');
    $tss = PK01_DB::t('seller_sales');
    $rows = [];
    if ($seller_payment_query !== '') {
        $like = '%'.$wpdb->esc_like($seller_payment_query).'%';
        $sql = "SELECT i.*, s.name seller_name, s.code seller_code, s.phone seller_phone,
                       s.payment_term_days, s.payment_term_label,
                       COALESCE((SELECT SUM(p.amount) FROM `{$tp}` p WHERE p.invoice_id=i.id),0) total_paid,
                       so.order_no seller_order_no, so.marketplace_order_no, so.tracking_no seller_tracking,
                       ss.tracking_no sale_tracking
                FROM `{$ti}` i
                JOIN `{$tsa}` s ON s.id=i.seller_account_id
                LEFT JOIN `{$tso}` so ON so.id=i.order_id
                LEFT JOIN `{$tss}` ss ON ss.order_id=i.order_id AND ss.seller_account_id=i.seller_account_id
                WHERE i.total > 0 AND (
                    i.invoice_no LIKE %s OR s.name LIKE %s OR s.code LIKE %s OR
                    so.order_no LIKE %s OR so.marketplace_order_no LIKE %s OR so.tracking_no LIKE %s OR ss.tracking_no LIKE %s
                    OR EXISTS (SELECT 1 FROM `{$tship}` sh WHERE (sh.seller_sale_id=ss.id OR sh.seller_sale_id IN (SELECT id FROM `{$tss}` WHERE order_id=i.order_id)) AND sh.tracking_no LIKE %s)
                ) ORDER BY i.id DESC LIMIT 50";
        $rows = $wpdb->get_results($wpdb->prepare($sql,$like,$like,$like,$like,$like,$like,$like,$like),ARRAY_A) ?: [];
    } else {
        $rows = $wpdb->get_results("SELECT i.*, s.name seller_name, s.code seller_code, s.phone seller_phone,
                    s.payment_term_days, s.payment_term_label,
                    COALESCE((SELECT SUM(p.amount) FROM `{$tp}` p WHERE p.invoice_id=i.id),0) total_paid,
                    so.order_no seller_order_no, so.marketplace_order_no, so.tracking_no seller_tracking,
                    ss.tracking_no sale_tracking
                    FROM `{$ti}` i JOIN `{$tsa}` s ON s.id=i.seller_account_id
                    LEFT JOIN `{$tso}` so ON so.id=i.order_id
                    LEFT JOIN `{$tss}` ss ON ss.order_id=i.order_id AND ss.seller_account_id=i.seller_account_id
                    WHERE i.total > 0 AND i.status IN ('unpaid','partial') ORDER BY COALESCE(i.due_date,'9999-12-31') ASC,i.id DESC LIMIT 30",ARRAY_A) ?: [];
    }
    foreach ($rows as $r) {
        $r['remaining'] = max(0,(float)$r['total']-(float)$r['total_paid']);
        $r['status_calc'] = $r['remaining'] <= 0.01 ? 'paid' : ((float)$r['total_paid'] > 0 ? 'partial' : 'unpaid');
        $seller_payment_results[] = $r;
    }

// Invoice Seller yang sudah memiliki pembayaran nyata, untuk bukti transfer setoran.
$cashier_transfer_invoices=[];
if($can_manage && class_exists('PK01_DB')){
    $ti2=PK01_DB::t('seller_invoices'); $tp2=PK01_DB::t('seller_payments'); $sa2=PK01_DB::t('sales_accounts');
    if($ti2&&$tp2&&$sa2){$cashier_transfer_invoices=$wpdb->get_results("SELECT i.id,i.invoice_no,i.total,i.seller_account_id,s.name seller_name,COALESCE((SELECT SUM(p.amount) FROM `{$tp2}` p WHERE p.invoice_id=i.id),0) paid,COALESCE((SELECT SUM(d.amount) FROM `".PK01_DB::t('cashier_deposits')."` d WHERE d.invoice_id=i.id AND d.status IN ('submitted','approved')),0) pending FROM `{$ti2}` i JOIN `{$sa2}` s ON s.id=i.seller_account_id WHERE i.total>0 AND (i.status IS NULL OR i.status NOT IN ('paid','lunas')) AND (COALESCE((SELECT SUM(p.amount) FROM `{$tp2}` p WHERE p.invoice_id=i.id),0)+COALESCE((SELECT SUM(d.amount) FROM `".PK01_DB::t('cashier_deposits')."` d WHERE d.invoice_id=i.id AND d.status IN ('submitted','approved')),0)) < i.total ORDER BY i.id DESC LIMIT 50",ARRAY_A)?:[];}
}
}

// 5. STATISTIK REAL DARI DATABASE (NON-DUMMY)
$total_omzet_month = (float) $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(total_amount), 0) FROM `{$tbl_orders}` 
     WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s 
     AND status NOT IN ('cancelled', 'batal', 'failed')",
    $current_month
));

$order_count_month = (int) $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM `{$tbl_orders}` 
     WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s 
     AND status NOT IN ('cancelled', 'batal', 'failed')",
    $current_month
));

$pending_process_count = (int) $wpdb->get_var(
    "SELECT COUNT(*) FROM `{$tbl_orders}` 
     WHERE status IN ('processing', 'pending', 'paid', 'dikemas')"
);

$gross_profit_month = (float) $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(total_amount - (hpp * qty)), 0) FROM `{$tbl_orders}` 
     WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s 
     AND status NOT IN ('cancelled', 'batal', 'failed')",
    $current_month
));

$aov_month = $order_count_month > 0 ? ($total_omzet_month / $order_count_month) : 0;

// Distribusi Omzet per Kanal Penjualan (Real Omnichannel Share)
$channel_stats = $wpdb->get_results($wpdb->prepare(
    "SELECT channel, COALESCE(SUM(total_amount), 0) as total_omzet, COUNT(id) as total_orders 
     FROM `{$tbl_orders}` 
     WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal', 'failed')
     GROUP BY channel ORDER BY total_omzet DESC",
    $current_month
), ARRAY_A) ?: [];

// Master Varian & Seller untuk Form
$variants = [];
if ($tbl_variants) {
    $variants = $wpdb->get_results("SELECT id, sku, name, price, hpp, stock FROM `{$tbl_variants}` WHERE status = 'active' ORDER BY name ASC LIMIT 150", ARRAY_A) ?: [];
}

$sellers = [];
if ($tbl_sellers) {
    $sellers = $wpdb->get_results("SELECT id, code, name, commission_percent FROM `{$tbl_sellers}` WHERE active = 1 ORDER BY name ASC", ARRAY_A) ?: [];
}
?>

<style>
:root {
    --pk-sal-navy: #0f172a;
    --pk-sal-border: #e2e8f0;
    --pk-sal-green: #059669;
    --pk-sal-blue: #2563eb;
    --pk-sal-amber: #d97706;
    --pk-sal-purple: #7c3aed;
    --pk-sal-muted: #64748b;
}

.pk01-sales-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-sales-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-sal-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #064e3b 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-sal-eyebrow {
    display: inline-block;
    background: rgba(52, 211, 153, 0.15);
    color: #34d399;
    border: 1px solid rgba(52, 211, 153, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-sal-hero h1 { margin: 0 0 6px 0; font-size: 24px; font-weight: 800; color: #f8fafc; }
.pk01-sal-hero p { margin: 0; font-size: 13px; color: #cbd5e1; max-width: 820px; line-height: 1.5; }

/* 4 Executive KPI Cards */
.pk01-sal-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-sal-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; }
.pk01-kpi-card.c-green  { border-left-color: var(--pk-sal-green); }
.pk01-kpi-card.c-blue   { border-left-color: var(--pk-sal-blue); }
.pk01-kpi-card.c-amber  { border-left-color: var(--pk-sal-amber); }
.pk01-kpi-card.c-purple { border-left-color: var(--pk-sal-purple); }

.pk01-kpi-card small { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--pk-sal-muted); display: block; }
.pk01-kpi-card strong { font-size: 22px; font-weight: 800; display: block; margin: 6px 0 2px 0; }
.pk01-kpi-card span { font-size: 11px; color: var(--pk-sal-muted); }

/* Omnichannel Revenue Strip */
.pk01-channel-strip {
    background: #ffffff;
    border: 1px solid var(--pk-sal-border);
    border-radius: 14px;
    padding: 16px 20px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-channel-head { font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.8px; color: #64748b; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; }
.pk01-channel-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; }
.pk01-channel-pill { background: #f8fafc; border: 1px solid var(--pk-sal-border); border-radius: 10px; padding: 12px 14px; display: flex; flex-direction: column; gap: 2px; }
.pk01-channel-pill-top { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 700; color: #0f172a; }
.pk01-channel-pill strong { font-size: 15px; font-family: monospace; color: #047857; }

/* POS Split Layout */
.pk01-pos-split {
    display: grid;
    grid-template-columns: 1.45fr 0.95fr;
    gap: 24px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 960px) {
    .pk01-pos-split { grid-template-columns: 1fr; }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-sal-border);
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 { margin: 0; font-size: 17px; font-weight: 800; color: #0f172a; }

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item { display: flex; flex-direction: column; gap: 5px; }
.pk01-field-item label { font-size: 12px; font-weight: 700; color: #334155; }
.pk01-input { width: 100%; padding: 9px 13px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 13px; background: #f8fafc; color: #0f172a; }
.pk01-input:focus { outline: none; border-color: #2563eb; background: #ffffff; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15); }

/* Live POS Ticket & Handshake Indicators */
.pk01-pos-ticket {
    background: #ffffff;
    border: 1px solid var(--pk-sal-border);
    border-radius: 14px;
    padding: 22px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.03);
    position: sticky;
    top: 20px;
}
.pk01-ticket-title { font-size: 14px; font-weight: 800; color: #0f172a; border-bottom: 1px dashed #cbd5e1; padding-bottom: 10px; margin-bottom: 14px; display: flex; justify-content: space-between; align-items: center; }
.pk01-ticket-row { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
.pk01-handshake-status-box {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 12px 14px;
    margin-top: 14px;
    font-size: 11px;
    color: #475569;
    line-height: 1.5;
}

/* Action Buttons & Alerts */
.pk01-btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; border: none; text-decoration: none !important; }
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-wa { background: #25d366; color: #fff !important; }

.pk01-sal-alert { padding: 12px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; margin-bottom: 20px; }
.pk01-sal-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-sal-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-sales-cockpit">
    
    <?php if ($can_manage): ?>
<section style="margin-bottom:18px;border:1px solid #e2e8f0;border-radius:14px;background:#fff;padding:18px;">
<div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;"><div><span style="font-size:10px;font-weight:800;color:#2563eb;letter-spacing:.08em;">ORDER SELLER MASUK</span><h3 style="margin:4px 0;">Kasir menerima order dari Dashboard Seller</h3><p style="margin:0;color:#64748b;font-size:12px;">SKU PK01 adalah sumber kebenaran barang. Resi hanya referensi pengiriman dan boleh menyusul.</p></div><span style="padding:7px 10px;border-radius:9px;background:#eff6ff;color:#1d4ed8;font-weight:800;font-size:12px;"><?php echo count($seller_pending_orders); ?> menunggu</span></div>
<?php echo $seller_order_notice; ?>
<div style="overflow:auto;margin-top:12px;"><table style="width:100%;border-collapse:collapse;font-size:12px;"><thead><tr><th>Order</th><th>Seller</th><th>Marketplace</th><th>Produk PK01</th><th>Resi</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($seller_pending_orders as $so): ?><tr><td><b><?php echo esc_html($so['order_no']); ?></b><small style="display:block;color:#64748b;"><?php echo esc_html($so['marketplace_order_no']?:'-'); ?></small></td><td><?php echo esc_html($so['seller_name']); ?></td><td><?php echo esc_html(ucwords(str_replace('_',' ',$so['marketplace']?:'marketplace'))); ?></td><td><?php echo esc_html($so['item_summary']?:'-'); ?></td><td style="font-family:monospace;"><?php echo esc_html($so['tracking_no']?:'Belum ada'); ?></td><td><strong><?php echo esc_html(str_replace('_',' ', $so['status'])); ?></strong></td><td><?php if($so['status']==='requested'): ?><form method="post"><?php echo wp_nonce_field('pk01_accept_seller_order','pk01_seller_order_nonce',true,false); ?><input type="hidden" name="pk01_accept_seller_order" value="1"><input type="hidden" name="seller_order_id" value="<?php echo (int)$so['id']; ?>"><button class="button button-primary" type="submit">Terima Order</button></form><?php elseif(in_array($so['status'],['awaiting_production','awaiting_purchase'],true)): ?><form method="post"><?php echo wp_nonce_field('pk01_resume_seller_order','pk01_resume_seller_order_nonce',true,false); ?><input type="hidden" name="pk01_resume_seller_order" value="1"><input type="hidden" name="seller_order_id" value="<?php echo (int)$so['id']; ?>"><button class="button" type="submit">Cek &amp; Lanjutkan</button></form><?php endif; ?></td></tr><?php endforeach; if(!$seller_pending_orders): ?><tr><td colspan="7" style="padding:24px;text-align:center;color:#94a3b8;">Tidak ada order Seller yang menunggu Kasir.</td></tr><?php endif; ?></tbody></table></div>
</section>
<?php endif; ?>

<!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-sal-hero">
        <div>
            <span class="pk01-sal-eyebrow">OMNICHANNEL SALES &bull; POS &amp; INTERCONNECTED DESK</span>
            <h1>Penjualan &amp; Kasir Pesanan Seluruh Channel</h1>
            <p>
                Bukukan transaksi kasir dari Toko Online, WhatsApp, Mitra Seller, atau Toko Fisik. 
                Sistem secara otomatis menghubungkan pesanan ke <strong>Gudang Stok, Antrean Packing, Buku Kas, Piutang, dan Komisi Seller</strong> secara simultan.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_sales_nonce'); ?>
                <input type="hidden" name="pk01_export_sales_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Transaksi (.CSV)
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-sal-kpis">
        <div class="pk01-kpi-card c-green">
            <small>Omzet Penjualan (Bulan Ini)</small>
            <strong style="color:#065f46;">Rp <?php echo number_format($total_omzet_month, 0, ',', '.'); ?></strong>
            <span><?php echo (int)$order_count_month; ?> transaksi pesanan berhasil</span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Estimasi Laba Kotor (HPP)</small>
            <strong style="color:#1d4ed8;">Rp <?php echo number_format($gross_profit_month, 0, ',', '.'); ?></strong>
            <span>Omzet dikurangi modal pokok produk</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Pesanan Perlu Diproses</small>
            <strong style="color:#d97706;"><?php echo (int)$pending_process_count; ?> <span style="font-size:13px;font-weight:normal;">Order</span></strong>
            <span>Menunggu pengemasan / kirim resi</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Rata-rata Nilai Order (AOV)</small>
            <strong style="color:#7c3aed;">Rp <?php echo number_format($aov_month, 0, ',', '.'); ?></strong>
            <span>Rata-rata belanja per transaksi</span>
        </div>
    </div>

    <!-- 3. REAL BREAKDOWN: KONTRIBUSI KANAL PENJUALAN -->
    <?php if (!empty($channel_stats)): ?>
    <section class="pk01-channel-strip">
        <div class="pk01-channel-head">
            <span>🌐 Kontribusi Omzet per Saluran Penjualan (Bulan Ini):</span>
            <span>Total Saluran Aktif: <?php echo count($channel_stats); ?></span>
        </div>
        <div class="pk01-channel-grid">
            <?php foreach ($channel_stats as $cs): 
                $ch_label = ucfirst($cs['channel']);
                $share_pct = ($total_omzet_month > 0) ? round(($cs['total_omzet'] / $total_omzet_month) * 100, 1) : 0;
            ?>
                <div class="pk01-channel-pill">
                    <div class="pk01-channel-pill-top">
                        <span><?php echo esc_html($ch_label); ?> (<?php echo (int)$cs['total_orders']; ?>x)</span>
                        <span style="font-size:11px;color:#2563eb;font-weight:700;"><?php echo $share_pct; ?>%</span>
                    </div>
                    <strong>Rp <?php echo number_format((float)$cs['total_omzet'], 0, ',', '.'); ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>


    <!-- 4B. TAB PEMBAYARAN SELLER -->
    <section class="pk01-surface" style="margin-top:18px;">
      <div class="pk01-surface-head"><h3>💳 Pembayaran Seller</h3><span style="font-size:12px;color:#64748b">Cari berdasarkan Resi / AWB, Invoice, Order, atau Seller</span></div>
      <?php echo $seller_payment_notice; ?>
      <form method="get" style="display:grid;grid-template-columns:minmax(260px,1fr) auto;gap:10px;margin:12px 0;">
        <?php foreach ($_GET as $k=>$v) if ($k!=='seller_payment_q') echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr(is_scalar($v)?$v:'').'">'; ?>
        <input type="search" name="seller_payment_q" value="<?php echo esc_attr($seller_payment_query); ?>" class="pk01-input" placeholder="Scan / ketik RESI atau nama/kode Seller / nomor invoice...">
        <button class="pk01-btn pk01-btn-primary" type="submit">🔎 Cari Tagihan</button>
      </form>
      <div style="font-size:12px;color:#64748b;margin-bottom:10px;">Alur: <b>Seller terdaftar → Order nyata → Invoice Seller → jatuh tempo sesuai termin → Kasir mengajukan pembayaran → Keuangan menyetujui → Keuangan menerima → AR dan Buku Kas dibukukan satu kali.</b> Resi hanya dipakai untuk menemukan order, bukan membuat tagihan baru.</div>
      <div style="overflow:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:12px;">
          <thead><tr><th style="text-align:left;padding:9px;background:#f8fafc;">Invoice / Order</th><th style="text-align:left;padding:9px;background:#f8fafc;">Seller</th><th style="text-align:left;padding:9px;background:#f8fafc;">Resi</th><th style="text-align:left;padding:9px;background:#f8fafc;">Termin</th><th style="text-align:right;padding:9px;background:#f8fafc;">Tagihan</th><th style="text-align:right;padding:9px;background:#f8fafc;">Sisa</th><th style="text-align:left;padding:9px;background:#f8fafc;">Status</th><th style="text-align:left;padding:9px;background:#f8fafc;">Bayar</th></tr></thead>
          <tbody>
          <?php foreach ($seller_payment_results as $r): ?>
            <?php $due = $r['due_date'] ?: '-'; $term = $r['payment_term_label'] ?: ((int)($r['payment_term_days']??0) > 0 ? ((int)$r['payment_term_days'].' Hari') : 'Langsung / COD'); ?>
            <tr>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($r['invoice_no'] ?: '-'); ?></b><small style="display:block;color:#64748b;"><?php echo esc_html($r['seller_order_no'] ?: ('Order #'.(int)$r['order_id'])); ?></small></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($r['seller_name']); ?></b><small style="display:block;color:#64748b;"><?php echo esc_html($r['seller_code']); ?></small></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;font-family:monospace;"><?php echo esc_html($r['seller_tracking'] ?: ($r['sale_tracking'] ?: '-')); ?></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php echo esc_html($term); ?><small style="display:block;color:#64748b;">Jatuh tempo: <?php echo esc_html($due); ?></small></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;text-align:right;">Rp <?php echo esc_html(number_format((float)$r['total'],0,',','.')); ?></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;text-align:right;font-weight:800;">Rp <?php echo esc_html(number_format((float)$r['remaining'],0,',','.')); ?></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;"><span class="pk01-badge <?php echo $r['status_calc']==='paid'?'badge-success':'badge-warning'; ?>"><?php echo esc_html(strtoupper($r['status_calc'])); ?></span></td>
              <td style="padding:9px;border-bottom:1px solid #eef2f7;min-width:270px;">
                <?php if ($r['remaining'] > 0.01): ?>
                <form method="post" style="display:grid;grid-template-columns:1fr 130px auto;gap:6px;align-items:center;">
                  <?php echo wp_nonce_field('pk01_seller_payment_action','pk01_seller_payment_nonce',true,false); ?><input type="hidden" name="pk01_seller_payment" value="1"><input type="hidden" name="seller_invoice_id" value="<?php echo (int)$r['id']; ?>"><input type="hidden" name="seller_account_id" value="<?php echo (int)$r['seller_account_id']; ?>"><input type="hidden" name="seller_order_id" value="<?php echo (int)($r['order_id']??0); ?>">
                  <input type="number" name="seller_payment_amount" step="0.01" min="0.01" max="<?php echo esc_attr($r['remaining']); ?>" value="<?php echo esc_attr($r['remaining']); ?>" class="pk01-input" title="Nominal pembayaran">
                  <select name="seller_payment_method" class="pk01-input"><option>Transfer Bank</option><option>QRIS</option></select><input type="text" name="seller_payment_reference" class="pk01-input" placeholder="Ref transfer wajib">
                  <button type="submit" class="pk01-btn pk01-btn-primary" onclick="return confirm('Kirim pembayaran Seller ini ke Keuangan untuk persetujuan?');">Ajukan</button>
                </form>
                <?php else: ?><span style="color:#059669;font-weight:700;">✓ Lunas</span><?php endif; ?>
              </td>
            </tr>
          <?php endforeach; if (!$seller_payment_results): ?><tr><td colspan="8" style="padding:24px;text-align:center;color:#94a3b8;">Belum ada tagihan Seller terbuka. Cari dengan Resi/AWB atau Seller untuk melihat tagihan.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- 4. IMPORT RESI MASSAL -->
    <?php if ($can_manage): ?>
    <section class="pk01-surface" style="margin-bottom:18px">
      <div class="pk01-surface-head"><h3>📥 Upload Resi Massal dari Excel</h3><span style="font-size:12px;color:#64748b">CSV UTF-8 • Pengiriman/Gudang/Laporan • AWB wajib berasal dari marketplace/kurir</span></div>
      <form method="post" enctype="multipart/form-data" style="display:grid;grid-template-columns:1fr auto;gap:12px;align-items:end">
        <?php echo wp_nonce_field('pk01_resi_import_action','pk01_resi_import_nonce',true,false); ?><input type="hidden" name="pk01_import_resi_csv" value="1">
        <div><label style="display:block;font-weight:700;font-size:12px;margin-bottom:5px">File CSV dari Excel</label><input type="file" name="pk01_resi_file" accept=".csv,text/csv" required style="width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:8px"></div>
        <button class="pk01-btn pk01-btn-primary" type="submit">📦 Import Resi &amp; Buat Record Gudang</button>
      </form>
      <div style="margin-top:9px;font-size:12px;color:#64748b"><b>Format sederhana:</b> <code>resi,courier,service,order_no</code>. <b>resi wajib</b>; <b>order_no opsional</b> bila resi sudah tersimpan pada order. PK01 tidak membuat AWB palsu. Sistem hanya menghubungkan resi yang diberikan marketplace/kurir ke order nyata, lalu membuat record shipment + barcode internal untuk Gudang. Excel: <b>Save As → CSV UTF-8</b>.</div>
    </section>
    <?php endif; ?>

    <!-- 5. POS SPLIT: FORM INPUT & LIVE PROFIT TICKETING -->
    <?php if ($can_manage): ?>
    <div class="pk01-pos-split">
        
        <!-- FORM INPUT PENJUALAN -->
        <div class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>🛍️ Input Transaksi Kasir / Pesanan Baru</h3>
            </div>

            <form method="post" action="" id="pk01-pos-form" enctype="multipart/form-data">
                <?php echo wp_nonce_field('pk01_sale_create_action', 'pk01_sale_nonce', true, false); ?>
                <input type="hidden" name="pk01_create_sale" value="1">

                <div class="pk01-form-grid">
                    <div class="pk01-field-item">
                        <label>Saluran Penjualan (Channel) <span style="color:#dc2626;">*</span></label>
                        <select name="sale_channel" class="pk01-input" required>
                            <option value="website">Website / Toko Online</option>
                            <option value="whatsapp">WhatsApp / Chat Langsung</option>
                            <option value="seller">Mitra Seller / Afiliasi</option>
                            <option value="marketplace">Marketplace (Shopee / Tokopedia)</option>
                            <option value="workshop">Toko Fisik / Workshop</option>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Tautkan Mitra Seller (Otomatis Komisi &amp; Target)</label>
                        <select name="sale_seller_id" id="pk01-sale-seller" class="pk01-input">
                            <option value="0" data-comm="0">— Tanpa Mitra Seller —</option>
                            <?php foreach ($sellers as $s): ?>
                                <option value="<?php echo (int)$s['id']; ?>" data-comm="<?php echo (float)$s['commission_percent']; ?>">
                                    <?php echo esc_html($s['code'] . ' — ' . $s['name']); ?> (Komisi: <?php echo (float)$s['commission_percent']; ?>%)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Nomor Resi / AWB (Opsional — laporan pengiriman)</label>
                        <input type="text" name="sale_tracking_no" class="pk01-input" placeholder="Scan / masukkan resi asli dari kurir">
                    </div>
                    <div class="pk01-field-item">
                        <label>Kurir</label>
                        <select name="sale_courier" class="pk01-input">
                            <option value="">— Pilih kurir —</option><option value="jne">JNE</option><option value="jnt">J&amp;T Express</option><option value="sicepat">SiCepat</option><option value="spx">SPX Express</option><option value="anteraja">AnterAja</option><option value="ninja">Ninja Xpress</option><option value="tiki">TIKI</option><option value="pos">POS Indonesia</option><option value="jne_trucking">JNE Trucking</option><option value="jnt_cargo">J&amp;T Cargo</option><option value="wahana_cargo">Wahana Cargo</option><option value="pos_cargo">Pos Indonesia Cargo</option>
                        </select>
                    </div>
                    <div class="pk01-field-item" style="grid-column:1/-1"><div style="padding:9px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;font-size:12px;color:#1e40af"><b>Penting:</b> Resi hanya menghubungkan Penjualan → Gudang → Pengiriman → Laporan. Resi tidak menentukan harga, pembayaran, atau tagihan.</div></div>

                    <div class="pk01-field-item">
                        <label>Nama Lengkap Pelanggan <span style="color:#dc2626;">*</span></label>
                        <input type="text" name="sale_customer_name" class="pk01-input" required placeholder="Contoh: Ibu Rina Hartono">
                    </div>

                    <div class="pk01-field-item">
                        <label>No. WhatsApp Pelanggan</label>
                        <input type="tel" name="sale_customer_phone" class="pk01-input" placeholder="08xxxxxxxxxx">
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>Pilih Produk / Varian (Dari Master Gudang) <span style="color:#dc2626;">*</span></label>
                        <select name="sale_variant_id" id="pk01-sale-product-select" class="pk01-input">
                            <option value="0" data-price="0" data-hpp="0" data-stock="9999">— Produk Kustom / Ketik Manual —</option>
                            <?php foreach ($variants as $v): ?>
                                <option value="<?php echo (int)$v['id']; ?>" 
                                        data-price="<?php echo esc_attr($v['price'] ?? 0); ?>" 
                                        data-hpp="<?php echo esc_attr($v['hpp'] ?? 0); ?>" 
                                        data-stock="<?php echo esc_attr($v['stock'] ?? 0); ?>">
                                    [<?php echo esc_html($v['sku']); ?>] <?php echo esc_html($v['name']); ?> (Stok: <?php echo esc_html($v['stock'] ?? 0); ?> | Rp <?php echo number_format((float)($v['price'] ?? 0), 0, ',', '.'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-field-item" style="grid-column:1/-1;margin-top:4px;padding:14px;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px">
                        <label style="display:flex;gap:8px;align-items:center;font-weight:800"><input type="checkbox" name="sale_is_new_model" id="pk01-sale-new-model" value="1"> MODEL BARU — belum pernah diproduksi / belum ada di Master PK01</label>
                        <div id="pk01-new-model-panel" style="display:none;margin-top:12px">
                            <div style="padding:10px 12px;background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;font-size:12px;color:#9a3412;margin-bottom:12px"><b>WAJIB:</b> Kasir harus memberikan identitas model, ukuran, Gambar Produk, dan Gambar Kerja. Jika metode produksi CNC dipilih, File CNC juga wajib. Setelah disimpan, data ini menjadi Master PK01 dan dipakai Produksi sebagai acuan.</div>
                            <div class="pk01-form-grid">
                                <div class="pk01-field-item"><label>Nama Model *</label><input name="new_model_name" class="pk01-input" placeholder="Contoh: KAZE NEW 120"></div>
                                <div class="pk01-field-item"><label>Kode Produk *</label><input name="new_model_code" class="pk01-input" placeholder="PRD-KAZE-NEW"></div>
                                <div class="pk01-field-item"><label>SKU PK01 *</label><input name="new_model_sku" class="pk01-input" placeholder="KAZE-NEW-120"></div>
                                <div class="pk01-field-item"><label>Material *</label><input name="new_model_material" class="pk01-input" placeholder="Multipleks 18 mm"></div>
                                <div class="pk01-field-item"><label>Finishing</label><input name="new_model_finishing" class="pk01-input" placeholder="HPL / Cat"></div>
                                <div class="pk01-field-item"><label>Metode Produksi *</label><select name="new_model_method" id="pk01-new-model-method" class="pk01-input"><option value="manual">Manual / Non-CNC</option><option value="cnc">CNC</option></select></div>
                                <div class="pk01-field-item"><label>Panjang *</label><input type="number" min="0.001" step="0.001" name="new_model_length" class="pk01-input"></div>
                                <div class="pk01-field-item"><label>Lebar *</label><input type="number" min="0.001" step="0.001" name="new_model_width" class="pk01-input"></div>
                                <div class="pk01-field-item"><label>Tinggi *</label><input type="number" min="0.001" step="0.001" name="new_model_height" class="pk01-input"></div>
                                <div class="pk01-field-item"><label>Tebal</label><input type="number" min="0" step="0.001" name="new_model_thickness" class="pk01-input"></div>
                                <div class="pk01-field-item"><label>Satuan</label><select name="new_model_unit" class="pk01-input"><option value="cm">cm</option><option value="mm">mm</option><option value="m">m</option></select></div>
                                <div class="pk01-field-item"><label>HPP Awal (opsional)</label><input type="number" min="0" step="0.01" name="new_model_hpp" class="pk01-input" value="0"></div>
                                <div class="pk01-field-item"><label>Gambar Produk *</label><input type="file" name="new_model_image" accept="image/jpeg,image/png,image/webp" class="pk01-input"></div>
                                <div class="pk01-field-item"><label>Gambar Kerja / Drawing *</label><input type="file" name="new_model_drawing" accept="image/jpeg,image/png,image/webp,application/pdf" class="pk01-input"></div>
                                <div class="pk01-field-item" id="pk01-cnc-file-wrap" style="display:none"><label>File CNC *</label><input type="file" name="new_model_cnc" accept=".nc,.gcode,.tap,.txt,.dxf" class="pk01-input"></div>
                            </div>
                        </div>
                    </div>

                    <div class="pk01-field-item">
                        <label>Jumlah Beli (Qty) <span style="color:#dc2626;">*</span></label>
                        <input type="number" step="any" min="1" name="sale_qty" id="pk01-sale-qty" class="pk01-input" value="1" required>
                    </div>

                    <div class="pk01-field-item">
                        <label>Harga Satuan (Rp) <span style="color:#dc2626;">*</span></label>
                        <input type="number" step="any" min="0" name="sale_price" id="pk01-sale-price" class="pk01-input" placeholder="Contoh: 250000" required>
                    </div>

                    <div class="pk01-field-item">
                        <label>Metode Pembayaran <span style="color:#dc2626;">*</span></label>
                        <select name="sale_payment_method" class="pk01-input">
                            <option value="Transfer Bank BCA">Transfer Bank BCA</option>
                            <option value="Transfer Bank Mandiri">Transfer Bank Mandiri</option>
                            <option value="Transfer Bank BRI">Transfer Bank BRI</option>
                            <option value="Kas Tunai / COD">Kas Tunai / COD</option>
                            <option value="QRIS / E-Wallet">QRIS / E-Wallet</option>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Status Pembayaran <span style="color:#dc2626;">*</span></label>
                        <select name="sale_payment_status" id="pk01-sale-payment-status" class="pk01-input" style="font-weight:700;">
                            <option value="paid">Lunas — Uang Masuk ke Buku Kas</option>
                            <option value="partial">DP / Sebagian — Sebagian Kas, Sisa Piutang</option>
                            <option value="unpaid">Belum Bayar — Tanpa Mutasi Kas Masuk</option>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Nominal Dibayar / Uang Muka DP (Rp)</label>
                        <input type="number" step="any" min="0" name="sale_paid_amount" id="pk01-sale-paid-amount" class="pk01-input" value="0">
                    </div>

                    <div class="pk01-field-item">
                        <label>Status Pesanan</label>
                        <select name="sale_status" class="pk01-input">
                            <option value="processing">🟢 Siap Diproses / Antrean Packing</option>
                            <option value="pending">⏳ Menunggu Pembayaran</option>
                            <option value="completed">✅ Selesai Diterima</option>
                        </select>
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>Alamat Pengiriman Lengkap (Otomatis ke Surat Jalan)</label>
                        <textarea name="sale_shipping_address" rows="2" class="pk01-input" placeholder="Jalan, RT/RW, Kelurahan, Kecamatan, Kota, Kode Pos..."></textarea>
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>Catatan Pesanan / Request Khusus</label>
                        <input type="text" name="sale_notes" class="pk01-input" placeholder="Contoh: Finishing Natural Glossy, kirim hari Sabtu">
                    </div>

                    <div style="grid-column: 1 / -1; margin-top: 6px;">
                        <button class="pk01-btn pk01-btn-primary" type="submit" style="width:100%;justify-content:center;padding:12px;">
                            💾 Bukukan Penjualan &amp; Sinkronkan ke Sistem
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- LIVE POS TICKET SIMULATOR & JABAT TANGAN MODUL -->
        <aside class="pk01-pos-ticket">
            <div class="pk01-ticket-title">
                <span>🧾 Ringkasan Penjualan &amp; Integrasi</span>
                <span style="font-size:11px;color:#059669;font-weight:700;">Live Engine</span>
            </div>

            <div class="pk01-ticket-row">
                <span>Total Belanja Produk:</span>
                <strong id="tick_total" style="font-size:16px;font-family:monospace;color:#0f172a;">Rp 0</strong>
            </div>

            <div class="pk01-ticket-row">
                <span>Modal Pokok (HPP):</span>
                <strong id="tick_hpp" style="color:#b45309;font-family:monospace;">Rp 0</strong>
            </div>

            <div class="pk01-ticket-row">
                <span>Estimasi Laba Kotor:</span>
                <strong id="tick_profit" style="color:#059669;font-family:monospace;">Rp 0 (0%)</strong>
            </div>

            <div class="pk01-ticket-row">
                <span>Komisi Mitra Seller:</span>
                <strong id="tick_comm" style="color:#7c3aed;font-family:monospace;">Rp 0</strong>
            </div>

            <div class="pk01-ticket-row">
                <span>Uang Masuk ke Buku Kas:</span>
                <strong id="tick_paid" style="color:#1d4ed8;font-family:monospace;">Rp 0</strong>
            </div>

            <div class="pk01-ticket-row" id="tick_receivable_row" style="display:none;color:#dc2626;">
                <span>Sisa Piutang Tertagih:</span>
                <strong id="tick_receivable" style="font-family:monospace;">Rp 0</strong>
            </div>

            <!-- JABAT TANGAN MODUL STATUS -->
            <div class="pk01-handshake-status-box">
                <strong style="display:block;color:#0f172a;margin-bottom:6px;">🤝 Status Sinkronisasi Antar-Modul:</strong>
                <div>📦 <b>Gudang:</b> <span id="tick_stock_status">Pilih produk untuk cek stok</span></div>
                <div>🎁 <b>Packing:</b> <span id="tick_packing_status">Otomatis masuk antrean jika LUNAS</span></div>
                <div>💵 <b>Buku Kas:</b> <span id="tick_cash_status">Otomatis tercatat kas masuk</span></div>
            </div>
        </aside>

    </div>
    <?php endif; ?>

</div>

<!-- LIVE JAVASCRIPT POS & HANDSHAKE SIMULATOR -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var pSelect      = document.getElementById('pk01-sale-product-select'),
        qtyInput     = document.getElementById('pk01-sale-qty'),
        priceInput   = document.getElementById('pk01-sale-price'),
        payStatus    = document.getElementById('pk01-sale-payment-status'),
        paidInput    = document.getElementById('pk01-sale-paid-amount'),
        sellerSelect = document.getElementById('pk01-sale-seller');

    var tickTotal      = document.getElementById('tick_total'),
        tickHpp        = document.getElementById('tick_hpp'),
        tickProfit     = document.getElementById('tick_profit'),
        tickComm       = document.getElementById('tick_comm'),
        tickPaid       = document.getElementById('tick_paid'),
        tickRecRow     = document.getElementById('tick_receivable_row'),
        tickRec        = document.getElementById('tick_receivable'),
        tickStock      = document.getElementById('tick_stock_status'),
        tickPacking    = document.getElementById('tick_packing_status'),
        tickCash       = document.getElementById('tick_cash_status');

    var currentHpp = 0;
    var currentStock = 9999;

    function formatRp(n) {
        return 'Rp ' + Math.round(n || 0).toLocaleString('id-ID');
    }

    var newModelCheck=document.getElementById('pk01-sale-new-model'), newModelPanel=document.getElementById('pk01-new-model-panel'), newModelMethod=document.getElementById('pk01-new-model-method'), cncWrap=document.getElementById('pk01-cnc-file-wrap'), productSelect=document.getElementById('pk01-sale-product-select');
    function toggleNewModel(){
        var on=!!(newModelCheck&&newModelCheck.checked);
        if(newModelPanel)newModelPanel.style.display=on?'block':'none';
        if(productSelect){productSelect.disabled=on; if(on)productSelect.value='0'; else productSelect.disabled=false;}
        if(cncWrap)cncWrap.style.display=(on&&newModelMethod&&newModelMethod.value==='cnc')?'block':'none';
        if(newModelPanel) newModelPanel.querySelectorAll('input,select').forEach(function(el){ if(el.name!=='new_model_hpp') el.required=on; });
        calculatePOS();
    }
    if(newModelCheck)newModelCheck.addEventListener('change',toggleNewModel);
    if(newModelMethod)newModelMethod.addEventListener('change',toggleNewModel);

    function calculatePOS() {
        var q = parseFloat(qtyInput ? qtyInput.value : 1) || 1;
        var p = parseFloat(priceInput ? priceInput.value : 0) || 0;
        var total = q * p;
        var hppTotal = currentHpp * q;
        var profit = total - hppTotal;
        var marginPct = total > 0 ? ((profit / total) * 100).toFixed(1) : 0;

        // Komisi Seller
        var commPct = 0;
        if (sellerSelect && sellerSelect.selectedOptions[0]) {
            commPct = parseFloat(sellerSelect.selectedOptions[0].getAttribute('data-comm')) || 0;
        }
        var commTotal = (total * commPct) / 100;

        // Status Pembayaran & Kas
        var pStatus = payStatus ? payStatus.value : 'paid';
        var paid = 0;

        if (pStatus === 'paid') {
            paid = total;
            if (paidInput) {
                paidInput.value = total;
                paidInput.disabled = true;
            }
            if (tickPacking) tickPacking.innerHTML = '<span style="color:#059669;font-weight:700;">✓ Langsung Masuk Antrean Packing</span>';
            if (tickCash) tickCash.innerHTML = '<span style="color:#059669;font-weight:700;">✓ Kas bertambah ' + formatRp(total) + '</span>';
        } else if (pStatus === 'unpaid') {
            paid = 0;
            if (paidInput) {
                paidInput.value = 0;
                paidInput.disabled = true;
            }
            if (tickPacking) tickPacking.innerHTML = '<span style="color:#d97706;font-weight:700;">⏳ Ditahan (Menunggu Bayar)</span>';
            if (tickCash) tickCash.innerHTML = '<span style="color:#64748b;">Tanpa kas masuk (Rp 0)</span>';
        } else {
            if (paidInput) {
                paidInput.disabled = false;
                paid = parseFloat(paidInput.value) || 0;
            }
            if (tickPacking) tickPacking.innerHTML = '<span style="color:#d97706;font-weight:700;">DP Diterima (Antrean Sesuai Kebijakan)</span>';
            if (tickCash) tickCash.innerHTML = '<span style="color:#059669;font-weight:700;">✓ Kas bertambah DP ' + formatRp(paid) + '</span>';
        }

        var receivable = Math.max(0, total - paid);

        // Update Ticket Simulator
        if (tickTotal)  tickTotal.textContent  = formatRp(total);
        if (tickHpp)    tickHpp.textContent    = formatRp(hppTotal);
        if (tickProfit) tickProfit.textContent = formatRp(profit) + ' (' + marginPct + '%)';
        if (tickComm)   tickComm.textContent   = formatRp(commTotal);
        if (tickPaid)   tickPaid.textContent   = formatRp(paid);

        if (tickRecRow && tickRec) {
            if (pStatus === 'partial' && receivable > 0) {
                tickRecRow.style.display = 'flex';
                tickRec.textContent = formatRp(receivable);
            } else {
                tickRecRow.style.display = 'none';
            }
        }

        // Cek Ketersediaan Stok Fisik
        if (tickStock) {
            if (pSelect && pSelect.value !== '0') {
                if (currentStock >= q) {
                    tickStock.innerHTML = '<span style="color:#059669;font-weight:700;">✓ Stok Cukup (' + currentStock + ' ' + (currentStock - q >= 0 ? '&rarr; Sisa ' + (currentStock - q) : '') + ')</span>';
                } else {
                    tickStock.innerHTML = '<span style="color:#dc2626;font-weight:700;">⚠️ Stok Kurang! (Tersedia: ' + currentStock + ')</span>';
                }
            } else {
                tickStock.innerHTML = '<span style="color:#2563eb;">Produk kustom (Stok fleksibel)</span>';
            }
        }
    }

    if (pSelect) {
        pSelect.addEventListener('change', function() {
            var opt = this.options[this.selectedIndex];
            var price = opt.getAttribute('data-price');
            currentHpp   = parseFloat(opt.getAttribute('data-hpp')) || 0;
            currentStock = parseFloat(opt.getAttribute('data-stock')) || 0;

            if (price && parseFloat(price) > 0 && priceInput) {
                priceInput.value = parseFloat(price);
            }
            calculatePOS();
        });
    }

    [qtyInput, priceInput, paidInput].forEach(function(el) {
        if (el) el.addEventListener('input', calculatePOS);
    });

    if (payStatus) {
        payStatus.addEventListener('change', calculatePOS);
    }

    if (sellerSelect) {
        sellerSelect.addEventListener('change', calculatePOS);
    }

    calculatePOS();
});
</script>

<?php
// 6. MONITOR FULFILLMENT — KASIR HANYA MEMANTAU, BUKAN MEMPROSES BARANG FISIK.
if (class_exists('PK01_Operational_Flow')):
    $monitor_orders = PK01_Operational_Flow::monitor_orders(25);
?>
<div style="margin:22px 0;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:18px;">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
        <div><h3 style="margin:0 0 4px;">📦 Pantauan Order & Fulfillment</h3><p style="margin:0;color:#64748b;font-size:12px;">Kasir cukup memastikan penjualan berhasil. Setelah itu status berubah otomatis dari pembayaran → packing → resi → kurir → pelanggan → retur bila ada.</p></div>
        <span style="font-size:11px;font-weight:800;color:#2563eb;background:#eff6ff;padding:6px 9px;border-radius:20px;">READ ONLY</span>
    </div>
    <div style="overflow:auto;margin-top:14px;">
        <table style="width:100%;border-collapse:collapse;font-size:12px;">
            <thead><tr><th style="text-align:left;padding:9px;background:#f8fafc;">Order</th><th style="text-align:left;padding:9px;background:#f8fafc;">Pelanggan</th><th style="text-align:left;padding:9px;background:#f8fafc;">Pembayaran</th><th style="text-align:left;padding:9px;background:#f8fafc;">Fulfillment</th><th style="text-align:left;padding:9px;background:#f8fafc;">Resi</th><th style="text-align:left;padding:9px;background:#f8fafc;">Retur</th></tr></thead>
            <tbody>
            <?php if (empty($monitor_orders)): ?>
                <tr><td colspan="6" style="padding:16px;text-align:center;color:#94a3b8;">Belum ada order penjualan.</td></tr>
            <?php else: foreach ($monitor_orders as $mo): ?>
                <tr>
                    <td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($mo['order_no']); ?></b></td>
                    <td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php echo esc_html($mo['customer_name']); ?></td>
                    <td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php echo esc_html(strtoupper($mo['payment_status'] ?: '-')); ?></td>
                    <td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html(PK01_Operational_Flow::status_label($mo['shipping_status'] ?: $mo['status'])); ?></b></td>
                    <td style="padding:9px;border-bottom:1px solid #eef2f7;font-family:monospace;"><?php echo esc_html($mo['tracking_no'] ?: '-'); ?><?php if (!empty($mo['courier'])): ?><br><span style="color:#64748b;"><?php echo esc_html(strtoupper($mo['courier'])); ?></span><?php endif; ?></td>
                    <td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php echo esc_html($mo['return_no'] ? ($mo['return_status'] ?: $mo['return_no']) : '-'); ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php
// 6B. LAPORAN RETUR UNTUK KASIR — READ ONLY. Kasir tidak menerima/memproses barang fisik.
if (class_exists('PK01_DB')):
    global $wpdb;
    $tret=PK01_DB::t('returns'); $tri=PK01_DB::t('return_items'); $tsa=PK01_DB::t('sales_accounts'); $tso=PK01_DB::t('sales_orders');
    $cashier_returns=$wpdb->get_results("SELECT r.return_no,r.tracking_no,r.status,r.qc_status,r.seller_name,r.seller_adjustment_amount,r.warehouse_received_at,r.accepted_at,r.order_id,r.customer_name,sa.email seller_email,sa.phone seller_phone,so.order_no,ri.qty,v.sku,v.name product_name FROM `{$tret}` r LEFT JOIN `{$tri}` ri ON ri.return_id=r.id LEFT JOIN `".PK01_DB::t('product_variants')."` v ON v.id=ri.variant_id LEFT JOIN `{$tsa}` sa ON sa.id=r.seller_account_id LEFT JOIN `{$tso}` so ON so.id=r.order_id WHERE r.status NOT IN ('cancelled') ORDER BY r.id DESC LIMIT 50",ARRAY_A)?:[];
?>
<div style="margin:22px 0;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:18px;">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
        <div><h3 style="margin:0 0 4px;">↩️ Laporan Retur Seller</h3><p style="margin:0;color:#64748b;font-size:12px;">Kasir hanya memantau. Saat Gudang scan dan menyatakan unit diterima, koreksi omzet/tagihan Seller tercatat otomatis.</p></div>
        <span style="font-size:11px;font-weight:800;color:#2563eb;background:#eff6ff;padding:6px 9px;border-radius:20px;">READ ONLY</span>
    </div>
    <div style="overflow:auto;margin-top:14px;">
        <table style="width:100%;border-collapse:collapse;font-size:12px;">
            <thead><tr><th style="text-align:left;padding:9px;background:#f8fafc;">Retur / Order</th><th style="text-align:left;padding:9px;background:#f8fafc;">Seller</th><th style="text-align:left;padding:9px;background:#f8fafc;">Barang</th><th style="text-align:left;padding:9px;background:#f8fafc;">Resi</th><th style="text-align:left;padding:9px;background:#f8fafc;">Status</th><th style="text-align:right;padding:9px;background:#f8fafc;">Pengurang Tagihan</th><th style="text-align:left;padding:9px;background:#f8fafc;">Notifikasi</th></tr></thead>
            <tbody>
            <?php if(empty($cashier_returns)): ?><tr><td colspan="7" style="padding:16px;text-align:center;color:#94a3b8;">Belum ada data retur.</td></tr>
            <?php else: foreach($cashier_returns as $cr):
                $phone=preg_replace('/\D+/','',(string)($cr['seller_phone']??'')); if(strpos($phone,'62')!==0&&$phone!=='')$phone='62'.ltrim($phone,'0');
                $msg="Halo ".($cr['seller_name']?:'Mitra Seller').", barang retur ".($cr['return_no']?:'-')." dari order ".($cr['order_no']?:'-')." telah diterima Gudang. Resi: ".($cr['tracking_no']?:'-').". Koreksi tagihan Seller: Rp ".number_format((float)($cr['seller_adjustment_amount']??0),0,',','.').". Status: ".strtoupper((string)($cr['status']?:'-')).".";
                $wa=$phone?'https://wa.me/'.$phone.'?text='.rawurlencode($msg):'';
            ?>
                <tr><td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($cr['return_no']);?></b><small style="display:block;color:#64748b;"><?php echo esc_html($cr['order_no']?:'Order #'.$cr['order_id']);?></small></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($cr['seller_name']?:'-');?></b><?php if($cr['seller_email']):?><small style="display:block;color:#64748b;"><?php echo esc_html($cr['seller_email']);?></small><?php endif;?></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php echo esc_html(($cr['product_name']?:'-').' × '.($cr['qty']??0));?></td><td style="padding:9px;border-bottom:1px solid #eef2f7;font-family:monospace;"><?php echo esc_html($cr['tracking_no']?:'-');?></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($cr['status']);?></b><small style="display:block;color:#64748b;"><?php echo esc_html($cr['qc_status']?:'-');?></small></td><td style="padding:9px;border-bottom:1px solid #eef2f7;text-align:right;"><b>Rp <?php echo esc_html(number_format((float)($cr['seller_adjustment_amount']??0),0,',','.'));?></b></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php if($wa):?><a href="<?php echo esc_url($wa);?>" target="_blank" style="font-weight:700;">WA Seller</a><?php else:?><span style="color:#94a3b8;">No. WA tidak ada</span><?php endif;?></td></tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php
// 6C. CONTROL TOWER KASIR — JOB PRODUKSI & PENUGASAN TAHAP
if ($can_manage && class_exists('PK01_DB')):
    $tjobs=PK01_DB::t('jobs'); $tji=PK01_DB::t('job_items'); $tv=PK01_DB::t('product_variants'); $tp=PK01_DB::t('products'); $tja=PK01_DB::t('job_assignments'); $te=PK01_DB::t('employees');
    $cashier_jobs=$wpdb->get_results("SELECT j.id,j.job_no,j.status,j.target_qty,j.deadline,j.created_at,p.name product_name,v.sku, GROUP_CONCAT(CONCAT(COALESCE(ja.role_code,'tahap'),': ',COALESCE(e.name,'belum ditugaskan'),' [',COALESCE(ja.status,'-'),']') ORDER BY ja.id SEPARATOR ' | ') assignments FROM `{$tjobs}` j LEFT JOIN `{$tji}` ji ON ji.job_id=j.id LEFT JOIN `{$tv}` v ON v.id=ji.variant_id LEFT JOIN `{$tp}` p ON p.id=v.product_id LEFT JOIN `{$tja}` ja ON ja.job_id=j.id LEFT JOIN `{$te}` e ON e.id=ja.employee_id GROUP BY j.id ORDER BY j.id DESC LIMIT 30",ARRAY_A)?:[];
?>
<div style="margin:22px 0;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:18px;">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
        <div><h3 style="margin:0 0 4px;">🏭 Job Produksi — Dispatch dari Kasir</h3><p style="margin:0;color:#64748b;font-size:12px;">Kasir melihat Job yang lahir dari order Seller/penjualan. Satu Job tetap satu pekerjaan produksi, tetapi dapat mempunyai beberapa tahap pekerja, misalnya <b>CNC → Prema</b>.</p></div>
        <span style="font-size:11px;font-weight:800;color:#166534;background:#dcfce7;padding:6px 9px;border-radius:20px;">REAL ASSIGNMENT</span>
    </div>
    <?php echo $production_dispatch_notice; ?>
    <section class="pk01-op-card" style="margin-top:18px;border:1px solid #dbeafe;border-radius:14px;padding:18px;background:#fff;">
      <div style="display:flex;justify-content:space-between;gap:15px;align-items:flex-start;flex-wrap:wrap"><div><h3 style="margin:0 0 4px">💰 Setoran Kasir → Keuangan</h3><p style="margin:0;color:#64748b;font-size:12px">Kasir menyerahkan uang/konfirmasi pembayaran kepada Keuangan. Untuk pembayaran Seller, cukup pilih Seller dan nominal; nomor invoice boleh kosong. Sistem akan mengalokasikan ke tagihan tertua saat Keuangan menerima.</p></div></div>
      <?php echo $cashier_deposit_notice; ?>
      <form method="post" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-top:12px">
        <?php echo wp_nonce_field('pk01_cashier_deposit_submit','pk01_cashier_deposit_nonce',true,false); ?><input type="hidden" name="pk01_cashier_deposit_submit" value="1">
        <label style="font-size:12px;font-weight:700">Jenis<input name="deposit_type" value="cash" list="pk01-deposit-types" class="pk01-input" required><datalist id="pk01-deposit-types"><option value="cash">Kas Tunai</option><option value="transfer">Transfer Seller</option></datalist></label>
        <label style="font-size:12px;font-weight:700">Nominal<input name="deposit_amount" type="number" min="0.01" step="0.01" class="pk01-input" required></label>
        <label style="font-size:12px;font-weight:700">Sumber Akun<input name="deposit_source_account" value="<?php echo esc_attr(class_exists('PK01_Engine')?PK01_Engine::cashier_account(get_current_user_id()):'Kas Tunai Toko'); ?>" class="pk01-input"></label>
        <label style="font-size:12px;font-weight:700">Tujuan Keuangan<input name="deposit_destination_account" value="Kas/Bank Keuangan" class="pk01-input"></label>
        <label style="font-size:12px;font-weight:700">Metode<input name="deposit_payment_method" value="Kas Tunai" class="pk01-input"></label>
        <label style="font-size:12px;font-weight:700">Referensi/Bukti<input name="deposit_reference_no" class="pk01-input" placeholder="Wajib untuk transfer"></label>
        <label style="font-size:12px;font-weight:700">Seller (jika setoran adalah pembayaran Seller)<select name="deposit_seller_id" class="pk01-input"><option value="0">— Bukan pembayaran Seller / pilih jika Seller membayar —</option><?php foreach($sellers as $sv): ?><option value="<?php echo (int)$sv['id']; ?>"><?php echo esc_html($sv['code'].' — '.$sv['name']); ?></option><?php endforeach; ?></select></label>
        <label style="font-size:12px;font-weight:700">Invoice Seller (opsional)<select name="deposit_invoice_id" class="pk01-input"><option value="0">— Kosongkan jika Seller tidak tahu invoice —</option><?php foreach($cashier_transfer_invoices as $iv): ?><option value="<?php echo (int)$iv['id']; ?>" data-seller="<?php echo (int)$iv['seller_account_id']; ?>"><?php echo esc_html($iv['invoice_no'].' · '.$iv['seller_name'].' · dibayar Rp '.number_format(max(0,(float)$iv['total']-(float)$iv['paid']-(float)($iv['pending']??0)),0,',','.')); ?></option><?php endforeach; ?></select></label>
        <label style="font-size:12px;font-weight:700">Keterangan<input name="deposit_notes" class="pk01-input" placeholder="Contoh: setoran akhir shift"></label>
        <div style="grid-column:1/-1"><button type="submit" class="pk01-op-button">📨 Kirim Setoran ke Keuangan</button></div>
      </form>
    </section>

    <div style="margin-top:12px;padding:11px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;font-size:12px;"><b>Aturan:</b> PK01 memilih pekerja berdasarkan role/skill yang tersimpan. Jika Job membutuhkan CNC, Master G-code harus tersedia. Jika membutuhkan CNC + Prema, dua assignment dibuat ke dua pekerja berbeda. G-code tidak dijalankan otomatis.</div>
    <div style="overflow:auto;margin-top:14px;">
      <table style="width:100%;border-collapse:collapse;font-size:12px;"><thead><tr><th style="text-align:left;padding:9px;background:#f8fafc;">Job</th><th style="text-align:left;padding:9px;background:#f8fafc;">Produk</th><th style="text-align:left;padding:9px;background:#f8fafc;">Tahap & Pekerja</th><th style="text-align:left;padding:9px;background:#f8fafc;">Status</th><th style="text-align:left;padding:9px;background:#f8fafc;">Aksi</th></tr></thead><tbody>
      <?php if(empty($cashier_jobs)): ?><tr><td colspan="5" style="padding:16px;text-align:center;color:#94a3b8;">Belum ada Job Produksi.</td></tr>
      <?php else: foreach($cashier_jobs as $cj): ?>
        <tr><td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($cj['job_no']); ?></b><small style="display:block;color:#64748b;">Target <?php echo esc_html($cj['target_qty']); ?> unit<?php if($cj['deadline']): ?> · Deadline <?php echo esc_html($cj['deadline']); ?><?php endif; ?></small></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($cj['product_name']?:'-'); ?></b><small style="display:block;color:#64748b;"><?php echo esc_html($cj['sku']?:'-'); ?></small></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><?php echo esc_html($cj['assignments']?:'Belum ada assignment'); ?></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><b><?php echo esc_html($cj['status']); ?></b></td><td style="padding:9px;border-bottom:1px solid #eef2f7;"><form method="post" style="margin:0"><?php echo wp_nonce_field('pk01_cashier_dispatch_job','pk01_cashier_dispatch_nonce',true,false); ?><input type="hidden" name="pk01_cashier_dispatch_job" value="1"><input type="hidden" name="job_id" value="<?php echo (int)$cj['id']; ?>"><button class="pk01-op-button is-small" type="submit">🔄 Cek / Kirim Tahap</button></form></td></tr>
      <?php endforeach; endif; ?>
      </tbody></table>
    </div>
</div>
<?php endif; ?>

<?php
// 7. PEMUATAN TABEL RIWAYAT DENGAN MULTI-PATH RESOLVER AMAN
$loaded = false;
$candidates = [];

if (defined('PK01_DIR')) {
    $candidates[] = trailingslashit(PK01_DIR) . 'includes/core/view/tampilan-data-modul.php';
}


foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        require_once $cand;
        $loaded = true;
        break;
    }
}

if (function_exists('pk01_tampilkan_data_modul')) {
    pk01_tampilkan_data_modul(
        'sales', 
        'Riwayat Seluruh Transaksi Penjualan', 
        'PENJUALAN & OMZET', 
        'Daftar riwayat faktur pesanan, pelanggan, status kirim, dan omzet masuk di sistem PK01.'
    );
} elseif (!$loaded) {
    echo '<div style="background:#ffffff;border:1px dashed #cbd5e1;border-radius:12px;padding:26px;text-align:center;color:#64748b;font-size:13px;">
            📁 Modul antarmuka tabel <code>tampilan-data-modul.php</code> belum ditemukan di folder <code>includes/</code>.
          </div>';
}