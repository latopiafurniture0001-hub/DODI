<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_user = wp_get_current_user();

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('pricing') || PK01_Authorization::can('finance')));

// 2. HELPER TABEL SISTEM
$get_table = function($key) use ($wpdb) {
    $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) ? $t : false;
};

$tbl_pricing  = $get_table('pricing');
$tbl_hpp      = $get_table('hpp_components');
$tbl_variants = $get_table('product_variants');
$tbl_products = $get_table('products');
$tbl_logs     = $get_table('logs');

// PERIKSA / BUAT TABEL JIKA BELUM ADA (Mencegah Fatal Error)
if (!$tbl_pricing) {
    $tbl_pricing = $wpdb->prefix . 'pk01_pricing';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `{$tbl_pricing}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `variant_id` bigint(20) unsigned DEFAULT 0,
        `sku` varchar(100) NOT NULL DEFAULT '',
        `name` varchar(255) NOT NULL DEFAULT '',
        `hpp` decimal(15,2) NOT NULL DEFAULT 0.00,
        `price` decimal(15,2) NOT NULL DEFAULT 0.00,
        `margin_percent` decimal(6,2) NOT NULL DEFAULT 0.00,
        `target_markup_percent` decimal(6,2) NOT NULL DEFAULT 0.00,
        `fee_percent` decimal(6,2) NOT NULL DEFAULT 0.00,
        `selling_cost_fixed` decimal(15,2) NOT NULL DEFAULT 0.00,
        `channel` varchar(50) NOT NULL DEFAULT 'direct',
        `price_source` varchar(30) NOT NULL DEFAULT 'manual',
        `ai_recommendation` text DEFAULT NULL,
        `status` varchar(50) NOT NULL DEFAULT 'approved',
        `valid_from` date NOT NULL,
        `valid_to` date DEFAULT NULL,
        `approved_by` varchar(150) DEFAULT '',
        `description` text DEFAULT NULL,
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `sku` (`sku`),
        KEY `status` (`status`)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe($sql);
}

// 3. LOGIKA BARU: EKSPOR MATRIKS HARGA KE CSV (AUDIT STRATEGI HARGA)
if (isset($_POST['pk01_export_pricing_csv']) && check_admin_referer('pk01_export_pricing_nonce')) {
    if ($can_manage && $tbl_pricing) {
        $export_data = $wpdb->get_results(
            "SELECT sku, name, hpp, price, margin_percent, target_markup_percent, fee_percent, selling_cost_fixed, channel, status, approved_by, valid_from
             FROM `{$tbl_pricing}` ORDER BY id DESC LIMIT 5000",
            ARRAY_A
        );
        if (!empty($export_data)) {
            $filename = 'pk01-pricing-margin-matrix-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Kode SKU', 'Nama Produk', 'HPP (Rp)', 'Harga Jual (Rp)', 'Margin (%)', 'Markup (%)', 'Channel Fee (%)', 'Biaya Packing (Rp)', 'Kanal Penjualan', 'Status', 'Disetujui Oleh', 'Mulai Berlaku']);
            foreach ($export_data as $row) {
                fputcsv($out, $row);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. SIMPAN RINCIAN HPP PER VARIAN (LOGIKA LAMA TETAP UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_hpp'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-prc-alert is-error">⚠️ Anda tidak memiliki hak untuk mengubah HPP.</div>';
    } else {
        $nonce = sanitize_text_field(wp_unslash($_POST['pk01_hpp_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'pk01_hpp_action')) {
            $notice = '<div class="pk01-prc-alert is-error">⚠️ Sesi HPP kedaluwarsa. Muat ulang halaman.</div>';
        } elseif (!$tbl_hpp || !$tbl_variants) {
            $notice = '<div class="pk01-prc-alert is-error">⚠️ Tabel HPP/varian belum tersedia di database.</div>';
        } else {
            $variant_id = absint($_POST['hpp_variant_id'] ?? 0);
            $num = function($v){ return max(0, (float)preg_replace('/[^0-9.\-]/','',str_replace(',', '.', (string)$v))); };
            $labor     = $num($_POST['hpp_labor'] ?? 0);
            $overhead  = $num($_POST['hpp_overhead'] ?? 0);
            $packaging = $num($_POST['hpp_packaging'] ?? 0);
            $other     = $num($_POST['hpp_other'] ?? 0);
            $basis     = max(1, $num($_POST['hpp_basis_qty'] ?? 1));
            $hpp_mode  = sanitize_key($_POST['hpp_mode'] ?? 'manual');

            if ($hpp_mode === 'auto' && class_exists('PK01_Engine') && method_exists('PK01_Engine','estimate_hpp_from_system') && $variant_id > 0) {
                try {
                    $auto = PK01_Engine::estimate_hpp_from_system($variant_id, $basis, 12);
                    $labor     = (float)$auto['labor_cost'];
                    $overhead  = (float)$auto['overhead_cost'];
                    $packaging = (float)$auto['packaging_cost'];
                    $other     = (float)$auto['other_cost'];
                } catch (Throwable $e) {
                    $notice = '<div class="pk01-prc-alert is-error">HPP otomatis gagal: '.esc_html($e->getMessage()).'</div>';
                    $hpp_mode = 'manual';
                }
            }

            $material_total = 0;
            $component_rows = [];
            $material_ids = (array)($_POST['hpp_material_id'] ?? []);
            $names        = (array)($_POST['hpp_component_name'] ?? []);
            $qtys         = (array)($_POST['hpp_qty'] ?? []);
            $units        = (array)($_POST['hpp_unit'] ?? []);
            $costs        = (array)($_POST['hpp_unit_cost'] ?? []);
            $wastes       = (array)($_POST['hpp_waste_percent'] ?? []);

            foreach ($names as $i => $nm) {
                $name  = sanitize_text_field(wp_unslash($nm)); 
                $qty   = $num($qtys[$i] ?? 0); 
                $cost  = $num($costs[$i] ?? 0); 
                $waste = min(100, $num($wastes[$i] ?? 0));
                
                if ($name === '' && empty($material_ids[$i])) continue;
                
                $amount = round($qty * $cost * (1 + $waste / 100), 2); 
                $material_total += $amount;
                
                $component_rows[] = [
                    'component_type' => 'material',
                    'material_id'    => absint($material_ids[$i] ?? 0),
                    'component_name' => $name,
                    'qty'            => $qty,
                    'unit'           => sanitize_text_field(wp_unslash($units[$i] ?? 'pcs')),
                    'unit_cost'      => $cost,
                    'waste_percent'  => $waste,
                    'amount'         => $amount,
                    'notes'          => sanitize_textarea_field(wp_unslash($_POST['hpp_notes'][$i] ?? '')),
                    'created_by'     => $current_user->ID,
                    'created_at'     => current_time('mysql'),
                    'updated_at'     => current_time('mysql')
                ];
            }

            $total = round(($material_total + $labor + $overhead + $packaging + $other) / $basis, 2);
            if ($hpp_mode === 'auto' && !empty($auto)) {
                $material_total = (float)$auto['material_cost'];
                $labor          = (float)$auto['labor_cost'];
                $overhead       = (float)$auto['overhead_cost'];
                $packaging      = (float)$auto['packaging_cost'];
                $other          = (float)$auto['other_cost'];
                $total          = (float)$auto['hpp_per_unit'];
            }

            if ($variant_id <= 0 || $total <= 0) {
                $notice = '<div class="pk01-prc-alert is-error">⚠️ Pilih varian dan pastikan rincian HPP menghasilkan nilai lebih dari Rp 0.</div>';
            } else {
                $wpdb->query('START TRANSACTION');
                try {
                    $wpdb->delete($tbl_hpp, ['variant_id' => $variant_id]);
                    foreach ($component_rows as $row) {
                        $wpdb->insert($tbl_hpp, array_merge($row, ['variant_id' => $variant_id]));
                    }
                    
                    $variant_cols = $wpdb->get_col("SHOW COLUMNS FROM `{$tbl_variants}`", 0);
                    $vdata = ['hpp' => $total, 'updated_at' => current_time('mysql')];
                    
                    foreach (['hpp_material'=>$material_total, 'hpp_labor'=>$labor, 'hpp_overhead'=>$overhead, 'hpp_packaging'=>$packaging, 'hpp_other'=>$other, 'hpp_basis_qty'=>$basis, 'hpp_method'=>'full_cost'] as $k => $v) {
                        if (in_array($k, $variant_cols, true)) $vdata[$k] = $v;
                    }
                    
                    $wpdb->update($tbl_variants, $vdata, ['id' => $variant_id]);
                    $wpdb->query('COMMIT');
                    
                    if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'log')) { 
                        PK01_Engine::log('hpp_recalculated', 'product_variants', 'variant', (string)$variant_id, null, $vdata); 
                    }
                    $notice = '<div class="pk01-prc-alert is-success">✅ HPP berhasil dihitung dan disimpan: <b>Rp ' . number_format($total, 0, ',', '.') . '</b> per ' . $basis . ' unit dasar.</div>';
                } catch (Throwable $e) { 
                    $wpdb->query('ROLLBACK'); 
                    $notice = '<div class="pk01-prc-alert is-error">❌ Gagal menyimpan HPP: ' . esc_html($e->getMessage()) . '</div>'; 
                }
            }
        }
    }
}

// 5. PROSES APPROVAL CEPAT OLEH ADMIN
if (isset($_GET['action'], $_GET['pricing_id'], $_GET['_wpnonce']) && $_GET['action'] === 'approve_pricing' && $is_admin) {
    if (wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'pk01_approve_price_' . (int)$_GET['pricing_id'])) {
        $p_id = absint($_GET['pricing_id']);
        $wpdb->update($tbl_pricing, [
            'status'      => 'approved',
            'approved_by' => $current_user->display_name ?: $current_user->user_login
        ], ['id' => $p_id]);

        if ($tbl_logs) {
            $wpdb->insert($tbl_logs, [
                'user_id'     => $current_user->ID,
                'action'      => 'pricing_approved',
                'module'      => 'pricing',
                'entity'      => 'ID #' . $p_id,
                'description' => 'Admin menyetujui perubahan harga jual ID #' . $p_id,
                'created_at'  => current_time('mysql')
            ]);
        }
        $notice = '<div class="pk01-prc-alert is-success">✅ Harga jual ID #' . $p_id . ' resmi disetujui dan aktif menjadi acuan order.</div>';
    }
}

// 6. PROSES SIMPAN PENETAPAN HARGA BARU
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_pricing'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-prc-alert is-error">⚠️ Anda tidak memiliki hak otorisasi untuk mengubah harga.</div>';
    } else {
        $nonce = sanitize_text_field(wp_unslash($_POST['pk01_pricing_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'pk01_pricing_action')) {
            $notice = '<div class="pk01-prc-alert is-error">⚠️ Sesi kedaluwarsa. Silakan muat ulang halaman.</div>';
        } else {
            $clean_num = function($val) {
                return (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)$val));
            };

            $sku                = sanitize_text_field(wp_unslash($_POST['sku'] ?? ''));
            $name               = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
            $variant_id         = absint($_POST['variant_id'] ?? 0);
            $hpp                = $clean_num($_POST['hpp'] ?? 0);
            $price              = $clean_num($_POST['price'] ?? 0);
            $target_markup      = max(0, (float)($_POST['target_markup_percent'] ?? 0));
            $fee_percent        = max(0, (float)($_POST['fee_percent'] ?? 0));
            $selling_cost_fixed = max(0, $clean_num($_POST['selling_cost_fixed'] ?? 0));
            $channel            = sanitize_key($_POST['channel'] ?? 'direct');
            $price_source       = sanitize_key($_POST['price_source'] ?? 'manual');
            $ai_recommendation  = sanitize_textarea_field(wp_unslash($_POST['ai_recommendation'] ?? ''));
            $valid_from         = sanitize_text_field(wp_unslash($_POST['valid_from'] ?? current_time('Y-m-d')));
            $description        = sanitize_textarea_field(wp_unslash($_POST['description'] ?? ''));

            $status      = $is_admin ? 'approved' : 'pending';
            $approved_by = $is_admin ? ($current_user->display_name ?: $current_user->user_login) : 'Menunggu Approval';

            $margin_percent = 0;
            if ($price > 0 && $price >= $hpp) {
                $margin_percent = round((($price - $hpp) / $price) * 100, 2);
            }

            if ($price <= 0) {
                $notice = '<div class="pk01-prc-alert is-error">⚠️ Harga jual harus lebih besar dari Rp 0.</div>';
            } elseif (empty($sku) || empty($name)) {
                $notice = '<div class="pk01-prc-alert is-error">⚠️ Kode SKU dan Nama Produk wajib diisi.</div>';
            } else {
                try {
                    if ($status === 'approved') {
                        $wpdb->update($tbl_pricing, [
                            'status'   => 'archived',
                            'valid_to' => current_time('Y-m-d')
                        ], [
                            'sku'    => $sku,
                            'status' => 'approved'
                        ]);
                    }

                    $wpdb->insert($tbl_pricing, [
                        'variant_id'            => $variant_id,
                        'sku'                   => $sku,
                        'name'                  => $name,
                        'hpp'                   => $hpp,
                        'price'                 => $price,
                        'margin_percent'        => $margin_percent,
                        'target_markup_percent' => $target_markup,
                        'fee_percent'           => $fee_percent,
                        'selling_cost_fixed'    => $selling_cost_fixed,
                        'channel'               => $channel,
                        'price_source'          => $price_source,
                        'ai_recommendation'     => $ai_recommendation,
                        'status'                => $status,
                        'valid_from'            => $valid_from,
                        'approved_by'           => $approved_by,
                        'description'           => $description,
                        'created_at'            => current_time('mysql')
                    ]);

                    if ($tbl_logs) {
                        $wpdb->insert($tbl_logs, [
                            'user_id'     => $current_user->ID,
                            'action'      => 'pricing_set',
                            'module'      => 'pricing',
                            'entity'      => $sku,
                            'description' => 'Menetapkan harga baru ' . $sku . ' menjadi Rp ' . number_format($price,0,',','.') . ' (Margin: ' . $margin_percent . '%) [' . strtoupper($status) . ']',
                            'created_at'  => current_time('mysql')
                        ]);
                    }

                    $notice = '<div class="pk01-prc-alert is-success">✅ Harga untuk <b>' . esc_html($name) . '</b> berhasil disimpan ' . ($status === 'approved' ? 'dan resmi aktif.' : 'dan menunggu persetujuan Admin.') . '</div>';
                    $_POST = [];
                } catch (Throwable $e) {
                    $notice = '<div class="pk01-prc-alert is-error">❌ Gagal menyimpan: ' . esc_html($e->getMessage()) . '</div>';
                }
            }
        }
    }
}

// 7. STATISTIK HARGA DARI DATABASE REAL
$total_active_prices = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_pricing}` WHERE status = 'approved'");
$avg_margin          = (float) $wpdb->get_var("SELECT AVG(margin_percent) FROM `{$tbl_pricing}` WHERE status = 'approved'");
$pending_count       = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_pricing}` WHERE status = 'pending'");

$product_options = [];
if ($tbl_variants) {
    $product_options = $wpdb->get_results("SELECT id, sku, name, hpp FROM `{$tbl_variants}` ORDER BY name ASC LIMIT 150", ARRAY_A) ?: [];
} elseif ($tbl_products) {
    $product_options = $wpdb->get_results("SELECT id, code as sku, name, cost as hpp FROM `{$tbl_products}` ORDER BY name ASC LIMIT 150", ARRAY_A) ?: [];
}
?>

<style>
:root {
    --pk-prc-navy: #0f172a;
    --pk-prc-border: #e2e8f0;
    --pk-prc-green: #059669;
    --pk-prc-blue: #2563eb;
    --pk-prc-amber: #d97706;
}

.pk01-pricing-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-pricing-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-prc-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #064e3b 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-prc-eyebrow {
    display: inline-block;
    background: rgba(52, 211, 153, 0.15);
    color: #34d399;
    border: 1px solid rgba(52, 211, 153, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-prc-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-prc-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 3 Executive Scorecards */
.pk01-prc-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-prc-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-green::before { background: var(--pk-prc-green); }
.pk01-kpi-card.c-blue::before  { background: var(--pk-prc-blue); }
.pk01-kpi-card.c-amber::before { background: var(--pk-prc-amber); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: #64748b;
}

/* Card Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-prc-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h2 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-surface-head p {
    margin: 4px 0 0 0;
    font-size: 13px;
    color: #64748b;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}
@media (max-width: 900px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-form-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-form-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: #2563eb;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Live Simulation Card */
.pk01-margin-simulation-bar {
    grid-column: 1 / -1;
    background: #f0fdf4;
    border: 1px dashed #86efac;
    border-radius: 12px;
    padding: 16px 20px;
    margin-top: 8px;
}
.pk01-sim-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    font-size: 12px;
    font-weight: 700;
    color: #166534;
    text-transform: uppercase;
}
.pk01-sim-metrics {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 12px;
}
.pk01-sim-box span {
    font-size: 11px;
    color: #166534;
    display: block;
}
.pk01-sim-box strong {
    font-size: 16px;
    font-family: monospace;
    display: block;
    margin-top: 2px;
}

/* HPP Components Table */
.pk01-hpp-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    margin-top: 10px;
}
.pk01-hpp-table th {
    background: #f8fafc;
    padding: 9px 10px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-prc-border);
}
.pk01-hpp-table td {
    padding: 8px 10px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }

.pk01-prc-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-prc-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-prc-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-pricing-cockpit">
    
    <!-- 1. HERO COCKPIT -->
    <header class="pk01-prc-hero">
        <div>
            <span class="pk01-prc-eyebrow">STRATEGIC PRICING &bull; MARGIN ARCHITECTURE</span>
            <h1>Penetapan Harga Jual, HPP &amp; Margin Produk</h1>
            <p>
                Kalkulasi harga jual berbasis data pokok terukur (Bahan baku riil, waste %, upah borongan, overhead pabrik, dan potongan kanal marketplace).
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_pricing_nonce'); ?>
                <input type="hidden" name="pk01_export_pricing_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Matriks Harga (.CSV)
                </button>
            </form>
        </div>
    </header>

    <!-- 2. 3 EXECUTIVE KPI SCORECARDS -->
    <div class="pk01-prc-kpis">
        <div class="pk01-kpi-card c-green">
            <small>Harga Produk Aktif</small>
            <strong style="color:#059669;"><?php echo number_format($total_active_prices, 0, ',', '.'); ?> <span style="font-size:13px;font-weight:normal;">SKU</span></strong>
            <span>Harga jual resmi disetujui untuk transaksi</span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Rata-rata Margin Keuntungan</small>
            <strong style="color:#1d4ed8;"><?php echo number_format($avg_margin, 1, ',', '.'); ?>%</strong>
            <span>Persentase margin kotor terhadap harga jual</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Menunggu Persetujuan Admin</small>
            <strong style="color:#d97706;"><?php echo (int)$pending_count; ?> <span style="font-size:13px;font-weight:normal;">Pengajuan</span></strong>
            <span>Draft usulan harga baru staf</span>
        </div>
    </div>

    <?php echo $notice; ?>

    <!-- 3. HPP PRODUKSI REAL (KALKULATOR LENGKAP & SKALA BASIS) -->
    <?php if ($can_manage):
    $hpp_variants = $tbl_variants ? $wpdb->get_results("SELECT v.id,v.sku,v.name,v.size,v.material,v.finishing,v.hpp,v.hpp_material,v.hpp_labor,v.hpp_overhead,v.hpp_packaging,v.hpp_other,v.hpp_basis_qty,p.product_length,p.product_width,p.product_height,p.product_thickness,p.dimension_unit,p.category FROM `{$tbl_variants}` v LEFT JOIN `{$tbl_products}` p ON p.id=v.product_id WHERE v.status='active' ORDER BY v.name ASC LIMIT 100", ARRAY_A) : [];
    $materials = $get_table('materials');
    $hpp_materials = $materials ? $wpdb->get_results("SELECT id,code,name,unit,cost FROM `{$materials}` WHERE status='active' ORDER BY name ASC LIMIT 200", ARRAY_A) : [];
    ?>
    <section class="pk01-surface" style="border-left:4px solid #10b981;">
        <div class="pk01-surface-head">
            <h2>Kalkulator Rincian HPP Produksi Lengkap</h2>
            <p>HPP dihitung dari bahan aktual, toleransi waste %, upah langsung, overhead tetap, dan kemasan per basis produksi.</p>
        </div>

        <form method="post" id="pk01-hpp-form">
            <?php echo wp_nonce_field('pk01_hpp_action','pk01_hpp_nonce',true,false); ?>
            <input type="hidden" name="pk01_save_hpp" value="1">

            <div class="pk01-form-grid">
                <div class="pk01-form-item">
                    <label>Pilih Produk / Varian <span style="color:#dc2626;">*</span></label>
                    <select name="hpp_variant_id" id="pk01-hpp-variant" class="pk01-input" required>
                        <option value="">— Pilih Varian Produk —</option>
                        <?php foreach($hpp_variants as $v): ?>
                            <option value="<?php echo (int)$v['id']; ?>" 
                                data-size="<?php echo esc_attr($v['product_length'].' × '.$v['product_width'].' × '.$v['product_height'].' '.$v['dimension_unit']); ?>" 
                                data-thickness="<?php echo esc_attr($v['product_thickness'].' '.$v['dimension_unit']); ?>" 
                                data-material="<?php echo esc_attr($v['material']); ?>" 
                                data-finish="<?php echo esc_attr($v['finishing']); ?>" 
                                data-hpp="<?php echo esc_attr($v['hpp']); ?>">
                                [<?php echo esc_html($v['sku']); ?>] <?php echo esc_html($v['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pk01-form-item">
                    <label>Basis Kuantitas Produksi (Unit)</label>
                    <input type="number" min="1" step=".0001" name="hpp_basis_qty" id="pk01-hpp-basis" class="pk01-input" value="1">
                </div>

                <div class="pk01-form-item">
                    <label>Metode Kalkulasi HPP</label>
                    <select name="hpp_mode" id="pk01-hpp-mode" class="pk01-input">
                        <option value="manual">Manual — Tentukan Komponen Spesifik</option>
                        <option value="auto">Otomatis — Baca dari Pembelian &amp; Histori Produksi</option>
                    </select>
                </div>

                <div id="pk01-hpp-spec" style="grid-column:1/-1;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:12px;font-size:13px;">
                    Pilih varian untuk memuat spesifikasi ukuran, tebal, material kayu, dan jenis finishing.
                </div>
            </div>

            <!-- Tabel Komponen Bahan -->
            <div style="overflow-x:auto;margin-top:14px;">
                <table class="pk01-hpp-table" id="pk01-hpp-components">
                    <thead>
                        <tr>
                            <th>Bahan / Material Komponen</th>
                            <th style="width:100px;">Kuantitas</th>
                            <th style="width:90px;">Satuan</th>
                            <th style="width:130px;">Harga Satuan (Rp)</th>
                            <th style="width:100px;">Waste (%)</th>
                            <th style="text-align:right;width:140px;">Subtotal Biaya</th>
                            <th style="width:50px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="hpp-row">
                            <td>
                                <select name="hpp_material_id[]" class="hpp-material pk01-input">
                                    <option value="">Manual / Komponen Lain</option>
                                    <?php foreach($hpp_materials as $m): ?>
                                        <option value="<?php echo (int)$m['id']; ?>" data-name="<?php echo esc_attr($m['name']); ?>" data-unit="<?php echo esc_attr($m['unit']); ?>" data-cost="<?php echo esc_attr($m['cost']); ?>">
                                            <?php echo esc_html($m['code'].' — '.$m['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input name="hpp_component_name[]" class="pk01-input" placeholder="Nama komponen" style="margin-top:5px;">
                            </td>
                            <td><input type="number" min="0" step=".000001" name="hpp_qty[]" class="hpp-qty pk01-input" value="1"></td>
                            <td><input name="hpp_unit[]" class="hpp-unit pk01-input" value="pcs"></td>
                            <td><input type="number" min="0" step=".01" name="hpp_unit_cost[]" class="hpp-cost pk01-input" value="0"></td>
                            <td><input type="number" min="0" max="100" step=".01" name="hpp_waste_percent[]" class="hpp-waste pk01-input" value="0"></td>
                            <td class="hpp-amount" style="text-align:right;font-family:monospace;font-weight:700;">Rp 0</td>
                            <td><button type="button" class="pk01-btn pk01-btn-export hpp-remove" style="padding:4px 8px;">×</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <button type="button" class="pk01-btn pk01-btn-export" id="hpp-add" style="margin-top:8px;">+ Tambah Komponen Bahan</button>

            <!-- Biaya Non-Material -->
            <div class="pk01-form-grid" style="margin-top:16px;">
                <div class="pk01-form-item">
                    <label>Upah Langsung / Unit (Rp)</label>
                    <input type="number" min="0" step=".01" name="hpp_labor" id="hpp-labor" class="pk01-input" value="0">
                </div>
                <div class="pk01-form-item">
                    <label>Overhead Produksi / Batch (Rp)</label>
                    <input type="number" min="0" step=".01" name="hpp_overhead" id="hpp-overhead" class="pk01-input" value="0">
                </div>
                <div class="pk01-form-item">
                    <label>Kemasan &amp; Pelindung / Unit (Rp)</label>
                    <input type="number" min="0" step=".01" name="hpp_packaging" id="hpp-packaging" class="pk01-input" value="0">
                </div>
                <div class="pk01-form-item">
                    <label>Biaya Lain-lain / Batch (Rp)</label>
                    <input type="number" min="0" step=".01" name="hpp_other" id="hpp-other" class="pk01-input" value="0">
                </div>
            </div>

            <!-- Rekapitulasi HPP Bar -->
            <div style="margin-top:16px;padding:16px;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:12px;display:grid;grid-template-columns:repeat(3,1fr);gap:14px;">
                <div>Total Biaya Bahan:<br><strong id="hpp-material-total" style="font-size:16px;font-family:monospace;">Rp 0</strong></div>
                <div>Total HPP Perolehan:<br><strong id="hpp-total" style="font-size:18px;color:#047857;font-family:monospace;">Rp 0</strong></div>
                <div>HPP per Unit Bersih:<br><strong id="hpp-per-unit" style="font-size:18px;color:#1e3a8a;font-family:monospace;">Rp 0</strong></div>
            </div>

            <div id="pk01-hpp-scale-note" style="margin-top:12px;font-size:12px;color:#64748b;">
                Mode manual aktif. Admin menentukan rincian komponen HPP secara eksplisit.
            </div>

            <button type="submit" class="pk01-btn pk01-btn-primary" style="margin-top:14px;">
                💾 Simpan &amp; Tetapkan HPP Produk
            </button>
        </form>
    </section>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const f = document.getElementById('pk01-hpp-form'); 
        if (!f) return;

        const money = n => 'Rp ' + Math.round(n || 0).toLocaleString('id-ID');

        const recalc = () => {
            let mat = 0; 
            f.querySelectorAll('.hpp-row').forEach(r => {
                let q = parseFloat(r.querySelector('.hpp-qty')?.value) || 0,
                    c = parseFloat(r.querySelector('.hpp-cost')?.value) || 0,
                    w = parseFloat(r.querySelector('.hpp-waste')?.value) || 0,
                    a = q * c * (1 + w / 100);
                r.querySelector('.hpp-amount').textContent = money(a);
                mat += a;
            }); 
            let basis = Math.max(1, parseFloat(f.querySelector('#pk01-hpp-basis').value) || 1), 
                lab   = parseFloat(f.querySelector('#hpp-labor').value) || 0,
                oh    = parseFloat(f.querySelector('#hpp-overhead').value) || 0,
                pack  = parseFloat(f.querySelector('#hpp-packaging').value) || 0,
                other = parseFloat(f.querySelector('#hpp-other').value) || 0,
                total = mat + lab + oh + pack + other;

            f.querySelector('#hpp-material-total').textContent = money(mat);
            f.querySelector('#hpp-total').textContent = money(total);
            f.querySelector('#hpp-per-unit').textContent = money(total / basis);
        };

        const bind = r => {
            r.querySelectorAll('input,select').forEach(x => x.addEventListener('input', recalc));
            r.querySelector('.hpp-material')?.addEventListener('change', e => {
                let o = e.target.selectedOptions[0];
                if (o && o.value) {
                    r.querySelector('[name="hpp_component_name[]"]').value = o.dataset.name || '';
                    r.querySelector('.hpp-unit').value = o.dataset.unit || 'pcs';
                    r.querySelector('.hpp-cost').value = o.dataset.cost || 0;
                    recalc();
                }
            });
            r.querySelector('.hpp-remove')?.addEventListener('click', () => {
                let rows = f.querySelectorAll('.hpp-row');
                if (rows.length > 1) r.remove();
                recalc();
            });
        };

        f.querySelectorAll('.hpp-row').forEach(bind); 

        document.getElementById('hpp-add').addEventListener('click', () => {
            let r = f.querySelector('.hpp-row').cloneNode(true);
            r.querySelectorAll('input').forEach(x => {
                if (x.name === 'hpp_qty[]') x.value = 1;
                else if (x.name === 'hpp_waste_percent[]') x.value = 0;
                else x.value = '';
            });
            r.querySelector('.hpp-material').value = '';
            r.querySelector('.hpp-amount').textContent = 'Rp 0';
            f.querySelector('tbody').appendChild(r);
            bind(r);
            recalc();
        });

        f.querySelector('#pk01-hpp-variant').addEventListener('change', function() {
            let o = this.selectedOptions[0];
            f.querySelector('#pk01-hpp-spec').innerHTML = o && o.value 
                ? '<b>Ukuran:</b> ' + (o.dataset.size || '-') + ' &bull; <b>Tebal:</b> ' + (o.dataset.thickness || '-') + ' &bull; <b>Bahan:</b> ' + (o.dataset.material || '-') + ' &bull; <b>Finishing:</b> ' + (o.dataset.finish || '-')
                : 'Pilih varian untuk melihat spesifikasi detail.';
        });

        const mode = f.querySelector('#pk01-hpp-mode'), 
              note = f.querySelector('#pk01-hpp-scale-note');

        const syncMode = () => {
            if (!mode || !note) return; 
            note.innerHTML = mode.value === 'auto'
                ? '<b>Mode otomatis aktif:</b> Sistem menghitung bobot bahan riil, riwayat upah produksi, dan alokasi overhead batch dari data server.'
                : '<b>Mode manual aktif:</b> Admin menetapkan rincian komponen HPP secara mandiri.';
        };
        mode?.addEventListener('change', syncMode); 
        syncMode();

        f.querySelectorAll('input').forEach(x => x.addEventListener('input', recalc));
        recalc();
    });
    </script>
    <?php endif; ?>

    <!-- 4. FORM PENETAPAN HARGA JUAL & KALKULATOR MARGIN OTOMATIS -->
    <?php if ($can_manage): ?>
    <section class="pk01-surface">
        <div class="pk01-surface-head">
            <h2>➕ Tetapkan Harga Jual &amp; Margin Kanal</h2>
            <p>Kalkulasi margin otomatis berdasarkan HPP, target markup, dan potongan komisi kanal penjualan.</p>
        </div>

        <form method="post" action="">
            <?php echo wp_nonce_field('pk01_pricing_action', 'pk01_pricing_nonce', true, false); ?>
            <input type="hidden" name="pk01_save_pricing" value="1">
            <input type="hidden" name="variant_id" id="pk01-variant-id" value="0">

            <div class="pk01-form-grid">
                <div class="pk01-form-item">
                    <label>Pilih Produk (Dari Master Database)</label>
                    <select id="pk01-product-select" class="pk01-input">
                        <option value="">— Pilih Produk Master —</option>
                        <?php foreach ($product_options as $p): ?>
                            <option value="<?php echo (int)$p['id']; ?>" 
                                data-sku="<?php echo esc_attr($p['sku']); ?>" 
                                data-name="<?php echo esc_attr($p['name']); ?>" 
                                data-hpp="<?php echo esc_attr($p['hpp'] ?? 0); ?>">
                                [<?php echo esc_html($p['sku']); ?>] <?php echo esc_html($p['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pk01-form-item">
                    <label>Kode SKU <span style="color:#dc2626;">*</span></label>
                    <input type="text" name="sku" id="pk01-sku" class="pk01-input" placeholder="PRD-001" required value="<?php echo esc_attr($_POST['sku'] ?? ''); ?>">
                </div>

                <div class="pk01-form-item">
                    <label>Nama Produk / Varian <span style="color:#dc2626;">*</span></label>
                    <input type="text" name="name" id="pk01-name" class="pk01-input" placeholder="Nama Produk" required value="<?php echo esc_attr($_POST['name'] ?? ''); ?>">
                </div>

                <div class="pk01-form-item">
                    <label>Modal Pokok / HPP (Rp) <span style="color:#dc2626;">*</span></label>
                    <input type="number" step="any" min="0" name="hpp" id="pk01-hpp" class="pk01-input" placeholder="0" required value="<?php echo esc_attr($_POST['hpp'] ?? ''); ?>">
                </div>

                <div class="pk01-form-item">
                    <label>Harga Jual Final (Rp) <span style="color:#dc2626;">*</span></label>
                    <input type="number" step="any" min="1" name="price" id="pk01-price" class="pk01-input" placeholder="150000" required value="<?php echo esc_attr($_POST['price'] ?? ''); ?>">
                </div>

                <div class="pk01-form-item">
                    <label>Kanal Penjualan</label>
                    <select name="channel" id="pk01-channel" class="pk01-input">
                        <option value="direct" data-fee="0">Penjualan Langsung (Toko/WA) — Fee 0%</option>
                        <option value="marketplace" data-fee="8.5">Marketplace (Shopee/Tokopedia) — Fee ~8.5%</option>
                        <option value="third_party" data-fee="12">Mitra Seller / Afiliasi — Fee ~12%</option>
                        <option value="custom" data-fee="0">Kanal Kustom Lainnya</option>
                    </select>
                </div>

                <div class="pk01-form-item">
                    <label>Target Markup dari HPP (%)</label>
                    <input type="number" step="0.1" min="0" name="target_markup_percent" id="pk01-markup" class="pk01-input" value="<?php echo esc_attr($_POST['target_markup_percent'] ?? 30); ?>">
                </div>

                <div class="pk01-form-item">
                    <label>Fee Potongan Kanal (%)</label>
                    <input type="number" step="0.01" min="0" max="99.99" name="fee_percent" id="pk01-fee" class="pk01-input" value="<?php echo esc_attr($_POST['fee_percent'] ?? 0); ?>">
                </div>

                <div class="pk01-form-item">
                    <label>Biaya Kemasan &amp; Handling / Unit (Rp)</label>
                    <input type="number" step="any" min="0" name="selling_cost_fixed" id="pk01-selling-cost" class="pk01-input" value="<?php echo esc_attr($_POST['selling_cost_fixed'] ?? 0); ?>">
                </div>

                <input type="hidden" name="price_source" id="pk01-price-source" value="manual">
                <input type="hidden" name="ai_recommendation" id="pk01-ai-recommendation" value="">

                <!-- LIVE BREAKDOWN SIMULASI HARGA & MARGIN -->
                <div class="pk01-margin-simulation-bar">
                    <div class="pk01-sim-head">
                        <span>📊 Simulasi Alokasi Nilai Harga Jual:</span>
                        <span id="pk01-margin-display" style="font-size:14px;color:#1e3a8a;">Margin Bersih: 0%</span>
                    </div>
                    <div class="pk01-sim-metrics">
                        <div class="pk01-sim-box">
                            <span>Modal HPP:</span>
                            <strong id="sim_hpp_val" style="color:#b45309;">Rp 0</strong>
                        </div>
                        <div class="pk01-sim-box">
                            <span>Fee Kanal Penjualan:</span>
                            <strong id="sim_fee_val" style="color:#dc2626;">Rp 0</strong>
                        </div>
                        <div class="pk01-sim-box">
                            <span>Biaya Kemasan/Handling:</span>
                            <strong id="sim_pack_val" style="color:#475569;">Rp 0</strong>
                        </div>
                        <div class="pk01-sim-box">
                            <span>Estimasi Laba Kotor:</span>
                            <strong id="pk01-profit-display" style="color:#047857;font-size:17px;">Rp 0</strong>
                        </div>
                    </div>
                </div>

                <div class="pk01-form-item">
                    <label>Mulai Berlaku</label>
                    <input type="date" name="valid_from" class="pk01-input" value="<?php echo esc_attr($_POST['valid_from'] ?? current_time('Y-m-d')); ?>" required>
                </div>

                <div class="pk01-form-item" style="grid-column: span 2;">
                    <label>Catatan Alasan Perubahan Harga</label>
                    <input type="text" name="description" class="pk01-input" placeholder="Contoh: Penyesuaian kenaikan harga bahan baku triplek..." value="<?php echo esc_attr($_POST['description'] ?? ''); ?>">
                </div>

                <div style="grid-column: 1 / -1; margin-top: 6px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        <?php echo $is_admin ? '💾 Tetapkan &amp; Aktifkan Harga Resmi' : '📝 Ajukan Perubahan Harga (Approval Admin)'; ?>
                    </button>
                </div>
            </div>
        </form>
    </section>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var pSelect   = document.getElementById('pk01-product-select'),
            sku       = document.getElementById('pk01-sku'),
            name      = document.getElementById('pk01-name'),
            vid       = document.getElementById('pk01-variant-id'),
            hpp       = document.getElementById('pk01-hpp'),
            price     = document.getElementById('pk01-price'),
            markup    = document.getElementById('pk01-markup'),
            fee       = document.getElementById('pk01-fee'),
            fixed     = document.getElementById('pk01-selling-cost'),
            channel   = document.getElementById('pk01-channel'),
            source    = document.getElementById('pk01-price-source'),
            profit    = document.getElementById('pk01-profit-display'),
            margin    = document.getElementById('pk01-margin-display'),
            simHpp    = document.getElementById('sim_hpp_val'),
            simFee    = document.getElementById('sim_fee_val'),
            simPack   = document.getElementById('sim_pack_val');

        function formatRp(n) {
            return 'Rp ' + Math.round(n || 0).toLocaleString('id-ID');
        }

        function calc() {
            var h = parseFloat(hpp?.value) || 0,
                m = parseFloat(markup?.value) || 0,
                f = parseFloat(fee?.value) || 0,
                c = parseFloat(fixed?.value) || 0;

            var raw = f < 100 ? ((h * (1 + m / 100) + c) / (1 - f / 100)) : 0;
            var pr = raw > 0 ? Math.ceil(raw / 1000) * 1000 : 0;

            if (price && document.activeElement !== price && pr > 0) {
                price.value = Math.round(pr);
            }

            var activePrice = parseFloat(price?.value) || pr;
            var feeAmt = activePrice * f / 100;
            var p = activePrice - feeAmt - c - h;

            if (simHpp)  simHpp.textContent  = formatRp(h);
            if (simFee)  simFee.textContent  = formatRp(feeAmt) + ' (' + f + '%)';
            if (simPack) simPack.textContent = formatRp(c);
            if (profit)  profit.textContent  = formatRp(p);

            var pct = activePrice > 0 ? (p / activePrice * 100) : 0;
            if (margin)  margin.textContent  = 'Margin Bersih: ' + pct.toFixed(1) + '%';
        }

        if (channel && fee) {
            channel.addEventListener('change', function() {
                var selectedOpt = this.options[this.selectedIndex];
                var channelFee = selectedOpt.getAttribute('data-fee');
                if (channelFee !== null) {
                    fee.value = channelFee;
                    calc();
                }
            });
        }

        if (pSelect) {
            pSelect.addEventListener('change', function() {
                var o = this.options[this.selectedIndex];
                if (o.value) {
                    sku.value = o.dataset.sku || '';
                    name.value = o.dataset.name || '';
                    vid.value = o.value;
                    hpp.value = o.dataset.hpp || 0;
                    source.value = 'manual';
                    calc();
                }
            });
        }

        [hpp, markup, fee, fixed, price].forEach(function(x) {
            if (x) x.addEventListener('input', function() {
                if (this !== price) source.value = 'manual';
                calc();
            });
        });

        calc();
    });
    </script>
    <?php endif; ?>

</div>

<?php
// 8. TAMPILKAN TABEL MODUL MENGGUNAKAN MULTI-PATH RESOLVER AMAN
$loaded = false;
$candidates = [];

if (defined('PK01_DIR')) {
    $candidates[] = trailingslashit(PK01_DIR) . 'includes/core/view/tampilan-data-modul.php';
}


foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        require_once $cand;
        $loaded = true;
        break;
    }
}

if (function_exists('pk01_tampilkan_data_modul')) {
    pk01_tampilkan_data_modul('pricing', 'Riwayat Harga Jual Produk', 'KEUANGAN & MARGIN', 'Daftar riwayat penetapan harga, HPP, margin keuntungan, dan persetujuan otorisasi.');
} elseif (!$loaded) {
    echo '<div style="background:#ffffff;border:1px dashed #cbd5e1;border-radius:12px;padding:26px;text-align:center;color:#64748b;font-size:13px;">
            📁 Modul antarmuka tabel <code>tampilan-data-modul.php</code> belum ditemukan di folder <code>includes/</code>.
          </div>';
}