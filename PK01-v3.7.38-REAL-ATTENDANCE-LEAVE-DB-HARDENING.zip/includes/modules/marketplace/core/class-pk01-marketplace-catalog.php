<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Marketplace Catalog / Adapter Registry.
 *
 * IMPORTANT: PK01 never claims a marketplace template is official by guessing.
 * An administrator must install the current marketplace template (CSV/XLSX)
 * and map its columns. Seller exports are blocked while a template is not
 * verified. Product content comes from PK01 Theme/E-Commerce source services.
 */
class PK01_Marketplace_Catalog {
    const OPTION_TEMPLATES = 'pk01_marketplace_templates';
    const OPTION_PRICES    = 'pk01_marketplace_seller_prices';

    public static function init() {
        add_action('wp_ajax_pk01_seller_catalog_export', [__CLASS__, 'ajax_export']);
    }

    public static function marketplaces() {
        return [
            'shopee'      => 'Shopee',
            'tokopedia'   => 'Tokopedia',
            'tiktok_shop' => 'TikTok Shop',
            'lazada'      => 'Lazada',
            'generic'     => 'CSV Umum',
        ];
    }

    /**
     * Backward compatible profile accessor. Built-in headers are intentionally
     * marked unverified and are NOT used for production exports.
     */
    public static function profiles() {
        $out = [];
        foreach (self::marketplaces() as $key => $label) {
            $tpl = self::get_template($key);
            $out[$key] = [
                'label'       => $label,
                'format'      => $tpl['format'] ?? 'csv',
                'headers'     => $tpl['headers'] ?? [],
                'verified'    => !empty($tpl['verified']),
                'template_at' => $tpl['updated_at'] ?? '',
                'source'      => $tpl['source'] ?? 'admin_official_template',
            ];
        }
        return $out;
    }

    public static function get_templates() {
        $v = get_option(self::OPTION_TEMPLATES, []);
        return is_array($v) ? $v : [];
    }

    public static function get_template($marketplace) {
        $marketplace = sanitize_key($marketplace);
        $all = self::get_templates();
        $t = isset($all[$marketplace]) && is_array($all[$marketplace]) ? $all[$marketplace] : [];
        return wp_parse_args($t, [
            'marketplace' => $marketplace,
            'label'       => self::marketplaces()[$marketplace] ?? $marketplace,
            'format'      => 'csv',
            'headers'     => [],
            'source_file' => '',
            'verified'    => false,
            'mapping'     => [],
            'required'    => [],
            'source'      => 'admin_official_template',
            'updated_at'  => '',
        ]);
    }

    /** Canonical PK01 fields exposed to marketplace adapters. */
    public static function canonical_fields() {
        return [
            'sku_pk01'       => 'SKU PK01',
            'sku_seller'     => 'SKU Seller/Marketplace',
            'product_name'   => 'Nama Produk',
            'variant_name'   => 'Nama Varian/Model',
            'description'    => 'Deskripsi',
            'category'      => 'Kategori',
            'brand'         => 'Merek',
            'price_buy'     => 'Harga Beli/HPP (INTERNAL - DILARANG EXPORT)',
            'price_seller'  => 'Harga Jual Seller',
            'price_market'  => 'Harga Jual Marketplace',
            'stock'         => 'Stok PK01 Riil',
            'weight'        => 'Berat (gram)',
            'length'        => 'Panjang (cm)',
            'width'         => 'Lebar (cm)',
            'height'        => 'Tinggi (cm)',
            'size'          => 'Ukuran',
            'material'      => 'Material',
            'finishing'     => 'Finishing',
            'image_1'       => 'Gambar 1',
            'image_2'       => 'Gambar 2',
            'image_3'       => 'Gambar 3',
            'image_4'       => 'Gambar 4',
            'image_5'       => 'Gambar 5',
        ];
    }

    public static function source_manifest() {
        return [
            'product_name'  => ['source'=>'PK01_Ecommerce / PK01_Theme_Integration','field'=>'products.name','rule'=>'Master PK01'],
            'description'   => ['source'=>'PK01_Ecommerce / Theme Integration','field'=>'products.description','rule'=>'Master PK01; tidak dibuat AI'],
            'sku_pk01'      => ['source'=>'PK01_Ecommerce','field'=>'product_variants.sku','rule'=>'ID barang utama'],
            'variant_name'  => ['source'=>'PK01_Ecommerce','field'=>'product_variants.name','rule'=>'Varian/model master'],
            'size'          => ['source'=>'PK01_Ecommerce','field'=>'product_variants.size','rule'=>'Tidak boleh ditebak'],
            'material'      => ['source'=>'PK01_Ecommerce','field'=>'product_variants.material','rule'=>'Master PK01'],
            'finishing'     => ['source'=>'PK01_Ecommerce','field'=>'product_variants.finishing','rule'=>'Master PK01'],
            'price_buy'     => ['source'=>'PK01_Ecommerce','field'=>'product_variants.hpp','rule'=>'HPP internal'],
            'stock'         => ['source'=>'PK01_Ecommerce','field'=>'product_variants.stock','rule'=>'Stok riil PK01'],
            'image_1..5'    => ['source'=>'WordPress Media / Theme Integration','field'=>'products.image_id + gallery','rule'=>'URL gambar yang benar-benar tersedia'],
            'price_seller'  => ['source'=>'PK01 seller pricing','field'=>'seller_id + variant_id','rule'=>'Harga seller dapat diedit'],
            'price_market'  => ['source'=>'Seller marketplace pricing','field'=>'seller_id + marketplace + variant_id','rule'=>'Harga marketplace dapat diedit sebelum export'],
        ];
    }

    /**
     * Single source-of-truth health used by all dashboards.
     * It reports where catalog content and stock actually come from; it never invents values.
     */
    public static function source_health() {
        $ecommerce = class_exists('PK01_Ecommerce') && method_exists('PK01_Ecommerce','products');
        $theme = class_exists('PK01_Theme_Integration');
        $templates = [];
        foreach (self::marketplaces() as $mk=>$label) {
            $t=self::get_template($mk);
            $templates[$mk]=['label'=>$label,'ready'=>self::template_is_ready($mk),'format'=>$t['format']??'','source_file'=>$t['source_file']??'','updated_at'=>$t['updated_at']??''];
        }
        return [
            'catalog_service'=>$ecommerce,
            'theme_integration'=>$theme,
            'product_source'=>$ecommerce?'PK01_Ecommerce::products() → PK01 Master':'PK01 Master fallback',
            'image_source'=>'WordPress Media / PK01 product_gallery',
            'stock_source'=>'PK01 stock_transactions; master variant.stock only as opening/fallback',
            'templates'=>$templates,
        ];
    }

    public static function seller_marketplace_prices($seller_id, $marketplace) {
        $all = get_option(self::OPTION_PRICES, []);
        $key = (int)$seller_id . ':' . sanitize_key($marketplace);
        return isset($all[$key]) && is_array($all[$key]) ? $all[$key] : [];
    }

    public static function set_seller_marketplace_price($seller_id, $marketplace, $variant_id, $price) {
        $seller_id=(int)$seller_id; $marketplace=sanitize_key($marketplace); $variant_id=(int)$variant_id;
        if ($seller_id<=0 || $variant_id<=0 || !isset(self::marketplaces()[$marketplace])) return false;
        $all=get_option(self::OPTION_PRICES, []); if(!is_array($all))$all=[];
        $key=$seller_id.':'.$marketplace; if(!isset($all[$key])||!is_array($all[$key]))$all[$key]=[];
        $all[$key][$variant_id]=max(0,(float)$price); return update_option(self::OPTION_PRICES,$all,false);
    }

    private static function image_urls($product) {
        global $wpdb;
        $ids=[];
        if(!empty($product['image_id'])) $ids[]=(int)$product['image_id'];
        if(!empty($product['gallery_ids']) && is_array($product['gallery_ids'])) foreach($product['gallery_ids'] as $id) $ids[]=(int)$id;
        if(!empty($product['id']) && class_exists('PK01_DB')) {
            $gt=PK01_DB::t('product_gallery');
            $gallery=$wpdb->get_col($wpdb->prepare("SELECT attachment_id FROM `{$gt}` WHERE product_id=%d ORDER BY sort_order ASC,id ASC LIMIT 10",(int)$product['id']));
            foreach((array)$gallery as $id) $ids[]=(int)$id;
        }
        $ids=array_values(array_unique(array_filter($ids)));
        $urls=[]; foreach($ids as $id){$u=wp_get_attachment_image_url($id,'large');if($u)$urls[]=$u;}
        return array_slice($urls,0,5);
    }

    /**
     * Build rows from PK01_Ecommerce first, with Theme Integration as the
     * storefront contract. Direct DB is only the final internal fallback.
     */
    public static function rows($seller_id, $marketplace='generic', $variant_ids=[]) {
        global $wpdb;
        $prices=self::seller_marketplace_prices($seller_id,$marketplace);
        $rows=[];
        $data=[];
        if(class_exists('PK01_Ecommerce') && method_exists('PK01_Ecommerce','products')){
            try { $r=PK01_Ecommerce::products(); $data=$r instanceof WP_REST_Response?$r->get_data():$r; } catch(Throwable $e) { $data=[]; }
        }
        if(!is_array($data))$data=[];
        $variant_filter=array_values(array_filter(array_map('absint',(array)$variant_ids)));
        foreach($data as $p){
            $images=self::image_urls($p);
            if(empty($images) && !empty($p['image']))$images=[(string)$p['image']];
            foreach((array)($p['variants']??[]) as $v){
                $vid=(int)($v['id']??0); if($vid<=0)continue;
                if($variant_filter && !in_array($vid,$variant_filter,true)) continue;
                $size=(string)($v['size']??''); $parts=preg_split('/[^0-9]+/',trim($size));$nums=array_values(array_filter($parts,'strlen'));
                $market_price=isset($prices[$vid])?(float)$prices[$vid]:(float)($v['price']??0);
                $seller_price=(class_exists('PK01_Engine')&&method_exists('PK01_Engine','seller_price'))?(float)PK01_Engine::seller_price((int)$seller_id,$vid):(float)($v['price']??0);
                $rows[]=[
                    'variant_id'=>$vid,'sku'=>(string)($v['sku']??''),'product_name'=>(string)($p['name']??''),'variant_name'=>(string)($v['name']??''),'size'=>$size,'material'=>(string)($v['material']??''),'finishing'=>(string)($v['finishing']??''),
                    'price_buy'=>(float)($v['hpp']??0),'price_seller'=>$seller_price,'price_market'=>$market_price,'price'=>$market_price,'stock'=>(float)($v['stock']??0),
                    'description'=>wp_strip_all_tags((string)($p['description']??'')),'images'=>$images,'length'=>(float)($p['length']??($nums[0]??0)),'width'=>(float)($p['width']??($nums[1]??0)),'height'=>(float)($p['height']??($nums[2]??0)),'weight'=>(float)($p['weight']??0),'category'=>(string)($p['category']??''),'brand'=>(string)($p['brand']??''),'seller_sku'=>(string)($v['sku']??''),
                ];
            }
        }
        return $rows;
    }

    private static function map_value($field,$r,$index=0) {
        switch($field){
            case 'sku_pk01':return $r['sku']; case 'sku_seller':return $r['seller_sku']; case 'product_name':return trim($r['product_name'].' '.$r['variant_name']);
            case 'variant_name':return $r['variant_name']; case 'description':return $r['description']; case 'price_buy':return $r['price_buy']; case 'price_seller':return $r['price_seller']; case 'price_market':return $r['price_market']; case 'stock':return $r['stock'];
            case 'size':return $r['size']; case 'category':return $r['category']; case 'brand':return $r['brand']; case 'material':return $r['material']; case 'finishing':return $r['finishing']; case 'length':return $r['length']; case 'width':return $r['width']; case 'height':return $r['height']; case 'weight':return $r['weight'];
            case 'brand':return ''; case 'category':return ''; case 'image_1':case 'image_2':case 'image_3':case 'image_4':case 'image_5':return $r['images'][(int)substr($field,-1)-1]??'';
        }
        return '';
    }

    public static function template_is_ready($marketplace) {
        $t=self::get_template($marketplace); return !empty($t['verified']) && !empty($t['headers']) && !empty($t['mapping']);
    }

    private static function xlsx_escape($v) {
        return htmlspecialchars((string)$v, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }

    private static function export_xlsx($headers,$rows) {
        if(!class_exists('ZipArchive')) throw new Exception('Server tidak memiliki ZipArchive untuk membuat XLSX. Export diblokir agar file tidak rusak.');
        $tmp=wp_tempnam('pk01-marketplace.xlsx'); if(!$tmp) throw new Exception('Tidak dapat membuat file XLSX sementara.');
        $z=new ZipArchive(); if($z->open($tmp,ZipArchive::OVERWRITE)!==true) throw new Exception('XLSX tidak dapat dibuat.');
        $cols=[]; $n=count($headers);
        for($i=0;$i<$n;$i++){ $x=$i+1;$letters=''; while($x>0){$m=($x-1)%26;$letters=chr(65+$m).$letters;$x=intdiv($x-1,26);} $cols[$i]=$letters; }
        $sheet='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
        $sheet.='<row r="1">'; foreach($headers as $i=>$h){$c=$cols[$i].'1';$sheet.='<c r="'.$c.'" t="inlineStr"><is><t>'.self::xlsx_escape($h).'</t></is></c>';} $sheet.='</row>';
        $rr=2; foreach($rows as $row){$sheet.='<row r="'.$rr.'">'; foreach($row as $i=>$v){$c=$cols[$i].$rr; if(is_numeric($v) && $v!==''){$sheet.='<c r="'.$c.'"><v>'.self::xlsx_escape($v).'</v></c>';} else {$sheet.='<c r="'.$c.'" t="inlineStr"><is><t>'.self::xlsx_escape($v).'</t></is></c>';}} $sheet.='</row>'; $rr++; }
        $sheet.='</sheetData></worksheet>';
        $z->addFromString('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
        $z->addFromString('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
        $z->addFromString('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Produk" sheetId="1" r:id="rId1"/></sheets></workbook>');
        $z->addFromString('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
        $z->addFromString('xl/worksheets/sheet1.xml',$sheet); $z->close(); return $tmp;
    }


    /** Marketplace export only uses published, commerce-ready PK01 products. */
    public static function validate_export_rows($rows) {
        $invalid=[];
        foreach ((array)$rows as $r) {
            $missing=[];
            if (trim((string)($r['sku']??''))==='') $missing[]='SKU';
            if (trim((string)($r['product_name']??''))==='') $missing[]='nama';
            if (trim((string)($r['description']??''))==='') $missing[]='deskripsi';
            if ((float)($r['price_market']??0)<=0) $missing[]='harga';
            if (empty($r['images'])) $missing[]='gambar';
            if ($missing) $invalid[]=(string)($r['sku']??'Variant #'.($r['variant_id']??0)).' ['.implode(', ',$missing).']';
        }
        if ($invalid) throw new Exception('Ada produk yang belum siap untuk marketplace: '.implode('; ',array_slice($invalid,0,10)).(count($invalid)>10?' ...':''));
        return true;
    }

    public static function export_csv($seller_id,$marketplace='generic',$variant_ids=[]) {
        $t=self::get_template($marketplace);
        if(!self::template_is_ready($marketplace)) throw new Exception('Template resmi '.$marketplace.' belum dipasang/diverifikasi. Export diblokir agar format marketplace tidak salah.');
        $rows=self::rows($seller_id,$marketplace,$variant_ids); self::validate_export_rows($rows); $lines=[];
        foreach($rows as $r){$line=[]; foreach($t['headers'] as $idx=>$header){$field=$t['mapping'][$idx]??'';$line[]=self::map_value($field,$r,$idx);} $lines[]=$line;}
        $format=strtolower((string)($t['format']??'csv'));
        if($format==='xlsx') { return self::export_xlsx($t['headers'],$lines); }
        $fh=fopen('php://output','w'); fprintf($fh,"\xEF\xBB\xBF"); $delimiter=($format==='tsv')?"\t":','; fputcsv($fh,$t['headers'],$delimiter); foreach($lines as $line) fputcsv($fh,$line,$delimiter); fclose($fh); return true;
    }

    /** Read the first row from CSV/TSV. XLSX is accepted if ZipArchive exists. */
    public static function read_template_headers($file) {
        $name=strtolower((string)($file['name']??'')); $tmp=(string)($file['tmp_name']??''); if(!$tmp||!is_uploaded_file($tmp))throw new Exception('File template tidak valid.');
        $ext=pathinfo($name,PATHINFO_EXTENSION);
        if(in_array($ext,['csv','txt','tsv'],true)){
            $fh=fopen($tmp,'r');$row=fgetcsv($fh,0,$ext==='tsv'?"\t":',');fclose($fh);return array_values(array_map('trim',(array)$row));
        }
        if($ext==='xlsx' && class_exists('ZipArchive')){
            $z=new ZipArchive();if($z->open($tmp)!==true)throw new Exception('XLSX template tidak dapat dibuka.');
            $xml=$z->getFromName('xl/worksheets/sheet1.xml');$shared=$z->getFromName('xl/sharedStrings.xml');$z->close();if(!$xml)throw new Exception('Sheet pertama XLSX tidak ditemukan.');
            $sharedVals=[];if($shared){$sx=simplexml_load_string($shared);foreach($sx->si as $si){$sharedVals[]=implode('',array_map('strval',$si->t));}}
            $sx=simplexml_load_string($xml);$ns=$sx->getNamespaces(true);$sx->registerXPathNamespace('x',$ns['']);$cells=$sx->xpath('//x:sheetData/x:row[1]/x:c');$out=[];
            foreach($cells as $c){$type=(string)$c['t'];$v=isset($c->v)?(string)$c->v:'';$out[]=$type==='s'?($sharedVals[(int)$v]??''):$v;}return $out;
        }
        throw new Exception('Template harus CSV/TSV atau XLSX.');
    }

    public static function auto_map_headers($headers) {
        $aliases=[
            'sku_pk01'=>['sku pk01','pk01 sku','product sku','item sku','sku produk'],
            'sku_seller'=>['sku seller','seller sku','sellersku','seller sku/id','sku marketplace','merchant sku'],
            'product_name'=>['product name','nama produk','name','title','judul produk'],
            'variant_name'=>['variant','nama varian','model','variation','variasi'],
            'description'=>['description','deskripsi','product description','deskripsi produk'],
            'category'=>['category','kategori','category id','kategori produk'], 'brand'=>['brand','merek'],
            'price_market'=>['price','harga','harga jual','selling price','sale price','harga produk'], 'stock'=>['stock','stok','quantity','qty','inventory'],
            'weight'=>['weight','berat','package weight','berat produk'], 'length'=>['length','panjang','package length'], 'width'=>['width','lebar','package width'], 'height'=>['height','tinggi','package height'],
            'image_1'=>['image','image url','main image','mainimage','foto 1','foto utama','gambar 1'], 'image_2'=>['image2','image 2','foto 2','gambar 2'], 'image_3'=>['image3','image 3','foto 3','gambar 3'], 'image_4'=>['image4','image 4','foto 4','gambar 4'], 'image_5'=>['image5','image 5','foto 5','gambar 5'],
        ];
        $mapping=[];foreach($headers as $i=>$h){$n=strtolower(trim(preg_replace('/[^a-z0-9]+/',' ',(string)$h)));$best='';foreach($aliases as $field=>$arr){foreach($arr as $a){$an=strtolower(trim(preg_replace('/[^a-z0-9]+/',' ',$a)));if($n===$an){$best=$field;break 2;}}}$mapping[$i]=$best;}return $mapping;
    }

    public static function save_template($marketplace,$file,$mark_verified=false) {
        $marketplace=sanitize_key($marketplace);if(!isset(self::marketplaces()[$marketplace]))throw new Exception('Marketplace tidak dikenal.');
        $headers=self::read_template_headers($file);if(empty($headers))throw new Exception('Header template kosong.');$mapping=self::auto_map_headers($headers);
        $missing=[];foreach($headers as $i=>$h){if(empty($mapping[$i]))$missing[]=$h;}
        $required_fields=['product_name','description','price_market','stock','image_1'];
        foreach($required_fields as $rf){if(!in_array($rf,$mapping,true))$missing[]='FIELD:'.$rf;}
        $all=self::get_templates();$all[$marketplace]=['marketplace'=>$marketplace,'label'=>self::marketplaces()[$marketplace],'format'=>strtolower(pathinfo($file['name'],PATHINFO_EXTENSION)),'headers'=>$headers,'source_file'=>sanitize_file_name($file['name']),'verified'=>(bool)$mark_verified && empty($missing),'mapping'=>$mapping,'unmapped'=>$missing,'source'=>'admin_official_template','updated_at'=>current_time('mysql')];update_option(self::OPTION_TEMPLATES,$all,false);return $all[$marketplace];
    }

    public static function save_template_mapping($marketplace,$mapping,$verify=false) {
        $marketplace=sanitize_key($marketplace); $all=self::get_templates(); if(empty($all[$marketplace])) throw new Exception('Template belum diupload.');
        $t=$all[$marketplace]; $clean=[]; foreach((array)$mapping as $i=>$field){$clean[(int)$i]=sanitize_key($field); if($clean[(int)$i]==='price_buy') $clean[(int)$i]='';}
        $missing=[]; foreach((array)$t['headers'] as $i=>$h){if(empty($clean[$i]))$missing[]=$h;}
        foreach(['product_name','description','price_market','stock','image_1'] as $rf){if(!in_array($rf,$clean,true))$missing[]='FIELD:'.$rf;}
        $t['mapping']=$clean;$t['unmapped']=$missing;$t['verified']=((bool)$verify && empty($missing));$t['updated_at']=current_time('mysql');$all[$marketplace]=$t;update_option(self::OPTION_TEMPLATES,$all,false);return $t;
    }

    public static function ajax_export(){
        if(!is_user_logged_in())wp_die('Unauthorized',403);if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'pk01_seller_catalog'))wp_die('Sesi tidak valid',403);
        $seller_id=absint($_GET['seller_id']??0);$mp=sanitize_key($_GET['marketplace']??'generic');$variant_ids=[]; if(isset($_GET['variant_ids'])) $variant_ids=array_values(array_filter(array_map('absint',preg_split('/[^0-9]+/',(string)wp_unslash($_GET['variant_ids']))))); if(!$seller_id)wp_die('Seller tidak valid',400);
        try{
            $t=self::get_template($mp); $format=strtolower((string)($t['format']??'csv'));
            if($format==='xlsx'){ $file=self::export_csv($seller_id,$mp,$variant_ids); if(!is_string($file)||!is_file($file)) throw new Exception('File XLSX tidak berhasil dibuat.'); nocache_headers(); header('Content-Type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename=pk01-'.$mp.'-catalog-'.date('Ymd-His').'.xlsx'); readfile($file); @unlink($file); }
            else { nocache_headers(); header('Content-Type:'.($format==='tsv'?'text/tab-separated-values':'text/csv').'; charset=utf-8'); header('Content-Disposition: attachment; filename=pk01-'.$mp.'-catalog-'.date('Ymd-His').'.'.($format==='tsv'?'tsv':'csv')); self::export_csv($seller_id,$mp,$variant_ids); }
        }catch(Throwable $e){status_header(409);header('Content-Type:text/plain; charset=utf-8');echo $e->getMessage();}exit;
    }
}
