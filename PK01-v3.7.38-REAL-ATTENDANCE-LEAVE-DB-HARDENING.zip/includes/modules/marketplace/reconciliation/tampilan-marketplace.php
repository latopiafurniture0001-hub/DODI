<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_month = current_time('Y-m');

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('finance') || PK01_Authorization::can('marketplace')));

// 2. DETEKSI & INISIALISASI TABEL
$get_table = function($key) use ($wpdb) {
    $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
};

$tbl_payouts = $get_table('marketplace_payouts') ?: ($get_table('marketplace') ?: $wpdb->prefix . 'pk01_marketplace_payouts');
$tbl_ledger  = $get_table('cash_ledger');
$tbl_costs   = $get_table('operational_costs');
$tbl_logs    = $get_table('logs') ?: $get_table('activity_logs');

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_payouts)) === $tbl_payouts);

// AUTO-CREATE TABEL MARKETPLACE PAYOUTS JIKA BELUM ADA (MENCEGAH ERROR)
if (!$table_exists) {
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `{$tbl_payouts}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `payout_no` varchar(100) NOT NULL,
        `channel_id` varchar(50) NOT NULL DEFAULT 'shopee',
        `payout_date` date NOT NULL,
        `order_count` int(11) NOT NULL DEFAULT 1,
        `gross` decimal(15,2) NOT NULL DEFAULT 0.00,
        `deductions` decimal(15,2) NOT NULL DEFAULT 0.00,
        `net_received` decimal(15,2) NOT NULL DEFAULT 0.00,
        `account_id` varchar(100) NOT NULL DEFAULT 'BCA Resmi',
        `status` varchar(50) NOT NULL DEFAULT 'completed',
        `notes` text DEFAULT NULL,
        `created_by` bigint(20) unsigned DEFAULT 0,
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `payout_no` (`payout_no`),
        KEY `channel_id` (`channel_id`),
        KEY `payout_date` (`payout_date`)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe($sql);
    $table_exists = true;
}

// 3. LOGIKA BARU: EKSPOR REKONSILIASI PAYOUT KE CSV (AUDIT PAJAK & BANK)
if (isset($_POST['pk01_export_payouts_csv']) && check_admin_referer('pk01_export_payouts_nonce')) {
    if ($can_manage && $table_exists) {
        $export_data = $wpdb->get_results(
            "SELECT payout_no, channel_id, payout_date, order_count, gross, deductions, net_received, account_id, status, notes, created_at
             FROM `{$tbl_payouts}` ORDER BY payout_date DESC, id DESC LIMIT 5000",
            ARRAY_A
        );
        if (!empty($export_data)) {
            $filename = 'pk01-marketplace-payouts-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['No. Payout', 'Kanal Marketplace', 'Tanggal Cair', 'Jml Pesanan', 'Omzet Kotor (Rp)', 'Potongan Admin (Rp)', 'Bersih Diterima (Rp)', 'Rekening Bank', 'Status', 'Catatan', 'Waktu Input']);
            foreach ($export_data as $row) {
                fputcsv($out, [
                    $row['payout_no'],
                    ucfirst($row['channel_id']),
                    $row['payout_date'],
                    $row['order_count'],
                    $row['gross'],
                    $row['deductions'],
                    $row['net_received'],
                    $row['account_id'],
                    $row['status'],
                    $row['notes'],
                    $row['created_at']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3B. INPUT PENJUALAN MARKETPLACE SELLER: harga mengikuti PK01, bukan harga marketplace Seller
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_marketplace_seller_sale'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-op-notice" style="margin-bottom:12px;"><strong>Source of Truth:</strong> Master Produk + SKU + stok PK01. Marketplace hanya channel; harga marketplace Seller dapat berbeda dari harga internal.</div><div class="pk01-mp-alert is-error">Anda tidak memiliki izin untuk mencatat penjualan Seller.</div>';
    } elseif (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_mp_seller_sale_nonce'] ?? '')), 'pk01_marketplace_seller_sale_action')) {
        $notice = '<div class="pk01-mp-alert is-error">Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        try {
            if (!class_exists('PK01_Engine') || !method_exists('PK01_Engine','seller_create_marketplace_sale')) throw new Exception('Mesin penjualan Seller belum tersedia.');
            $r=PK01_Engine::seller_create_marketplace_sale(
                absint($_POST['mp_sale_seller_id']??0), absint($_POST['mp_sale_variant_id']??0), (float)($_POST['mp_sale_qty']??0),
                sanitize_key($_POST['mp_sale_marketplace']??'marketplace'), sanitize_text_field(wp_unslash($_POST['mp_sale_order_no']??'')), sanitize_text_field(wp_unslash($_POST['mp_sale_tracking_no']??'')),
                sanitize_text_field(wp_unslash($_POST['mp_sale_seller_sku']??'')), sanitize_text_field(wp_unslash($_POST['mp_sale_seller_product_name']??'')), sanitize_text_field(wp_unslash($_POST['mp_sale_seller_model']??'')), sanitize_text_field(wp_unslash($_POST['mp_sale_seller_size']??''))
            );
            $notice='<div class="pk01-mp-alert is-success">Penjualan Seller <b>'.esc_html($r['order_no']).'</b> tersimpan. Tagihan dibuat berdasarkan <b>harga internal PK01</b>. Harga Seller di marketplace tidak digunakan.</div>';
        } catch(Throwable $e) { $notice='<div class="pk01-mp-alert is-error">Gagal mencatat penjualan Seller: '.esc_html($e->getMessage()).'</div>'; }
    }
}

// 4. PROSES INPUT REKONSILIASI PENCAIRAN (PAYOUT) MARKETPLACE (LOGIKA LAMA UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_marketplace_payout'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-mp-alert is-error">⚠️ Anda tidak memiliki izin untuk membukukan rekonsiliasi marketplace.</div>';
    } else {
        $nonce = sanitize_text_field(wp_unslash($_POST['pk01_mp_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'pk01_marketplace_payout_action')) {
            $notice = '<div class="pk01-mp-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
        } else {
            $clean_num = function($val) {
                return (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)$val));
            };

            $channel_id   = sanitize_key($_POST['mp_channel'] ?? 'shopee');
            $payout_no    = strtoupper(sanitize_text_field(trim($_POST['mp_payout_no'] ?? '')));
            $payout_date  = sanitize_text_field($_POST['mp_payout_date'] ?? current_time('Y-m-d'));
            $order_count  = max(1, absint($_POST['mp_order_count'] ?? 1));
            $gross        = $clean_num($_POST['mp_gross'] ?? 0);
            $deductions   = $clean_num($_POST['mp_deductions'] ?? 0);
            $account_id   = sanitize_text_field(wp_unslash($_POST['mp_account'] ?? 'Rekening Bank Resmi'));
            $status       = sanitize_key($_POST['mp_status'] ?? 'completed');
            $notes        = sanitize_textarea_field(wp_unslash($_POST['mp_notes'] ?? ''));
            $owner_type   = in_array(sanitize_key($_POST['mp_owner_type'] ?? 'company'), ['company','seller'], true) ? sanitize_key($_POST['mp_owner_type']) : 'company';
            $seller_account_id = absint($_POST['mp_seller_account_id'] ?? 0);
            $user_id      = get_current_user_id();

            // Hitung Dana Bersih Otomatis
            $net_received = max(0, $gross - $deductions);

            // Nomor payout resmi wajib berasal dari registry dokumen PK01. Tidak ada random/dummy.
            if (empty($payout_no)) {
                if (!class_exists('PK01_Engine') || !method_exists('PK01_Engine', 'document_number')) {
                    $notice = '<div class="pk01-mp-alert is-error">Nomor payout belum dapat diterbitkan karena registry dokumen PK01 tidak tersedia.</div>';
                } else {
                    $payout_no = PK01_Engine::document_number('payout');
                }
            }

            if ($gross <= 0) {
                $notice = '<div class="pk01-mp-alert is-error">⚠️ Nominal omzet kotor pesanan harus lebih besar dari Rp 0.</div>';
            } else {
                try {
                    // A-C. PAYOUT + KAS + FEE MELALUI ENGINE, SATU KALI
                    if(!class_exists('PK01_Engine') || !method_exists('PK01_Engine','record_marketplace_payout')) throw new Exception('Mesin marketplace PK01 tidak tersedia.');
                    $payout_id=PK01_Engine::record_marketplace_payout($channel_id,$payout_date,$order_count,$gross,$deductions,$account_id,$status,$notes,$payout_no,$owner_type,$seller_account_id);

                    // D. JABAT TANGAN 3: AUDIT TRAIL LOG
                    if ($tbl_logs && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
                        $wpdb->insert($tbl_logs, [
                            'user_id'     => $user_id,
                            'action'      => 'marketplace_payout_settled',
                            'module'      => 'marketplace',
                            'entity'      => $payout_no,
                            'description' => "Membukukan pencairan {$channel_id}: Kotor Rp " . number_format($gross, 0, ',', '.') . " | Potongan Rp " . number_format($deductions, 0, ',', '.') . " | Masuk Kas Rp " . number_format($net_received, 0, ',', '.'),
                            'created_at'  => current_time('mysql')
                        ]);
                    }

                    $channel_name = ucfirst($channel_id);
                    $success_target = $owner_type === 'seller' ? 'dicatat sebagai monitoring payout Seller; tagihan tetap berasal dari penjualan PK01' : 'masuk ke Buku Kas perusahaan dan menjadi settlement marketplace';
                    $notice = '<div class="pk01-mp-alert is-success">✅ Settlement <b>' . esc_html($channel_name) . ' (' . esc_html($payout_no) . ')</b> berhasil dibukukan. Dana bersih <b>Rp ' . number_format($net_received, 0, ',', '.') . '</b> ' . esc_html($success_target) . '.</div>';
                    $_POST = [];
                } catch (Throwable $e) {
                    $notice = '<div class="pk01-mp-alert is-error">❌ Gagal membukukan payout: ' . esc_html($e->getMessage()) . '</div>';
                }
            }
        }
    }
}

// 5. STATISTIK REKONSILIASI MARKETPLACE RIIL DARI DATABASE
$stat_month = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        SUM(gross) AS total_gross,
        SUM(deductions) AS total_deductions,
        SUM(net_received) AS total_net,
        SUM(order_count) AS total_orders
     FROM `{$tbl_payouts}`
     WHERE DATE_FORMAT(payout_date, '%%Y-%%m') = %s
     AND status = 'completed'",
    $current_month
), ARRAY_A);

$total_gross_month      = (float) ($stat_month['total_gross'] ?? 0);
$total_deductions_month = (float) ($stat_month['total_deductions'] ?? 0);
$total_net_month        = (float) ($stat_month['total_net'] ?? 0);
$total_orders_month     = (int) ($stat_month['total_orders'] ?? 0);

$effective_fee_percent = ($total_gross_month > 0) ? round(($total_deductions_month / $total_gross_month) * 100, 1) : 0;

// Ambil Distribusi Nyata per Kanal Marketplace
$channel_distribution = $wpdb->get_results($wpdb->prepare(
    "SELECT channel_id, SUM(gross) as gross, SUM(deductions) as deductions, SUM(net_received) as net, COUNT(id) as count
     FROM `{$tbl_payouts}`
     WHERE DATE_FORMAT(payout_date, '%%Y-%%m') = %s AND status = 'completed'
     GROUP BY channel_id
     ORDER BY net DESC",
    $current_month
), ARRAY_A) ?: [];

// Ambil Informasi Rekening Bank dari Pengaturan Sentral
$central_settings = (array) get_option('pk01_settings', []);
$bank_account_default = !empty($central_settings['bank_name']) 
    ? $central_settings['bank_name'] . ' - ' . ($central_settings['bank_account_number'] ?? '') . ' (a.n ' . ($central_settings['bank_account_name'] ?? '') . ')'
    : 'BCA Rekening Operasional Perusahaan';

$rp = function($v) {
    return class_exists('PK01_Settings') && method_exists('PK01_Settings', 'money')
        ? PK01_Settings::money($v) 
        : 'Rp ' . number_format((float)$v, 0, ',', '.');
};
?>

<style>
:root {
    --pk-mp-navy: #0f172a;
    --pk-mp-border: #e2e8f0;
    --pk-mp-green: #059669;
    --pk-mp-red: #dc2626;
    --pk-mp-blue: #2563eb;
    --pk-mp-purple: #7c3aed;
    --pk-mp-muted: #64748b;
}

.pk01-marketplace-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-marketplace-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-mp-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-mp-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-mp-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-mp-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-mp-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-mp-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-green::before  { background: var(--pk-mp-green); }
.pk01-kpi-card.c-red::before    { background: var(--pk-mp-red); }
.pk01-kpi-card.c-blue::before   { background: var(--pk-mp-blue); }
.pk01-kpi-card.c-purple::before { background: var(--pk-mp-purple); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: #64748b;
}

/* Multi-Channel Distribution Strip */
.pk01-channel-strip {
    background: #ffffff;
    border: 1px solid var(--pk-mp-border);
    border-radius: 14px;
    padding: 16px 20px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-channel-head {
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: #64748b;
    margin-bottom: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk01-channel-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
}
.pk01-channel-pill {
    background: #f8fafc;
    border: 1px solid var(--pk-mp-border);
    border-radius: 10px;
    padding: 12px 14px;
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.pk01-channel-pill-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    font-weight: 700;
    color: #0f172a;
}
.pk01-channel-pill strong {
    font-size: 16px;
    font-family: monospace;
    color: #047857;
}

/* Form Card */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-mp-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-surface-head p {
    margin: 4px 0 0 0;
    font-size: 13px;
    color: #64748b;
}

/* Form Grid */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    background: #f8fafc;
    color: #0f172a;
}
.pk01-input:focus {
    outline: none;
    border-color: #2563eb;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Fee Estimator Preset Pills */
.pk01-fee-presets {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 4px;
}
.pk01-fee-pill {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 10px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-fee-pill:hover {
    background: #0f172a;
    color: #ffffff;
    border-color: #0f172a;
}

/* Live Calculation Banner */
.pk01-calc-preview {
    grid-column: 1 / -1;
    background: #f0fdf4;
    border: 1px dashed #86efac;
    border-radius: 12px;
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 6px;
}
.pk01-calc-preview span {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    color: #166534;
    display: block;
}
.pk01-calc-preview strong {
    font-size: 22px;
    font-family: monospace;
    color: #047857;
    font-weight: 900;
}

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }

.pk01-mp-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-mp-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-mp-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-marketplace-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-mp-hero">
        <div>
            <span class="pk01-mp-eyebrow">RECONCILIATION &bull; E-COMMERCE SETTLEMENT</span>
            <h1>Penjualan &amp; Payout Marketplace</h1>
            <p>
                Rekonsiliasi pencairan dana dari Shopee, Tokopedia, TikTok Shop, dan Lazada. Memisahkan omzet kotor pesanan, potongan biaya admin platform, 
                serta dana bersih yang masuk ke rekening bank secara presisi.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_payouts_nonce'); ?>
                <input type="hidden" name="pk01_export_payouts_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Payout CSV
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-mp-kpis">
        <div class="pk01-kpi-card c-green">
            <small>Dana Bersih Masuk Rekening</small>
            <strong style="color:#065f46;"><?php echo esc_html($rp($total_net_month)); ?></strong>
            <span>Otomatis menambah saldo Buku Kas</span>
        </div>

        <div class="pk01-kpi-card c-red">
            <small>Total Potongan Biaya Admin</small>
            <strong style="color:#991b1b;">− <?php echo esc_html($rp($total_deductions_month)); ?></strong>
            <span>Rata-rata potongan: <b><?php echo $effective_fee_percent; ?>%</b></span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Omzet Bruto Marketplace</small>
            <strong style="color:#1d4ed8;"><?php echo esc_html($rp($total_gross_month)); ?></strong>
            <span>Total nilai belanja pembeli sebelum fee</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Pesanan Terselesaikan</small>
            <strong style="color:#6d28d9;"><?php echo (int)$total_orders_month; ?> <span style="font-size:13px;font-weight:normal;">Paket</span></strong>
            <span>Periode: <?php echo esc_html(date_i18n('F Y')); ?></span>
        </div>
    </div>

    <!-- 3. REAL BREAKDOWN: DISTRIBUSI PENCAIRAN PER KANAL (MASTERPIECE FEATURE) -->
    <?php if (!empty($channel_distribution)): ?>
    <section class="pk01-channel-strip">
        <div class="pk01-channel-head">
            <span>🛒 Distribusi Pencairan per Kanal Marketplace (Bulan Ini):</span>
            <span>Total Kanal Aktif: <?php echo count($channel_distribution); ?></span>
        </div>
        <div class="pk01-channel-grid">
            <?php foreach ($channel_distribution as $cd): 
                $ch_name = ucfirst($cd['channel_id']);
                $net_val = (float)$cd['net'];
                $ded_val = (float)$cd['deductions'];
                $fee_pct = ($cd['gross'] > 0) ? round(($ded_val / $cd['gross']) * 100, 1) : 0;
            ?>
                <div class="pk01-channel-pill">
                    <div class="pk01-channel-pill-top">
                        <span><?php echo esc_html($ch_name); ?> (<?php echo (int)$cd['count']; ?>x)</span>
                        <span style="font-size:11px;color:#dc2626;font-weight:700;">Fee <?php echo $fee_pct; ?>%</span>
                    </div>
                    <strong><?php echo esc_html($rp($net_val)); ?></strong>
                    <small style="font-size:10px;color:#64748b;">Potongan: <?php echo esc_html($rp($ded_val)); ?></small>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- 3C. PENJUALAN MARKETPLACE SELLER -->
    <?php if ($can_manage): ?>
    <section class="pk01-surface">
        <div class="pk01-surface-head"><div><h3>🛒 Catat Penjualan Seller</h3><p>Masukkan identitas produk seperti yang tampil di marketplace Seller. Data tersebut hanya untuk pencocokan; <b>SKU/Varian PK01 tetap menjadi master barang</b>. Harga tagihan mengikuti harga internal PK01.</p></div></div>
        <form method="post" action="">
            <?php echo wp_nonce_field('pk01_marketplace_seller_sale_action', 'pk01_mp_seller_sale_nonce', true, false); ?>
            <input type="hidden" name="pk01_save_marketplace_seller_sale" value="1">
            <div class="pk01-form-grid">
                <div class="pk01-field-item"><label>Seller *</label><select name="mp_sale_seller_id" class="pk01-input" required><option value="">Pilih Seller...</option><?php foreach($seller_options as $so): ?><option value="<?php echo (int)$so['id']; ?>"><?php echo esc_html(($so['code'] ? $so['code'].' — ' : '').$so['name']); ?></option><?php endforeach; ?></select></div>
                <div class="pk01-field-item"><label>Marketplace *</label><select name="mp_sale_marketplace" class="pk01-input" required><option value="shopee">Shopee</option><option value="tokopedia">Tokopedia</option><option value="tiktok">TikTok Shop</option><option value="lazada">Lazada</option><option value="blibli">Blibli</option><option value="marketplace">Marketplace Lainnya</option></select></div>
                <div class="pk01-field-item"><label>SKU Seller</label><input type="text" name="mp_sale_seller_sku" class="pk01-input" placeholder="SKU/varian dari Seller, jika ada"></div>
                <div class="pk01-field-item"><label>Nama Produk Seller *</label><input type="text" name="mp_sale_seller_product_name" class="pk01-input" placeholder="Nama produk sesuai marketplace"></div>
                <div class="pk01-field-item"><label>Model</label><input type="text" name="mp_sale_seller_model" class="pk01-input" placeholder="Contoh: KAZE 01"></div>
                <div class="pk01-field-item"><label>Ukuran / Varian</label><input type="text" name="mp_sale_seller_size" class="pk01-input" placeholder="Contoh: 120 cm"></div>
                <div class="pk01-field-item"><label>Konfirmasi SKU / Varian PK01 *</label><select name="mp_sale_variant_id" class="pk01-input" required><option value="">Pilih SKU PK01 yang benar...</option><?php $vtab=$get_table('product_variants'); $vrows=$vtab?$wpdb->get_results("SELECT id,sku,name,size,price FROM `{$vtab}` WHERE status='active' ORDER BY name,sku LIMIT 2000",ARRAY_A):[]; foreach($vrows as $vr): ?><option value="<?php echo (int)$vr['id']; ?>"><?php echo esc_html(($vr['sku']?$vr['sku'].' — ':'').$vr['name'].(!empty($vr['size'])?' | '.$vr['size']:'')); ?></option><?php endforeach; ?></select><small style="display:block;margin-top:5px;color:#64748b">Jika nama/SKU Seller berbeda dengan PK01, jangan buat SKU baru. Pilih varian PK01 yang sesuai. Mapping akan disimpan untuk transaksi berikutnya.</small></div>
                <div class="pk01-field-item"><label>Qty *</label><input type="number" name="mp_sale_qty" class="pk01-input" min="0.0001" step="0.0001" value="1" required></div>
                <div class="pk01-field-item"><label>No. Pesanan Marketplace *</label><input type="text" name="mp_sale_order_no" class="pk01-input" required placeholder="Nomor pesanan dari marketplace"></div>
                <div class="pk01-field-item"><label>No. Resi *</label><input type="text" name="mp_sale_tracking_no" class="pk01-input" required placeholder="Nomor resi"></div>
                <div style="grid-column:1/-1"><button class="pk01-btn pk01-btn-primary" type="submit">Simpan & Buat Tagihan</button><small style="display:block;margin-top:7px;color:#64748b">PK01 menyimpan data asli Seller (nama/SKU/model/ukuran), lalu mengikatnya ke satu SKU/Varian PK01. Resi tetap menjadi kunci logistik; alamat tidak diperlukan untuk mencari barang di gudang.</small></div>
            </div>
        </form>
    </section>
    <?php endif; ?>

    <!-- 4. FORM INPUT REKONSILIASI PAYOUT BARU -->
    <?php if ($can_manage): ?>
    <section class="pk01-surface">
        <div class="pk01-surface-head">
            <div>
                <h3>📥 Catat Pencairan Saldo / Payout Marketplace</h3>
                <p>Salin rincian penarikan saldo penjual dari laporan Seller Center (Shopee, Tokopedia, TikTok Shop, dll).</p>
            </div>
            <span style="font-size:11px;background:#f1f5f9;border:1px solid #cbd5e1;padding:4px 10px;border-radius:12px;font-weight:600;color:#475569;">
                Perusahaan: masuk Kas | Seller: menjadi Tagihan
            </span>
        </div>

        <form method="post" action="">
            <?php echo wp_nonce_field('pk01_marketplace_payout_action', 'pk01_mp_nonce', true, false); ?>
            <input type="hidden" name="pk01_save_marketplace_payout" value="1">

            <div class="pk01-form-grid">
                <div class="pk01-field-item">
                    <label>Saluran Marketplace <span style="color:#dc2626;">*</span></label>
                    <select name="mp_channel" id="pk01-mp-channel" class="pk01-input" required>
                        <option value="shopee" data-default-fee="8.5">Shopee Indonesia (~8.5%)</option>
                        <option value="tokopedia" data-default-fee="8.0">Tokopedia (~8.0%)</option>
                        <option value="tiktok" data-default-fee="8.5">TikTok Shop / Tokopedia (~8.5%)</option>
                        <option value="lazada" data-default-fee="7.5">Lazada Indonesia (~7.5%)</option>
                        <option value="blibli" data-default-fee="6.0">Blibli (~6.0%)</option>
                    </select>
                </div>

                <div class="pk01-field-item">
                    <label>Pemilik Dana <span style="color:#dc2626;">*</span></label>
                    <select name="mp_owner_type" id="pk01-mp-owner-type" class="pk01-input" required>
                        <option value="company">Perusahaan — uang masuk rekening perusahaan</option>
                        <option value="seller">Seller — uang masuk rekening Seller, hanya monitoring payout</option>
                    </select>
                </div>

                <div class="pk01-field-item" id="pk01-mp-seller-wrap" style="display:none;">
                    <label>Seller <span style="color:#dc2626;">*</span></label>
                    <select name="mp_seller_account_id" id="pk01-mp-seller" class="pk01-input">
                        <option value="0">Pilih Seller...</option>
                        <?php
                        $seller_table = $get_table('sales_accounts');
                        $seller_options = $seller_table ? ($wpdb->get_results("SELECT id,name,code FROM `{$seller_table}` WHERE type='seller' AND active=1 ORDER BY name ASC", ARRAY_A) ?: []) : [];
                        foreach ($seller_options as $so):
                        ?>
                            <option value="<?php echo (int)$so['id']; ?>"><?php echo esc_html(($so['code'] ? $so['code'].' — ' : '') . $so['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small style="display:block;margin-top:5px;color:#64748b;">Payout Seller hanya dicatat sebagai referensi. Tagihan Seller berasal dari penjualan PK01, bukan dari nominal payout marketplace.</small>
                </div>

                <div class="pk01-field-item">
                    <label>ID Penarikan / No. Payout</label>
                    <input type="text" name="mp_payout_no" class="pk01-input" placeholder="Otomatis sistem jika kosong" style="font-family:monospace;font-weight:700;">
                </div>

                <div class="pk01-field-item">
                    <label>Tanggal Dana Diterima di Bank <span style="color:#dc2626;">*</span></label>
                    <input type="date" name="mp_payout_date" class="pk01-input" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" required>
                </div>

                <div class="pk01-field-item">
                    <label>Jumlah Pesanan Terselesaikan</label>
                    <input type="number" min="1" name="mp_order_count" class="pk01-input" value="1" placeholder="Contoh: 12" required>
                </div>

                <div class="pk01-field-item">
                    <label>Omzet Kotor Penjualan (Rp) <span style="color:#dc2626;">*</span></label>
                    <input type="number" step="any" min="1" name="mp_gross" id="pk01-mp-gross" class="pk01-input" placeholder="Nilai belanja pembeli (cth: 1500000)" required>
                </div>

                <div class="pk01-field-item">
                    <label>Total Potongan Biaya Admin (Rp) <span style="color:#dc2626;">*</span></label>
                    <input type="number" step="any" min="0" name="mp_deductions" id="pk01-mp-deductions" class="pk01-input" placeholder="Admin fee, gratis ongkir dll" required>
                    <div class="pk01-fee-presets">
                        <span style="font-size:10px;color:#64748b;font-weight:700;">Hitung Cepat:</span>
                        <span class="pk01-fee-pill" data-pct="7.5">Fee 7.5%</span>
                        <span class="pk01-fee-pill" data-pct="8.5">Fee 8.5%</span>
                        <span class="pk01-fee-pill" data-pct="10.0">Fee 10%</span>
                        <span class="pk01-fee-pill" data-pct="12.0">Fee 12%</span>
                    </div>
                </div>

                <div class="pk01-field-item" style="grid-column: span 2;">
                    <label>Rekening / Referensi Pencairan <span style="color:#dc2626;">*</span></label>
                    <input type="text" name="mp_account" class="pk01-input" value="<?php echo esc_attr($bank_account_default); ?>" required>
                </div>

                <div class="pk01-field-item">
                    <label>Status Pencairan Dana</label>
                    <select name="mp_status" class="pk01-input">
                        <option value="completed">✅ Berhasil Diterima (Masuk Kas &amp; Beban Operasional)</option>
                        <option value="pending">⏳ Masih Ditransfer (Menunggu Kliring Bank)</option>
                    </select>
                </div>

                <div class="pk01-field-item" style="grid-column: span 2;">
                    <label>Catatan Tambahan (Opsional)</label>
                    <input type="text" name="mp_notes" class="pk01-input" placeholder="Contoh: Batch pesanan tanggal 1-5 September">
                </div>

                <!-- LIVE PREVIEW HASIL DANA BERSIH & PERSENTASE POTONGAN -->
                <div class="pk01-calc-preview">
                    <div>
                        <span>Dana Bersih / Nilai Tagihan:</span>
                        <strong id="pk01-mp-net-display">Rp 0</strong>
                    </div>
                    <div style="text-align:right;">
                        <span style="color:#b91c1c;">Beban Potongan Fee:</span>
                        <div id="pk01-mp-fee-display" style="font-size:16px;font-weight:800;font-family:monospace;color:#dc2626;">0% (- Rp 0)</div>
                    </div>
                </div>

                <div style="grid-column: 1 / -1; margin-top: 8px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        💾 Simpan Settlement Marketplace
                    </button>
                </div>
            </div>
        </form>
    </section>
    <?php endif; ?>

</div>

<!-- LIVE CALCULATOR POTONGAN MARKETPLACE -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var grossInput      = document.getElementById('pk01-mp-gross');
    var deductionsInput = document.getElementById('pk01-mp-deductions');
    var netDisplay      = document.getElementById('pk01-mp-net-display');
    var feeDisplay      = document.getElementById('pk01-mp-fee-display');
    var feePills        = document.querySelectorAll('.pk01-fee-pill');

    function calculateNet() {
        if (!grossInput || !deductionsInput) return;
        var g = parseFloat(grossInput.value) || 0;
        var d = parseFloat(deductionsInput.value) || 0;
        var net = Math.max(0, g - d);
        var feePercent = (g > 0 && d > 0) ? ((d / g) * 100).toFixed(1) : '0';

        if (netDisplay) {
            netDisplay.innerText = 'Rp ' + Math.round(net).toLocaleString('id-ID');
        }
        if (feeDisplay) {
            feeDisplay.innerText = feePercent + '% (- Rp ' + Math.round(d).toLocaleString('id-ID') + ')';
        }
    }

    if (grossInput && deductionsInput) {
        grossInput.addEventListener('input', calculateNet);
        deductionsInput.addEventListener('input', calculateNet);
    }

    if (feePills.length > 0) {
        feePills.forEach(function(pill) {
            pill.addEventListener('click', function() {
                var g = parseFloat(grossInput ? grossInput.value : 0) || 0;
                var pct = parseFloat(this.dataset.pct) || 0;
                if (g > 0 && pct > 0) {
                    var calculatedFee = Math.round(g * (pct / 100));
                    deductionsInput.value = calculatedFee;
                    calculateNet();
                } else {
                    alert('Silakan isi nominal Omzet Kotor terlebih dahulu.');
                    if (grossInput) grossInput.focus();
                }
            });
        });
    }

    var ownerType = document.getElementById('pk01-mp-owner-type');
    var sellerWrap = document.getElementById('pk01-mp-seller-wrap');
    var sellerSelect = document.getElementById('pk01-mp-seller');
    function syncOwnerUI(){
        var isSeller = ownerType && ownerType.value === 'seller';
        if (sellerWrap) sellerWrap.style.display = isSeller ? '' : 'none';
        if (sellerSelect) sellerSelect.required = !!isSeller;
        var account = document.querySelector('[name="mp_account"]');
        if (account && isSeller) { account.value='Rekening Seller (sesuai bukti settlement)'; account.removeAttribute('required'); }
        else if (account) { account.required=true; if(!account.value || account.value.indexOf('Rekening Seller')===0) account.value=<?php echo wp_json_encode($bank_account_default); ?>; }
    }
    if(ownerType) ownerType.addEventListener('change',syncOwnerUI);
    syncOwnerUI();
    calculateNet();
});
</script>

<?php
// 5. TAMPILKAN TABEL MODUL MENGGUNAKAN MULTI-PATH RESOLVER AMAN
$loaded = false;
$candidates = [];

if (defined('PK01_DIR')) {
    $candidates[] = trailingslashit(PK01_DIR) . 'includes/core/view/tampilan-data-modul.php';
}


foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        require_once $cand;
        $loaded = true;
        break;
    }
}

if (function_exists('pk01_tampilkan_data_modul')) {
    pk01_tampilkan_data_modul(
        'marketplace', 
        'Riwayat Pencairan Saldo Marketplace', 
        'REKONSILIASI & PAYOUT', 
        'Daftar riwayat seluruh penarikan dana dari Shopee, Tokopedia, TikTok Shop, dan marketplace lainnya.'
    );
} elseif (!$loaded) {
    echo '<div style="background:#ffffff;border:1px dashed #cbd5e1;border-radius:12px;padding:26px;text-align:center;color:#64748b;font-size:13px;">
            📁 Modul antarmuka tabel <code>tampilan-data-modul.php</code> belum ditemukan di folder <code>includes/</code>.
          </div>';
}