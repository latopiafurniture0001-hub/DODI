# PK01 — Modul Warehouse

Folder canonical: `includes/modules/warehouse/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/warehouse/dashboard/tampilan-gudang.php`
- `includes/modules/warehouse/inbound-supplier/tampilan-terima-supplier.php`
- `includes/modules/warehouse/outbound/tampilan-kirim-barang.php`
- `includes/modules/warehouse/returns/tampilan-retur.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
