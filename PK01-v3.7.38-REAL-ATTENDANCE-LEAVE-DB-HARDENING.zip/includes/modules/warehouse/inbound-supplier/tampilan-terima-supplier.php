<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$T = fn($k) => PK01_DB::t($k); 
$notice = ''; 
$error = ''; 
$print = null;

$role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
if (!(current_user_can('manage_options') || in_array($role, ['pk01_admin', 'pk01_gudang', 'administrator', 'shop_manager'], true))) {
    echo '<div class="pk01-op-card" style="max-width:650px;margin:40px auto;text-align:center"><h2>Akses Terima Barang Supplier</h2><p>Hanya petugas Gudang/Admin yang dapat menerima barang fisik dari supplier.</p></div>';
    return;
}

// ==========================================================================
// 1. PROSES PENERIMAAN BARANG SUPPLIER & UPLOAD BUKTI BON
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_wh_in_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_wh_in_nonce'] ?? '')), 'pk01_wh_in')) {
        $error = 'Sesi keamanan tidak valid. Muat ulang halaman.';
    } else {
        try {
            $a = sanitize_key($_POST['pk01_wh_in_action']);
            if ($a === 'receive_supplier') {
                $mid       = absint($_POST['material_id'] ?? 0);
                $qty       = (float)($_POST['qty'] ?? 0);
                $cost      = (float)($_POST['unit_cost'] ?? 0);
                $paid      = !empty($_POST['paid']);
                $po_id     = absint($_POST['po_id'] ?? 0);
                $manual_sup= absint($_POST['supplier_id'] ?? 0);
                $notes     = sanitize_textarea_field(wp_unslash($_POST['notes'] ?? ''));

                if (!$mid || $qty <= 0) {
                    throw new Exception('Pilih bahan baku dan masukkan jumlah fisik yang diterima secara valid.');
                }

                // 1. INTEGRASI/SALING BERSALAMAN DENGAN DATA PEMBELIAN (PO)
                $supplier_id   = 0;
                $supplier_name = '';
                $po_no         = '';
                $po_total      = 0;

                if ($po_id > 0) {
                    $po_data = $wpdb->get_row($wpdb->prepare(
                        "SELECT po.*, COALESCE(s.name, '') AS supplier_name 
                         FROM `{$T('purchase_orders')}` po 
                         LEFT JOIN `{$T('suppliers')}` s ON s.id = po.supplier_id 
                         WHERE po.id = %d", 
                        $po_id
                    ), ARRAY_A);

                    if (!$po_data) {
                        throw new Exception('Data PO tidak ditemukan dalam database pembelian.');
                    }

                    $supplier_id   = (int)$po_data['supplier_id'];
                    $supplier_name = $po_data['supplier_name'] ?: 'Supplier Terdaftar';
                    $po_no         = $po_data['po_no'];
                    $po_total      = (float)$po_data['total'];
                } else {
                    // Penerimaan Langsung Tanpa PO
                    $supplier_id = $manual_sup;
                    if ($supplier_id > 0) {
                        $supplier_name = (string)$wpdb->get_var($wpdb->prepare("SELECT name FROM `{$T('suppliers')}` WHERE id=%d", $supplier_id));
                    }
                }

                // 2. PROSES UPLOAD BUKTI BON / SURAT JALAN SUPPLIER
                $bon_file_url = '';
                if (!empty($_FILES['bon_file']['name'])) {
                    require_once(ABSPATH . 'wp-admin/includes/file.php');
                    $file_ext = strtolower(pathinfo($_FILES['bon_file']['name'], PATHINFO_EXTENSION));
                    $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];

                    if (!in_array($file_ext, $allowed_exts, true)) {
                        throw new Exception('Format bukti bon tidak didukung. Harap upload format gambar (JPG/PNG) atau PDF.');
                    }

                    $upload_overrides = ['test_form' => false];
                    $movefile = wp_handle_upload($_FILES['bon_file'], $upload_overrides);

                    if ($movefile && !isset($movefile['error'])) {
                        $bon_file_url = esc_url_raw($movefile['url']);
                    } else {
                        throw new Exception('Gagal mengupload berkas bon: ' . ($movefile['error'] ?? 'Kesalahan server.'));
                    }
                }

                // Gabungkan link bukti ke dalam catatan
                $full_notes = trim($notes . ($bon_file_url ? "\n[BUKTI_BON: {$bon_file_url}]" : ''));

                // 3. EKSEKUSI ENGINE STOK & GOODS RECEIPT
                $receipt_no = class_exists('PK01_Engine') ? PK01_Engine::document_number('goods_receipt') : 'WGR-' . current_time('YmdHis');
                PK01_Engine::record_inventory_receipt($mid, $qty, $cost, $paid, $full_notes);

                if (!$wpdb->insert($T('goods_receipts'), [
                    'receipt_no'  => $receipt_no,
                    'po_id'       => $po_id,
                    'material_id' => $mid,
                    'qty'         => $qty,
                    'received_at' => current_time('mysql'),
                    'received_by' => get_current_user_id(),
                    'notes'       => $full_notes
                ])) {
                    throw new Exception($wpdb->last_error ?: 'Data penerimaan supplier gagal disimpan.');
                }
                $goods_receipt_id = (int)$wpdb->insert_id;

                // 4. PENERBITAN DOKUMEN GUDANG RESMI (TUKAR FAKTUR / KONTRABON)
                $doc = PK01_Engine::document_number('warehouse_supplier');
                if (!$wpdb->insert($T('warehouse_documents'), [
                    'doc_no'       => $doc,
                    'doc_type'     => 'supplier_in',
                    'direction'    => 'in',
                    'tracking_no'  => '',
                    'courier_name' => '',
                    'seller_name'  => sanitize_text_field($supplier_name),
                    'order_id'     => 0,
                    'shipment_id'  => 0,
                    'return_id'    => 0,
                    'reference_no' => $receipt_no,
                    'status'       => 'received',
                    'notes'        => 'Diterima fisik oleh gudang. PO: ' . ($po_no ?: '-') . ($bon_file_url ? " | Bukti: {$bon_file_url}" : ''),
                    'created_by'   => get_current_user_id(),
                    'created_at'   => current_time('mysql')
                ])) {
                    throw new Exception($wpdb->last_error ?: 'Tanda terima barang masuk gagal dibuat.');
                }

                // Jika memakai PO, update status PO menjadi received
                if ($po_id > 0) {
                    $wpdb->update($T('purchase_orders'), [
                        'status' => 'received',
                        'updated_at' => current_time('mysql')
                    ], ['id' => $po_id]);
                }

                $material = $wpdb->get_row($wpdb->prepare("SELECT code, name, unit FROM `{$T('materials')}` WHERE id=%d", $mid), ARRAY_A);
                $current_user = wp_get_current_user();

                // 5. DATA TANDA TERIMA / VOUCHER TUKAR FAKTUR
                $print = [
                    'receipt_id'    => $goods_receipt_id,
                    'doc_no'        => $doc,
                    'receipt_no'    => $receipt_no,
                    'po_no'         => $po_no ?: 'Penerimaan Tanpa PO',
                    'po_total'      => $po_total,
                    'supplier_name' => $supplier_name ?: 'Supplier Umum',
                    'material'      => $material['name'] ?? '-',
                    'code'          => $material['code'] ?? '-',
                    'unit'          => $material['unit'] ?? 'Unit',
                    'qty'           => $qty,
                    'cost'          => $cost,
                    'total_cost'    => $qty * $cost,
                    'paid'          => $paid,
                    'bon_url'       => $bon_file_url,
                    'notes'         => $notes,
                    'staff_name'    => $current_user->display_name ?: $current_user->user_login,
                    'date'          => current_time('d/m/Y H:i:s')
                ];

                $notice = 'Barang dari supplier <strong>' . esc_html($supplier_name) . '</strong> berhasil diverifikasi & diterima. Tanda terima tukar faktur siap dicetak.';
            }
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

// Data Master untuk Formulir
$materials = $wpdb->get_results("SELECT id, code, name, unit, cost, stock FROM `{$T('materials')}` ORDER BY name ASC", ARRAY_A) ?: [];
$suppliers = $wpdb->get_results("SELECT id, name FROM `{$T('suppliers')}` WHERE status='active' ORDER BY name ASC", ARRAY_A) ?: [];

// Query PO aktif bersalaman langsung dengan nama Supplier sah
$pos = $wpdb->get_results("
    SELECT po.id, po.po_no, po.supplier_id, po.total, po.status, po.payment_status,
           COALESCE(s.name, 'Supplier Tidak Terdaftar') AS supplier_name
    FROM `{$T('purchase_orders')}` po
    LEFT JOIN `{$T('suppliers')}` s ON s.id = po.supplier_id
    WHERE po.status NOT IN ('cancelled', 'closed', 'received')
    ORDER BY po.id DESC LIMIT 100
", ARRAY_A) ?: [];

$docs = $wpdb->get_results("SELECT * FROM `{$T('warehouse_documents')}` WHERE doc_type='supplier_in' ORDER BY id DESC LIMIT 30", ARRAY_A) ?: [];
?>

<style>
.pkwhin{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#0f172a;max-width:1440px;margin:15px auto 50px}.pkwhin *{box-sizing:border-box}.pkwhin-hero{background:linear-gradient(135deg,#0f172a,#1e293b 65%,#166534);color:#fff;border-radius:18px;padding:26px;margin-bottom:18px}.pkwhin h1{margin:5px 0;font-size:26px}.pkwhin p{color:#cbd5e1}.pkwhin-grid{display:grid;grid-template-columns:1.2fr 1fr;gap:18px}.pkwhin-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:20px}.pkwhin-note{padding:12px 14px;border-radius:10px;background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;font-size:12px;margin-bottom:14px}.pkwhin-ok{padding:12px 14px;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;border-radius:10px;margin-bottom:14px}.pkwhin-err{padding:12px 14px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px;margin-bottom:14px}.pkwhin-form label{font-size:12px;font-weight:700;display:block;margin:6px 0 4px;color:#334155}.pkwhin-form input,.pkwhin-form select,.pkwhin-form textarea{width:100%;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:8px;background:#fff;font-size:13px}.pkwhin-form input[readonly]{background:#f8fafc;color:#64748b;cursor:not-allowed}.pkwhin-btn{border:0;border-radius:8px;padding:12px 18px;background:#059669;color:#fff;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:6px}.pkwhin-btn:hover{background:#047857}.pkwhin-table{width:100%;border-collapse:collapse;font-size:12.5px}.pkwhin-table th,.pkwhin-table td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left}.pkwhin-table th{background:#f8fafc;font-size:11px;text-transform:uppercase;color:#64748b}

/* Style Lembar Tukar Faktur / Tanda Terima Resmi */
.pk-kontrabon{border:2px dashed #059669;border-radius:14px;padding:26px;background:#fff;max-width:760px;margin:24px auto;box-shadow:0 10px 25px -5px rgba(0,0,0,.05)}
.pk-kontrabon-head{text-align:center;border-bottom:2px solid #e2e8f0;padding-bottom:14px;margin-bottom:18px}
.pk-kontrabon-head h2{margin:0;font-size:20px;color:#065f46;letter-spacing:.5px}
.pk-kontrabon-badge{display:inline-block;padding:4px 12px;background:#ecfdf5;color:#047857;border-radius:99px;font-size:11px;font-weight:800;margin-top:6px;border:1px solid #a7f3d0}
.pk-kontrabon-tbl{width:100%;border-collapse:collapse;margin-bottom:18px;font-size:13px}
.pk-kontrabon-tbl td{padding:8px 10px;border-bottom:1px solid #f1f5f9}
.pk-kontrabon-tbl td.lbl{width:35%;color:#64748b;font-weight:600}
.pk-kontrabon-tbl td.val{font-weight:700;color:#0f172a}
.pk-kontrabon-bon{display:flex;align-items:center;gap:12px;background:#f8fafc;padding:10px 14px;border-radius:8px;border:1px solid #e2e8f0;margin-bottom:18px}
.pk-kontrabon-sigs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-top:30px;text-align:center;font-size:11px}
.pk-sig-line{border-top:1px solid #0f172a;margin-top:60px;padding-top:4px;font-weight:700}

/* Print Rules */
@media print{
  body *{visibility:hidden}
  .pk-kontrabon, .pk-kontrabon *{visibility:visible}
  .pk-kontrabon{position:absolute;left:0;top:0;width:100%;border:1px solid #000;box-shadow:none;padding:15px}
  .pk-no-print{display:none !important}
}
@media(max-width:900px){.pkwhin-grid{grid-template-columns:1fr}}
</style>

<div class="pkwhin">
  <div class="pkwhin-hero">
    <small>GUDANG / TERIMA SUPPLIER &amp; KONTRABON</small>
    <h1>📥 Terima Barang dari Supplier</h1>
    <p>Sinkronisasi langsung dengan modul Pembelian (PO). Memvalidasi nama supplier asli dari database dan menerbitkan tanda terima tukar faktur pembayaran.</p>
  </div>

  <?php if($notice):?><div class="pkwhin-ok">✓ <?php echo $notice;?></div><?php endif;?>
  <?php if($error):?><div class="pkwhin-err">✕ <?php echo esc_html($error);?></div><?php endif;?>

  <div class="pkwhin-grid">
    <!-- FORM TERIMA FISIK -->
    <section class="pkwhin-card">
      <h3 style="margin-top:0;">Verifikasi Kedatangan Barang Fisik</h3>
      <div class="pkwhin-note">
        <b>Saling Bersalaman:</b> Pilih PO untuk mencocokkan otomatis nama supplier terdaftar dari modul Pembelian.
      </div>

      <form method="post" enctype="multipart/form-data" class="pkwhin-form">
        <?php wp_nonce_field('pk01_wh_in','pk01_wh_in_nonce');?>
        <input type="hidden" name="pk01_wh_in_action" value="receive_supplier">

        <!-- 1. PILIH PO PEMBELIAN -->
        <label>Pilih Nomor Purchase Order (PO) *</label>
        <select name="po_id" id="pk_po_select" onchange="syncPoWithSupplier(this)">
          <option value="0" data-supplier-id="0" data-supplier-name="-- Penerimaan Langsung (Tanpa PO) --">
            -- Pilih PO Pembelian (Rekomendasi) --
          </option>
          <?php foreach($pos as $po):?>
            <option value="<?php echo (int)$po['id'];?>" 
                    data-supplier-id="<?php echo (int)$po['supplier_id'];?>" 
                    data-supplier-name="<?php echo esc_attr($po['supplier_name']);?>"
                    data-po-total="<?php echo esc_attr($po['total']);?>">
              <?php echo esc_html($po['po_no'].' — '.$po['supplier_name'].' (Rp '.number_format((float)$po['total'],0,',','.').')');?>
            </option>
          <?php endforeach;?>
        </select>

        <!-- 2. NAMA SUPPLIER SAH (BERSALAMAN DENGAN PO) -->
        <label>Nama Supplier Resmi Terdaftar</label>
        <div id="supplier_locked_box" style="display:none;margin-bottom:8px;">
          <input type="text" id="pk_supplier_display" readonly style="font-weight:700;color:#1e40af;background:#eff6ff;border-color:#bfdbfe;">
        </div>
        <div id="supplier_manual_box">
          <select name="supplier_id" id="pk_supplier_select">
            <option value="0">Pilih Supplier Master (Jika Tanpa PO)</option>
            <?php foreach($suppliers as $s):?>
              <option value="<?php echo (int)$s['id'];?>"><?php echo esc_html($s['name']);?></option>
            <?php endforeach;?>
          </select>
        </div>

        <!-- 3. PILIH BAHAN BAKU -->
        <label>Bahan Baku / Komoditas *</label>
        <select name="material_id" required id="pk_material_select" onchange="syncMaterialCost(this)">
          <option value="">-- Pilih Bahan Baku --</option>
          <?php foreach($materials as $m):?>
            <option value="<?php echo (int)$m['id'];?>" data-cost="<?php echo esc_attr($m['cost']);?>" data-unit="<?php echo esc_attr($m['unit']);?>">
              <?php echo esc_html($m['code'].' — '.$m['name'].' (Satuan: '.$m['unit'].')');?>
            </option>
          <?php endforeach;?>
        </select>

        <div class="pkwhin-grid" style="gap:12px;margin-bottom:0;">
          <div>
            <label>Jumlah Fisik Diterima *</label>
            <input type="number" step="0.0001" min="0.0001" name="qty" required placeholder="0.00">
          </div>
          <div>
            <label>Harga Satuan (Rp)</label>
            <input type="number" step="0.01" min="0" name="unit_cost" id="pk_unit_cost" value="0">
          </div>
        </div>

        <!-- 4. UPLOAD BUKTI BON / SURAT JALAN -->
        <label style="color:#047857;">📸 Upload Bukti Bon / Surat Jalan Fisik (Wajib untuk Pembayaran)</label>
        <input type="file" name="bon_file" accept="image/*,.pdf" style="padding:7px;border-style:dashed;">

        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:8px 0 12px;">
          <input type="checkbox" name="paid" value="1" style="width:auto;margin:0;">
          <span>Sudah Dibayar Lunas di Depan (Prepaid)</span>
        </label>

        <label>Catatan Pemeriksaan Fisik Gudang</label>
        <textarea name="notes" rows="2" placeholder="Catatan kondisi kemasan, nomor polisi kendaraan pengantar, dll..."></textarea>

        <button class="pkwhin-btn" style="width:100%;justify-content:center;">
          ✓ Terima Fisik &amp; Terbitkan Tanda Terima Tukar Faktur
        </button>
      </form>
    </section>

    <!-- SOP PEMERIKSAAN & TUKAR PO -->
    <section class="pkwhin-card">
      <h3 style="margin-top:0;">🛡️ Standar Tukar Faktur &amp; Pembayaran</h3>
      <div style="font-size:13px;line-height:1.6;color:#475569;">
        <p><strong>1. Verifikasi Identitas Supplier:</strong> Sistem mengunci nama supplier langsung dari PO aktif. Gudang tidak diperkenankan membuat nama manual/dummy.</p>
        <p><strong>2. Pemeriksaan Fisik:</strong> Hitung kuantitas riil yang diturunkan dari armada supplier, pastikan kemasan utuh.</p>
        <p><strong>3. Lampiran Wajib (Bon/Surat Jalan):</strong> Wajib memfoto bon asli yang dibawa supir/kurir supplier sebagai bukti audit.</p>
        <p><strong>4. Tukar PO ke Pembayaran (Kontrabon):</strong> Tanda terima yang dicetak berfungsi sebagai <em>Good Receipt Note</em> sah bagi supplier untuk menagihkan pencairan dana ke bagian Keuangan/Kasir.</p>
      </div>
    </section>
  </div>

  <!-- TANDA TERIMA SAH / VOUCHER TUKAR FAKTUR PEMBAYARAN -->
  <?php if($print):?>
    <div class="pk-kontrabon">
      <div class="pk-kontrabon-head">
        <h2>TANDA TERIMA BARANG &amp; VOUCHER TUKAR FAKTUR</h2>
        <small>GOODS RECEIPT NOTE (GRN) — BUKTI SAH PENCAIRAN PEMBAYARAN</small><br>
        <span class="pk-kontrabon-badge">STATUS: FISIK DITERIMA GUDANG</span>
      </div>

      <table class="pk-kontrabon-tbl">
        <tr>
          <td class="lbl">No. Dokumen Penerimaan</td>
          <td class="val" style="color:#059669;font-size:15px;"><?php echo esc_html($print['doc_no']);?></td>
        </tr>
        <tr>
          <td class="lbl">Referensi Transaksi</td>
          <td class="val"><?php echo esc_html($print['receipt_no']);?></td>
        </tr>
        <tr style="background:#eff6ff;">
          <td class="lbl" style="color:#1e40af;">No. Purchase Order (PO)</td>
          <td class="val" style="color:#1e40af;font-size:14px;"><?php echo esc_html($print['po_no']);?></td>
        </tr>
        <tr style="background:#f8fafc;">
          <td class="lbl">Nama Supplier Resmi</td>
          <td class="val" style="font-size:14px;"><b><?php echo esc_html($print['supplier_name']);?></b></td>
        </tr>
        <tr>
          <td class="lbl">Bahan Baku Diterima</td>
          <td class="val"><?php echo esc_html($print['material'].' (Kode: '.$print['code'].')');?></td>
        </tr>
        <tr>
          <td class="lbl">Jumlah Kuantitas Fisik</td>
          <td class="val" style="font-size:15px;color:#047857;"><?php echo (float)$print['qty'].' '.esc_html($print['unit']);?></td>
        </tr>
        <tr>
          <td class="lbl">Nilai Satuan / Total</td>
          <td class="val">Rp <?php echo number_format((float)$print['cost'],0,',','.').' / Total: Rp '.number_format((float)$print['total_cost'],0,',','.');?></td>
        </tr>
        <tr>
          <td class="lbl">Status Kasir / Keuangan</td>
          <td class="val">
            <span style="color:<?php echo $print['paid']?'#047857':'#b45309';?>;font-weight:800;">
              <?php echo $print['paid'] ? '✓ SUDAH LUNAS (PREPAID)' : '⏳ SIAP DITUKAR FAKTUR / BELUM DIBAYAR';?>
            </span>
          </td>
        </tr>
        <tr>
          <td class="lbl">Waktu Kedatangan</td>
          <td class="val"><?php echo esc_html($print['date']);?></td>
        </tr>
      </table>

      <!-- LAMPIRAN FOTO BUKTI BON FISIK -->
      <?php if(!empty($print['bon_url'])):?>
        <div class="pk-kontrabon-bon">
          <span style="font-size:20px;">📎</span>
          <div style="flex:1;">
            <strong>Lampiran Bukti Bon / Surat Jalan Supplier:</strong>
            <div style="font-size:11px;color:#64748b;">Berkas fisik telah divalidasi dan diarsipkan secara digital.</div>
          </div>
          <a href="<?php echo esc_url($print['bon_url']);?>" target="_blank" style="padding:6px 12px;background:#059669;color:#fff;text-decoration:none;border-radius:6px;font-size:11px;font-weight:700;">
            Lihat Berkas Foto
          </a>
        </div>
      <?php endif;?>

      <!-- 3 KOLOM TANDA TANGAN UNTUK TUKAR PO KE KASIR/KEUANGAN -->
      <div class="pk-kontrabon-sigs">
        <div>
          <span>Diterima Oleh,</span>
          <div style="font-size:10px;color:#64748b;">(Petugas Gudang)</div>
          <div class="pk-sig-line"><?php echo esc_html($print['staff_name']);?></div>
        </div>
        <div>
          <span>Diserahkan Oleh,</span>
          <div style="font-size:10px;color:#64748b;">(Kurir / Supir Supplier)</div>
          <div class="pk-sig-line"><?php echo esc_html($print['supplier_name']);?></div>
        </div>
        <div>
          <span>Verifikasi Kasir/Finance,</span>
          <div style="font-size:10px;color:#64748b;">(Pencairan Pembayaran PO)</div>
          <div class="pk-sig-line">( ................................... )</div>
        </div>
      </div>

      <div class="pk-no-print" style="margin-top:24px;text-align:center;">
        <?php if (!empty($print['receipt_id']) && function_exists('pk01_print_url')): ?><a class="pkwhin-btn" target="_blank" rel="noopener" href="<?php echo esc_url(pk01_print_url('penerimaan-supplier',(int)$print['receipt_id'])); ?>">🖨️ Cetak PDF Profesional</a><?php endif; ?>
      </div>
    </div>
  <?php endif;?>

  <!-- RIWAYAT DOKUMEN PENERIMAAN -->
  <section class="pkwhin-card" style="margin-top:24px">
    <h3>Riwayat Dokumen Penerimaan Gudang (WGR)</h3>
    <div style="overflow:auto">
      <table class="pkwhin-table">
        <thead>
          <tr>
            <th>Dokumen</th>
            <th>Supplier Resmi</th>
            <th>Referensi GR</th>
            <th>Status</th>
            <th>Waktu Diterima</th>
          </tr>
        </thead>
        <tbody>
          <?php if(empty($docs)):?>
            <tr><td colspan="5" style="text-align:center;color:#94a3b8;">Belum ada riwayat penerimaan barang masuk.</td></tr>
          <?php else:?>
            <?php foreach($docs as $d):?>
              <tr>
                <td><b><?php echo esc_html($d['doc_no']);?></b></td>
                <td><b><?php echo esc_html($d['seller_name']?:'-');?></b></td>
                <td><?php echo esc_html($d['reference_no']?:'-');?></td>
                <td><span style="color:#047857;font-weight:700;"><?php echo esc_html(strtoupper($d['status']));?></span></td>
                <td><?php echo esc_html($d['created_at']);?></td>
              </tr>
            <?php endforeach;?>
          <?php endif;?>
        </tbody>
      </table>
    </div>
  </section>
</div>

<!-- JAVASCRIPT: LOGIKA BERSALAMAN ANTARA PO, SUPPLIER, & HARGA BAHAN -->
<script>
function syncPoWithSupplier(selectEl) {
    var selectedOpt = selectEl.options[selectEl.selectedIndex];
    var supplierId = selectedOpt.getAttribute('data-supplier-id');
    var supplierName = selectedOpt.getAttribute('data-supplier-name');

    var lockedBox = document.getElementById('supplier_locked_box');
    var manualBox = document.getElementById('supplier_manual_box');
    var displayInput = document.getElementById('pk_supplier_display');
    var selectSupplier = document.getElementById('pk_supplier_select');

    if (supplierId && parseInt(supplierId) > 0) {
        // Kunci nama supplier sesuai data resmi PO (Bersalaman)
        lockedBox.style.display = 'block';
        manualBox.style.display = 'none';
        displayInput.value = '✓ ' + supplierName + ' (Terkunci Otomatis dari PO)';
        selectSupplier.value = supplierId;
    } else {
        // Buka pilihan manual jika penerimaan langsung tanpa PO
        lockedBox.style.display = 'none';
        manualBox.style.display = 'block';
        displayInput.value = '';
        selectSupplier.value = '0';
    }
}

function syncMaterialCost(selectEl) {
    var selectedOpt = selectEl.options[selectEl.selectedIndex];
    var cost = selectedOpt.getAttribute('data-cost');
    var costInput = document.getElementById('pk_unit_cost');
    if (cost && parseFloat(cost) > 0 && parseFloat(costInput.value) === 0) {
        costInput.value = parseFloat(cost);
    }
}
</script>
