<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$T = fn($k) => PK01_DB::t($k); 
$notice = ''; 
$error = ''; 
$print = null;

$role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
if (!(current_user_can('manage_options') || in_array($role, ['pk01_admin', 'pk01_gudang', 'administrator', 'shop_manager'], true))) {
    echo '<div style="max-width:900px;margin:18px auto 0;padding:12px 14px;border:1px solid #bfdbfe;background:#eff6ff;border-radius:10px;color:#1e3a8a;font-size:12px"><b>Barcode Internal PK01:</b> dipakai Gudang untuk mencari order dan barang tanpa menunggu AWB kurir. Barcode ini bukan AWB resmi kurir. Saat AWB resmi sudah tersedia, hubungkan ke shipment yang sama agar tracking API dapat berjalan.</div><div class="pk01-op-card" style="max-width:650px;margin:40px auto;text-align:center"><h2>Akses Kirim Barang</h2><p>Hanya petugas Gudang/Admin yang dapat melakukan serah-terima fisik ke kurir.</p></div>';
    return;
}

// PENCARIAN RESI → ORDER → PRODUK (tanpa input ulang)
$resi_lookup=null; $resi_lookup_items=[];
if (isset($_GET['pk01_wh_resi_search'])) {
    $q=strtoupper(sanitize_text_field(wp_unslash($_GET['resi_lookup']??'')));
    if($q!==''){
        $resi_lookup=PK01_Engine::find_shipment_by_scan_code($q);
        if($resi_lookup){
            $order_id=(int)($resi_lookup['sale_id']??0);
            if($order_id){ $o2=$wpdb->get_row($wpdb->prepare("SELECT order_no,customer_name,customer_phone,shipping_address,status order_status,shipping_status FROM `{$T('sales_orders')}` WHERE id=%d",$order_id),ARRAY_A); if($o2)$resi_lookup=array_merge($resi_lookup,$o2); }
        }
        if($resi_lookup && !empty($resi_lookup['sale_id'])){
            $resi_lookup_items=$wpdb->get_results($wpdb->prepare("SELECT soi.variant_id,soi.product_name,soi.qty,soi.unit_price,v.sku FROM `{$T('sales_order_items')}` soi LEFT JOIN `{$T('product_variants')}` v ON v.id=soi.variant_id WHERE soi.order_id=%d ORDER BY soi.id ASC",(int)$resi_lookup['sale_id']),ARRAY_A)?:[];
        }
    }
}

if($resi_lookup){
    echo '<div style="max-width:900px;margin:10px auto;padding:14px;border:1px solid #dbeafe;background:#fff;border-radius:10px;text-align:center"><div style="font-size:12px;color:#64748b;margin-bottom:6px">KODE INTERNAL PK01 — scan di Gudang</div><div style="font-weight:800;font-family:monospace;font-size:16px;margin-bottom:8px">'.esc_html($resi_lookup['internal_shipment_no']??'-').'</div>'.PK01_Engine::internal_barcode_svg($resi_lookup['internal_barcode']??($resi_lookup['internal_shipment_no']??''),52).'<div style="font-size:11px;color:#64748b;margin-top:5px">AWB Kurir: '.esc_html($resi_lookup['tracking_no']?:'Belum tersedia').'</div></div>';
}

// Proses Form Serah Terima
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_wh_out_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_wh_out_nonce'] ?? '')), 'pk01_wh_out')) {
        $error = 'Sesi keamanan tidak valid. Muat ulang halaman.';
    } else {
        try {
            $a = sanitize_key($_POST['pk01_wh_out_action']);
            if ($a === 'attach_awb') {
                $shipment_id=(int)($_POST['shipment_id']??0);
                $awb=strtoupper(sanitize_text_field(wp_unslash($_POST['courier_awb']??'')));
                $cv=sanitize_text_field(wp_unslash($_POST['courier_vendor']??''));
                $svc=sanitize_text_field(wp_unslash($_POST['service']??''));
                if($shipment_id<=0||$awb==='') throw new Exception('Shipment internal dan AWB resmi kurir wajib diisi.');
                $r=PK01_Engine::attach_courier_awb($shipment_id,$awb,$cv,$svc);
                $notice='AWB resmi '.esc_html($awb).' berhasil dihubungkan ke shipment internal '.esc_html($r['internal_shipment_no']??'-').'. PK01 sekarang dapat menjalankan verifikasi/tracking API.';
            } elseif ($a === 'handover') {
                $tracking       = strtoupper(sanitize_text_field(wp_unslash($_POST['tracking_no'] ?? '')));
                $courier_vendor = sanitize_text_field(wp_unslash($_POST['courier_vendor'] ?? ''));
                $driver_name    = sanitize_text_field(wp_unslash($_POST['driver_name'] ?? ''));
                $driver_phone   = sanitize_text_field(wp_unslash($_POST['driver_phone'] ?? ''));
                $driver_plate   = sanitize_text_field(wp_unslash($_POST['driver_plate'] ?? ''));

                if ($tracking === '') {
                    throw new Exception('Scan barcode internal PK01 atau AWB kurir.');
                }
                if ($driver_name === '') {
                    throw new Exception('Nama Kurir / Driver yang mengambil barang wajib diisi!');
                }

                // Format identitas kurir untuk kompatibilitas PK01_Engine
                $courier_full_label = trim(($courier_vendor ? $courier_vendor . ' - ' : '') . $driver_name . ($driver_plate ? " [{$driver_plate}]" : ''));

                // Eksekusi serah terima gudang
                $r = PK01_Engine::warehouse_handover_shipment($tracking, $courier_full_label);

                $handover_doc_id = (int)$wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM `{$T('warehouse_documents')}` WHERE doc_no=%s AND doc_type='outbound_courier' ORDER BY id DESC LIMIT 1",
                    (string)($r['doc_no'] ?? '')
                ));
                $current_user = wp_get_current_user();
                $staff_name = $current_user->display_name ?: $current_user->user_login;

                // Data untuk Tanda Terima Resmi
                $print = [
                    'doc_id'         => $handover_doc_id,
                    'doc_no'         => $r['doc_no'] ?? ('BA-OUT-' . date('Ymd-His')),
                    'tracking_no'    => $r['shipment']['tracking_no'] ?? $tracking,
                    'courier_vendor' => $courier_vendor ?: ($r['courier_name'] ?? '-'),
                    'driver_name'    => $driver_name,
                    'driver_phone'   => $driver_phone ?: '-',
                    'driver_plate'   => $driver_plate ?: '-',
                    'staff_name'     => $staff_name,
                    'seller'         => $r['seller_name'] ?? '-',
                    'recipient'      => $r['shipment']['recipient_name'] ?? '-',
                    'date'           => current_time('d/m/Y H:i:s')
                ];

                $notice = 'Barang berhasil diserahterimakan kepada kurir ' . esc_html($driver_name) . '. Status pengiriman menjadi SHIPPED.';
            }
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$shipments = $wpdb->get_results("SELECT s.*, COALESCE(sa.name, '') seller_name FROM `{$T('shipments')}` s LEFT JOIN `{$T('seller_sales')}` ss ON ss.id=s.seller_sale_id LEFT JOIN `{$T('sales_accounts')}` sa ON sa.id=ss.seller_account_id WHERE (s.tracking_no<>'' OR s.internal_shipment_no<>'' OR s.internal_barcode<>'') ORDER BY s.id DESC LIMIT 100", ARRAY_A) ?: [];
$docs = $wpdb->get_results("SELECT * FROM `{$T('warehouse_documents')}` WHERE doc_type='outbound_courier' ORDER BY id DESC LIMIT 30", ARRAY_A) ?: [];
?>

<style>
.pkwhout{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#0f172a;max-width:1440px;margin:15px auto 50px}.pkwhout *{box-sizing:border-box}.pkwhout-hero{background:linear-gradient(135deg,#0f172a,#1e293b 65%,#1e3a8a);color:#fff;border-radius:18px;padding:26px;margin-bottom:18px}.pkwhout h1{margin:5px 0;font-size:26px}.pkwhout p{color:#cbd5e1}.pkwhout-grid{display:grid;grid-template-columns:1fr 1.4fr;gap:18px}.pkwhout-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:18px}.pkwhout-note{padding:12px 14px;border-radius:10px;background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;font-size:12px;margin-bottom:14px}.pkwhout-ok{padding:12px 14px;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;border-radius:10px;margin-bottom:14px;font-weight:600}.pkwhout-err{padding:12px 14px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px;margin-bottom:14px;font-weight:600}.pkwhout-form label{font-size:12px;font-weight:700;display:block;margin:8px 0 4px;color:#334155}.pkwhout-form input,.pkwhout-form select{width:100%;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:8px;font-size:13px}.pkwhout-btn{border:0;border-radius:8px;padding:12px 18px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:6px}.pkwhout-btn:hover{background:#1d4ed8}.pkwhout-table{width:100%;border-collapse:collapse;font-size:12.5px}.pkwhout-table th,.pkwhout-table td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left}.pkwhout-table th{background:#f8fafc;font-size:11px;text-transform:uppercase;color:#64748b}

/* Style Tanda Terima Fisik (Receipt) */
.pkwhout-receipt-wrap{margin-top:24px}
.pkwhout-receipt{border:2px dashed #94a3b8;border-radius:14px;padding:26px;max-width:720px;background:#fff;margin:0 auto;box-shadow:0 4px 16px rgba(0,0,0,.04)}
.pkwhout-receipt-head{text-align:center;border-bottom:2px solid #e2e8f0;padding-bottom:14px;margin-bottom:16px}
.pkwhout-receipt-head h3{margin:0;font-size:18px;color:#0f172a;letter-spacing:1px}
.pkwhout-receipt-head small{color:#64748b;font-size:12px}
.pkwhout-badge{display:inline-block;padding:3px 10px;border-radius:99px;font-size:11px;font-weight:800;background:#dcfce7;color:#15803d;margin-top:5px}
.pkwhout-receipt-table{width:100%;border-collapse:collapse;margin-bottom:20px;font-size:13px}
.pkwhout-receipt-table td{padding:8px 10px;border-bottom:1px solid #f1f5f9}
.pkwhout-receipt-table td.label{width:35%;color:#64748b;font-weight:600}
.pkwhout-signatures{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:30px;text-align:center;font-size:12px}
.pkwhout-sig-box{border-top:1px solid #0f172a;margin-top:65px;padding-top:6px;font-weight:700}

/* Print Stylesheet */
@media print{
  body *{visibility:hidden}
  .pkwhout-receipt, .pkwhout-receipt *{visibility:visible}
  .pkwhout-receipt{position:absolute;left:0;top:0;width:100%;max-width:100%;border:1px solid #000;box-shadow:none;padding:15px}
  .pkwhout-no-print{display:none !important}
}
@media(max-width:900px){.pkwhout-grid{grid-template-columns:1fr}}
</style>

<div class="pkwhout">
  <div class="pkwhout-hero">
    <small>GUDANG / KIRIM BARANG</small>
    <h1>📤 Kirim Barang ke Kurir</h1>
    <p>Pencatatan fisik serah terima barang ke kurir/driver penjemput beserta bukti tanda terima serah terima resmi.</p>
  </div>

  <?php if ($notice): ?>
    <div class="pkwhout-ok">✓ <?php echo esc_html($notice); ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="pkwhout-err">✕ <?php echo esc_html($error); ?></div>
  <?php endif; ?>

  <section class="pkwhout-card" style="margin-bottom:18px">
    <h3>🔎 Cari Barang Berdasarkan Resi</h3>
    <div class="pkwhout-note">Scan resi yang berasal dari marketplace/kurir atau kode internal PK01. Resi adalah kunci pencarian pengiriman; PK01 mencari order asli lalu menampilkan produk/SKU/qty. Tidak perlu alamat dan tidak mengubah tagihan.</div>
    <form method="get" class="pkwhout-form" style="display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end">
      <input type="hidden" name="page_id" value="<?php echo esc_attr($_GET['page_id']??''); ?>">
      <div><label>Nomor Resi / AWB</label><input name="resi_lookup" value="<?php echo esc_attr($_GET['resi_lookup']??''); ?>" autofocus placeholder="Scan barcode resi..." autocomplete="off"></div>
      <button class="pkwhout-btn" type="submit" name="pk01_wh_resi_search" value="1">🔎 Cari Barang</button>
    </form>
    <?php if(isset($_GET['pk01_wh_resi_search'])): ?>
      <?php if($resi_lookup): ?>
        <div class="pkwhout-ok" style="margin-top:14px"><b><?php echo esc_html($resi_lookup['tracking_no']); ?></b> · <?php echo esc_html(strtoupper($resi_lookup['courier'])); ?> · Order <b><?php echo esc_html($resi_lookup['order_no']?:('#'.$resi_lookup['sale_id'])); ?></b> · Status: <b><?php echo esc_html($resi_lookup['status']); ?></b></div>
        <div style="overflow:auto"><table class="pkwhout-table"><thead><tr><th>SKU</th><th>Nama Produk</th><th>Qty</th><th>Harga Internal</th></tr></thead><tbody>
        <?php foreach($resi_lookup_items as $it): ?><tr><td><?php echo esc_html($it['sku']?:'-'); ?></td><td><b><?php echo esc_html($it['product_name']); ?></b></td><td><?php echo esc_html($it['qty']); ?></td><td>Rp <?php echo number_format((float)$it['unit_price'],0,',','.'); ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
        <div style="margin-top:10px;font-size:12px;color:#64748b"><b>Kode Internal:</b> <?php echo esc_html($resi_lookup['internal_shipment_no'] ?? '-'); ?> · <b>AWB Kurir:</b> <?php echo esc_html($resi_lookup['tracking_no'] ?: 'Belum tersedia'); ?><br><b>Identitas order dan barang diambil langsung dari transaksi PK01. Alamat tidak diperlukan untuk pencarian Gudang.</b></div>
        <?php if (empty($resi_lookup['tracking_no'])): ?>
          <form method="post" class="pkwhout-form" style="margin-top:12px;padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px">
            <?php wp_nonce_field('pk01_wh_out','pk01_wh_out_nonce'); ?>
            <input type="hidden" name="pk01_wh_out_action" value="attach_awb">
            <input type="hidden" name="shipment_id" value="<?php echo esc_attr($resi_lookup['id']); ?>">
            <b>Hubungkan AWB resmi kurir</b>
            <input name="courier_awb" required placeholder="Scan AWB resmi kurir setelah diterbitkan" autocomplete="off">
            <input name="courier_vendor" value="<?php echo esc_attr($resi_lookup['courier']??''); ?>" placeholder="Kurir">
            <input name="service" value="<?php echo esc_attr($resi_lookup['service']??'REG'); ?>" placeholder="Layanan">
            <button class="pkwhout-btn" type="submit">🔗 Simpan AWB &amp; Verifikasi API</button>
          </form>
        <?php endif; ?>
      <?php else: ?>
        <div class="pkwhout-err" style="margin-top:14px">Resi tidak ditemukan pada data Pengiriman PK01. Barang tidak boleh ditebak berdasarkan nomor resi.</div>
      <?php endif; ?>
    <?php endif; ?>
  </section>

  <div class="pkwhout-grid">
    <!-- FORM SERAH TERIMA -->
    <section class="pkwhout-card">
      <h3>Scan Resi & Serah Terima</h3>
      <div class="pkwhout-note">
        <b>Titik resmi SHIPPED:</b> Pastikan kurir benar-benar telah menerima paket sebelum mengonfirmasi serah terima.
      </div>
      
      <form method="post" class="pkwhout-form">
        <?php wp_nonce_field('pk01_wh_out', 'pk01_wh_out_nonce'); ?>
        <input type="hidden" name="pk01_wh_out_action" value="handover">

        <label>Nomor Resi Paket *</label>
        <input name="tracking_no" autofocus required placeholder="Scan barcode nomor resi..." autocomplete="off">

        <label>Ekspedisi / Jasa Pengiriman</label>
        <input name="courier_vendor" list="courier_list" placeholder="Pilih atau ketik ekspedisi (misal: J&T, JNE, SiCepat)">
        <datalist id="courier_list">
          <option value="J&T Express">
          <option value="JNE Express">
          <option value="SiCepat Express">
          <option value="Shopee Xpress (SPX)">
          <option value="Anteraja">
          <option value="Ninja Xpress">
          <option value="GoSend / GrabExpress">
          <option value="Armada Gudang / Toko">
        </datalist>

        <label style="color:#b91c1c;">Nama Kurir / Driver Pengambil *</label>
        <input name="driver_name" required placeholder="Nama lengkap driver yang mengambil barang">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div>
            <label>No. Plat Kendaraan (Opsional)</label>
            <input name="driver_plate" placeholder="Cth: B 1234 ABC">
          </div>
          <div>
            <label>No. HP Driver (Opsional)</label>
            <input name="driver_phone" placeholder="Cth: 0812xxxxxxx">
          </div>
        </div>

        <button class="pkwhout-btn" style="width:100%;justify-content:center;margin-top:10px;">
          🚚 Serah Terima & Buat Tanda Terima
        </button>
      </form>
    </section>

    <!-- PENGIRIMAN TERBARU -->
    <section class="pkwhout-card">
      <h3>Pengiriman Terbaru</h3>
      <div style="overflow:auto;max-height:480px;">
        <table class="pkwhout-table">
          <thead>
            <tr>
              <th>Kode Internal</th><th>AWB Kurir</th>
              <th>Kurir / Penjemput</th>
              <th>Seller</th>
              <th>Penerima</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($shipments)): ?>
              <tr><td colspan="6" style="text-align:center;color:#94a3b8;">Belum ada data pengiriman.</td></tr>
            <?php else: ?>
              <?php foreach (array_slice($shipments, 0, 20) as $s): ?>
                <tr>
                  <td><b><?php echo esc_html($s['internal_shipment_no'] ?: '-'); ?></b></td><td><b><?php echo esc_html($s['tracking_no'] ?: 'Belum tersedia'); ?></b></td>
                  <td><?php echo esc_html($s['courier'] ?: '-'); ?></td>
                  <td><?php echo esc_html($s['seller_name'] ?: '-'); ?></td>
                  <td><?php echo esc_html($s['recipient_name'] ?: '-'); ?></td>
                  <td>
                    <span style="font-weight:700;color:<?php echo ($s['status'] === 'SHIPPED' || ($s['shipping_status'] ?? '') === 'SHIPPED') ? '#15803d' : '#64748b'; ?>">
                      <?php echo esc_html($s['status'] ?: ($s['shipping_status'] ?? '-')); ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <!-- TANDA TERIMA SERAH TERIMA FISIK -->
  <?php if ($print): ?>
    <div class="pkwhout-receipt-wrap">
      <div class="pkwhout-receipt">
        <div class="pkwhout-receipt-head">
          <h3>TANDA TERIMA SERAH TERIMA BARANG</h3>
          <small>GUDANG &rarr; KURIR PENGIRIMAN</small><br>
          <span class="pkwhout-badge">STATUS: RESMI DISERAHKAN (SHIPPED)</span>
        </div>

        <table class="pkwhout-receipt-table">
          <tr>
            <td class="label">No. Dokumen Tanda Terima</td>
            <td><b><?php echo esc_html($print['doc_no']); ?></b></td>
          </tr>
          <tr>
            <td class="label">Waktu Serah Terima</td>
            <td><?php echo esc_html($print['date']); ?></td>
          </tr>
          <tr>
            <td class="label">Nomor Resi Paket</td>
            <td style="font-size:15px;"><b><?php echo esc_html($print['tracking_no']); ?></b></td>
          </tr>
          <tr>
            <td class="label">Ekspedisi</td>
            <td><?php echo esc_html($print['courier_vendor']); ?></td>
          </tr>
          <tr style="background:#f8fafc;">
            <td class="label" style="color:#0f172a;"><b>Nama Kurir / Driver</b></td>
            <td><b style="color:#1e40af;font-size:14px;"><?php echo esc_html($print['driver_name']); ?></b></td>
          </tr>
          <tr>
            <td class="label">No. Kendaraan / Plat</td>
            <td><?php echo esc_html($print['driver_plate']); ?></td>
          </tr>
          <tr>
            <td class="label">Kontak / No. HP Kurir</td>
            <td><?php echo esc_html($print['driver_phone']); ?></td>
          </tr>
          <tr>
            <td class="label">Pengirim (Seller)</td>
            <td><?php echo esc_html($print['seller']); ?></td>
          </tr>
          <tr>
            <td class="label">Penerima Barang</td>
            <td><?php echo esc_html($print['recipient']); ?></td>
          </tr>
          <tr>
            <td class="label">Petugas Gudang (Penyerah)</td>
            <td><?php echo esc_html($print['staff_name']); ?></td>
          </tr>
        </table>

        <!-- KOLOM TANDA TANGAN / PARAF -->
        <div class="pkwhout-signatures">
          <div>
            <div>Diserahkan Oleh,</div>
            <div style="font-size:10px;color:#64748b;">(Petugas Gudang)</div>
            <div class="pkwhout-sig-box"><?php echo esc_html($print['staff_name']); ?></div>
          </div>
          <div>
            <div>Diterima Oleh,</div>
            <div style="font-size:10px;color:#64748b;">(Kurir / Driver Pengambil)</div>
            <div class="pkwhout-sig-box"><?php echo esc_html($print['driver_name']); ?></div>
          </div>
        </div>

        <div class="pkwhout-no-print" style="margin-top:24px;text-align:center;">
          <?php if (!empty($print['doc_id']) && function_exists('pk01_print_url')): ?><a class="pkwhout-btn" target="_blank" rel="noopener" href="<?php echo esc_url(pk01_print_url('serah-terima-kurir',(int)$print['doc_id'])); ?>">🖨️ Cetak PDF Profesional</a><?php endif; ?>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <!-- RIWAYAT DOKUMEN -->
  <section class="pkwhout-card" style="margin-top:24px">
    <h3>Riwayat Dokumen Tanda Terima Outbound</h3>
    <div style="overflow:auto">
      <table class="pkwhout-table">
        <thead>
          <tr>
            <th>Dokumen</th>
            <th>Kode Internal</th><th>AWB Kurir</th>
            <th>Kurir / Pengambil</th>
            <th>Status</th>
            <th>Waktu</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($docs)): ?>
            <tr><td colspan="5" style="text-align:center;color:#94a3b8;">Belum ada dokumen yang dibuat.</td></tr>
          <?php else: ?>
            <?php foreach ($docs as $d): ?>
              <tr>
                <td><b><?php echo esc_html($d['doc_no']); ?></b></td>
                <td><?php echo esc_html($d['tracking_no'] ?: '-'); ?></td>
                <td><?php echo esc_html($d['courier_name'] ?: '-'); ?></td>
                <td><span style="color:#15803d;font-weight:700;"><?php echo esc_html($d['status']); ?></span></td>
                <td><?php echo esc_html($d['created_at']); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</div>