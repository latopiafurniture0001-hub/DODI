<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$T = fn($k) => class_exists('PK01_DB') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;

$notice = '';
$receipt_data = null;
$action = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('returns')
    : esc_url($_SERVER['REQUEST_URI'] ?? '');

// ==========================================================================
// 1. PROSES RETUR, PEMOTONGAN AR SELLER, & DUAL RECEIPT
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_ret_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_ret_nonce'] ?? '')), 'pk01_ret_save')) {
        $notice = '<div class="pk-alert pk-alert-error"><div class="pk-alert-icon">⚠️</div><div>Sesi keamanan tidak valid. Silakan muat ulang halaman.</div></div>';
    } else {
        try {
            $a = sanitize_key($_POST['pk01_ret_action']);
            
            // --------------------------------------------------------------
            // A. GUDANG TERIMA RETUR FISIK (DARI KURIR)
            // --------------------------------------------------------------
            if ($a === 'warehouse_receive') {
                $tracking_no  = sanitize_text_field(wp_unslash($_POST['tracking_no'] ?? ''));
                $courier_name = sanitize_text_field(wp_unslash($_POST['courier_name'] ?? 'Ekspedisi / Kurir'));
                $driver_name  = sanitize_text_field(wp_unslash($_POST['driver_name'] ?? ''));

                if (empty($tracking_no)) {
                    throw new Exception('Silakan scan atau masukkan nomor resi paket retur.');
                }

                // Cari data retur aktif berdasarkan resi
                $return_row = $wpdb->get_row($wpdb->prepare(
                    "SELECT r.*, ri.variant_id, ri.qty, v.sku, v.name AS product_name, 
                            COALESCE(sa.name, '') AS seller_name, sa.id AS seller_acc_id
                     FROM `{$T('returns')}` r
                     LEFT JOIN `{$T('return_items')}` ri ON ri.return_id = r.id
                     LEFT JOIN `{$T('product_variants')}` v ON v.id = ri.variant_id
                     LEFT JOIN `{$T('sales_accounts')}` sa ON sa.id = r.seller_account_id
                     WHERE r.tracking_no = %s 
                     ORDER BY r.id DESC LIMIT 1",
                    $tracking_no
                ), ARRAY_A);

                if (!$return_row) {
                    throw new Exception("Nomor Resi [{$tracking_no}] tidak terdaftar dalam pendaftaran retur PK01.");
                }

                $return_id = (int)$return_row['id'];

                // Eksekusi engine utama jika ada
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'warehouse_receive_return')) {
                    PK01_Engine::warehouse_receive_return($return_id, $tracking_no, $courier_name, '');
                } else {
                    $wpdb->update($T('returns'), [
                        'status' => 'warehouse_received',
                        'updated_at' => current_time('mysql')
                    ], ['id' => $return_id]);
                }

                // ----------------------------------------------------------
                // LOGIKA PRO: PEMOTONGAN AR PENJUALAN SELLER OTOMATIS
                // ----------------------------------------------------------
                $adj_amount = (float)($return_row['seller_adjustment_amount'] ?? 0);
                $seller_id  = (int)($return_row['seller_acc_id'] ?? 0);
                $ar_status  = $return_row['seller_ar_adjustment_status'] ?? '';

                if ($seller_id > 0 && $ar_status !== 'applied') {
                    // Update saldo/AR di akun seller (mengurangi tagihan penjualan)
                    if ($adj_amount > 0) {
                        $wpdb->query($wpdb->prepare(
                            "UPDATE `{$T('sales_accounts')}` 
                             SET current_ar = GREATEST(0, current_ar - %f),
                                 updated_at = %s 
                             WHERE id = %d",
                            $adj_amount, current_time('mysql'), $seller_id
                        ));
                    }

                    // Tandai bahwa pemotongan AR sudah diaplikasikan agar tidak dipotong ganda
                    $wpdb->update($T('returns'), [
                        'seller_ar_adjustment_status'  => 'applied',
                        'seller_adjustment_applied_at' => current_time('mysql')
                    ], ['id' => $return_id]);
                }

                // Ambil staf yang sedang login
                $current_user = wp_get_current_user();
                $staff_name = $current_user->display_name ?: $current_user->user_login;

                // Siapkan data tanda terima ganda
                $receipt_data = [
                    'return_id'   => $return_id,
                    'doc_no'       => (string)($r['doc_no'] ?? $return_row['return_no'] ?? 'RET-'.$return_id),
                    'date'         => current_time('d/m/Y H:i:s'),
                    'tracking_no'  => $tracking_no,
                    'courier_name' => $courier_name,
                    'driver_name'  => $driver_name ?: '-',
                    'qty'          => (float)($return_row['qty'] ?? 1),
                    'sku'          => $return_row['sku'] ?? '-',
                    'product_name' => $return_row['product_name'] ?? 'Barang Retur',
                    'seller_name'  => $return_row['seller_name'] ?: 'Umum / Toko',
                    'adj_amount'   => $adj_amount,
                    'staff_name'   => $staff_name
                ];

                $ar_note = ($adj_amount > 0) 
                    ? ' Tagihan AR Seller <strong>' . esc_html($receipt_data['seller_name']) . '</strong> berhasil dipotong sebesar <strong>Rp ' . number_format($adj_amount, 0, ',', '.') . '</strong>.'
                    : '';

                $notice = '<div class="pk-alert pk-alert-success"><div class="pk-alert-icon">✓</div><div><strong>Paket Retur Diterima!</strong> Resi <code>' . esc_html($tracking_no) . '</code> berhasil dicatat fisik.' . $ar_note . ' Tanda terima Kasir & Kurir siap dicetak di bawah.</div></div>';
            
            // --------------------------------------------------------------
            // B. PENDAFTARAN RENCANA RETUR BARU
            // --------------------------------------------------------------
            } elseif ($a === 'create') {
                $source      = sanitize_text_field(wp_unslash($_POST['source'] ?? 'website'));
                $ref_id      = absint($_POST['ref_id'] ?? 0);
                $variant_id  = absint($_POST['variant_id'] ?? 0);
                $qty         = floatval($_POST['qty'] ?? 1);
                $reason      = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));
                $tracking_no = sanitize_text_field(wp_unslash($_POST['tracking_no'] ?? ''));

                if ($variant_id <= 0) throw new Exception('Silakan pilih SKU / Barang yang akan diretur.');
                if ($qty <= 0) throw new Exception('Jumlah retur harus minimal 1 pcs.');

                if (empty($ref_id)) { PK01_Engine::create_return_by_tracking($tracking_no, $variant_id, $qty, $reason); } else { PK01_Engine::create_return($source === 'seller' ? 'seller_order' : 'sales_order', $ref_id, $variant_id, $qty, $reason, $tracking_no); }
                $notice = '<div class="pk-alert pk-alert-success"><div class="pk-alert-icon">✓</div><div><strong>Pendaftaran Retur Berhasil!</strong> Menunggu kedatangan fisik barang dari kurir.</div></div>';
            
            // --------------------------------------------------------------
            // C. VERIFIKASI FISIK QC OLEH GUDANG
            // --------------------------------------------------------------
            } elseif ($a === 'qc') {
                $return_id = absint($_POST['return_id'] ?? 0);
                $condition = sanitize_key($_POST['condition'] ?? 'good');

                if ($return_id <= 0) throw new Exception('ID Retur tidak valid.');

                PK01_Engine::receive_and_qc_return($return_id, $condition);
                $notice = '<div class="pk-alert pk-alert-success"><div class="pk-alert-icon">✓</div><div><strong>Verifikasi QC Selesai!</strong> Stok telah disinkronkan otomatis (' . ($condition === 'good' ? 'Stok Jadi Siap Jual' : 'Stok Karantina/Rusak') . ').</div></div>';
            }
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error"><div class="pk-alert-icon">✕</div><div><strong>Gagal:</strong> ' . esc_html($e->getMessage()) . '</div></div>';
        }
    }
}

// ==========================================================================
// 2. QUERY DATA DISPLAY & STATISTIK
// ==========================================================================
$returns = $wpdb->get_results(
    "SELECT r.*, ri.variant_id, ri.qty, v.sku, v.name AS product_name,
            COALESCE(sa.name, '') AS seller_name
     FROM `{$T('returns')}` r 
     INNER JOIN `{$T('return_items')}` ri ON ri.return_id = r.id 
     INNER JOIN `{$T('product_variants')}` v ON v.id = ri.variant_id 
     LEFT JOIN `{$T('sales_accounts')}` sa ON sa.id = r.seller_account_id
     ORDER BY r.id DESC 
     LIMIT 50", 
    ARRAY_A
) ?: [];

$variants = $wpdb->get_results(
    "SELECT id, sku, name 
     FROM `{$T('product_variants')}` 
     WHERE status = 'active' 
     ORDER BY name ASC", 
    ARRAY_A
) ?: [];

$kpi_total_retur = count($returns);
$kpi_pending_qc  = 0;
$kpi_done_qc     = 0;
$kpi_total_pcs   = 0;

foreach ($returns as $item) {
    $qty_val = (float)($item['qty'] ?? 0);
    $kpi_total_pcs += $qty_val;
    if (($item['status'] ?? '') === 'completed') {
        $kpi_done_qc++;
    } else {
        $kpi_pending_qc++;
    }
}
?>

<style>
.pk-qc-wrap {
    --pk-primary: #0f172a;
    --pk-accent: #2563eb;
    --pk-accent-hover: #1d4ed8;
    --pk-surface: #ffffff;
    --pk-border: #e2e8f0;
    --pk-text-main: #0f172a;
    --pk-text-muted: #64748b;
    --pk-radius: 14px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: var(--pk-text-main);
    margin-top: 15px;
}
.pk-qc-wrap * { box-sizing: border-box; }

.pk-alert { display: flex; align-items: center; gap: 12px; padding: 14px 18px; border-radius: var(--pk-radius); margin-bottom: 20px; font-size: 14px; line-height: 1.5; }
.pk-alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk-alert-error { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
.pk-alert-icon { font-weight: bold; font-size: 18px; line-height: 1; }

.pk-hero-card {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #1e3a8a 100%);
    color: #fff; border-radius: var(--pk-radius); padding: 24px 28px; margin-bottom: 24px;
    display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap;
}
.pk-hero-eyebrow { background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); font-size: 11px; font-weight: 700; text-transform: uppercase; padding: 4px 10px; border-radius: 6px; }

/* KPI Grid */
.pk-kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 24px; }
.pk-kpi-card { background: var(--pk-surface); border: 1px solid var(--pk-border); border-radius: 12px; padding: 16px 18px; border-left: 4px solid #cbd5e1; }
.pk-kpi-card.c-blue { border-left-color: #3b82f6; }
.pk-kpi-card.c-amber { border-left-color: #f59e0b; background: #fffdf5; }
.pk-kpi-card.c-green { border-left-color: #10b981; }
.pk-kpi-card.c-purple { border-left-color: #8b5cf6; }
.pk-kpi-card small { font-size: 11px; font-weight: 700; text-transform: uppercase; color: var(--pk-text-muted); display: block; }
.pk-kpi-card strong { font-size: 24px; font-weight: 800; color: var(--pk-text-main); display: block; margin: 4px 0 2px 0; }

/* Scan Box Gudang */
.pk-scan-box {
    background: #eff6ff; border: 1.5px solid #bfdbfe; border-radius: var(--pk-radius);
    padding: 20px 24px; margin-bottom: 24px;
}
.pk-scan-box h3 { margin: 0 0 6px 0; font-size: 18px; color: #1e3a8a; }
.pk-scan-box p { margin: 0 0 14px 0; font-size: 13px; color: #1e40af; }
.pk-scan-form { display: grid; grid-template-columns: 1.6fr 1fr 1fr auto; gap: 12px; align-items: end; }
@media(max-width: 900px){ .pk-scan-form { grid-template-columns: 1fr; } }
.pk-scan-form label { font-size: 12px; font-weight: 700; display: block; margin-bottom: 5px; color: #1e3a8a; }
.pk-scan-form input { width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 13px; }

/* Layout Grid Panels */
.pk-main-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 22px; align-items: start; margin-bottom: 26px; }
@media (max-width: 960px) { .pk-main-grid { grid-template-columns: 1fr; } }

.pk-panel { background: var(--pk-surface); border-radius: var(--pk-radius); border: 1px solid var(--pk-border); overflow: hidden; }
.pk-panel-head { padding: 16px 20px; background: #fafbfc; border-bottom: 1px solid var(--pk-border); font-weight: 700; }
.pk-panel-body { padding: 20px; }
.pk-form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; }
.pk-field { display: flex; flex-direction: column; gap: 5px; }
.pk-field.is-wide { grid-column: 1 / -1; }
.pk-field label { font-size: 12px; font-weight: 700; color: #334155; }
.pk-field input, .pk-field select { width: 100%; border: 1px solid var(--pk-border); border-radius: 8px; padding: 9px 12px; font-size: 13px; }
.pk-submit-btn { background: var(--pk-primary); color: #fff; border: 0; font-weight: 700; padding: 12px 20px; border-radius: 8px; cursor: pointer; width: 100%; margin-top: 14px; }

/* DUAL RECEIPT STYLING */
.pk-receipt-container { margin-bottom: 30px; }
.pk-receipt-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media(max-width: 850px){ .pk-receipt-grid { grid-template-columns: 1fr; } }

.pk-receipt-card {
    background: #fff; border: 2px dashed #94a3b8; border-radius: 12px; padding: 20px;
    font-size: 12.5px; position: relative; box-shadow: 0 4px 12px rgba(0,0,0,0.03);
}
.pk-receipt-card.kasir { border-color: #2563eb; background: #fcfdff; }
.pk-receipt-card.kurir { border-color: #059669; background: #fcfdfc; }

.pk-receipt-header { text-align: center; border-bottom: 1.5px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 14px; }
.pk-receipt-tag {
    display: inline-block; font-size: 10px; font-weight: 800; text-transform: uppercase;
    padding: 3px 8px; border-radius: 4px; margin-bottom: 4px;
}
.tag-kasir { background: #dbeafe; color: #1e40af; }
.tag-kurir { background: #dcfce7; color: #166534; }

.pk-receipt-tbl { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
.pk-receipt-tbl td { padding: 6px 0; border-bottom: 1px solid #f1f5f9; }
.pk-receipt-tbl td.lbl { width: 40%; color: #64748b; font-weight: 600; }
.pk-receipt-tbl td.val { font-weight: 700; color: #0f172a; }

.pk-receipt-sigs { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-top: 24px; text-align: center; font-size: 11px; }
.pk-receipt-sigline { border-top: 1px solid #334155; margin-top: 45px; padding-top: 4px; font-weight: 700; }

.pk-btn-print {
    padding: 7px 14px; font-size: 12px; font-weight: 700; border-radius: 6px; cursor: pointer;
    border: 1px solid #cbd5e1; background: #fff; display: inline-flex; align-items: center; gap: 5px;
}
.pk-btn-print:hover { background: #f8fafc; }

/* Table Section */
.pk-table-panel { background: var(--pk-surface); border-radius: var(--pk-radius); border: 1px solid var(--pk-border); overflow: hidden; }
.pk-table-toolbar { padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; background: #fafbfc; border-bottom: 1px solid var(--pk-border); }
.pk-table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
.pk-table th { background: #f8fafc; color: var(--pk-text-muted); font-size: 11px; text-transform: uppercase; padding: 12px 16px; border-bottom: 1px solid var(--pk-border); }
.pk-table td { padding: 12px 16px; border-bottom: 1px solid #f1f5f9; }

/* PRINT RULES */
@media print {
    body * { visibility: hidden !important; }
    .print-target, .print-target * { visibility: visible !important; }
    .print-target { position: absolute; left: 0; top: 0; width: 100% !important; border: 1px solid #000 !important; box-shadow: none !important; }
    .pk-no-print { display: none !important; }
}
</style>

<div class="pk-qc-wrap">
    
    <!-- 1. HERO HEADER -->
    <div class="pk-hero-card pk-no-print">
        <div>
            <span class="pk-hero-eyebrow">QUALITY CONTROL &amp; REKONSILIASI SELLER</span>
            <h2 style="margin:6px 0;font-size:22px;">Retur Barang &amp; Penerimaan Fisik</h2>
            <p style="margin:0;font-size:13px;color:#cbd5e1;">Pencatatan resi kurir, pembuatan tanda terima ganda (Kasir vs Kurir), dan koreksi tagihan AR Seller otomatis.</p>
        </div>
        <div>
            <a class="pk-btn-print" target="_blank" href="<?php echo esc_url(function_exists('pk01_print_url') ? pk01_print_url('retur') : '#'); ?>" style="color:#0f172a;">
                🖨️ Rekap Laporan Retur
            </a>
        </div>
    </div>

    <!-- ALERT NOTIFIKASI -->
    <div class="pk-no-print"><?php echo $notice; ?></div>

    <!-- 2. SCAN CEPAT RETUR MASUK (ACTION UTAMA GUDANG) -->
    <div class="pk-scan-box pk-no-print">
        <h3>📦 Scan / Penerimaan Retur dari Kurir</h3>
        <p>Gudang menerima barang fisik retur dari kurir/ekspedisi (JNE, J&amp;T, SiCepat, dll). Sistem langsung menerbitkan 2 lembar bukti tanda terima dan mengurangi tagihan AR seller.</p>
        <form method="post" action="<?php echo esc_url($action); ?>" class="pk-scan-form">
            <?php wp_nonce_field('pk01_ret_save', 'pk01_ret_nonce'); ?>
            <input type="hidden" name="pk01_ret_action" value="warehouse_receive">

            <div>
                <label>Nomor Resi Retur (Barcode) *</label>
                <input name="tracking_no" autofocus required placeholder="Scan barcode resi retur..." autocomplete="off">
            </div>

            <div>
                <label>Ekspedisi Penyerah</label>
                <input name="courier_name" list="courier_options" placeholder="Pilih / ketik ekspedisi" value="J&T Express">
                <datalist id="courier_options">
                    <option value="J&T Express">
                    <option value="JNE Express">
                    <option value="SiCepat Express">
                    <option value="Shopee Xpress (SPX)">
                    <option value="Ninja Xpress">
                    <option value="Anteraja">
                    <option value="Armada Toko">
                </datalist>
            </div>

            <div>
                <label>Nama Driver Kurir (Opsional)</label>
                <input name="driver_name" placeholder="Nama kurir yang menyerahkan">
            </div>

            <div>
                <button type="submit" class="pk-submit-btn" style="margin:0;padding:11px 18px;background:#2563eb;">
                    ✓ Terima &amp; Buat Bukti
                </button>
            </div>
        </form>
    </div>

    <!-- 3. TAMPILAN TANDA TERIMA GANDA (DUAL RECEIPT DISPLAY) -->
    <?php if ($receipt_data): ?>
    <div class="pk-receipt-container">
        <div class="pk-no-print" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <strong style="font-size:15px;">📄 Bukti Serah Terima Berhasil Dibuat:</strong>
            <?php if (!empty($receipt_data['return_id']) && function_exists('pk01_print_url')): ?><a class="pk-btn-print" target="_blank" rel="noopener" href="<?php echo esc_url(pk01_print_url('retur-terima',(int)$receipt_data['return_id'])); ?>">🖨️ Cetak 2 Salinan PDF Profesional</a><?php endif; ?>
        </div>

        <div class="pk-receipt-grid" id="pk-print-wrapper">
            
            <!-- A. SALINAN KASIR / INTERNAL GUDANG (DETAIL SELLER & POTONGAN AR ADA) -->
            <div class="pk-receipt-card kasir" id="receipt-kasir">
                <div class="pk-receipt-header">
                    <span class="pk-receipt-tag tag-kasir">SALINAN KASIR &amp; AKUNTANSI (INTERNAL)</span>
                    <h4 style="margin:4px 0;font-size:15px;color:#1e3a8a;">TANDA TERIMA RETUR FISIK</h4>
                    <small style="color:#64748b;">No. Dokumen: <?php echo esc_html($receipt_data['doc_no']); ?>-K</small>
                </div>
                <table class="pk-receipt-tbl">
                    <tr><td class="lbl">Tanggal &amp; Waktu</td><td class="val"><?php echo esc_html($receipt_data['date']); ?></td></tr>
                    <tr><td class="lbl">Nomor Resi Paket</td><td class="val" style="color:#2563eb;"><?php echo esc_html($receipt_data['tracking_no']); ?></td></tr>
                    <tr><td class="lbl">Ekspedisi / Kurir</td><td class="val"><?php echo esc_html($receipt_data['courier_name']); ?> (<?php echo esc_html($receipt_data['driver_name']); ?>)</td></tr>
                    <tr style="background:#eff6ff;"><td class="lbl" style="color:#1e40af;">Seller / Pemilik Toko</td><td class="val" style="color:#1e40af;"><?php echo esc_html($receipt_data['seller_name']); ?></td></tr>
                    <tr><td class="lbl">Barang (SKU)</td><td class="val"><?php echo esc_html($receipt_data['product_name']); ?> (<?php echo esc_html($receipt_data['sku']); ?>)</td></tr>
                    <tr><td class="lbl">Kuantitas Fisik</td><td class="val"><?php echo (float)$receipt_data['qty']; ?> pcs</td></tr>
                    <tr style="background:#ecfdf5;"><td class="lbl" style="color:#065f46;">Potong Tagihan AR</td><td class="val" style="color:#047857;">Rp <?php echo number_format($receipt_data['adj_amount'], 0, ',', '.'); ?> (Diterapkan)</td></tr>
                </table>

                <div class="pk-receipt-sigs">
                    <div>
                        <span>Petugas Gudang</span>
                        <div class="pk-receipt-sigline"><?php echo esc_html($receipt_data['staff_name']); ?></div>
                    </div>
                    <div>
                        <span>Kasir / Finance</span>
                        <div class="pk-receipt-sigline">( ............................ )</div>
                    </div>
                </div>

                <div class="pk-no-print" style="margin-top:16px;text-align:right;">
                    
                </div>
            </div>

            <!-- B. SALINAN KURIR (HANYA RESI & JUMLAH FISIK / NAMA SELLER & AR DISEMBUNYIKAN) -->
            <div class="pk-receipt-card kurir" id="receipt-kurir">
                <div class="pk-receipt-header">
                    <span class="pk-receipt-tag tag-kurir">SALINAN KURIR / EKSPEDISI</span>
                    <h4 style="margin:4px 0;font-size:15px;color:#065f46;">BUKTI SERAH TERIMA RETUR</h4>
                    <small style="color:#64748b;">No. Dokumen: <?php echo esc_html($receipt_data['doc_no']); ?>-C</small>
                </div>
                <table class="pk-receipt-tbl">
                    <tr><td class="lbl">Tanggal &amp; Waktu</td><td class="val"><?php echo esc_html($receipt_data['date']); ?></td></tr>
                    <tr><td class="lbl">Nomor Resi Paket</td><td class="val" style="font-size:14px;color:#0f172a;"><?php echo esc_html($receipt_data['tracking_no']); ?></td></tr>
                    <tr><td class="lbl">Ekspedisi Penyerah</td><td class="val"><?php echo esc_html($receipt_data['courier_name']); ?></td></tr>
                    <tr><td class="lbl">Nama Driver</td><td class="val"><?php echo esc_html($receipt_data['driver_name']); ?></td></tr>
                    <tr style="background:#f8fafc;"><td class="lbl" style="font-weight:800;">Jumlah Diterima</td><td class="val" style="font-size:15px;color:#047857;"><b><?php echo (float)$receipt_data['qty']; ?> Koli / Pcs</b></td></tr>
                    <tr><td class="lbl">Kondisi Luar Paket</td><td class="val">Segel / Paket Diterima Utuh</td></tr>
                </table>

                <div class="pk-receipt-sigs">
                    <div>
                        <span>Diterima Gudang</span>
                        <div class="pk-receipt-sigline"><?php echo esc_html($receipt_data['staff_name']); ?></div>
                    </div>
                    <div>
                        <span>Diserahkan Kurir</span>
                        <div class="pk-receipt-sigline"><?php echo esc_html($receipt_data['driver_name'] !== '-' ? $receipt_data['driver_name'] : '( Driver Kurir )'); ?></div>
                    </div>
                </div>

                <div class="pk-no-print" style="margin-top:16px;text-align:right;">
                    
                </div>
            </div>

        </div>
    </div>
    <?php endif; ?>

    <!-- 4. KPI COCKPIT -->
    <div class="pk-kpi-grid pk-no-print">
        <div class="pk-kpi-card c-blue">
            <small>Total Kasus Retur</small>
            <strong><?php echo (int)$kpi_total_retur; ?></strong>
        </div>
        <div class="pk-kpi-card c-amber">
            <small>Menunggu QC Fisik</small>
            <strong style="color:#d97706;"><?php echo (int)$kpi_pending_qc; ?></strong>
        </div>
        <div class="pk-kpi-card c-green">
            <small>Selesai Verifikasi</small>
            <strong style="color:#10b981;"><?php echo (int)$kpi_done_qc; ?></strong>
        </div>
        <div class="pk-kpi-card c-purple">
            <small>Total Kuantitas Fisik</small>
            <strong style="color:#8b5cf6;"><?php echo number_format($kpi_total_pcs); ?> <span style="font-size:13px;font-weight:normal;">pcs</span></strong>
        </div>
    </div>

    <!-- 5. PENDAFTARAN RENCANA RETUR & SOP -->
    <div class="pk-main-grid pk-no-print">
        <div class="pk-panel">
            <div class="pk-panel-head">📋 Registrasi Rencana Retur Baru</div>
            <div class="pk-panel-body">
                <form method="post" action="<?php echo esc_url($action); ?>">
                    <?php wp_nonce_field('pk01_ret_save', 'pk01_ret_nonce'); ?>
                    <input type="hidden" name="pk01_ret_action" value="create">

                    <div class="pk-form-grid">
                        <div class="pk-field">
                            <label>Asal Kanal Retur *</label>
                            <select name="source" required>
                                <option value="website">Website Toko</option>
                                <option value="marketplace">Marketplace (Shopee/Tokopedia/TikTok)</option>
                                <option value="seller">Mitra Seller / Agen</option>
                            </select>
                        </div>
                        <div class="pk-field">
                            <label>Nomor Resi Retur *</label>
                            <input type="text" name="tracking_no" required placeholder="Contoh: JNT123456789">
                        </div>
                        <div class="pk-field is-wide">
                            <label>Pilih SKU Barang Retur *</label>
                            <select name="variant_id" required>
                                <option value="">-- Pilih SKU Produk --</option>
                                <?php foreach ($variants as $v): ?>
                                    <option value="<?php echo (int)$v['id']; ?>"><?php echo esc_html($v['sku'] . ' — ' . $v['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="pk-field">
                            <label>Jumlah Qty *</label>
                            <input type="number" name="qty" min="1" step="1" required value="1">
                        </div>
                        <div class="pk-field">
                            <label>ID Pesanan / Ref (opsional — resi adalah kunci utama)</label>
                            <input type="number" name="ref_id" placeholder="Cth: 1042">
                        </div>
                        <div class="pk-field is-wide">
                            <label>Alasan Retur</label>
                            <input type="text" name="reason" placeholder="Contoh: Salah ukuran / barang lecet">
                        </div>
                    </div>
                    <button type="submit" class="pk-submit-btn">➕ Daftarkan Rencana Retur</button>
                </form>
            </div>
        </div>

        <div class="pk-panel">
            <div class="pk-panel-head">🛡️ Alur &amp; Regulasi Finansial</div>
            <div class="pk-panel-body" style="font-size:12.5px;color:#475569;line-height:1.6;">
                <p style="margin-top:0;">1. <strong>Penerimaan Fisik:</strong> Saat kurir tiba di gudang, petugas meng-input nomor resi pada panel scan biru di atas.</p>
                <p>2. <strong>Potong Tagihan Seller:</strong> Untuk retur Seller, resi/order dicari dari transaksi PK01. Saat Gudang menerima fisik (<em>warehouse_received</em>), nilai harga internal transaksi mengurangi tagihan Seller. Payout marketplace Seller tidak memengaruhi tagihan dan tidak masuk kas perusahaan.</p>
                <p>3. <strong>Tanda Terima 2 Pihak:</strong>
                   <br>- Berikan lembar kurir tanpa informasi finansial/seller.
                   <br>- Simpan lembar kasir untuk rekonsiliasi pembukuan.</p>
                <p style="margin-bottom:0;">4. <strong>Stok Gudang:</strong> Stok baru resmi bertambah setelah verifikasi QC dilakukan.</p>
            </div>
        </div>
    </div>

    <!-- 6. TABEL RIWAYAT RETUR & QC -->
    <div class="pk-table-panel pk-no-print">
        <div class="pk-table-toolbar">
            <div style="font-weight:700;">Riwayat Kasus Retur Masuk</div>
            <input type="text" id="pk-retur-search" placeholder="Cari No Retur, SKU, Resi..." style="padding:6px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:12.5px;">
        </div>

        <div style="overflow-x:auto;">
            <table class="pk-table" id="pk-retur-table">
                <thead>
                    <tr>
                        <th>No Retur / Tgl</th>
                        <th>Seller</th>
                        <th>Barang &amp; SKU</th>
                        <th style="text-align:center;">Qty</th>
                        <th>Resi &amp; Alasan</th>
                        <th>Status AR Seller</th>
                        <th>Status Fisik</th>
                        <th style="text-align:right;">QC Gudang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($returns)): foreach ($returns as $r): 
                        $is_done = (($r['status'] ?? '') === 'completed');
                        $tracking = !empty($r['tracking_no']) ? $r['tracking_no'] : '-';
                        $search_meta = strtolower($r['return_no'] . ' ' . $r['sku'] . ' ' . $r['product_name'] . ' ' . $tracking . ' ' . $r['seller_name']);
                    ?>
                        <tr class="pk-row" data-search="<?php echo esc_attr($search_meta); ?>">
                            <td>
                                <b><?php echo esc_html($r['return_no']); ?></b>
                                <div style="font-size:11px;color:#64748b;"><?php echo esc_html(date('d/m/Y', strtotime($r['created_at']))); ?></div>
                            </td>
                            <td>
                                <b><?php echo esc_html($r['seller_name'] ?: 'Umum / Toko'); ?></b>
                            </td>
                            <td>
                                <div><?php echo esc_html($r['product_name']); ?></div>
                                <code style="font-size:11px;background:#f1f5f9;padding:2px 4px;border-radius:3px;"><?php echo esc_html($r['sku']); ?></code>
                            </td>
                            <td style="text-align:center;font-weight:700;">
                                <?php echo (float)$r['qty']; ?> pcs
                            </td>
                            <td>
                                <span style="font-family:monospace;"><?php echo esc_html($tracking); ?></span>
                                <div style="font-size:11px;color:#64748b;font-style:italic;">"<?php echo esc_html(mb_strimwidth($r['reason'] ?: 'Retur', 0, 30, '...')); ?>"</div>
                            </td>
                            <td>
                                <?php if (($r['seller_ar_adjustment_status'] ?? '') === 'applied'): ?>
                                    <span style="display:inline-block;padding:3px 8px;border-radius:4px;background:#dcfce7;color:#166534;font-size:11px;font-weight:700;">
                                        ✓ AR Dipotong (Rp <?php echo number_format((float)($r['seller_adjustment_amount'] ?? 0), 0, ',', '.'); ?>)
                                    </span>
                                <?php else: ?>
                                    <span style="font-size:11px;color:#94a3b8;">Menunggu Scan Resi</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="display:inline-block;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;background:<?php echo $is_done ? '#dcfce7;color:#166534;' : '#fef3c7;color:#92400e;'; ?>">
                                    <?php echo $is_done ? 'Selesai QC' : (($r['status'] === 'warehouse_received') ? 'Fisik Diterima' : 'Menunggu Barang'); ?>
                                </span>
                            </td>
                            <td style="text-align:right;">
                                <?php if (!$is_done): ?>
                                    <form method="post" action="<?php echo esc_url($action); ?>" style="display:inline-flex;gap:4px;align-items:center;">
                                        <?php wp_nonce_field('pk01_ret_save', 'pk01_ret_nonce'); ?>
                                        <input type="hidden" name="pk01_ret_action" value="qc">
                                        <input type="hidden" name="return_id" value="<?php echo (int)$r['id']; ?>">
                                        <select name="condition" style="padding:4px;font-size:11px;border-radius:4px;">
                                            <option value="good">🟢 Baik</option>
                                            <option value="damaged">🔴 Rusak</option>
                                        </select>
                                        <button type="submit" class="pk-btn-print" style="padding:4px 8px;background:#2563eb;color:#fff;border:0;">QC</button>
                                    </form>
                                <?php else: ?>
                                    <span style="color:#047857;font-weight:700;font-size:11px;">✓ Stok Update</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="8" style="text-align:center;padding:24px;color:#94a3b8;">Belum ada riwayat retur barang.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- SCRIPT UNTUK PENCARIAN & PENCETAKAN TANDA TERIMA MANDIRI -->
<script>
// Live Search Filter Table
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('pk-retur-search');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var query = this.value.toLowerCase().trim();
            var rows = document.querySelectorAll('#pk-retur-table tbody tr.pk-row');
            rows.forEach(function(row) {
                var text = row.getAttribute('data-search') || '';
                row.style.display = (text.indexOf(query) > -1) ? '' : 'none';
            });
        });
    }
});
</script>