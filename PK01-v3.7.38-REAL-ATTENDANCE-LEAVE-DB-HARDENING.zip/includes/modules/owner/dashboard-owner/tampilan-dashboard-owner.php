<?php
if (!defined('ABSPATH')) exit;
if (!is_user_logged_in()) return;
if (class_exists('PK01_Authorization') && !PK01_Authorization::can('dashboard')) return;

global $wpdb;

// 1. HELPER TABEL & URL AMAN
$tbl = function($key) use ($wpdb) {
    $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) ? $t : false;
};

$url_helper = function($slug) {
    if (class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')) {
        return PK01_Shortcodes::frontend_url_public($slug);
    }
    return add_query_arg('pk01_view', $slug, home_url('/'));
};

$orders  = $tbl('sales_orders'); 
$cash    = $tbl('cash_ledger'); 
$costs   = $tbl('operational_costs');
$payroll = $tbl('payroll'); 
$returns = $tbl('returns'); 
$jobs    = $tbl('jobs'); 
$ship    = $tbl('shipments');
$seller  = $tbl('sales_accounts');

$now   = current_time('timestamp'); 
$month = current_time('Y-m'); 
$today = current_time('Y-m-d');
$fmt   = function($n) { return 'Rp ' . number_format((float)$n, 0, ',', '.'); };
$q     = function($sql, $args = []) use ($wpdb) {
    return $args ? $wpdb->get_var($wpdb->prepare($sql, ...$args)) : $wpdb->get_var($sql);
};

// 2. QUERY DATA FINANSIAL & OPERASIONAL REAL
$sales = 0; $hpp = 0; $commission = 0; $orders_count = 0; $paid_orders = 0; $receivable = 0;
if ($orders) {
    $sales        = (float)$q("SELECT COALESCE(SUM(total_amount), 0) FROM `$orders` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal')", [$month]);
    $hpp          = (float)$q("SELECT COALESCE(SUM(hpp * qty), 0) FROM `$orders` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal')", [$month]);
    $commission   = (float)$q("SELECT COALESCE(SUM(commission), 0) FROM `$orders` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal')", [$month]);
    $orders_count = (int)$q("SELECT COUNT(*) FROM `$orders` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal')", [$month]);
    $paid_orders  = (int)$q("SELECT COUNT(*) FROM `$orders` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND payment_status IN ('paid', 'lunas', 'completed') AND status NOT IN ('cancelled', 'batal')", [$month]);
    $receivable   = (float)$q("SELECT COALESCE(SUM(GREATEST(total_amount - COALESCE(paid_amount, 0), 0)), 0) FROM `$orders` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND payment_status NOT IN ('paid', 'lunas', 'completed') AND status NOT IN ('cancelled', 'batal')", [$month]);
}

$cash_in = 0; $cash_out = 0; $cash_balance = 0;
if ($cash) {
    $cash_in      = (float)$q("SELECT COALESCE(SUM(amount), 0) FROM `$cash` WHERE direction = 'in' AND DATE_FORMAT(created_at, '%%Y-%%m') = %s", [$month]);
    $cash_out     = (float)$q("SELECT COALESCE(SUM(amount), 0) FROM `$cash` WHERE direction = 'out' AND DATE_FORMAT(created_at, '%%Y-%%m') = %s", [$month]);
    $cash_balance = (float)$q("SELECT COALESCE(SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END), 0) FROM `$cash`");
}

$op_cost = 0; if ($costs)   $op_cost = (float)$q("SELECT COALESCE(SUM(amount), 0) FROM `$costs` WHERE DATE_FORMAT(cost_date, '%%Y-%%m') = %s", [$month]);
$pay     = 0; if ($payroll) $pay     = (float)$q("SELECT COALESCE(SUM(amount), 0) FROM `$payroll` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status = 'paid'", [$month]);
$refund  = 0; if ($returns) $refund  = (float)$q("SELECT COALESCE(SUM(refund_amount), 0) FROM `$returns` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status IN ('completed', 'refunded', 'paid')", [$month]);

$gross_profit     = $sales - $hpp - $commission - $refund;
$operating_profit = $gross_profit - $op_cost - $pay;
$active_jobs      = 0; if ($jobs) $active_jobs = (int)$q("SELECT COUNT(*) FROM `$jobs` WHERE status NOT IN ('completed', 'selesai', 'cancelled')");
$ship_queue       = 0; if ($ship) $ship_queue  = (int)$q("SELECT COUNT(*) FROM `$ship` WHERE status NOT IN ('delivered', 'completed', 'selesai', 'cancelled')");
$pending_pay      = 0; if ($orders) $pending_pay = (int)$q("SELECT COUNT(*) FROM `$orders` WHERE payment_status NOT IN ('paid', 'lunas', 'completed') AND status NOT IN ('cancelled', 'batal')");

// Metrik Persentase Tambahan
$margin_pct = ($sales > 0) ? round(($operating_profit / $sales) * 100, 1) : 0;
$paid_pct   = ($orders_count > 0) ? round(($paid_orders / $orders_count) * 100) : 0;

// Kalkulasi Bar Visual Laba Rugi
$hpp_pct    = ($sales > 0) ? min(100, round((($hpp + $commission + $refund) / $sales) * 100)) : 0;
$opex_pct   = ($sales > 0) ? min(100, round((($op_cost + $pay) / $sales) * 100)) : 0;
$profit_pct = ($sales > 0 && $operating_profit > 0) ? max(0, 100 - $hpp_pct - $opex_pct) : 0;

// 3. SMART BUSINESS RADAR SIGNALS
$signals = [];
if ($receivable > 0) {
    $signals[] = ['type' => 'warning', 'icon' => '⚠️', 'title' => 'Piutang Belum Tertagih', 'text' => $fmt($receivable) . ' masih tertahan pada pesanan bulan berjalan.', 'url' => $url_helper('sales_hub')];
}
if ($operating_profit < 0) {
    $signals[] = ['type' => 'danger', 'icon' => '🚨', 'title' => 'Margin Laba Tertekan', 'text' => 'Total HPP, pengeluaran operasional, dan gaji melebihi omzet yang tercatat.', 'url' => $url_helper('finance_hub')];
}
if ($pending_pay > 0) {
    $signals[] = ['type' => 'warning', 'icon' => '⏳', 'title' => 'Menunggu Pelunasan Pembayaran', 'text' => $pending_pay . ' pesanan sedang menunggu konfirmasi pembayaran atau transfer.', 'url' => $url_helper('sales_hub')];
}
if ($active_jobs > 0) {
    $signals[] = ['type' => 'info', 'icon' => '⚙️', 'title' => 'Produksi Sedang Berjalan', 'text' => $active_jobs . ' antrean SPK aktif di lantai kerja. Pantau kapasitas dan deadline.', 'url' => $url_helper('production_hub')];
}
if ($ship_queue > 0) {
    $signals[] = ['type' => 'info', 'icon' => '🚚', 'title' => 'Antrean Pengiriman Barang', 'text' => $ship_queue . ' paket sedang dalam proses pengiriman atau persiapan kurir.', 'url' => $url_helper('shipping_hub')];
}
if (!$signals) {
    $signals[] = ['type' => 'success', 'icon' => '🛡️', 'title' => 'Kondisi Operasional Stabil', 'text' => 'Seluruh parameter kas, piutang, antrean pesanan, dan produksi dalam batas aman.', 'url' => $url_helper('dashboard')];
}

$ai_prompt = "Analisis bisnis pemilik periode " . wp_date('F Y', $now) . ". Omzet: {$fmt($sales)}, Laba Bersih: {$fmt($operating_profit)}, Kas Masuk: {$fmt($cash_in)}, Kas Keluar: {$fmt($cash_out)}, Piutang: {$fmt($receivable)}, Saldo Kas: {$fmt($cash_balance)}, Antrean SPK: {$active_jobs}, Pengiriman: {$ship_queue}. Berikan 3 evaluasi prioritas strategis.";
$ai_url = $url_helper('ai_assistant');
$ai_url = add_query_arg('pk01_ai_prompt', rawurlencode($ai_prompt), $ai_url);
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
    --pk-elevated:  0 12px 24px -4px rgb(0 0 0 / 0.08), 0 4px 8px -2px rgb(0 0 0 / 0.04);
}

.pk01-dash-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-dash-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Glassmorphism */
.pk01-dash-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 24px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 25px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 760px;
    line-height: 1.5;
}
.pk01-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-cockpit-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulse 2s infinite;
}
@keyframes pkPulse {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 6 KPI Cards Deck */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 14px;
    margin-bottom: 24px;
}
@media (max-width: 1200px) { .pk01-kpi-deck { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 680px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 16px 18px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.pk01-kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--pk-elevated);
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; height: 3.5px;
}
.pk01-kpi-card.c-indigo::before  { background: var(--pk-indigo); }
.pk01-kpi-card.c-emerald::before { background: var(--pk-emerald); }
.pk01-kpi-card.c-amber::before   { background: var(--pk-amber); }
.pk01-kpi-card.c-rose::before    { background: var(--pk-rose); }
.pk01-kpi-card.c-sky::before     { background: var(--pk-sky); }
.pk01-kpi-card.c-dark::before    { background: var(--pk-slate-900); }

.pk01-kpi-head {
    font-size: 11px;
    font-weight: 700;
    color: var(--pk-slate-600);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk01-kpi-val {
    font-size: 20px;
    font-weight: 800;
    color: var(--pk-slate-900);
    margin: 8px 0 4px;
    word-break: break-word;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}
.pk01-kpi-foot {
    font-size: 11.5px;
    color: var(--pk-slate-600);
    display: flex;
    align-items: center;
    gap: 4px;
}
.pk01-pill-stat {
    font-size: 10.5px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
}
.pill-green { background: #ecfdf5; color: #065f46; }
.pill-amber { background: #fffbeb; color: #92400e; }
.pill-red   { background: #fef2f2; color: #991b1b; }

/* 3. Main Split Grid */
.pk01-split-grid {
    display: grid;
    grid-template-columns: 1.55fr 1fr;
    gap: 22px;
    margin-bottom: 24px;
    align-items: start;
}
@media (max-width: 1024px) { .pk01-split-grid { grid-template-columns: 1fr; } }

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 22px 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 16px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-tag {
    font-size: 11px;
    font-weight: 700;
    color: var(--pk-indigo);
    text-transform: uppercase;
    letter-spacing: 0.8px;
}

/* AI Action Button */
.pk01-ai-launcher {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: #ffffff !important;
    text-decoration: none !important;
    font-size: 12.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 8px;
    transition: all 0.2s ease;
    box-shadow: 0 2px 6px rgba(79, 70, 229, 0.25);
}
.pk01-ai-launcher:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 10px rgba(79, 70, 229, 0.35);
}

/* Radar Signals List */
.pk01-signal-feed {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 12px;
}
.pk01-signal-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    border-left: 4px solid;
    gap: 14px;
    transition: background 0.15s ease;
}
.pk01-signal-box.warning { border-left-color: #f59e0b; background: #fffbeb; border-color: #fef3c7; }
.pk01-signal-box.danger  { border-left-color: #ef4444; background: #fef2f2; border-color: #fee2e2; }
.pk01-signal-box.info    { border-left-color: #0284c7; background: #f0f9ff; border-color: #e0f2fe; }
.pk01-signal-box.success { border-left-color: #10b981; background: #ecfdf5; border-color: #d1fae5; }

.pk01-signal-desc strong {
    font-size: 13.5px;
    font-weight: 750;
    color: #0f172a;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 2px;
}
.pk01-signal-desc p {
    margin: 0;
    font-size: 12.5px;
    color: #475569;
    line-height: 1.4;
}
.pk01-signal-btn {
    font-size: 12px;
    font-weight: 700;
    text-decoration: none !important;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    color: #0f172a;
    padding: 5px 12px;
    border-radius: 6px;
    white-space: nowrap;
    transition: all 0.15s;
}
.pk01-signal-btn:hover { background: #f8fafc; border-color: #94a3b8; }

/* Visual P&L Decomposition Bar */
.pk01-pl-breakdown {
    margin-top: 18px;
    background: #f8fafc;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    padding: 16px;
}
.pk01-pl-bar-wrap {
    height: 12px;
    border-radius: 6px;
    background: #e2e8f0;
    display: flex;
    overflow: hidden;
    margin: 10px 0 8px;
}
.pk01-pl-segment {
    height: 100%;
    transition: width 0.3s ease;
}
.pk01-pl-legend {
    display: flex;
    justify-content: space-between;
    font-size: 11.5px;
    color: #64748b;
    flex-wrap: wrap;
    gap: 8px;
}

/* Liquidity Flow Rows */
.pk01-flow-table {
    display: flex;
    flex-direction: column;
}
.pk01-flow-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 11px 0;
    border-bottom: 1px solid #f1f5f9;
    font-size: 13px;
}
.pk01-flow-row:last-child { border-bottom: none; }
.pk01-flow-row span { color: var(--pk-slate-600); font-weight: 500; }
.pk01-flow-row strong {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    color: var(--pk-slate-900);
}

/* 4. Tri-Hub Operational Cards */
.pk01-hub-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-bottom: 24px;
}
@media (max-width: 900px) { .pk01-hub-grid { grid-template-columns: 1fr; } }

.pk01-hub-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 20px 22px;
    box-shadow: var(--pk-shadow);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.2s ease;
}
.pk01-hub-card:hover { transform: translateY(-2px); box-shadow: var(--pk-elevated); }

.pk01-hub-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}
.pk01-hub-title {
    font-size: 11px;
    font-weight: 750;
    color: var(--pk-slate-600);
    text-transform: uppercase;
    letter-spacing: 0.8px;
}
.pk01-hub-metric {
    font-size: 24px;
    font-weight: 800;
    color: var(--pk-slate-900);
    margin: 4px 0 6px;
}
.pk01-hub-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    line-height: 1.45;
    margin: 0 0 16px;
}

.pk01-btn-block {
    display: block;
    text-align: center;
    padding: 9px 14px;
    background: #f8fafc;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 12.5px;
    font-weight: 700;
    color: var(--pk-slate-800);
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-block:hover {
    background: var(--pk-slate-900);
    color: #ffffff !important;
    border-color: var(--pk-slate-900);
}

/* 5. Footnote Audit */
.pk01-audit-footnote {
    background: #f8fafc;
    border: 1px dashed #cbd5e1;
    border-radius: 12px;
    padding: 14px 20px;
    font-size: 12px;
    color: #64748b;
    line-height: 1.5;
    display: flex;
    align-items: center;
    gap: 10px;
}
</style>

<div class="pk01-dash-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-dash-hero">
        <div class="pk01-hero-left">
            <span class="pk01-eyebrow">EXECUTIVE CONTROL TOWER &bull; RADAR BISNIS</span>
            <h1>🏢 Dashboard Pemilik</h1>
            <p>
                Pusat kendali likuiditas kas, margin laba operasional riil, pemantauan piutang macet, dan mitigasi risiko alur produksi di PK01.
            </p>
        </div>

        <div class="pk01-cockpit-widget">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>DATA SYNCHRONIZED</span>
            </div>
            <div style="font-size:16px; font-weight:800; color:#ffffff; margin:3px 0 1px;">
                <?php echo esc_html(wp_date('F Y', $now)); ?>
            </div>
            <div style="font-size:11px; color:#cbd5e1;" id="pk01-live-clock">
                <?php echo esc_html(wp_date('d M Y, H:i:s', $now)); ?> WIB
            </div>
        </div>
    </header>

    <!-- 2. 6 EXECUTIVE FINANCIAL SCORECARDS -->
    <section class="pk01-kpi-deck">
        <!-- Omzet Penjualan -->
        <div class="pk01-kpi-card c-indigo">
            <div class="pk01-kpi-head">
                <span>Omzet Penjualan</span>
                <span>🛒</span>
            </div>
            <div class="pk01-kpi-val"><?php echo esc_html($fmt($sales)); ?></div>
            <div class="pk01-kpi-foot">
                <span class="pk01-pill-stat pill-green"><?php echo (int)$orders_count; ?> Order</span>
                <span>Bulan Berjalan</span>
            </div>
        </div>

        <!-- Uang Masuk Kas -->
        <div class="pk01-kpi-card c-emerald">
            <div class="pk01-kpi-head">
                <span>Uang Masuk Kas</span>
                <span>💰</span>
            </div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo esc_html($fmt($cash_in)); ?></div>
            <div class="pk01-kpi-foot">
                <span>Inflow Ledger Aktual</span>
            </div>
        </div>

        <!-- Total Piutang Tertahan -->
        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-head">
                <span>Total Piutang</span>
                <span>⏳</span>
            </div>
            <div class="pk01-kpi-val" style="color:#d97706;"><?php echo esc_html($fmt($receivable)); ?></div>
            <div class="pk01-kpi-foot">
                <span class="pk01-pill-stat pill-amber"><?php echo (int)$pending_pay; ?> Belum Lunas</span>
            </div>
        </div>

        <!-- HPP + Komisi -->
        <div class="pk01-kpi-card c-dark">
            <div class="pk01-kpi-head">
                <span>HPP &amp; Komisi</span>
                <span>📦</span>
            </div>
            <div class="pk01-kpi-val"><?php echo esc_html($fmt($hpp + $commission)); ?></div>
            <div class="pk01-kpi-foot">
                <span>Beban Pokok Penjualan</span>
            </div>
        </div>

        <!-- Laba Bersih Operasional -->
        <div class="pk01-kpi-card <?php echo ($operating_profit >= 0) ? 'c-emerald' : 'c-rose'; ?>">
            <div class="pk01-kpi-head">
                <span>Laba Operasional</span>
                <span>📊</span>
            </div>
            <div class="pk01-kpi-val" style="<?php echo ($operating_profit >= 0) ? 'color:#059669;' : 'color:#dc2626;'; ?>">
                <?php echo esc_html($fmt($operating_profit)); ?>
            </div>
            <div class="pk01-kpi-foot">
                <span class="pk01-pill-stat <?php echo ($margin_pct >= 0) ? 'pill-green' : 'pill-red'; ?>">
                    Margin: <?php echo ($margin_pct > 0 ? '+' : '') . $margin_pct; ?>%
                </span>
            </div>
        </div>

        <!-- Saldo Kas Toko Riil -->
        <div class="pk01-kpi-card c-sky">
            <div class="pk01-kpi-head">
                <span>Saldo Kas Riil</span>
                <span>🏦</span>
            </div>
            <div class="pk01-kpi-val" style="color:#0284c7;"><?php echo esc_html($fmt($cash_balance)); ?></div>
            <div class="pk01-kpi-foot">
                <span>Akumulasi Saldo Fisik</span>
            </div>
        </div>
    </section>

    <!-- 3. MAIN SECTION: SMART RADAR & LIQUIDITY SPLIT -->
    <div class="pk01-split-grid">
        
        <!-- Kolom Kiri: Smart Business Radar & Laba Rugi Visual -->
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <span class="pk01-surface-tag">Sistem Mitigasi Risiko</span>
                    <h3>⚡ Radar &amp; Prioritas Tindakan Cepat</h3>
                </div>
                <a class="pk01-ai-launcher" href="<?php echo esc_url($ai_url); ?>">
                    <span>🤖</span> <span>Analisis Asisten AI</span>
                </a>
            </div>

            <div class="pk01-signal-feed">
                <?php foreach ($signals as $sig): ?>
                    <div class="pk01-signal-box <?php echo esc_attr($sig['type']); ?>">
                        <div class="pk01-signal-desc">
                            <strong><span><?php echo esc_html($sig['icon']); ?></span> <?php echo esc_html($sig['title']); ?></strong>
                            <p><?php echo esc_html($sig['text']); ?></p>
                        </div>
                        <a class="pk01-signal-btn" href="<?php echo esc_url($sig['url']); ?>">Buka Modul &rarr;</a>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Visual Bar Dekomposisi Laba Rugi -->
            <div class="pk01-pl-breakdown">
                <div style="display:flex; justify-content:space-between; align-items:center; font-size:12px; font-weight:700;">
                    <span style="color:#0f172a;">Dekomposisi Penyerapan Omzet Bulan Ini:</span>
                    <span style="color:#059669;"><?php echo $fmt($sales); ?></span>
                </div>
                
                <div class="pk01-pl-bar-wrap">
                    <div class="pk01-pl-segment" style="width:<?php echo $hpp_pct; ?>%; background:#64748b;" title="HPP & Komisi: <?php echo $hpp_pct; ?>%"></div>
                    <div class="pk01-pl-segment" style="width:<?php echo $opex_pct; ?>%; background:#f59e0b;" title="Beban Opex & Gaji: <?php echo $opex_pct; ?>%"></div>
                    <div class="pk01-pl-segment" style="width:<?php echo $profit_pct; ?>%; background:#10b981;" title="Laba Bersih: <?php echo $profit_pct; ?>%"></div>
                </div>

                <div class="pk01-pl-legend">
                    <span><b style="color:#64748b;">■</b> HPP &amp; Komisi (<?php echo $hpp_pct; ?>%)</span>
                    <span><b style="color:#f59e0b;">■</b> Opex &amp; Gaji (<?php echo $opex_pct; ?>%)</span>
                    <span><b style="color:#10b981;">■</b> Margin Laba Bersih (<?php echo $profit_pct; ?>%)</span>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Likuiditas & Arus Kas Riil -->
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <span class="pk01-surface-tag">Likuiditas Arus Kas</span>
                    <h3>💳 Arus Kas Masuk &amp; Keluar</h3>
                </div>
            </div>

            <div class="pk01-flow-table">
                <div class="pk01-flow-row">
                    <span>Total Uang Masuk (Inflow)</span>
                    <strong style="color:#059669;"><?php echo esc_html($fmt($cash_in)); ?></strong>
                </div>
                <div class="pk01-flow-row">
                    <span>Total Uang Keluar (Outflow)</span>
                    <strong style="color:#dc2626;"><?php echo esc_html($fmt($cash_out)); ?></strong>
                </div>
                <div class="pk01-flow-row">
                    <span>Biaya Operasional Rutin</span>
                    <strong><?php echo esc_html($fmt($op_cost)); ?></strong>
                </div>
                <div class="pk01-flow-row">
                    <span>Pencairan Gaji &amp; Payroll</span>
                    <strong><?php echo esc_html($fmt($pay)); ?></strong>
                </div>
                <div class="pk01-flow-row">
                    <span>Pengembalian / Refund Retur</span>
                    <strong style="color:#dc2626;"><?php echo esc_html($fmt($refund)); ?></strong>
                </div>
                <div class="pk01-flow-row">
                    <span>Rasio Pelunasan Piutang</span>
                    <strong style="color:#0284c7;"><?php echo (int)$paid_pct; ?>% Lunas</strong>
                </div>
            </div>

            <a class="pk01-btn-block" style="margin-top:16px;" href="<?php echo esc_url($url_helper('finance_hub')); ?>">
                📊 Buka Buku Kas &amp; Laporan Keuangan &rarr;
            </a>
        </div>

    </div>

    <!-- 4. OPERATIONAL TRI-HUB STATUS -->
    <div class="pk01-hub-grid">
        <!-- Pusat Penjualan -->
        <div class="pk01-hub-card">
            <div>
                <div class="pk01-hub-top">
                    <span class="pk01-hub-title">Pusat Penjualan &amp; POS</span>
                    <span style="font-size:18px;">🛒</span>
                </div>
                <div class="pk01-hub-metric"><?php echo esc_html($orders_count); ?> Order</div>
                <p class="pk01-hub-desc">
                    Sebanyak <strong><?php echo esc_html($paid_orders); ?> order</strong> telah berstatus lunas. Pantau tagihan jatuh tempo pelanggan.
                </p>
            </div>
            <a class="pk01-btn-block" href="<?php echo esc_url($url_helper('sales_hub')); ?>">
                Kontrol Order Penjualan &rarr;
            </a>
        </div>

        <!-- Pusat Produksi -->
        <div class="pk01-hub-card">
            <div>
                <div class="pk01-hub-top">
                    <span class="pk01-hub-title">Lantai Produksi Pabrik</span>
                    <span style="font-size:18px;">🏭</span>
                </div>
                <div class="pk01-hub-metric"><?php echo esc_html($active_jobs); ?> Antrean SPK</div>
                <p class="pk01-hub-desc">
                    Surat Perintah Kerja (SPK) aktif yang sedang diproses. Awasi batas deadline pengerjaan staf.
                </p>
            </div>
            <a class="pk01-btn-block" href="<?php echo esc_url($url_helper('production_hub')); ?>">
                Pantau SPK &amp; Job Produksi &rarr;
            </a>
        </div>

        <!-- Pusat Ekspedisi -->
        <div class="pk01-hub-card">
            <div>
                <div class="pk01-hub-top">
                    <span class="pk01-hub-title">Logistik &amp; Kurir</span>
                    <span style="font-size:18px;">🚚</span>
                </div>
                <div class="pk01-hub-metric"><?php echo esc_html($ship_queue); ?> Pengiriman</div>
                <p class="pk01-hub-desc">
                    Paket atau manifes ekspedisi yang sedang dalam proses pengantaran kurir ke alamat pelanggan.
                </p>
            </div>
            <a class="pk01-btn-block" href="<?php echo esc_url($url_helper('shipping_hub')); ?>">
                Lacak Resi Ekspedisi &rarr;
            </a>
        </div>
    </div>

    <!-- 5. AUDIT FOOTNOTE -->
    <footer class="pk01-audit-footnote">
        <span style="font-size:16px;">🛡️</span>
        <div>
            <b>Kaidah Integritas Data Eksekutif:</b> Indikator omzet, arus kas, dan margin laba dihitung otomatis tanpa estimasi rekayasa langsung dari tabel riil transaksi aktif PK01. Pembaruan data sinkron secara <i>real-time</i> setiap kali transaksi dicatat.
        </div>
    </footer>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Live update jam digital WIB
    var clockEl = document.getElementById('pk01-live-clock');
    if (clockEl) {
        function updateTime() {
            var now = new Date();
            var timeStr = now.toLocaleTimeString('id-ID', { hour12: false });
            var dateStr = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
            clockEl.innerHTML = dateStr + ', <b>' + timeStr + ' WIB</b>';
        }
        setInterval(updateTime, 1000);
    }
});
</script>