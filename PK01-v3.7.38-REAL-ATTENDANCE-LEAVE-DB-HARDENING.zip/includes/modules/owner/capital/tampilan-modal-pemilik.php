<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
if (!current_user_can('manage_options')) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;">Akses Dibatasi</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Hanya Administrator yang memiliki wewenang mengelola permodalan dan bagi hasil kemitraan.</p>
          </div>';
    return;
}

// 2. HELPER TABEL RESMI PK01
$tO    = PK01_DB::t('company_owners'); 
$tD    = PK01_DB::t('profit_distributions'); 
$tI    = PK01_DB::t('profit_distribution_items'); 
$tT    = PK01_DB::t('owner_transactions'); 
$tInv  = PK01_DB::t('investors'); 
$tInvT = PK01_DB::t('investor_transactions');

$msg = ''; 
$err = '';
$today      = current_time('Y-m-d');
$month_from = current_time('Y-m-01');
$year_from  = current_time('Y-01-01');
$all_from   = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'first_financial_date') ? PK01_Engine::first_financial_date() : $year_from;

// Laporan Finansial Real-time
$month_report = class_exists('PK01_Engine') ? PK01_Engine::financial_report($month_from, $today) : [];
$year_report  = class_exists('PK01_Engine') ? PK01_Engine::financial_report($year_from, $today) : [];
$all_report   = class_exists('PK01_Engine') ? PK01_Engine::financial_report($all_from, $today) : [];
$undistributed= class_exists('PK01_Engine') ? PK01_Engine::undistributed_profit($today) : 0;
$cash_balance = class_exists('PK01_Engine') ? PK01_Engine::cash_balance() : 0;

// 3. ACTION HANDLERS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_owner_action'])) {
    check_admin_referer('pk01_owner_action', 'pk01_owner_nonce');
    try {
        $a = sanitize_key($_POST['pk01_owner_action']);

        // A. TAMBAH INVESTOR (PEMILIK MODAL)
        if ($a === 'add_investor') {
            $name = sanitize_text_field($_POST['investor_name'] ?? '');
            if (!$name) throw new Exception('Nama investor penyetor modal wajib diisi.');
            
            $wpdb->insert($tInv, [
                'name'                 => $name,
                'investment_reference' => sanitize_text_field($_POST['investment_reference'] ?? ''),
                'contact'              => sanitize_text_field($_POST['investor_contact'] ?? ''),
                'bank_name'            => sanitize_text_field($_POST['bank_name'] ?? ''),
                'account_name'         => sanitize_text_field($_POST['account_name'] ?? ''),
                'account_number'       => sanitize_text_field($_POST['account_number'] ?? ''),
                'notes'                => sanitize_textarea_field($_POST['investor_notes'] ?? ''),
                'status'               => 'active',
                'created_at'           => current_time('mysql')
            ]);
            if (!$wpdb->insert_id) throw new Exception($wpdb->last_error ?: 'Gagal mendaftarkan investor.');
            $msg = 'Mitra investor berhasil didaftarkan.';

        // B. CATAT SUNTIKAN MODAL INVESTOR (MASUK KAS + BUKU MODAL)
        } elseif ($a === 'investor_investment') {
            $investor = (int)($_POST['investor_id'] ?? 0);
            $amount   = round((float)($_POST['investment_amount'] ?? 0), 2);
            if (!$investor || $amount <= 0) throw new Exception('Pilih investor dan masukkan nominal suntikan modal.');
            
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tInv} WHERE id = %d AND status = 'active'", $investor));
            if (!$row) throw new Exception('Data investor tidak ditemukan.');
            
            $ref = 'INVEST-' . current_time('YmdHis') . '-' . $investor;
            $wpdb->query('START TRANSACTION');
            try {
                $wpdb->insert($tInvT, [
                    'investor_id'      => $investor,
                    'transaction_type' => 'investment_in',
                    'amount'           => $amount,
                    'reference_no'     => $ref,
                    'description'      => sanitize_textarea_field($_POST['investment_notes'] ?? 'Penyetoran modal investasi'),
                    'created_by'       => get_current_user_id(),
                    'created_at'       => current_time('mysql')
                ]);
                $id = $wpdb->insert_id;
                if (!$id) throw new Exception($wpdb->last_error ?: 'Pencatatan investasi gagal.');

                $ct = PK01_DB::t('capital_transactions');
                $wpdb->insert($ct, [
                    'amount'        => $amount,
                    'owner_id'      => 0,
                    'investor_id'   => $investor,
                    'capital_type'  => 'investor_capital',
                    'source'        => 'Investor',
                    'description'   => 'Suntikan modal: ' . $row->name,
                    'created_at'    => current_time('mysql')
                ]);
                
                if (class_exists('PK01_Engine')) {
                    PK01_Engine::cash('in', $amount, 'Dana Investasi Modal', 'investor_transaction', $id, 'Suntikan modal investor: ' . $row->name, 'Kas Tunai Toko', $ref);
                }
                $wpdb->query('COMMIT');
            } catch (Throwable $e) {
                $wpdb->query('ROLLBACK');
                throw $e;
            }
            if (class_exists('PK01_Engine')) {
                PK01_Engine::log('investor_investment', 'finance', 'investor_transaction', (string)$id, null, ['investor_id' => $investor, 'amount' => $amount, 'ref' => $ref], 'Penyetoran modal investor');
            }
            $msg = 'Suntikan modal investor berhasil dicatat ke Kas & Buku Modal. (Bukan Omzet & Bukan Laba).';

        // C. DISTRIBUSI LABA MURNI KEMITRAAN (BAGI HASIL 50:50 OPERATOR VS INVESTOR)
        } elseif ($a === 'distribute_partnership') {
            $date = sanitize_text_field($_POST['period_end'] ?? $today);
            if ($date > $today) throw new Exception('Tanggal periode pembagian tidak boleh di masa depan.');
            
            $profit = class_exists('PK01_Engine') ? PK01_Engine::undistributed_profit($date) : 0;
            if ($profit <= 0) throw new Exception('Belum ada laba bersih yang tersedia untuk dibagikan per tanggal ' . $date . '.');

            $operator_pct = (float) str_replace(',', '.', (string)($_POST['operator_percent'] ?? 50));
            $investor_pct = (float) str_replace(',', '.', (string)($_POST['investor_percent'] ?? 50));

            if (abs(($operator_pct + $investor_pct) - 100) > 0.01) {
                throw new Exception('Total rasio pembagian (Pengelola + Investor) harus tepat 100%.');
            }

            // Target Investor Spesifik
            $target_investor = (int)($_POST['target_investor_id'] ?? 0);
            $target_owner    = (int)($_POST['target_owner_id'] ?? 0);

            $pool_operator = round($profit * ($operator_pct / 100), 2);
            $pool_investor = round($profit - $pool_operator, 2);

            $wpdb->query('START TRANSACTION');
            try {
                $wpdb->insert($tD, [
                    'period_end'           => $date,
                    'profit_base'          => $profit,
                    'distributable_profit' => $profit,
                    'status'               => 'approved',
                    'created_by'           => get_current_user_id(),
                    'created_at'           => current_time('mysql')
                ]);
                $did = (int)$wpdb->insert_id;
                if (!$did) throw new Exception($wpdb->last_error ?: 'Gagal membuat dokumen distribusi laba.');

                // 1. Alokasi Porsi Pengelola Usaha
                $wpdb->insert($tI, [
                    'distribution_id'  => $did,
                    'owner_id'         => $target_owner ?: 1,
                    'investor_id'      => 0,
                    'beneficiary_type' => 'owner',
                    'share_percent'    => $operator_pct,
                    'allocated_amount' => $pool_operator,
                    'withdrawn_amount' => 0,
                    'created_at'       => current_time('mysql')
                ]);

                // 2. Alokasi Porsi Investor Pemodal
                $wpdb->insert($tI, [
                    'distribution_id'  => $did,
                    'owner_id'         => 0,
                    'investor_id'      => $target_investor,
                    'beneficiary_type' => 'investor',
                    'share_percent'    => $investor_pct,
                    'allocated_amount' => $pool_investor,
                    'withdrawn_amount' => 0,
                    'created_at'       => current_time('mysql')
                ]);

                $wpdb->query('COMMIT');
            } catch (Throwable $e) {
                $wpdb->query('ROLLBACK');
                throw $e;
            }

            if (class_exists('PK01_Engine')) {
                PK01_Engine::log('profit_distributed', 'finance', 'profit_distribution', (string)$did, null, [
                    'profit' => $profit, 'operator_pct' => $operator_pct, 'investor_pct' => $investor_pct,
                    'pool_operator' => $pool_operator, 'pool_investor' => $pool_investor
                ], 'Distribusi Laba Kemitraan Usaha');
            }
            $msg = 'Bagi hasil murni berhasil dieksekusi! Hak laba Pengelola (Rp ' . number_format($pool_operator, 0, ',', '.') . ') & Investor (Rp ' . number_format($pool_investor, 0, ',', '.') . ') telah dialokasikan.';

        // D. PENCAIRAN BAGI HASIL / BON INVESTOR
        } elseif ($a === 'withdraw_investor') {
            $investor = (int)($_POST['investor_withdraw_id'] ?? 0);
            $amount   = round((float)($_POST['investor_withdraw_amount'] ?? 0), 2);
            if (!$investor || $amount <= 0) throw new Exception('Pilih investor dan nominal penarikan.');
            
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tInv} WHERE id = %d AND status = 'active'", $investor));
            if (!$row) throw new Exception('Data investor tidak ditemukan.');
            
            $entitlement = class_exists('PK01_Engine') ? PK01_Engine::investor_profit_entitlement($investor, $today) : 0;
            $allow_advance = !empty($_POST['allow_profit_advance']);

            if ($amount > $entitlement + 0.01 && !$allow_advance) {
                throw new Exception('Nominal penarikan (Rp ' . number_format($amount, 0, ',', '.') . ') melebihi hak laba tersedia (Rp ' . number_format($entitlement, 0, ',', '.') . '). Centang opsi "Izinkan BON LABA" jika ini adalah pengambilan di muka.');
            }
            if ($amount > $cash_balance + 0.01) {
                throw new Exception('Saldo kas riil toko (Rp ' . number_format($cash_balance, 0, ',', '.') . ') tidak mencukupi untuk pembayaran ini.');
            }

            $current_paid = min($amount, $entitlement);
            $new_advance  = max(0, round($amount - $current_paid, 2));
            $ref = 'INV-PAY-' . current_time('YmdHis') . '-' . $investor;

            $wpdb->query('START TRANSACTION');
            try {
                $id = 0; $aid = 0;
                if ($current_paid > 0) {
                    $wpdb->insert($tInvT, [
                        'investor_id'      => $investor,
                        'transaction_type' => 'profit_paid',
                        'amount'           => $current_paid,
                        'reference_no'     => $ref . '-PAID',
                        'description'      => sanitize_textarea_field($_POST['investor_withdraw_notes'] ?? 'Bagi hasil laba usaha'),
                        'created_by'       => get_current_user_id(),
                        'created_at'       => current_time('mysql')
                    ]);
                    $id = $wpdb->insert_id;
                }
                if ($new_advance > 0) {
                    $wpdb->insert($tInvT, [
                        'investor_id'      => $investor,
                        'transaction_type' => 'profit_advance',
                        'amount'           => $new_advance,
                        'reference_no'     => $ref . '-ADV',
                        'description'      => 'Bon Laba Investor (Uang muka keuntungan dipotong distribusi berikutnya). ' . sanitize_textarea_field($_POST['investor_withdraw_notes'] ?? ''),
                        'created_by'       => get_current_user_id(),
                        'created_at'       => current_time('mysql')
                    ]);
                    $aid = $wpdb->insert_id;
                }

                $cash_ref_id = $id ?: $aid;
                if (class_exists('PK01_Engine')) {
                    PK01_Engine::cash('out', $amount, 'Bagi Hasil Investor', 'investor_transaction', $cash_ref_id, 'Pembayaran bagi hasil/bon investor: ' . $row->name, 'Kas Tunai Toko', $ref);
                }
                $wpdb->query('COMMIT');
            } catch (Throwable $e) {
                $wpdb->query('ROLLBACK');
                throw $e;
            }

            $msg = ($new_advance > 0) 
                ? 'Pembayaran berhasil diproses: Rp ' . number_format($current_paid, 0, ',', '.') . ' sebagai bagi hasil, dan Rp ' . number_format($new_advance, 0, ',', '.') . ' sebagai BON LABA (otomatis memotong laba berikutnya).'
                : 'Pencairan bagi hasil investor berhasil dicatat.';

        // E. PENARIKAN LABA PENGELOLA USAHA
        } elseif ($a === 'withdraw_owner') {
            $owner  = (int)($_POST['owner_id'] ?? 0);
            $amount = (float)($_POST['amount'] ?? 0);
            $type   = sanitize_key($_POST['withdraw_type'] ?? 'profit_draw');

            if (!$owner || $amount <= 0) throw new Exception('Pilih pengelola dan masukkan nominal penarikan.');
            $ownerRow = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tO} WHERE id = %d AND status = 'active'", $owner));
            if (!$ownerRow) throw new Exception('Pengelola usaha tidak ditemukan.');

            $entitlement = class_exists('PK01_Engine') ? PK01_Engine::owner_profit_entitlement($owner, $today) : 0;
            if ($amount > $entitlement + 0.01) {
                throw new Exception('Penarikan melebihi hak laba pengelola yang tersedia (Hak: Rp ' . number_format($entitlement, 0, ',', '.') . ').');
            }
            if ($amount > $cash_balance + 0.01) {
                throw new Exception('Saldo kas fisik tidak mencukupi untuk penarikan ini.');
            }

            $period = current_time('Y-m'); $owner_reference_no = class_exists('PK01_Engine') ? PK01_Engine::document_number('owner_receipt') : 'OWN-' . current_time('YmdHis');
            $wpdb->query('START TRANSACTION');
            try {
                $wpdb->insert($tT, [
                    'owner_id'         => $owner,
                    'transaction_type' => $type,
                    'amount'           => $amount,
                    'period_key'       => $period,
                    'reference_no'     => $owner_reference_no,
                    'description'      => sanitize_textarea_field($_POST['description'] ?? 'Penarikan laba pengelola'),
                    'created_by'       => get_current_user_id(),
                    'created_at'       => current_time('mysql')
                ]);
                $id = $wpdb->insert_id;
                if (!$id) throw new Exception($wpdb->last_error ?: 'Transaksi gagal.');

                if (class_exists('PK01_Engine')) {
                    PK01_Engine::cash('out', $amount, 'Penarikan Laba Pengelola', 'owner_transaction', $id, 'Penarikan laba pengelola: ' . $ownerRow->name, 'Kas Tunai Toko', $owner_reference_no);
                }
                $wpdb->query('COMMIT');
            } catch (Throwable $e) {
                $wpdb->query('ROLLBACK');
                throw $e;
            }
            $msg = 'Penarikan laba pengelola usaha berhasil dicatat dan memotong kas riil.';

        // F. INPUT MODAL AWAL INTERNAL PENGELOLA
        } elseif ($a === 'capital') {
            $amount = (float)($_POST['capital_amount'] ?? 0);
            $owner  = (int)($_POST['capital_owner_id'] ?? 0);
            $source = sanitize_text_field($_POST['capital_source'] ?? 'Modal Sendiri');
            if ($amount <= 0) throw new Exception('Nominal modal harus lebih dari Rp 0.');

            if (class_exists('PK01_Engine')) {
                PK01_Engine::create_capital($amount, $source, 'Penyetoran modal kerja awal', $owner);
            }
            $msg = 'Modal awal pengelola berhasil dicatat ke buku ekuitas & kas.';
        }
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

// 4. PRE-FETCH DATA UNTUK TAMPILAN
$owners    = $wpdb->get_results("SELECT * FROM {$tO} WHERE status = 'active' ORDER BY id ASC") ?: [];
$investors = $wpdb->get_results("SELECT * FROM {$tInv} WHERE status = 'active' ORDER BY id ASC") ?: [];

// Hitung total modal investor riil yang sedang aktif disetor
$total_investor_capital = (float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$tInvT} WHERE transaction_type = 'investment_in'");
$total_investor_paid    = (float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$tInvT} WHERE transaction_type = 'profit_paid'");

$dist = $wpdb->get_results("
    SELECT d.*, 
           COALESCE(SUM(CASE WHEN i.beneficiary_type = 'owner' THEN i.allocated_amount ELSE 0 END), 0) AS operator_share,
           COALESCE(SUM(CASE WHEN i.beneficiary_type = 'investor' THEN i.allocated_amount ELSE 0 END), 0) AS investor_share
    FROM {$tD} d 
    LEFT JOIN {$tI} i ON i.distribution_id = d.id 
    GROUP BY d.id 
    ORDER BY d.id DESC LIMIT 15
") ?: [];

$invtx = $wpdb->get_results("SELECT t.*, i.name AS investor_name FROM {$tInvT} t LEFT JOIN {$tInv} i ON i.id = t.investor_id ORDER BY t.id DESC LIMIT 15") ?: [];
$ownertx = $wpdb->get_results("SELECT t.*, o.name AS owner_name FROM {$tT} t LEFT JOIN {$tO} o ON o.id = t.owner_id ORDER BY t.id DESC LIMIT 15") ?: [];
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-equity-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-equity-app * { box-sizing: border-box; }

/* 1. Hero Cockpit */
.pk01-equity-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-stat-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}

/* 2. Executive KPI Cards */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-emerald::before { background: var(--pk-emerald); }
.pk01-kpi-card.c-indigo::before  { background: var(--pk-indigo); }
.pk01-kpi-card.c-sky::before     { background: var(--pk-sky); }
.pk01-kpi-card.c-amber::before   { background: var(--pk-amber); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 24px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; }
.pk01-kpi-sub { font-size: 12px; color: var(--pk-slate-600); }

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surface Cards */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Form Controls */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
}
.pk01-form-group { display: flex; flex-direction: column; gap: 6px; }
.pk01-form-group label { font-size: 12.5px; font-weight: 700; color: var(--pk-slate-700); }
.pk01-ctrl {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13.5px;
    background: #ffffff;
    transition: all 0.2s ease;
}
.pk01-ctrl:focus {
    outline: none;
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Visual Splitter Card */
.pk01-split-box {
    background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
    border: 1px solid #c7d2fe;
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 22px;
}
.pk01-split-visual {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 20px;
    margin: 18px 0;
    text-align: center;
}
@media (max-width: 680px) {
    .pk01-split-visual { grid-template-columns: 1fr; }
}
.pk01-split-col {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    padding: 18px;
    box-shadow: var(--pk-shadow);
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

/* Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 9px 16px;
    font-size: 13px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
.pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
.pk01-btn-emerald:hover { background: #059669; }

.pk01-money {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 800;
    color: #0f172a;
}
.pk01-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.badge-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.badge-warning { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }

.pk01-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-alert.is-error   { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }
</style>

<div class="pk01-equity-app">

    <!-- 1. HERO COCKPIT BANNER -->
    <header class="pk01-equity-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">PARTNERSHIP &bull; 50:50 PROFIT SPLIT ENGINE</span>
            <h1>🤝 Kemitraan Usaha &amp; Bagi Hasil Laba Riil</h1>
            <p>
                Konsep murni kemitraan usaha (Syirkah/Bagi Dua): <strong>Pihak 1 Penjalan Usaha (Pengelola)</strong> dan <strong>Pihak 2 Penyetor Modal (Investor)</strong>. 
                Bagi hasil dihitung murni dari laba bersih riil yang belum terbagi, bukan dari omzet kotor.
            </p>
        </div>
        <div class="pk01-stat-pill">
            <div style="font-size:12px; font-weight:700; color:#4ade80;">● KAS TOKO RIIL AKTIF</div>
            <div style="font-size:18px; font-weight:800; color:#ffffff; margin-top:2px;">
                Rp <?php echo number_format($cash_balance, 0, ',', '.'); ?>
            </div>
        </div>
    </header>

    <?php if ($msg): ?><div class="pk01-alert is-success">✅ <?php echo esc_html($msg); ?></div><?php endif; ?>
    <?php if ($err): ?><div class="pk01-alert is-error">❌ <?php echo esc_html($err); ?></div><?php endif; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-emerald">
            <div class="pk01-kpi-label">Laba Bersih Belum Dibagi</div>
            <div class="pk01-kpi-val" style="color:#059669;">Rp <?php echo number_format($undistributed, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Pool laba riil siap didistribusikan</div>
        </div>

        <div class="pk01-kpi-card c-indigo">
            <div class="pk01-kpi-label">Laba Bersih Bulan Ini</div>
            <div class="pk01-kpi-val">Rp <?php echo number_format((float)($month_report['net_profit'] ?? 0), 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub"><?php echo esc_html($month_from); ?> s/d <?php echo esc_html($today); ?></div>
        </div>

        <div class="pk01-kpi-card c-sky">
            <div class="pk01-kpi-label">Total Modal Investor Masuk</div>
            <div class="pk01-kpi-val" style="color:#0284c7;">Rp <?php echo number_format($total_investor_capital, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Masuk kas &amp; buku ekuitas modal</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Bagi Hasil Telah Terbayar</div>
            <div class="pk01-kpi-val" style="color:#d97706;">Rp <?php echo number_format($total_investor_paid, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Total laba ditarik oleh mitra</div>
        </div>
    </section>

    <!-- 3. TABS NAVIGASI UTAMA -->
    <nav class="pk01-nav-tabs" aria-label="Menu Bagi Hasil">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-split">
            ⚖️ Eksekusi Bagi Hasil Laba (Bagi Dua)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-investors">
            🏢 Investor &amp; Setoran Modal
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-payouts">
            💸 Pencairan Laba &amp; Bon Investor
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-history">
            📜 Riwayat Distribusi &amp; Pembukuan
        </button>
    </nav>

    <!-- 4. TAB 1: KALKULATOR & EKSEKUSI BAGI HASIL 50:50 -->
    <div class="pk01-pane is-active" id="tab-split">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>⚖️ Pembagian Laba Murni Kemitraan (Bagi Hasil Usaha)</h3>
                    <div class="pk01-surface-desc">
                        Laba bersih riil dialokasikan ke masing-masing pihak. Nilai dasar laba tidak dapat diedit sembarangan karena ditarik langsung dari selisih pendapatan riil.
                    </div>
                </div>
            </div>

            <!-- VISUAL SPLITTER CARD -->
            <div class="pk01-split-box">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div>
                        <span style="font-size:12px; font-weight:700; color:#475569; text-transform:uppercase;">Pool Laba Bersih yang Siap Dibagikan:</span>
                        <div style="font-size:26px; font-weight:800; color:#0f172a; margin-top:2px;">
                            Rp <span id="pk01-display-profit"><?php echo number_format($undistributed, 0, ',', '.'); ?></span>
                        </div>
                    </div>
                    <span class="pk01-badge badge-success" style="font-size:12px; padding:6px 12px;">
                        ✓ Berdasarkan Laba Bersih Pembukuan Riil
                    </span>
                </div>

                <div class="pk01-split-visual">
                    <!-- Pihak Pengelola -->
                    <div class="pk01-split-col">
                        <span style="font-size:11px; font-weight:700; color:#4f46e5; text-transform:uppercase; letter-spacing:0.5px;">PIHAK 1: PENGELOLA USAHA</span>
                        <h4 style="margin:6px 0; font-size:16px; color:#0f172a;">Pelaksana &amp; Manajemen Toko</h4>
                        <div style="font-size:22px; font-weight:800; color:#4f46e5; margin:10px 0;">
                            Rp <span id="pk01-preview-operator">0</span>
                        </div>
                        <div style="font-size:12px; color:#64748b;">Porsi Bagian: <b id="pk01-label-operator">50%</b></div>
                    </div>

                    <div style="font-size:22px; font-weight:800; color:#6366f1;">
                        🤝
                    </div>

                    <!-- Pihak Investor -->
                    <div class="pk01-split-col">
                        <span style="font-size:11px; font-weight:700; color:#059669; text-transform:uppercase; letter-spacing:0.5px;">PIHAK 2: INVESTOR PEMODAL</span>
                        <h4 style="margin:6px 0; font-size:16px; color:#0f172a;">Penyedia Dana Modal Usaha</h4>
                        <div style="font-size:22px; font-weight:800; color:#059669; margin:10px 0;">
                            Rp <span id="pk01-preview-investor">0</span>
                        </div>
                        <div style="font-size:12px; color:#64748b;">Porsi Bagian: <b id="pk01-label-investor">50%</b></div>
                    </div>
                </div>
            </div>

            <!-- FORM EKSEKUSI DISTRIBUSI -->
            <form method="post" action="">
                <?php wp_nonce_field('pk01_owner_action', 'pk01_owner_nonce'); ?>
                <input type="hidden" name="pk01_owner_action" value="distribute_partnership">

                <div class="pk01-form-grid">
                    <div class="pk01-form-group">
                        <label>Bagi Hasil Sampai Tanggal Buku</label>
                        <input type="date" name="period_end" class="pk01-ctrl" value="<?php echo esc_attr($today); ?>" max="<?php echo esc_attr($today); ?>" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Pilih Pihak Investor Penerima</label>
                        <select name="target_investor_id" class="pk01-ctrl" required>
                            <option value="">-- Pilih Investor Penerima Laba --</option>
                            <?php foreach ($investors as $inv): ?>
                                <option value="<?php echo (int)$inv->id; ?>">
                                    <?php echo esc_html($inv->name); ?> (<?php echo esc_html($inv->investment_reference ?: 'Investor Modal'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-form-group">
                        <label>Persentase Pengelola Usaha (%)</label>
                        <input type="number" step="0.1" min="0" max="100" id="input_operator_pct" name="operator_percent" class="pk01-ctrl" value="50" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Persentase Investor Pemodal (%)</label>
                        <input type="number" step="0.1" min="0" max="100" id="input_investor_pct" name="investor_percent" class="pk01-ctrl" value="50" required>
                    </div>
                </div>

                <div style="margin-top:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <span style="font-size:12px; color:#64748b;">
                        💡 Snapshot persentase akan disimpan permanen pada saat distribusi dieksekusi.
                    </span>
                    <button type="submit" class="pk01-btn pk01-btn-primary" <?php disabled($undistributed <= 0); ?>>
                        🚀 Eksekusi Pembagian Laba Periode Ini
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- 5. TAB 2: INVESTOR & SUNTIKAN MODAL -->
    <div class="pk01-pane" id="tab-investors">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🏢 Manajemen Investor &amp; Penyetoran Modal Usaha</h3>
                    <div class="pk01-surface-desc">
                        Dana suntikan investor langsung menambah kas dan ekuitas modal kerja. Tidak menjadi omzet dan tidak menjadi laba.
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1.2fr 1fr; gap:20px; align-items:start;">
                <!-- Form Tambah Investor -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px;">
                    <h4 style="margin:0 0 12px; font-size:15px; font-weight:800; color:#0f172a;">➕ Daftarkan Profil Investor Baru</h4>
                    <form method="post">
                        <?php wp_nonce_field('pk01_owner_action', 'pk01_owner_nonce'); ?>
                        <input type="hidden" name="pk01_owner_action" value="add_investor">

                        <div class="pk01-form-grid" style="grid-template-columns:1fr 1fr;">
                            <div class="pk01-form-group">
                                <label>Nama Lengkap Investor <span style="color:#ef4444;">*</span></label>
                                <input name="investor_name" class="pk01-ctrl" required placeholder="Nama investor">
                            </div>
                            <div class="pk01-form-group">
                                <label>No. Perjanjian / Ref Akad</label>
                                <input name="investment_reference" class="pk01-ctrl" placeholder="Contoh: AKAD-01/INV/2026">
                            </div>
                            <div class="pk01-form-group">
                                <label>Kontak WhatsApp / HP</label>
                                <input name="investor_contact" class="pk01-ctrl" placeholder="08xxxxxxxxxx">
                            </div>
                            <div class="pk01-form-group">
                                <label>Nama Bank Pembayaran</label>
                                <input name="bank_name" class="pk01-ctrl" placeholder="BCA / Mandiri / BSI">
                            </div>
                            <div class="pk01-form-group">
                                <label>Nomor Rekening</label>
                                <input name="account_number" class="pk01-ctrl" placeholder="Nomor rekening bank">
                            </div>
                            <div class="pk01-form-group">
                                <label>Nama Pemilik Rekening</label>
                                <input name="account_name" class="pk01-ctrl" placeholder="Atas nama rekening">
                            </div>
                            <div class="pk01-form-group" style="grid-column:1/-1;">
                                <label>Catatan / Klausul Investasi</label>
                                <textarea name="investor_notes" class="pk01-ctrl" rows="2" placeholder="Catatan kesepakatan kemitraan..."></textarea>
                            </div>
                        </div>

                        <button type="submit" class="pk01-btn pk01-btn-primary" style="margin-top:14px;">
                            Simpan Profil Investor
                        </button>
                    </form>
                </div>

                <!-- Form Catat Suntikan Modal -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px;">
                    <h4 style="margin:0 0 12px; font-size:15px; font-weight:800; color:#0f172a;">📥 Catat Suntikan Dana Modal</h4>
                    <form method="post">
                        <?php wp_nonce_field('pk01_owner_action', 'pk01_owner_nonce'); ?>
                        <input type="hidden" name="pk01_owner_action" value="investor_investment">

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Pilih Investor Penyetor <span style="color:#ef4444;">*</span></label>
                            <select name="investor_id" class="pk01-ctrl" required>
                                <option value="">-- Pilih Investor --</option>
                                <?php foreach ($investors as $i): ?>
                                    <option value="<?php echo (int)$i->id; ?>"><?php echo esc_html($i->name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Nominal Modal Masuk (Rp) <span style="color:#ef4444;">*</span></label>
                            <input name="investment_amount" type="number" step="0.01" min="0.01" class="pk01-ctrl" placeholder="Nominal modal disetor" required>
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:14px;">
                            <label>Keterangan Transfer</label>
                            <input name="investment_notes" class="pk01-ctrl" placeholder="Contoh: Setoran modal kerja tahap 1">
                        </div>

                        <button type="submit" class="pk01-btn pk01-btn-emerald">
                            📥 Masukkan ke Kas &amp; Buku Modal
                        </button>
                    </form>
                </div>
            </div>

            <!-- TABEL DAFTAR INVESTOR & STATUS SALDO -->
            <div style="margin-top:24px;">
                <h4 style="margin:0 0 10px; font-size:15px; font-weight:800; color:#0f172a;">📊 Status Modal &amp; Hak Laba per Investor</h4>
                <div class="pk01-table-card">
                    <table class="pk01-tbl">
                        <thead>
                            <tr>
                                <th>Nama Investor</th>
                                <th>Rekening Bank</th>
                                <th>Total Modal Disetor</th>
                                <th>Hak Laba Tersedia</th>
                                <th>Status Bon Laba</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($investors)): foreach ($investors as $inv): 
                                $invested = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$tInvT} WHERE investor_id = %d AND transaction_type = 'investment_in'", $inv->id));
                                $entitlement = class_exists('PK01_Engine') ? PK01_Engine::investor_profit_entitlement((int)$inv->id, $today) : 0;
                                $adv = class_exists('PK01_Engine') ? PK01_Engine::investor_profit_advance_balance((int)$inv->id, $today) : 0;
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($inv->name); ?></strong>
                                    <div style="font-size:11.5px; color:#64748b;"><?php echo esc_html($inv->investment_reference ?: 'Mitra Pemodal'); ?></div>
                                </td>
                                <td>
                                    <div><?php echo esc_html($inv->bank_name ?: '-'); ?></div>
                                    <div style="font-size:11px; color:#64748b; font-family:monospace;"><?php echo esc_html($inv->account_number ?: ''); ?> a.n <?php echo esc_html($inv->account_name ?: '-'); ?></div>
                                </td>
                                <td><span class="pk01-money" style="color:#0284c7;">Rp <?php echo number_format($invested, 0, ',', '.'); ?></span></td>
                                <td><span class="pk01-money" style="color:#059669;">Rp <?php echo number_format($entitlement, 0, ',', '.'); ?></span></td>
                                <td>
                                    <?php if ($adv > 0): ?>
                                        <span class="pk01-badge badge-warning">Bon: Rp <?php echo number_format($adv, 0, ',', '.'); ?></span>
                                    <?php else: ?>
                                        <span class="pk01-badge badge-success">✓ Bersih (Nol Bon)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; else: ?>
                                <tr><td colspan="5" style="text-align:center; padding:30px; color:#94a3b8;">Belum ada mitra investor yang didaftarkan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- 6. TAB 3: PENCAIRAN LABA & BON INVESTOR -->
    <div class="pk01-pane" id="tab-payouts">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>💸 Pencairan Bagi Hasil &amp; Bon Uang Muka Laba</h3>
                    <div class="pk01-surface-desc">
                        Penarikan bagi hasil mengurangi saldo kas riil toko dan hak laba mitra yang bersangkutan. Bukan beban operasional.
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                <!-- Pencairan Investor -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px;">
                    <h4 style="margin:0 0 10px; font-size:15px; font-weight:800; color:#0f172a;">Pencairan Bagi Hasil Investor</h4>
                    <form method="post">
                        <?php wp_nonce_field('pk01_owner_action', 'pk01_owner_nonce'); ?>
                        <input type="hidden" name="pk01_owner_action" value="withdraw_investor">

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Pilih Investor</label>
                            <select name="investor_withdraw_id" class="pk01-ctrl" required>
                                <option value="">-- Pilih Investor --</option>
                                <?php foreach ($investors as $i): 
                                    $ent = class_exists('PK01_Engine') ? PK01_Engine::investor_profit_entitlement((int)$i->id, $today) : 0;
                                ?>
                                    <option value="<?php echo (int)$i->id; ?>">
                                        <?php echo esc_html($i->name); ?> (Hak: Rp <?php echo number_format($ent, 0, ',', '.'); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Nominal Pembayaran (Rp)</label>
                            <input name="investor_withdraw_amount" type="number" step="0.01" min="0.01" class="pk01-ctrl" required placeholder="Nominal yang dibayarkan">
                        </div>

                        <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:10px 12px; margin-bottom:12px;">
                            <label style="display:flex; align-items:flex-start; gap:8px; cursor:pointer; font-size:12px; color:#92400e;">
                                <input type="checkbox" name="allow_profit_advance" value="1" style="margin-top:2px;">
                                <span><b>Izinkan Sistem BON LABA:</b> Jika nominal melebihi hak saat ini, selisih dibukukan sebagai uang muka keuntungan yang otomatis memotong laba periode berikutnya.</span>
                            </label>
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:14px;">
                            <label>Keterangan Penarikan</label>
                            <input name="investor_withdraw_notes" class="pk01-ctrl" placeholder="Contoh: Transfer keuntungan periode September">
                        </div>

                        <button type="submit" class="pk01-btn pk01-btn-primary">
                            Bayarkan Bagi Hasil Investor
                        </button>
                    </form>
                </div>

                <!-- Penarikan Pengelola Usaha -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px;">
                    <h4 style="margin:0 0 10px; font-size:15px; font-weight:800; color:#0f172a;">Penarikan Hak Laba Pengelola Usaha</h4>
                    <form method="post">
                        <?php wp_nonce_field('pk01_owner_action', 'pk01_owner_nonce'); ?>
                        <input type="hidden" name="pk01_owner_action" value="withdraw_owner">

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Pilih Pengelola Usaha</label>
                            <select name="owner_id" class="pk01-ctrl" required>
                                <option value="">-- Pilih Pengelola --</option>
                                <?php foreach ($owners as $o): 
                                    $ent_o = class_exists('PK01_Engine') ? PK01_Engine::owner_profit_entitlement((int)$o->id, $today) : 0;
                                ?>
                                    <option value="<?php echo (int)$o->id; ?>">
                                        <?php echo esc_html($o->name); ?> (Hak: Rp <?php echo number_format($ent_o, 0, ',', '.'); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Jenis Transaksi</label>
                            <select name="withdraw_type" class="pk01-ctrl">
                                <option value="profit_draw">Tarik Hak Laba Pengelola</option>
                                <option value="owner_advance">Bon / Uang Muka Pengelola</option>
                            </select>
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:12px;">
                            <label>Nominal Penarikan (Rp)</label>
                            <input name="amount" type="number" step="0.01" min="0.01" class="pk01-ctrl" required placeholder="Nominal yang ditarik">
                        </div>

                        <div class="pk01-form-group" style="margin-bottom:14px;">
                            <label>Keterangan</label>
                            <input name="description" class="pk01-ctrl" placeholder="Keterangan penarikan...">
                        </div>

                        <button type="submit" class="pk01-btn pk01-btn-emerald">
                            Cairkan Laba Pengelola
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- 7. TAB 4: RIWAYAT DISTRIBUSI & AUDIT -->
    <div class="pk01-pane" id="tab-history">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📜 Riwayat Distribusi Laba &amp; Bukti Pembayaran</h3>
                    <div class="pk01-surface-desc">
                        Dokumentasi resmi seluruh periode pembagian keuntungan kemitraan yang pernah dieksekusi sistem.
                    </div>
                </div>
            </div>

            <!-- Tabel Distribusi -->
            <div class="pk01-table-card" style="margin-bottom:24px;">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th>No. Referensi</th>
                            <th>Tanggal Periode Buku</th>
                            <th>Total Laba Dibagikan</th>
                            <th>Porsi Pengelola</th>
                            <th>Porsi Investor</th>
                            <th style="text-align:center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($dist)): foreach ($dist as $d): ?>
                        <tr>
                            <td><strong>#DIST-<?php echo esc_html($d->id); ?></strong></td>
                            <td><?php echo esc_html(date_i18n('d M Y', strtotime($d->period_end))); ?></td>
                            <td><span class="pk01-money">Rp <?php echo number_format((float)$d->distributable_profit, 0, ',', '.'); ?></span></td>
                            <td><span class="pk01-money" style="color:#4f46e5;">Rp <?php echo number_format((float)$d->operator_share, 0, ',', '.'); ?></span></td>
                            <td><span class="pk01-money" style="color:#059669;">Rp <?php echo number_format((float)$d->investor_share, 0, ',', '.'); ?></span></td>
                            <td style="text-align:center;">
                                <span class="pk01-badge badge-success">● <?php echo esc_html(strtoupper($d->status)); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="6" style="text-align:center; padding:30px; color:#94a3b8;">Belum ada riwayat distribusi laba yang pernah dibuat.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Tabel Transaksi Pembayaran Terkini -->
            <h4 style="margin:0 0 10px; font-size:15px; font-weight:800; color:#0f172a;">Bukti Pembayaran / Penarikan Terakhir</h4>
            <div class="pk01-table-card">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th>Waktu Transaksi</th>
                            <th>Penerima Dana</th>
                            <th>Tipe Penarikan</th>
                            <th>Nominal</th>
                            <th>No. Referensi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($invtx)): foreach ($invtx as $tx_item): ?>
                        <tr>
                            <td><?php echo esc_html($tx_item->created_at); ?></td>
                            <td><strong><?php echo esc_html($tx_item->investor_name); ?></strong> <span style="font-size:11px; color:#64748b;">(Investor)</span></td>
                            <td><span class="pk01-badge <?php echo $tx_item->transaction_type === 'profit_advance' ? 'badge-warning' : 'badge-success'; ?>"><?php echo esc_html($tx_item->transaction_type); ?></span></td>
                            <td><span class="pk01-money">Rp <?php echo number_format((float)$tx_item->amount, 0, ',', '.'); ?></span></td>
                            <td><code><?php echo esc_html($tx_item->reference_no); ?></code></td>
                        </tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="5" style="text-align:center; padding:24px; color:#94a3b8;">Belum ada riwayat pencairan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH URL
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. LIVE INTERACTIVE 50:50 SPLITTER CALCULATOR
    const totalProfit     = <?php echo (float)$undistributed; ?>;
    const inputOperator   = document.getElementById('input_operator_pct');
    const inputInvestor   = document.getElementById('input_investor_pct');
    const prevOperator    = document.getElementById('pk01-preview-operator');
    const prevInvestor    = document.getElementById('pk01-preview-investor');
    const labelOperator   = document.getElementById('pk01-label-operator');
    const labelInvestor   = document.getElementById('pk01-label-investor');

    function updateSplitter() {
        if (!inputOperator || !inputInvestor) return;

        let opPct = parseFloat(inputOperator.value) || 0;
        let invPct = parseFloat(inputInvestor.value) || 0;

        if (labelOperator) labelOperator.innerText = opPct + '%';
        if (labelInvestor) labelInvestor.innerText = invPct + '%';

        let opVal  = Math.round(totalProfit * (opPct / 100));
        let invVal = Math.round(totalProfit * (invPct / 100));

        if (prevOperator) prevOperator.innerText = opVal.toLocaleString('id-ID');
        if (prevInvestor) prevInvestor.innerText = invVal.toLocaleString('id-ID');
    }

    if (inputOperator && inputInvestor) {
        inputOperator.addEventListener('input', function() {
            let val = Math.max(0, Math.min(100, parseFloat(this.value) || 0));
            inputInvestor.value = (100 - val).toFixed(1).replace('.0', '');
            updateSplitter();
        });

        inputInvestor.addEventListener('input', function() {
            let val = Math.max(0, Math.min(100, parseFloat(this.value) || 0));
            inputOperator.value = (100 - val).toFixed(1).replace('.0', '');
            updateSplitter();
        });

        updateSplitter();
    }
});
</script>