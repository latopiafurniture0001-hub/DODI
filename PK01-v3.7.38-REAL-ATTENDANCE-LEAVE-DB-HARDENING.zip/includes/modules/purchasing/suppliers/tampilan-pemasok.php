<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage   = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('suppliers') || PK01_Authorization::can('inventory') || PK01_Authorization::can('purchasing')));

$action = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('suppliers')
    : add_query_arg('pk01_view', 'suppliers', home_url('/'));

$notice = '';

// Helper Nama Tabel
$tbl_suppliers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('suppliers') 
    : $wpdb->prefix . 'pk01_suppliers';

$tbl_materials = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('materials') 
    : $wpdb->prefix . 'pk01_materials';

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_suppliers)) === $tbl_suppliers);
$has_materials = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_materials)) === $tbl_materials);

// 2. LOGIKA BARU: EKSPOR DATA PEMASOK KE CSV (PROCUREMENT AUDIT)
if (isset($_POST['pk01_export_suppliers_csv']) && check_admin_referer('pk01_export_suppliers_nonce')) {
    if ($can_manage && $table_exists) {
        $export_rows = $wpdb->get_results(
            "SELECT * FROM `{$tbl_suppliers}` ORDER BY id DESC", 
            ARRAY_A
        );
        if (!empty($export_rows)) {
            $filename = 'pk01-master-pemasok-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID', 'Kode Pemasok', 'Nama Pemasok', 'Kontak / WhatsApp', 'Status', 'Waktu Terdaftar']);
            foreach ($export_rows as $r) {
                fputcsv($out, [
                    $r['id'],
                    $r['code'],
                    $r['name'],
                    $r['contact'],
                    ucfirst($r['status']),
                    $r['created_at'] ?? '-'
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. PROSES SIMPAN / UPDATE DATA PEMASOK (LOGIKA LAMA UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_supplier_save'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_supplier_nonce'] ?? '')), 'pk01_supplier_save')) {
        $notice = '<div class="pk01-sup-alert is-error">⚠️ Sesi keamanan tidak valid atau telah kedaluwarsa.</div>';
    } else {
        try {
            $id      = (int)($_POST['id'] ?? 0);
            $code    = sanitize_text_field(wp_unslash($_POST['code'] ?? ''));
            $name    = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
            $contact = sanitize_text_field(wp_unslash($_POST['contact'] ?? ''));
            $status  = in_array($_POST['status'] ?? '', ['active', 'inactive'], true) ? $_POST['status'] : 'active';

            if (empty($name)) {
                throw new Exception('Nama pemasok / vendor wajib diisi.');
            }

            PK01_Engine::save_supplier($id, $code, $name, $contact, $status);
            $notice = '<div class="pk01-sup-alert is-success">✅ Data pemasok <strong>' . esc_html($name) . '</strong> berhasil disimpan.</div>';
            $_POST = [];
        } catch (Throwable $e) {
            $notice = '<div class="pk01-sup-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 4. AMBIL DATA EDIT & DAFTAR REKANAN PEMASOK REAL DARI DATABASE
$edit_id = (int)($_GET['edit_id'] ?? 0);
$edit    = ($edit_id && $table_exists) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_suppliers}` WHERE id = %d", $edit_id), ARRAY_A) : null;

$rows = [];
if ($table_exists) {
    if ($has_materials) {
        $rows = $wpdb->get_results(
            "SELECT s.*, COALESCE((SELECT COUNT(*) FROM `{$tbl_materials}` m WHERE m.supplier_id = s.id), 0) AS total_materials 
             FROM `{$tbl_suppliers}` s 
             ORDER BY s.id DESC LIMIT 150", 
            ARRAY_A
        ) ?: [];
    } else {
        $rows = $wpdb->get_results("SELECT *, 0 AS total_materials FROM `{$tbl_suppliers}` ORDER BY id DESC LIMIT 150", ARRAY_A) ?: [];
    }
}

// 5. METRIK REAL SUPPLY CHAIN
$total_suppliers  = count($rows);
$active_suppliers = 0;
$with_contact     = 0;
$total_items_supplied = 0;

foreach ($rows as $r) {
    if (($r['status'] ?? '') === 'active') $active_suppliers++;
    if (!empty($r['contact'])) $with_contact++;
    $total_items_supplied += (int)($r['total_materials'] ?? 0);
}

// Helper Format WA
if (!function_exists('pk01_format_supplier_wa')) {
    function pk01_format_supplier_wa($phone) {
        $clean = preg_replace('/[^0-9]/', '', $phone);
        if (empty($clean)) return '';
        if (substr($clean, 0, 1) === '0') {
            $clean = '62' . substr($clean, 1);
        } elseif (substr($clean, 0, 2) !== '62') {
            $clean = '62' . $clean;
        }
        return 'https://wa.me/' . $clean;
    }
}

// Saran Kode Otomatis Jika Tambah Baru
$suggested_code = empty($edit['code']) ? 'SUP-' . str_pad((string)($total_suppliers + 1), 3, '0', STR_PAD_LEFT) : $edit['code'];
?>

<style>
:root {
    --pk-sup-navy: #0f172a;
    --pk-sup-border: #e2e8f0;
    --pk-sup-blue: #2563eb;
    --pk-sup-green: #059669;
    --pk-sup-amber: #d97706;
    --pk-sup-purple: #7c3aed;
    --pk-sup-muted: #64748b;
}

.pk01-supplier-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-supplier-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-sup-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-sup-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-sup-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-sup-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-sup-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-sup-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-sup-blue); }
.pk01-kpi-card.c-green::before  { background: var(--pk-sup-green); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-sup-amber); }
.pk01-kpi-card.c-purple::before { background: var(--pk-sup-purple); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--pk-sup-muted);
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: var(--pk-sup-muted);
}

/* Split Form & Guidelines */
.pk01-sup-split {
    display: grid;
    grid-template-columns: 1.4fr 0.9fr;
    gap: 20px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 960px) {
    .pk01-sup-split { grid-template-columns: 1fr; }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-sup-border);
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: var(--pk-sup-blue);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Table Style */
.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-sup-border);
    border-radius: 12px;
}
.pk01-sup-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-sup-table th {
    background: #f8fafc;
    padding: 11px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-sup-border);
}
.pk01-sup-table td {
    padding: 11px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-sup-table tr:hover td { background: #fbfcfe; }

/* Status Badges */
.pk01-badge-status {
    display: inline-block;
    padding: 3px 9px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.badge-active   { background: #dcfce7; color: #166534; }
.badge-inactive { background: #fee2e2; color: #991b1b; }

/* Action Buttons */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-wa {
    background: #25d366;
    color: #ffffff !important;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-btn-wa:hover { background: #1ebc57; }

.pk01-sup-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-sup-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-sup-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-supplier-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-sup-hero">
        <div>
            <span class="pk01-sup-eyebrow">PROCUREMENT &bull; SUPPLY CHAIN MASTER</span>
            <h1>Direktori &amp; Master Pemasok (Vendor)</h1>
            <p>
                Satu basis data vendor terpadu yang menjadi rujukan resmi bagi modul <strong>Bahan Baku Gudang</strong>, 
                <strong>Penerimaan Barang</strong>, dan <strong>Surat Pesanan Pembelian (PO)</strong> di PK01.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_suppliers_nonce'); ?>
                <input type="hidden" name="pk01_export_suppliers_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Katalog Vendor (.CSV)
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-sup-kpis">
        <div class="pk01-kpi-card c-blue">
            <small>Total Pemasok Terdaftar</small>
            <strong><?php echo number_format($total_suppliers); ?> <span style="font-size:13px;font-weight:normal;">Rekanan</span></strong>
            <span>Vendor material terdata</span>
        </div>

        <div class="pk01-kpi-card c-green">
            <small>Pemasok Status Aktif</small>
            <strong style="color:#059669;"><?php echo number_format($active_suppliers); ?> <span style="font-size:13px;font-weight:normal;">Vendor</span></strong>
            <span>Siap melayani pesanan PO</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Kontak WhatsApp Tersimpan</small>
            <strong style="color:#d97706;"><?php echo number_format($with_contact); ?> <span style="font-size:13px;font-weight:normal;">Kontak</span></strong>
            <span>Siap pesan ulang instan</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Material Gudang Terhubung</small>
            <strong style="color:#7c3aed;"><?php echo number_format($total_items_supplied); ?> <span style="font-size:13px;font-weight:normal;">Item</span></strong>
            <span>Item bahan baku teralokasi</span>
        </div>
    </div>

    <!-- 3. SPLIT FORM & PANDUAN PENGADAAN -->
    <div class="pk01-sup-split">
        
        <!-- Form Tambah / Edit Pemasok -->
        <div class="pk01-surface">
            <div class="pk01-surface-head">
                <h3><?php echo $edit ? '✏️ Edit Pemasok: ' . esc_html($edit['name']) : '➕ Tambah Pemasok Baru'; ?></h3>
                <?php if ($edit): ?>
                    <a href="<?php echo esc_url($action); ?>" style="font-size:12px; color:#dc2626; text-decoration:none; font-weight:700;">✕ Batal Edit</a>
                <?php endif; ?>
            </div>

            <form method="post" action="<?php echo esc_url($action); ?>">
                <?php echo wp_nonce_field('pk01_supplier_save', 'pk01_supplier_nonce', true, false); ?>
                <input type="hidden" name="pk01_supplier_save" value="1">
                <input type="hidden" name="id" value="<?php echo (int)($edit['id'] ?? 0); ?>">

                <div class="pk01-form-grid">
                    <div class="pk01-field-item">
                        <label>Kode Pemasok (Vendor Code)</label>
                        <input type="text" name="code" class="pk01-input" value="<?php echo esc_attr($suggested_code); ?>" placeholder="Contoh: SUP-001">
                    </div>

                    <div class="pk01-field-item">
                        <label>Status Kerja Sama <span style="color:#dc2626;">*</span></label>
                        <select name="status" class="pk01-input" style="font-weight:700;">
                            <option value="active" <?php selected($edit['status'] ?? 'active', 'active'); ?>>Aktif (Dapat Dipilih di PO/Bahan)</option>
                            <option value="inactive" <?php selected($edit['status'] ?? '', 'inactive'); ?>>Nonaktif</option>
                        </select>
                    </div>

                    <div class="pk01-field-item" style="grid-column: span 2;">
                        <label>Nama Lengkap Perusahaan / Toko Supplier <span style="color:#dc2626;">*</span></label>
                        <input type="text" name="name" class="pk01-input" required value="<?php echo esc_attr($edit['name'] ?? ''); ?>" placeholder="Contoh: UD Kayu Rimba Sejahtera / CV Logam Jaya">
                    </div>

                    <div class="pk01-field-item" style="grid-column: span 2;">
                        <label>No. Kontak / WhatsApp Sales Vendor</label>
                        <input type="tel" name="contact" id="input_sup_contact" class="pk01-input" value="<?php echo esc_attr($edit['contact'] ?? ''); ?>" placeholder="Contoh: 081298765432">
                        <span id="sup_wa_hint" style="font-size:11px;color:#64748b;margin-top:2px;"></span>
                    </div>
                </div>

                <div style="margin-top:18px; display:flex; gap:10px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        <?php echo $edit ? '💾 Simpan Perubahan Pemasok' : '💾 Simpan Pemasok Baru'; ?>
                    </button>
                    <?php if ($edit): ?>
                        <a class="pk01-btn pk01-btn-export" href="<?php echo esc_url($action); ?>">Batal</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Box Panduan Rantai Pasok -->
        <div class="pk01-surface" style="background:#f8fafc;">
            <div class="pk01-surface-head">
                <h3>💡 Integrasi Rantai Pasok Terpusat</h3>
            </div>
            <p style="font-size:13px; color:#475569; line-height:1.6; margin:0 0 14px 0;">
                Data rekanan vendor yang disimpan di menu ini menjadi acuan tunggal untuk seluruh pengadaan persediaan:
            </p>
            <div style="background:#ffffff; border:1px solid #cbd5e1; border-radius:8px; padding:14px; font-size:13px; margin-bottom:12px;">
                <ul style="margin:0; padding-left:18px; line-height:1.6; color:#1e293b;">
                    <li><b>Master Bahan Baku:</b> Menautkan supplier utama pada setiap item bahan.</li>
                    <li><b>Penerimaan Barang:</b> Memverifikasi barang masuk sesuai surat jalan vendor.</li>
                    <li><b>Hutang Dagang:</b> Riwayat tagihan faktur terdata per pemasok.</li>
                </ul>
            </div>
            <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0;">
                ℹ️ Memperbarui nama atau nomor WhatsApp vendor di sini otomatis menyelaraskan seluruh histori pembelian masa lalu dan masa depan.
            </p>
        </div>

    </div>

    <!-- 4. TOOLBAR PENCARIAN -->
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
        <h3 style="margin:0; font-size:17px; font-weight:800; color:#0f172a;">Daftar Rekanan Pemasok Aktif</h3>
        <input type="search" id="pk01-search-supplier" class="pk01-input" placeholder="🔍 Cari kode, nama vendor, kontak..." style="width:280px;">
    </div>

    <!-- 5. TABEL DATA PEMASOK -->
    <div class="pk01-table-wrap">
        <table id="pk01-table-suppliers" class="pk01-sup-table">
            <thead>
                <tr>
                    <th style="width:110px;">Kode</th>
                    <th>Nama Pemasok / Toko</th>
                    <th>Kontak / WhatsApp</th>
                    <th style="text-align:center;width:120px;">Item Disuplai</th>
                    <th style="text-align:center;width:90px;">Status</th>
                    <th style="text-align:center;width:160px;">Aksi Cepat</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($rows)): ?>
                    <?php foreach ($rows as $r): 
                        $is_act = (($r['status'] ?? '') === 'active');
                        $has_phone = !empty($r['contact']);
                        $wa_link = $has_phone ? pk01_format_supplier_wa($r['contact']) : '';
                    ?>
                    <tr>
                        <td>
                            <code style="background:#f1f5f9; padding:2px 6px; border-radius:4px; font-weight:700; color:#0f172a; border:1px solid #e2e8f0;">
                                <?php echo esc_html($r['code'] ?: 'SUP-'.$r['id']); ?>
                            </code>
                        </td>
                        <td>
                            <strong style="color:#0f172a;"><?php echo esc_html($r['name']); ?></strong>
                        </td>
                        <td>
                            <?php if ($has_phone): ?>
                                <span style="font-family:monospace; font-weight:600;"><?php echo esc_html($r['contact']); ?></span>
                            <?php else: ?>
                                <span style="color:#94a3b8;">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center;">
                            <span style="font-size:12px; font-weight:700; background:#f1f5f9; padding:3px 8px; border-radius:6px; color:#475569;">
                                <?php echo (int)($r['total_materials'] ?? 0); ?> Bahan
                            </span>
                        </td>
                        <td style="text-align:center;">
                            <span class="pk01-badge-status <?php echo $is_act ? 'badge-active' : 'badge-inactive'; ?>">
                                <?php echo $is_act ? 'Aktif' : 'Nonaktif'; ?>
                            </span>
                        </td>
                        <td style="text-align:center;">
                            <div style="display:inline-flex; gap:6px; align-items:center;">
                                <?php if (!empty($wa_link)): ?>
                                    <a class="pk01-btn-wa" target="_blank" href="<?php echo esc_url($wa_link); ?>" title="Hubungi Vendor via WhatsApp">
                                        💬 Chat
                                    </a>
                                <?php endif; ?>
                                <a class="pk01-btn pk01-btn-export" href="<?php echo esc_url(add_query_arg('edit_id', (int)$r['id'], $action)); ?>" style="padding:4px 10px; font-size:12px;">
                                    ✏️ Edit
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:36px; color:#94a3b8;">
                            Belum ada data pemasok yang tersimpan di sistem.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. LIVE WHATSAPP NUMBER HINT
    var contactInput = document.getElementById('input_sup_contact');
    var hint = document.getElementById('sup_wa_hint');

    if (contactInput && hint) {
        contactInput.addEventListener('input', function() {
            var val = this.value.replace(/[^0-9]/g, '');
            if (val.length > 5) {
                if (val.substr(0, 1) === '0') val = '62' + val.substr(1);
                hint.textContent = 'Preview Tautan Langsung: https://wa.me/' + val;
            } else {
                hint.textContent = '';
            }
        });
    }

    // 2. LIVE SEARCH PEMASOK
    var searchInput = document.getElementById('pk01-search-supplier');
    var table       = document.getElementById('pk01-table-suppliers');

    if (searchInput && table) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            var rows   = table.querySelectorAll('tbody tr');

            rows.forEach(function(row) {
                var text = row.innerText.toLowerCase();
                row.style.display = (text.indexOf(filter) > -1) ? '' : 'none';
            });
        });
    }
});
</script>