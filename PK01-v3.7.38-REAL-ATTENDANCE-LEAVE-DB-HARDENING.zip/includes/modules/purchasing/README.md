# PK01 — Modul Purchasing

Folder canonical: `includes/modules/purchasing/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/purchasing/purchase-orders/tampilan-pembelian.php`
- `includes/modules/purchasing/suppliers/tampilan-pemasok.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
