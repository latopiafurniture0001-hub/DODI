<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage   = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('purchasing') || PK01_Authorization::can('inventory')));

$action = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('purchase')
    : add_query_arg('pk01_view', 'purchase', home_url('/'));

// Helper Nama Tabel Resmi PK01
$tbl_po        = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('purchase_orders') : $wpdb->prefix . 'pk01_purchase_orders';
$tbl_suppliers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('suppliers') : $wpdb->prefix . 'pk01_suppliers';
$tbl_receipts  = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('goods_receipts') : $wpdb->prefix . 'pk01_goods_receipts';
$tbl_materials = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('materials') : $wpdb->prefix . 'pk01_materials';

$current_month = current_time('Y-m');

/* Produk Jadi dari Luar: terima stok ke SKU Master PK01 yang sama. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_finished_purchase_save']) && $can_manage) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_finished_purchase_nonce'] ?? '')), 'pk01_finished_purchase')) {
        $notice = '<div class="pk01-op-alert pk01-alert-error">Sesi keamanan kedaluwarsa.</div>';
    } else {
        try {
            $vid=absint($_POST['finished_variant_id']??0); $qty=max(0.0001,(float)($_POST['finished_qty']??0)); $cost=max(0,(float)($_POST['finished_unit_cost']??0)); $supplier=absint($_POST['finished_supplier_id']??0);
            $r=PK01_Engine::purchase_finished_product($vid,$qty,$cost,$supplier,sanitize_textarea_field(wp_unslash($_POST['finished_notes']??'')));
            $notice='<div class="pk01-op-alert pk01-alert-success">✅ Pembelian produk jadi <strong>'.esc_html($r['purchase_no']).'</strong> diterima. Stok <strong>'.esc_html($r['variant_id']).'</strong> bertambah '.number_format($r['qty'],0,',','.').' unit. Produk tetap memakai SKU PK01 yang sama.</div>';
        } catch(Throwable $e){ $notice='<div class="pk01-op-alert pk01-alert-error">❌ '.esc_html($e->getMessage()).'</div>'; }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_external_product_create']) && $can_manage) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_external_product_nonce'] ?? '')), 'pk01_external_product')) {
        $notice = '<div class="pk01-op-alert pk01-alert-error">Sesi keamanan kedaluwarsa.</div>';
    } else {
        try {
            $code=sanitize_text_field(wp_unslash($_POST['ext_product_code']??'')); $name=sanitize_text_field(wp_unslash($_POST['ext_product_name']??'')); $sku=sanitize_text_field(wp_unslash($_POST['ext_product_sku']??''));
            $size=sanitize_text_field(wp_unslash($_POST['ext_product_size']??'')); $material=sanitize_text_field(wp_unslash($_POST['ext_product_material']??'')); $finish=sanitize_text_field(wp_unslash($_POST['ext_product_finish']??''));
            $price=max(0,(float)($_POST['ext_product_price']??0)); $cost=max(0,(float)($_POST['ext_product_cost']??0)); $supplier=absint($_POST['ext_product_supplier']??0);
            if($code===''||$name===''||$sku==='')throw new Exception('Kode Produk, Nama Produk, dan SKU wajib diisi.');
            $pid=PK01_Engine::create_product($code,$name,'Produk jadi dibeli dari luar.',$name,['supply_mode'=>'purchase','spec_status'=>'complete']);
            $vid=PK01_Engine::create_variant($pid,$sku,$name,$size,$material,$finish,$cost,$price,0);
            if($vid<=0)throw new Exception('SKU produk luar gagal dibuat.');
            PK01_Engine::set_variant_supply_mode($vid,'purchase',$supplier,'',$cost);
            $notice='<div class="pk01-op-alert pk01-alert-success">✅ Produk luar <strong>'.esc_html($sku).'</strong> berhasil ditambahkan ke Master PK01 sebagai <b>Produk Beli dari Luar</b>. Stok awal tetap 0; gunakan penerimaan pembelian untuk menambah stok.</div>';
        } catch(Throwable $e){$notice='<div class="pk01-op-alert pk01-alert-error">❌ '.esc_html($e->getMessage()).'</div>';}
    }
}


// 2. LOGIKA BARU: EKSPOR DATA PURCHASE ORDER KE CSV (PROCUREMENT AUDIT)
if (isset($_POST['pk01_export_po_csv']) && check_admin_referer('pk01_export_po_nonce')) {
    if ($can_manage) {
        $export_pos = $wpdb->get_results(
            "SELECT po.*, s.name AS supplier_name 
             FROM `{$tbl_po}` po 
             LEFT JOIN `{$tbl_suppliers}` s ON s.id = po.supplier_id 
             ORDER BY po.id DESC LIMIT 5000", 
            ARRAY_A
        );
        if (!empty($export_pos)) {
            $filename = 'pk01-purchase-orders-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID', 'Nomor PO', 'Pemasok / Vendor', 'Nilai Tagihan (Rp)', 'Status', 'Tanggal Penerbitan']);
            foreach ($export_pos as $p) {
                fputcsv($out, [
                    $p['id'],
                    $p['po_no'],
                    $p['supplier_name'] ?: 'Pemasok Umum',
                    $p['total'],
                    strtoupper($p['status']),
                    $p['created_at']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. PROSES PENERBITAN PURCHASE ORDER (LOGIKA LAMA TETAP UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_po_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_po_nonce'] ?? '')), 'pk01_po_save')) {
        $notice = '<div class="pk01-po-alert is-error">⚠️ Sesi keamanan tidak valid atau telah berakhir. Silakan muat ulang halaman.</div>';
    } else {
        try {
            $supp_id = absint($_POST['supplier_id'] ?? 0);
            
            // Penomoran Dokumen PO Dinamis
            $suggested_po = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'document_number') 
                ? PK01_Engine::document_number('po') 
                : 'PO-' . date('ymd') . '-' . wp_rand(10, 99);

            $po_no = sanitize_text_field(trim($_POST['po_no'] ?? ''));
            if (empty($po_no)) {
                $po_no = $suggested_po;
            }

            $clean_total = (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)($_POST['total'] ?? 0)));

            if ($supp_id <= 0) {
                throw new Exception('Silakan pilih pemasok / vendor penerima pesanan.');
            }

            if ($clean_total < 0) {
                throw new Exception('Nilai total pesanan PO tidak boleh bernilai negatif.');
            }

            $wpdb->insert($tbl_po, [
                'po_no'       => $po_no,
                'supplier_id' => $supp_id,
                'status'      => 'confirmed',
                'total'       => $clean_total,
                'created_at'  => current_time('mysql'),
                'updated_at'  => current_time('mysql')
            ]);

            $notice = '<div class="pk01-po-alert is-success">✅ Purchase Order <strong>' . esc_html($po_no) . '</strong> sebesar <b>Rp ' . number_format($clean_total, 0, ',', '.') . '</b> berhasil diterbitkan!</div>';
            $_POST = [];
        } catch (Throwable $e) {
            $notice = '<div class="pk01-po-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 4. KUERI DATA REAL DARI DATABASE
$suppliers = $wpdb->get_results(
    "SELECT * FROM `{$tbl_suppliers}` WHERE status = 'active' ORDER BY name ASC", 
    ARRAY_A
) ?: [];

$pos = $wpdb->get_results(
    "SELECT po.*, s.name AS supplier_name 
     FROM `{$tbl_po}` po 
     LEFT JOIN `{$tbl_suppliers}` s ON s.id = po.supplier_id 
     ORDER BY po.id DESC LIMIT 50", 
    ARRAY_A
) ?: [];

$receipts = [];
$tbl_receipts_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_receipts)) === $tbl_receipts);
if ($tbl_receipts_exists) {
    $receipts = $wpdb->get_results(
        "SELECT gr.*, po.po_no, s.name AS supplier_name, m.name AS material_name, m.unit AS material_unit 
         FROM `{$tbl_receipts}` gr 
         LEFT JOIN `{$tbl_po}` po ON po.id = gr.po_id 
         LEFT JOIN `{$tbl_suppliers}` s ON s.id = po.supplier_id 
         LEFT JOIN `{$tbl_materials}` m ON m.id = gr.material_id 
         ORDER BY gr.id DESC LIMIT 50", 
        ARRAY_A
    ) ?: [];
}

// 5. METRIK REAL PENGADAAN (NON-DUMMY)
$total_po_all   = count($pos);
$total_cost_month = 0;
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_po)) === $tbl_po) {
    $total_cost_month = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(total), 0) FROM `{$tbl_po}` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s",
        $current_month
    ));
}

$total_receipts_count = count($receipts);
$active_suppliers_count = count($suppliers);

// Penomoran Dokumen PO Usulan
$suggested_po_code = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'document_number') 
    ? PK01_Engine::document_number('po') 
    : 'PO-' . date('ymd') . '-01';

// URL Print Helper
$print_po_all_url = function_exists('pk01_print_url') ? pk01_print_url('pembelian') : '#';
$print_receipt_all_url = function_exists('pk01_print_url') ? pk01_print_url('penerimaan') : '#';
?>

<style>
:root {
    --pk-po-navy: #0f172a;
    --pk-po-border: #e2e8f0;
    --pk-po-blue: #2563eb;
    --pk-po-green: #059669;
    --pk-po-amber: #d97706;
    --pk-po-purple: #7c3aed;
    --pk-po-muted: #64748b;
}

.pk01-purchasing-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-purchasing-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-po-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-po-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-po-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-po-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-po-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-po-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-po-blue); }
.pk01-kpi-card.c-green::before  { background: var(--pk-po-green); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-po-amber); }
.pk01-kpi-card.c-purple::before { background: var(--pk-po-purple); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--pk-po-muted);
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: var(--pk-po-muted);
}

/* Split Form & Guidelines */
.pk01-po-split {
    display: grid;
    grid-template-columns: 1.4fr 0.9fr;
    gap: 20px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 960px) {
    .pk01-po-split { grid-template-columns: 1fr; }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-po-border);
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: var(--pk-po-blue);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Quick Increment Pills */
.pk01-amount-pills {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 4px;
}
.pk01-pill-amt {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 10px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill-amt:hover {
    background: #0f172a;
    color: #ffffff;
    border-color: #0f172a;
}

/* Tab Switcher Strip */
.pk01-po-tabs {
    display: flex;
    gap: 8px;
    border-bottom: 2px solid var(--pk-po-border);
    margin-bottom: 22px;
    overflow-x: auto;
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-po-muted);
    border: none;
    background: transparent;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    margin-bottom: -2px;
    transition: all .15s ease;
    white-space: nowrap;
}
.pk01-tab-btn:hover { color: #0f172a; }
.pk01-tab-btn.active {
    color: var(--pk-po-blue);
    border-bottom-color: var(--pk-po-blue);
}

.pk01-tab-pane { display: none; }
.pk01-tab-pane.active { display: block; animation: pk01Fade .2s ease-in-out; }
@keyframes pk01Fade { from { opacity: 0; transform: translateY(3px); } to { opacity: 1; transform: translateY(0); } }

/* Table Style */
.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-po-border);
    border-radius: 12px;
}
.pk01-po-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-po-table th {
    background: #f8fafc;
    padding: 11px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-po-border);
}
.pk01-po-table td {
    padding: 11px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-po-table tr:hover td { background: #fbfcfe; }

/* Status Badges */
.pk01-status-pill {
    display: inline-block;
    padding: 3px 9px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.3px;
}
.st-confirmed { background: #dcfce7; color: #166534; }
.st-pending   { background: #fef3c7; color: #92400e; }

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-pdf {
    background: #eff6ff;
    color: #2563eb !important;
    border: 1px solid #bfdbfe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-btn-pdf:hover {
    background: #2563eb;
    color: #ffffff !important;
}

.pk01-po-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-po-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-po-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-purchasing-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-po-hero">
        <div>
            <span class="pk01-po-eyebrow">PROCUREMENT &bull; PURCHASE ORDER ENGINE</span>
            <h1>Pembelian Bahan Baku &amp; Pengadaan (PO)</h1>
            <p>
                Kelola surat pesanan pembelian bahan baku, kayu, logam, cat finishing, dan perlengkapan produksi. 
                Penerbitan PO menjadi acuan resmi penerimaan barang masuk di gudang serta kontrol hutang ke pihak pemasok.
            </p>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <?php if ($print_po_all_url !== '#'): ?>
                <a class="pk01-btn pk01-btn-export" target="_blank" href="<?php echo esc_url($print_po_all_url); ?>">
                    🖨️ Cetak Semua PO PDF
                </a>
            <?php endif; ?>
            <?php if ($print_receipt_all_url !== '#'): ?>
                <a class="pk01-btn pk01-btn-export" target="_blank" href="<?php echo esc_url($print_receipt_all_url); ?>">
                    📄 Cetak Penerimaan PDF
                </a>
            <?php endif; ?>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_po_nonce'); ?>
                <input type="hidden" name="pk01_export_po_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor PO CSV
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-po-kpis">
        <div class="pk01-kpi-card c-green">
            <small>Total Belanja PO Bulan Ini</small>
            <strong style="color:#059669;">Rp <?php echo number_format($total_cost_month, 0, ',', '.'); ?></strong>
            <span>Periode: <?php echo esc_html(date_i18n('F Y')); ?></span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Total Purchase Order (PO)</small>
            <strong style="color:#1d4ed8;"><?php echo number_format($total_po_all); ?> <span style="font-size:13px;font-weight:normal;">Berkas</span></strong>
            <span>Dokumen pesanan diterbitkan</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Penerimaan Barang Masuk</small>
            <strong style="color:#7c3aed;"><?php echo number_format($total_receipts_count); ?> <span style="font-size:13px;font-weight:normal;">Tanda Terima</span></strong>
            <span>Tercatat di kartu stok gudang</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Rekanan Pemasok Aktif</small>
            <strong style="color:#d97706;"><?php echo number_format($active_suppliers_count); ?> <span style="font-size:13px;font-weight:normal;">Vendor</span></strong>
            <span>Siap melayani pesanan PO</span>
        </div>
    </div>

    <!-- 3. SPLIT FORM TERBITKAN PO & PANDUAN PENGADAAN -->
    <?php if ($can_manage): ?>
    <div class="pk01-po-split">
        
        <div class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>📝 Terbitkan Purchase Order (PO) Baru</h3>
            </div>

            <form method="post" action="<?php echo esc_url($action); ?>">
                <?php echo wp_nonce_field('pk01_po_save', 'pk01_po_nonce', true, false); ?>
                <input type="hidden" name="pk01_po_action" value="create">

                <div class="pk01-form-grid">
                    <div class="pk01-field-item">
                        <label>Nomor Dokumen PO</label>
                        <input type="text" name="po_no" class="pk01-input" placeholder="<?php echo esc_attr($suggested_po_code); ?>" style="font-family:monospace;font-weight:700;">
                    </div>

                    <div class="pk01-field-item">
                        <label>Pemasok / Vendor <span style="color:#dc2626;">*</span></label>
                        <select name="supplier_id" class="pk01-input" required>
                            <option value="">— Pilih Rekanan Pemasok —</option>
                            <?php foreach ($suppliers as $s): ?>
                                <option value="<?php echo (int)$s['id']; ?>">
                                    <?php echo esc_html($s['name']); ?> (<?php echo esc_html($s['code'] ?: 'SUP-'.$s['id']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>Total Nilai Tagihan Pembelian (Rp) <span style="color:#dc2626;">*</span></label>
                        <input type="number" min="0" step="any" id="pk01-po-total" name="total" class="pk01-input" placeholder="Contoh: 2500000" required>
                        <div class="pk01-amount-pills">
                            <span class="pk01-pill-amt" data-amt="500000">+500 rb</span>
                            <span class="pk01-pill-amt" data-amt="1000000">+1 jt</span>
                            <span class="pk01-pill-amt" data-amt="2500000">+2.5 jt</span>
                            <span class="pk01-pill-amt" data-amt="5000000">+5 jt</span>
                            <span class="pk01-pill-amt" data-amt="10000000">+10 jt</span>
                            <span class="pk01-pill-amt" data-amt="25000000">+25 jt</span>
                        </div>
                    </div>
                </div>

                <div style="margin-top:16px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        📑 Terbitkan Purchase Order
                    </button>
                </div>
            </form>
        </div>

        <!-- Box Panduan Pengadaan & Hutang -->
        <div class="pk01-surface" style="background:#f8fafc;">
            <div class="pk01-surface-head">
                <h3>💡 Alur Pengadaan &amp; Hutang Dagang</h3>
            </div>
            <p style="font-size:13px; color:#475569; line-height:1.6; margin:0 0 14px 0;">
                Penerbitan PO adalah jembatan kontrol perbendaharaan antara pesanan kantor dengan stok barang masuk:
            </p>
            <div style="background:#ffffff; border:1px solid #cbd5e1; border-radius:8px; padding:14px; font-size:13px; margin-bottom:12px;">
                <ul style="margin:0; padding-left:18px; line-height:1.6; color:#1e293b;">
                    <li><b>Validasi Gudang:</b> Tim gudang hanya menerima barang yang nomor PO-nya cocok.</li>
                    <li><b>Kontrol Kas:</b> Pengeluaran kas terverifikasi sesuai total tagihan pada berkas PO.</li>
                    <li><b>Pencegahan Duplikasi:</b> Setiap bahan terdata riwayat vendor asalnya.</li>
                </ul>
            </div>
            <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0;">
                ℹ️ Setelah bahan diterima fisik di gudang, penerimaan dapat dicatat di menu <strong>Penerimaan Barang</strong> untuk menambah stok kartu bahan secara otomatis.
            </p>
        </div>

    </div>
    <?php endif; ?>

    <!-- 4. TABS NAVIGASI BERKAS PENGADAAN -->
    <nav class="pk01-po-tabs" aria-label="Navigasi Berkas Pengadaan">
        <button type="button" class="pk01-tab-btn active" data-target="tab-pos">
            📑 Daftar Purchase Order (<?php echo count($pos); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-receipts">
            📦 Riwayat Penerimaan Barang (<?php echo count($receipts); ?>)
        </button>
    </nav>

    <!-- TAB 1: DAFTAR PURCHASE ORDER -->
    <div class="pk01-tab-pane active" id="tab-pos">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>📑 Daftar Dokumen Purchase Order (PO) Terbaru</h3>
                <input type="search" id="pk01-search-po" class="pk01-input" placeholder="🔍 Cari no PO, pemasok..." style="width:240px;">
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-po-table" id="pk01-table-pos">
                    <thead>
                        <tr>
                            <th style="width:160px;">No. PO</th>
                            <th>Pemasok / Vendor</th>
                            <th style="text-align:right;">Nilai Pembelian</th>
                            <th style="text-align:center;width:120px;">Status</th>
                            <th>Tanggal Terbit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($pos)): ?>
                            <?php foreach ($pos as $p): ?>
                            <tr>
                                <td>
                                    <strong style="font-family:monospace; color:#0f172a;"><?php echo esc_html($p['po_no']); ?></strong>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($p['supplier_name'] ?: 'Pemasok Umum'); ?></strong>
                                </td>
                                <td style="text-align:right; font-family:monospace; font-weight:800; color:#0f172a;">
                                    Rp <?php echo number_format((float)$p['total'], 0, ',', '.'); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-status-pill st-confirmed">
                                        <?php echo esc_html(strtoupper($p['status'] ?: 'CONFIRMED')); ?>
                                    </span>
                                </td>
                                <td style="color:#64748b; font-size:12px;">
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($p['created_at']))); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align:center; padding:36px; color:#94a3b8;">
                                    Belum ada transaksi pembelian Purchase Order (PO) yang tercatat.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 2: RIWAYAT PENERIMAAN BARANG -->
    <div class="pk01-tab-pane" id="tab-receipts">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>📦 Riwayat Penerimaan Fisik Barang Masuk (Goods Receipts)</h3>
                <span style="font-size:12px; color:#64748b;">Sinkron langsung dengan kartu stok bahan baku gudang</span>
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-po-table">
                    <thead>
                        <tr>
                            <th style="width:130px;">No. Bukti</th>
                            <th>No. PO Terkait</th>
                            <th>Pemasok</th>
                            <th>Bahan / Material</th>
                            <th style="text-align:center;">Kuantitas Masuk</th>
                            <th>Waktu Terima</th>
                            <th style="text-align:center;width:110px;">Cetak Bukti</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($receipts)): ?>
                            <?php foreach ($receipts as $gr): 
                                $qty_str = rtrim(rtrim(number_format((float)$gr['qty'], 4, ',', '.'), '0'), ',');
                                $receipt_pdf_url = function_exists('pk01_print_url') 
                                    ? pk01_print_url('penerimaan', (int)$gr['id']) 
                                    : add_query_arg(['pk01_print'=>'penerimaan', 'id'=>(int)$gr['id']], home_url('/'));
                            ?>
                            <tr>
                                <td>
                                    <strong style="font-family:monospace; color:#0f172a;"><?php echo esc_html($gr['receipt_no']); ?></strong>
                                </td>
                                <td>
                                    <span style="font-family:monospace; color:#64748b;"><?php echo esc_html($gr['po_no'] ?: '—'); ?></span>
                                </td>
                                <td><?php echo esc_html($gr['supplier_name'] ?: '—'); ?></td>
                                <td><strong><?php echo esc_html($gr['material_name'] ?: 'Bahan Baku'); ?></strong></td>
                                <td style="text-align:center; font-family:monospace; font-weight:800; color:#047857;">
                                    <?php echo esc_html($qty_str . ' ' . ($gr['material_unit'] ?? '')); ?>
                                </td>
                                <td style="color:#64748b; font-size:12px;"><?php echo esc_html($gr['received_at']); ?></td>
                                <td style="text-align:center;">
                                    <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($receipt_pdf_url); ?>">
                                        🖨️ PDF
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align:center; padding:36px; color:#94a3b8;">
                                    Belum ada catatan fisik penerimaan barang masuk di gudang.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. QUICK AMOUNT INCREMENT PILLS
    var amtInput = document.getElementById('pk01-po-total');
    var amtPills = document.querySelectorAll('.pk01-pill-amt');

    if (amtInput && amtPills.length > 0) {
        amtPills.forEach(function(pill) {
            pill.addEventListener('click', function() {
                var cur = parseFloat(amtInput.value) || 0;
                var add = parseFloat(this.dataset.amt) || 0;
                amtInput.value = cur + add;
                amtInput.focus();
            });
        });
    }

    // 2. TAB SWITCHER (PO vs GOODS RECEIPTS)
    var tabBtns = document.querySelectorAll('.pk01-tab-btn');
    var panes   = document.querySelectorAll('.pk01-tab-pane');

    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            tabBtns.forEach(function(b) { b.classList.remove('active'); });
            panes.forEach(function(p) { p.classList.remove('active'); });

            this.classList.add('active');
            var targetId   = this.getAttribute('data-target');
            var targetPane = document.getElementById(targetId);
            if (targetPane) targetPane.classList.add('active');
        });
    });

    // 3. LIVE SEARCH PURCHASE ORDERS
    var searchInput = document.getElementById('pk01-search-po');
    var table       = document.getElementById('pk01-table-pos');

    if (searchInput && table) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            var rows   = table.querySelectorAll('tbody tr');

            rows.forEach(function(row) {
                var text = row.innerText.toLowerCase();
                row.style.display = (text.indexOf(filter) > -1) ? '' : 'none';
            });
        });
    }
});
</script>