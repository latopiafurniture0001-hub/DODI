<?php
if (!defined('ABSPATH')) exit;
if (!is_user_logged_in() || !class_exists('PK01_Authorization') || !PK01_Authorization::can('administration')) return;

global $wpdb;

$T = function($k) { return PK01_DB::t($k); };
$count = function($sql) use ($wpdb) { 
    $val = $wpdb->get_var($sql);
    return $val !== null ? (int)$val : 0; 
};

$today = current_time('Y-m-d');

// 1. DATA STATISTIK OPERASIONAL
$emp_active = $count("SELECT COUNT(*) FROM " . $T('employees') . " WHERE status='active'");
$att_today  = $count("SELECT COUNT(DISTINCT employee_id) FROM " . $T('attendance_records') . " WHERE work_date = '" . esc_sql($today) . "'");
$inside     = $count("SELECT COUNT(*) FROM " . $T('security_visitor_visits') . " WHERE status='inside'");
$incidents  = $count("SELECT COUNT(*) FROM " . $T('security_incidents') . " WHERE status='open'");
$jobs       = $count("SELECT COUNT(*) FROM " . $T('jobs') . " WHERE status NOT IN ('completed','cancelled','selesai')");

// Hitung Rasio Kehadiran (%)
$att_percentage = ($emp_active > 0) ? round(($att_today / $emp_active) * 100) : 0;

// URL Generator
$base = class_exists('PK01_Shortcodes') ? PK01_Shortcodes::frontend_url_public('') : PK01_DB::page_url();

// 2. AMBIL 5 LOG AKTIVITAS TERAKHIR (REAL-TIME AUDIT FEED)
$recent_logs = [];
$tbl_logs = $T('activity_logs');
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
    $recent_logs = $wpdb->get_results(
        "SELECT l.*, u.display_name, u.user_login 
         FROM `{$tbl_logs}` l 
         LEFT JOIN `{$wpdb->users}` u ON u.ID = l.user_id 
         ORDER BY l.id DESC LIMIT 5",
        ARRAY_A
    ) ?: [];
}
?>

<style>
:root {
    --pk-adm-slate-900: #0f172a;
    --pk-adm-slate-800: #1e293b;
    --pk-adm-slate-600: #475569;
    --pk-adm-slate-200: #e2e8f0;
    --pk-adm-slate-100: #f8fafc;
    --pk-adm-indigo: #4f46e5;
    --pk-adm-emerald: #10b981;
    --pk-adm-amber: #f59e0b;
    --pk-adm-rose: #ef4444;
    --pk-adm-sky: #0284c7;
    --pk-adm-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-adm-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 40px;
}
.pk01-adm-app * { box-sizing: border-box; }

/* Hero Cockpit */
.pk01-adm-hero {
    background: linear-gradient(135deg, #090d16 0%, #111827 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 24px;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.25);
}
.pk01-adm-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    margin: 6px 0;
    color: #f8fafc;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-adm-hero-left p {
    margin: 0;
    color: #94a3b8;
    font-size: 13.5px;
    max-width: 720px;
    line-height: 1.5;
}
.pk01-adm-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.2);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}

/* Operational Status Badge */
.pk01-adm-status-box {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 12px;
    padding: 12px 18px;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 4px;
}
.pk01-live-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    font-weight: 700;
    color: #4ade80;
}
.pk01-live-dot {
    width: 8px;
    height: 8px;
    background: #4ade80;
    border-radius: 50%;
    box-shadow: 0 0 0 rgba(74, 222, 128, 0.4);
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 5 KPI Cards Grid */
.pk01-adm-kpi-deck {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}
@media (max-width: 1200px) {
    .pk01-adm-kpi-deck { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 768px) {
    .pk01-adm-kpi-deck { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 480px) {
    .pk01-adm-kpi-deck { grid-template-columns: 1fr; }
}

.pk01-adm-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-adm-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-adm-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.pk01-adm-kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.08);
}
.pk01-adm-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; height: 4px;
}
.pk01-adm-kpi-card.c-emerald::before { background: var(--pk-adm-emerald); }
.pk01-adm-kpi-card.c-indigo::before  { background: var(--pk-adm-indigo); }
.pk01-adm-kpi-card.c-sky::before     { background: var(--pk-adm-sky); }
.pk01-adm-kpi-card.c-rose::before    { background: var(--pk-adm-rose); }
.pk01-adm-kpi-card.c-amber::before   { background: var(--pk-adm-amber); }

.pk01-kpi-label {
    font-size: 11px;
    font-weight: 700;
    color: var(--pk-adm-slate-600);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk01-kpi-val {
    font-size: 28px;
    font-weight: 800;
    color: var(--pk-adm-slate-900);
    margin: 8px 0 4px;
    line-height: 1;
}
.pk01-kpi-foot {
    font-size: 11.5px;
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 4px;
}

/* Module Launcher Grid */
.pk01-adm-modules {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}
@media (max-width: 1024px) {
    .pk01-adm-modules { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 580px) {
    .pk01-adm-modules { grid-template-columns: 1fr; }
}

.pk01-module-btn {
    background: #ffffff;
    border: 1px solid var(--pk-adm-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    text-decoration: none !important;
    color: inherit;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: var(--pk-adm-shadow);
    transition: all 0.2s ease;
}
.pk01-module-btn:hover {
    border-color: var(--pk-adm-indigo);
    background: #fbfcfe;
    transform: translateY(-2px);
    box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.1);
}
.pk01-module-info {
    display: flex;
    align-items: center;
    gap: 14px;
}
.pk01-module-icon {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    background: #f1f5f9;
}
.pk01-module-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--pk-adm-slate-900);
    margin-bottom: 2px;
}
.pk01-module-desc {
    font-size: 11.5px;
    color: var(--pk-adm-slate-600);
}
.pk01-module-arrow {
    font-size: 16px;
    color: #94a3b8;
    transition: transform 0.2s ease;
}
.pk01-module-btn:hover .pk01-module-arrow {
    transform: translateX(4px);
    color: var(--pk-adm-indigo);
}

/* Two Column Lower Section */
.pk01-adm-split {
    display: grid;
    grid-template-columns: 1.4fr 1fr;
    gap: 20px;
}
@media (max-width: 992px) {
    .pk01-adm-split { grid-template-columns: 1fr; }
}

.pk01-adm-card {
    background: #ffffff;
    border: 1px solid var(--pk-adm-slate-200);
    border-radius: 16px;
    padding: 22px 24px;
    box-shadow: var(--pk-adm-shadow);
}
.pk01-card-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-adm-slate-100);
    padding-bottom: 12px;
    margin-bottom: 16px;
}
.pk01-card-head h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 800;
    color: var(--pk-adm-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Audit Feed */
.pk01-feed-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.pk01-feed-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 10px 12px;
    border-radius: 8px;
    background: #f8fafc;
    border: 1px solid #f1f5f9;
}
.pk01-feed-icon {
    font-size: 14px;
    margin-top: 2px;
}
.pk01-feed-body {
    flex: 1;
    font-size: 12.5px;
}
.pk01-feed-body strong {
    color: var(--pk-adm-slate-900);
}
.pk01-feed-time {
    font-size: 11px;
    color: #94a3b8;
    white-space: nowrap;
}

/* Governance Card */
.pk01-gov-box {
    background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
    border: 1px solid #bbf7d0;
}
.pk01-gov-points {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 14px;
}
.pk01-gov-point {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    font-size: 12.5px;
    color: #334155;
    line-height: 1.5;
}
.pk01-gov-badge {
    background: #166534;
    color: #ffffff;
    font-size: 10px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    flex-shrink: 0;
    margin-top: 2px;
}
</style>

<div class="pk01-adm-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-adm-hero">
        <div class="pk01-adm-hero-left">
            <span class="pk01-adm-tag">OPERATIONAL CONTROL &bull; NON-FINANCE CORE</span>
            <h1>🏢 Pusat Kendali Administrasi</h1>
            <p>
                Sentralisasi pengawasan tata kelola personalia SDM, presensi, penjagaan pos sekuriti, kepatuhan K3/insiden, dan log aktivitas operasional harian.
            </p>
        </div>

        <div class="pk01-adm-status-box">
            <div class="pk01-live-badge">
                <span class="pk01-live-dot"></span>
                <span>SISTEM AKTIF</span>
            </div>
            <div style="font-size:12px; color:#cbd5e1;" id="pk01-adm-clock">
                <?php echo date_i18n('l, d F Y'); ?>
            </div>
        </div>
    </header>

    <!-- 2. 5 EXECUTIVE KPI CARDS -->
    <section class="pk01-adm-kpi-deck">
        
        <!-- Karyawan Aktif -->
        <div class="pk01-adm-kpi-card c-emerald">
            <div class="pk01-kpi-label">
                <span>Karyawan Aktif</span>
                <span>👥</span>
            </div>
            <div class="pk01-kpi-val"><?php echo number_format($emp_active); ?></div>
            <div class="pk01-kpi-foot">
                <span style="color:#059669; font-weight:700;">● Terdaftar</span> di Master SDM
            </div>
        </div>

        <!-- Presensi Hari Ini -->
        <div class="pk01-adm-kpi-card c-indigo">
            <div class="pk01-kpi-label">
                <span>Presensi Hari Ini</span>
                <span>🕘</span>
            </div>
            <div class="pk01-kpi-val"><?php echo number_format($att_today); ?></div>
            <div class="pk01-kpi-foot">
                <span>Rasio: <b><?php echo $att_percentage; ?>%</b> kehadiran</span>
            </div>
        </div>

        <!-- Tamu di Area -->
        <div class="pk01-adm-kpi-card c-sky">
            <div class="pk01-kpi-label">
                <span>Tamu di Area</span>
                <span>🎫</span>
            </div>
            <div class="pk01-kpi-val"><?php echo number_format($inside); ?></div>
            <div class="pk01-kpi-foot">
                <span>Sedang berada di lokasi</span>
            </div>
        </div>

        <!-- Insiden Terbuka -->
        <div class="pk01-adm-kpi-card c-rose">
            <div class="pk01-kpi-label">
                <span>Insiden Terbuka</span>
                <span>⚠️</span>
            </div>
            <div class="pk01-kpi-val" style="<?php echo ($incidents > 0) ? 'color:#dc2626;' : ''; ?>">
                <?php echo number_format($incidents); ?>
            </div>
            <div class="pk01-kpi-foot">
                <?php if ($incidents > 0): ?>
                    <span style="color:#dc2626; font-weight:700;">Butuh tindakan penanganan!</span>
                <?php else: ?>
                    <span style="color:#059669;">Nol insiden dilaporkan</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Job Produksi Berjalan -->
        <div class="pk01-adm-kpi-card c-amber">
            <div class="pk01-kpi-label">
                <span>Job SPK Berjalan</span>
                <span>⚙️</span>
            </div>
            <div class="pk01-kpi-val"><?php echo number_format($jobs); ?></div>
            <div class="pk01-kpi-foot">
                <span>Lantai produksi aktif</span>
            </div>
        </div>

    </section>

    <!-- 3. INTERACTIVE MODULE LAUNCHER -->
    <nav class="pk01-adm-modules">
        
        <a class="pk01-module-btn" href="<?php echo esc_url(add_query_arg('pk01_view', 'attendance', $base)); ?>">
            <div class="pk01-module-info">
                <div class="pk01-module-icon" style="background:#eef2ff; color:#4f46e5;">🕘</div>
                <div>
                    <div class="pk01-module-title">Presensi & Cuti</div>
                    <div class="pk01-module-desc">Biometrik, jam kerja & izin</div>
                </div>
            </div>
            <div class="pk01-module-arrow">→</div>
        </a>

        <a class="pk01-module-btn" href="<?php echo esc_url(add_query_arg('pk01_view', 'hr', $base)); ?>">
            <div class="pk01-module-info">
                <div class="pk01-module-icon" style="background:#ecfdf5; color:#059669;">👥</div>
                <div>
                    <div class="pk01-module-title">Manajemen SDM</div>
                    <div class="pk01-module-desc">Master profil & borongan</div>
                </div>
            </div>
            <div class="pk01-module-arrow">→</div>
        </a>

        <a class="pk01-module-btn" href="<?php echo esc_url(add_query_arg('pk01_view', 'security', $base)); ?>">
            <div class="pk01-module-info">
                <div class="pk01-module-icon" style="background:#f0f9ff; color:#0284c7;">🛡️</div>
                <div>
                    <div class="pk01-module-title">Keamanan & Tamu</div>
                    <div class="pk01-module-desc">Buku tamu & log insiden</div>
                </div>
            </div>
            <div class="pk01-module-arrow">→</div>
        </a>

        <a class="pk01-module-btn" href="<?php echo esc_url(add_query_arg('pk01_view', 'logs', $base)); ?>">
            <div class="pk01-module-info">
                <div class="pk01-module-icon" style="background:#faf5ff; color:#7c3aed;">📋</div>
                <div>
                    <div class="pk01-module-title">Audit Trail & Log</div>
                    <div class="pk01-module-desc">Rekam jejak aktivitas sistem</div>
                </div>
            </div>
            <div class="pk01-module-arrow">→</div>
        </a>

    </nav>

    <!-- 4. LOWER SECTION: LIVE AUDIT FEED & GOVERNANCE -->
    <div class="pk01-adm-split">
        
        <!-- Live Audit Activity Feed -->
        <div class="pk01-adm-card">
            <div class="pk01-card-head">
                <h3>📋 Jejak Aktivitas Terkini (Audit Log)</h3>
                <a href="<?php echo esc_url(add_query_arg('pk01_view', 'logs', $base)); ?>" style="font-size:12px; color:var(--pk-adm-indigo); text-decoration:none; font-weight:700;">Lihat Semua &rarr;</a>
            </div>

            <div class="pk01-feed-list">
                <?php if (!empty($recent_logs)): foreach ($recent_logs as $lg): ?>
                    <div class="pk01-feed-item">
                        <span class="pk01-feed-icon">⚡</span>
                        <div class="pk01-feed-body">
                            <div>
                                <strong><?php echo esc_html($lg['display_name'] ?: $lg['user_login'] ?: 'System'); ?></strong>
                                <span style="color:#64748b;">— <?php echo esc_html($lg['description'] ?: $lg['action']); ?></span>
                            </div>
                            <?php if (!empty($lg['entity'])): ?>
                                <code style="font-size:11px; color:#475569; background:#fff; padding:1px 5px; border-radius:4px; border:1px solid #e2e8f0; margin-top:2px; display:inline-block;">
                                    <?php echo esc_html($lg['entity']); ?>
                                </code>
                            <?php endif; ?>
                        </div>
                        <div class="pk01-feed-time">
                            <?php echo human_time_diff(strtotime($lg['created_at']), current_time('timestamp')) . ' lalu'; ?>
                        </div>
                    </div>
                <?php endforeach; else: ?>
                    <div style="text-align:center; padding:25px; color:#94a3b8; font-size:13px;">
                        Belum ada rekaman log audit terkini.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Governance & Separation of Duties Card -->
        <div class="pk01-adm-card pk01-gov-box">
            <div class="pk01-card-head" style="border-bottom-color:#bbf7d0;">
                <h3 style="color:#166534;">🏛️ Kepatuhan &amp; Pemisahan Wewenang (SOP)</h3>
            </div>
            
            <p style="font-size:12.5px; color:#334155; line-height:1.5; margin:0 0 12px;">
                Untuk menjaga akuntabilitas dan mematuhi prinsip <i>Separation of Duties</i> (SoD), modul <b>Administrasi</b> dan <b>Keuangan/Akuntansi</b> dipisahkan secara ketat:
            </p>

            <div class="pk01-gov-points">
                <div class="pk01-gov-point">
                    <span class="pk01-gov-badge">ADMIN</span>
                    <div>
                        <b>Wewenang Non-Keuangan:</b> Pengelolaan personil, pencatatan presensi biometrik, perizinan cuti, buku tamu, keselamatan fisik, serta audit akses.
                    </div>
                </div>
                <div class="pk01-gov-point">
                    <span class="pk01-gov-badge" style="background:#0f172a;">KEUANGAN</span>
                    <div>
                        <b>Wewenang Finansial Khusus:</b> Arus kas, jurnal umum, HPP produksi, pencairan gaji (payroll disbursement), hutang-piutang, dan pelaporan laba/rugi.
                    </div>
                </div>
            </div>

            <div style="margin-top:16px; padding:10px 12px; background:#ffffff; border:1px solid #bbf7d0; border-radius:8px; font-size:11.5px; color:#166534; display:flex; align-items:center; gap:6px;">
                <span>🛡️</span>
                <span>Standar audit operasional & perlindungan data internal aktif.</span>
            </div>
        </div>

    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Live update jam operasional
    var clockEl = document.getElementById('pk01-adm-clock');
    if (clockEl) {
        var baseDate = clockEl.innerText.split('•')[0].trim();
        function updateTime() {
            var now = new Date();
            var timeStr = now.toLocaleTimeString('id-ID', { hour12: false });
            clockEl.innerHTML = baseDate + ' &bull; <b>' + timeStr + ' WIB</b>';
        }
        updateTime();
        setInterval(updateTime, 1000);
    }
});
</script>