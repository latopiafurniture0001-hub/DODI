<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && PK01_Authorization::can('system_logs'));

if (!$can_manage) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;">Akses Ditolak</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin otorisasi untuk mengakses modul audit trail log aktivitas.</p>
          </div>';
    return;
}

// 2. DETEKSI TABEL & SKEMA DATABASE
$table_name = class_exists('PK01_Audit') && method_exists('PK01_Audit', 'table') 
    ? PK01_Audit::table() 
    : (class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('activity_logs') : $wpdb->prefix . 'pk01_activity_logs');

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) === $table_name);

// Deteksi Kolom Waktu Otomatis
$col_time = 'timestamp';
if ($table_exists) {
    $has_created_at = $wpdb->get_results("SHOW COLUMNS FROM `{$table_name}` LIKE 'created_at'");
    if (!empty($has_created_at)) {
        $col_time = 'created_at';
    }
}

// 3. PROSES PEMBERSIHAN LOG LAMA (MAINTENANCE & RETENSI)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_action_clean_logs'])) {
    check_admin_referer('pk01_clean_logs_action', 'pk01_logs_nonce');
    $days = absint($_POST['purge_days'] ?? 90);
    if ($days > 0 && $table_exists) {
        try {
            $deleted = $wpdb->query($wpdb->prepare(
                "DELETE FROM `{$table_name}` WHERE `{$col_time}` < DATE_SUB(NOW(), INTERVAL %d DAY)",
                $days
            ));
            // Optimalkan tabel setelah penghapusan massal
            $wpdb->query("OPTIMIZE TABLE `{$table_name}`");
            $notice = '<div class="pk01-log-alert is-success">✅ Berhasil membersihkan <strong>' . number_format((int)$deleted) . '</strong> riwayat log yang berusia lebih dari ' . $days . ' hari. Tabel database telah dioptimalkan.</div>';
        } catch (Throwable $e) {
            $notice = '<div class="pk01-log-alert is-error">❌ Gagal membersihkan log: ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 4. FILTER PARAMETER DARI URL
$filter_search = sanitize_text_field($_GET['log_search'] ?? '');
$filter_level  = sanitize_key($_GET['log_level'] ?? '');
$filter_module = sanitize_key($_GET['log_module'] ?? '');
$filter_days   = absint($_GET['log_days'] ?? 30);
if (!in_array($filter_days, [7, 30, 90, 180, 365], true)) $filter_days = 30;

// 5. PROSES EKSPOR CSV ARSIP AUDIT TRAIL
if (isset($_POST['pk01_action_export_csv']) && check_admin_referer('pk01_export_logs_csv_nonce')) {
    if ($table_exists) {
        $where_exp = ["1=1"];
        $params_exp = [];

        if ($filter_days > 0) {
            $where_exp[] = "`{$col_time}` >= DATE_SUB(NOW(), INTERVAL %d DAY)";
            $params_exp[] = $filter_days;
        }
        if (!empty($filter_level)) {
            $where_exp[] = "level = %s";
            $params_exp[] = $filter_level;
        }
        if (!empty($filter_module)) {
            $where_exp[] = "module = %s";
            $params_exp[] = $filter_module;
        }

        $exp_sql = "SELECT * FROM `{$table_name}` WHERE " . implode(' AND ', $where_exp) . " ORDER BY id DESC LIMIT 5000";
        $export_records = !empty($params_exp) ? $wpdb->get_results($wpdb->prepare($exp_sql, $params_exp), ARRAY_A) : $wpdb->get_results($exp_sql, ARRAY_A);

        if (!empty($export_records)) {
            $filename = 'pk01-audit-trail-' . current_time('Y-m-d-His') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            
            $output = fopen('php://output', 'w');
            fputcsv($output, array_keys($export_records[0]));
            foreach ($export_records as $row) {
                fputcsv($output, array_values($row));
            }
            fclose($output);
            exit;
        }
    }
}

// 6. METRIK & STATISTIK DATABASE RIIL
$total_logs     = 0;
$today_logs     = 0;
$sec_warnings   = 0;
$log_storage_mb = 0;
$modules_list   = [];

if ($table_exists) {
    $total_logs = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}`");
    
    $today_logs = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `{$table_name}` WHERE DATE(`{$col_time}`) = %s",
        current_time('Y-m-d')
    ));

    $sec_warnings = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}` WHERE level IN ('warning', 'security', 'error')");

    // Ukuran Penyimpanan Fisik MySQL
    $size_query = $wpdb->get_row($wpdb->prepare(
        "SELECT ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb 
         FROM information_schema.TABLES 
         WHERE table_schema = DATABASE() AND table_name = %s",
        $table_name
    ));
    $log_storage_mb = (float)($size_query->size_mb ?? 0);

    // Ambil Daftar Modul Riil untuk Dropdown Filter
    $modules_list = $wpdb->get_col("SELECT DISTINCT module FROM `{$table_name}` WHERE module IS NOT NULL AND module <> '' ORDER BY module ASC") ?: [];
}

// 7. QUERY DAFTAR LOG UTAMA
$where_clauses = ["1=1"];
$query_params  = [];

if ($filter_days > 0) {
    $where_clauses[] = "`{$col_time}` >= DATE_SUB(NOW(), INTERVAL %d DAY)";
    $query_params[]  = $filter_days;
}
if (!empty($filter_level)) {
    $where_clauses[] = "level = %s";
    $query_params[]  = $filter_level;
}
if (!empty($filter_module)) {
    $where_clauses[] = "module = %s";
    $query_params[]  = $filter_module;
}
if (!empty($filter_search)) {
    $where_clauses[] = "(action LIKE %s OR entity LIKE %s OR description LIKE %s OR user_name LIKE %s)";
    $like_term       = '%' . $wpdb->esc_like($filter_search) . '%';
    $query_params[]  = $like_term;
    $query_params[]  = $like_term;
    $query_params[]  = $like_term;
    $query_params[]  = $like_term;
}

$final_where = implode(' AND ', $where_clauses);
$sql_query   = "SELECT * FROM `{$table_name}` WHERE {$final_where} ORDER BY id DESC LIMIT 200";

$records = [];
if ($table_exists) {
    $records = !empty($query_params) ? $wpdb->get_results($wpdb->prepare($sql_query, $query_params), ARRAY_A) : $wpdb->get_results($sql_query, ARRAY_A);
}
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-log-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-log-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Glassmorphism */
.pk01-log-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-health-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 4 KPI Deck */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-green::before  { background: var(--pk-emerald); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-amber); }
.pk01-kpi-card.c-purple::before { background: #8b5cf6; }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 26px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; }
.pk01-kpi-sub { font-size: 12px; color: var(--pk-slate-600); }

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surface Cards */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Filter Bar */
.pk01-filter-bar {
    background: #f8fafc;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    padding: 14px 18px;
    margin-bottom: 18px;
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}
.pk01-form-ctrl {
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    background: #ffffff;
    color: #0f172a;
    outline: none;
    transition: all 0.2s;
}
.pk01-form-ctrl:focus {
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-table th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-table td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-table tr:hover td { background: #fbfcfe; }

/* Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 15px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-danger { background: var(--pk-rose); color: #ffffff !important; }
.pk01-btn-danger:hover { background: #dc2626; }
.pk01-btn-sm { padding: 4px 8px; font-size: 11.5px; border-radius: 6px; }

.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 11.5px;
}

/* Status Severity Pills */
.pk01-sev-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 8px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}
.sev-info     { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.sev-warning  { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.sev-security { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.sev-error    { background: #450a0a; color: #fecaca; border: 1px solid #7f1d1d; }

.pk01-log-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-log-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-log-alert.is-error   { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }

/* Modal Detail Inspector */
.pk01-modal {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(15, 23, 42, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    padding: 20px;
    backdrop-filter: blur(3px);
}
.pk01-modal-card {
    background: #ffffff;
    border-radius: 16px;
    width: 100%;
    max-width: 580px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    animation: pkModalIn 0.25s ease-out;
}
@keyframes pkModalIn {
    from { opacity: 0; transform: translateY(12px) scale(0.97); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}
</style>

<div class="pk01-log-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-log-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">TAMPER-EVIDENT AUDIT &bull; SECURITY MONITOR</span>
            <h1>🛡️ Log Aktivitas &amp; Integritas Operasional</h1>
            <p>
                Perekaman otomatis jejak transaksi sistem, autentikasi pengguna, perubahan data gudang, dan persetujuan dokumen di PK01 secara terpusat dan <strong>read-only</strong>.
            </p>
        </div>
        <div class="pk01-health-pill">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>AUDIT RECORDING ONLINE</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                Integritas: <b>Auto-Timestamp Hash</b>
            </div>
        </div>
    </header>

    <!-- 2. EXECUTIVE 4 KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Total Log Tersimpan</div>
            <div class="pk01-kpi-val"><?php echo number_format($total_logs, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Seluruh jejak transaksi tercatat</div>
        </div>

        <div class="pk01-kpi-card c-green">
            <div class="pk01-kpi-label">Aktivitas Hari Ini</div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo number_format($today_logs, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Transaksi &bull; Mutasi &bull; Login</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Ukuran Storage MySQL</div>
            <div class="pk01-kpi-val" style="color:#d97706;"><?php echo number_format($log_storage_mb, 2, ',', '.'); ?> <span style="font-size:14px;font-weight:400;color:#64748b;">MB</span></div>
            <div class="pk01-kpi-sub">Kapasitas penyimpanan fisik</div>
        </div>

        <div class="pk01-kpi-card c-purple">
            <div class="pk01-kpi-label">Log Security &amp; Error</div>
            <div class="pk01-kpi-val" style="<?php echo ($sec_warnings > 0) ? 'color:#dc2626;' : 'color:#059669;'; ?>">
                <?php echo number_format($sec_warnings); ?>
            </div>
            <div class="pk01-kpi-sub">Insiden peringatan &amp; kegagalan</div>
        </div>
    </section>

    <?php if (!empty($notice)) echo $notice; ?>

    <!-- 3. TABS NAVIGASI UTAMA -->
    <nav class="pk01-nav-tabs" aria-label="Menu Log Aktivitas">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-all-logs">
            📋 Semua Log Aktivitas (<?php echo count($records); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-security-logs">
            🚨 Log Kritis &amp; Security (<?php echo (int)$sec_warnings; ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-maintenance">
            ⚙️ Pemeliharaan &amp; Retensi Storage
        </button>
    </nav>

    <!-- 4. TAB 1: SEMUA LOG AKTIVITAS (BUILT-IN DATA ENGINE) -->
    <div class="pk01-pane is-active" id="tab-all-logs">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📋 Riwayat Jejak Transaksi &amp; Operasional</h3>
                    <div class="pk01-surface-desc">
                        Menampilkan rekaman aktivitas terkini langsung dari basis data PK01.
                    </div>
                </div>
                <?php if ($table_exists): ?>
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('pk01_export_logs_csv_nonce'); ?>
                        <input type="hidden" name="pk01_action_export_csv" value="1">
                        <button type="submit" class="pk01-btn pk01-btn-subtle" title="Unduh arsip log audit sesuai filter aktif">
                            📥 Ekspor Audit (.CSV)
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- FILTER BAR MULTI-DIMENSI -->
            <form class="pk01-filter-bar" method="get">
                <input type="hidden" name="pk01_view" value="<?php echo esc_attr($_GET['pk01_view'] ?? 'logs'); ?>">

                <input type="search" name="log_search" class="pk01-form-ctrl" value="<?php echo esc_attr($filter_search); ?>" placeholder="🔍 Cari aksi, entitas, staf..." style="width:220px;">

                <select name="log_module" class="pk01-form-ctrl">
                    <option value="">-- Semua Modul --</option>
                    <?php foreach ($modules_list as $mod): ?>
                        <option value="<?php echo esc_attr($mod); ?>" <?php selected($filter_module, $mod); ?>>
                            Modul: <?php echo esc_html(strtoupper($mod)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="log_level" class="pk01-form-ctrl">
                    <option value="">-- Semua Level --</option>
                    <option value="info" <?php selected($filter_level, 'info'); ?>>Info (Normal)</option>
                    <option value="warning" <?php selected($filter_level, 'warning'); ?>>Warning (Peringatan)</option>
                    <option value="security" <?php selected($filter_level, 'security'); ?>>Security (Akses Penting)</option>
                    <option value="error" <?php selected($filter_level, 'error'); ?>>Error (Kegagalan)</option>
                </select>

                <select name="log_days" class="pk01-form-ctrl">
                    <option value="7" <?php selected($filter_days, 7); ?>>7 Hari Terakhir</option>
                    <option value="30" <?php selected($filter_days, 30); ?>>30 Hari Terakhir</option>
                    <option value="90" <?php selected($filter_days, 90); ?>>90 Hari Terakhir</option>
                    <option value="180" <?php selected($filter_days, 180); ?>>180 Hari Terakhir</option>
                    <option value="365" <?php selected($filter_days, 365); ?>>1 Tahun Terakhir</option>
                </select>

                <button class="pk01-btn pk01-btn-dark" type="submit">Filter Log</button>

                <?php if (!empty($filter_search) || !empty($filter_level) || !empty($filter_module) || $filter_days !== 30): ?>
                    <a class="pk01-btn pk01-btn-subtle" href="<?php echo esc_url(remove_query_arg(['log_search', 'log_level', 'log_module', 'log_days'])); ?>#tab-all-logs">
                        ✕ Reset
                    </a>
                <?php endif; ?>
            </form>

            <!-- TABEL DATA AUDIT TRAIL -->
            <div class="pk01-table-card">
                <?php if (empty($records)): ?>
                    <div style="text-align:center; padding:44px 20px; color:#94a3b8; font-size:13px;">
                        📁 Belum ada rekaman aktivitas pada filter dan periode waktu yang dipilih.
                    </div>
                <?php else: ?>
                    <table class="pk01-table">
                        <thead>
                            <tr>
                                <th style="width:140px;">Waktu &amp; Tanggal</th>
                                <th>Staf Pengguna</th>
                                <th>Modul</th>
                                <th>Aksi Operasional</th>
                                <th>Objek / Entitas</th>
                                <th style="text-align:center; width:90px;">Tingkat</th>
                                <th style="text-align:center; width:80px;">Rincian</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $r): 
                                $raw_level = strtolower($r['level'] ?? 'info');
                                $sev_class = 'sev-info';
                                if ($raw_level === 'error') $sev_class = 'sev-error';
                                elseif ($raw_level === 'security') $sev_class = 'sev-security';
                                elseif ($raw_level === 'warning') $sev_class = 'sev-warning';

                                $time_val = $r[$col_time] ?? ($r['timestamp'] ?? '—');
                            ?>
                            <tr>
                                <td>
                                    <span class="pk01-code-badge"><?php echo esc_html($time_val); ?></span>
                                </td>
                                <td>
                                    <strong style="color:#0f172a; font-size:13px;"><?php echo esc_html($r['user_name'] ?? 'Sistem / Autopilot'); ?></strong>
                                    <?php if (!empty($r['user_id'])): ?>
                                        <div style="font-size:11px; color:#64748b;">UID: #<?php echo (int)$r['user_id']; ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="pk01-code-badge" style="background:#eef2ff; color:#3730a3; border-color:#c7d2fe;">
                                        <?php echo esc_html(strtoupper($r['module'] ?? 'SYSTEM')); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($r['action'] ?? '—'); ?></strong>
                                    <?php if (!empty($r['description'])): ?>
                                        <div style="font-size:11.5px; color:#64748b;"><?php echo esc_html(mb_strimwidth((string)$r['description'], 0, 45, '…')); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($r['entity'])): ?>
                                        <code style="font-size:11.5px; background:#fff; padding:2px 6px; border:1px solid #e2e8f0; border-radius:4px;"><?php echo esc_html($r['entity']); ?></code>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-sev-pill <?php echo esc_attr($sev_class); ?>">
                                        ● <?php echo esc_html($raw_level); ?>
                                    </span>
                                </td>
                                <td style="text-align:center;">
                                    <button type="button" class="pk01-btn pk01-btn-subtle pk01-btn-sm pk01-inspect-btn" 
                                            data-time="<?php echo esc_attr($time_val); ?>"
                                            data-user="<?php echo esc_attr($r['user_name'] ?? 'Sistem'); ?>"
                                            data-mod="<?php echo esc_attr($r['module'] ?? '-'); ?>"
                                            data-act="<?php echo esc_attr($r['action'] ?? '-'); ?>"
                                            data-ent="<?php echo esc_attr($r['entity'] ?? '-'); ?>"
                                            data-desc="<?php echo esc_attr($r['description'] ?? 'Tidak ada rincian tambahan.'); ?>"
                                            data-lvl="<?php echo esc_attr(strtoupper($raw_level)); ?>"
                                            title="Buka rincian lengkap">
                                        🔍 Detail
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 5. TAB 2: LOG KRITIS & KEAMANAN (SOC ALERTS) -->
    <div class="pk01-pane" id="tab-security-logs">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3 style="color:#b91c1c;">🚨 Log Keamanan, Peringatan &amp; Error Kritis</h3>
                    <div class="pk01-surface-desc">
                        Fokus pemantauan insiden kegagalan login, modifikasi wewenang staf, pembatalan pesanan dan error eksekusi data.
                    </div>
                </div>
            </div>

            <div class="pk01-table-card">
                <?php
                $sec_records = array_filter($records, function($item) {
                    return in_array(strtolower($item['level'] ?? ''), ['warning', 'security', 'error'], true);
                });
                if (empty($sec_records)):
                ?>
                    <div style="text-align:center; padding:44px 20px; color:#059669; font-size:13px;">
                        <div style="font-size:36px; margin-bottom:8px;">🟢</div>
                        <strong>Kondisi Bersih</strong>: Tidak ada insiden keamanan atau error kritis yang tercatat pada rentang filter ini.
                    </div>
                <?php else: ?>
                    <table class="pk01-table">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Staf Pengguna</th>
                                <th>Modul</th>
                                <th>Aktivitas</th>
                                <th>Objek</th>
                                <th>Keterangan Lengkap</th>
                                <th style="text-align:center;">Tingkat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sec_records as $sr): 
                                $s_level = strtolower($sr['level'] ?? 'warning');
                                $s_class = ($s_level === 'error') ? 'sev-error' : 'sev-security';
                            ?>
                            <tr>
                                <td><span class="pk01-code-badge"><?php echo esc_html($sr[$col_time] ?? '-'); ?></span></td>
                                <td><strong><?php echo esc_html($sr['user_name'] ?? 'Sistem'); ?></strong></td>
                                <td><span class="pk01-code-badge"><?php echo esc_html(strtoupper($sr['module'] ?? 'SEC')); ?></span></td>
                                <td><strong style="color:#b91c1c;"><?php echo esc_html($sr['action']); ?></strong></td>
                                <td><code><?php echo esc_html($sr['entity'] ?: '-'); ?></code></td>
                                <td style="font-size:12px; color:#475569; max-width:320px;"><?php echo esc_html($sr['description'] ?: '-'); ?></td>
                                <td style="text-align:center;">
                                    <span class="pk01-sev-pill <?php echo esc_attr($s_class); ?>">
                                        ● <?php echo esc_html($s_level); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 6. TAB 3: PEMELIHARAAN & RETENSI STORAGE -->
    <div class="pk01-pane" id="tab-maintenance">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>⚙️ Pemeliharaan Kapasitas &amp; Retensi Log</h3>
                    <div class="pk01-surface-desc">
                        Kebijakan pembersihan otomatis riwayat log lama untuk menjaga performa optimal MySQL.
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
                <!-- Card Purge -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:22px;">
                    <h4 style="margin:0 0 6px; font-size:15px; font-weight:800; color:#0f172a;">🗑️ Bersihkan Riwayat Log Usang</h4>
                    <p style="font-size:12.5px; color:#64748b; margin-bottom:16px; line-height:1.5;">
                        Log yang berusia melebihi batas waktu yang dipilih akan dihapus permanen. Master data, pesanan, dan akun pengguna tidak akan tersentuh.
                    </p>

                    <form method="post" action="" onsubmit="return confirm('PERINGATAN: Apakah Anda yakin ingin menghapus log lama? Tindakan ini tidak dapat dibatalkan.');">
                        <?php wp_nonce_field('pk01_clean_logs_action', 'pk01_logs_nonce'); ?>
                        <input type="hidden" name="pk01_action_clean_logs" value="1">

                        <div style="margin-bottom:14px;">
                            <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:6px;">Batas Usia Retensi Log:</label>
                            <select name="purge_days" class="pk01-form-ctrl" style="width:100%;">
                                <option value="30">Lebih dari 30 Hari</option>
                                <option value="60">Lebih dari 60 Hari</option>
                                <option value="90" selected>Lebih dari 90 Hari (Rekomendasi)</option>
                                <option value="180">Lebih dari 180 Hari (6 Bulan)</option>
                                <option value="365">Lebih dari 1 Tahun (365 Hari)</option>
                            </select>
                        </div>

                        <button type="submit" class="pk01-btn pk01-btn-danger">
                            🗑️ Eksekusi Pembersihan Log
                        </button>
                    </form>
                </div>

                <!-- Card Storage Diagnostic -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:22px;">
                    <h4 style="margin:0 0 6px; font-size:15px; font-weight:800; color:#0f172a;">📊 Diagnostik Storage Fisik</h4>
                    <p style="font-size:12.5px; color:#64748b; margin-bottom:16px; line-height:1.5;">
                        Informasi teknis alokasi memori fisik tabel database di server hosting Anda.
                    </p>

                    <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px; margin-bottom:16px;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:12.5px;">
                            <span style="color:#64748b;">Nama Tabel Fisik:</span>
                            <code><?php echo esc_html($table_name); ?></code>
                        </div>
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:12.5px;">
                            <span style="color:#64748b;">Jumlah Total Baris:</span>
                            <strong><?php echo number_format($total_logs); ?> Baris</strong>
                        </div>
                        <div style="display:flex; justify-content:space-between; font-size:12.5px;">
                            <span style="color:#64748b;">Ukuran Index &amp; Data:</span>
                            <strong style="color:#d97706;"><?php echo number_format($log_storage_mb, 2); ?> MB</strong>
                        </div>
                    </div>

                    <div style="font-size:11.5px; color:#166534; background:#ecfdf5; border:1px solid #a7f3d0; border-radius:8px; padding:10px 12px; display:flex; align-items:center; gap:6px;">
                        <span>🛡️</span>
                        <span>Integritas penyimpanan tabel database dalam batas normal.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- MODAL DETAIL INSPECTOR -->
<div id="pk01-log-modal" class="pk01-modal">
    <div class="pk01-modal-card">
        <div style="padding:18px 22px; border-bottom:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center;">
            <h4 style="margin:0; font-size:16px; font-weight:800; color:#0f172a;" id="pk01-modal-title">Rincian Aktivitas Audit</h4>
            <button type="button" id="pk01-close-log-modal" style="background:none; border:none; font-size:18px; cursor:pointer; color:#64748b;">✕</button>
        </div>
        <div style="padding:22px; max-height:420px; overflow-y:auto;" id="pk01-modal-body">
            <!-- Dynamic Injection via JS -->
        </div>
        <div style="padding:14px 22px; background:#f8fafc; border-top:1px solid #e2e8f0; text-align:right;">
            <button type="button" class="pk01-btn pk01-btn-dark pk01-btn-sm" id="pk01-close-log-btn">Tutup</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    // Cek Hash URL saat halaman dibuka
    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. MODAL LOG INSPECTOR
    const modal = document.getElementById('pk01-log-modal');
    const modalBody = document.getElementById('pk01-modal-body');
    const inspectBtns = document.querySelectorAll('.pk01-inspect-btn');
    const closeBtn1 = document.getElementById('pk01-close-log-modal');
    const closeBtn2 = document.getElementById('pk01-close-log-btn');

    inspectBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const time = this.dataset.time;
            const user = this.dataset.user;
            const mod  = this.dataset.mod;
            const act  = this.dataset.act;
            const ent  = this.dataset.ent;
            const desc = this.dataset.desc;
            const lvl  = this.dataset.lvl;

            modalBody.innerHTML = `
                <div style="display:flex; flex-direction:column; gap:12px; font-size:13px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; padding:10px 12px; border-radius:8px; border:1px solid #e2e8f0;">
                        <span>Waktu Pencatatan: <b>${time}</b></span>
                        <span style="font-weight:700; font-size:11px; padding:2px 8px; border-radius:10px; background:#0f172a; color:#fff;">${lvl}</span>
                    </div>
                    <div><span style="color:#64748b; font-size:11.5px;">Pengguna:</span><div style="font-weight:700; color:#0f172a;">${user}</div></div>
                    <div style="display:flex; gap:20px;">
                        <div><span style="color:#64748b; font-size:11.5px;">Modul:</span><div><code>${mod}</code></div></div>
                        <div><span style="color:#64748b; font-size:11.5px;">Entitas:</span><div><code>${ent}</code></div></div>
                    </div>
                    <div><span style="color:#64748b; font-size:11.5px;">Aksi Operasional:</span><div style="font-weight:700;">${act}</div></div>
                    <div>
                        <span style="color:#64748b; font-size:11.5px;">Deskripsi / Rincian Payload:</span>
                        <div style="margin-top:4px; padding:12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; font-family:ui-monospace, monospace; font-size:12px; color:#334155; white-space:pre-wrap; word-break:break-word;">${desc}</div>
                    </div>
                </div>
            `;
            modal.style.display = 'flex';
        });
    });

    function closeModal() { if (modal) modal.style.display = 'none'; }
    if (closeBtn1) closeBtn1.addEventListener('click', closeModal);
    if (closeBtn2) closeBtn2.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) closeModal();
        });
    }
});
</script>