
<?php
/**
 * PK01 Enterprise Central Settings Engine, Multi-Courier Logistics & Data Management Hub
 * Standardized Architecture - Operational Control System, Selective Reset & Indonesian Courier Engine
 */

if (!defined('ABSPATH')) exit;

if (!current_user_can('manage_options')) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">⛔</div>
            <strong style="font-size:16px;">Akses Ditolak</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki hak otorisasi administrator untuk mengelola pengaturan sistem PK01.</p>
          </div>';
    return;
}

// =========================================================================
// SMART DATA HEALTH: PEMERIKSAAN MANUAL OLEH ADMIN
// =========================================================================
$pk01_health_action_notice = '';
if (isset($_POST['pk01_run_health_check']) && check_admin_referer('pk01_health_check_nonce')) {
    try {
        $result = class_exists('PK01_Data_Health') ? PK01_Data_Health::check() : null;
        if ($result) {
            PK01_Data_Health::save_result($result);
            $pk01_health_action_notice = '<div class="pk01-alert pk01-alert-success">🩺 Pemeriksaan selesai. Status: <strong>'.esc_html($result['status']).'</strong>, skor '.esc_html((string)$result['score']).'%. Tidak ada data bisnis yang dibuat atau diubah.</div>';
        } else {
            $pk01_health_action_notice = '<div class="pk01-alert pk01-alert-error">Mesin pemeriksaan kesehatan data belum tersedia.</div>';
        }
    } catch (Throwable $e) {
        $pk01_health_action_notice = '<div class="pk01-alert pk01-alert-error">Pemeriksaan gagal: '.esc_html($e->getMessage()).'</div>';
    }
}
if (isset($_POST['pk01_repair_sync_now']) && check_admin_referer('pk01_repair_sync_nonce')) {
    try {
        if (class_exists('PK01_Smart_Plugin') && method_exists('PK01_Smart_Plugin','runtime_guard')) PK01_Smart_Plugin::runtime_guard();
        if (class_exists('PK01_Data_Health')) PK01_Data_Health::save_result(PK01_Data_Health::check());
        $pk01_health_action_notice = '<div class="pk01-alert pk01-alert-success">⚙️ Struktur yang benar-benar hilang telah diperiksa/dipulihkan dan pemeriksaan ulang dijalankan. Sinkronisasi hanya memakai data transaksi nyata; tidak membuat data contoh.</div>';
    } catch (Throwable $e) {
        $pk01_health_action_notice = '<div class="pk01-alert pk01-alert-error">Perbaikan/sinkronisasi gagal: '.esc_html($e->getMessage()).'</div>';
    }
}
$pk01_operational_snapshot = class_exists('PK01_Data_Health') && method_exists('PK01_Data_Health','operational_snapshot') ? PK01_Data_Health::operational_snapshot() : array();

// =========================================================================
// MARKETPLACE CATALOG SOURCE: OFFICIAL TEMPLATE REGISTRY
// =========================================================================
$pk01_marketplace_catalog_notice = '';
if (isset($_POST['pk01_marketplace_template_upload']) && check_admin_referer('pk01_marketplace_template_nonce')) {
    try {
        $mp = sanitize_key(wp_unslash($_POST['marketplace_template_key'] ?? ''));
        $verify = !empty($_POST['marketplace_template_verify']);
        if (empty($_FILES['marketplace_template_file'])) throw new Exception('File template belum dipilih.');
        $tpl = PK01_Marketplace_Catalog::save_template($mp, $_FILES['marketplace_template_file'], $verify);
        $pk01_marketplace_catalog_notice = '<div class="pk01-alert pk01-alert-success">Template <strong>'.esc_html($tpl['label']).'</strong> tersimpan. '.(!empty($tpl['verified'])?'Status: <b>TERVERIFIKASI</b>.':'Status: <b>BELUM TERVERIFIKASI</b>; kolom yang tidak dikenali harus diperiksa sebelum export.').'</div>';
    } catch (Throwable $e) {
        $pk01_marketplace_catalog_notice = '<div class="pk01-alert pk01-alert-error">Gagal menyimpan template marketplace: '.esc_html($e->getMessage()).'</div>';
    }
}

// Simpan mapping manual/AI-assisted dari header template ke field kanonik PK01.
if (isset($_POST['pk01_marketplace_mapping_save']) && check_admin_referer('pk01_marketplace_mapping_nonce')) {
    try {
        $mp=sanitize_key(wp_unslash($_POST['marketplace_mapping_key']??''));
        $mapping=is_array($_POST['marketplace_mapping']??null)?wp_unslash($_POST['marketplace_mapping']):[];
        $tpl=PK01_Marketplace_Catalog::save_template_mapping($mp,$mapping,!empty($_POST['marketplace_mapping_verify']));
        $pk01_marketplace_catalog_notice='<div class="pk01-alert pk01-alert-success">Mapping <strong>'.esc_html($tpl['label']).'</strong> tersimpan. Status: '.(!empty($tpl['verified'])?'<b>TERVERIFIKASI</b>':'<b>BELUM TERVERIFIKASI</b>').'.</div>';
    } catch(Throwable $e){$pk01_marketplace_catalog_notice='<div class="pk01-alert pk01-alert-error">Gagal menyimpan mapping: '.esc_html($e->getMessage()).'</div>';}
}

// =========================================================================
// ACTION 1: EKSPOR DATABASE SQL (DIJALANKAN SEBELUM OUTPUT HTML)
// =========================================================================
if (isset($_POST['pk01_action_export_sql']) && check_admin_referer('pk01_export_db_nonce')) {
    global $wpdb;
    
    $export_scope = sanitize_key($_POST['export_scope'] ?? 'pk01_only');
    if ($export_scope === 'pk01_only') {
        $tables = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}pk01_%'");
    } else {
        $tables = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}%'");
    }
    
    $sql_dump  = "-- --------------------------------------------------------\n";
    $sql_dump .= "-- PK01 Enterprise Database Backup Archive\n";
    $sql_dump .= "-- Generated Date  : " . current_time('mysql') . " WIB\n";
    $sql_dump .= "-- Scope           : " . strtoupper($export_scope) . " (" . count($tables) . " Tables)\n";
    $sql_dump .= "-- WordPress Prefix: " . $wpdb->prefix . "\n";
    $sql_dump .= "-- --------------------------------------------------------\n\n";
    $sql_dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

    foreach ($tables as $tbl) {
        $create_row = $wpdb->get_row("SHOW CREATE TABLE `{$tbl}`", ARRAY_N);
        if ($create_row && isset($create_row[1])) {
            $sql_dump .= "DROP TABLE IF EXISTS `{$tbl}`;\n";
            $sql_dump .= $create_row[1] . ";\n\n";

            $rows = $wpdb->get_results("SELECT * FROM `{$tbl}`", ARRAY_A);
            if (!empty($rows)) {
                foreach ($rows as $r) {
                    $cols = array_map(function($c) { return "`" . str_replace("`", "``", $c) . "`"; }, array_keys($r));
                    $vals = array_map(function($v) {
                        return is_null($v) ? "NULL" : "'" . esc_sql($v) . "'";
                    }, array_values($r));

                    $sql_dump .= "INSERT INTO `{$tbl}` (" . implode(", ", $cols) . ") VALUES (" . implode(", ", $vals) . ");\n";
                }
                $sql_dump .= "\n";
            }
        }
    }
    $sql_dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

    $filename = 'pk01-backup-' . $export_scope . '-' . current_time('Y-m-d-His') . '.sql';
    nocache_headers();
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($sql_dump));
    echo $sql_dump;
    exit;
}

// Aktifkan WordPress Native Media Library Script & Style
if (function_exists('wp_enqueue_media')) {
    wp_enqueue_media();
}

/*
|--------------------------------------------------------------------------
| LOGISTICS ENGINE: UNIVERSAL INDONESIAN COURIER TRACKER & DIRECT WEB ENGINE
|--------------------------------------------------------------------------
*/
if (!class_exists('PK01_Shipping_Engine')) {
    /** Compatibility facade. All real tracking logic lives in PK01_Shipping_Smart. */
    class PK01_Shipping_Engine {
        public static function get_settings() {
            if (class_exists('PK01_Shipping_Smart')) return PK01_Shipping_Smart::settings();
            return (array)get_option('pk01_shipping_settings', []);
        }
        public static function track($courier,$waybill) {
            if (class_exists('PK01_Shipping_Smart')) {
                $r=PK01_Shipping_Smart::sync_tracking_no($waybill);
                if(is_array($r)) return ['success'=>true,'courier'=>$courier,'waybill'=>$waybill,'status'=>$r['status']??'','status_label'=>PK01_Shipping_Smart::status_label($r['status']??''),'history'=>$r['events']??[],'direct_link'=>PK01_Shipping_Smart::get_direct_tracking_url($courier,$waybill)];
            }
            return ['success'=>false,'message'=>'Mesin tracking PK01 belum aktif.'];
        }
        public static function get_direct_tracking_url($courier,$waybill) {
            return class_exists('PK01_Shipping_Smart') ? PK01_Shipping_Smart::get_direct_tracking_url($courier,$waybill) : '';
        }
    }
}

/*
|--------------------------------------------------------------------------
| FORMATTER PENOMORAN DINAMIS DOKUMEN
|--------------------------------------------------------------------------
*/
if (!function_exists('pk01_format_doc_number')) {
    function pk01_format_doc_number($prefix, $digits, $seq, $pattern = '') {
        $seq_padded = str_pad((string)$seq, max(1, (int)$digits), '0', STR_PAD_LEFT);
        if (empty($pattern)) $pattern = '{PREFIX}-{SEQ}';

        $roman_months = array(1=>'I',2=>'II',3=>'III',4=>'IV',5=>'V',6=>'VI',7=>'VII',8=>'VIII',9=>'IX',10=>'X',11=>'XI',12=>'XII');
        $m_idx = (int)current_time('n');
        $roman = $roman_months[$m_idx] ?? 'I';

        $replacements = array(
            '{PREFIX}' => strtoupper($prefix),
            '{YYYY}'   => current_time('Y'),
            '{YY}'     => current_time('y'),
            '{MM}'     => current_time('m'),
            '{DD}'     => current_time('d'),
            '{ROMAN}'  => $roman,
            '{SEQ}'    => $seq_padded,
        );
        return str_replace(array_keys($replacements), array_values($replacements), $pattern);
    }
}

/*
|--------------------------------------------------------------------------
| CONFIGURATION LOADER & DEFAULTS
|--------------------------------------------------------------------------
*/
$pk01_get_settings = function () {
    $all = array();
    if (class_exists('PK01_Settings')) {
        if (method_exists('PK01_Settings', 'get_group')) {
            $groups = array('general', 'documents', 'notifications', 'integration', 'backup', 'access');
            foreach ($groups as $group) {
                $g = PK01_Settings::get_group($group);
                if (is_array($g)) $all = array_merge($all, $g);
            }
            if (!empty($all)) return $all;
        }
        if (method_exists('PK01_Settings', 'get')) {
            $x = PK01_Settings::get();
            if (is_array($x) && !empty($x)) return $x;
        }
    }
    return (array) get_option('pk01_settings', array());
};

$settings = $pk01_get_settings();
$shipping_cfg = PK01_Shipping_Engine::get_settings();

$defaults = array(
    'company_name'          => get_bloginfo('name'),
    'company_legal_name'    => '',
    'company_tagline'       => '',
    'company_address'       => '',
    'company_city'          => 'Jakarta Barat',
    'company_phone'         => '',
    'company_email'         => get_option('admin_email'),
    'company_nib'           => '',
    'company_npwp'          => '',
    'company_logo'          => '',
    'company_stamp'         => '',
    'signee_name'           => '',
    'signee_position'       => '',
    'invoice_terms'         => '',

    'bank_name'             => '',
    'bank_account_number'   => '',
    'bank_account_name'     => '',
    'tax_default_percent'   => 11,
    'invoice_due_days'      => 14,
    'stock_alert_min_default' => 5,
    'currency_symbol'       => 'Rp',

    'wa_enabled'            => '0',
    'wa_provider'           => 'none',
    'wa_sender'             => '',
    'wa_api_key'            => '',

    'ai_enabled'            => '1',
    'ai_provider'           => 'openai',
    'ai_api_key'            => '',
    'ai_model'              => 'gpt-4o-mini',
    'ai_business_type'      => 'manufacture',
    'ai_custom_context'     => 'Fokus pada mitigasi arus kas, pengendalian HPP pesanan, antrean job produksi SPK, dan akurasi status resi pengiriman.',

    'invoice_prefix'        => 'INV',   'invoice_digits'        => 5, 'invoice_sequence'        => 1, 'invoice_pattern'        => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'po_prefix'             => 'PO',    'po_digits'             => 5, 'po_sequence'             => 1, 'po_pattern'             => '{PREFIX}/{YYYY}/{SEQ}',
    'delivery_prefix'       => 'SJ',    'delivery_digits'       => 5, 'delivery_sequence'       => 1, 'delivery_pattern'       => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'payment_prefix'        => 'KK',    'payment_digits'        => 5, 'payment_sequence'        => 1, 'payment_pattern'        => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'seller_prefix'         => 'SLR',   'seller_digits'         => 4, 'seller_sequence'         => 1, 'seller_pattern'         => '{PREFIX}-{YY}-{SEQ}',
    'sales_prefix'          => 'SO',    'sales_digits'          => 5, 'sales_sequence'          => 1, 'sales_pattern'          => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'job_prefix'            => 'SPK',   'job_digits'            => 5, 'job_sequence'            => 1, 'job_pattern'            => '{PREFIX}/{YYYY}/{SEQ}',
    'production_prefix'     => 'PROD',  'production_digits'     => 5, 'production_sequence'     => 1, 'production_pattern'     => '{PREFIX}/{YYYY}/{SEQ}',
    'payroll_prefix'        => 'PAY',   'payroll_digits'        => 5, 'payroll_sequence'        => 1, 'payroll_pattern'        => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'payout_prefix'         => 'WD',    'payout_digits'         => 4, 'payout_sequence'         => 1, 'payout_pattern'         => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'employee_prefix'       => 'KRY',   'employee_digits'       => 3, 'employee_sequence'       => 1, 'employee_pattern'       => '{PREFIX}-{SEQ}',
    'material_prefix'       => 'MAT',   'material_digits'       => 4, 'material_sequence'       => 1, 'material_pattern'       => '{PREFIX}-{SEQ}',
    'return_prefix'         => 'RET',   'return_digits'         => 4, 'return_sequence'         => 1, 'return_pattern'         => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'shipment_prefix'       => 'SHP',   'shipment_digits'       => 5, 'shipment_sequence'       => 1, 'shipment_pattern'       => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'stock_adjustment_prefix'=> 'ADJ',  'stock_adjustment_digits'=>4, 'stock_adjustment_sequence'=>1,'stock_adjustment_pattern'=> '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'project_prefix'        => 'PRJ',   'project_digits'        => 4, 'project_sequence'        => 1, 'project_pattern'        => '{PREFIX}/{YYYY}/{SEQ}',
    'goods_receipt_prefix' => 'GR', 'goods_receipt_digits' => 5, 'goods_receipt_sequence' => 1, 'goods_receipt_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'warehouse_supplier_prefix' => 'WGR', 'warehouse_supplier_digits' => 5, 'warehouse_supplier_sequence' => 1, 'warehouse_supplier_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'warehouse_return_prefix' => 'WRT', 'warehouse_return_digits' => 5, 'warehouse_return_sequence' => 1, 'warehouse_return_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'warehouse_return_courier_prefix' => 'WRTC', 'warehouse_return_courier_digits' => 5, 'warehouse_return_courier_sequence' => 1, 'warehouse_return_courier_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'warehouse_handover_prefix' => 'WHD', 'warehouse_handover_digits' => 5, 'warehouse_handover_sequence' => 1, 'warehouse_handover_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'warehouse_production_out_prefix' => 'WPO', 'warehouse_production_out_digits' => 5, 'warehouse_production_out_sequence' => 1, 'warehouse_production_out_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'warehouse_production_in_prefix' => 'WPI', 'warehouse_production_in_digits' => 5, 'warehouse_production_in_sequence' => 1, 'warehouse_production_in_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'journal_prefix' => 'JNL', 'journal_digits' => 6, 'journal_sequence' => 1, 'journal_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'expense_prefix' => 'BKK', 'expense_digits' => 5, 'expense_sequence' => 1, 'expense_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'capital_prefix' => 'CAP', 'capital_digits' => 5, 'capital_sequence' => 1, 'capital_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'closing_prefix' => 'CLOSE', 'closing_digits' => 5, 'closing_sequence' => 1, 'closing_pattern' => '{PREFIX}/{YYYY}/{SEQ}',
    'owner_receipt_prefix' => 'OWN', 'owner_receipt_digits' => 5, 'owner_receipt_sequence' => 1, 'owner_receipt_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'seller_order_prefix' => 'SEL', 'seller_order_digits' => 5, 'seller_order_sequence' => 1, 'seller_order_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'seller_invoice_prefix' => 'SINV', 'seller_invoice_digits' => 5, 'seller_invoice_sequence' => 1, 'seller_invoice_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'security_visitor_prefix' => 'VIS', 'security_visitor_digits' => 5, 'security_visitor_sequence' => 1, 'security_visitor_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'security_gate_prefix' => 'SEC-G', 'security_gate_digits' => 5, 'security_gate_sequence' => 1, 'security_gate_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'security_incident_prefix' => 'INC', 'security_incident_digits' => 5, 'security_incident_sequence' => 1, 'security_incident_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'seller_bonus_prefix' => 'BON', 'seller_bonus_digits' => 5, 'seller_bonus_sequence' => 1, 'seller_bonus_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
    'cs_ticket_prefix' => 'CS', 'cs_ticket_digits' => 5, 'cs_ticket_sequence' => 1, 'cs_ticket_pattern' => '{PREFIX}/{YYYY}{MM}/{SEQ}',
);

$settings = wp_parse_args($settings, $defaults);

/*
|--------------------------------------------------------------------------
| ACTION HANDLERS
|--------------------------------------------------------------------------
*/
$notice = '';

// 1. Simpan Pengaturan
if (isset($_POST['pk01_central_settings_save']) && check_admin_referer('pk01_central_settings_save')) {
    try {
        $text_fields = array(
            'company_name', 'company_legal_name', 'company_tagline', 'company_address',
            'company_city', 'company_phone', 'company_email', 'company_nib', 'company_npwp',
            'bank_name', 'bank_account_number', 'bank_account_name', 'currency_symbol',
            'signee_name', 'signee_position', 'wa_provider', 'wa_sender',
            'ai_provider', 'ai_model', 'ai_business_type'
        );

        foreach ($text_fields as $f) {
            if (isset($_POST[$f])) $settings[$f] = sanitize_text_field(wp_unslash($_POST[$f]));
        }

        if (isset($_POST['invoice_terms'])) $settings['invoice_terms'] = sanitize_textarea_field(wp_unslash($_POST['invoice_terms']));
        if (isset($_POST['ai_custom_context'])) $settings['ai_custom_context'] = sanitize_textarea_field(wp_unslash($_POST['ai_custom_context']));

        $settings['tax_default_percent']     = max(0, min(100, (float)($_POST['tax_default_percent'] ?? 11)));
        $settings['invoice_due_days']        = max(1, min(180, (int)($_POST['invoice_due_days'] ?? 14)));
        $settings['stock_alert_min_default'] = max(0, (int)($_POST['stock_alert_min_default'] ?? 5));

        if (isset($_POST['company_logo']))  $settings['company_logo']  = esc_url_raw(wp_unslash($_POST['company_logo']));
        if (isset($_POST['company_stamp'])) $settings['company_stamp'] = esc_url_raw(wp_unslash($_POST['company_stamp']));

        $settings['wa_enabled'] = !empty($_POST['wa_enabled']) ? '1' : '0';
        $settings['ai_enabled'] = !empty($_POST['ai_enabled']) ? '1' : '0';

        if (!empty($_POST['wa_api_key'])) $settings['wa_api_key'] = sanitize_text_field(wp_unslash($_POST['wa_api_key']));
        if (!empty($_POST['ai_api_key'])) $settings['ai_api_key'] = sanitize_text_field(wp_unslash($_POST['ai_api_key']));

        // Penomoran
        $doc_types = class_exists('PK01_Settings') && method_exists('PK01_Settings','document_registry') ? array_keys(PK01_Settings::document_registry()) : array('invoice','po','delivery','payment','seller','seller_order','seller_invoice','sales','job','production','payroll','payout','employee','material','return','shipment','stock_adjustment','project','goods_receipt','warehouse_supplier','warehouse_return','warehouse_return_courier','warehouse_handover','warehouse_production_out','warehouse_production_in','journal','expense','capital','closing','owner_receipt','security_visitor','security_gate','security_incident');
        foreach ($doc_types as $type) {
            $pk = $type . '_prefix'; $dk = $type . '_digits'; $sk = $type . '_sequence'; $ptk = $type . '_pattern';
            if (isset($_POST[$pk]))  $settings[$pk] = preg_replace('/[^A-Z0-9\-_]/', '', strtoupper(sanitize_text_field(wp_unslash($_POST[$pk]))));
            if (isset($_POST[$dk]))  $settings[$dk] = max(1, min(10, (int)$_POST[$dk]));
            if (isset($_POST[$sk]))  $settings[$sk] = max(1, (int)$_POST[$sk]);
            if (isset($_POST[$ptk])) $settings[$ptk] = sanitize_text_field(wp_unslash($_POST[$ptk]));
        }

        update_option('pk01_seller_prefix', $settings['seller_prefix'], false);
        update_option('pk01_seller_digits', (int)$settings['seller_digits'], false);
        update_option('pk01_seller_use_year', (strpos($settings['seller_pattern'], '{YY}') !== false || strpos($settings['seller_pattern'], '{YYYY}') !== false ? 1 : 0), false);

        // Simpan integrasi pengiriman: satu konfigurasi canonical yang dipakai Engine + webhook + cron.
        $raw_couriers = is_array($_POST['shipping_active_couriers'] ?? null) ? wp_unslash($_POST['shipping_active_couriers']) : [];
        $routes = is_array($_POST['shipping_courier_routes'] ?? null) ? wp_unslash($_POST['shipping_courier_routes']) : [];
        $api_keys = is_array($_POST['shipping_api_keys'] ?? null) ? wp_unslash($_POST['shipping_api_keys']) : [];
        $clean_keys=[]; foreach($api_keys as $k=>$v){$k=sanitize_key($k);$v=trim((string)$v);if($k!==''&&$v!=='')$clean_keys[$k]=$v;}
        $old_ship = class_exists('PK01_Shipping_Smart') ? PK01_Shipping_Smart::settings() : (array)$shipping_cfg;
        foreach((array)($old_ship['api_keys']??[]) as $k=>$v){ if(empty($clean_keys[$k]) && $v!=='') $clean_keys[sanitize_key($k)]=$v; }
        $new_shipping_cfg = array(
            'provider'              => sanitize_key(wp_unslash($_POST['shipping_provider'] ?? ($old_ship['provider'] ?? 'none'))),
            'api_key'               => (string)($clean_keys[sanitize_key($_POST['shipping_provider'] ?? ($old_ship['provider'] ?? 'none'))] ?? ''),
            'api_keys'              => $clean_keys,
            'provider_enabled'      => is_array($_POST['shipping_provider_enabled'] ?? null) ? array_fill_keys(array_map('sanitize_key',wp_unslash($_POST['shipping_provider_enabled'])),true) : [],
            'enabled'               => !empty($_POST['shipping_enabled']),
            'webhook_enabled'       => !empty($_POST['shipping_webhook_enabled']),
            'webhook_secret'        => sanitize_text_field(wp_unslash($_POST['shipping_webhook_secret'] ?? ($old_ship['webhook_secret'] ?? ''))),
            'base_url'              => esc_url_raw(trim((string)wp_unslash($_POST['shipping_base_url'] ?? ($old_ship['base_url'] ?? '')))),
            'biteship_base'         => esc_url_raw(trim((string)wp_unslash($_POST['shipping_biteship_base'] ?? 'https://api.biteship.com'))),
            'raja_base'             => esc_url_raw(trim((string)wp_unslash($_POST['shipping_raja_base'] ?? 'https://rajaongkir.komerce.id/api/v1'))),
            'origin_city'           => sanitize_text_field(wp_unslash($_POST['shipping_origin_city'] ?? '')),
            'cache_hours'           => max(1,min(48,(int)($_POST['shipping_cache_hours'] ?? 3))),
            'auto_sync_minutes'     => max(15,(int)($_POST['shipping_auto_sync_minutes'] ?? 60)),
            'polling'               => sanitize_key(wp_unslash($_POST['shipping_polling'] ?? 'hourly')),
            'default_service'       => sanitize_key(wp_unslash($_POST['shipping_default_service'] ?? 'REG')),
            'courier_routes'        => array_map('sanitize_key',$routes),
            'active_couriers'       => array_map('sanitize_key',$raw_couriers),
            'shipping_active_couriers'=>array_map('sanitize_key',$raw_couriers),
            'shipping_provider'     => sanitize_key(wp_unslash($_POST['shipping_provider'] ?? ($old_ship['provider'] ?? 'none'))),
            'shipping_api_key'      => (string)($clean_keys[sanitize_key($_POST['shipping_provider'] ?? ($old_ship['provider'] ?? 'none'))] ?? ''),
            'shipping_origin_city'  => sanitize_text_field(wp_unslash($_POST['shipping_origin_city'] ?? '')),
            'shipping_cache_hours'  => max(1,min(48,(int)($_POST['shipping_cache_hours'] ?? 3))),
        );
        // Direct URL templates are still useful as human verification links, never as fake API data.
        $new_shipping_cfg['shipping_direct_urls'] = (array)($old_ship['shipping_direct_urls'] ?? []);
        $new_shipping_cfg['shipping_official_portals'] = (array)($old_ship['shipping_official_portals'] ?? []);
        if (isset($_POST['shipping_direct_urls']) && is_array($_POST['shipping_direct_urls'])) foreach($_POST['shipping_direct_urls'] as $ck=>$u) $new_shipping_cfg['shipping_direct_urls'][sanitize_key($ck)] = esc_url_raw(trim($u));
        update_option('pk01_shipping_settings',$new_shipping_cfg,false);
        if(class_exists('PK01_Settings')) PK01_Settings::update_group('integration',['shipping'=>$new_shipping_cfg]);
        $shipping_cfg=$new_shipping_cfg;

        if (class_exists('PK01_Settings') && method_exists('PK01_Settings', 'update_group')) PK01_Settings::update_group('general', $settings);
        else update_option('pk01_settings', $settings, false);

        $notice = '<div class="pk01-alert is-success">✅ Seluruh konfigurasi profil, penomoran dokumen, AI, operasional, dan tautan kurir berhasil disimpan secara permanen.</div>';
    } catch (Throwable $e) {
        $notice = '<div class="pk01-alert is-error">❌ Gagal menyimpan pengaturan: ' . esc_html($e->getMessage()) . '</div>';
    }
}

// 2. Edit Pengguna & Role
if (isset($_POST['pk01_update_user_action']) && check_admin_referer('pk01_update_user_nonce')) {
    $uid = absint($_POST['edit_user_id'] ?? 0);
    $target = $uid ? get_user_by('id', $uid) : false;
    $allowed_roles = [
        'pk01_admin','pk01_keuangan','pk01_produksi','pk01_gudang','pk01_logistik',
        'pk01_kasir','pk01_hr','pk01_packing','pk01_employee','pk01_seller'
    ];
    if (!$target) {
        $notice = '<div class="pk01-alert is-error">❌ Pengguna tidak ditemukan.</div>';
    } elseif ($uid === get_current_user_id() && !empty($_POST['edit_user_role']) && $_POST['edit_user_role'] !== ($target->roles[0] ?? '')) {
        $notice = '<div class="pk01-alert is-error">❌ Demi keamanan, role akun Anda sendiri yang sedang aktif tidak dapat diubah dari menu ini.</div>';
    } else {
        $new_email = sanitize_email(wp_unslash($_POST['edit_user_email'] ?? $target->user_email));
        $new_name  = sanitize_text_field(wp_unslash($_POST['edit_user_display_name'] ?? $target->display_name));
        $new_role  = sanitize_key(wp_unslash($_POST['edit_user_role'] ?? ($target->roles[0] ?? 'pk01_employee')));
        $new_pass  = (string)($_POST['edit_user_pass'] ?? '');
        $errors = [];
        if (!$new_email || !is_email($new_email)) $errors[] = 'Email tidak valid.';
        $email_owner = email_exists($new_email);
        if ($email_owner && (int)$email_owner !== $uid) $errors[] = 'Email sudah digunakan akun lain.';
        if (!in_array($new_role, $allowed_roles, true) && !in_array('administrator', (array)$target->roles, true)) $errors[] = 'Role tidak diizinkan.';
        if ($new_pass !== '' && strlen($new_pass) < 8) $errors[] = 'Password baru minimal 8 karakter.';
        
        if (!$errors) {
            $data = ['ID' => $uid, 'user_email' => $new_email, 'display_name' => $new_name, 'first_name' => $new_name];
            if ($new_pass !== '') $data['user_pass'] = $new_pass;
            $updated = wp_update_user($data);
            if (is_wp_error($updated)) $errors[] = $updated->get_error_message();
            else {
                if (!in_array('administrator', (array)$target->roles, true)) (new WP_User($uid))->set_role($new_role);
                $notice = '<div class="pk01-alert is-success">✅ Data pengguna <strong>' . esc_html($target->user_login) . '</strong> berhasil diperbarui.</div>';
            }
        }
        if ($errors) $notice = '<div class="pk01-alert is-error">❌ ' . esc_html(implode(' ', $errors)) . '</div>';
    }
}

// 3. Registrasi Staf & Role Baru
if (isset($_POST['pk01_create_user_action']) && check_admin_referer('pk01_create_user_nonce')) {
    $u_login = sanitize_user(wp_unslash($_POST['new_user_login'] ?? ''));
    $u_email = sanitize_email(wp_unslash($_POST['new_user_email'] ?? ''));
    $u_name  = sanitize_text_field(wp_unslash($_POST['new_user_display_name'] ?? ''));
    $u_pass  = (string)($_POST['new_user_pass'] ?? '');
    $u_role  = sanitize_key(wp_unslash($_POST['new_user_role'] ?? 'pk01_employee'));

    if (empty($u_login) || empty($u_email) || empty($u_pass)) $notice = '<div class="pk01-alert is-error">❌ Username, email, dan password wajib diisi.</div>';
    elseif (username_exists($u_login)) $notice = '<div class="pk01-alert is-error">❌ Username sudah terdaftar.</div>';
    elseif (email_exists($u_email)) $notice = '<div class="pk01-alert is-error">❌ Email sudah terdaftar.</div>';
    elseif (strlen($u_pass) < 8) $notice = '<div class="pk01-alert is-error">❌ Password minimal 8 karakter.</div>';
    else {
        $uid = wp_create_user($u_login, $u_pass, $u_email);
        if (is_wp_error($uid)) {
            $notice = '<div class="pk01-alert is-error">❌ ' . esc_html($uid->get_error_message()) . '</div>';
        } else {
            $user_obj = new WP_User($uid);
            $user_obj->set_role($u_role);
            if (!empty($u_name)) wp_update_user(array('ID' => $uid, 'display_name' => $u_name, 'first_name' => $u_name));
            $notice = '<div class="pk01-alert is-success">✅ Pengguna baru <strong>' . esc_html($u_login) . '</strong> (' . esc_html($u_role) . ') berhasil didaftarkan!</div>';
        }
    }
}

// 4. Impor Database SQL
if (isset($_POST['pk01_action_import_sql']) && check_admin_referer('pk01_import_db_nonce')) {
    global $wpdb;
    if (!empty($_FILES['pk01_sql_file']['tmp_name']) && is_uploaded_file($_FILES['pk01_sql_file']['tmp_name'])) {
        $file_name = sanitize_file_name($_FILES['pk01_sql_file']['name']);
        if (strtolower(pathinfo($file_name, PATHINFO_EXTENSION)) !== 'sql') {
            $notice = '<div class="pk01-alert is-error">❌ File harus berekstensi .sql</div>';
        } else {
            $sql_content = file_get_contents($_FILES['pk01_sql_file']['tmp_name']);
            if (!empty($sql_content)) {
                $lines = explode("\n", $sql_content);
                $cleaned = '';
                foreach ($lines as $line) {
                    $tr = trim($line);
                    if ($tr === '' || strpos($tr, '--') === 0 || strpos($tr, '/*') === 0) continue;
                    $cleaned .= $line . "\n";
                }
                $queries = explode(";\n", $cleaned);
                $executed = 0;
                $wpdb->query("SET FOREIGN_KEY_CHECKS=0");
                foreach ($queries as $q) {
                    $q = trim($q);
                    if (!empty($q)) { $wpdb->query($q); $executed++; }
                }
                $wpdb->query("SET FOREIGN_KEY_CHECKS=1");
                $notice = '<div class="pk01-alert is-success">✅ Pemulihan basis data selesai! Total ' . number_format($executed) . ' kueri SQL berhasil dipulihkan.</div>';
            }
        }
    }
}

// 5. Reset Data Selektif & Granular
$module_table_map = array(
    'orders'     => array('sales_orders', 'orders', 'sales_order_items', 'order_meta'),
    'production' => array('jobs', 'production_jobs', 'job_assignments', 'job_timelines', 'job_costs'),
    'finance'    => array('cash_ledger', 'operational_costs', 'payroll', 'cash_mutations'),
    'shipments'  => array('shipments', 'shipping_manifests', 'shipping_logs'),
    'returns'    => array('returns', 'refunds', 'return_items'),
    'mutations'  => array('stock_mutations', 'inventory_logs', 'material_usage'),
    'sellers'    => array('seller_payouts', 'seller_commissions', 'affiliate_logs')
);

// Hitung data aktual riil per modul sebelum reset
global $wpdb;
$module_counts = array();
foreach ($module_table_map as $mod_key => $tables_list) {
    $c = 0;
    foreach ($tables_list as $tbl) {
        $full_tbl = $wpdb->prefix . 'pk01_' . $tbl;
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $full_tbl)) === $full_tbl) {
            $c += (int)$wpdb->get_var("SELECT COUNT(*) FROM `{$full_tbl}`");
        }
    }
    $module_counts[$mod_key] = $c;
}

if (isset($_POST['pk01_action_selective_reset']) && check_admin_referer('pk01_selective_reset_nonce')) {
    $confirm_text = strtoupper(trim(sanitize_text_field($_POST['confirm_reset_keyword'] ?? '')));
    $selected_modules = (array)($_POST['reset_modules'] ?? array());

    if ($confirm_text !== 'RESET') {
        $notice = '<div class="pk01-alert is-error">❌ Kata konfirmasi salah! Ketik kata <strong>RESET</strong> (huruf besar).</div>';
    } elseif (empty($selected_modules)) {
        $notice = '<div class="pk01-alert is-error">❌ Tidak ada modul yang dipilih untuk di-reset.</div>';
    } else {
        $wpdb->query("SET FOREIGN_KEY_CHECKS=0");
        foreach ($selected_modules as $mod_key) {
            if (isset($module_table_map[$mod_key])) {
                foreach ($module_table_map[$mod_key] as $sub_tbl) {
                    $target_table = $wpdb->prefix . 'pk01_' . $sub_tbl;
                    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $target_table)) === $target_table) {
                        $wpdb->query("TRUNCATE TABLE `{$target_table}`");
                    }
                }
            }
        }
        $wpdb->query("SET FOREIGN_KEY_CHECKS=1");

        $notice = '<div class="pk01-alert is-success">✅ Modul (' . implode(', ', array_map('esc_html', $selected_modules)) . ') telah di-reset bersih ke kondisi awal.</div>';
    }
}

// Data Master Kurir Terintegrasi
$indonesian_couriers = array(
    'jne'      => array('name' => 'JNE Express', 'code' => 'JNE', 'portal' => 'https://www.jne.co.id/tracking-package', 'default_direct' => 'https://berdu.id/cek-resi/jne?resi={AWB}'),
    'jnt'      => array('name' => 'J&T Express', 'code' => 'J&T', 'portal' => 'https://www.jet.co.id/track', 'default_direct' => 'https://berdu.id/cek-resi/jnt?resi={AWB}'),
    'sicepat'  => array('name' => 'SiCepat Ekspres', 'code' => 'SICEPAT', 'portal' => 'https://www.sicepat.com/checkAwb', 'default_direct' => 'https://www.sicepat.com/checkAwb/{AWB}'),
    'anteraja' => array('name' => 'Anteraja', 'code' => 'ANTERAJA', 'portal' => 'https://anteraja.id/tracking', 'default_direct' => 'https://berdu.id/cek-resi/anteraja?resi={AWB}'),
    'pos'      => array('name' => 'Pos Indonesia', 'code' => 'POS', 'portal' => 'https://www.posindonesia.co.id/id/tracking', 'default_direct' => 'https://berdu.id/cek-resi/pos?resi={AWB}'),
    'lion'     => array('name' => 'Lion Parcel', 'code' => 'LION', 'portal' => 'https://lionparcel.com/track', 'default_direct' => 'https://berdu.id/cek-resi/lion-parcel?resi={AWB}'),
    'ninja'    => array('name' => 'Ninja Xpress', 'code' => 'NINJA', 'portal' => 'https://www.ninjaxpress.co/id-id/tracking', 'default_direct' => 'https://www.ninjaxpress.co/id-id/tracking?id={AWB}'),
    'ide'      => array('name' => 'ID Express', 'code' => 'IDE', 'portal' => 'https://idexpress.com/track', 'default_direct' => 'https://berdu.id/cek-resi/id-express?resi={AWB}'),
    'wahana'   => array('name' => 'Wahana Prestasi', 'code' => 'WAHANA', 'portal' => 'https://www.wahana.com/tracking', 'default_direct' => 'https://berdu.id/cek-resi/wahana?resi={AWB}'),
    'tiki'     => array('name' => 'TIKI', 'code' => 'TIKI', 'portal' => 'https://www.tiki.id/id/tracking', 'default_direct' => 'https://berdu.id/cek-resi/tiki?resi={AWB}'),
    'spx'      => array('name' => 'SPX (Shopee Express)', 'code' => 'SPX', 'portal' => 'https://spx.co.id/', 'default_direct' => 'https://spx.co.id/track?awb={AWB}'),
    'sap'      => array('name' => 'SAP Express', 'code' => 'SAP', 'portal' => 'https://www.sap-express.id/id/cek-resi', 'default_direct' => 'https://berdu.id/cek-resi/sap?resi={AWB}')
);
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-rose:      #ef4444;
    --pk-amber:     #f59e0b;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-cfg-wrap {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 60px;
}
.pk01-cfg-wrap * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-hero-cockpit {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-system-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}

/* 2. Modern Scrollable Tab Bar */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}
.pk01-tab-btn.is-danger {
    color: #dc2626;
}
.pk01-tab-btn.is-danger.is-active {
    background: #dc2626;
    color: #ffffff;
}

/* Panels */
.pk01-panel { display: none; }
.pk01-panel.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Cards & Surfaces */
.pk01-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-card-title {
    font-size: 18px;
    font-weight: 800;
    margin: 0 0 4px;
    color: var(--pk-slate-900);
}
.pk01-card-desc {
    font-size: 13px;
    color: var(--pk-slate-600);
    margin-bottom: 22px;
}

.pk01-grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; }
.pk01-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; }
@media (max-width: 880px) { .pk01-grid-2, .pk01-grid-3 { grid-template-columns: 1fr; } }

/* Form Controls */
.pk01-form-group { display: flex; flex-direction: column; gap: 6px; }
.pk01-form-group label { font-size: 12.5px; font-weight: 700; color: var(--pk-slate-700); }
.pk01-ctrl {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13.5px;
    background: #ffffff;
    transition: all 0.2s ease;
}
.pk01-ctrl:focus {
    outline: none;
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Alert Boxes */
.pk01-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-alert.is-error { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }

/* Buttons */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 9px 16px;
    font-size: 13px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
.pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-danger { background: var(--pk-rose); color: #ffffff !important; }
.pk01-btn-danger:hover { background: #dc2626; }
.pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
.pk01-btn-emerald:hover { background: #059669; }

/* Sticky Footer */
.pk01-sticky-bar {
    position: sticky;
    bottom: 20px;
    background: rgba(255, 255, 255, 0.92);
    backdrop-filter: blur(12px);
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 16px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.12);
    z-index: 99;
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

/* Pill Button */
.pk01-pill-token {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    color: #1e40af;
    border-radius: 6px;
    padding: 3px 7px;
    font-size: 11px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill-token:hover {
    background: var(--pk-indigo);
    color: #ffffff;
    border-color: var(--pk-indigo);
}

/* Granular Reset Cards */
.pk01-danger-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 14px;
    margin: 18px 0;
}
.pk01-danger-card {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    padding: 14px;
    display: flex;
    gap: 12px;
    align-items: flex-start;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-danger-card:hover {
    border-color: #f87171;
    background: #fffafa;
}
.pk01-danger-card input {
    width: 18px;
    height: 18px;
    margin-top: 3px;
    flex-shrink: 0;
    cursor: pointer;
}
.pk01-record-badge {
    display: inline-block;
    background: #fee2e2;
    color: #991b1b;
    padding: 2px 7px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    margin-left: 6px;
}
</style>

<div class="pk01-cfg-wrap">

    <!-- 1. HERO COCKPIT -->
    <header class="pk01-hero-cockpit">
        <div class="pk01-hero-left">
            <span class="pk01-eyebrow">⚙️ ENTERPRISE CONTROL &bull; CENTRAL REPOSITORY</span>
            <h1>Pusat Pengaturan Sentral PK01</h1>
            <p>
                Konfigurasi legalitas identitas usaha, format penomoran dokumen otomatis, integrasi multi-kurir ekspedisi Indonesia, kecerdasan buatan AI, serta manajemen basis data aman.
            </p>
        </div>
        <div class="pk01-system-pill">
            <div style="font-size:12px; font-weight:700; color:#4ade80;">● SERVER AKTIF</div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                PHP <?php echo PHP_VERSION; ?> &bull; <?php echo current_time('d M Y'); ?>
            </div>
        </div>
    </header>

    <?php if (!empty($notice)) echo $notice; ?>

    <!-- 2. SCROLLABLE TAB NAVIGATION -->
    <nav class="pk01-nav-tabs" aria-label="Menu Pengaturan">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-company">🏢 Profil Usaha</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-data-health">🩺 Kesehatan & Data Nyata</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-numbering">🔢 Penomoran Dokumen</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-policy">⚖️ Finansial &amp; Bank</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-shipping">🚚 Ekspedisi &amp; Resi Real</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-marketplace-source">🧩 Sumber &amp; Template Marketplace</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-ai">🤖 AI Assistant</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-whatsapp">💬 WhatsApp Gateway</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-users">👥 Pendaftaran Staf</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-backup">🛡️ Cadangan SQL</button>
        <button type="button" class="pk01-tab-btn is-danger" data-target="tab-reset">⚠️ Reset Data Selektif</button>
    </nav>

    <!-- SMART DATA HEALTH -->
    <div class="pk01-panel" id="tab-data-health">
        <section class="pk01-card">
            <div class="pk01-panel-head"><h2>🩺 Kesehatan Sistem & Kelengkapan Data Nyata</h2><p>Panel ini hanya membaca database. Angka tidak diisi agar layar terlihat penuh. Jika belum ada transaksi, hasilnya memang 0.</p></div>
            <?php echo $pk01_health_action_notice; ?>
            <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0;">
                <div class="pk01-card" style="margin:0;background:#f8fafc;"><small>Total baris data yang dicek</small><strong style="display:block;font-size:24px;"><?php echo number_format((int)($pk01_operational_snapshot['rows_total']??0)); ?></strong></div>
                <div class="pk01-card" style="margin:0;background:#f8fafc;"><small>Baris data lengkap</small><strong style="display:block;font-size:24px;"><?php echo number_format((int)($pk01_operational_snapshot['rows_complete']??0)); ?></strong></div>
                <div class="pk01-card" style="margin:0;background:#f8fafc;"><small>Transaksi penjualan</small><strong style="display:block;font-size:24px;"><?php echo number_format((int)($pk01_operational_snapshot['sales_total']??0)); ?></strong><span style="font-size:11px;color:#64748b;">valid: <?php echo number_format((int)($pk01_operational_snapshot['sales_valid']??0)); ?></span></div>
                <div class="pk01-card" style="margin:0;background:#f8fafc;"><small>Job produksi</small><strong style="display:block;font-size:24px;"><?php echo number_format((int)($pk01_operational_snapshot['jobs_total']??0)); ?></strong><span style="font-size:11px;color:#64748b;">selesai: <?php echo number_format((int)($pk01_operational_snapshot['jobs_finished']??0)); ?></span></div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
                <form method="post"><?php wp_nonce_field('pk01_health_check_nonce'); ?><button class="pk01-btn pk01-btn-primary" type="submit" name="pk01_run_health_check" value="1">🩺 Periksa Kesehatan Data Sekarang</button></form>
                <form method="post"><?php wp_nonce_field('pk01_repair_sync_nonce'); ?><button class="pk01-btn pk01-btn-subtle" type="submit" name="pk01_repair_sync_now" value="1">⚙️ Perbaiki Struktur & Sinkronkan Data Nyata</button></form>
            </div>
            <div class="pk01-table-card"><table class="pk01-tbl"><thead><tr><th>Domain</th><th>Total</th><th>Lengkap</th><th>Belum lengkap</th><th>Kelengkapan</th></tr></thead><tbody>
            <?php foreach((array)($pk01_operational_snapshot['groups']??array()) as $g): ?><tr><td><strong><?php echo esc_html($g['label']); ?></strong></td><td><?php echo number_format((int)$g['total']); ?></td><td><?php echo number_format((int)$g['complete']); ?></td><td><?php echo number_format((int)$g['incomplete']); ?></td><td><?php echo number_format((float)$g['percent'],1,',','.'); ?>%</td></tr><?php endforeach; ?>
            </tbody></table></div>
            <div style="margin-top:14px;padding:13px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e3a8a;font-size:12px;"><strong>Aturan Smart PK01:</strong> struktur/laman yang hilang boleh dibuat otomatis karena itu infrastruktur. Data bisnis seperti produk, order, penjualan, pembayaran, stok, Seller, Job, dan produksi <strong>tidak pernah dibuat otomatis</strong>. Jika integrasi belum dapat dijalankan karena kredensial/API/template resmi belum tersedia, PK01 menampilkan status dan alasan, bukan membuat data palsu.</div>
        </section>
    </div>

    <!-- 3. FORM PENGATURAN UTAMA -->
    <form method="post" id="pk01-main-form">
        <?php wp_nonce_field('pk01_central_settings_save'); ?>
        <input type="hidden" name="pk01_central_settings_save" value="1">

        <!-- TAB 1: PROFIL USAHA -->
        <div class="pk01-panel is-active" id="tab-company">
            <section class="pk01-card">
                <h2 class="pk01-card-title">Identitas Legalitas Usaha &amp; Format Cetak</h2>
                <p class="pk01-card-desc">Informasi yang tampil pada kop surat resmi, faktur tagihan, surat jalan pengiriman, dan SPK kerja.</p>
                <div class="pk01-grid-2">
                    <div class="pk01-form-group">
                        <label>Nama Brand / Merek Usaha</label>
                        <input type="text" name="company_name" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_name']); ?>" placeholder="Contoh: PT Manufaktur Kayu Nusantara">
                    </div>
                    <div class="pk01-form-group">
                        <label>Nama Legal Badan Usaha (PT / CV / UD)</label>
                        <input type="text" name="company_legal_name" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_legal_name']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Slogan / Tagline Usaha</label>
                        <input type="text" name="company_tagline" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_tagline']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Kota Penerbit Surat / Dokumen</label>
                        <input type="text" name="company_city" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_city']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Nomor Induk Berusaha (NIB)</label>
                        <input type="text" name="company_nib" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_nib']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Nomor Pokok Wajib Pajak (NPWP)</label>
                        <input type="text" name="company_npwp" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_npwp']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>No. Telepon Kantor / Hotline WhatsApp</label>
                        <input type="text" name="company_phone" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_phone']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Email Resmi Usaha</label>
                        <input type="email" name="company_email" class="pk01-ctrl" value="<?php echo esc_attr($settings['company_email']); ?>">
                    </div>
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label>Alamat Workshop / Pabrik Lengkap</label>
                        <textarea name="company_address" class="pk01-ctrl" rows="2"><?php echo esc_textarea($settings['company_address']); ?></textarea>
                    </div>

                    <div class="pk01-form-group">
                        <label>Logo Usaha</label>
                        <div style="display:flex;gap:12px;align-items:center;background:#f8fafc;padding:12px;border:1px solid #e2e8f0;border-radius:10px;">
                            <img id="logo_display_thumb" src="<?php echo esc_url($settings['company_logo']); ?>" alt="Logo" style="max-width:55px;max-height:55px;object-fit:contain;<?php echo empty($settings['company_logo']) ? 'display:none;' : ''; ?>">
                            <span id="logo_placeholder_text" style="font-size:11px;color:#94a3b8;font-weight:700;<?php echo !empty($settings['company_logo']) ? 'display:none;' : ''; ?>">LOGO</span>
                            <input type="hidden" id="cfg_company_logo" name="company_logo" value="<?php echo esc_attr($settings['company_logo']); ?>">
                            <button type="button" class="pk01-btn pk01-btn-subtle" id="btn_upload_logo">📁 Pilih Logo</button>
                            <button type="button" class="pk01-btn pk01-btn-danger" id="btn_remove_logo" style="<?php echo empty($settings['company_logo']) ? 'display:none;' : ''; ?>">Hapus</button>
                        </div>
                    </div>
                    <div class="pk01-form-group">
                        <label>Cap Stempel Perusahaan (PNG Transparan)</label>
                        <div style="display:flex;gap:12px;align-items:center;background:#f8fafc;padding:12px;border:1px solid #e2e8f0;border-radius:10px;">
                            <img id="stamp_display_thumb" src="<?php echo esc_url($settings['company_stamp']); ?>" alt="Stempel" style="max-width:55px;max-height:55px;object-fit:contain;<?php echo empty($settings['company_stamp']) ? 'display:none;' : ''; ?>">
                            <span id="stamp_placeholder_text" style="font-size:11px;color:#94a3b8;font-weight:700;<?php echo !empty($settings['company_stamp']) ? 'display:none;' : ''; ?>">CAP</span>
                            <input type="hidden" id="cfg_company_stamp" name="company_stamp" value="<?php echo esc_attr($settings['company_stamp']); ?>">
                            <button type="button" class="pk01-btn pk01-btn-subtle" id="btn_upload_stamp">📁 Pilih Cap</button>
                            <button type="button" class="pk01-btn pk01-btn-danger" id="btn_remove_stamp" style="<?php echo empty($settings['company_stamp']) ? 'display:none;' : ''; ?>">Hapus</button>
                        </div>
                    </div>

                    <div class="pk01-form-group">
                        <label>Nama Pejabat Penandatangan</label>
                        <input type="text" name="signee_name" class="pk01-ctrl" value="<?php echo esc_attr($settings['signee_name']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Jabatan Penandatangan</label>
                        <input type="text" name="signee_position" class="pk01-ctrl" value="<?php echo esc_attr($settings['signee_position']); ?>">
                    </div>
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label>Catatan Syarat Pembayaran (Footer Faktur / Tagihan)</label>
                        <textarea name="invoice_terms" class="pk01-ctrl" rows="2"><?php echo esc_textarea($settings['invoice_terms']); ?></textarea>
                    </div>
                </div>
            </section>
        </div>

        <!-- TAB 2: PENOMORAN DOKUMEN -->
        <div class="pk01-panel" id="tab-numbering">
            <section class="pk01-card">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
                    <div>
                        <h2 class="pk01-card-title">Pola Penomoran Dokumen Otomatis</h2>
                        <p class="pk01-card-desc" style="margin:0;">Format nomor dokumen unik di seluruh alur pesanan, keuangan, gudang &amp; SPK.</p>
                    </div>
                    <input type="search" id="pk01_doc_search" class="pk01-ctrl" placeholder="🔍 Cari jenis dokumen..." style="max-width:240px;">
                </div>

                <div class="pk01-table-card">
                    <table class="pk01-tbl" id="pk01_doc_table">
                        <thead>
                            <tr>
                                <th style="width:180px;">Jenis Dokumen</th>
                                <th style="width:90px;">Prefix</th>
                                <th>Pola Penomoran (Dynamic Pattern)</th>
                                <th style="width:70px;">Digit</th>
                                <th style="width:80px;">Urut</th>
                                <th>Pratinjau Hasil</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $doc_labels = class_exists('PK01_Settings') && method_exists('PK01_Settings','document_registry') ? array_map(function($d){ return $d['label']; }, PK01_Settings::document_registry()) : array();
                            foreach ($doc_labels as $k => $lbl):
                                $p_val = $settings[$k . '_prefix'] ?? 'DOC';
                                $d_val = $settings[$k . '_digits'] ?? 5;
                                $s_val = $settings[$k . '_sequence'] ?? 1;
                                $pt_val = $settings[$k . '_pattern'] ?? '{PREFIX}-{SEQ}';
                                $sample = pk01_format_doc_number($p_val, $d_val, $s_val, $pt_val);
                            ?>
                            <tr class="numbering-row" data-label="<?php echo esc_attr(strtolower($lbl . ' ' . $k)); ?>">
                                <td><strong><?php echo esc_html($lbl); ?></strong></td>
                                <td><input type="text" name="<?php echo esc_attr($k . '_prefix'); ?>" value="<?php echo esc_attr($p_val); ?>" class="pk01-ctrl num-prefix" style="text-transform:uppercase;"></td>
                                <td>
                                    <input type="text" name="<?php echo esc_attr($k . '_pattern'); ?>" value="<?php echo esc_attr($pt_val); ?>" class="pk01-ctrl num-pattern">
                                    <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:6px;">
                                        <button type="button" class="pk01-pill-token" data-ins="{PREFIX}">+ Prefix</button>
                                        <button type="button" class="pk01-pill-token" data-ins="{YYYY}">+ YYYY</button>
                                        <button type="button" class="pk01-pill-token" data-ins="{YY}">+ YY</button>
                                        <button type="button" class="pk01-pill-token" data-ins="{MM}">+ MM</button>
                                        <button type="button" class="pk01-pill-token" data-ins="{DD}">+ DD</button>
                                        <button type="button" class="pk01-pill-token" data-ins="{ROMAN}">+ ROMAN</button>
                                        <button type="button" class="pk01-pill-token" data-ins="{SEQ}">+ SEQ</button>
                                    </div>
                                </td>
                                <td><input type="number" name="<?php echo esc_attr($k . '_digits'); ?>" min="1" max="10" value="<?php echo esc_attr($d_val); ?>" class="pk01-ctrl num-digits"></td>
                                <td><input type="number" name="<?php echo esc_attr($k . '_sequence'); ?>" min="1" value="<?php echo esc_attr($s_val); ?>" class="pk01-ctrl num-seq"></td>
                                <td>
                                    <span class="num-preview" style="background:#f1f5f9;color:#0f172a;font-family:ui-monospace,monospace;font-size:12px;font-weight:700;padding:6px 10px;border-radius:6px;border:1px solid #cbd5e1;display:inline-block;">
                                        <?php echo esc_html($sample); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>

        <!-- TAB 3: FINANSIAL & BANK -->
        <div class="pk01-panel" id="tab-policy">
            <section class="pk01-card">
                <h2 class="pk01-card-title">Rekening Bank &amp; Kebijakan Toko</h2>
                <p class="pk01-card-desc">Informasi pembayaran transfer dan aturan jatuh tempo piutang pelanggan.</p>
                <div class="pk01-grid-3">
                    <div class="pk01-form-group">
                        <label>Nama Bank Penerima</label>
                        <input type="text" name="bank_name" class="pk01-ctrl" value="<?php echo esc_attr($settings['bank_name']); ?>" placeholder="BCA / Mandiri / BRI / BSI">
                    </div>
                    <div class="pk01-form-group">
                        <label>Nomor Rekening</label>
                        <input type="text" name="bank_account_number" class="pk01-ctrl" value="<?php echo esc_attr($settings['bank_account_number']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Nama Pemilik Rekening (a.n.)</label>
                        <input type="text" name="bank_account_name" class="pk01-ctrl" value="<?php echo esc_attr($settings['bank_account_name']); ?>">
                    </div>

                    <div class="pk01-form-group">
                        <label>PPN / Pajak Default (%)</label>
                        <input type="number" step="0.1" name="tax_default_percent" class="pk01-ctrl" value="<?php echo esc_attr($settings['tax_default_percent']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Jatuh Tempo Faktur (Hari)</label>
                        <input type="number" name="invoice_due_days" class="pk01-ctrl" value="<?php echo esc_attr($settings['invoice_due_days']); ?>">
                    </div>
                    <div class="pk01-form-group">
                        <label>Batas Minimum Stok Kritis</label>
                        <input type="number" name="stock_alert_min_default" class="pk01-ctrl" value="<?php echo esc_attr($settings['stock_alert_min_default']); ?>">
                    </div>
                </div>
            </section>
        </div>

        <!-- TAB 4: EKSPEDISI & RESI REAL -->
        <div class="pk01-panel" id="tab-marketplace-source">
    <div class="pk01-panel-head"><h2>🧩 Sumber Data & Template Marketplace</h2><p>PK01 hanya mengeluarkan file setelah template resmi marketplace dipasang. Sistem tidak menebak kolom yang belum diverifikasi.</p></div>
    <?php echo $pk01_marketplace_catalog_notice; ?>
    <div class="pk01-grid-2">
      <section class="pk01-card">
        <h3>Pasang Template Resmi Terbaru</h3>
        <p>Upload template produk yang benar-benar diberikan Seller Center marketplace. CSV/TSV dan XLSX didukung untuk membaca header. Setelah upload, PK01 melakukan pemetaan otomatis; export tetap diblokir bila ada kolom yang belum dikenali.</p>
        <form method="post" enctype="multipart/form-data">
          <?php wp_nonce_field('pk01_marketplace_template_nonce'); ?>
          <input type="hidden" name="pk01_marketplace_template_upload" value="1">
          <label>Marketplace</label>
          <select name="marketplace_template_key" class="pk01-ctrl" required>
            <?php foreach (PK01_Marketplace_Catalog::marketplaces() as $mk=>$ml): ?><option value="<?php echo esc_attr($mk); ?>"><?php echo esc_html($ml); ?></option><?php endforeach; ?>
          </select>
          <label style="display:block;margin-top:10px;">File template resmi</label>
          <input type="file" name="marketplace_template_file" accept=".csv,.tsv,.txt,.xlsx" required>
          <label style="display:block;margin-top:10px;"><input type="checkbox" name="marketplace_template_verify" value="1"> Tandai terverifikasi setelah pemetaan otomatis selesai</label>
          <button class="button button-primary" type="submit" style="margin-top:12px;">Simpan Template &amp; Cek Mapping</button>
        </form>
      </section>
      <section class="pk01-card">
        <h3>Status & Mapping Adapter</h3>
        <table class="widefat striped"><thead><tr><th>Marketplace</th><th>Template</th><th>Status</th><th>Kolom belum dikenali</th></tr></thead><tbody>
        <?php foreach(PK01_Marketplace_Catalog::marketplaces() as $mk=>$ml): $t=PK01_Marketplace_Catalog::get_template($mk); ?>
          <tr><td><?php echo esc_html($ml); ?></td><td><?php echo esc_html($t['source_file']?:'Belum dipasang'); ?></td><td><?php echo !empty($t['verified'])?'✅ Terverifikasi':'⚠️ Belum siap'; ?></td><td><?php echo esc_html(implode(', ',(array)($t['unmapped']??[]))); ?></td></tr>
        <?php endforeach; ?></tbody></table>
        <hr style="margin:18px 0;">
        <h4>Periksa Mapping Kolom</h4>
        <p>Pilih marketplace lalu pastikan setiap header template menunjuk ke field PK01 yang benar. Jika header ambigu seperti <b>SKU</b>, PK01 tidak menebak dan wajib dikonfirmasi.</p>
        <select id="pk01-map-market" class="pk01-ctrl" onchange="pk01LoadMarketplaceMap(this.value)">
          <?php foreach(PK01_Marketplace_Catalog::marketplaces() as $mk=>$ml): ?><option value="<?php echo esc_attr($mk); ?>"><?php echo esc_html($ml); ?></option><?php endforeach; ?>
        </select>
        <?php foreach(PK01_Marketplace_Catalog::marketplaces() as $mk=>$ml): $t=PK01_Marketplace_Catalog::get_template($mk); ?>
        <form method="post" class="pk01-market-map-form" data-market="<?php echo esc_attr($mk); ?>" style="display:<?php echo $mk==='shopee'?'block':'none'; ?>;margin-top:10px;">
          <?php wp_nonce_field('pk01_marketplace_mapping_nonce'); ?><input type="hidden" name="pk01_marketplace_mapping_save" value="1"><input type="hidden" name="marketplace_mapping_key" value="<?php echo esc_attr($mk); ?>">
          <table class="widefat"><thead><tr><th>Header Template</th><th>Field PK01</th></tr></thead><tbody>
          <?php foreach((array)$t['headers'] as $i=>$h): ?><tr><td><code><?php echo esc_html($h); ?></code></td><td><select name="marketplace_mapping[<?php echo (int)$i; ?>]" class="pk01-ctrl"><option value="">-- Tidak digunakan / wajib dipetakan --</option><?php foreach(PK01_Marketplace_Catalog::canonical_fields() as $cf=>$cl): ?><option value="<?php echo esc_attr($cf); ?>" <?php selected(($t['mapping'][$i]??''),$cf); ?>><?php echo esc_html($cl); ?></option><?php endforeach; ?></select></td></tr><?php endforeach; ?>
          </tbody></table>
          <label style="display:block;margin-top:10px;"><input type="checkbox" name="marketplace_mapping_verify" value="1"> Saya sudah memeriksa mapping terhadap template resmi terbaru.</label>
          <button class="button button-primary" type="submit" style="margin-top:8px;">Simpan Mapping &amp; Verifikasi</button>
        </form>
        <?php endforeach; ?>
        <div style="margin-top:12px;padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;font-size:12px;"><b>Source of Truth:</b> Produk, SKU, varian, ukuran, gambar, deskripsi, HPP dan stok berasal dari PK01 E-Commerce/Theme Integration. Harga marketplace adalah override Seller per marketplace. AI hanya boleh memberi saran mapping/menandai konflik; sistem tetap meminta konfirmasi manusia sebelum template dinyatakan verified.</div>
      </section>
    </div>
</div>

<div class="pk01-panel" id="tab-shipping">
            <section class="pk01-card">
                <h2 class="pk01-card-title">Kurir Ekspedisi Indonesia &amp; Auto-Track Resi Real</h2>
                <p class="pk01-card-desc">
                    Data tracking PK01 berasal dari API provider yang benar-benar terhubung. Jika API belum diisi, sistem hanya menyediakan link web untuk verifikasi manual dan TIDAK membuat status tracking palsu.
                </p>

                <div class="pk01-grid-2">
                    <div class="pk01-form-group">
                        <label>Mode Data Tracking</label>
                        <select name="shipping_mode" class="pk01-ctrl" style="font-weight:700;">
                            <option value="none">Manual / API belum terhubung</option>
                        </select>
                    </div>
                    <div class="pk01-form-group">
                        <label>Penyedia API Kurir</label>
                        <select name="shipping_provider" class="pk01-ctrl">
                            <?php foreach (array('none'=>'Belum terhubung','biteship'=>'Biteship — Multi Kurir','rajaongkir'=>'RajaOngkir/Komerce','binderbyte'=>'Binderbyte','custom'=>'Custom API') as $pv=>$pn): ?>
                                <option value="<?php echo esc_attr($pv); ?>" <?php selected(($shipping_cfg['provider'] ?? $shipping_cfg['shipping_provider'] ?? 'none'), $pv); ?>><?php echo esc_html($pn); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="pk01-form-group">
                        <label>API Key Provider Utama</label>
                        <input type="password" name="shipping_api_keys[<?php echo esc_attr($shipping_cfg['provider'] ?? 'none'); ?>]" class="pk01-ctrl" autocomplete="new-password" placeholder="<?php echo !empty($shipping_cfg['api_key']) ? '•••••••••••••••• (Tersimpan)' : 'Masukkan API Key provider'; ?>">
                    </div>
                    <div class="pk01-form-group" style="grid-column:1 / -1;">
                        <label>API Key per Provider (opsional, simpan yang memang Anda miliki)</label>
                        <div class="pk01-grid-2">
                            <?php foreach(array('biteship'=>'Biteship','binderbyte'=>'Binderbyte','rajaongkir'=>'RajaOngkir/Komerce','custom'=>'Custom API') as $apk=>$apn): ?>
                                <div>
                                    <label style="font-size:12px;"><?php echo esc_html($apn); ?></label>
                                    <input type="password" name="shipping_api_keys[<?php echo esc_attr($apk); ?>]" class="pk01-ctrl" autocomplete="new-password" placeholder="<?php echo !empty(($shipping_cfg['api_keys'][$apk] ?? '')) ? '•••••••••••••••• (Tersimpan)' : 'API Key / Token'; ?>">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <small style="display:block;color:#64748b;margin-top:6px;">Kurir diarahkan ke provider melalui kolom API Provider per Kurir di bawah. Jika key kosong, PK01 tidak akan mengaku mendapat data API.</small>
                    </div>
                    <div class="pk01-form-group">
                        <label>Kota Asal Pengirim Default</label>
                        <input type="text" name="shipping_origin_city" class="pk01-ctrl" value="<?php echo esc_attr($shipping_cfg['shipping_origin_city']); ?>" placeholder="Contoh: Jakarta Barat">
                    </div>
                    <div class="pk01-form-group">
                        <label><input type="checkbox" name="shipping_enabled" value="1" <?php checked(!empty($shipping_cfg['enabled'])); ?>> Aktifkan sinkronisasi API otomatis</label>
                        <small style="color:#64748b;display:block;margin-top:5px;">Cron hanya membaca shipment nyata dan menyimpan event API yang diterima.</small>
                    </div>
                    <div class="pk01-form-group">
                        <label>Webhook Secret (opsional)</label>
                        <input type="password" name="shipping_webhook_secret" class="pk01-ctrl" value="<?php echo esc_attr($shipping_cfg['webhook_secret'] ?? ''); ?>" autocomplete="new-password">
                    </div>
                </div>

                <div style="margin-top:24px;">
                    <h3 style="font-size:15px;font-weight:800;margin-bottom:6px;color:#0f172a;">Daftar Ekspedisi Resmi Indonesia &amp; Template URL Auto-Tracking</h3>
                    <div class="pk01-table-card">
                        <table class="pk01-tbl">
                            <thead>
                                <tr>
                                    <th style="width:50px; text-align:center;">Aktif</th>
                                    <th style="width:160px;">Kurir</th>
                                    <th>API Provider untuk Kurir</th><th>Template Link Verifikasi ({AWB})</th>
                                    <th style="width:150px; text-align:center;">Web Resmi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $act_couriers = (array)($shipping_cfg['shipping_active_couriers'] ?? array());
                                $saved_urls   = (array)($shipping_cfg['shipping_direct_urls'] ?? array());

                                foreach ($indonesian_couriers as $ck => $cdata):
                                    $is_act = in_array($ck, $act_couriers, true);
                                    $cur_val = $saved_urls[$ck] ?? $cdata['default_direct'];
                                ?>
                                <tr>
                                    <td style="text-align:center;">
                                        <input type="checkbox" name="shipping_active_couriers[]" value="<?php echo esc_attr($ck); ?>" <?php checked($is_act, true); ?> style="width:16px;height:16px;cursor:pointer;">
                                    </td>
                                    <td>
                                        <strong style="color:#0f172a;display:block;"><?php echo esc_html($cdata['name']); ?></strong>
                                        <span style="font-size:11px;color:#64748b;font-family:monospace;"><?php echo esc_html($cdata['code']); ?></span>
                                    </td>
                                    <td>
                                        <select name="shipping_courier_routes[<?php echo esc_attr($ck); ?>]" class="pk01-ctrl" style="font-size:12px;padding:6px 10px;">
                                            <?php foreach(array('none'=>'Manual','biteship'=>'Biteship','rajaongkir'=>'RajaOngkir/Komerce','binderbyte'=>'Binderbyte','custom'=>'Custom API') as $rp=>$rn): ?>
                                                <option value="<?php echo esc_attr($rp); ?>" <?php selected(($shipping_cfg['courier_routes'][$ck] ?? $shipping_cfg['provider'] ?? 'none'),$rp); ?>><?php echo esc_html($rn); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="text" name="shipping_direct_urls[<?php echo esc_attr($ck); ?>]" value="<?php echo esc_attr($cur_val); ?>" class="pk01-ctrl" style="font-size:12px;font-family:monospace;padding:6px 10px;">
                                    </td>
                                    <td style="text-align:center;">
                                        <a href="<?php echo esc_url($cdata['portal']); ?>" target="_blank" class="pk01-btn pk01-btn-subtle" style="font-size:11px;padding:4px 10px;">
                                            🌐 Buka Portal &nearr;
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </section>
        </div>

        <!-- TAB 5: AI ASSISTANT -->
        <div class="pk01-panel" id="tab-ai">
            <section class="pk01-card">
                <h2 class="pk01-card-title">Kecerdasan Buatan (AI Control Tower)</h2>
                <p class="pk01-card-desc">Konteks cerdas yang digunakan oleh asisten analitik pada dashboard pimpinan usaha.</p>
                <div class="pk01-grid-2">
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer">
                            <input type="checkbox" name="ai_enabled" value="1" <?php checked($settings['ai_enabled'], '1'); ?> style="width:18px;height:18px">
                            <span style="font-weight:700;">Aktifkan Asisten AI Terintegrasi PK01</span>
                        </label>
                    </div>
                    <div class="pk01-form-group">
                        <label>Provider Mesin AI</label>
                        <select name="ai_provider" class="pk01-ctrl">
                            <option value="openai" <?php selected($settings['ai_provider'], 'openai'); ?>>OpenAI (ChatGPT)</option>
                            <option value="claude" <?php selected($settings['ai_provider'], 'claude'); ?>>Anthropic Claude</option>
                            <option value="gemini" <?php selected($settings['ai_provider'], 'gemini'); ?>>Google Gemini</option>
                            <option value="deepseek" <?php selected($settings['ai_provider'], 'deepseek'); ?>>DeepSeek AI</option>
                        </select>
                    </div>
                    <div class="pk01-form-group">
                        <label>Nama Model AI</label>
                        <input type="text" name="ai_model" class="pk01-ctrl" value="<?php echo esc_attr($settings['ai_model']); ?>" placeholder="gpt-4o-mini / gemini-1.5-flash">
                    </div>
                    <div class="pk01-form-group">
                        <label>Sektor / Industri Usaha</label>
                        <select name="ai_business_type" class="pk01-ctrl">
                            <option value="manufacture" <?php selected($settings['ai_business_type'], 'manufacture'); ?>>Pabrikasi / Manufaktur / Custom Workshop</option>
                            <option value="furniture" <?php selected($settings['ai_business_type'], 'furniture'); ?>>Furniture Kayu &amp; Interior</option>
                            <option value="garment" <?php selected($settings['ai_business_type'], 'garment'); ?>>Konveksi / Garment / Tekstil</option>
                            <option value="retail" <?php selected($settings['ai_business_type'], 'retail'); ?>>Toko Retail &amp; Grosir</option>
                        </select>
                    </div>
                    <div class="pk01-form-group">
                        <label>API Key AI</label>
                        <input type="password" name="ai_api_key" class="pk01-ctrl" autocomplete="new-password" placeholder="<?php echo !empty($settings['ai_api_key']) ? '•••••••••••••••• (Tersimpan)' : 'Masukkan API Key AI'; ?>">
                    </div>
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label>Instruksi / Persona Khusus AI</label>
                        <textarea name="ai_custom_context" class="pk01-ctrl" rows="3"><?php echo esc_textarea($settings['ai_custom_context']); ?></textarea>
                    </div>
                </div>
            </section>
        </div>

        <!-- TAB 6: WHATSAPP -->
        <div class="pk01-panel" id="tab-whatsapp">
            <section class="pk01-card">
                <h2 class="pk01-card-title">Gateway Notifikasi WhatsApp</h2>
                <p class="pk01-card-desc">Kirim notifikasi otomatis saat pesanan baru masuk, SPK selesai, atau resi pengiriman dibuat.</p>
                <div class="pk01-grid-2">
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer">
                            <input type="checkbox" name="wa_enabled" value="1" <?php checked($settings['wa_enabled'], '1'); ?> style="width:18px;height:18px">
                            <span style="font-weight:700;">Aktifkan Notifikasi WhatsApp Otomatis</span>
                        </label>
                    </div>
                    <div class="pk01-form-group">
                        <label>Penyedia Gateway</label>
                        <select name="wa_provider" class="pk01-ctrl">
                            <option value="none" <?php selected($settings['wa_provider'], 'none'); ?>>Tidak Digunakan</option>
                            <option value="fonnte" <?php selected($settings['wa_provider'], 'fonnte'); ?>>Fonnte Gateway</option>
                            <option value="wablas" <?php selected($settings['wa_provider'], 'wablas'); ?>>Wablas Gateway</option>
                        </select>
                    </div>
                    <div class="pk01-form-group">
                        <label>Nomor WhatsApp Pengirim</label>
                        <input type="text" name="wa_sender" class="pk01-ctrl" value="<?php echo esc_attr($settings['wa_sender']); ?>" placeholder="628xxxxxxxxxx">
                    </div>
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label>API Key / Token WhatsApp</label>
                        <input type="password" name="wa_api_key" class="pk01-ctrl" autocomplete="new-password" placeholder="<?php echo !empty($settings['wa_api_key']) ? '•••••••••••••••• (Tersimpan)' : 'Masukkan Token API'; ?>">
                    </div>
                </div>
            </section>
        </div>

        <!-- STICKY ACTION BAR -->
        <div class="pk01-sticky-bar">
            <div>
                <strong style="color:#0f172a; display:block;">Simpan Pengaturan Sentral</strong>
                <span style="font-size:12px; color:#64748b;">Perubahan langsung diterapkan pada seluruh dokumen dan sistem.</span>
            </div>
            <button type="submit" class="pk01-btn pk01-btn-primary" style="padding:11px 26px;">💾 Simpan Semua Konfigurasi</button>
        </div>
    </form>

    <!-- TAB 7: PENDAFTARAN & ROLE USER -->
    <div class="pk01-panel" id="tab-users">
        <section class="pk01-card">
            <h2 class="pk01-card-title">Daftarkan Akun Staf &amp; Penetapan Wewenang</h2>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0 18px;">
            <?php foreach (['pk01_kasir'=>'Kasir','pk01_keuangan'=>'Keuangan','pk01_produksi'=>'Produksi','pk01_gudang'=>'Gudang','pk01_logistik'=>'Logistik','pk01_packing'=>'Packing','pk01_employee'=>'Pekerja','pk01_seller'=>'Seller'] as $rk=>$rl): $cnt=count(get_users(['role'=>$rk,'fields'=>'ID'])); ?>
              <span style="padding:7px 10px;border:1px solid #e2e8f0;border-radius:999px;background:#f8fafc;font-size:12px;"><b><?php echo esc_html($rl); ?></b>: <?php echo (int)$cnt; ?> akun</span>
            <?php endforeach; ?>
            </div>
            <p class="pk01-card-desc" style="margin-top:-8px;">Tidak ada batas satu akun per role. Anda dapat membuat 2, 5, atau lebih akun Kasir/Keuangan/Produksi sesuai kebutuhan. Setiap akun memakai login WordPress sendiri sehingga audit dan tanggung jawab tetap jelas.</p>
            <p class="pk01-card-desc">Tambahkan akun login baru secara langsung dan tetapkan peran sesuai divisi operasional.</p>
            
            <form method="post" action="" style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:22px; margin-bottom:28px;">
                <?php wp_nonce_field('pk01_create_user_nonce'); ?>
                <input type="hidden" name="pk01_create_user_action" value="1">

                <div class="pk01-grid-2">
                    <div class="pk01-form-group">
                        <label>Username Login <span style="color:#ef4444;">*</span></label>
                        <input type="text" name="new_user_login" class="pk01-ctrl" required placeholder="Contoh: staf.produksi01">
                    </div>
                    <div class="pk01-form-group">
                        <label>Alamat Email Aktif <span style="color:#ef4444;">*</span></label>
                        <input type="email" name="new_user_email" class="pk01-ctrl" required placeholder="staf@perusahaan.com">
                    </div>
                    <div class="pk01-form-group">
                        <label>Nama Lengkap Staf</label>
                        <input type="text" name="new_user_display_name" class="pk01-ctrl" placeholder="Nama Lengkap Karyawan">
                    </div>
                    <div class="pk01-form-group">
                        <label>Password Akun <span style="color:#ef4444;">*</span></label>
                        <input type="password" name="new_user_pass" class="pk01-ctrl" minlength="8" required placeholder="Minimal 8 karakter">
                    </div>
                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label>Wewenang / Hak Akses (Role Operasional PK01) <span style="color:#ef4444;">*</span></label>
                        <select name="new_user_role" class="pk01-ctrl" style="font-weight:700;">
                            <option value="pk01_admin">🛡️ Admin Operasional (Akses Lengkap PK01)</option>
                            <option value="pk01_keuangan">💰 Divisi Keuangan &amp; Buku Kas (Finance)</option>
                            <option value="pk01_produksi">🏭 Kepala / Staf Produksi (SPK &amp; Job)</option>
                            <option value="pk01_gudang">📦 Pengelola Gudang &amp; Stok Bahan</option>
                            <option value="pk01_logistik">🚚 Tim Logistik, Resi &amp; Ekspedisi</option>
                            <option value="pk01_kasir">🛒 Kasir Penjualan / POS Order</option>
                            <option value="pk01_hr">👥 HRD, Data Karyawan &amp; Payroll Upah</option>
                            <option value="pk01_packing">📦 Tim Pengemasan (Packing Workspace)</option>
                            <option value="pk01_employee" selected>👷 Pekerja / Operator Produksi (Employee)</option>
                            <option value="pk01_seller">🤝 Mitra Seller / Affiliate</option>
                        </select>
                    </div>
                </div>

                <div style="margin-top:16px;">
                    <button type="submit" class="pk01-btn pk01-btn-primary">➕ Daftarkan Pengguna Baru</button>
                </div>
            </form>

            <?php
            $edit_id = absint($_GET['pk01_edit_user'] ?? 0);
            $edit_user = $edit_id ? get_user_by('id', $edit_id) : false;
            $user_role_options = [
                'pk01_admin'=>'🛡️ Admin Operasional','pk01_keuangan'=>'💰 Keuangan','pk01_produksi'=>'🏭 Produksi',
                'pk01_gudang'=>'📦 Gudang','pk01_logistik'=>'🚚 Logistik','pk01_kasir'=>'🛒 Kasir',
                'pk01_hr'=>'👥 HRD','pk01_packing'=>'📦 Packing','pk01_employee'=>'👷 Pekerja / Operator','pk01_seller'=>'🤝 Seller / Affiliate'
            ];
            if ($edit_user): ?>
            <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:14px; padding:20px; margin-bottom:24px;">
                <div style="display:flex; justify-content:space-between; gap:12px; align-items:center; flex-wrap:wrap;">
                    <div>
                        <strong style="font-size:16px; color:#1e3a8a;">✏️ Edit Pengguna: <?php echo esc_html($edit_user->user_login); ?></strong>
                        <div style="font-size:12px; color:#64748b; margin-top:3px;">Perubahan disimpan ke akun WordPress terpadu.</div>
                    </div>
                    <a href="<?php echo esc_url(remove_query_arg('pk01_edit_user')); ?>#tab-users" class="pk01-btn pk01-btn-subtle" style="font-size:12px;">Batal</a>
                </div>
                <form method="post" style="margin-top:16px;">
                    <?php wp_nonce_field('pk01_update_user_nonce'); ?>
                    <input type="hidden" name="pk01_update_user_action" value="1">
                    <input type="hidden" name="edit_user_id" value="<?php echo (int)$edit_user->ID; ?>">
                    <div class="pk01-grid-2">
                        <div class="pk01-form-group"><label>Username</label><input class="pk01-ctrl" value="<?php echo esc_attr($edit_user->user_login); ?>" disabled></div>
                        <div class="pk01-form-group"><label>Email</label><input type="email" name="edit_user_email" class="pk01-ctrl" value="<?php echo esc_attr($edit_user->user_email); ?>" required></div>
                        <div class="pk01-form-group"><label>Nama Lengkap</label><input name="edit_user_display_name" class="pk01-ctrl" value="<?php echo esc_attr($edit_user->display_name); ?>" required></div>
                        <div class="pk01-form-group"><label>Password Baru <small style="color:#64748b;">(kosong = tetap)</small></label><input type="password" name="edit_user_pass" class="pk01-ctrl" minlength="8" autocomplete="new-password"></div>
                        <div class="pk01-form-group" style="grid-column:1/-1;"><label>Role / Wewenang</label>
                        <select name="edit_user_role" class="pk01-ctrl" <?php disabled(in_array('administrator',(array)$edit_user->roles,true)); ?>>
                            <?php if (in_array('administrator',(array)$edit_user->roles,true)): ?><option value="administrator" selected>👑 Administrator WordPress</option><?php endif; ?>
                            <?php foreach($user_role_options as $rk=>$rl): ?><option value="<?php echo esc_attr($rk); ?>" <?php selected($edit_user->roles[0] ?? '',$rk); ?>><?php echo esc_html($rl); ?></option><?php endforeach; ?>
                        </select></div>
                    </div>
                    <button type="submit" class="pk01-btn pk01-btn-primary" style="margin-top:14px;">💾 Simpan Perubahan Pengguna</button>
                </form>
            </div>
            <?php endif; ?>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <h3 style="font-size:16px; font-weight:800; margin:0;">Daftar Akun Pengguna</h3>
                <input type="search" id="pk01-user-filter" class="pk01-ctrl" placeholder="🔍 Cari pengguna..." style="width:220px; font-size:12px; padding:6px 10px;">
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl" id="pk01-user-tbl">
                    <thead><tr><th>ID</th><th>Username</th><th>Nama Lengkap</th><th>Email</th><th>Role</th><th style="text-align:center;">Aksi</th></tr></thead>
                    <tbody>
                        <?php
                        $recent_users = get_users(array('number' => 100, 'orderby' => 'ID', 'order' => 'DESC'));
                        foreach ($recent_users as $u):
                            $r_str = !empty($u->roles) ? implode(', ', $u->roles) : 'Tanpa Role';
                            $edit_url = add_query_arg('pk01_edit_user', (int)$u->ID);
                        ?>
                        <tr>
                            <td style="font-weight:700; color:#64748b;">#<?php echo esc_html($u->ID); ?></td>
                            <td><strong style="font-family:monospace;"><?php echo esc_html($u->user_login); ?></strong></td>
                            <td><?php echo esc_html($u->display_name ?: '-'); ?></td>
                            <td><?php echo esc_html($u->user_email); ?></td>
                            <td><span style="display:inline-block; padding:3px 8px; border-radius:6px; font-size:11px; font-weight:700; background:#f1f5f9; color:#334155;"><?php echo esc_html($r_str); ?></span></td>
                            <td style="text-align:center;"><a href="<?php echo esc_url($edit_url); ?>#tab-users" class="pk01-btn pk01-btn-subtle" style="padding:4px 10px; font-size:11px;">✏️ Edit</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 8: CADANGAN SQL -->
    <div class="pk01-panel" id="tab-backup">
        <section class="pk01-card">
            <h2 class="pk01-card-title">Cadangan &amp; Pemulihan Basis Data (SQL Studio)</h2>
            <p class="pk01-card-desc">Unduh berkas cadangan database (.sql) atau pulihkan tabel transaksi Anda kapan saja.</p>

            <div class="pk01-grid-2">
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:22px;">
                    <h3 style="margin:0 0 8px; font-size:16px; font-weight:800; color:#0f172a;">📥 Ekspor Database SQL</h3>
                    <p style="font-size:13px; color:#64748b; margin-bottom:14px;">Pilih cakupan tabel database yang ingin dicadangkan:</p>
                    <form method="post" action="">
                        <?php wp_nonce_field('pk01_export_db_nonce'); ?>
                        <input type="hidden" name="pk01_action_export_sql" value="1">
                        <div style="display:flex; flex-direction:column; gap:8px; margin-bottom:14px; font-size:13px;">
                            <label style="cursor:pointer; display:flex; align-items:center; gap:8px;">
                                <input type="radio" name="export_scope" value="pk01_only" checked>
                                <span><b>Tabel Inti PK01 Saja</b> (Cepat, Ringan &amp; Bersih)</span>
                            </label>
                            <label style="cursor:pointer; display:flex; align-items:center; gap:8px;">
                                <input type="radio" name="export_scope" value="all">
                                <span><b>Seluruh Database WordPress</b> (Full System Backup)</span>
                            </label>
                        </div>
                        <button type="submit" class="pk01-btn pk01-btn-emerald">💾 Unduh Berkas Cadangan (.SQL)</button>
                    </form>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:22px;">
                    <h3 style="margin:0 0 8px; font-size:16px; font-weight:800; color:#0f172a;">📤 Pulihkan Basis Data (.SQL)</h3>
                    <p style="font-size:13px; color:#64748b;">Unggah file <code>.sql</code> untuk memulihkan tabel ke kondisi sebelumnya.</p>
                    <form method="post" action="" enctype="multipart/form-data">
                        <?php wp_nonce_field('pk01_import_db_nonce'); ?>
                        <input type="hidden" name="pk01_action_import_sql" value="1">
                        <div style="margin:14px 0;"><input type="file" name="pk01_sql_file" accept=".sql" required style="font-size:13px;"></div>
                        <button type="submit" class="pk01-btn pk01-btn-danger" onclick="return confirm('PERINGATAN: Memulihkan database akan menimpa data yang ada saat ini. Lanjutkan?');">⚡ Pulihkan Database</button>
                    </form>
                </div>
            </div>
        </section>
    </div>

    <!-- TAB 9: RESET DATA SELEKTIF -->
    <div class="pk01-panel" id="tab-reset">
        <section class="pk01-card" style="border-color:#fca5a5;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                <span style="background:#fee2e2;color:#b91c1c;padding:4px 10px;border-radius:6px;font-weight:800;font-size:12px;">ZONA KRITIS</span>
                <h2 class="pk01-card-title" style="color:#b91c1c;margin:0;">Reset Data Selektif &amp; Terkendali</h2>
            </div>
            <p class="pk01-card-desc">
                Pilih modul tertentu yang ingin dibersihkan hanya jika memang diperlukan untuk pemeliharaan data. Penghapusan transaksi tidak boleh dipakai untuk memperbaiki saldo; gunakan koreksi/reversal yang memiliki audit trail. 
                <strong>Pengaturan profil usaha, akun pengguna staf, dan master produk/bahan baku TIDAK AKAN terhapus.</strong>
            </p>

            <form method="post" action="" onsubmit="return validateSelectiveReset();">
                <?php wp_nonce_field('pk01_selective_reset_nonce'); ?>
                <input type="hidden" name="pk01_action_selective_reset" value="1">

                <div class="pk01-danger-grid">
                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="orders">
                        <div>
                            <strong>🛒 Pesanan &amp; Penjualan <span class="pk01-record-badge"><?php echo number_format($module_counts['orders']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan order penjualan, invoice kasir &amp; item transaksi.</p>
                        </div>
                    </label>

                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="production">
                        <div>
                            <strong>🏭 Job Produksi &amp; SPK <span class="pk01-record-badge"><?php echo number_format($module_counts['production']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan antrean surat perintah kerja (SPK) &amp; log pekerjaan.</p>
                        </div>
                    </label>

                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="finance">
                        <div>
                            <strong>💰 Keuangan &amp; Payroll <span class="pk01-record-badge"><?php echo number_format($module_counts['finance']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan mutasi kas, pengeluaran operasional &amp; slip gaji.</p>
                        </div>
                    </label>

                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="shipments">
                        <div>
                            <strong>🚚 Pengiriman &amp; Ekspedisi <span class="pk01-record-badge"><?php echo number_format($module_counts['shipments']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan manifest pengiriman kurir dan nomor resi paket.</p>
                        </div>
                    </label>

                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="returns">
                        <div>
                            <strong>↩️ Retur Barang &amp; Refund <span class="pk01-record-badge"><?php echo number_format($module_counts['returns']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan histori kompensasi dan pengembalian barang.</p>
                        </div>
                    </label>

                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="mutations">
                        <div>
                            <strong>📋 Log Mutasi Stok <span class="pk01-record-badge"><?php echo number_format($module_counts['mutations']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan catatan mutasi stok (master bahan tetap utuh).</p>
                        </div>
                    </label>

                    <label class="pk01-danger-card">
                        <input type="checkbox" name="reset_modules[]" value="sellers">
                        <div>
                            <strong>🤝 Riwayat Komisi Seller <span class="pk01-record-badge"><?php echo number_format($module_counts['sellers']); ?> Data</span></strong>
                            <p style="font-size:12px;color:#64748b;margin:3px 0 0;">Bersihkan pencairan saldo afiliasi &amp; histori komisi.</p>
                        </div>
                    </label>
                </div>

                <div style="background:#fff1f2; border:1px solid #fecdd3; border-radius:12px; padding:18px; margin-top:20px;">
                    <label style="display:block; font-size:13px; font-weight:700; color:#9f1239; margin-bottom:6px;">
                        Ketik kata <code style="background:#ffe4e6; padding:2px 6px; border-radius:4px; font-size:13px;">RESET</code> untuk mengonfirmasi:
                    </label>
                    <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
                        <input type="text" id="confirm_reset_keyword" name="confirm_reset_keyword" class="pk01-ctrl" placeholder="Ketik RESET di sini..." style="max-width:260px; border-color:#fda4af;" required autocomplete="off">
                        <button type="submit" class="pk01-btn pk01-btn-danger">
                            ⚠️ Bersihkan Modul yang Dipilih
                        </button>
                    </div>
                </div>
            </form>
        </section>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panels = document.querySelectorAll('.pk01-panel');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const panel = document.getElementById(targetId);
        if (btn && panel) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panels.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            panel.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash) {
        switchTab(currentHash);
    }

    // 2. LIVE DOCUMENT NUMBERING PREVIEW
    const romanMonths = ["I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"];
    const now = new Date();
    const curYear4 = now.getFullYear();
    const curYear2 = String(curYear4).slice(-2);
    const curMonth = String(now.getMonth() + 1).padStart(2, '0');
    const curDay   = String(now.getDate()).padStart(2, '0');
    const curRoman = romanMonths[now.getMonth()];

    const rows = document.querySelectorAll('.numbering-row');
    rows.forEach(row => {
        const prefixInput = row.querySelector('.num-prefix');
        const patternInput = row.querySelector('.num-pattern');
        const digitsInput = row.querySelector('.num-digits');
        const seqInput = row.querySelector('.num-seq');
        const preview = row.querySelector('.num-preview');
        const pills = row.querySelectorAll('.pk01-pill-token');

        function updateNumberPreview() {
            const p = (prefixInput.value || '').trim().toUpperCase();
            let pat = (patternInput.value || '').trim();
            const d = Math.max(1, Math.min(10, parseInt(digitsInput.value) || 1));
            const s = Math.max(1, parseInt(seqInput.value) || 1);
            const padded = String(s).padStart(d, '0');

            if (!pat) pat = '{PREFIX}-{SEQ}';

            let res = pat
                .replace(/{PREFIX}/g, p)
                .replace(/{YYYY}/g, curYear4)
                .replace(/{YY}/g, curYear2)
                .replace(/{MM}/g, curMonth)
                .replace(/{DD}/g, curDay)
                .replace(/{ROMAN}/g, curRoman)
                .replace(/{SEQ}/g, padded);

            preview.textContent = res;
        }

        [prefixInput, patternInput, digitsInput, seqInput].forEach(inp => {
            if (inp) inp.addEventListener('input', updateNumberPreview);
        });

        pills.forEach(pill => {
            pill.addEventListener('click', function(e) {
                e.preventDefault();
                patternInput.value = (patternInput.value || '') + this.getAttribute('data-ins');
                updateNumberPreview();
            });
        });
    });

    // 3. SEARCH FILTER DOKUMEN & PENGGUNA
    const docSearch = document.getElementById('pk01_doc_search');
    if (docSearch) {
        docSearch.addEventListener('input', function() {
            const q = this.value.toLowerCase().trim();
            rows.forEach(r => {
                const label = r.getAttribute('data-label') || '';
                r.style.display = label.includes(q) ? '' : 'none';
            });
        });
    }

    const userSearch = document.getElementById('pk01-user-filter');
    const userTable = document.getElementById('pk01-user-tbl');
    if (userSearch && userTable) {
        userSearch.addEventListener('input', function() {
            const q = this.value.toLowerCase().trim();
            const uRows = userTable.querySelectorAll('tbody tr');
            uRows.forEach(r => {
                r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none';
            });
        });
    }

    // 4. WORDPRESS MEDIA UPLOADER (LOGO & CAP)
    function setupMediaUploader(btnId, removeBtnId, inputId, thumbImgId, placeholderId) {
        const btn = document.getElementById(btnId);
        const removeBtn = document.getElementById(removeBtnId);
        const input = document.getElementById(inputId);
        const thumb = document.getElementById(thumbImgId);
        const placeholder = document.getElementById(placeholderId);

        let uploader;
        if (btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                if (uploader) { uploader.open(); return; }
                uploader = wp.media({ title: 'Pilih File Gambar', button: { text: 'Gunakan Gambar' }, multiple: false, library: { type: 'image' } });
                uploader.on('select', function() {
                    const attachment = uploader.state().get('selection').first().toJSON();
                    input.value = attachment.url;
                    if (thumb) { thumb.src = attachment.url; thumb.style.display = 'block'; }
                    if (placeholder) placeholder.style.display = 'none';
                    if (removeBtn) removeBtn.style.display = 'inline-flex';
                });
                uploader.open();
            });
        }

        if (removeBtn) {
            removeBtn.addEventListener('click', function(e) {
                e.preventDefault();
                input.value = '';
                if (thumb) { thumb.src = ''; thumb.style.display = 'none'; }
                if (placeholder) placeholder.style.display = 'block';
                if (removeBtn) removeBtn.style.display = 'none';
            });
        }
    }
    setupMediaUploader('btn_upload_logo', 'btn_remove_logo', 'cfg_company_logo', 'logo_display_thumb', 'logo_placeholder_text');
    setupMediaUploader('btn_upload_stamp', 'btn_remove_stamp', 'cfg_company_stamp', 'stamp_display_thumb', 'stamp_placeholder_text');

});

function pk01LoadMarketplaceMap(key){document.querySelectorAll('.pk01-market-map-form').forEach(function(f){f.style.display=f.getAttribute('data-market')===key?'block':'none';});}
</script>
