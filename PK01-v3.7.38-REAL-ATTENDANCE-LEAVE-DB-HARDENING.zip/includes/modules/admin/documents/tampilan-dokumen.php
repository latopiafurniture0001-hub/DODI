<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin && (!is_user_logged_in() || !class_exists('PK01_Authorization') || !PK01_Authorization::can_action('documents', 'view'))) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:32px;margin-bottom:8px;">⛔</div>
            <strong style="font-size:16px;">Akses Ditolak</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin keamanan yang memadai untuk membuka pusat arsip dokumen.</p>
          </div>';
    return;
}

// 2. HELPER NAMA TABEL RESMI PK01
$T = function($k) use ($wpdb) {
    $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
    return ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) ? $t : false;
};

// 3. KUERI DATA REAL RIWAYAT TRANSAKSI DENGAN RELASI RAPI
$rows = [];
$tbl_emp = $T('employees');

// A. Penjualan / Invoice
$orders = $T('sales_orders') ?: $T('orders');
if ($orders) {
    $rows['penjualan'] = $wpdb->get_results(
        "SELECT id, COALESCE(NULLIF(invoice_no,''), order_no, CONCAT('INV-', id)) AS doc_no, 
                customer_name, total_amount, created_at, status 
         FROM `{$orders}` ORDER BY id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

// B. SPK Produksi
$jobs = $T('jobs') ?: $T('production_jobs');
if ($jobs) {
    $rows['produksi'] = $wpdb->get_results(
        "SELECT id, job_no, status, production_date, deadline, target_qty 
         FROM `{$jobs}` ORDER BY id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

// C. Upah Borongan / Job Wages
$wages = $T('job_wages');
if ($wages) {
    $emp_join = $tbl_emp ? "LEFT JOIN `{$tbl_emp}` e ON e.id = w.employee_id" : "";
    $emp_field = $tbl_emp ? "e.name AS employee_name, e.code AS employee_code," : "CONCAT('Staf #', w.employee_id) AS employee_name, '' AS employee_code,";
    $rows['upah'] = $wpdb->get_results(
        "SELECT w.id, w.job_id, {$emp_field} w.job_detail, w.amount, w.status, w.period_key, w.paid_at 
         FROM `{$wages}` w {$emp_join} ORDER BY w.id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

// D. Slip Payroll
$payroll = $T('payroll');
if ($payroll) {
    $emp_join = $tbl_emp ? "LEFT JOIN `{$tbl_emp}` e ON e.id = p.employee_id" : "";
    $emp_field = $tbl_emp ? "e.name AS employee_name, e.code AS employee_code," : "CONCAT('Staf #', p.employee_id) AS employee_name, '' AS employee_code,";
    $rows['payroll'] = $wpdb->get_results(
        "SELECT p.id, {$emp_field} p.period, p.amount, p.status, p.paid_at, p.created_at 
         FROM `{$payroll}` p {$emp_join} ORDER BY p.id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

// E. Biaya Operasional
$costs = $T('operational_costs');
if ($costs) {
    $rows['biaya'] = $wpdb->get_results(
        "SELECT id, category, amount, cost_date, payment_method, description 
         FROM `{$costs}` ORDER BY id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

// F. Surat Jalan Pengiriman
$ship = $T('shipments');
if ($ship) {
    $rows['pengiriman'] = $wpdb->get_results(
        "SELECT id, tracking_no, courier, service, recipient_name, status, created_at 
         FROM `{$ship}` ORDER BY id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

// G. Penerimaan Barang — satu daftar nyata dari GR + dokumen supplier-in.
// Prioritas Goods Receipt karena itu sumber transaksi stok. Jika instalasi lama
// hanya memiliki warehouse_documents, data tetap terlihat dan dapat dicetak melalui
// adapter supplier-in tanpa membuat data dummy.
$receipts = $T('goods_receipts');
$warehouse_docs = $T('warehouse_documents');
$rows['penerimaan'] = [];
if ($receipts) {
    $rows['penerimaan'] = $wpdb->get_results(
        "SELECT gr.id, gr.receipt_no, gr.po_id, gr.qty, gr.received_at, gr.received_by,
                'goods_receipt' AS source_type, gr.id AS source_id, wd.doc_no AS warehouse_doc_no,
                po.po_no, s.name AS supplier_name, m.name AS material_name, m.unit AS material_unit
         FROM `{$receipts}` gr
         LEFT JOIN `{$T('purchase_orders')}` po ON po.id=gr.po_id
         LEFT JOIN `{$T('suppliers')}` s ON s.id=po.supplier_id
         LEFT JOIN `{$T('materials')}` m ON m.id=gr.material_id
         LEFT JOIN `{$warehouse_docs}` wd ON wd.reference_no=gr.receipt_no AND wd.doc_type='supplier_in'
         ORDER BY gr.id DESC LIMIT 100",
        ARRAY_A
    ) ?: [];
}
// Compatibility: data lama yang sudah membuat tanda terima Gudang tetapi
// belum mempunyai row goods_receipts tetap ditampilkan, namun ditandai sumbernya.
if ($warehouse_docs) {
    $legacy = $wpdb->get_results(
        "SELECT wd.id, wd.doc_no AS receipt_no, 0 AS po_id, 0 AS qty, wd.created_at AS received_at,
                wd.created_by AS received_by, 'warehouse_document' AS source_type, wd.id AS source_id,
                wd.doc_no AS warehouse_doc_no, '' AS po_no, wd.seller_name AS supplier_name, '' AS material_name, '' AS material_unit
         FROM `{$warehouse_docs}` wd
         LEFT JOIN `{$receipts}` gr ON gr.receipt_no=wd.reference_no
         WHERE wd.doc_type='supplier_in' AND gr.id IS NULL
         ORDER BY wd.id DESC LIMIT 100", ARRAY_A
    ) ?: [];
    if ($legacy) $rows['penerimaan'] = array_merge($rows['penerimaan'], $legacy);
}

// H. Profil Karyawan
if ($tbl_emp) {
    $rows['karyawan'] = $wpdb->get_results(
        "SELECT id, code, name, position, division, status 
         FROM `{$tbl_emp}` ORDER BY id DESC LIMIT 100", 
        ARRAY_A
    ) ?: [];
}

$finance_url = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('finance_reports')
    : add_query_arg('pk01_view', 'finance_reports', home_url('/'));

// Helper Generator URL Cetak PDF
$get_print_url = function($type, $id = 0, $args = []) {
    if (function_exists('pk01_print_url')) {
        return pk01_print_url($type, $id, $args);
    }
    return add_query_arg(array_merge(['pk01_print' => $type, 'doc_id' => $id], $args), home_url('/'));
};

// Hitung Total Seluruh Berkas Siap Cetak
$total_ready_docs = 0;
foreach ($rows as $item_group) {
    $total_ready_docs += count($item_group);
}

// Konfigurasi 8 Modul Dokumen
$sections = [
    'penjualan'  => ['label' => 'Faktur / Invoice',         'icon' => '🛒', 'print_type' => 'penjualan',          'tag' => 'Penjualan',  'desc' => 'Invoice resmi pesanan, bukti nota transaksi toko & website'],
    'produksi'   => ['label' => 'SPK Job Produksi',         'icon' => '🏭', 'print_type' => 'produksi',           'tag' => 'Produksi',   'desc' => 'Surat Perintah Kerja lantai produksi & perakitan barang'],
    'upah'       => ['label' => 'Voucher Upah Borongan',    'icon' => '💰', 'print_type' => 'upah-job',           'tag' => 'Upah',       'desc' => 'Kuitansi & tanda terima upah borongan pekerjaan staf'],
    'payroll'    => ['label' => 'Slip Gaji Payroll',        'icon' => '🧾', 'print_type' => 'slip-gaji',          'tag' => 'Payroll',    'desc' => 'Lembar rincian gaji pokok, tunjangan & potongan karyawan'],
    'biaya'      => ['label' => 'Bukti Pengeluaran Kas',    'icon' => '💸', 'print_type' => 'biaya-operasional',   'tag' => 'Keuangan',   'desc' => 'Voucher pengeluaran kas kecil & biaya belanja operasional'],
    'pengiriman' => ['label' => 'Surat Jalan / Manifest',   'icon' => '🚚', 'print_type' => 'pengiriman',          'tag' => 'Logistik',   'desc' => 'Surat jalan ekspedisi pengantaran paket & logistik armada'],
    'penerimaan' => ['label' => 'Bukti Penerimaan Barang',  'icon' => '📦', 'print_type' => 'penerimaan',          'tag' => 'Gudang',     'desc' => 'Berita acara penerimaan barang masuk dari vendor/supplier'],
    'karyawan'   => ['label' => 'Lembar Profil Staf',       'icon' => '👥', 'print_type' => 'karyawan',            'tag' => 'SDM',        'desc' => 'Formulir biodata lengkap, jabatan, dan jadwal shift staf'],
];
?>

<style>
:root {
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-blue:      #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
    --pk-card-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.07), 0 4px 6px -4px rgb(0 0 0 / 0.07);
}

.pk01-docs-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-docs-cockpit * { box-sizing: border-box; }

/* 1. Header Banner Glassmorphism */
.pk01-doc-hero {
    background: linear-gradient(135deg, #090d16 0%, #111827 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 28px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-counter-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 14px 22px;
    text-align: right;
    min-width: 170px;
    backdrop-filter: blur(8px);
}
.pk01-counter-widget span {
    display: block;
    font-size: 11px;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.pk01-counter-widget strong {
    display: block;
    font-size: 24px;
    font-weight: 800;
    color: #38bdf8;
    margin-top: 2px;
}

/* 2. Global Actions & Search Bar */
.pk01-doc-toolbar {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 16px 22px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: var(--pk-shadow);
}
.pk01-toolbar-group {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

/* Buttons */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 15px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: #334155 !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-pdf {
    background: #eff6ff;
    color: #2563eb !important;
    border: 1px solid #bfdbfe;
    padding: 5px 12px;
    font-size: 12px;
    font-weight: 700;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.pk01-btn-pdf:hover {
    background: #2563eb;
    color: #ffffff !important;
    border-color: #2563eb;
}

.pk01-search-box {
    position: relative;
    display: flex;
    align-items: center;
}
.pk01-search-input {
    padding: 9px 14px 9px 34px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    width: 290px;
    background: #f8fafc;
    transition: all 0.2s ease;
}
.pk01-search-input:focus {
    outline: none;
    border-color: var(--pk-indigo);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}
.pk01-search-icon {
    position: absolute;
    left: 11px;
    color: #94a3b8;
    pointer-events: none;
    font-size: 14px;
}

/* 3. Modern Scrollable Tabs */
.pk01-doc-tabs {
    display: flex;
    gap: 6px;
    border-bottom: 2px solid var(--pk-slate-200);
    margin-bottom: 22px;
    overflow-x: auto;
    padding-bottom: 2px;
}
.pk01-doc-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 16px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 8px 8px 0 0;
    transition: all 0.2s ease;
    white-space: nowrap;
    position: relative;
}
.pk01-doc-tab-btn:hover {
    color: var(--pk-indigo);
    background: #eef2ff;
}
.pk01-doc-tab-btn.is-active {
    color: var(--pk-indigo);
}
.pk01-doc-tab-btn.is-active::after {
    content: "";
    position: absolute;
    bottom: -4px;
    left: 0;
    right: 0;
    height: 3px;
    background: var(--pk-indigo);
    border-radius: 3px 3px 0 0;
}
.pk01-tab-badge {
    background: #e2e8f0;
    color: #475569;
    font-size: 11px;
    padding: 2px 7px;
    border-radius: 12px;
    font-weight: 700;
}
.pk01-doc-tab-btn.is-active .pk01-tab-badge {
    background: #e0e7ff;
    color: var(--pk-indigo);
}

/* 4. Document Surfaces & Data Tables */
.pk01-doc-pane { display: none; }
.pk01-doc-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(5px); }
    to { opacity: 1; transform: translateY(0); }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 22px 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 10px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-main-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-main-table th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-main-table td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
    color: #334155;
}
.pk01-main-table tr:hover td {
    background: #fbfcfe;
}
.pk01-main-table tr:last-child td {
    border-bottom: none;
}

/* Codes, Numbers, and Status Badges */
.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 7px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 12px;
}
.pk01-money {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    color: #047857;
    font-size: 13.5px;
}
.pk01-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: capitalize;
}
.badge-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.badge-warning { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.badge-danger  { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.badge-neutral { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }

.pk01-empty-state {
    text-align: center;
    padding: 44px 20px;
    color: #94a3b8;
}
.pk01-empty-icon {
    font-size: 38px;
    margin-bottom: 8px;
}
</style>

<div class="pk01-docs-cockpit">

    <!-- 1. HERO COCKPIT BANNER -->
    <header class="pk01-doc-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">ENTERPRISE DOCUMENT SUITE &bull; READ-ONLY ARCHIVE</span>
            <h1>📑 Pusat Berkas &amp; Cetak Ulang</h1>
            <p>
                Akses arsip dokumen legalitas usaha langsung dari basis data transaksi nyata. 
                Pencetakan ulang faktur, surat jalan, SPK produksi, voucher kas, atau slip gaji bersifat <strong>read-only</strong> dan aman tanpa memengaruhi jurnal pembukuan.
            </p>
        </div>
        <div class="pk01-counter-widget">
            <span>Total Berkas Terdaftar</span>
            <strong><?php echo number_format($total_ready_docs, 0, ',', '.'); ?> Arsip</strong>
        </div>
    </header>

    <!-- 2. GLOBAL ACTIONS TOOLBAR & LIVE SEARCH -->
    <div class="pk01-doc-toolbar">
        <div class="pk01-toolbar-group">
            <a class="pk01-btn pk01-btn-dark" target="_blank" href="<?php echo esc_url($get_print_url('keuangan', 0, ['from' => current_time('Y-m-01'), 'to' => current_time('Y-m-d')])); ?>">
                🖨️ Cetak Laba Rugi Periode
            </a>
            <a class="pk01-btn pk01-btn-subtle" target="_blank" href="<?php echo esc_url($get_print_url('general-ledger', 0, ['from' => current_time('Y-m-01'), 'to' => current_time('Y-m-d')])); ?>">
                📑 Cetak General Ledger (GL)
            </a>
            <a class="pk01-btn pk01-btn-subtle" href="<?php echo esc_url($finance_url); ?>">
                📊 Buka Dashboard Keuangan &rarr;
            </a>
        </div>

        <div class="pk01-search-box">
            <span class="pk01-search-icon">🔍</span>
            <input type="search" id="pk01_doc_live_search" class="pk01-search-input" placeholder="Cari no. dokumen, nama staf, status...">
        </div>
    </div>

    <!-- 3. TABS NAVIGASI 8 KATEGORI DOKUMEN -->
    <nav class="pk01-doc-tabs" aria-label="Kategori Dokumen">
        <?php 
        $tab_index = 0;
        foreach ($sections as $sec_key => $sec_cfg): 
            $count_sec = count($rows[$sec_key] ?? []);
            $is_active = ($tab_index === 0);
            $tab_index++;
        ?>
            <button type="button" class="pk01-doc-tab-btn <?php echo $is_active ? 'is-active' : ''; ?>" data-target="pane-<?php echo esc_attr($sec_key); ?>">
                <span><?php echo esc_html($sec_cfg['icon']); ?></span>
                <span><?php echo esc_html($sec_cfg['label']); ?></span>
                <span class="pk01-tab-badge"><?php echo number_format($count_sec); ?></span>
            </button>
        <?php endforeach; ?>
    </nav>

    <!-- 4. KONTEN MASING-MASING TAB DOKUMEN -->
    <main class="pk01-doc-panes">

        <!-- TAB 1: PENJUALAN / INVOICE -->
        <section class="pk01-doc-pane is-active" id="pane-penjualan">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>🛒 Faktur &amp; Invoice Penjualan</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['penjualan']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['penjualan'] ?? []); ?> Rekaman</span>
                </div>

                <?php if (empty($rows['penjualan'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada faktur penjualan yang tercatat di sistem.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>No. Invoice / Pesanan</th>
                                    <th>Nama Pelanggan</th>
                                    <th>Tanggal Transaksi</th>
                                    <th>Nilai Tagihan</th>
                                    <th>Status Pembayaran</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['penjualan'] as $r): 
                                    $st = strtolower($r['status'] ?? '');
                                    $badge = in_array($st, ['paid', 'lunas', 'completed'], true) ? 'badge-success' : (in_array($st, ['pending', 'waiting'], true) ? 'badge-warning' : 'badge-neutral');
                                ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['doc_no']); ?></span></td>
                                    <td><strong><?php echo esc_html($r['customer_name'] ?: 'Pelanggan Umum'); ?></strong></td>
                                    <td><?php echo esc_html($r['created_at'] ? date_i18n('d M Y, H:i', strtotime($r['created_at'])) : '-'); ?></td>
                                    <td><span class="pk01-money">Rp <?php echo number_format((float)$r['total_amount'], 0, ',', '.'); ?></span></td>
                                    <td><span class="pk01-badge <?php echo esc_attr($badge); ?>">● <?php echo esc_html(ucfirst($r['status'])); ?></span></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('penjualan', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 2: SPK PRODUKSI -->
        <section class="pk01-doc-pane" id="pane-produksi">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>🏭 Surat Perintah Kerja (SPK Produksi)</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['produksi']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['produksi'] ?? []); ?> SPK</span>
                </div>

                <?php if (empty($rows['produksi'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada SPK produksi tercatat.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>No. SPK Job</th>
                                    <th>Target Volume</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Batas Waktu (Deadline)</th>
                                    <th>Status Produksi</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['produksi'] as $r): 
                                    $st = strtolower($r['status'] ?? '');
                                    $badge = in_array($st, ['completed', 'selesai'], true) ? 'badge-success' : (in_array($st, ['progress', 'processing', 'berjalan'], true) ? 'badge-warning' : 'badge-neutral');
                                ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['job_no']); ?></span></td>
                                    <td><strong><?php echo number_format((float)($r['target_qty'] ?? 0)); ?> Unit</strong></td>
                                    <td><?php echo esc_html($r['production_date'] ? date_i18n('d M Y', strtotime($r['production_date'])) : '-'); ?></td>
                                    <td><?php echo esc_html($r['deadline'] ? date_i18n('d M Y', strtotime($r['deadline'])) : '-'); ?></td>
                                    <td><span class="pk01-badge <?php echo esc_attr($badge); ?>">● <?php echo esc_html(ucfirst($r['status'])); ?></span></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('produksi', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 3: VOUCHER UPAH BORONGAN -->
        <section class="pk01-doc-pane" id="pane-upah">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>💰 Voucher &amp; Tanda Terima Upah Borongan</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['upah']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['upah'] ?? []); ?> Voucher</span>
                </div>

                <?php if (empty($rows['upah'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada voucher upah borongan.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>Ref ID</th>
                                    <th>Nama Tenaga Kerja</th>
                                    <th>Rincian Pekerjaan / Job</th>
                                    <th>Nominal Upah</th>
                                    <th>Periode / Tgl Bayar</th>
                                    <th>Status Pembayaran</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['upah'] as $r): 
                                    $st = strtolower($r['status'] ?? '');
                                    $badge = in_array($st, ['paid', 'lunas'], true) ? 'badge-success' : 'badge-warning';
                                ?>
                                <tr>
                                    <td><span class="pk01-code-badge">WAG-#<?php echo esc_html($r['id']); ?></span></td>
                                    <td>
                                        <strong><?php echo esc_html($r['employee_name'] ?: 'Staf #'.$r['employee_id']); ?></strong>
                                        <?php if (!empty($r['employee_code'])): ?><div style="font-size:11px;color:#64748b;"><?php echo esc_html($r['employee_code']); ?></div><?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html($r['job_detail'] ?: 'Upah Borongan Job'); ?></td>
                                    <td><span class="pk01-money">Rp <?php echo number_format((float)$r['amount'], 0, ',', '.'); ?></span></td>
                                    <td><?php echo esc_html($r['period_key'] ?: ($r['paid_at'] ? date_i18n('d M Y', strtotime($r['paid_at'])) : '-')); ?></td>
                                    <td><span class="pk01-badge <?php echo esc_attr($badge); ?>">● <?php echo esc_html(ucfirst($r['status'])); ?></span></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('upah-job', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 4: SLIP GAJI PAYROLL -->
        <section class="pk01-doc-pane" id="pane-payroll">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>🧾 Slip Gaji Payroll Karyawan</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['payroll']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['payroll'] ?? []); ?> Slip</span>
                </div>

                <?php if (empty($rows['payroll'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada data slip payroll yang diterbitkan.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>Karyawan</th>
                                    <th>Periode Penggajian</th>
                                    <th>Total Gaji Bersih</th>
                                    <th>Tanggal Pembayaran</th>
                                    <th>Status</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['payroll'] as $r): 
                                    $st = strtolower($r['status'] ?? '');
                                    $badge = in_array($st, ['paid', 'lunas'], true) ? 'badge-success' : 'badge-warning';
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($r['employee_name'] ?: 'Staf #'.$r['employee_id']); ?></strong>
                                        <?php if (!empty($r['employee_code'])): ?><div style="font-size:11px;color:#64748b;"><?php echo esc_html($r['employee_code']); ?></div><?php endif; ?>
                                    </td>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['period']); ?></span></td>
                                    <td><span class="pk01-money">Rp <?php echo number_format((float)$r['amount'], 0, ',', '.'); ?></span></td>
                                    <td><?php echo esc_html($r['paid_at'] ? date_i18n('d M Y', strtotime($r['paid_at'])) : ($r['created_at'] ? date_i18n('d M Y', strtotime($r['created_at'])) : '-')); ?></td>
                                    <td><span class="pk01-badge <?php echo esc_attr($badge); ?>">● <?php echo esc_html(ucfirst($r['status'])); ?></span></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('slip-gaji', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 5: BIAYA OPERASIONAL -->
        <section class="pk01-doc-pane" id="pane-biaya">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>💸 Bukti Pengeluaran Kas Operasional</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['biaya']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['biaya'] ?? []); ?> Bukti</span>
                </div>

                <?php if (empty($rows['biaya'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada bukti kas operasional tercatat.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>Kategori Biaya</th>
                                    <th>Keterangan / Keperluan</th>
                                    <th>Tanggal Kas</th>
                                    <th>Metode Bayar</th>
                                    <th>Jumlah Pengeluaran</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['biaya'] as $r): ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['category'] ?: 'Umum'); ?></span></td>
                                    <td><?php echo esc_html($r['description'] ?: '-'); ?></td>
                                    <td><?php echo esc_html($r['cost_date'] ? date_i18n('d M Y', strtotime($r['cost_date'])) : '-'); ?></td>
                                    <td><span class="pk01-badge badge-neutral"><?php echo esc_html(strtoupper($r['payment_method'] ?: 'KAS')); ?></span></td>
                                    <td><span class="pk01-money" style="color:#b91c1c;">Rp <?php echo number_format((float)$r['amount'], 0, ',', '.'); ?></span></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('biaya-operasional', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 6: SURAT JALAN PENGIRIMAN -->
        <section class="pk01-doc-pane" id="pane-pengiriman">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>🚚 Surat Jalan &amp; Manifest Pengiriman</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['pengiriman']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['pengiriman'] ?? []); ?> Kiriman</span>
                </div>

                <?php if (empty($rows['pengiriman'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada surat jalan pengiriman tercatat.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>No. Resi / AWB</th>
                                    <th>Kurir &amp; Layanan</th>
                                    <th>Penerima Tujuan</th>
                                    <th>Waktu Pembuatan</th>
                                    <th>Status Pengantaran</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['pengiriman'] as $r): 
                                    $st = strtolower($r['status'] ?? '');
                                    $badge = in_array($st, ['delivered', 'selesai', 'sampai'], true) ? 'badge-success' : (in_array($st, ['shipping', 'transit', 'dikirim'], true) ? 'badge-warning' : 'badge-neutral');
                                ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['tracking_no'] ?: 'AWB-#'.$r['id']); ?></span></td>
                                    <td><strong><?php echo esc_html(strtoupper($r['courier'] ?: 'Armada Internal')); ?></strong> <span style="font-size:11px;color:#64748b;">(<?php echo esc_html($r['service'] ?: 'Standar'); ?>)</span></td>
                                    <td><?php echo esc_html($r['recipient_name'] ?: '-'); ?></td>
                                    <td><?php echo esc_html($r['created_at'] ? date_i18n('d M Y, H:i', strtotime($r['created_at'])) : '-'); ?></td>
                                    <td><span class="pk01-badge <?php echo esc_attr($badge); ?>">● <?php echo esc_html(ucfirst($r['status'])); ?></span></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('pengiriman', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 7: BUKTI PENERIMAAN BARANG -->
        <section class="pk01-doc-pane" id="pane-penerimaan">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>📦 Tanda Terima &amp; Good Receipt Gudang</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['penerimaan']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['penerimaan'] ?? []); ?> Berkas</span>
                </div>

                <?php if (empty($rows['penerimaan'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada tanda terima barang masuk.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>No. Bukti Terima</th>
                                    <th>Ref. PO Pembelian</th>
                                    <th>Kuantitas Diterima</th>
                                    <th>Waktu Penerimaan</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['penerimaan'] as $r): ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['receipt_no'] ?: '-'); ?></span></td>
                                    <td><?php echo !empty($r['po_no']) ? '<span class="pk01-code-badge">' . esc_html($r['po_no']) . '</span>' : '<span style="color:#94a3b8;">Non-PO</span>'; ?></td>
                                    <td><strong><?php echo $r['source_type']==='warehouse_document' ? '—' : number_format((float)($r['qty'] ?? 0)); ?> <?php echo $r['source_type']==='warehouse_document' ? '' : 'Item'; ?></strong></td>
                                    <td><?php echo esc_html($r['received_at'] ? date_i18n('d M Y, H:i', strtotime($r['received_at'])) : '-'); ?></td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" rel="noopener" href="<?php echo esc_url($get_print_url($r['source_type']==='warehouse_document' ? 'penerimaan-supplier' : 'penerimaan', (int)$r['source_id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- TAB 8: DATA PROFIL KARYAWAN -->
        <section class="pk01-doc-pane" id="pane-karyawan">
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>👥 Lembar Biodata &amp; Profil Karyawan</h3>
                        <div class="pk01-surface-desc"><?php echo esc_html($sections['karyawan']['desc']); ?></div>
                    </div>
                    <span class="pk01-tab-badge" style="font-size:12px; padding:4px 10px;"><?php echo count($rows['karyawan'] ?? []); ?> Staf</span>
                </div>

                <?php if (empty($rows['karyawan'])): ?>
                    <div class="pk01-empty-state"><div class="pk01-empty-icon">📁</div>Belum ada profil staf terdaftar.</div>
                <?php else: ?>
                    <div class="pk01-table-wrap">
                        <table class="pk01-main-table doc-searchable-table">
                            <thead>
                                <tr>
                                    <th>Kode Staf</th>
                                    <th>Nama Lengkap</th>
                                    <th>Jabatan / Posisi</th>
                                    <th>Divisi / Departemen</th>
                                    <th>Status Kerja</th>
                                    <th style="text-align:center; width:110px;">Cetak Berkas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows['karyawan'] as $r): 
                                    $is_act = (($r['status'] ?? '') === 'active');
                                ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($r['code']); ?></span></td>
                                    <td><strong><?php echo esc_html($r['name']); ?></strong></td>
                                    <td><?php echo esc_html($r['position'] ?: '—'); ?></td>
                                    <td><?php echo esc_html($r['division'] ?: 'Umum'); ?></td>
                                    <td>
                                        <span class="pk01-badge <?php echo $is_act ? 'badge-success' : 'badge-danger'; ?>">
                                            ● <?php echo $is_act ? 'Aktif' : 'Nonaktif'; ?>
                                        </span>
                                    </td>
                                    <td style="text-align:center;">
                                        <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($get_print_url('karyawan', (int)$r['id'])); ?>">
                                            🖨️ PDF
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

    </main>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH URL
    var tabBtns = document.querySelectorAll('.pk01-doc-tab-btn');
    var panes   = document.querySelectorAll('.pk01-doc-pane');

    function activateTab(targetId) {
        if (!targetId) return;
        var btn = document.querySelector('.pk01-doc-tab-btn[data-target="' + targetId + '"]');
        var pane = document.getElementById(targetId);

        if (btn && pane) {
            tabBtns.forEach(function(b) { b.classList.remove('is-active'); });
            panes.forEach(function(p) { p.classList.remove('is-active'); });

            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var targetId = this.getAttribute('data-target');
            activateTab(targetId);
            // Simpan ke URL hash tanpa reload halaman
            if (history.replaceState) {
                history.replaceState(null, null, '#' + targetId.replace('pane-', ''));
            }
        });
    });

    // Cek jika ada hash saat dimuat pertama kali
    var initialHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (initialHash) {
        activateTab('pane-' + initialHash);
    }

    // 2. LIVE SEARCH INSTAN & PENGHITUNG HASIL
    var searchInput = document.getElementById('pk01_doc_live_search');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            var activePane = document.querySelector('.pk01-doc-pane.is-active');
            if (!activePane) return;

            var rows = activePane.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                var text = row.innerText.toLowerCase();
                row.style.display = (text.indexOf(filter) > -1) ? '' : 'none';
            });
        });
    }
});
</script>