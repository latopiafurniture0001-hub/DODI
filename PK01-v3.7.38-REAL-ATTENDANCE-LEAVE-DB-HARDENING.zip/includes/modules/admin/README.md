# PK01 — Modul Admin

Folder canonical: `includes/modules/admin/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/admin/activity/tampilan-aktivitas.php`
- `includes/modules/admin/administration/tampilan-administrasi.php`
- `includes/modules/admin/core/class-pk01-admin.php`
- `includes/modules/admin/dashboard-role/tampilan-dashboard-role.php`
- `includes/modules/admin/documents/tampilan-dokumen.php`
- `includes/modules/admin/master-data/tampilan-master-data.php`
- `includes/modules/admin/settings/tampilan-pengaturan.php`
- `includes/modules/admin/users/tampilan-pengguna.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
