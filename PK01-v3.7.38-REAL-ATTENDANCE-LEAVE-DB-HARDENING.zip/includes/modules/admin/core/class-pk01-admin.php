<?php
if (!defined('ABSPATH')) exit;

class PK01_Admin {

    /**
     * Inisialisasi Hook & Aksi Admin
     */
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'redirect_legacy_admin']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'css']);
        add_action('admin_bar_menu', [__CLASS__, 'admin_bar_quick_launcher'], 90);

        // Handler Aksi Admin Post
        add_action('admin_post_pk01_save_ai', [__CLASS__, 'save_ai']);
        add_action('admin_post_pk01_ai_orchestrator_save', [__CLASS__, 'save_ai_orchestrator']);
        add_action('admin_post_pk01_backup_download', [__CLASS__, 'backup_download']);
        add_action('admin_post_pk01_backup_restore', [__CLASS__, 'backup_restore']);
        add_action('admin_post_pk01_product_save', [__CLASS__, 'product_save']);
        add_action('admin_post_pk01_seller_save', [__CLASS__, 'seller_save']);
        add_action('admin_post_pk01_seller_order', [__CLASS__, 'seller_order']);
        add_action('admin_post_pk01_seller_fulfill', [__CLASS__, 'seller_fulfill']);
        add_action('admin_post_pk01_seller_pay', [__CLASS__, 'seller_pay']);
    }

    /**
     * PK01 sengaja tidak membuat submenu di sidebar WP Admin
     * Seluruh operasional dan transaksi dipusatkan di Dashboard Frontend Modern.
     */
    public static function menu() {
        // Seluruh operasional PK01 dipusatkan di dashboard frontend.
    }

    /**
     * Helper Deteksi URL Frontend Dashboard Bebas 404 (Saling Bersalaman)
     */
    public static function get_frontend_url($view = 'dashboard') {
        global $wpdb;

        // Normalisasi alias view
        if ($view === 'seller') $view = 'sellers';
        if ($view === 'employee') $view = 'employees';
        if ($view === 'cost') $view = 'operational_costs';

        // 1. Coba melalui fungsi bawaan shortcode PK01 jika ada
        if (class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')) {
            $u = PK01_Shortcodes::frontend_url_public($view);
            if (!empty($u)) return $u;
        }
        if (class_exists('PK01_DB') && method_exists('PK01_DB', 'ensure_pages')) {
            $id = (int)PK01_DB::ensure_pages();
            if ($id && get_post_status($id) === 'publish') {
                return add_query_arg('pk01_view', $view, get_permalink($id));
            }
        }

        // 2. Cari halaman WordPress nyata yang berisi shortcode [pk01_operasional]
        $page_id = $wpdb->get_var("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type = 'page' AND post_content LIKE '%[pk01_operasional%' LIMIT 1");
        if ($page_id) {
            return add_query_arg('pk01_view', $view, get_permalink($page_id));
        }

        // 3. Fallback ke URL standar
        return add_query_arg('pk01_view', $view, home_url('/dashboard-operasional/'));
    }

    /**
     * Pintasan Cepat di Bilah Atas WP Admin (Top Bar Menu)
     */
    public static function admin_bar_quick_launcher($wp_admin_bar) {
        if (!current_user_can('manage_options')) return;

        $root_url = self::get_frontend_url('dashboard');

        // Menu Utama
        $wp_admin_bar->add_node([
            'id'    => 'pk01_launcher',
            'title' => '⚡ <span class="ab-label" style="font-weight:700;">PK01 Operasional</span>',
            'href'  => $root_url,
            'meta'  => ['target' => '_blank', 'title' => 'Buka Dashboard PK01']
        ]);

        // Submenu Navigasi Cepat
        $submenus = [
            'pk01_bar_dash'       => ['📊 Dashboard Utama', 'dashboard'],
            'pk01_bar_sales'      => ['🛍️ Kasir & Penjualan', 'sales'],
            'pk01_bar_materials'  => ['🪵 Bahan Baku & Gudang', 'materials'],
            'pk01_bar_costs'      => ['💸 Biaya Usaha Operasional', 'operational_costs'],
            'pk01_bar_cash'       => ['💵 Buku Kas Perusahaan', 'cash'],
            'pk01_bar_sellers'    => ['🤝 Mitra Seller & Afiliasi', 'sellers'],
            'pk01_bar_employees'  => ['👥 Karyawan & Upah', 'employees'],
            'pk01_bar_shipments'  => ['🚚 Pengiriman & Resi', 'shipments'],
            'pk01_bar_marketplace'=> ['🛒 Rekonsiliasi Marketplace', 'marketplace'],
            'pk01_bar_finance'    => ['📈 Laporan Laba Rugi Riil', 'finance'],
            'pk01_bar_settings'   => ['⚙️ Pengaturan Sentral & Kop', 'settings'],
        ];

        foreach ($submenus as $node_id => $item) {
            $wp_admin_bar->add_node([
                'parent' => 'pk01_launcher',
                'id'     => $node_id,
                'title'  => $item[0],
                'href'   => self::get_frontend_url($item[1]),
                'meta'   => ['target' => '_blank']
            ]);
        }
    }

    /**
     * Redirect Cerdas Link Lama WP Admin ke Tampilan Modul Frontend yang Sesuai
     */
    public static function redirect_legacy_admin() {
        if (!is_admin() || !current_user_can('manage_options')) return;

        $page = sanitize_key($_GET['page'] ?? '');
        if (!$page || strpos($page, 'pk01') !== 0) return;

        // Peta pengalihan modul spesifik (Bukan semuanya dilempar ke system)
        $route_map = [
            'pk01'              => 'dashboard',
            'pk01-dashboard'    => 'dashboard',
            'pk01-products'     => 'products',
            'pk01-stock'        => 'materials',
            'pk01-materials'    => 'materials',
            'pk01-purchase'     => 'materials',
            'pk01-sales'        => 'sales',
            'pk01-seller'       => 'sellers',
            'pk01-sellers'      => 'sellers',
            'pk01-employees'    => 'employees',
            'pk01-suppliers'    => 'suppliers',
            'pk01-ops'          => 'operational_costs',
            'pk01-cash'         => 'cash',
            'pk01-pricing'      => 'pricing',
            'pk01-shipments'    => 'shipments',
            'pk01-marketplace'  => 'marketplace',
            'pk01-finance'      => 'finance',
            'pk01-ai'           => 'ai',
            'pk01-settings'     => 'settings',
            'pk01-logs'         => 'logs',
            'pk01-system'       => 'system',
        ];

        $target_view = $route_map[$page] ?? 'dashboard';
        wp_safe_redirect(self::get_frontend_url($target_view));
        exit;
    }

    /**
     * Assets Stylesheet & Scripts Admin
     */
    public static function css($hook) {
        if (strpos($hook, 'pk01') !== false) {
            if (defined('PK01_URL') && defined('PK01_VERSION')) {
                wp_enqueue_style('pk01', PK01_URL . 'assets/admin.css', [], PK01_VERSION);
            }
            wp_enqueue_media();
            wp_enqueue_script('jquery');
        }
    }

    // =========================================================================
    // HANDLER AKSI SIMPAN DENGAN JABAT TANGAN DATABASE
    // =========================================================================

    /**
     * Simpan Produk & Varian Baru
     */
    public static function product_save() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_product_save');

        global $wpdb;
        $now = current_time('mysql');

        $code = sanitize_text_field($_POST['code'] ?? '');
        $name = sanitize_text_field($_POST['name'] ?? '');
        $sku  = sanitize_text_field($_POST['sku'] ?? '');

        if (!$code || !$name || !$sku) {
            wp_die('Kode Produk, Nama, dan SKU Varian wajib diisi.');
        }

        $tbl_products = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('products') : $wpdb->prefix . 'pk01_products';
        $tbl_variants = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_variants') : $wpdb->prefix . 'pk01_product_variants';
        $tbl_logs     = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('activity_logs') : $wpdb->prefix . 'pk01_activity_logs';

        $slug  = sanitize_title($_POST['slug'] ?? $name);
        $desc  = wp_kses_post($_POST['description'] ?? '');
        $img   = absint($_POST['image_id'] ?? 0);
        $hpp   = (float) sanitize_text_field($_POST['hpp'] ?? 0);
        $price = (float) sanitize_text_field($_POST['price'] ?? ($hpp * 1.3));

        // Insert Produk Induk
        $wpdb->insert($tbl_products, [
            'code'        => $code,
            'name'        => $name,
            'slug'        => $slug,
            'description' => $desc,
            'image_id'    => $img,
            'status'      => 'active',
            'created_at'  => $now,
            'updated_at'  => $now
        ]);

        $pid = (int) $wpdb->insert_id;
        if (!$pid) {
            wp_die('Gagal menyimpan produk. Kode produk kemungkinan sudah pernah digunakan.');
        }

        // Insert Varian SKU
        $wpdb->insert($tbl_variants, [
            'product_id' => $pid,
            'sku'        => $sku,
            'name'       => sanitize_text_field($_POST['variant_name'] ?? $name),
            'size'       => sanitize_text_field($_POST['size'] ?? ''),
            'material'   => sanitize_text_field($_POST['material'] ?? ''),
            'finishing'  => sanitize_text_field($_POST['finishing'] ?? ''),
            'hpp'        => $hpp,
            'price'      => $price,
            'status'     => 'active',
            'created_at' => $now,
            'updated_at' => $now
        ]);

        // Jabat Tangan ke Audit Log
        if ($tbl_logs && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
            $wpdb->insert($tbl_logs, [
                'user_id'     => get_current_user_id(),
                'action'      => 'product_created',
                'module'      => 'products',
                'entity'      => $code . ' - ' . $sku,
                'description' => "Menambahkan produk baru {$name} [SKU: {$sku}] HPP Rp " . number_format($hpp, 0, ',', '.'),
                'created_at'  => $now
            ]);
        }

        wp_safe_redirect(self::get_frontend_url('products'));
        exit;
    }

    /**
     * Simpan Master Seller
     */
    public static function seller_save() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_seller_save');

        try {
            $name       = sanitize_text_field($_POST['name'] ?? '');
            $code       = sanitize_text_field($_POST['code'] ?? '');
            $phone      = sanitize_text_field($_POST['phone'] ?? '');
            $email      = sanitize_email($_POST['email'] ?? '');
            $commission = (float) ($_POST['commission'] ?? 0);
            $affiliate  = (float) ($_POST['affiliate'] ?? 0);

            if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_create')) {
                PK01_Engine::seller_create($name, $code, $phone, $email, $commission, $affiliate);
            }
        } catch (Throwable $e) {
            wp_die(esc_html($e->getMessage()));
        }

        wp_safe_redirect(self::get_frontend_url('sellers'));
        exit;
    }

    /**
     * Buat Permintaan Barang Seller
     */
    public static function seller_order() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_seller_order');

        try {
            $seller_id  = absint($_POST['seller_id'] ?? 0);
            $variant_id = absint($_POST['variant_id'] ?? 0);
            $qty        = (float) ($_POST['qty'] ?? 1);

            if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_create_order')) {
                PK01_Engine::seller_create_order($seller_id, $variant_id, $qty);
            }
        } catch (Throwable $e) {
            wp_die(esc_html($e->getMessage()));
        }

        wp_safe_redirect(self::get_frontend_url('sellers'));
        exit;
    }

    /**
     * Serah Terima Barang Seller
     */
    public static function seller_fulfill() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_seller_fulfill');

        try {
            $order_id = absint($_POST['order_id'] ?? 0);
            if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_fulfill_order')) {
                PK01_Engine::seller_fulfill_order($order_id);
            }
        } catch (Throwable $e) {
            wp_die(esc_html($e->getMessage()));
        }

        wp_safe_redirect(self::get_frontend_url('sellers'));
        exit;
    }

    /**
     * Catat Pembayaran Invoice Seller
     */
    public static function seller_pay() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_seller_pay');

        try {
            $invoice_id = absint($_POST['invoice_id'] ?? 0);
            $amount     = (float) ($_POST['amount'] ?? 0);

            if ($invoice_id <= 0 || $amount <= 0) throw new Exception('Invoice dan nominal wajib valid.');
            throw new Exception('Entry pembayaran Seller langsung dari endpoint lama dinonaktifkan. Gunakan Setoran Kasir → Persetujuan Keuangan agar AR dan kas hanya berubah satu kali.');
        } catch (Throwable $e) {
            wp_die(esc_html($e->getMessage()));
        }

        wp_safe_redirect(self::get_frontend_url('sellers'));
        exit;
    }

    public static function save_ai_orchestrator() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_ai_orchestrator_save');
        $old=class_exists('PK01_AI_Orchestrator')?PK01_AI_Orchestrator::status():[];
        $submitted=(array)($_POST['providers']??[]); $providers=[];
        foreach(($old['providers']??[]) as $p){
            $id=sanitize_key($p['id']); $row=$p; $in=(array)($submitted[$id]??[]);
            $row['name']=sanitize_text_field($in['name']??$p['name']); $row['endpoint']=esc_url_raw($in['endpoint']??$p['endpoint']); $row['model']=sanitize_text_field($in['model']??$p['model']);
            $row['token']=sanitize_text_field($in['token']??''); $row['priority']=max(1,(int)($in['priority']??$p['priority'])); $row['enabled']=empty($in['enabled'])?0:1;
            $row['type']=$p['type']; $row['local']=$p['local']; $providers[]=$row;
        }
        if(class_exists('PK01_AI_Orchestrator')) PK01_AI_Orchestrator::save_config(['enabled'=>1,'offline_fallback'=>1,'active_provider'=>'auto','providers'=>$providers]);
        wp_safe_redirect(PK01_Admin::get_frontend_url('ai_center')); exit;
    }

    /**
     * Simpan Konfigurasi AI Assistant
     */
    public static function save_ai() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_ai_save');

        $o = class_exists('PK01_AI') ? PK01_AI::settings() : [];
        $n = $o;

        foreach (['provider', 'model', 'endpoint'] as $k) {
            $n[$k] = sanitize_text_field($_POST[$k] ?? '');
        }
        if (!empty($_POST['api_key'])) {
            $n['api_key'] = sanitize_text_field($_POST['api_key']);
        }
        $n['ai_enabled']     = !empty($_POST['ai_enabled']) ? 1 : 0;
        $n['default_profit'] = isset($_POST['default_profit']) ? (float)$_POST['default_profit'] : ($o['default_profit'] ?? 30);

        if (class_exists('PK01_Settings') && method_exists('PK01_Settings', 'update_group')) {
            PK01_Settings::update_group('ai', $n);
        } else {
            update_option('pk01_settings', $n);
        }

        wp_safe_redirect(self::get_frontend_url('ai'));
        exit;
    }

    /**
     * Download Backup Database PK01
     */
    public static function backup_download() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_backup_download');

        if (!class_exists('PK01_Backup')) {
            wp_die('Engine backup PK01 tidak ditemukan.');
        }

        $r = PK01_Backup::generate();
        if (is_wp_error($r)) {
            wp_die(esc_html($r->get_error_message()));
        }

        nocache_headers();
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($r['filename']) . '"');
        header('Content-Length: ' . (int)$r['size']);
        readfile($r['path']);
        if (empty($r['persistent'])) {
            @unlink($r['path']);
        }
        exit;
    }

    /**
     * Restore Backup Database PK01
     */
    public static function backup_restore() {
        if (!current_user_can('manage_options')) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_backup_restore');

        if (empty($_FILES['pk01_backup']['tmp_name'])) {
            wp_die('File cadangan ZIP belum dipilih.');
        }

        $f = $_FILES['pk01_backup'];
        if (!empty($f['error'])) {
            wp_die('Gagal mengunggah file cadangan.');
        }

        $name = sanitize_file_name($f['name']);
        if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'zip') {
            wp_die('Format file restore harus berekstensi .ZIP resmi PK01.');
        }

        if (!class_exists('PK01_Backup')) {
            wp_die('Engine backup PK01 tidak aktif.');
        }

        $r = PK01_Backup::restore($f['tmp_name']);
        if (is_wp_error($r)) {
            wp_die(esc_html($r->get_error_message()));
        }

        wp_safe_redirect(self::get_frontend_url('settings'));
        exit;
    }
}