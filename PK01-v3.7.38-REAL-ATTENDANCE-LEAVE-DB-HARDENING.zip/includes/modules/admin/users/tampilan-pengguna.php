<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;">Akses Dibatasi</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Menu Manajemen Pengguna &amp; Audit Trail hanya dapat dikelola oleh Administrator sistem.</p>
          </div>';
    return;
}

// 2. DETEKSI TABEL LOG AKTIVITAS & KOLOM WAKTU
$log_table = class_exists('PK01_Audit') && method_exists('PK01_Audit', 'table') 
    ? PK01_Audit::table() 
    : (class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('activity_logs') : $wpdb->prefix . 'pk01_activity_logs');

$has_log_table = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $log_table)) === $log_table);

$col_time = 'timestamp';
if ($has_log_table) {
    $has_created_at = $wpdb->get_results("SHOW COLUMNS FROM `{$log_table}` LIKE 'created_at'");
    if (!empty($has_created_at)) {
        $col_time = 'created_at';
    }
}

// 3. LOGIKA EKSPOR AUDIT TRAIL KE CSV (COMPLIANCE EXPORT)
if (isset($_POST['pk01_export_user_logs_csv']) && check_admin_referer('pk01_export_user_logs_nonce')) {
    if ($has_log_table) {
        $days_exp = absint($_POST['exp_days'] ?? 30);
        $user_exp = absint($_POST['exp_user'] ?? 0);
        $lvl_exp  = sanitize_key($_POST['exp_level'] ?? '');
        $since_exp = date('Y-m-d H:i:s', current_time('timestamp') - ($days_exp * DAY_IN_SECONDS));

        $where_exp = "`{$col_time}` >= %s";
        $params_exp = [$since_exp];
        if ($user_exp > 0) {
            $where_exp .= " AND user_id = %d";
            $params_exp[] = $user_exp;
        }
        if (!empty($lvl_exp)) {
            $where_exp .= " AND level = %s";
            $params_exp[] = $lvl_exp;
        }

        $export_logs = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM `{$log_table}` WHERE {$where_exp} ORDER BY id DESC LIMIT 5000", $params_exp),
            ARRAY_A
        );

        if (!empty($export_logs)) {
            $filename = 'pk01-audit-trail-' . current_time('Y-m-d-His') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID', 'Waktu', 'User ID', 'Nama Pengguna', 'Peran/Role', 'Modul', 'Aktivitas', 'Entitas Objek', 'Tingkat Severity']);
            foreach ($export_logs as $l) {
                fputcsv($out, [
                    $l['id'] ?? '-',
                    $l[$col_time] ?? '-',
                    $l['user_id'] ?? 0,
                    $l['user_name'] ?? 'Sistem',
                    $l['user_role'] ?? '-',
                    $l['module'] ?? '-',
                    $l['action'] ?? '-',
                    $l['entity'] ?? '-',
                    strtoupper($l['level'] ?? 'INFO')
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. DATA PENGGUNA & PARAMETER FILTER
$users = get_users([
    'orderby' => 'display_name',
    'order'   => 'ASC',
    'fields'  => ['ID', 'display_name', 'user_login', 'user_email', 'roles']
]);

$selected_user  = absint($_GET['pk01_log_user'] ?? 0);
$selected_level = sanitize_key($_GET['pk01_log_level'] ?? '');
$days           = absint($_GET['pk01_log_days'] ?? 30);
if (!in_array($days, [7, 30, 90, 180], true)) $days = 30;

// Pemetaan Role & Hitung Penggunaan
$role_labels = [];
$role_usage_counts = [];
foreach ((array)wp_roles()->roles as $rid => $rr) {
    $role_labels[$rid] = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'role_label')
        ? PK01_Engine::role_label($rid) 
        : translate_user_role($rr['name']);
}

foreach ($users as $u_item) {
    $primary_r = !empty($u_item->roles) ? $u_item->roles[0] : 'subscriber';
    $role_usage_counts[$primary_r] = ($role_usage_counts[$primary_r] ?? 0) + 1;
}

$total_users  = count($users);
$active_today = 0;
$sec_warnings = 0;
$now_time     = current_time('mysql');
$since_time   = date('Y-m-d H:i:s', current_time('timestamp') - ($days * DAY_IN_SECONDS));

$rows   = [];
$counts = [];

if ($has_log_table) {
    // Kueri Log Terfilter
    $where_parts = ["`{$col_time}` >= %s"];
    $params = [$since_time];
    
    if ($selected_user > 0) { 
        $where_parts[] = "user_id = %d"; 
        $params[] = $selected_user; 
    }
    if (!empty($selected_level)) {
        $where_parts[] = "level = %s";
        $params[] = $selected_level;
    }
    
    $where_sql = implode(' AND ', $where_parts);
    $rows = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM `{$log_table}` WHERE {$where_sql} ORDER BY id DESC LIMIT 250", $params), 
        ARRAY_A
    ) ?: [];

    // Pengguna Aktif Hari Ini
    $active_today = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT user_id) FROM `{$log_table}` 
         WHERE `{$col_time}` >= %s AND `{$col_time}` <= %s AND user_id > 0", 
        current_time('Y-m-d') . ' 00:00:00', 
        $now_time
    ));

    // Hitung Jumlah Log Security/Warning
    $sec_warnings = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `{$log_table}` 
         WHERE `{$col_time}` >= %s AND level IN ('warning', 'security', 'error')", 
        $since_time
    ));

    // Hitung Aktivitas per User
    $count_rows = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, COUNT(*) as total FROM `{$log_table}` 
         WHERE `{$col_time}` >= %s AND user_id > 0 GROUP BY user_id", 
        $since_time
    ), ARRAY_A) ?: [];

    foreach ($count_rows as $cr) {
        $counts[(int)$cr['user_id']] = (int)$cr['total'];
    }
}

// Warna Role Badge Modern
$get_role_badge_style = function($role) {
    switch ($role) {
        case 'administrator':
        case 'pk01_admin':
            return 'background:#faf5ff; color:#6b21a8; border:1px solid #e9d5ff;';
        case 'pk01_keuangan':
            return 'background:#ecfdf5; color:#065f46; border:1px solid #a7f3d0;';
        case 'pk01_produksi':
            return 'background:#fffbeb; color:#92400e; border:1px solid #fde68a;';
        case 'pk01_logistik':
            return 'background:#f0f9ff; color:#0369a1; border:1px solid #bae6fd;';
        case 'pk01_hr':
            return 'background:#fff1f2; color:#be123c; border:1px solid #fecdd3;';
        default:
            return 'background:#f1f5f9; color:#475569; border:1px solid #e2e8f0;';
    }
};
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-purple:    #8b5cf6;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-usr-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-usr-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Glassmorphism */
.pk01-usr-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-sec-indicator {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive KPI Deck */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-green::before  { background: var(--pk-emerald); }
.pk01-kpi-card.c-purple::before { background: var(--pk-purple); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-amber); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 26px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; }
.pk01-kpi-sub { font-size: 12px; color: var(--pk-slate-600); }

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surface Cards */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* User Directory List */
.pk01-user-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-height: 540px;
    overflow-y: auto;
}
.pk01-user-card-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 18px;
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    gap: 16px;
    transition: all 0.15s ease;
}
.pk01-user-card-item:hover {
    background: #fbfcfe;
    border-color: #cbd5e1;
    box-shadow: 0 4px 8px -2px rgba(0, 0, 0, 0.04);
}
.pk01-user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: linear-gradient(135deg, #4f46e5, #7c3aed);
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: 800;
    flex-shrink: 0;
}
.pk01-user-details {
    flex: 2;
    min-width: 190px;
}
.pk01-user-details strong {
    font-size: 13.5px;
    color: var(--pk-slate-900);
    display: block;
}
.pk01-user-details span {
    font-size: 11.5px;
    color: var(--pk-slate-600);
}
.pk01-role-badge {
    display: inline-block;
    padding: 3px 9px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-user-stat {
    text-align: right;
    min-width: 120px;
}
.pk01-user-stat strong {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 14px;
    color: var(--pk-slate-900);
    display: block;
}
.pk01-user-stat span {
    font-size: 11px;
    color: var(--pk-slate-600);
}

/* Audit Filter Controls */
.pk01-filter-bar {
    background: #f8fafc;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    padding: 14px 18px;
    margin-bottom: 18px;
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}
.pk01-form-ctrl {
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    background: #ffffff;
    color: #0f172a;
    outline: none;
    transition: all 0.2s;
}
.pk01-form-ctrl:focus {
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-table th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-table td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-table tr:hover td { background: #fbfcfe; }

/* Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-sm { padding: 4px 9px; font-size: 11.5px; border-radius: 6px; }

.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 12px;
}

/* Status Severity Pills */
.pk01-sev-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 8px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}
.sev-info     { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.sev-warning  { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.sev-security { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.sev-error    { background: #450a0a; color: #fecaca; border: 1px solid #7f1d1d; }

/* Grid Role Matrix */
.pk01-role-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 16px;
}
.pk01-role-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    padding: 16px 18px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: var(--pk-shadow);
}
</style>

<div class="pk01-usr-app">

    <!-- 1. HERO COCKPIT BANNER -->
    <header class="pk01-usr-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">IDENTITY &bull; AUDIT TRAIL ENGINE</span>
            <h1>🛡️ Manajemen Akses &amp; Log Aktivitas</h1>
            <p>
                Pusat pengawasan hak akses pengguna, simulasi tampilan kerja per divisi, serta rekaman jejak audit transaksi (read-only) untuk menjamin kepatuhan tata kelola internal.
            </p>
        </div>
        <div class="pk01-sec-indicator">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>AUDIT RECORDING AKTIF</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                Tingkat Keamanan: <b>Standar Korporat</b>
            </div>
        </div>
    </header>

    <!-- 2. 4 EXECUTIVE KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Pengguna Terdaftar</div>
            <div class="pk01-kpi-val"><?php echo number_format($total_users); ?></div>
            <div class="pk01-kpi-sub">Total akun staf aktif di portal</div>
        </div>

        <div class="pk01-kpi-card c-green">
            <div class="pk01-kpi-label">Staf Aktif Hari Ini</div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo number_format($active_today); ?></div>
            <div class="pk01-kpi-sub">Melakukan transaksi / absensi</div>
        </div>

        <div class="pk01-kpi-card c-purple">
            <div class="pk01-kpi-label">Entri Log Periode Ini</div>
            <div class="pk01-kpi-val" style="color:#7c3aed;"><?php echo number_format(count($rows)); ?></div>
            <div class="pk01-kpi-sub"><?php echo (int)$days; ?> hari terakhir terlacak</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Peringatan / Security</div>
            <div class="pk01-kpi-val" style="<?php echo ($sec_warnings > 0) ? 'color:#dc2626;' : 'color:#059669;'; ?>">
                <?php echo number_format($sec_warnings); ?>
            </div>
            <div class="pk01-kpi-sub">Insiden peringatan tercatat</div>
        </div>
    </section>

    <!-- 3. TABS NAVIGASI UTAMA -->
    <nav class="pk01-nav-tabs" aria-label="Menu Pengguna & Audit">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-users">
            👥 Direktori Staf &amp; Akses (<?php echo (int)$total_users; ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-logs">
            📋 Jejak Audit Terinci (Audit Trail)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-roles">
            🛡️ Matriks Peran &amp; Wewenang (<?php echo count($role_usage_counts); ?>)
        </button>
    </nav>

    <!-- 4. TAB 1: DIREKTORI PENGGUNA & PREVIEW ROLE -->
    <div class="pk01-pane is-active" id="tab-users">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>👥 Daftar Staf &amp; Simulasi Perspektif Peran</h3>
                    <div class="pk01-surface-desc">
                        Uji pratinjau antarmuka dashboard sesuai hak akses staf secara langsung tanpa perlu login ulang.
                    </div>
                </div>
                <div>
                    <input type="search" id="pk01_search_user_list" class="pk01-form-ctrl" placeholder="🔍 Cari nama, @username, peran..." style="width:260px;">
                </div>
            </div>

            <div class="pk01-user-list" id="pk01_user_container">
                <?php 
                foreach ($users as $usr):
                    $rid = !empty($usr->roles) ? $usr->roles[0] : 'subscriber';
                    $label = $role_labels[$rid] ?? ucfirst(str_replace('_', ' ', $rid));
                    $preview = class_exists('PK01_Authorization') 
                        ? PK01_Authorization::role_preview_url($rid) 
                        : add_query_arg('pk01_role_preview', $rid, class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes','frontend_url_public') ? PK01_Shortcodes::frontend_url_public('dashboard') : home_url('/'));
                    
                    $user_activity_count = $counts[(int)$usr->ID] ?? 0;
                    $badge_style = $get_role_badge_style($rid);

                    // Avatar inisial
                    $name_str = $usr->display_name ?: $usr->user_login;
                    $parts = explode(' ', trim($name_str));
                    $initial = count($parts) >= 2 
                        ? mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1) 
                        : mb_substr($name_str, 0, 2);
                ?>
                <div class="pk01-user-card-item" data-text="<?php echo esc_attr(strtolower($name_str . ' ' . $usr->user_login . ' ' . $usr->user_email . ' ' . $label)); ?>">
                    <div class="pk01-user-avatar">
                        <?php echo esc_html(strtoupper($initial)); ?>
                    </div>

                    <div class="pk01-user-details">
                        <strong><?php echo esc_html($name_str); ?></strong>
                        <span>@<?php echo esc_html($usr->user_login); ?> &bull; <?php echo esc_html($usr->user_email); ?></span>
                    </div>

                    <div>
                        <span class="pk01-role-badge" style="<?php echo esc_attr($badge_style); ?>">
                            ● <?php echo esc_html($label); ?>
                        </span>
                    </div>

                    <div class="pk01-user-stat">
                        <strong><?php echo number_format($user_activity_count); ?></strong>
                        <span>aktivitas / <?php echo (int)$days; ?> hari</span>
                    </div>

                    <div style="display:flex; gap:6px; align-items:center;">
                        <a class="pk01-btn pk01-btn-subtle pk01-btn-sm" href="<?php echo esc_url(add_query_arg(['pk01_view'=>'users', 'pk01_log_user'=>$usr->ID, 'pk01_log_days'=>$days])); ?>#tab-logs">
                            🔍 Filter Log
                        </a>
                        <a class="pk01-btn pk01-btn-dark pk01-btn-sm" target="_blank" href="<?php echo esc_url($preview); ?>" title="Simulasi dashboard sebagai role ini">
                            👁️ Preview
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- 5. TAB 2: AUDIT TRAIL LOG AKTIVITAS -->
    <div class="pk01-pane" id="tab-logs">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📋 Rekaman Audit Trail Sistem</h3>
                    <div class="pk01-surface-desc">
                        Seluruh jejak transaksi, mutasi keuangan, pembuatan SPK, dan login tercatat otomatis secara <strong>read-only</strong>.
                    </div>
                </div>
                <?php if ($has_log_table): ?>
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('pk01_export_user_logs_nonce'); ?>
                        <input type="hidden" name="pk01_export_user_logs_csv" value="1">
                        <input type="hidden" name="exp_days" value="<?php echo (int)$days; ?>">
                        <input type="hidden" name="exp_user" value="<?php echo (int)$selected_user; ?>">
                        <input type="hidden" name="exp_level" value="<?php echo esc_attr($selected_level); ?>">
                        <button type="submit" class="pk01-btn pk01-btn-subtle">
                            📥 Ekspor Audit (.CSV)
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- FILTER BAR -->
            <form class="pk01-filter-bar" method="get">
                <input type="hidden" name="pk01_view" value="users">
                
                <label style="font-size:12px; font-weight:700; color:#475569;">Pilih Staf:
                    <select name="pk01_log_user" class="pk01-form-ctrl">
                        <option value="0">— Seluruh Pengguna —</option>
                        <?php foreach ($users as $usr): ?>
                            <option value="<?php echo (int)$usr->ID; ?>" <?php selected($selected_user, (int)$usr->ID); ?>>
                                <?php echo esc_html($usr->display_name ?: $usr->user_login); ?> (@<?php echo esc_html($usr->user_login); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label style="font-size:12px; font-weight:700; color:#475569;">Tingkat Severity:
                    <select name="pk01_log_level" class="pk01-form-ctrl">
                        <option value="">— Seluruh Level —</option>
                        <option value="info" <?php selected($selected_level, 'info'); ?>>Info (Normal)</option>
                        <option value="warning" <?php selected($selected_level, 'warning'); ?>>Warning (Peringatan)</option>
                        <option value="security" <?php selected($selected_level, 'security'); ?>>Security (Akses Penting)</option>
                        <option value="error" <?php selected($selected_level, 'error'); ?>>Error (Kegagalan)</option>
                    </select>
                </label>

                <label style="font-size:12px; font-weight:700; color:#475569;">Periode:
                    <select name="pk01_log_days" class="pk01-form-ctrl">
                        <option value="7" <?php selected($days, 7); ?>>7 Hari Terakhir</option>
                        <option value="30" <?php selected($days, 30); ?>>30 Hari Terakhir</option>
                        <option value="90" <?php selected($days, 90); ?>>90 Hari Terakhir</option>
                        <option value="180" <?php selected($days, 180); ?>>180 Hari Terakhir</option>
                    </select>
                </label>

                <button class="pk01-btn pk01-btn-dark" type="submit">Filter Log</button>

                <?php if ($selected_user || !empty($selected_level)): ?>
                    <a class="pk01-btn pk01-btn-subtle" href="?pk01_view=users#tab-logs">✕ Reset Filter</a>
                <?php endif; ?>
            </form>

            <!-- TABEL AUDIT TRAIL -->
            <div class="pk01-table-card">
                <?php if (empty($rows)): ?>
                    <div style="text-align:center; padding:44px 20px; color:#94a3b8; font-size:13px;">
                        📁 Belum ada rekaman aktivitas pada filter dan periode waktu yang dipilih.
                    </div>
                <?php else: ?>
                    <table class="pk01-table">
                        <thead>
                            <tr>
                                <th style="width:145px;">Waktu &amp; Tanggal</th>
                                <th>Staf Pengguna</th>
                                <th>Role</th>
                                <th>Modul</th>
                                <th>Aksi Operasional</th>
                                <th>Entitas Terkait</th>
                                <th style="text-align:center; width:100px;">Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): 
                                $raw_level = strtolower($r['level'] ?? 'info');
                                $sev_class = 'sev-info';
                                if ($raw_level === 'error') $sev_class = 'sev-error';
                                elseif ($raw_level === 'security') $sev_class = 'sev-security';
                                elseif ($raw_level === 'warning') $sev_class = 'sev-warning';

                                $time_val = $r[$col_time] ?? ($r['timestamp'] ?? '—');
                            ?>
                            <tr>
                                <td>
                                    <span class="pk01-code-badge" style="font-size:11.5px;">
                                        <?php echo esc_html($time_val); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong style="color:#0f172a;"><?php echo esc_html($r['user_name'] ?? 'Sistem / Anonim'); ?></strong>
                                    <?php if (!empty($r['user_id'])): ?>
                                        <div style="font-size:11px; color:#64748b;">ID: #<?php echo (int)$r['user_id']; ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span style="font-size:12px; color:#475569;">
                                        <?php echo esc_html($role_labels[$r['user_role'] ?? ''] ?? ($r['user_role'] ?? '—')); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="pk01-code-badge"><?php echo esc_html($r['module'] ?? '—'); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($r['action'] ?? '—'); ?></strong>
                                </td>
                                <td style="color:#475569; font-size:12.5px;">
                                    <?php echo esc_html($r['entity'] ?? '—'); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-sev-pill <?php echo esc_attr($sev_class); ?>">
                                        ● <?php echo esc_html($raw_level); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 6. TAB 3: MATRIKS PERAN & SEBARAN WEWENANG -->
    <div class="pk01-pane" id="tab-roles">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🛡️ Matriks &amp; Sebaran Wewenang PK01</h3>
                    <div class="pk01-surface-desc">
                        Distribusi akun pengguna yang aktif berdasarkan divisi operasional yang terdaftar.
                    </div>
                </div>
            </div>

            <div class="pk01-role-grid">
                <?php foreach ($role_usage_counts as $rk => $ucount): 
                    $rname = $role_labels[$rk] ?? ucfirst(str_replace('_', ' ', $rk));
                    $badge_style = $get_role_badge_style($rk);
                ?>
                <div class="pk01-role-card">
                    <div>
                        <span class="pk01-role-badge" style="<?php echo esc_attr($badge_style); ?> margin-bottom:6px;">
                            <?php echo esc_html($rname); ?>
                        </span>
                        <div style="font-size:11.5px; color:#64748b; font-family:monospace;">
                            ID: <?php echo esc_html($rk); ?>
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <span style="font-size:20px; font-weight:800; color:#0f172a;"><?php echo (int)$ucount; ?></span>
                        <span style="font-size:11px; color:#64748b; display:block;">Staf Aktif</span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
    var tabBtns = document.querySelectorAll('.pk01-tab-btn');
    var panes   = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        var btn = document.querySelector('.pk01-tab-btn[data-target="' + targetId + '"]');
        var pane = document.getElementById(targetId);

        if (btn && pane) {
            tabBtns.forEach(function(b) { b.classList.remove('is-active'); });
            panes.forEach(function(p) { p.classList.remove('is-active'); });

            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    // Cek Hash URL saat halaman dibuka
    var currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. LIVE SEARCH FILTER UNTUK DAFTAR PENGGUNA
    var searchInput = document.getElementById('pk01_search_user_list');
    var container   = document.getElementById('pk01_user_container');

    if (searchInput && container) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            var rows   = container.querySelectorAll('.pk01-user-card-item');

            rows.forEach(function(row) {
                var text = row.getAttribute('data-text') || '';
                row.style.display = (text.indexOf(filter) > -1) ? '' : 'none';
            });
        });
    }
});
</script>