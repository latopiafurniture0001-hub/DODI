<?php
if (!defined('ABSPATH')) exit;
if (!is_user_logged_in()) return;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin && class_exists('PK01_Authorization') && !PK01_Authorization::can('dashboard')) {
    return;
}

global $wpdb;
$role  = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : 'subscriber';
$label = class_exists('PK01_Engine') ? PK01_Engine::role_label($role) : ucfirst($role);
$month = current_time('Y-m'); 
$today = current_time('Y-m-d');
$now   = current_time('timestamp');
$master_health = class_exists('PK01_Master_Contract') ? PK01_Master_Contract::source_health() : [];


// Helper Deteksi Tabel & Kueri Cepat
$T = function($k) use($wpdb) {
    $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k; 
    return ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) ? $t : false;
};
$N = function($sql, $args = []) use($wpdb) {
    return $args ? $wpdb->get_var($wpdb->prepare($sql, ...$args)) : $wpdb->get_var($sql);
};
$money = function($n) {
    return 'Rp ' . number_format((float)$n, 0, ',', '.');
};

// Product Master Control: satu pintu pembuatan produk/SKU. Dashboard Administrator
// harus menjawab dengan jelas: di mana produk dibuat, bagaimana masuk ke Theme/E-Commerce,
// dan siapa yang boleh mengubahnya. Seller/Kasir tidak membuat master produk.
$product_master_count = 0;
$product_active_count = 0;
$product_variant_count = 0;
$products_table_dash = $T('products');
$variants_table_dash = $T('product_variants');
if ($products_table_dash) {
    $product_master_count = (int)$N("SELECT COUNT(*) FROM `$products_table_dash`");
    $product_active_count = (int)$N("SELECT COUNT(*) FROM `$products_table_dash` WHERE status='active'");
}
if ($variants_table_dash) {
    $product_variant_count = (int)$N("SELECT COUNT(*) FROM `$variants_table_dash` WHERE status='active'");
}
$real_snapshot = (class_exists('PK01_Data_Health') && method_exists('PK01_Data_Health','operational_snapshot')) ? PK01_Data_Health::operational_snapshot() : [];
$real_sales_total = (int)($real_snapshot['sales_total'] ?? 0);
$real_sales_valid = (int)($real_snapshot['sales_valid'] ?? 0);
$real_jobs_total = (int)($real_snapshot['jobs_total'] ?? 0);
$real_jobs_finished = (int)($real_snapshot['jobs_finished'] ?? 0);
$real_rows_complete = (int)($real_snapshot['rows_complete'] ?? 0);
$real_rows_total = (int)($real_snapshot['rows_total'] ?? 0);
$real_completeness = (float)($real_snapshot['completeness_percent'] ?? 100);
$product_master_url = class_exists('PK01_Shortcodes') ? PK01_Shortcodes::frontend_url_public('products') : add_query_arg('pk01_view','products',home_url('/dashboard-operasional/'));
$storefront_url = home_url('/');

// Launcher marketplace khusus Seller. Sumber tetap Master PK01; tidak membuat SKU baru.
$seller_dashboard_account = null;
$seller_dashboard_portal_url = class_exists('PK01_Shortcodes') ? PK01_Shortcodes::frontend_url_public('dashboard') : home_url('/');
if ($role === 'pk01_seller' && $wpdb) {
    $seller_accounts_t = $T('sales_accounts');
    if ($seller_accounts_t) {
        $seller_dashboard_account = $wpdb->get_row($wpdb->prepare(
            "SELECT id,user_id,portal_token,name,code FROM `$seller_accounts_t` WHERE type='seller' AND active=1 AND user_id=%d LIMIT 1",
            get_current_user_id()
        ), ARRAY_A);
        if (!$seller_dashboard_account && class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview() && current_user_can('manage_options')) {
            $seller_dashboard_account = $wpdb->get_row("SELECT id,user_id,portal_token,name,code FROM `$seller_accounts_t` WHERE type='seller' AND active=1 ORDER BY id ASC LIMIT 1", ARRAY_A);
        }
    }
}
$seller_dashboard_marketplaces = class_exists('PK01_Marketplace_Catalog') ? PK01_Marketplace_Catalog::marketplaces() : [];

// Kamus Profil Peran & Konteks Kerja
$profiles = [
    'pk01_gudang'   => ['ey'=>'WAREHOUSE WORKSPACE','title'=>'Gudang & Persediaan Terkendali','desc'=>'Kelola stok fisik bahan baku, penerimaan barang masuk, pengeluaran ke SPK produksi, dan kesiapan material.','cards'=>[['inventory','Bahan Tersedia','materials'],['inventory','Stok Kritis / Habis','critical'],['purchasing_hub','Pembelian Berjalan','purchase'],['production_hub','Job Butuh Bahan','jobs_material']], 'actions'=>[['inventory','Kelola Stok & Mutasi'],['purchasing_hub','Pembelian & Penerimaan'],['production_hub','Kebutuhan Bahan Job'],['shipping_hub','Kesiapan Pengiriman']]],
    'pk01_produksi' => ['ey'=>'PRODUCTION WORKSPACE','title'=>'Lantai Produksi Terarah','desc'=>'Atur SPK, penugasan karyawan, kesiapan bahan baku, progres pengerjaan, dan upah borongan tanpa hambatan.','cards'=>[['production_hub','Job Aktif Berjalan','jobs'],['job_karyawan','Penerima Pekerjaan','assignments'],['inventory','Bahan Kritis Gudang','critical'],['job_wages','Kewajiban Upah Job','wages']], 'actions'=>[['production_hub','Kelola Job Produksi'],['cnc_dashboard','Dashboard Operator CNC'],['job_karyawan','Kirim & Pantau Job Pekerja'],['communications','Komunikasi Job'],['job_wages','Pantau & Rekap Upah Job'],['inventory','Cek Kesiapan Bahan']]],
    'pk01_kasir'    => ['ey'=>'SALES DESK WORKSPACE','title'=>'Kasir & Penjualan Toko','desc'=>'Proses pesanan pelanggan, pencatatan pembayaran kas, penerbitan invoice, setoran maker-checker, dan koordinasi antrean pengiriman.','cards'=>[['sales_hub','Pesanan Perlu Diproses','pending_orders'],['sales_hub','Omzet Bulan Ini','sales'],['cash','Saldo Kas & Bank','cash'],['shipping_hub','Pengiriman Aktif','shipments']], 'actions'=>[['sales_hub','Buka Kasir Penjualan'],['cash','Buku Kas & Setoran'],['shipping_hub','Pantau Status Pengiriman'],['orders','Daftar Semua Pesanan']]],
    'pk01_keuangan' => ['ey'=>'FINANCE WORKSPACE','title'=>'Pusat Keuangan & Laba Rugi','desc'=>'Pantau arus kas masuk, arus keluar, rekonsiliasi piutang, HPP pesanan, payroll, dan persetujuan setoran Kasir/Seller.','cards'=>[['finance_hub','Omzet Bulan Ini','sales'],['finance_hub','Laba Bersih Terukur','profit'],['cash','Saldo Kas & Bank','cash'],['finance_hub','Piutang Terindikasi','receivable']], 'actions'=>[['finance_hub','Pusat Laporan Keuangan'],['cash','Buku Kas, Setoran & Rekonsiliasi'],['operational_costs','Catat Biaya Operasional'],['payroll','Payroll & Pembayaran Gaji']]],
    'pk01_hr'       => ['ey'=>'PEOPLE OPERATIONS','title'=>'SDM & Manajemen Kerja','desc'=>'Kelola data karyawan, riwayat pekerjaan, penetapan tarif upah, dan penggajian payroll secara terstruktur.','cards'=>[['hr','Karyawan Aktif','employees'],['job_wages','Job Produksi Aktif','jobs'],['job_wages','Upah Belum Lunas','wages_due']], 'actions'=>[['hr','Kelola Data SDM'],['job_wages','Tarif & Upah Job'],['payroll','Penggajian Payroll'],['master_data','Master Karyawan']]],
    'pk01_logistik' => ['ey'=>'LOGISTICS WORKSPACE','title'=>'Logistik & Pengiriman Cepat','desc'=>'Fokus pada pengiriman, ekspedisi, nomor resi, dan status paket. Akses kasir dan gudang tidak termasuk dalam peran ini.','cards'=>[['shipping_hub','Pengiriman Berjalan','shipments'],['packing','Siap dari Packing','pack_ready']], 'actions'=>[['shipping_hub','Kelola Ekspedisi & Resi'],['packing','Cek Antrean Packing']]],
    'pk01_seller'   => ['ey'=>'SELLER WORKSPACE','title'=>'Pusat Penjualan Mitra','desc'=>'Kelola katalog, pesanan, marketplace, pengiriman, tagihan, dan komisi Anda dari satu workspace. Seller tidak membuat Master Produk baru.','cards'=>[['seller_portal','Penjualan Bersih','seller_net_sales'],['seller_portal','Retur Diterima','seller_returns'],['seller_portal','Tagihan Belum Dibayar','seller_invoice_unpaid'],['seller_portal','Tagihan Sudah Dibayar','seller_invoice_paid'],['seller_portal','Target & Pencapaian','seller_target_progress'],['seller_portal','Komisi Belum Dicairkan','seller_bonus_due']], 'actions'=>[['seller_portal','📦 Katalog, Pesanan & Marketplace','tab-marketplace-catalog'],['communications','💬 Chat Order / Job',''],['seller_portal','🧾 Tagihan & Komisi','tab-invoices'],['seller_portal','📣 Promosi & Afiliasi','tab-catalog']]],
    'pk01_owner'    => ['ey'=>'OWNER CONTROL TOWER','title'=>'Pusat Kendali Eksekutif Pemilik','desc'=>'Ringkasan keputusan strategis bisnis, likuiditas kas, profitabilitas, margin HPP, dan mitigasi risiko usaha.','cards'=>[['sales_hub','Omzet Periode Ini','sales'],['finance_hub','Laba Operasional','profit'],['cash','Saldo Kas Riil','cash'],['finance_hub','Total Piutang','receivable']], 'actions'=>[['sales_hub','Penjualan'],['finance_hub','Pusat Keuangan'],['production_hub','Produksi'],['inventory','Gudang Stok'],['ai_assistant','Konsultasi AI Owner']]],
    'pk01_investor' => ['ey'=>'INVESTOR SUITE','title'=>'Ringkasan Kinerja Investasi','desc'=>'Transparansi kinerja bisnis periode berjalan, pertumbuhan pendapatan, dan pembagian dividen laba.','cards'=>[['finance_reports','Laba Periode Berjalan','profit'],['finance_reports','Total Penjualan','sales'],['cash','Saldo Kas Sistem','cash']], 'actions'=>[['finance_reports','Laporan Laba Rugi Komprehensif'],['ai_assistant','Tanya AI seputar Kinerja Usaha']]],
    'shop_manager'  => ['ey'=>'OPERATIONS MANAGER','title'=>'Kendali Operasional Usaha','desc'=>'Pantau keterhubungan antara penjualan kasir, antrean produksi, stok gudang, dan logistik secara terpadu.','cards'=>[['sales_hub','Pesanan Perlu Perhatian','pending_orders'],['production_hub','Job Produksi Aktif','jobs'],['inventory','Stok Kritis Gudang','critical'],['finance_hub','Laba Terukur','profit']], 'actions'=>[['sales_hub','Penjualan'],['production_hub','Produksi'],['inventory','Gudang'],['finance_hub','Keuangan'],['shipping_hub','Pengiriman']]],
    'editor'        => ['ey'=>'BUSINESS MONITORING','title'=>'Monitoring Alur Usaha','desc'=>'Akses terstruktur untuk memantau transaksi, pergerakan persediaan, dan laporan perkembangan bisnis.','cards'=>[['sales_hub','Pesanan','pending_orders'],['production_hub','Job Aktif','jobs'],['inventory','Stok Kritis','critical'],['shipping_hub','Pengiriman','shipments']], 'actions'=>[['sales_hub','Penjualan'],['production_hub','Produksi'],['inventory','Gudang'],['shipping_hub','Logistik']]],
    'administrator' => ['ey'=>'MASTER CONTROL TOWER','title'=>'Control Tower Administrator','desc'=>'Akses penuh tanpa batas ke seluruh modul operasional, database master, AI Engine, dan pengaturan sistem.','cards'=>[['sales_hub','Pesanan Menunggu','pending_orders'],['production_hub','Job Produksi Berjalan','jobs'],['inventory','Material Kritis','critical'],['finance_hub','Laba Bersih Riil','profit']], 'actions'=>[['master_data','Master Data Terpusat'],['products','＋ Tambah / Upload Produk Master'],['sales_hub','Penjualan'],['production_hub','Produksi'],['inventory','Gudang'],['finance_hub','Keuangan'],['shipping_hub','Logistik'],['ai_center','AI Center']]],
    'pk01_admin'    => ['ey'=>'ADMIN OPERASIONAL','title'=>'Pusat Kendali Operasional PK01','desc'=>'Kelola seluruh alur harian dari satu workspace operasional yang terintegrasi secara komprehensif.','cards'=>[['sales_hub','Pesanan Menunggu','pending_orders'],['production_hub','Job Produksi Berjalan','jobs'],['inventory','Material Kritis','critical'],['finance_hub','Laba Bersih Riil','profit']], 'actions'=>[['master_data','Master Data Terpusat'],['products','＋ Tambah / Upload Produk Master'],['sales_hub','Penjualan'],['production_hub','Produksi'],['inventory','Gudang'],['finance_hub','Keuangan'],['ai_center','AI Center']]],
    'pk01_packing' => ['ey'=>'PACKING WORKSPACE','title'=>'Packing & Kemas','desc'=>'Fokus pada antrean pesanan yang siap dipacking, pemeriksaan barang, dan serah-terima ke logistik.','cards'=>[['packing','Siap Dipacking','pack_ready'],['shipping_hub','Pengiriman Berjalan','shipments']], 'actions'=>[['packing','Antrean Packing'],['shipping_hub','Pantau Pengiriman']]],
    'pk01_employee' => ['ey'=>'EMPLOYEE WORKSPACE','title'=>'Pekerjaan Saya','desc'=>'Melihat pekerjaan yang ditugaskan, status pekerjaan, absensi, dan panduan kerja sesuai peran.','cards'=>[['job_karyawan','Job Saya','assignments']], 'actions'=>[['job_karyawan','Buka Pekerjaan Saya']]],
    'pk01_customer_service' => ['ey'=>'CUSTOMER SERVICE WORKSPACE','title'=>'Customer Service','desc'=>'Kelola antrean komunikasi pelanggan, seller, dan tindak lanjut layanan.','cards'=>[['customer_service','Tiket Layanan','cs_tickets']], 'actions'=>[['customer_service','Buka Customer Service']]],
    'pk01_security' => ['ey'=>'SECURITY WORKSPACE','title'=>'Security & Keamanan','desc'=>'Pantau aktivitas keamanan, kunjungan, kendaraan, barang, insiden, dan kamera.','cards'=>[['security','Insiden Keamanan','security_incidents']], 'actions'=>[['security','Buka Security']]],
];

$p = $profiles[$role] ?? [
    'ey'      => 'PK01 WORKSPACE',
    'title'   => 'Ruang Kerja Operasional',
    'desc'    => 'Modul dan tindakan disesuaikan dengan wewenang pekerjaan Anda.',
    'cards'   => [],
    'actions' => []
];

// Pengambilan Data Finansial dari Engine Pusat
$finance = (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'financial_report'))
    ? PK01_Engine::financial_report($month . '-01', $today)
    : [];

$vals = [];
$vals['sales']      = (float)($finance['gross_sales'] ?? 0); 
$vals['profit']     = (float)($finance['net_profit'] ?? 0); 
$vals['cash']       = (float)($finance['cash_balance'] ?? 0);
$vals['receivable'] = max(0, (float)($finance['gross_sales'] ?? 0) - (float)($finance['returns'] ?? 0) - (float)($finance['cash_in'] ?? 0));

// Pengambilan Data Operasional Real Database
$orders    = $T('sales_orders') ?: $T('orders'); 
$jobs      = $T('jobs') ?: $T('production_jobs'); 
$materials = $T('materials'); 
$assign    = $T('job_assignments'); 
$employees = $T('employees'); 
$ship      = $T('shipments'); 
$po        = $T('purchase_orders'); 
$wages     = $T('job_wages');

$vals['pending_orders'] = $orders ? (int)$N("SELECT COUNT(*) FROM `$orders` WHERE status NOT IN ('completed','cancelled','batal') AND payment_status NOT IN ('paid','lunas','completed')") : 0;
$vals['jobs']           = $jobs ? (int)$N("SELECT COUNT(*) FROM `$jobs` WHERE status NOT IN ('completed','selesai','cancelled')") : 0;
$vals['assignments']    = $assign ? (int)$N("SELECT COUNT(*) FROM `$assign` WHERE status NOT IN ('completed','returned')") : 0;
$vals['employees']      = $employees ? (int)$N("SELECT COUNT(*) FROM `$employees` WHERE status='active'") : 0;
$vals['shipments']      = $ship ? (int)$N("SELECT COUNT(*) FROM `$ship` WHERE status NOT IN ('delivered','completed','selesai','cancelled')") : 0;
$vals['critical']       = $materials ? (int)$N("SELECT COUNT(*) FROM `$materials` WHERE stock<=min_stock") : 0;
$vals['materials']      = $materials ? (int)$N("SELECT COUNT(*) FROM `$materials` WHERE status='active'") : 0;
$vals['purchase']       = $po ? (int)$N("SELECT COUNT(*) FROM `$po` WHERE status NOT IN ('completed','cancelled','closed')") : 0;
$vals['wages_due']      = $wages ? (float)$N("SELECT COALESCE(SUM(GREATEST(total_amount-COALESCE(paid_amount,0),0)),0) FROM `$wages` WHERE status NOT IN ('paid','lunas')") : 0;
$vals['wages']          = $vals['wages_due'];

$vals['pack_ready'] = 0; 
$pack = $T('orders') ?: $orders; 
if ($pack) {
    $vals['pack_ready'] = (int)$N("SELECT COUNT(*) FROM `$pack` WHERE payment_status='paid' AND shipping_status IN ('pending','ready_to_pack','packing') AND status NOT IN ('cancelled','failed','refunded','shipped','completed')");
}

// KPI tambahan untuk dashboard role: semuanya berasal dari tabel nyata.
$vals['jobs_material'] = 0;
$job_materials = $T('job_materials');
if ($job_materials) {
    // Job yang masih memiliki kebutuhan bahan yang belum dikeluarkan.
    $vals['jobs_material'] = (int)$N("SELECT COUNT(DISTINCT job_id) FROM `$job_materials` WHERE COALESCE(issued_qty,0) <= 0 AND COALESCE(used_qty,0) <= 0");
}
$vals['cs_tickets'] = 0;
$cs_tickets = $T('cs_tickets');
if ($cs_tickets) {
    $vals['cs_tickets'] = (int)$N("SELECT COUNT(*) FROM `$cs_tickets` WHERE status NOT IN ('closed','resolved','cancelled')");
}
$vals['security_incidents'] = 0;
$security_incidents = $T('security_incidents');
if ($security_incidents) {
    $vals['security_incidents'] = (int)$N("SELECT COUNT(*) FROM `$security_incidents` WHERE status NOT IN ('closed','resolved','cancelled')");
}

// Konteks pekerja: dashboard karyawan memakai assignment miliknya sendiri.
$worker_employee_id = 0;
$worker_cnc_jobs = 0;
$worker_prema_jobs = 0;
if ($role === 'pk01_employee' && $employees && $assign) {
    $worker_employee_id = (int)$N("SELECT id FROM `$employees` WHERE user_id=%d AND status='active' ORDER BY id LIMIT 1", [get_current_user_id()]);
    if ($worker_employee_id) {
        $vals['assignments'] = (int)$N("SELECT COUNT(*) FROM `$assign` WHERE employee_id=%d AND status NOT IN ('completed','returned')", [$worker_employee_id]);
        $worker_cnc_jobs = (int)$N("SELECT COUNT(*) FROM `$assign` WHERE employee_id=%d AND role_code='cnc' AND status NOT IN ('completed','returned')", [$worker_employee_id]);
        $worker_prema_jobs = (int)$N("SELECT COUNT(*) FROM `$assign` WHERE employee_id=%d AND role_code='prema' AND status NOT IN ('completed','returned')", [$worker_employee_id]);
    }
    if (class_exists('PK01_Authorization') && PK01_Authorization::employee_has_job_role('cnc')) {
        $p['cards'][] = ['cnc_dashboard','Job CNC Saya','worker_cnc'];
        $p['actions'][] = ['cnc_dashboard','⚙️ Dashboard Operator CNC'];
    }
    if (class_exists('PK01_Authorization') && PK01_Authorization::employee_has_job_role('prema')) {
        $p['actions'][] = ['job_karyawan','🎨 Pekerjaan Prema Saya'];
    }
    $p['actions'][] = ['communications','💬 Komunikasi Job'];
}
$vals['worker_cnc'] = $worker_cnc_jobs;
$vals['worker_prema'] = $worker_prema_jobs;

// Logika Khusus Mitra Seller
$vals['seller_target_progress'] = 0; 
$vals['seller_bonus_due'] = 0;
$vals['seller_net_sales'] = 0;
$vals['seller_returns'] = 0;
$vals['seller_invoice_unpaid'] = 0;
$vals['seller_invoice_paid'] = 0;
if (in_array($role, ['pk01_seller'], true)) { 
    $sa = $T('sales_accounts');
    $ss = $T('seller_sales');
    $sb = $T('seller_targets');
    $bl = $T('seller_bonus_ledger'); 
    if ($sa && $ss && $sb) {
        $sid = (int)$N("SELECT id FROM `$sa` WHERE user_id=%d AND active=1 ORDER BY id LIMIT 1", [get_current_user_id()]);
        if ($sid) {
            $period = current_time('Y-m');
            $target_row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$sb` WHERE seller_account_id=%d AND period_key=%s AND status='active' ORDER BY CASE WHEN participant_type='seller' THEN 0 ELSE 1 END,id DESC LIMIT 1", $sid, $period), ARRAY_A);
            $target = (float)($target_row['target_amount'] ?? 0);
            if (($target_row['participant_type'] ?? 'seller') === 'marketing') { 
                $am = $T('seller_affiliate_ledger');
                $sales = $am ? (float)$N("SELECT COALESCE(SUM(base_amount),0) FROM `$am` WHERE seller_account_id=%d AND created_at BETWEEN %s AND %s AND status IN ('pending','ready','paid','approved')", [$sid, $period.'-01 00:00:00', date('Y-m-t').' 23:59:59']) : 0; 
            } else { 
                $sales = (float)$N("SELECT COALESCE(SUM(total),0) FROM `$ss` WHERE seller_account_id=%d AND sold_at BETWEEN %s AND %s", [$sid, $period.'-01 00:00:00', date('Y-m-t').' 23:59:59']); 
            }
            $vals['seller_target_progress'] = $target > 0 ? min(100, ($sales / $target) * 100) : 0;
            $vals['seller_bonus_due'] = $bl ? (float)$N("SELECT COALESCE(SUM(bonus_amount),0) FROM `$bl` WHERE seller_account_id=%d AND status='earned'", [$sid]) : 0;
            // Laporan Seller selalu memakai transaksi asli: penjualan - retur yang sudah diterima Gudang.
            $so = $T('sales_orders');
            $rt = $T('returns');
            $si = $T('seller_invoices');
            $sp = $T('seller_payments');
            $gross = $so ? (float)$N("SELECT COALESCE(SUM(total_amount),0) FROM `$so` WHERE seller_id=%d AND status NOT IN ('cancelled','batal','failed')", [$sid]) : 0;
            $retur = ($rt && $wpdb->get_var("SHOW COLUMNS FROM `{$rt}` LIKE 'seller_ar_adjustment_status'"))
                ? (float)$N("SELECT COALESCE(SUM(CASE WHEN seller_ar_adjustment_status='applied' THEN seller_adjustment_amount ELSE 0 END),0) FROM `$rt` WHERE seller_account_id=%d AND status NOT IN ('cancelled')", [$sid])
                : 0;
            $vals['seller_returns'] = $retur;
            $vals['seller_net_sales'] = max(0, $gross - $retur);
            if ($si) {
                $vals['seller_invoice_unpaid'] = (float)$N("SELECT COALESCE(SUM(GREATEST(i.total-COALESCE((SELECT SUM(p.amount) FROM `$sp` p WHERE p.invoice_id=i.id),0),0)),0) FROM `$si` i WHERE i.seller_account_id=%d", [$sid]);
                $vals['seller_invoice_paid'] = $sp ? (float)$N("SELECT COALESCE(SUM(p.amount),0) FROM `$sp` p INNER JOIN `$si` i ON i.id=p.invoice_id WHERE i.seller_account_id=%d", [$sid]) : 0;
            }
        }
    }
}

// SMART CONTROL TOWER — hanya untuk Admin/Owner/Manager/Keuangan.
// Semua metrik berasal dari transaksi/master nyata. Jika tabel/kolom tidak tersedia, bagian tersebut tidak mengarang data.
$master_source_banner = '<section style="margin:0 0 18px;padding:14px 16px;border:1px solid #dbeafe;border-radius:12px;background:#eff6ff;display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;"><div><strong style="color:#1e3a8a;">🔗 Sumber Data PK01 Terpusat</strong><div style="font-size:12px;color:#475569;margin-top:3px;">Dashboard membaca Product Master, SKU, stok, order, Job, Seller dan Keuangan dari sumber PK01 yang sama. Tidak ada data contoh.</div></div><div style="font-size:11px;color:#334155;">Master: '.(!empty($master_health['product_master'])?'OK':'belum tersedia').' · SKU: '.(!empty($master_health['variant_master'])?'OK':'belum tersedia').' · E-Commerce: '.(!empty($master_health['commerce_service'])?'OK':'belum tersedia').'</div></section>';
if (in_array($role, ['administrator','pk01_admin','pk01_owner','shop_manager','pk01_keuangan'], true)) echo $master_source_banner;
// Smart Control Tower hanya tampil pada Beranda yang memang memiliki fungsi monitoring manajerial.
// Jangan gunakan $is_admin di sini: Administrator yang sedang PREVIEW Seller/Kasir/Pekerja
// tetap mempertahankan permission admin, tetapi tampilan harus benar-benar mengikuti role preview.
$smart_enabled = in_array($role, ['administrator','pk01_admin','pk01_owner','shop_manager','pk01_keuangan'], true);
$smart = [
    'returns_count'=>0,'returns_value'=>0,'seller_unpaid'=>0,'seller_unpaid_count'=>0,
    'top_sellers'=>[],'top_return_sellers'=>[],'top_unpaid_sellers'=>[],'marketplace_sellers'=>[],
    'top_products'=>[],'active_jobs'=>[],'stock_total'=>0,'stock_critical'=>0
];
if ($smart_enabled) {
    $rt=$T('returns'); $si=$T('seller_invoices'); $sp=$T('seller_payments'); $sa=$T('sales_accounts');
    $so=$T('sales_orders'); $jobs_t=$T('jobs') ?: $T('production_jobs');
    $seller_orders_t=$T('seller_orders');
    $cols = static function($table) use ($wpdb) {
        if (!$table) return [];
        $rows=$wpdb->get_col("SHOW COLUMNS FROM `{$table}`",0);
        return is_array($rows)?$rows:[];
    };
    if ($rt) {
        $rc=$cols($rt);
        $smart['returns_count']=(int)$N("SELECT COUNT(*) FROM `$rt` WHERE status NOT IN ('cancelled','completed','selesai')");
        if (in_array('refund_amount',$rc,true)) {
            $smart['returns_value']=(float)$N("SELECT COALESCE(SUM(COALESCE(refund_amount,0)),0) FROM `$rt` WHERE status NOT IN ('cancelled')");
        }
        // Ranking seller berdasarkan retur yang benar-benar tercatat. Tidak membuat seller anonim sebagai seller palsu.
        if ($sa && in_array('seller_account_id',$rc,true)) {
            $smart['top_return_sellers']=$wpdb->get_results("SELECT sa.name,sa.code,COUNT(r.id) return_count,COALESCE(SUM(COALESCE(r.refund_amount,0)),0) return_value FROM `$rt` r INNER JOIN `$sa` sa ON sa.id=r.seller_account_id WHERE r.seller_account_id>0 AND r.status NOT IN ('cancelled') GROUP BY sa.id ORDER BY return_count DESC,return_value DESC LIMIT 5",ARRAY_A)?:[];
        } elseif ($sa && $seller_orders_t && in_array('seller_order_id',$rc,true)) {
            $smart['top_return_sellers']=$wpdb->get_results("SELECT sa.name,sa.code,COUNT(r.id) return_count,COALESCE(SUM(COALESCE(r.refund_amount,0)),0) return_value FROM `$rt` r INNER JOIN `$seller_orders_t` so2 ON so2.id=r.seller_order_id INNER JOIN `$sa` sa ON sa.id=so2.seller_account_id WHERE r.seller_order_id>0 AND r.status NOT IN ('cancelled') GROUP BY sa.id ORDER BY return_count DESC,return_value DESC LIMIT 5",ARRAY_A)?:[];
        }
    }
    if ($si) {
        $sp_join = $sp ? "COALESCE((SELECT SUM(p.amount) FROM `$sp` p WHERE p.invoice_id=i.id),0)" : "0";
        $smart['seller_unpaid']=(float)$N("SELECT COALESCE(SUM(GREATEST(i.total-($sp_join),0)),0) FROM `$si` i");
        $smart['seller_unpaid_count']=(int)$N("SELECT COUNT(*) FROM `$si` i WHERE GREATEST(i.total-($sp_join),0)>0.01");
        if ($sa) {
            $smart['top_unpaid_sellers']=$wpdb->get_results("SELECT sa.name,sa.code,COALESCE(SUM(GREATEST(i.total-($sp_join),0)),0) unpaid_amount,COUNT(i.id) invoice_count FROM `$si` i INNER JOIN `$sa` sa ON sa.id=i.seller_account_id GROUP BY sa.id HAVING unpaid_amount>0.01 ORDER BY unpaid_amount DESC LIMIT 5",ARRAY_A)?:[];
        }
    }
    if ($sa && $so) {
        $smart['top_sellers']=$wpdb->get_results("SELECT sa.name,sa.code,COALESCE(SUM(so.total_amount),0) total_sales,COUNT(so.id) orders FROM `$sa` sa INNER JOIN `$so` so ON so.seller_id=sa.id WHERE sa.type='seller' AND so.status NOT IN ('cancelled','batal','failed') GROUP BY sa.id ORDER BY total_sales DESC LIMIT 5",ARRAY_A)?:[];
        $smart['marketplace_sellers']=$wpdb->get_results("SELECT COALESCE(NULLIF(so.channel,''),'unknown') marketplace,sa.name seller_name,sa.code seller_code,COALESCE(SUM(so.total_amount),0) total_sales,COUNT(so.id) orders FROM `$so` so INNER JOIN `$sa` sa ON sa.id=so.seller_id WHERE so.seller_id>0 AND so.channel NOT IN ('website','whatsapp','offline','manual') AND so.status NOT IN ('cancelled','batal','failed') GROUP BY so.channel,sa.id ORDER BY total_sales DESC LIMIT 10",ARRAY_A)?:[];
    }
    if ($so) {
        $smart['top_products']=$wpdb->get_results("SELECT COALESCE(NULLIF(product_name,''),'Produk tanpa nama') product_name,COALESCE(SUM(qty),0) qty_sold,COALESCE(SUM(total_amount),0) revenue FROM `$so` WHERE status NOT IN ('cancelled','batal','failed') GROUP BY product_name ORDER BY qty_sold DESC,revenue DESC LIMIT 5",ARRAY_A)?:[];
    }
    if ($jobs_t) {
        $smart['active_jobs']=$wpdb->get_results("SELECT job_no,status,target_qty,deadline,priority FROM `$jobs_t` WHERE status NOT IN ('completed','selesai','cancelled','closed') ORDER BY CASE WHEN priority='urgent' THEN 0 WHEN priority='high' THEN 1 ELSE 2 END, deadline ASC LIMIT 8",ARRAY_A)?:[];
    }
    if ($materials) {
        $smart['stock_total']=(float)$N("SELECT COALESCE(SUM(stock),0) FROM `$materials` WHERE status='active'");
        $smart['stock_critical']=(int)$N("SELECT COUNT(*) FROM `$materials` WHERE status='active' AND stock<=min_stock");
    }
}

// Prompt & Tautan Asisten AI
$ai_prompt = 'Analisis kondisi operasional role ' . $label . '. Gunakan data PK01 nyata periode ' . $month . '. Berikan 3 prioritas tindakan paling penting hari ini, mitigasi risiko utama, dan modul yang harus dibuka pengguna. Jangan mengarang angka.';
$ai_url = add_query_arg('pk01_ai_prompt', rawurlencode($ai_prompt), PK01_Shortcodes::frontend_url_public('ai_assistant'));
?>

<style>
:root {
    --pk-ws-navy: #0f172a;
    --pk-ws-blue: #2563eb;
    --pk-ws-green: #059669;
    --pk-ws-amber: #d97706;
    --pk-ws-red: #dc2626;
    --pk-ws-border: #e2e8f0;
    --pk-ws-muted: #64748b;
}

.pk01-masterpiece-dashboard {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 0 auto 40px;
}
.pk01-masterpiece-dashboard * { box-sizing: border-box; }

/* Hero Banner */
.pk01-mp-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-mp-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-mp-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-mp-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}
.pk01-mp-user {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 10px 16px;
    text-align: right;
    min-width: 180px;
}
.pk01-mp-user span {
    display: block;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: #64748b;
}
.pk01-mp-user strong {
    display: block;
    font-size: 16px;
    color: #f1f5f9;
    margin: 2px 0;
}
.pk01-mp-user small {
    font-size: 11px;
    color: #38bdf8;
}

/* Operational Radar Alert Strip */
.pk01-radar-strip {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}
.pk01-radar-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    text-decoration: none !important;
    background: #ffffff;
    border: 1px solid var(--pk-ws-border);
    color: #334155;
    box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    transition: all 0.15s ease;
}
.pk01-radar-chip:hover { transform: translateY(-1px); }
.pk01-radar-chip.has-alert { background: #fffbeb; border-color: #fde68a; color: #b45309; }
.pk01-radar-chip.has-danger { background: #fef2f2; border-color: #fecaca; color: #dc2626; }

/* AI Operations Copilot Banner */
.pk01-mp-ai {
    background: #ffffff;
    border: 1px solid #dbeafe;
    border-radius: 14px;
    padding: 20px 24px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.04);
}
.pk01-mp-ai span {
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: #4f46e5;
}
.pk01-mp-ai h2 {
    margin: 3px 0 4px 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-mp-ai p {
    margin: 0;
    font-size: 13px;
    color: #64748b;
    max-width: 820px;
}
.pk01-ai-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: #4f46e5;
    color: #ffffff !important;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-ai-btn:hover {
    background: #4338ca;
    transform: translateY(-1px);
}

/* Dynamic KPI Grid */
.pk01-mp-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 24px;
}
.pk01-mp-kpi {
    background: #ffffff;
    border: 1px solid var(--pk-ws-border);
    border-radius: 12px;
    padding: 18px;
    text-decoration: none !important;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    transition: all 0.15s ease;
    border-left: 4px solid var(--pk-ws-blue);
}
.pk01-mp-kpi:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 14px rgba(0,0,0,0.06);
    border-color: #cbd5e1;
}
.pk01-mp-kpi span {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
}
.pk01-mp-kpi strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    margin: 8px 0 4px 0;
}
.pk01-mp-kpi small {
    font-size: 11px;
    color: #2563eb;
    font-weight: 600;
}

/* Actions Section */
.pk01-mp-section {
    background: #ffffff;
    border: 1px solid var(--pk-ws-border);
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-mp-section-head {
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-mp-section-head span {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: #64748b;
}
.pk01-mp-section-head h2 {
    margin: 3px 0 0 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-mp-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
}
.pk01-action-link {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: #f8fafc;
    border: 1px solid var(--pk-ws-border);
    border-radius: 10px;
    text-decoration: none !important;
    color: #0f172a;
    font-size: 13px;
    font-weight: 700;
    transition: all 0.15s ease;
}
.pk01-action-link:hover {
    background: #0f172a;
    color: #ffffff !important;
    border-color: #0f172a;
    transform: translateX(2px);
}
.pk01-action-link b {
    color: #2563eb;
    font-size: 14px;
}
.pk01-action-link:hover b { color: #ffffff; }

/* Admin Role Preview Grid */
.pk01-role-preview-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-top: 14px;
}
.pk01-role-preview-card {
    background: #f8fafc;
    border: 1px solid var(--pk-ws-border);
    border-radius: 10px;
    padding: 12px 14px;
    text-decoration: none !important;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: all 0.15s ease;
}
.pk01-role-preview-card:hover {
    background: #ffffff;
    border-color: #3b82f6;
    box-shadow: 0 4px 10px rgba(0,0,0,0.04);
}
.pk01-role-preview-card span {
    font-size: 12px;
    font-weight: 700;
    color: #0f172a;
}
.pk01-role-preview-card strong {
    font-size: 12px;
    color: #2563eb;
    margin: 6px 0 2px;
}
.pk01-role-preview-card small {
    font-size: 10px;
    color: #64748b;
}

/* Architecture Flow Footer */
.pk01-mp-flow {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;
    padding: 14px 18px;
    background: #ffffff;
    border: 1px dashed var(--pk-ws-border);
    border-radius: 12px;
    font-size: 11px;
    font-weight: 800;
    color: #64748b;
    letter-spacing: 0.8px;
}
.pk01-mp-flow span {
    background: #f1f5f9;
    padding: 4px 8px;
    border-radius: 4px;
    color: #334155;
}
.pk01-mp-flow i {
    font-style: normal;
    color: #94a3b8;
}

.pk01-smart-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0 0 20px}.pk01-smart-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:16px}.pk01-smart-card .label{font-size:10px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.7px}.pk01-smart-card strong{display:block;font-size:22px;margin-top:6px;color:#0f172a}.pk01-smart-card small{display:block;color:#64748b;margin-top:5px}.pk01-smart-panel{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:18px;margin-bottom:20px}.pk01-smart-columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:14px}.pk01-smart-list{margin:10px 0 0;padding:0;list-style:none}.pk01-smart-list li{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid #eef2f7;font-size:12px}.pk01-smart-list li:last-child{border-bottom:0}.pk01-smart-table{width:100%;border-collapse:collapse;font-size:12px;margin-top:12px}.pk01-smart-table th,.pk01-smart-table td{text-align:left;padding:8px;border-bottom:1px solid #eef2f7}.pk01-smart-table th{background:#f8fafc;color:#475569}.pk01-smart-badge{display:inline-block;padding:3px 7px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-weight:700;font-size:10px}.pk01-smart-badge.warn{background:#fffbeb;color:#b45309}.pk01-smart-badge.danger{background:#fef2f2;color:#b91c1c}@media(max-width:1000px){.pk01-smart-grid{grid-template-columns:repeat(2,1fr)}.pk01-smart-columns{grid-template-columns:1fr}}@media(max-width:560px){.pk01-smart-grid{grid-template-columns:1fr}}
</style>

<div class="pk01-masterpiece-dashboard">
    
    <!-- 1. HERO COCKPIT PERAN AKTIF -->
    <header class="pk01-mp-hero">
        <div>
            <span class="pk01-mp-eyebrow"><?php echo esc_html($p['ey']); ?></span>
            <h1><?php echo esc_html($p['title']); ?></h1>
            <p><?php echo esc_html($p['desc']); ?></p>
        </div>
        <div class="pk01-mp-user">
            <span>PERAN AKTIF</span>
            <strong><?php echo esc_html($label); ?></strong>
            <small><?php echo esc_html(wp_date('d M Y &bull; H:i', $now)); ?> WIB</small>
        </div>
    </header>

    <!-- 2. RADAR OPERASIONAL: hanya dashboard manajerial -->
    <?php if (in_array($role, ['administrator','pk01_admin','pk01_owner','shop_manager','pk01_keuangan'], true)): ?>
    <section class="pk01-radar-strip">
        <a href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('sales_hub')); ?>" class="pk01-radar-chip <?php echo $vals['pending_orders'] > 0 ? 'has-alert' : ''; ?>">
            🛒 Pesanan Menunggu: <b><?php echo number_format($vals['pending_orders']); ?></b>
        </a>
        <a href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('production_hub')); ?>" class="pk01-radar-chip">
            🏭 Job Produksi Aktif: <b><?php echo number_format($vals['jobs']); ?></b>
        </a>
        <a href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('inventory')); ?>" class="pk01-radar-chip <?php echo $vals['critical'] > 0 ? 'has-danger' : ''; ?>">
            🪵 Bahan Kritis: <b><?php echo number_format($vals['critical']); ?></b>
        </a>
        <a href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('shipping_hub')); ?>" class="pk01-radar-chip">
            🚚 Pengiriman Berjalan: <b><?php echo number_format($vals['shipments']); ?></b>
        </a>
    </section>
    <?php endif; ?>

    <!-- 3. AI OPERATIONS COPILOT (TERINTEGRASI CONTEXT-AWARE) -->
    <section class="pk01-mp-ai">
        <div>
            <span>AI OPERATIONS COPILOT</span>
            <h2>Prioritas Kerja &amp; Panduan Tindakan Hari Ini</h2>
            <p>
                Asisten AI membaca konteks data transaksi PK01 khusus untuk wewenang <strong><?php echo esc_html($label); ?></strong>. 
                AI bertindak sebagai penasihat operasional tanpa merubah mutasi buku kas atau data transaksi langsung.
            </p>
        </div>
        <a href="<?php echo esc_url($ai_url); ?>" class="pk01-ai-btn">
            ✨ Analisis dengan AI &rarr;
        </a>
    </section>

    <?php if ($smart_enabled): ?>
    <section class="pk01-smart-panel">
      <div class="pk01-mp-section-head"><div><span>SMART CONTROL TOWER</span><h2>Pantauan Bisnis Terpadu</h2><p>Hanya membaca data transaksi dan master PK01 yang tersedia. Tidak membuat order, seller, retur, stok, job, atau nominal contoh.</p></div></div>
      <div class="pk01-smart-grid">
        <div class="pk01-smart-card"><span class="label">Retur Perlu Perhatian</span><strong><?php echo number_format($smart['returns_count']); ?></strong><small>Nilai refund tercatat: <?php echo esc_html($money($smart['returns_value'])); ?></small></div>
        <div class="pk01-smart-card"><span class="label">Piutang Seller Belum Dibayar</span><strong><?php echo esc_html($money($smart['seller_unpaid'])); ?></strong><small><?php echo number_format($smart['seller_unpaid_count']); ?> invoice masih bersisa</small></div>
        <div class="pk01-smart-card"><span class="label">Job Produksi Aktif</span><strong><?php echo number_format(count($smart['active_jobs'])); ?></strong><small>Prioritas dan deadline dari Job nyata</small></div>
        <div class="pk01-smart-card"><span class="label">Stok Bahan Aktif</span><strong><?php echo esc_html(number_format($smart['stock_total'],2,',','.')); ?></strong><small><?php echo number_format($smart['stock_critical']); ?> bahan di bawah/minimum</small></div>
      </div>
      <div class="pk01-smart-columns">
        <div><h3>🏆 Seller Penjualan Terbesar</h3><ul class="pk01-smart-list"><?php if(!$smart['top_sellers']): ?><li><span>Belum ada transaksi Seller.</span></li><?php else: foreach($smart['top_sellers'] as $r): ?><li><span><b><?php echo esc_html($r['name']); ?></b><small style="display:block;color:#64748b"><?php echo esc_html($r['code']); ?> · <?php echo number_format((int)$r['orders']); ?> order</small></span><strong><?php echo esc_html($money($r['total_sales'])); ?></strong></li><?php endforeach; endif; ?></ul></div>
        <div><h3>↩️ Seller Paling Banyak Retur</h3><ul class="pk01-smart-list"><?php if(!$smart['top_return_sellers']): ?><li><span>Belum ada retur Seller yang terhubung.</span></li><?php else: foreach($smart['top_return_sellers'] as $r): ?><li><span><b><?php echo esc_html($r['name']); ?></b><small style="display:block;color:#64748b"><?php echo esc_html($r['code']); ?> · <?php echo number_format((int)$r['return_count']); ?> retur</small></span><strong><?php echo esc_html($money($r['return_value'])); ?></strong></li><?php endforeach; endif; ?></ul></div>
      </div>
      <div class="pk01-smart-columns">
        <div><h3>⚠️ Seller dengan Piutang Terbesar</h3><ul class="pk01-smart-list"><?php if(!$smart['top_unpaid_sellers']): ?><li><span>Tidak ada piutang Seller yang tersisa.</span></li><?php else: foreach($smart['top_unpaid_sellers'] as $r): ?><li><span><b><?php echo esc_html($r['name']); ?></b><small style="display:block;color:#64748b"><?php echo esc_html($r['code']); ?> · <?php echo number_format((int)$r['invoice_count']); ?> invoice bersisa</small></span><strong><?php echo esc_html($money($r['unpaid_amount'])); ?></strong></li><?php endforeach; endif; ?></ul></div>
        <div><h3>🔥 Produk Paling Terjual</h3><ul class="pk01-smart-list"><?php if(!$smart['top_products']): ?><li><span>Belum ada data penjualan produk.</span></li><?php else: foreach($smart['top_products'] as $r): ?><li><span><b><?php echo esc_html($r['product_name']); ?></b><small style="display:block;color:#64748b">Omzet <?php echo esc_html($money($r['revenue'])); ?></small></span><strong><?php echo esc_html(number_format((float)$r['qty_sold'],0,',','.')); ?> unit</strong></li><?php endforeach; endif; ?></ul></div>
      </div>
      <div style="margin-top:16px"><h3>🛒 Seller per Marketplace</h3><div style="overflow:auto"><table class="pk01-smart-table"><thead><tr><th>Marketplace</th><th>Seller</th><th>Order</th><th>Penjualan</th></tr></thead><tbody><?php if(!$smart['marketplace_sellers']): ?><tr><td colspan="4">Belum ada penjualan marketplace yang terhubung ke Seller.</td></tr><?php else: foreach($smart['marketplace_sellers'] as $r): ?><tr><td><span class="pk01-smart-badge"><?php echo esc_html(strtoupper($r['marketplace'])); ?></span></td><td><b><?php echo esc_html($r['seller_name']); ?></b><small style="display:block;color:#64748b"><?php echo esc_html($r['seller_code']); ?></small></td><td><?php echo number_format((int)$r['orders']); ?></td><td><b><?php echo esc_html($money($r['total_sales'])); ?></b></td></tr><?php endforeach; endif; ?></tbody></table></div></div>
      <div style="margin-top:16px"><h3>🏭 Job yang Sedang Dikerjakan</h3><div style="overflow:auto"><table class="pk01-smart-table"><thead><tr><th>Job</th><th>Status</th><th>Target</th><th>Deadline</th></tr></thead><tbody><?php if(!$smart['active_jobs']): ?><tr><td colspan="4">Tidak ada job produksi aktif.</td></tr><?php else: foreach($smart['active_jobs'] as $r): ?><tr><td><b><?php echo esc_html($r['job_no']); ?></b></td><td><span class="pk01-smart-badge <?php echo in_array($r['priority'],['urgent','high'],true)?'warn':''; ?>"><?php echo esc_html(strtoupper($r['status'])); ?></span></td><td><?php echo esc_html($r['target_qty'] ?? '-'); ?></td><td><?php echo esc_html($r['deadline'] ?? '-'); ?></td></tr><?php endforeach; endif; ?></tbody></table></div></div>
    </section>
    <?php endif; ?>

    <?php if ($role === 'administrator' && $is_admin): ?>
    <!-- PRODUCT MASTER: pintu yang jelas untuk upload produk ke seluruh ekosistem PK01 -->
    <section class="pk01-mp-section pk01-product-master-launcher">
        <div class="pk01-mp-section-head">
            <div>
                <span>MASTER PRODUK</span>
                <h2>Produk Website &amp; SKU</h2>
                <p>Semua produk dibuat atau di-upload di <strong>Master Produk PK01</strong>. Setelah berstatus aktif dan lengkap, data yang sama dibaca langsung oleh E-Commerce/Theme, katalog Seller, order, stok, Produksi, dan marketplace.</p>
            </div>
            <a class="pk01-action-link" href="<?php echo esc_url($product_master_url); ?>"><span>📥 Buka Master Produk &amp; Upload</span><b>↗</b></a>
        </div>
        <div class="pk01-mp-actions">
            <a class="pk01-action-link" href="<?php echo esc_url($product_master_url); ?>"><span>📥 Upload CSV Product Master</span><b>↗</b></a>
            <a class="pk01-action-link" href="<?php echo esc_url($product_master_url); ?>#pk01-manual-product"><span>➕ Tambah Produk Manual + Gambar</span><b>↗</b></a>
            <a class="pk01-action-link" href="<?php echo esc_url($storefront_url); ?>" target="_blank" rel="noopener"><span>🌐 Lihat Website / Theme</span><b>↗</b></a>
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px;">
            <div style="padding:12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;"><small>Total Produk Master</small><strong style="display:block;font-size:20px;"><?php echo number_format($product_master_count); ?></strong></div>
            <div style="padding:12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;"><small>Produk Aktif di Website</small><strong style="display:block;font-size:20px;"><?php echo number_format($product_active_count); ?></strong></div>
            <div style="padding:12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;"><small>SKU Aktif</small><strong style="display:block;font-size:20px;"><?php echo number_format($product_variant_count); ?></strong></div>
        </div>
        <div style="margin-top:10px;padding:10px 12px;border-radius:9px;background:#ecfdf5;border:1px solid #bbf7d0;color:#166534;font-size:12px;">
            <strong>Alur yang benar:</strong> Master Produk → Produk aktif → Theme/E-Commerce membaca katalog → Seller &amp; Marketplace memakai SKU yang sama. <strong>Tidak ada upload produk master dari Seller atau Marketplace.</strong>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($role === 'pk01_seller'): ?>
    <section class="pk01-mp-section pk01-seller-marketplace-launcher">
        <div class="pk01-mp-section-head"><div><span>JUAL DI MARKETPLACE</span><h2>Download Katalog untuk Seller Center</h2><p>Produk dibuat Admin di Master Produk PK01. Seller mengatur harga marketplace lalu mengunduh file untuk di-upload ke Seller Center.</p></div><a class="pk01-action-link" href="<?php echo esc_url($seller_dashboard_portal_url); ?>"><span>📦 Buka Katalog Lengkap</span><b>↗</b></a></div>
        <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;">
        <?php foreach ($seller_dashboard_marketplaces as $mk=>$ml): $tpl=PK01_Marketplace_Catalog::get_template($mk); $ready=!empty($tpl['verified']); $preview=class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview(); $token=!empty($seller_dashboard_account['portal_token']) ? $seller_dashboard_account['portal_token'] : ''; $export_url=$seller_dashboard_portal_url; if(!$preview && $token!=='') $export_url=add_query_arg(['pk01_seller'=>$token,'pk01_catalog_export'=>'1','marketplace'=>$mk],$export_url); ?>
            <div style="border:1px solid #e2e8f0;border-radius:14px;padding:15px;background:#fff;"><strong style="display:block;font-size:15px;"><?php echo esc_html($ml); ?></strong><small style="display:block;color:#64748b;margin:5px 0 12px;"><?php echo $ready ? 'Template siap digunakan' : 'Template resmi belum dipasang Admin'; ?></small>
                <?php if ($preview): ?><span style="display:block;padding:9px 10px;border-radius:9px;background:#f1f5f9;color:#64748b;font-size:12px;">👁 Mode Preview — download dinonaktifkan</span>
                <?php elseif ($ready && $token!==''): ?><a class="pk01-action-link" href="<?php echo esc_url($export_url); ?>"><span>⬇ Download Semua SKU</span><b>↓</b></a><a class="pk01-action-link" style="margin-top:7px;" href="<?php echo esc_url($seller_dashboard_portal_url); ?>"><span>☑ Pilih SKU</span><b>→</b></a>
                <?php else: ?><span style="display:block;padding:9px 10px;border-radius:9px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;font-size:12px;">⏳ Menunggu template resmi dari Admin</span><?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
        <div style="margin-top:12px;padding:11px 13px;border-radius:10px;background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;font-size:12px;"><strong>Alur:</strong> Master Produk PK01 → Katalog Seller → Harga Marketplace → Download CSV/XLSX → Seller upload ke Seller Center. HPP internal tidak diekspor.</div>
    </section>
    <?php endif; ?>

    <?php if ($role === 'administrator' && $is_admin && class_exists('PK01_Marketplace_Catalog')): ?>
    <section class="pk01-mp-section pk01-marketplace-template-launcher">
        <div class="pk01-mp-section-head"><div><span>MARKETPLACE</span><h2>Template Upload Marketplace</h2><p>Admin memasang template resmi terbaru dari Seller Center. Setelah dipetakan dan diverifikasi, Seller baru dapat men-download katalog.</p></div><a class="pk01-action-link" href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('system') . '#tab-marketplace-source'); ?>"><span>🧩 Kelola Template</span><b>↗</b></a></div>
        <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;"><?php foreach (PK01_Marketplace_Catalog::marketplaces() as $mk=>$ml): $mt=PK01_Marketplace_Catalog::get_template($mk); ?><div style="padding:12px;border:1px solid #e2e8f0;border-radius:11px;background:#f8fafc;"><strong><?php echo esc_html($ml); ?></strong><span style="display:block;margin-top:5px;font-size:12px;"><?php echo !empty($mt['verified']) ? '✅ Siap untuk Seller' : '⚠️ Belum siap'; ?></span></div><?php endforeach; ?></div>
    </section>
    <?php endif; ?>

    <?php if ($role === 'administrator' && $is_admin): ?>
    <section class="pk01-mp-section pk01-real-system-cockpit">
        <div class="pk01-mp-section-head">
            <div><span>SMART REAL-DATA CONTROL</span><h2>Aktivitas Nyata Sistem</h2><p>Angka berikut dihitung langsung dari database PK01. Tidak ada angka demo, transaksi contoh, atau generator data.</p></div>
            <a class="pk01-action-link" href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('system')); ?>#tab-data-health"><span>🩺 Cek Kesehatan Data</span><b>↗</b></a>
        </div>
        <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;">
            <div style="padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;"><small>TRANSAKSI PENJUALAN SEPANJANG WAKTU</small><strong style="display:block;font-size:28px;margin-top:5px;"><?php echo number_format($real_sales_total); ?></strong><span style="font-size:12px;color:#64748b;">Valid/non-batal: <?php echo number_format($real_sales_valid); ?></span></div>
            <div style="padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;"><small>JOB PRODUKSI YANG PERNAH DIBUAT</small><strong style="display:block;font-size:28px;margin-top:5px;"><?php echo number_format($real_jobs_total); ?></strong><span style="font-size:12px;color:#64748b;">Selesai: <?php echo number_format($real_jobs_finished); ?></span></div>
            <div style="padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;"><small>BARIS DATA LENGKAP</small><strong style="display:block;font-size:28px;margin-top:5px;"><?php echo number_format($real_rows_complete); ?> / <?php echo number_format($real_rows_total); ?></strong><span style="font-size:12px;color:#64748b;">Kelengkapan: <?php echo number_format($real_completeness,1,',','.'); ?>%</span></div>
            <div style="padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;"><small>STATUS DATA</small><strong style="display:block;font-size:22px;margin-top:9px;"><?php echo esc_html($real_snapshot['health_status'] ?? 'BELUM DIPERIKSA'); ?></strong><span style="font-size:12px;color:#64748b;">Skor: <?php echo $real_snapshot['health_score']===null?'—':number_format((float)$real_snapshot['health_score'],0).'%'; ?></span></div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 4. KARTU METRIK UTAMA DINAMIS SESUAI ROLE -->

    <section class="pk01-mp-kpis">
        <?php
        $seller_kpi_tabs = [
            'seller_net_sales'=>'tab-period-history',
            'seller_returns'=>'tab-financial-report',
            'seller_invoice_unpaid'=>'tab-invoices',
            'seller_invoice_paid'=>'tab-invoices',
            'seller_target_progress'=>'tab-period-history',
            'seller_bonus_due'=>'tab-commissions',
        ];
        foreach ($p['cards'] as $c): 
            $v = $vals[$c[2]] ?? 0; 
            $is_currency = in_array($c[2], ['sales', 'profit', 'cash', 'wages_due', 'wages', 'receivable', 'seller_net_sales', 'seller_returns', 'seller_invoice_unpaid', 'seller_invoice_paid', 'seller_bonus_due'], true);
            $display = $is_currency ? $money($v) : number_format((float)$v); 
        ?>
            <?php $kpi_url = PK01_Shortcodes::frontend_url_public($c[0]); if ($role === 'pk01_seller' && isset($seller_kpi_tabs[$c[2]])) $kpi_url .= '#'.$seller_kpi_tabs[$c[2]]; ?>
            <a href="<?php echo esc_url($kpi_url); ?>" class="pk01-mp-kpi">
                <span><?php echo esc_html($c[1]); ?></span>
                <strong><?php echo esc_html($display); ?></strong>
                <small>Buka modul &rarr;</small>
            </a>
        <?php endforeach; ?>
    </section>

    <!-- 5. KHUSUS ADMINISTRATOR: SIMULASI PRATINJAU PERAN TANPA LOGOUT -->
    <?php if ($is_admin && in_array($role, ['administrator'], true)): ?>
    <section class="pk01-mp-section">
        <div class="pk01-mp-section-head">
            <div>
                <span>ADMIN CONTROL SUITE</span>
                <h2>Pusat Pratinjau Seluruh Dashboard & Peran</h2>
                <p>Administrator dapat melihat seluruh dashboard dari satu tempat. Pratinjau hanya mengubah tampilan dashboard; akun, permission, dan hak akses Administrator tetap tidak berubah. Semua perubahan data dikunci.</p>
            </div>
        </div>
        
        <div class="pk01-role-preview-grid">
            <?php
            $preview_roles = [
                'administrator'=>['Administrator','Control Tower penuh','dashboard'],
                'pk01_admin'=>['Admin Operasional','Semua alur operasional','dashboard'],
                'pk01_owner'=>['Owner / Pemilik','Kendali eksekutif','owner_dashboard'],
                'shop_manager'=>['Manajer Operasional','Kendali lintas pekerjaan','dashboard'],
                'pk01_kasir'=>['Kasir','Penjualan & Order Seller','dashboard'],
                'pk01_seller'=>['Seller','Dashboard Seller: katalog, order & marketplace','dashboard'],
                'pk01_gudang'=>['Gudang','Stok & Fulfillment','dashboard'],
                'pk01_produksi'=>['Produksi','SPK & Produksi','dashboard'],
                'pk01_packing'=>['Packing','Packing & Kemas','dashboard'],
                'pk01_logistik'=>['Logistik','Pengiriman & Resi','dashboard'],
                'pk01_keuangan'=>['Keuangan','Kas, laporan & piutang','dashboard'],
                'pk01_hr'=>['SDM','Karyawan & Payroll','dashboard'],
                'pk01_customer_service'=>['Customer Service','Layanan & komunikasi','dashboard'],
                'pk01_security'=>['Security','Keamanan operasional','security'],
                'pk01_employee'=>['Pekerja / Operator','Job Saya','dashboard'],
                'pk01_investor'=>['Investor','Ringkasan investasi','dashboard'],
            ];
            foreach ($preview_roles as $preview_slug => $meta):
                if ($preview_slug !== 'administrator' && !get_role($preview_slug)) continue;
                $preview_url = ($preview_slug === 'administrator') ? remove_query_arg('pk01_role_preview') : (class_exists('PK01_Authorization') ? PK01_Authorization::role_preview_url($preview_slug) : add_query_arg('pk01_role_preview', $preview_slug));
                if ($preview_slug !== 'administrator' && $meta[2] !== 'dashboard') $preview_url = add_query_arg('pk01_view', $meta[2], $preview_url);
            ?>
                <a class="pk01-role-preview-card" href="<?php echo esc_url($preview_url); ?>">
                    <span><?php echo esc_html($meta[0]); ?></span>
                    <strong>Lihat Dashboard &rarr;</strong>
                    <small><?php echo esc_html($meta[1]); ?> · Pratinjau Tampilan</small>
                </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($is_admin && $role === 'administrator'): ?>
    <section class="pk01-mp-section pk01-admin-dashboard-inventory">
        <div class="pk01-mp-section-head"><div><span>ADMIN READ-ONLY VIEW</span><h2>Seluruh Dashboard Dapat Diperiksa</h2><p>Setiap kartu membuka dashboard dengan perspektif role terkait. Mode ini hanya membaca data nyata dan tidak mengubah akun, permission, transaksi, stok, kas, atau konfigurasi.</p></div></div>
        <div class="pk01-role-preview-grid">
        <?php
        $all_preview_roles = [
            'pk01_admin'=>'Admin Operasional','pk01_owner'=>'Owner / Pemilik','pk01_investor'=>'Investor','shop_manager'=>'Manajer Operasional','pk01_kasir'=>'Kasir','pk01_seller'=>'Seller','pk01_gudang'=>'Gudang','pk01_produksi'=>'Produksi','pk01_packing'=>'Packing','pk01_logistik'=>'Logistik','pk01_keuangan'=>'Keuangan','pk01_hr'=>'SDM','pk01_customer_service'=>'Customer Service','pk01_security'=>'Security','pk01_employee'=>'Pekerja / Operator'
        ];
        foreach ($all_preview_roles as $slug=>$name):
            if (!get_role($slug)) continue;
            $u = class_exists('PK01_Authorization') ? PK01_Authorization::role_preview_url($slug) : add_query_arg('pk01_role_preview',$slug);
        ?>
            <a class="pk01-role-preview-card" href="<?php echo esc_url($u); ?>"><span><?php echo esc_html($name); ?></span><strong>👁 Lihat Dashboard</strong><small>Read-only · data nyata · tanpa mutasi</small></a>
        <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- 6. PINTASAN TINDAKAN SESUAI WEWENANG TUGAS -->
    <section class="pk01-mp-section">
        <div class="pk01-mp-section-head">
            <div>
                <span>MENU UTAMA</span>
                <h2>Pilih Pekerjaan Anda</h2>
            </div>
        </div>
        
        <div class="pk01-mp-actions">
            <?php foreach ($p['actions'] as $a):
                if (!$is_admin && class_exists('PK01_Authorization') && !PK01_Authorization::can($a[0])) continue;
                $action_url = PK01_Shortcodes::frontend_url_public($a[0]);
                if (!empty($a[2])) $action_url .= '#'.sanitize_key($a[2]);
            ?>
                <a href="<?php echo esc_url($action_url); ?>" class="pk01-action-link">
                    <span><?php echo esc_html($a[1]); ?></span>
                    <b>↗</b>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- 7. DIAGRAM TEKNIS: hanya tampil pada Administrator agar dashboard pekerjaan tetap sederhana. -->
    <?php if ($role === 'administrator' && $is_admin): ?>
    <footer class="pk01-mp-flow" aria-label="Alur Integritas Sistem">
        <span>DATABASE TRANSAKSI</span><i>&rarr;</i>
        <span>AI ANALISIS</span><i>&rarr;</i>
        <span>REKOMENDASI KERJA</span><i>&rarr;</i>
        <span>OTORISASI PENGGUNA</span><i>&rarr;</i>
        <span>ENGINE OPERASIONAL</span><i>&rarr;</i>
        <span>AUDIT TRAIL</span>
    </footer>
    <?php endif; ?>

</div>