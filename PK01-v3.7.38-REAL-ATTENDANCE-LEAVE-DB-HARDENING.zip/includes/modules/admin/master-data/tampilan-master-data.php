<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin && class_exists('PK01_Authorization') && !PK01_Authorization::can('master_data')) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🚫</div>
            <h3 style="margin:0 0 6px;color:#991b1b;font-size:17px;font-weight:800;">Akses Dibatasi</h3>
            <p style="margin:0;color:#64748b;font-size:13px;">Anda tidak memiliki izin otorisasi yang memadai untuk mengelola Master Data PK01.</p>
          </div>';
    return;
}

// 2. HELPER DETEKSI TABEL DATABASE PK01
$get_table = function($key) use ($wpdb) {
    $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
};

// 3. IDENTIFIKASI TABEL RIIL
$tbl_emp = $get_table('employees');
$tbl_mat = $get_table('materials');
$tbl_prd = $get_table('product_variants') ?: ($get_table('variants') ?: $get_table('products'));
$tbl_sup = $get_table('suppliers');
$tbl_cus = $get_table('customers');
$tbl_slr = $get_table('sales_accounts') ?: $get_table('sellers');

// Hitung Statistik Data Riil
$count_emp = $tbl_emp ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_emp}` WHERE status = 'active'") : 0;
$count_mat = $tbl_mat ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_mat}`") : 0;
$count_prd = $tbl_prd ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_prd}`" . ($tbl_prd === $get_table('products') ? "" : " WHERE status = 'active'")) : 0;
$count_sup = $tbl_sup ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_sup}`") : 0;
$count_cus = $tbl_cus ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_cus}`") : 0;
$count_slr = $tbl_slr ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_slr}` WHERE status = 'active'") : 0;

// 4. DAFTAR MASTER TAB & META CONFIG
$allowed = [
    'employees' => [
        'label'      => 'Karyawan & Upah',
        'icon'       => '👥',
        'count'      => $count_emp,
        'unit'       => 'Staf Aktif',
        'table'      => $tbl_emp,
        'module_key' => 'employees',
        'color'      => 'indigo',
        'desc'       => 'Master staf, sistem upah bulanan, harian & borongan multi-job'
    ],
    'materials' => [
        'label'      => 'Bahan Baku Gudang',
        'icon'       => '🪵',
        'count'      => $count_mat,
        'unit'       => 'Item Bahan',
        'table'      => $tbl_mat,
        'module_key' => 'materials',
        'color'      => 'emerald',
        'desc'       => 'Master stok bahan mentah, satuan gudang & estimasi harga pokok'
    ],
    'products'  => [
        'label'      => 'Produk & Varian SKU',
        'icon'       => '📦',
        'count'      => $count_prd,
        'unit'       => 'SKU Siap Jual',
        'table'      => $tbl_prd,
        'module_key' => 'products',
        'color'      => 'purple',
        'desc'       => 'Katalog produk jadi, variasi ukuran/warna, dan barcode SKU'
    ],
    'suppliers' => [
        'label'      => 'Pemasok (Vendor)',
        'icon'       => '🏢',
        'count'      => $count_sup,
        'unit'       => 'Vendor Bahan',
        'table'      => $tbl_sup,
        'module_key' => 'suppliers',
        'color'      => 'amber',
        'desc'       => 'Daftar supplier rekanan, nomor kontak dan riwayat pembelian PO'
    ],
    'customers' => [
        'label'      => 'Data Pelanggan',
        'icon'       => '🛒',
        'count'      => $count_cus,
        'unit'       => 'Kontak Pembeli',
        'table'      => $tbl_cus,
        'module_key' => 'customers',
        'color'      => 'rose',
        'desc'       => 'Buku alamat pelanggan, tier harga diskon, & histori pemesanan'
    ],
    'sellers'   => [
        'label'      => 'Mitra & Reseller',
        'icon'       => '🤝',
        'count'      => $count_slr,
        'unit'       => 'Mitra Aktif',
        'table'      => $tbl_slr,
        'module_key' => 'seller_register',
        'color'      => 'sky',
        'desc'       => 'Akun distributor, komisi penjualan dan izin channel distribusi'
    ],
    'pricing'   => [
        'label'      => 'Matriks Harga & Margin',
        'icon'       => '🏷️',
        'count'      => null,
        'unit'       => 'Konfigurasi',
        'table'      => null,
        'module_key' => 'pricing',
        'color'      => 'blue',
        'desc'       => 'Tabel penetapan margin laba kotor & tiering harga bertingkat'
    ]
];

// Identifikasi Tab Aktif
$current_tab = sanitize_key($_GET['master_tab'] ?? 'employees');
if (!array_key_exists($current_tab, $allowed)) {
    $current_tab = 'employees';
}

$active_cfg = $allowed[$current_tab];
$current_page_url = remove_query_arg(['edit_id', 'id', 'paged', 'action']);

// 5. FITUR EKSPOR CSV OTOMATIS BERDASARKAN TAB AKTIF
if (isset($_POST['pk01_export_master_csv']) && check_admin_referer('pk01_export_master_nonce')) {
    if (!empty($active_cfg['table'])) {
        $export_data = $wpdb->get_results("SELECT * FROM `{$active_cfg['table']}` ORDER BY id DESC LIMIT 500", ARRAY_A);
        if (!empty($export_data)) {
            $filename = 'pk01-master-' . $current_tab . '-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            
            // Header baris
            fputcsv($out, array_keys($export_data[0]));
            foreach ($export_data as $row) {
                fputcsv($out, array_values($row));
            }
            fclose($out);
            exit;
        }
    }
}
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-emerald:   #10b981;
    --pk-purple:    #8b5cf6;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
    --pk-elevated:  0 12px 24px -4px rgb(0 0 0 / 0.08), 0 4px 8px -2px rgb(0 0 0 / 0.04);
}

.pk01-mst-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-mst-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Glassmorphism */
.pk01-mst-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-content h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-content p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}

/* System Health Card */
.pk01-health-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 18px;
    text-align: right;
    min-width: 190px;
    backdrop-filter: blur(6px);
}
.pk01-health-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #4ade80;
    font-size: 11.5px;
    font-weight: 700;
}
.pk01-ping-dot {
    width: 8px;
    height: 8px;
    background: #4ade80;
    border-radius: 50%;
    animation: pkPulse 2s infinite;
}
@keyframes pkPulse {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 6 KPI Cards */
.pk01-kpi-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 12px;
    margin-bottom: 22px;
}
@media (max-width: 1200px) { .pk01-kpi-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 640px) { .pk01-kpi-grid { grid-template-columns: repeat(2, 1fr); } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 14px 16px;
    box-shadow: var(--pk-shadow);
    text-decoration: none !important;
    color: inherit;
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: all 0.2s ease;
}
.pk01-kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--pk-elevated);
    border-color: var(--pk-indigo);
}
.pk01-kpi-card.is-active {
    border-color: var(--pk-indigo);
    background: #fdfefe;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; height: 3.5px;
}
.pk01-kpi-card.c-indigo::before { background: var(--pk-indigo); }
.pk01-kpi-card.c-emerald::before { background: var(--pk-emerald); }
.pk01-kpi-card.c-purple::before { background: var(--pk-purple); }
.pk01-kpi-card.c-amber::before { background: var(--pk-amber); }
.pk01-kpi-card.c-rose::before { background: var(--pk-rose); }
.pk01-kpi-card.c-sky::before { background: var(--pk-sky); }

.pk01-kpi-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 11px;
    font-weight: 700;
    color: var(--pk-slate-600);
    text-transform: uppercase;
}
.pk01-kpi-val {
    font-size: 22px;
    font-weight: 800;
    color: var(--pk-slate-900);
    margin: 6px 0 2px;
    line-height: 1;
}
.pk01-kpi-sub {
    font-size: 11px;
    color: var(--pk-slate-600);
}

/* 3. Modern Tab Navigation */
.pk01-tabs-deck {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    text-decoration: none !important;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-link:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-link.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}
.pk01-tab-count {
    font-size: 11px;
    padding: 2px 7px;
    border-radius: 10px;
    font-weight: 700;
    background: #e2e8f0;
    color: #334155;
}
.pk01-tab-link.is-active .pk01-tab-count {
    background: rgba(255, 255, 255, 0.2);
    color: #ffffff;
}

/* 4. Contextual Toolbar */
.pk01-sub-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    gap: 12px;
    flex-wrap: wrap;
}
.pk01-sub-title h2 {
    margin: 0;
    font-size: 18px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-sub-title p {
    margin: 2px 0 0;
    font-size: 12.5px;
    color: var(--pk-slate-600);
}

.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #fff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; border: 1px solid #cbd5e1; color: #334155 !important; }
.pk01-btn-subtle:hover { background: #f8fafc; border-color: #94a3b8; }

/* 5. Autonomous Built-in Data Grid */
.pk01-surface-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    box-shadow: var(--pk-shadow);
    overflow: hidden;
}
.pk01-table-scroll {
    overflow-x: auto;
    width: 100%;
}
.pk01-data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-data-table th {
    background: #f8fafc;
    padding: 12px 16px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-data-table td {
    padding: 12px 16px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
    color: #334155;
}
.pk01-data-table tr:hover td { background: #fbfcfe; }

.pk01-badge-code {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
}
.pk01-pill-status {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-pill-status.active { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.pk01-pill-status.inactive { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
</style>

<div class="pk01-mst-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-mst-hero">
        <div class="pk01-hero-content">
            <span class="pk01-hero-badge">ENTERPRISE REPOSITORY &bull; RELATIONAL MASTER CORE</span>
            <h1>🏛️ Pusat Master Data Terpadu</h1>
            <p>
                Satu sumber kebenaran data (*Single Source of Truth*) yang mengikat modul <strong>Produksi SPK, Payroll Upah, Pergudangan Bahan, Kasir Faktur, dan Logistik Armada</strong> tanpa redudansi entri.
            </p>
        </div>

        <div class="pk01-health-widget">
            <div class="pk01-health-indicator">
                <span class="pk01-ping-dot"></span>
                <span>INTEGRITAS DATABASE VALID</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:4px;">
                Sinkronisasi: <b>Real-time DB</b>
            </div>
        </div>
    </header>

    <!-- 2. 6 INTERACTIVE KPI CARDS -->
    <div class="pk01-kpi-grid">
        <?php foreach ($allowed as $k => $c): 
            if ($k === 'pricing') continue; 
            $is_kpi_active = ($current_tab === $k);
        ?>
            <a href="<?php echo esc_url(add_query_arg('master_tab', $k, $current_page_url)); ?>" 
               class="pk01-kpi-card c-<?php echo esc_attr($c['color']); ?> <?php echo $is_kpi_active ? 'is-active' : ''; ?>">
                <div class="pk01-kpi-head">
                    <span><?php echo esc_html($c['label']); ?></span>
                    <span><?php echo esc_html($c['icon']); ?></span>
                </div>
                <div class="pk01-kpi-val"><?php echo number_format((int)$c['count']); ?></div>
                <div class="pk01-kpi-sub"><?php echo esc_html($c['unit']); ?></div>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- 3. TABS NAVIGASI UTAMA -->
    <nav class="pk01-tabs-deck">
        <?php foreach ($allowed as $tab_key => $tab_data): 
            $is_active = ($current_tab === $tab_key);
            $target_url = add_query_arg('master_tab', $tab_key, $current_page_url);
        ?>
            <a href="<?php echo esc_url($target_url); ?>" class="pk01-tab-link <?php echo $is_active ? 'is-active' : ''; ?>">
                <span><?php echo esc_html($tab_data['icon']); ?></span>
                <span><?php echo esc_html($tab_data['label']); ?></span>
                <?php if ($tab_data['count'] !== null): ?>
                    <span class="pk01-tab-count"><?php echo number_format($tab_data['count']); ?></span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <!-- 4. CONTEXTUAL SUB-TOOLBAR -->
    <div class="pk01-sub-toolbar">
        <div class="pk01-sub-title">
            <h2>
                <span><?php echo esc_html($active_cfg['icon']); ?></span>
                <span><?php echo esc_html($active_cfg['label']); ?></span>
            </h2>
            <p><?php echo esc_html($active_cfg['desc']); ?></p>
        </div>

        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
            <?php if ($current_tab === 'products'): ?>
                <a href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('products')); ?>" class="pk01-btn" style="text-decoration:none;background:#2563eb;color:#fff;border-color:#2563eb;">＋ Tambah / Upload Produk Master</a>
            <?php endif; ?>
            <?php if (!empty($active_cfg['table'])): ?>
                <form method="post" style="margin:0;">
                    <?php wp_nonce_field('pk01_export_master_nonce'); ?>
                    <input type="hidden" name="pk01_export_master_csv" value="1">
                    <button type="submit" class="pk01-btn pk01-btn-subtle" title="Ekspor dataset master ke file Excel / CSV">
                        📥 Ekspor Master (.CSV)
                    </button>
                </form>
            <?php endif; ?>
            
            <input type="search" id="pk01_master_search" class="pk01-btn-subtle" placeholder="🔍 Cari data..." style="padding:7px 12px; border-radius:8px; width:220px;">
        </div>
    </div>

    <!-- 5. MULTI-PATH RESOLVER & AUTONOMOUS BUILT-IN DATA VIEWER -->
    <main class="pk01-master-stage">
        <?php
        // A. Coba cari file views resmi via Registry
        $resolved_path = null;
        $module_key = $active_cfg['module_key'] ?? '';

        if ($module_key && class_exists('PK01_Module_Registry') && method_exists('PK01_Module_Registry', 'view_path')) {
            $resolved_path = PK01_Module_Registry::view_path($module_key);
        }

        // B. Coba cari file konvensional di dalam folder plugin jika registry tidak menemukan
        if (!$resolved_path || !file_exists($resolved_path)) {
            $candidate_locations = [
                PK01_DIR . 'includes/' . $module_key . '.php',
                PK01_DIR . 'includes/admin/' . $module_key . '.php',
                PK01_DIR . 'modules/' . $module_key . '/' . $module_key . '.php',
                PK01_DIR . 'views/' . $module_key . '.php',
                PK01_DIR . 'templates/' . $module_key . '.php',
            ];
            foreach ($candidate_locations as $cand) {
                if (file_exists($cand)) {
                    $resolved_path = $cand;
                    break;
                }
            }
        }

        // C. Eksekusi File Jika Ditemukan
        if ($resolved_path && file_exists($resolved_path)) {
            try {
                include $resolved_path;
            } catch (Throwable $e) {
                echo '<div class="pk01-surface-card" style="padding:24px;border-left:4px solid #ef4444;margin-top:14px;">
                        <h4 style="margin:0 0 6px;color:#991b1b;">⚠️ Kendala Teknis Saat Memuat Modul (' . esc_html($active_cfg['label']) . ')</h4>
                        <p style="margin:0;font-size:13px;color:#64748b;">' . esc_html($e->getMessage()) . '</p>
                      </div>';
            }
        } else {
            // D. AUTONOMOUS BUILT-IN DATA ENGINE (Tampil Otomatis Tanpa Error)
            $table_name = $active_cfg['table'];
            
            if ($table_name && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) === $table_name) {
                $raw_items = $wpdb->get_results("SELECT * FROM `{$table_name}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
                ?>
                <div class="pk01-surface-card">
                    <div style="padding:16px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:13px; font-weight:700; color:#334155;">
                            ⚡ Built-in Autonomous View &bull; <?php echo count($raw_items); ?> Entri Terkini
                        </span>
                        <span style="font-size:11.5px; color:#64748b;">Tabel DB: <code><?php echo esc_html($table_name); ?></code></span>
                    </div>

                    <?php if (empty($raw_items)): ?>
                        <div style="text-align:center; padding:50px 20px; color:#94a3b8;">
                            <div style="font-size:38px; margin-bottom:8px;">📁</div>
                            Belum ada baris data tersimpan di tabel master <strong><?php echo esc_html($active_cfg['label']); ?></strong>.
                        </div>
                    <?php else: 
                        $fields = array_keys($raw_items[0]);
                        // Filter kolom prioritas
                        $display_fields = array_slice($fields, 0, 7);
                    ?>
                        <div class="pk01-table-scroll">
                            <table class="pk01-data-table" id="pk01-master-datatable">
                                <thead>
                                    <tr>
                                        <?php foreach ($display_fields as $col): ?>
                                            <th><?php echo esc_html(strtoupper(str_replace('_', ' ', $col))); ?></th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($raw_items as $item): ?>
                                        <tr>
                                            <?php foreach ($display_fields as $col): 
                                                $val = $item[$col] ?? '';
                                                $is_code = in_array($col, ['code', 'sku', 'ref_code', 'id'], true);
                                                $is_money = in_array($col, ['price', 'rate', 'cost', 'amount'], true);
                                                $is_status = in_array($col, ['status', 'active'], true);
                                            ?>
                                                <td>
                                                    <?php if ($is_code): ?>
                                                        <span class="pk01-badge-code"><?php echo esc_html($val); ?></span>
                                                    <?php elseif ($is_money): ?>
                                                        <strong style="font-family:monospace; color:#059669;">
                                                            Rp <?php echo number_format((float)$val, 0, ',', '.'); ?>
                                                        </strong>
                                                    <?php elseif ($is_status): 
                                                        $st_act = in_array(strtolower((string)$val), ['active', '1', 'published'], true);
                                                    ?>
                                                        <span class="pk01-pill-status <?php echo $st_act ? 'active' : 'inactive'; ?>">
                                                            ● <?php echo esc_html(ucfirst((string)$val)); ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <?php echo esc_html(mb_strimwidth((string)$val, 0, 45, '…')); ?>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            } else {
                ?>
                <div class="pk01-surface-card" style="padding:48px 24px; text-align:center;">
                    <div style="font-size:42px; margin-bottom:12px;">⚙️</div>
                    <h3 style="margin:0 0 6px; font-size:18px; font-weight:800; color:#0f172a;">
                        Modul Konfigurasi <?php echo esc_html($active_cfg['label']); ?>
                    </h3>
                    <p style="color:#64748b; font-size:13px; max-width:520px; margin:0 auto; line-height:1.6;">
                        Tabel atau berkas konfigurasi khusus untuk modul ini dapat diatur melalui pengaturan global sistem PK01.
                    </p>
                </div>
                <?php
            }
        }
        ?>
    </main>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Live Search Otomatis untuk Built-in Table
    var searchInput = document.getElementById('pk01_master_search');
    var dataTable   = document.getElementById('pk01-master-datatable');

    if (searchInput && dataTable) {
        searchInput.addEventListener('input', function() {
            var term = this.value.toLowerCase().trim();
            var rows = dataTable.querySelectorAll('tbody tr');

            rows.forEach(function(r) {
                var text = r.innerText.toLowerCase();
                r.style.display = (text.indexOf(term) > -1) ? '' : 'none';
            });
        });
    }
});
</script>