<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_url = remove_query_arg(['edit_id']);
$current_month = current_time('Y-m');

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('seller') || PK01_Authorization::can('sales')));

// 2. DETEKSI TABEL-TABEL TERKAIT SECARA DINAMIS
$get_table = function($key) use ($wpdb) {
    $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
};

$tbl_sellers      = $get_table('sales_accounts') ?: ($get_table('sellers') ?: $wpdb->prefix . 'pk01_sellers');
$tbl_sales_orders = $get_table('sales_orders') ?: ($get_table('orders') ?: $wpdb->prefix . 'pk01_sales_orders');
$tbl_shipments    = $get_table('shipments') ?: $wpdb->prefix . 'pk01_shipments';
$tbl_orders       = $get_table('seller_orders');
$tbl_invoices     = $get_table('seller_invoices');
$tbl_payments     = $get_table('seller_payments');
$tbl_variants     = $get_table('product_variants') ?: $get_table('variants');
$tbl_targets      = $get_table('seller_targets');
$tbl_bonus        = $get_table('seller_bonus_ledger');
$tbl_logs         = $get_table('logs') ?: ($get_table('activity_logs') ?: $wpdb->prefix . 'pk01_activity_logs');
$tbl_ledger       = $get_table('cash_ledger');

// AUTO-CREATE TABEL INVOICE & PEMBAYARAN KONSINYASI JIKA BELUM TERSEDIA
if ($tbl_invoices && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_invoices)) !== $tbl_invoices) {
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe("CREATE TABLE `{$tbl_invoices}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `invoice_no` varchar(100) NOT NULL,
        `seller_account_id` bigint(20) unsigned NOT NULL,
        `total` decimal(15,2) NOT NULL DEFAULT 0.00,
        `status` varchar(50) NOT NULL DEFAULT 'unpaid',
        `due_date` date DEFAULT NULL,
        `notes` text DEFAULT NULL,
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `seller_account_id` (`seller_account_id`)
    ) {$charset};");
}

if ($tbl_payments && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_payments)) !== $tbl_payments) {
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe("CREATE TABLE `{$tbl_payments}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `invoice_id` varchar(100) NOT NULL,
        `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
        `payment_method` varchar(100) DEFAULT 'Transfer Bank',
        `paid_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `invoice_id` (`invoice_id`)
    ) {$charset};");
}

// 3. EKSPOR REKAP SELLER KE CSV
if (isset($_POST['pk01_export_sellers_csv']) && check_admin_referer('pk01_export_sellers_nonce')) {
    if ($can_manage && $tbl_sellers) {
        $export_sellers = $wpdb->get_results(
            "SELECT s.id, s.code, s.name, s.phone, s.email, s.commission_percent, s.active,
                    COALESCE(SUM(o.total_amount), 0) AS total_omzet,
                    COALESCE(SUM(o.commission), 0) AS total_komisi,
                    COUNT(o.id) AS total_transaksi
             FROM `{$tbl_sellers}` s
             LEFT JOIN `{$tbl_sales_orders}` o ON o.seller_id = s.id AND o.status NOT IN ('cancelled','batal','failed')
             WHERE s.type = 'seller'
             GROUP BY s.id
             ORDER BY total_omzet DESC",
            ARRAY_A
        );
        if (!empty($export_sellers)) {
            $filename = 'pk01-rekap-mitra-seller-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Peringkat', 'Kode Seller', 'Nama Mitra', 'WhatsApp', 'Email', 'Komisi (%)', 'Total Omzet (Rp)', 'Total Komisi (Rp)', 'Order Selesai', 'Status']);
            $rank = 1;
            foreach ($export_sellers as $r) {
                fputcsv($out, [
                    '#' . $rank++,
                    $r['code'],
                    $r['name'],
                    $r['phone'],
                    $r['email'],
                    $r['commission_percent'] . '%',
                    $r['total_omzet'],
                    $r['total_komisi'],
                    $r['total_transaksi'],
                    $r['active'] ? 'Aktif' : 'Nonaktif'
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. PROSES AKSI FORMULIR (CRUD, APPROVE, REJECT, ORDER, HANDOVER, BAYAR HUTANG, CAIRKAN KOMISI)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_seller_action_type'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_seller_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_seller_manage_action')) {
        $notice = '<div class="pk01-slr-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        $action_type = sanitize_key($_POST['pk01_seller_action_type']);
        try {
            // A. SIMPAN / EDIT SELLER
            if ($action_type === 'save' || $action_type === 'create') {
                $id         = absint($_POST['seller_id'] ?? 0);
                $name       = sanitize_text_field(wp_unslash($_POST['seller_name'] ?? ''));
                $code       = sanitize_text_field(wp_unslash($_POST['seller_code'] ?? ''));
                $phone      = sanitize_text_field(wp_unslash($_POST['seller_phone'] ?? ''));
                $email      = sanitize_email(wp_unslash($_POST['seller_email'] ?? ''));
                $commission = (float) sanitize_text_field($_POST['seller_commission'] ?? 0);
                $affiliate  = (float) sanitize_text_field($_POST['seller_affiliate'] ?? 0);
                $payment_term_days = max(0, absint($_POST['seller_payment_term_days'] ?? 0));
                $payment_term_label = sanitize_text_field(wp_unslash($_POST['seller_payment_term_label'] ?? 'Langsung / COD'));
                $is_active  = isset($_POST['seller_active']) ? 1 : 0;

                if (empty($code)) {
                    $prefix = get_option('pk01_seller_prefix', 'SLR');
                    $digits = absint(get_option('pk01_seller_digits', 4));
                    $total_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_sellers}`");
                    $code = $prefix . '-' . current_time('y') . '-' . str_pad((string)($total_count + 1), $digits, '0', STR_PAD_LEFT);
                }

                if (empty($name)) throw new Exception('Nama lengkap mitra seller wajib diisi.');

                if ($action_type === 'save' && $id > 0) {
                    if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_update')) {
                        PK01_Engine::seller_update($id, $name, $code, $phone, $email, $commission, $affiliate, $is_active, $payment_term_days, $payment_term_label);
                    } else {
                        $wpdb->update($tbl_sellers, [
                            'name'               => $name,
                            'code'               => $code,
                            'phone'              => $phone,
                            'email'              => $email,
                            'commission_percent' => $commission,
                            'affiliate_percent'  => $affiliate,
                            'payment_term_days' => $payment_term_days,
                            'payment_term_label'=> $payment_term_label,
                            'active'             => $is_active,
                            'updated_at'         => current_time('mysql')
                        ], ['id' => $id]);
                    }
                    $notice = '<div class="pk01-slr-alert is-success">✅ Data mitra seller <strong>' . esc_html($name) . '</strong> berhasil diperbarui.</div>';
                } else {
                    if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_create')) {
                        PK01_Engine::seller_create($name, $code, $phone, $email, $commission, $affiliate, $payment_term_days, $payment_term_label);
                    } else {
                        $wpdb->insert($tbl_sellers, [
                            'type'                => 'seller',
                            'name'                => $name,
                            'code'                => $code,
                            'phone'               => $phone,
                            'email'               => $email,
                            'commission_percent'  => $commission,
                            'affiliate_percent'   => $affiliate,
                            'payment_term_days'  => $payment_term_days,
                            'payment_term_label' => $payment_term_label,
                            'registration_status' => 'active',
                            'active'              => 1,
                            'portal_token'        => wp_generate_password(24, false),
                            'created_at'          => current_time('mysql')
                        ]);
                    }
                    $notice = '<div class="pk01-slr-alert is-success">✅ Mitra seller baru <strong>' . esc_html($name) . ' (' . esc_html($code) . ')</strong> berhasil didaftarkan.</div>';
                }
            }
            // B. APPROVE PENDAFTARAN
            elseif ($action_type === 'approve') {
                $target_id = absint($_POST['target_id'] ?? 0);
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_approve')) {
                    PK01_Engine::seller_approve($target_id, true);
                } else {
                    $wpdb->update($tbl_sellers, ['registration_status' => 'active', 'active' => 1], ['id' => $target_id]);
                }
                $notice = '<div class="pk01-slr-alert is-success">✅ Pendaftaran mitra seller disetujui &amp; akun telah aktif.</div>';
            }
            // C. TOLAK PENDAFTARAN
            elseif ($action_type === 'reject') {
                $target_id = absint($_POST['target_id'] ?? 0);
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_approve')) {
                    PK01_Engine::seller_approve($target_id, false);
                } else {
                    $wpdb->update($tbl_sellers, ['registration_status' => 'rejected', 'active' => 0], ['id' => $target_id]);
                }
                $notice = '<div class="pk01-slr-alert is-error">⚠️ Pendaftaran mitra seller telah ditolak.</div>';
            }
            // D. TERBITKAN FAKTUR TAGIHAN KONSINYASI — SATU SUMBER DI ENGINE
            elseif ($action_type === 'create_invoice') {
                $s_id=absint($_POST['inv_seller_id'] ?? 0); $inv_no=strtoupper(sanitize_text_field(trim($_POST['inv_no'] ?? '')));
                $total=(float)sanitize_text_field($_POST['inv_total'] ?? 0); $due_date=sanitize_text_field($_POST['inv_due_date'] ?? date('Y-m-d',strtotime('+14 days')));
                $notes=sanitize_textarea_field(wp_unslash($_POST['inv_notes'] ?? ''));
                if($s_id<=0||$total<=0) throw new Exception('Pilih seller dan masukkan total tagihan barang konsinyasi.');
                throw new Exception('Tagihan Seller dibuat otomatis dari penjualan/order Seller. Gunakan menu Penjualan Seller, bukan membuat tagihan manual.');
                $invoice=$wpdb->get_row($wpdb->prepare("SELECT invoice_no FROM `{$tbl_invoices}` WHERE id=%d",$id),ARRAY_A);
                $notice='<div class="pk01-slr-alert is-success">✅ Faktur tagihan <strong>'.esc_html($invoice['invoice_no']??$inv_no).'</strong> sebesar <b>Rp '.number_format($total,0,',','.').'</b> berhasil diterbitkan.</div>';
            }
            // E. SETORAN CICILAN / PELUNASAN HUTANG SELLER — CASH DICATAT ENGINE SEKALI
            elseif ($action_type === 'pay_balance') {
                $seller_id=absint($_POST['pay_balance_seller_id'] ?? 0); $amount=(float)sanitize_text_field($_POST['pay_balance_amount'] ?? 0);
                $method=sanitize_text_field(wp_unslash($_POST['pay_balance_method'] ?? 'Transfer Bank'));
                if($seller_id<=0||$amount<=0) throw new Exception('Seller dan nominal pembayaran wajib valid.');
                $ref=sanitize_text_field(wp_unslash($_POST['pay_balance_reference']??''));
                $r=PK01_Engine::submit_cashier_deposit($amount,stripos($method,'kas')!==false?'cash':'transfer',stripos($method,'kas')!==false?'Kas Tunai Toko':'Bank Seller / Bukti Transfer','Kas/Bank Keuangan',$method,$ref,'Pembayaran Seller diajukan dari Manajemen Seller; menunggu maker-checker Keuangan.', $seller_id, 0, 0);
                $notice='<div class="pk01-slr-alert is-success">📨 Setoran Seller <b>'.esc_html($r['deposit_no']).'</b> sebesar <b>Rp '.number_format($amount,0,',','.').'</b> diajukan. AR belum dipotong sampai Keuangan menyetujui dan menerima.</div>';
            }
            elseif ($action_type === 'pay') {
                $inv_id=absint($_POST['pay_invoice_id'] ?? 0); $amount=(float)sanitize_text_field($_POST['pay_amount'] ?? 0);
                $method=sanitize_text_field(wp_unslash($_POST['pay_method'] ?? 'Transfer Bank'));
                if($amount<=0) throw new Exception('Nominal pembayaran setoran harus lebih besar dari Rp 0.');
                $ref=sanitize_text_field(wp_unslash($_POST['pay_reference']??''));
                $r=PK01_Engine::submit_cashier_deposit($amount,stripos($method,'kas')!==false?'cash':'transfer',stripos($method,'kas')!==false?'Kas Tunai Toko':'Bank Seller / Bukti Transfer','Kas/Bank Keuangan',$method,$ref,'Pembayaran Seller per invoice diajukan; menunggu maker-checker Keuangan.', 0, $inv_id, 0);
                $notice='<div class="pk01-slr-alert is-success">📨 Setoran Seller <b>'.esc_html($r['deposit_no']).'</b> diajukan ke Keuangan. AR belum dipotong sampai disetujui dan diterima.</div>';
            }
            // F. BAYAR / CAIRKAN KOMISI SELLER — SATU PINTU KAS
            elseif ($action_type === 'pay_commission') {
                $order_id=absint($_POST['commission_order_id'] ?? 0); $comm_val=(float)sanitize_text_field($_POST['commission_amount'] ?? 0);
                $method=sanitize_text_field(wp_unslash($_POST['commission_method'] ?? 'Transfer Bank'));
                if($order_id<=0||$comm_val<=0) throw new Exception('Order dan nominal komisi wajib valid.');
                PK01_Engine::pay_seller_order_commission($order_id,$comm_val,$method);
                $notice='<div class="pk01-slr-alert is-success">✅ Komisi seller sebesar <b>Rp '.number_format($comm_val,0,',','.').'</b> berhasil dicairkan dan dicatat satu kali di kas keluar.</div>';
            }
            // G. SERAH TERIMA BARANG GUDANG KE SELLER
            elseif ($action_type === 'handover') {
                $order_id = absint($_POST['handover_order_id'] ?? 0);
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_fulfill_order')) {
                    PK01_Engine::seller_fulfill_order($order_id);
                } elseif ($tbl_orders) {
                    $wpdb->update($tbl_orders, ['status' => 'fulfilled', 'fulfilled_at' => current_time('mysql')], ['id' => $order_id]);
                }
                $notice = '<div class="pk01-slr-alert is-success">✅ Serah terima barang selesai. Stok tercatat ke inventaris seller.</div>';
            }

            $_POST = [];
        } catch (Throwable $e) {
            $notice = '<div class="pk01-slr-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 5. PROSES SIMPAN TARGET PENJUALAN
$target_notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_seller_target_save'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_seller_target_nonce'] ?? '')), 'pk01_seller_target_save')) {
        $target_notice = '<div class="pk01-slr-alert is-error">⚠️ Sesi keamanan target tidak valid.</div>';
    } else {
        try {
            $sid    = absint($_POST['target_seller_id'] ?? 0);
            $period = sanitize_text_field($_POST['target_period'] ?? current_time('Y-m'));
            $target = (float)$_POST['target_amount'];
            $bt     = sanitize_key($_POST['bonus_type'] ?? 'fixed');
            $bv     = (float)$_POST['bonus_value'];
            $ptype  = in_array($_POST['participant_type'] ?? 'seller', ['seller', 'marketing'], true) ? $_POST['participant_type'] : 'seller';

            PK01_Engine::set_seller_target($sid, $period, $target, $bt, $bv, $ptype);
            $target_notice = '<div class="pk01-slr-alert is-success">✅ Target penjualan periode ' . esc_html($period) . ' berhasil ditetapkan!</div>';
        } catch (Throwable $e) {
            $target_notice = '<div class="pk01-slr-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 6. AMBIL DATA EDIT SELLER
$edit_id = absint($_GET['edit_id'] ?? 0);
$edit = null;
if ($edit_id > 0 && $tbl_sellers) {
    $edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_sellers}` WHERE id = %d", $edit_id), ARRAY_A);
}

// 7. STATISTIK KEUANGAN SELLER REAL (ZERO DUMMY DATA)
$sellers = [];
$pending_reg = [];
$leaderboard_rankings = [];

if ($tbl_sellers) {
    $sellers = $wpdb->get_results("SELECT * FROM `{$tbl_sellers}` WHERE type = 'seller' ORDER BY id DESC", ARRAY_A) ?: [];
    $pending_reg = $wpdb->get_results("SELECT * FROM `{$tbl_sellers}` WHERE type = 'seller' AND registration_status = 'pending' ORDER BY id DESC", ARRAY_A) ?: [];

    // Hitung Leaderboard Bulan Ini
    $leaderboard_query = "SELECT s.id, s.code, s.name, s.commission_percent,
                                 COALESCE(SUM(o.total_amount), 0) AS total_omzet,
                                 COALESCE(SUM(o.commission), 0) AS total_komisi,
                                 COUNT(o.id) AS total_orders
                          FROM `{$tbl_sellers}` s
                          LEFT JOIN `{$tbl_sales_orders}` o ON o.seller_id = s.id 
                               AND o.status NOT IN ('cancelled','batal','failed')
                               AND DATE_FORMAT(o.created_at, '%%Y-%%m') = %s
                          WHERE s.type = 'seller' AND s.active = 1
                          GROUP BY s.id
                          ORDER BY total_omzet DESC";

    $leaderboard_rankings = $wpdb->get_results($wpdb->prepare($leaderboard_query, $current_month), ARRAY_A) ?: [];
}

// Ranking Map
$seller_rank_map = [];
$rank_counter = 1;
foreach ($leaderboard_rankings as $lr) {
    $seller_rank_map[(int)$lr['id']] = [
        'rank'   => $rank_counter++,
        'omzet'  => (float)$lr['total_omzet'],
        'komisi' => (float)$lr['total_komisi'],
        'orders' => (int)$lr['total_orders']
    ];
}

// 8. HITUNG HUTANG SELLER KE TOKO (KONSINYASI/OFFLINE) & KOMISI BELUM DIBAYAR KE SELLER
$total_invoiced_all    = 0;
$total_paid_by_sellers = 0;
$invoices_list         = [];

if ($tbl_invoices && $tbl_sellers) {
    $invoices_raw = $wpdb->get_results(
        "SELECT i.*, s.name AS seller_name, s.code AS seller_code, s.phone AS seller_phone,
                COALESCE((SELECT SUM(amount) FROM `{$tbl_payments}` WHERE invoice_id = i.id), 0) AS total_paid
         FROM `{$tbl_invoices}` i
         JOIN `{$tbl_sellers}` s ON s.id = i.seller_account_id
         ORDER BY i.id DESC LIMIT 100",
        ARRAY_A
    ) ?: [];

    foreach ($invoices_raw as $inv) {
        $tot  = (float)($inv['total'] ?? 0);
        $paid = (float)($inv['total_paid'] ?? 0);
        $rem  = max(0, $tot - $paid);
        $total_invoiced_all    += $tot;
        $total_paid_by_sellers += $paid;
        $inv['remaining_debt']  = $rem;
        $invoices_list[]        = $inv;
    }
}
$total_seller_debt_remaining = max(0, $total_invoiced_all - $total_paid_by_sellers);

// Hitung Komisi yang Belum Dibayar ke Seller
$pending_commissions_val = 0;
$paid_commissions_val    = 0;
if ($tbl_sales_orders) {
    $pending_commissions_val = (float) $wpdb->get_var(
        "SELECT COALESCE(SUM(commission), 0) FROM `{$tbl_sales_orders}` 
         WHERE seller_id > 0 
         AND LOWER(COALESCE(commission_status, 'pending')) IN ('pending', 'unpaid', '') 
         AND status NOT IN ('cancelled', 'batal', 'failed')"
    );

    $paid_commissions_val = (float) $wpdb->get_var(
        "SELECT COALESCE(SUM(commission), 0) FROM `{$tbl_sales_orders}` 
         WHERE seller_id > 0 
         AND LOWER(COALESCE(commission_status, '')) = 'paid' 
         AND status NOT IN ('cancelled', 'batal', 'failed')"
    );
}

// 9. KUERI HISTORI PENJUALAN SELLER + TRACKING KURIR REAL
$filter_year  = sanitize_text_field($_GET['filter_year'] ?? current_time('Y'));
$filter_month = sanitize_text_field($_GET['filter_month'] ?? current_time('m'));
$filter_sid   = absint($_GET['filter_seller_id'] ?? 0);

$where_orders = " WHERE o.seller_id > 0 ";
if ($filter_sid > 0) {
    $where_orders .= $wpdb->prepare(" AND o.seller_id = %d ", $filter_sid);
}
if ($filter_year !== 'all' && is_numeric($filter_year)) {
    $where_orders .= $wpdb->prepare(" AND YEAR(o.created_at) = %d ", (int)$filter_year);
}
if ($filter_month !== 'all' && is_numeric($filter_month)) {
    $where_orders .= $wpdb->prepare(" AND MONTH(o.created_at) = %d ", (int)$filter_month);
}

$seller_sales_records = [];
if ($tbl_sales_orders && $tbl_sellers) {
    $seller_sales_records = $wpdb->get_results(
        "SELECT o.*, s.name AS seller_name, s.code AS seller_code,
                sh.courier AS ship_courier, sh.tracking_no AS ship_awb, sh.status AS ship_status, sh.last_event_at
         FROM `{$tbl_sales_orders}` o 
         JOIN `{$tbl_sellers}` s ON s.id = o.seller_id 
         LEFT JOIN `{$tbl_shipments}` sh ON (sh.sale_id = o.id OR (sh.tracking_no = o.tracking_no AND o.tracking_no != ''))
         {$where_orders} 
         ORDER BY o.id DESC LIMIT 150", 
        ARRAY_A
    ) ?: [];
}

// 10. ANTREAN SERAH TERIMA GUDANG KE SELLER
$pending_orders = [];
if ($tbl_orders && $tbl_sellers) {
    $pending_orders = $wpdb->get_results(
        "SELECT o.*, s.name as seller_name 
         FROM `{$tbl_orders}` o 
         INNER JOIN `{$tbl_sellers}` s ON s.id = o.seller_account_id 
         WHERE o.status IN ('requested', 'menunggu_gudang') 
         ORDER BY o.id DESC", 
        ARRAY_A
    ) ?: [];
}

$variants = [];
if ($tbl_variants) {
    $variants = $wpdb->get_results("SELECT id, sku, name, hpp FROM `{$tbl_variants}` WHERE status = 'active' ORDER BY name ASC", ARRAY_A) ?: [];
}

$active_sellers_count = count(array_filter($sellers, function($s) { return !empty($s['active']); }));

$format_money = function($val) {
    return class_exists('PK01_Settings') && method_exists('PK01_Settings', 'money')
        ? PK01_Settings::money($val) 
        : 'Rp ' . number_format((float)$val, 0, ',', '.');
};
?>

<style>
:root {
    --pk-slr-navy: #0f172a;
    --pk-slr-border: #e2e8f0;
    --pk-slr-blue: #2563eb;
    --pk-slr-green: #059669;
    --pk-slr-amber: #d97706;
    --pk-slr-purple: #7c3aed;
    --pk-slr-red: #dc2626;
}

.pk01-seller-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-seller-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-slr-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #312e81 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-slr-eyebrow {
    display: inline-block;
    background: rgba(99, 102, 241, 0.2);
    color: #a5b4fc;
    border: 1px solid rgba(165, 180, 252, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-slr-hero h1 { margin: 0 0 6px 0; font-size: 24px; font-weight: 800; color: #f8fafc; }
.pk01-slr-hero p { margin: 0; font-size: 13px; color: #cbd5e1; max-width: 820px; line-height: 1.5; }

/* 4 Executive KPI Cards (Lengkap dengan Hutang Seller & Komisi Pending) */
.pk01-slr-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; }
.pk01-kpi-card.c-red    { border-left-color: var(--pk-slr-red); }
.pk01-kpi-card.c-green  { border-left-color: var(--pk-slr-green); }
.pk01-kpi-card.c-amber  { border-left-color: var(--pk-slr-amber); }
.pk01-kpi-card.c-blue   { border-left-color: var(--pk-slr-blue); }

.pk01-kpi-card small { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; display: block; }
.pk01-kpi-card strong { font-size: 22px; font-weight: 800; color: #0f172a; display: block; margin: 6px 0 2px 0; }
.pk01-kpi-card span { font-size: 11px; color: #64748b; }

/* Leaderboard Strip */
.pk01-leaderboard-strip {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 14px;
    padding: 18px 22px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-leaderboard-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 8px; }
.pk01-leaderboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 12px; }
.pk01-rank-podium { background: #f8fafc; border: 1px solid var(--pk-slr-border); border-radius: 10px; padding: 12px 14px; display: flex; align-items: center; gap: 12px; }
.pk01-rank-podium.rank-1 { background: #fffdf5; border-color: #fde047; }
.pk01-rank-podium.rank-2 { background: #f8fafc; border-color: #cbd5e1; }
.pk01-rank-podium.rank-3 { background: #fffaf5; border-color: #fed7aa; }
.pk01-medal-icon { font-size: 24px; flex-shrink: 0; }
.pk01-rank-info strong { display: block; font-size: 13px; color: #0f172a; }

/* Tab Switcher */
.pk01-slr-tabs {
    display: flex;
    gap: 8px;
    border-bottom: 2px solid var(--pk-slr-border);
    margin-bottom: 22px;
    overflow-x: auto;
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 18px;
    font-size: 13px;
    font-weight: 700;
    color: #64748b;
    border: none;
    background: transparent;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    margin-bottom: -2px;
    transition: all .15s ease;
    white-space: nowrap;
}
.pk01-tab-btn:hover { color: #0f172a; }
.pk01-tab-btn.active { color: var(--pk-slr-blue); border-bottom-color: var(--pk-slr-blue); }

.pk01-tab-pane { display: none; }
.pk01-tab-pane.active { display: block; animation: pk01Fade .2s ease-in-out; }
@keyframes pk01Fade { from { opacity: 0; transform: translateY(3px); } to { opacity: 1; transform: translateY(0); } }

/* Surface Card */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-head h3 { margin: 0; font-size: 17px; font-weight: 800; color: #0f172a; }

/* Table Style */
.pk01-table-wrap { overflow-x: auto; border: 1px solid var(--pk-slr-border); border-radius: 12px; }
.pk01-slr-table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
.pk01-slr-table th { background: #f8fafc; padding: 11px 12px; font-weight: 700; color: #475569; border-bottom: 2px solid var(--pk-slr-border); }
.pk01-slr-table td { padding: 11px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.pk01-slr-table tr:hover td { background: #fbfcfe; }

/* Badges & Buttons */
.pk01-badge { display: inline-block; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; }
.badge-success { background: #dcfce7; color: #166534; }
.badge-warning { background: #fef3c7; color: #92400e; }
.badge-danger  { background: #fee2e2; color: #991b1b; }
.badge-info    { background: #e0e7ff; color: #3730a3; }

.pk01-btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; text-decoration: none !important; }
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-track   { background: #2563eb; color: #ffffff !important; padding: 4px 10px; font-size: 11px; border-radius: 6px; }

.pk01-input { width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 13px; background: #f8fafc; }
.pk01-input:focus { outline: none; border-color: #2563eb; background: #ffffff; }

.pk01-slr-alert { padding: 12px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; margin-bottom: 20px; }
.pk01-slr-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-slr-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-seller-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-slr-hero">
        <div>
            <span class="pk01-slr-eyebrow">SELLER CENTER &bull; LOGISTICS &amp; FINANCIAL RECONCILIATION</span>
            <h1>Pusat Manajemen Mitra Seller &amp; Piutang Konsinyasi</h1>
            <p>
                Kelola jaringan penjual, pelacakan kurir ekspedisi real-time, transparansi tagihan saldo tagihan Seller, 
                serta pembukuan pencairan komisi penjualan secara otomatis dan terintegrasi ke Buku Kas.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_sellers_nonce'); ?>
                <input type="hidden" name="pk01_export_sellers_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Rekap Seller &amp; Rank (.CSV)
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL (TERHUBUNG KE HUTANG SELLER & KOMISI PENDING) -->
    <div class="pk01-slr-kpis">
        <div class="pk01-kpi-card c-red">
            <small>Sisa Hutang Seller ke Toko Kita</small>
            <strong style="color:#dc2626;"><?php echo $format_money($total_seller_debt_remaining); ?></strong>
            <span>Total tagihan penjualan Seller belum disetor</span>
        </div>

        <div class="pk01-kpi-card c-green">
            <small>Setoran Seller yang Sudah Kita Terima</small>
            <strong style="color:#059669;"><?php echo $format_money($total_paid_by_sellers); ?></strong>
            <span>Uang fisik/transfer yang telah masuk ke kas toko</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Komisi Seller Belum Dibayarkan</small>
            <strong style="color:#d97706;"><?php echo $format_money($pending_commissions_val); ?></strong>
            <span>Kewajiban komisi yang menunggu pencairan</span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Total Komisi Seller yang Sudah Cair</small>
            <strong style="color:#1d4ed8;"><?php echo $format_money($paid_commissions_val); ?></strong>
            <span>Hak mitra yang telah dibayarkan oleh toko</span>
        </div>
    </div>

    <!-- 3. TOP LEADERBOARD PODIUM SELLER (MOTIVASI JUARA JUALAN) -->
    <?php if (!empty($leaderboard_rankings)): ?>
    <section class="pk01-leaderboard-strip">
        <div class="pk01-leaderboard-head">
            <div>
                <strong style="font-size:15px;color:#0f172a;">🏆 Papan Peringkat Penjualan Seller Terbaik (Bulan Ini: <?php echo date_i18n('F Y'); ?>)</strong>
                <span style="display:block;font-size:12px;color:#64748b;">Peringkat dihitung otomatis dari akumulasi omzet penjualan pesanan nyata.</span>
            </div>
            <span style="font-size:12px;background:#eff6ff;color:#1e40af;font-weight:700;padding:4px 10px;border-radius:20px;">
                Total Seller Aktif: <?php echo count($leaderboard_rankings); ?> Mitra
            </span>
        </div>

        <div class="pk01-leaderboard-grid">
            <?php 
            foreach (array_slice($leaderboard_rankings, 0, 3) as $i => $lr):
                $medal_class = 'rank-' . ($i + 1);
            ?>
                <div class="pk01-rank-podium <?php echo esc_attr($medal_class); ?>">
                    <div class="pk01-medal-icon"><?php echo ($i === 0) ? '🥇' : (($i === 1) ? '🥈' : '🥉'); ?></div>
                    <div class="pk01-rank-info">
                        <strong><?php echo esc_html($lr['name']); ?></strong>
                        <span>Kode: <code><?php echo esc_html($lr['code']); ?></code> &bull; <b><?php echo (int)$lr['total_orders']; ?> Order</b></span>
                        <div style="margin-top:4px;font-size:13px;font-family:monospace;font-weight:800;color:#047857;">
                            <?php echo esc_html($format_money($lr['total_omzet'])); ?>
                        </div>
                        <span style="font-size:10px;color:#7c3aed;">Komisi: <?php echo esc_html($format_money($lr['total_komisi'])); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- 4. TABS NAVIGASI WORKSPACE LENGKAP -->
    <nav class="pk01-slr-tabs" aria-label="Navigasi Mitra Seller">
        <button type="button" class="pk01-tab-btn active" data-target="tab-debt-invoices">
            🧾 Rincian Tagihan &amp; Hutang Seller (<?php echo count($invoices_list); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-shipping-tracking">
            🚚 Status Pengiriman &amp; Resi Kurir (<?php echo count($seller_sales_records); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-history">
            📅 Histori Omzet &amp; Komisi per Periode
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-sellers">
            👥 Direktori Seller &amp; Peringkat
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-circulation">
            📦 Alokasi Stok Gudang &amp; Serah Terima
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-targets">
            🎯 Target Penjualan &amp; Bonus
        </button>
    </nav>

    <!-- TAB 1: BUKU TAGIHAN & HUTANG SELLER KE KITA (LENGKAP & TRANSPARAN) -->
    <div class="pk01-tab-pane active" id="tab-debt-invoices">
        <section class="pk01-surface" style="border-left:4px solid #dc2626;">
            <div class="pk01-surface-head">
                <div>
                    <h3>🧾 Kontrol Tagihan &amp; Tagihan Seller Seller ke Toko Kita</h3>
                    <p>
                        Setiap tagihan barang yang diambil seller dicatat secara transparan. Anda dapat melihat <strong>berapa yang sudah disetorkan</strong>, 
                        dan <strong>berapa sisa hutang yang masih harus dibayarkan seller</strong> ke kas kita.
                    </p>
                </div>
                <div>
                    <button type="button" class="pk01-btn pk01-btn-primary" onclick="alert('Tagihan Seller dibuat otomatis saat penjualan Seller dicatat. Tidak ada tagihan manual.');">
                        Tagihan dibuat otomatis dari Penjualan Seller
                    </button>
                </div>
            </div>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 16px;margin-bottom:18px;color:#475569;font-size:12px;line-height:1.6;">
                <strong style="color:#0f172a;">Alur tagihan otomatis:</strong> Penjualan Seller yang benar-benar dicatat di PK01 akan membuat tagihan berdasarkan harga internal Seller. Tidak ada tombol pembuatan tagihan manual agar angka AR tidak dapat dibuat tanpa transaksi. Retur yang sudah diterima Gudang mengurangi tagihan; pembayaran Seller mengurangi saldo tagihan secara keseluruhan.
            </div>

            <!-- TABEL DAFTAR TAGIHAN LENGKAP & STATUS HUTANG -->
            <?php if ($can_manage && !empty($sellers)): ?>
            <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:14px 16px;margin-bottom:18px;">
                <div style="font-weight:800;color:#0f172a;margin-bottom:8px;">💳 Catat Pembayaran Seller</div>
                <div style="font-size:12px;color:#64748b;margin-bottom:10px;">Satu pembayaran menjadi pengajuan setoran ke Keuangan. Seller tidak wajib tahu invoice; setelah disetujui, sistem mengalokasikan ke tagihan tertua berdasarkan jatuh tempo. AR baru berkurang saat Keuangan menerima.</div>
                <form method="post" action="" style="display:flex;gap:8px;align-items:end;flex-wrap:wrap;">
                    <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                    <input type="hidden" name="pk01_seller_action_type" value="pay_balance">
                    <div><label style="font-size:11px;font-weight:700;display:block;">Seller</label><select name="pay_balance_seller_id" class="pk01-input" required><option value="">— Pilih Seller —</option><?php foreach($sellers as $ss): if(empty($ss['active'])) continue; ?><option value="<?php echo (int)$ss['id']; ?>"><?php echo esc_html($ss['code'].' — '.$ss['name']); ?></option><?php endforeach; ?></select></div>
                    <div><label style="font-size:11px;font-weight:700;display:block;">Nominal</label><input type="number" step="any" min="1" name="pay_balance_amount" class="pk01-input" required></div>
                    <div><label style="font-size:11px;font-weight:700;display:block;">Metode</label><select name="pay_balance_method" class="pk01-input"><option>Transfer Bank</option><option>QRIS</option><option>Kas Tunai</option></select><input type="text" name="pay_balance_reference" class="pk01-input" placeholder="Ref transfer / bukti (wajib transfer)"></div>
                    <button type="submit" class="pk01-btn pk01-btn-primary">Catat Pembayaran</button>
                </form>
            </div>
            <?php endif; ?>

            <div class="pk01-table-wrap">
                <table class="pk01-slr-table">
                    <thead>
                        <tr>
                            <th style="width:140px;">No. Faktur</th>
                            <th>Mitra Seller</th>
                            <th>Jatuh Tempo</th>
                            <th style="text-align:right;">Total Tagihan Barang</th>
                            <th style="text-align:right;">Sudah Dibayar Seller</th>
                            <th style="text-align:right;">Sisa Hutang Seller</th>
                            <th style="text-align:center;width:100px;">Status</th>
                            <th style="text-align:center;width:190px;">Pembayaran Tagihan Seller</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($invoices_list)): ?>
                            <?php foreach ($invoices_list as $inv): 
                                $rem = (float)$inv['remaining_debt'];
                                $is_lunas = ($rem <= 0);
                            ?>
                            <tr>
                                <td>
                                    <strong style="font-family:monospace;color:#0f172a;"><?php echo esc_html($inv['invoice_no']); ?></strong>
                                    <small style="display:block;color:#64748b;font-size:11px;"><?php echo esc_html(date('d/m/Y', strtotime($inv['created_at']))); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($inv['seller_name']); ?></strong>
                                    <small style="display:block;color:#64748b;font-family:monospace;"><?php echo esc_html($inv['seller_code']); ?></small>
                                </td>
                                <td>
                                    <span style="font-size:12px;color:<?php echo (!empty($inv['due_date']) && strtotime($inv['due_date']) < current_time('timestamp') && !$is_lunas) ? '#dc2626;font-weight:700;' : '#475569;'; ?>">
                                        <?php echo !empty($inv['due_date']) ? esc_html(date('d/m/Y', strtotime($inv['due_date']))) : '—'; ?>
                                    </span>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;">
                                    <?php echo esc_html($format_money($inv['total'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;color:#059669;">
                                    <?php echo esc_html($format_money($inv['total_paid'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:800;color:<?php echo $is_lunas ? '#047857;' : '#dc2626;'; ?>">
                                    <?php echo esc_html($format_money($rem)); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo $is_lunas ? 'badge-success' : 'badge-danger'; ?>">
                                        <?php echo $is_lunas ? 'Lunas' : 'Belum Lunas'; ?>
                                    </span>
                                </td>
                                <td style="text-align:center;">
                                    <?php if (!$is_lunas && $can_manage): ?>
                                        <!-- FORM INPUT SETORAN CICILAN DANA DARI SELLER -->
                                        <form method="post" action="" style="display:flex;gap:4px;align-items:center;margin:0;">
                                            <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                                            <input type="hidden" name="pk01_seller_action_type" value="pay">
                                            <input type="hidden" name="pay_invoice_id" value="<?php echo (int)$inv['id']; ?>">
                                            <input type="number" step="any" min="1" max="<?php echo esc_attr($rem); ?>" name="pay_amount" value="<?php echo esc_attr($rem); ?>" style="width:100px;padding:4px 6px;font-size:11px;border:1px solid #cbd5e1;border-radius:4px;" required><input type="text" name="pay_reference" placeholder="Ref transfer" style="width:110px;padding:4px 6px;font-size:11px;border:1px solid #cbd5e1;border-radius:4px;">
                                            <button type="submit" class="pk01-btn pk01-btn-primary" style="padding:4px 8px;font-size:11px;" title="Catat Setoran Uang Masuk">
                                                Setor
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color:#059669;font-size:11px;font-weight:700;">✓ Selesai Terbayar</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align:center;padding:32px;color:#94a3b8;">
                                    Belum ada catatan tagihan Seller untuk mitra seller.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 2: STATUS PENGIRIMAN & PELACAKAN RESI KURIR ALA MARKETPLACE -->
    <div class="pk01-tab-pane" id="tab-shipping-tracking">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>🚚 Status Pengiriman &amp; Pelacakan Resi Pesanan Mitra Seller</h3>
                    <p>Penjual dapat memantau status pesanan mereka secara langsung: apakah sedang diproses, dikemas, dalam perjalanan kurir, atau sudah diterima pembeli.</p>
                </div>
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-slr-table">
                    <thead>
                        <tr>
                            <th style="width:140px;">No. Pesanan</th>
                            <th>Mitra Seller</th>
                            <th>Pelanggan &amp; Tujuan</th>
                            <th style="width:130px;">Ekspedisi &amp; Resi</th>
                            <th style="text-align:center;width:120px;">Status Kurir</th>
                            <th style="text-align:right;">Nominal Belanja</th>
                            <th style="text-align:center;width:110px;">Lacak Langsung</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($seller_sales_records)): ?>
                            <?php foreach ($seller_sales_records as $so): 
                                $awb = !empty($so['ship_awb']) ? $so['ship_awb'] : ($so['tracking_no'] ?? '');
                                $courier = !empty($so['ship_courier']) ? $so['ship_courier'] : ($so['courier'] ?? 'jne');
                                $ship_st = strtolower($so['ship_status'] ?: ($so['shipping_status'] ?: 'pending'));

                                $badge_class = 'badge-warning';
                                $badge_label = 'Diproses';
                                if ($ship_st === 'shipped' || $ship_st === 'on_process' || !empty($awb)) {
                                    $badge_class = 'badge-info';
                                    $badge_label = 'Dalam Perjalanan';
                                }
                                if ($ship_st === 'delivered' || $ship_st === 'selesai' || $so['status'] === 'completed') {
                                    $badge_class = 'badge-success';
                                    $badge_label = 'Terkirim';
                                }

                                $direct_track_url = class_exists('PK01_Shipping_Engine') && method_exists('PK01_Shipping_Engine', 'get_direct_tracking_url')
                                    ? PK01_Shipping_Engine::get_direct_tracking_url($courier, $awb)
                                    : 'https://cekresi.com/?noresi=' . urlencode($awb);
                            ?>
                            <tr>
                                <td>
                                    <strong style="font-family:monospace;color:#0f172a;"><?php echo esc_html($so['order_no']); ?></strong>
                                    <small style="display:block;color:#64748b;font-size:11px;"><?php echo esc_html(date('d/m/Y H:i', strtotime($so['created_at']))); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($so['seller_name']); ?></strong>
                                    <small style="display:block;color:#64748b;font-family:monospace;"><?php echo esc_html($so['seller_code']); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($so['customer_name']); ?></strong>
                                    <div style="font-size:11px;color:#64748b;"><?php echo esc_html(mb_strimwidth($so['shipping_address'] ?: 'Alamat tertera di invoice', 0, 35, '...')); ?></div>
                                </td>
                                <td>
                                    <?php if (!empty($awb)): ?>
                                        <strong style="font-size:12px;display:block;color:#1e40af;"><?php echo esc_html(strtoupper($courier)); ?></strong>
                                        <code style="font-size:11px;font-weight:700;"><?php echo esc_html($awb); ?></code>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;font-size:12px;font-style:italic;">Belum input resi</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo esc_attr($badge_class); ?>">
                                        <?php echo esc_html($badge_label); ?>
                                    </span>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;">
                                    <?php echo esc_html($format_money($so['total_amount'])); ?>
                                </td>
                                <td style="text-align:center;">
                                    <?php if (!empty($awb)): ?>
                                        <a href="<?php echo esc_url($direct_track_url); ?>" target="_blank" class="pk01-btn-track" title="Buka pelacakan resmi kurir">
                                            🔗 Lacak Resi
                                        </a>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;font-size:11px;">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align:center;padding:32px;color:#94a3b8;">
                                    Belum ada riwayat pesanan dari jalur mitra seller.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 3: HISTORI OMZET & KOMISI PER BULAN / PER TAHUN -->
    <div class="pk01-tab-pane" id="tab-history">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>📅 Histori Penjualan &amp; Komisi per Periode (Bulan &amp; Tahun)</h3>
                    <p>Filter dan verifikasi komisi yang didapatkan seller pada setiap transaksi pesanan.</p>
                </div>
            </div>

            <!-- FORM FILTER PERIODE & SELLER -->
            <form method="get" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;margin-bottom:18px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                <input type="hidden" name="pk01_view" value="<?php echo esc_attr($_GET['pk01_view'] ?? 'seller'); ?>">

                <label style="font-size:12px;font-weight:700;">Pilih Seller:
                    <select name="filter_seller_id" class="pk01-input" style="width:auto;">
                        <option value="0">— Semua Mitra Seller —</option>
                        <?php foreach ($sellers as $s): ?>
                            <option value="<?php echo (int)$s['id']; ?>" <?php selected($filter_sid, (int)$s['id']); ?>>
                                <?php echo esc_html($s['name'] . ' (' . $s['code'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label style="font-size:12px;font-weight:700;">Tahun:
                    <select name="filter_year" class="pk01-input" style="width:auto;">
                        <option value="all" <?php selected($filter_year, 'all'); ?>>Semua</option>
                        <?php for ($y = (int)current_time('Y'); $y >= (int)current_time('Y') - 3; $y--): ?>
                            <option value="<?php echo $y; ?>" <?php selected($filter_year, (string)$y); ?>><?php echo $y; ?></option>
                        <?php endfor; ?>
                    </select>
                </label>

                <label style="font-size:12px;font-weight:700;">Bulan:
                    <select name="filter_month" class="pk01-input" style="width:auto;">
                        <option value="all" <?php selected($filter_month, 'all'); ?>>Semua</option>
                        <?php for ($m = 1; $m <= 12; $m++): $m_val = str_pad($m, 2, '0', STR_PAD_LEFT); ?>
                            <option value="<?php echo $m_val; ?>" <?php selected($filter_month, $m_val); ?>><?php echo date_i18n('F', mktime(0, 0, 0, $m, 1)); ?></option>
                        <?php endfor; ?>
                    </select>
                </label>

                <button type="submit" class="pk01-btn pk01-btn-primary">Tampilkan Histori</button>
            </form>

            <div class="pk01-table-wrap">
                <table class="pk01-slr-table">
                    <thead>
                        <tr>
                            <th>Waktu Order</th>
                            <th>No. Order / Faktur</th>
                            <th>Nama Seller</th>
                            <th>Produk Terjual</th>
                            <th style="text-align:right;">Total Omzet</th>
                            <th style="text-align:right;">Hak Komisi</th>
                            <th style="text-align:center;width:120px;">Status Komisi</th>
                            <?php if ($can_manage): ?><th style="text-align:center;width:120px;">Pencairan Komisi</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($seller_sales_records)): ?>
                            <?php foreach ($seller_sales_records as $rec): 
                                $comm_amount = (float)($rec['commission'] ?? 0);
                                $comm_status = strtolower($rec['commission_status'] ?? 'pending');
                                $is_comm_paid = ($comm_status === 'paid');
                            ?>
                            <tr>
                                <td style="font-family:monospace;font-size:12px;color:#64748b;">
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($rec['created_at']))); ?>
                                </td>
                                <td>
                                    <strong style="font-family:monospace;"><?php echo esc_html($rec['order_no']); ?></strong>
                                </td>
                                <td><strong><?php echo esc_html($rec['seller_name']); ?></strong></td>
                                <td><?php echo esc_html($rec['product_name'] ?: 'Barang Toko'); ?> (<?php echo (float)$rec['qty']; ?> pcs)</td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;">
                                    <?php echo esc_html($format_money($rec['total_amount'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:800;color:#7c3aed;">
                                    <?php echo esc_html($format_money($comm_amount)); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo $is_comm_paid ? 'badge-success' : 'badge-warning'; ?>">
                                        <?php echo $is_comm_paid ? 'Sudah Cair' : 'Belum Dicairkan'; ?>
                                    </span>
                                </td>
                                <?php if ($can_manage): ?>
                                <td style="text-align:center;">
                                    <?php if (!$is_comm_paid && $comm_amount > 0): ?>
                                        <form method="post" action="" style="margin:0;" onsubmit="return confirm('Cairkan komisi sebesar <?php echo esc_js($format_money($comm_amount)); ?> ke seller ini? Tindakan ini mencatat pengeluaran ke Buku Kas.');">
                                            <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                                            <input type="hidden" name="pk01_seller_action_type" value="pay_commission">
                                            <input type="hidden" name="commission_order_id" value="<?php echo (int)$rec['id']; ?>">
                                            <input type="hidden" name="commission_amount" value="<?php echo esc_attr($comm_amount); ?>">
                                            <button type="submit" class="pk01-btn pk01-btn-primary" style="padding:3px 8px;font-size:11px;background:#059669;">
                                                ✓ Cairkan
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="font-size:11px;color:#059669;">✓ Tuntas</span>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?php echo $can_manage ? 8 : 7; ?>" style="text-align:center;padding:32px;color:#94a3b8;">
                                    Belum ada data transaksi penjualan pada filter periode yang dipilih.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 4: DIREKTORI MASTER SELLER -->
    <div class="pk01-tab-pane" id="tab-sellers">
        <?php if (!empty($pending_reg)): ?>
        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:16px;margin-bottom:20px;">
            <strong style="color:#92400e;font-size:14px;display:block;margin-bottom:8px;">⏳ Calon Seller Menunggu Persetujuan Admin</strong>
            <div class="pk01-table-wrap">
                <table class="pk01-slr-table">
                    <thead>
                        <tr><th>Kode</th><th>Nama</th><th>WhatsApp / Email</th><th>Waktu Daftar</th><th style="text-align:center;">Tindakan</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_reg as $pr): ?>
                        <tr>
                            <td><code><?php echo esc_html($pr['code']); ?></code></td>
                            <td><strong><?php echo esc_html($pr['name']); ?></strong></td>
                            <td><?php echo esc_html($pr['phone'] ?: $pr['email']); ?></td>
                            <td><?php echo esc_html(!empty($pr['created_at']) ? date('d/m/Y H:i', strtotime($pr['created_at'])) : '—'); ?></td>
                            <td style="text-align:center;">
                                <div style="display:inline-flex;gap:6px;">
                                    <form method="post" action="" style="margin:0;">
                                        <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                                        <input type="hidden" name="pk01_seller_action_type" value="approve">
                                        <input type="hidden" name="target_id" value="<?php echo (int)$pr['id']; ?>">
                                        <button type="submit" class="pk01-btn pk01-btn-primary" style="padding:4px 8px;font-size:11px;background:#10b981;">✅ Setujui</button>
                                    </form>
                                    <form method="post" action="" style="margin:0;">
                                        <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                                        <input type="hidden" name="pk01_seller_action_type" value="reject">
                                        <input type="hidden" name="target_id" value="<?php echo (int)$pr['id']; ?>">
                                        <button type="submit" class="pk01-btn pk01-btn-primary" style="padding:4px 8px;font-size:11px;background:#ef4444;">❌ Tolak</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Form Tambah / Edit Seller -->
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <h3><?php echo $edit ? '✏️ Edit Mitra: ' . esc_html($edit['name']) : '➕ Daftarkan Seller Baru'; ?></h3>
                <?php if ($edit): ?><a href="<?php echo esc_url($current_url); ?>" style="font-size:12px;color:#dc2626;text-decoration:none;font-weight:700;">✕ Batal Edit</a><?php endif; ?>
            </div>

            <form method="post" action="">
                <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                <input type="hidden" name="pk01_seller_action_type" value="<?php echo $edit ? 'save' : 'create'; ?>">
                <input type="hidden" name="seller_id" value="<?php echo (int)($edit['id'] ?? 0); ?>">

                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:12px;">
                    <div><label style="font-size:12px;font-weight:700;">Kode Seller</label><input type="text" name="seller_code" class="pk01-input" value="<?php echo esc_attr($edit['code'] ?? ''); ?>" placeholder="Otomatis sistem jika kosong"></div>
                    <div><label style="font-size:12px;font-weight:700;">Nama Lengkap Mitra <span style="color:#dc2626;">*</span></label><input type="text" name="seller_name" class="pk01-input" value="<?php echo esc_attr($edit['name'] ?? ''); ?>" required placeholder="Contoh: Budi Santoso"></div>
                    <div><label style="font-size:12px;font-weight:700;">No. WhatsApp</label><input type="tel" name="seller_phone" class="pk01-input" value="<?php echo esc_attr($edit['phone'] ?? ''); ?>" placeholder="08xxxxxxxxxx"></div>
                    <div><label style="font-size:12px;font-weight:700;">Email Login</label><input type="email" name="seller_email" class="pk01-input" value="<?php echo esc_attr($edit['email'] ?? ''); ?>" placeholder="seller@domain.com"></div>
                    <div><label style="font-size:12px;font-weight:700;">Komisi Seller (%)</label><input type="number" step="any" min="0" max="100" name="seller_commission" class="pk01-input" value="<?php echo esc_attr($edit['commission_percent'] ?? 10); ?>"></div>
                    <div><label style="font-size:12px;font-weight:700;">Komisi Afiliasi Refferal (%)</label><input type="number" step="any" min="0" max="100" name="seller_affiliate" class="pk01-input" value="<?php echo esc_attr($edit['affiliate_percent'] ?? 5); ?>"></div>
                    <div><label style="font-size:12px;font-weight:700;">Termin Pembayaran Seller</label><select name="seller_payment_term_days" class="pk01-input"><option value="0" <?php selected((int)($edit['payment_term_days'] ?? 0),0); ?>>Langsung / COD</option><option value="7" <?php selected((int)($edit['payment_term_days'] ?? 0),7); ?>>7 Hari</option><option value="14" <?php selected((int)($edit['payment_term_days'] ?? 0),14); ?>>14 Hari</option><option value="30" <?php selected((int)($edit['payment_term_days'] ?? 0),30); ?>>30 Hari</option><option value="60" <?php selected((int)($edit['payment_term_days'] ?? 0),60); ?>>60 Hari</option></select><input type="hidden" name="seller_payment_term_label" value="<?php echo esc_attr($edit['payment_term_label'] ?? 'Langsung / COD'); ?>"></div>
                </div>

                <?php if ($edit): ?>
                    <label style="display:flex;align-items:center;gap:8px;margin-top:12px;">
                        <input type="checkbox" name="seller_active" value="1" <?php checked((int)($edit['active'] ?? 0), 1); ?> style="width:16px;height:16px;">
                        <span style="font-weight:700;font-size:13px;">Status Mitra Aktif (Dapat Mengakses Portal &amp; Bertransaksi)</span>
                    </label>
                <?php endif; ?>

                <div style="margin-top:16px;display:flex;gap:10px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit"><?php echo $edit ? '💾 Simpan Perubahan' : '💾 Daftarkan Seller'; ?></button>
                    <?php if ($edit): ?><a class="pk01-btn pk01-btn-export" href="<?php echo esc_url($current_url); ?>">Batal</a><?php endif; ?>
                </div>
            </form>
        </section>

        <!-- Tabel Daftar Seluruh Seller -->
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>Daftar Seluruh Mitra Seller &amp; Peringkat</h3>
                <input type="search" id="pk01-search-seller" class="pk01-input" placeholder="🔍 Cari seller, kode, kontak..." style="max-width:260px;">
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-slr-table" id="pk01-table-sellers">
                    <thead>
                        <tr>
                            <th style="width:80px;text-align:center;">Peringkat</th>
                            <th style="width:100px;">Kode</th>
                            <th>Nama Mitra</th>
                            <th>Kontak</th>
                            <th style="text-align:center;width:90px;">Komisi</th>
                            <th style="text-align:right;">Omzet Bulan Ini</th>
                            <th style="text-align:center;width:90px;">Status</th>
                            <th>Tautan Portal Seller</th>
                            <th style="text-align:center;width:80px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($sellers)): ?>
                            <?php foreach ($sellers as $s): 
                                $portal_link = add_query_arg('pk01_seller', rawurlencode($s['portal_token'] ?? ''), home_url('/'));
                                $is_active = !empty($s['active']);
                                $s_id = (int)$s['id'];
                                $rank_data = $seller_rank_map[$s_id] ?? ['rank'=>'-', 'omzet'=>0];
                                $rank_badge = ($rank_data['rank'] === 1) ? '🥇 #1' : (($rank_data['rank'] === 2) ? '🥈 #2' : (($rank_data['rank'] === 3) ? '🥉 #3' : '#' . $rank_data['rank']));
                            ?>
                            <tr>
                                <td style="text-align:center;font-weight:800;font-size:13px;color:#2563eb;"><?php echo esc_html($rank_badge); ?></td>
                                <td><code style="font-weight:700;"><?php echo esc_html($s['code']); ?></code></td>
                                <td><strong><?php echo esc_html($s['name']); ?></strong></td>
                                <td><?php echo esc_html($s['phone'] ?: ($s['email'] ?: '—')); ?></td>
                                <td style="text-align:center;">
                                    <span style="background:#e0f2fe;color:#0369a1;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;">
                                        <?php echo (float)$s['commission_percent']; ?>%
                                    </span>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;color:#047857;">
                                    <?php echo esc_html($format_money($rank_data['omzet'])); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo $is_active ? 'badge-success' : 'badge-danger'; ?>">
                                        <?php echo $is_active ? 'Aktif' : 'Nonaktif'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="display:flex;gap:4px;align-items:center;">
                                        <input type="text" readonly value="<?php echo esc_url($portal_link); ?>" style="padding:4px 8px;font-size:11px;width:180px;" onclick="this.select();">
                                        <button type="button" class="pk01-btn pk01-btn-export" style="padding:4px 8px;font-size:11px;" onclick="navigator.clipboard.writeText('<?php echo esc_js($portal_link); ?>');this.innerText='✓';setTimeout(()=>{this.innerText='Salin'},1200);">Salin</button>
                                    </div>
                                </td>
                                <td style="text-align:center;">
                                    <a class="pk01-btn pk01-btn-export" href="<?php echo esc_url(add_query_arg('edit_id', (int)$s['id'])); ?>" style="padding:3px 8px;font-size:11px;">✏️ Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="9" style="text-align:center;padding:32px;color:#94a3b8;">Belum ada data mitra seller.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 5: ALOKASI BARANG GUDANG & SERAH TERIMA -->
    <div class="pk01-tab-pane" id="tab-circulation">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>📦 Permintaan Barang Konsinyasi ke Gudang &amp; Serah Terima</h3>
                <p>Buat alokasi barang untuk mitra seller dari stok produk gudang yang tersedia.</p>
            </div>

            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(320px, 1fr));gap:20px;">
                <!-- Form Ajukan Barang -->
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:18px;">
                    <h4 style="margin:0 0 10px 0;">➕ Ajukan Alokasi Produk Seller</h4>
                    <form method="post" action="">
                        <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                        <input type="hidden" name="pk01_seller_action_type" value="order">
                        <div style="display:grid;gap:10px;">
                            <label style="font-size:12px;font-weight:700;">Pilih Seller:
                                <select name="req_seller_id" class="pk01-input" required>
                                    <option value="">— Pilih Seller —</option>
                                    <?php foreach ($sellers as $s): if (empty($s['active'])) continue; ?>
                                        <option value="<?php echo (int)$s['id']; ?>"><?php echo esc_html($s['code'] . ' — ' . $s['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <label style="font-size:12px;font-weight:700;">Pilih Produk SKU:
                                <select name="req_variant_id" class="pk01-input" required>
                                    <option value="">— Pilih Produk —</option>
                                    <?php foreach ($variants as $v): ?>
                                        <option value="<?php echo (int)$v['id']; ?>">[<?php echo esc_html($v['sku']); ?>] <?php echo esc_html($v['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <label style="font-size:12px;font-weight:700;">Jumlah (Qty):
                                <input type="number" step="any" min="1" name="req_qty" class="pk01-input" value="1" required>
                            </label>
                            <button type="submit" class="pk01-btn pk01-btn-primary">+ Ajukan Barang</button>
                        </div>
                    </form>
                </div>

                <!-- Antrean Serah Terima -->
                <div>
                    <h4 style="margin:0 0 10px 0;">Antrean Serah-Terima Barang dari Gudang:</h4>
                    <?php if (!empty($pending_orders)): ?>
                        <div style="display:grid;gap:8px;">
                            <?php foreach ($pending_orders as $po): ?>
                            <div style="padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;display:flex;justify-content:space-between;align-items:center;">
                                <div>
                                    <strong><?php echo esc_html($po['seller_name']); ?></strong>
                                    <small style="display:block;font-family:monospace;color:#64748b;"><?php echo esc_html($po['order_no'] ?: '#' . $po['id']); ?></small>
                                </div>
                                <form method="post" action="" style="margin:0;">
                                    <?php echo wp_nonce_field('pk01_seller_manage_action', 'pk01_seller_nonce', true, false); ?>
                                    <input type="hidden" name="pk01_seller_action_type" value="handover">
                                    <input type="hidden" name="handover_order_id" value="<?php echo (int)$po['id']; ?>">
                                    <button type="submit" class="pk01-btn pk01-btn-primary" style="background:#10b981;padding:5px 10px;font-size:11px;">
                                        📤 Serahkan Barang
                                    </button>
                                </form>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div style="font-size:12px;color:#94a3b8;padding:14px;background:#f8fafc;border-radius:8px;">Tidak ada antrean serah-terima barang saat ini.</div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

    <!-- TAB 6: TARGET & BONUS PENJUALAN -->
    <div class="pk01-tab-pane" id="tab-targets">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>🎯 Target Penjualan &amp; Bonus Omzet</h3>
                    <p>Bonus dihitung otomatis dari penjualan nyata periode berjalan tanpa duplikasi.</p>
                </div>
            </div>

            <?php echo $target_notice; ?>

            <?php if ($target_can_manage): ?>
            <form method="post" action="" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:18px;margin-bottom:20px;">
                <input type="hidden" name="pk01_seller_target_save" value="1">
                <?php echo wp_nonce_field('pk01_seller_target_save', 'pk01_seller_target_nonce', true, false); ?>

                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:12px;">
                    <div><label style="font-size:12px;font-weight:700;">Seller / Marketing</label>
                        <select name="target_seller_id" class="pk01-input" required>
                            <?php foreach ($sellers as $ss): ?>
                                <option value="<?php echo (int)$ss['id']; ?>"><?php echo esc_html(($ss['code'] ?: '—') . ' — ' . $ss['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div><label style="font-size:12px;font-weight:700;">Peran</label>
                        <select name="participant_type" class="pk01-input">
                            <option value="seller">Seller</option>
                            <option value="marketing">Marketing</option>
                        </select>
                    </div>
                    <div><label style="font-size:12px;font-weight:700;">Periode</label><input type="month" name="target_period" class="pk01-input" value="<?php echo esc_attr(current_time('Y-m')); ?>" required></div>
                    <div><label style="font-size:12px;font-weight:700;">Target Penjualan (Rp)</label><input type="number" name="target_amount" class="pk01-input" min="1" step="0.01" placeholder="Contoh: 10000000" required></div>
                    <div><label style="font-size:12px;font-weight:700;">Jenis Bonus</label>
                        <select name="bonus_type" class="pk01-input">
                            <option value="fixed">Nominal Tetap (Rp)</option>
                            <option value="percent">Persentase (%) dari Omzet</option>
                        </select>
                    </div>
                    <div><label style="font-size:12px;font-weight:700;">Nilai Bonus</label><input type="number" name="bonus_value" class="pk01-input" min="0" step="0.01" required></div>
                </div>
                <button type="submit" class="pk01-btn pk01-btn-primary" style="margin-top:14px;">Simpan Target Periode</button>
            </form>
            <?php endif; ?>

            <div class="pk01-table-wrap">
                <table class="pk01-slr-table">
                    <thead>
                        <tr><th>Mitra Seller</th><th>Periode</th><th>Target Omzet</th><th>Penjualan Aktual</th><th>Progress Target</th><th>Bonus Diperoleh</th></tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($target_rows)): ?>
                            <?php foreach ($target_rows as $tr): 
                                $prog = min(100, (((float)$tr['sales_amount'] / max(1, (float)$tr['target_amount'])) * 100));
                                $btxt = ($tr['bonus_type'] === 'percent') ? ((float)$tr['bonus_value']) . '%' : 'Rp ' . number_format((float)$tr['bonus_value'], 0, ',', '.');
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($tr['seller_name']); ?></strong> (<?php echo esc_html($tr['seller_code']); ?>)</td>
                                <td><span style="font-family:monospace;font-weight:700;"><?php echo esc_html($tr['period_key']); ?></span></td>
                                <td style="font-family:monospace;">Rp <?php echo number_format((float)$tr['target_amount'], 0, ',', '.'); ?></td>
                                <td style="font-family:monospace;font-weight:700;color:#047857;">Rp <?php echo number_format((float)$tr['sales_amount'], 0, ',', '.'); ?></td>
                                <td>
                                    <div style="font-weight:700;font-size:12px;"><?php echo number_format($prog, 1, ',', '.'); ?>%</div>
                                    <div style="width:100%;background:#e2e8f0;height:6px;border-radius:3px;overflow:hidden;margin-top:2px;">
                                        <div style="background:<?php echo $prog >= 100 ? '#10b981' : '#2563eb'; ?>;height:100%;width:<?php echo $prog; ?>%;"></div>
                                    </div>
                                </td>
                                <td><b><?php echo esc_html($btxt); ?></b></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align:center;padding:24px;color:#94a3b8;">Belum ada target penjualan yang aktif.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TABS SWITCHER
    var tabBtns = document.querySelectorAll('.pk01-tab-btn');
    var tabPanes = document.querySelectorAll('.pk01-tab-pane');

    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            tabBtns.forEach(function(b) { b.classList.remove('active'); });
            tabPanes.forEach(function(p) { p.classList.remove('active'); });

            this.classList.add('active');
            var targetId = this.getAttribute('data-target');
            var targetPane = document.getElementById(targetId);
            if (targetPane) targetPane.classList.add('active');
        });
    });

    // 2. LIVE SEARCH SELLER DIRECTORY
    var searchInput = document.getElementById('pk01-search-seller');
    var table       = document.getElementById('pk01-table-sellers');

    if (searchInput && table) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            var rows   = table.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                var text = row.innerText.toLowerCase();
                row.style.display = (text.indexOf(filter) > -1) ? '' : 'none';
            });
        });
    }
});
</script>