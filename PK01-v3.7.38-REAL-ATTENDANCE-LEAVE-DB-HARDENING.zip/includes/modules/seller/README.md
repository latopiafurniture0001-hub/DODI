# PK01 — Modul Seller

Folder canonical: `includes/modules/seller/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/seller/core/class-pk01-affiliate.php`
- `includes/modules/seller/management/tampilan-penjual.php`
- `includes/modules/seller/portal/tampilan-portal-penjual.php`
- `includes/modules/seller/register/tampilan-daftar-seller.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
