<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise Affiliate & Multi-Channel Attribution Engine
 * Lapisan pelacakan referral, pembagian komisi, dan integrasi marketplace terpadu.
 */
class PK01_Affiliate {

    /**
     * Inisialisasi Hook Pelacakan
     */
    public static function init() {
        add_action('init', [__CLASS__, 'capture_affiliate'], 8);
        add_action('wp_footer', [__CLASS__, 'clear_tracking_query'], 99);

        // Jabat Tangan Otomatis: Sinkronkan komisi saat status pesanan berubah
        add_action('pk01_order_status_updated', [__CLASS__, 'sync_commission_status'], 10, 1);
        add_action('woocommerce_order_status_changed', [__CLASS__, 'sync_commission_status'], 10, 1);
    }

    private static function now() { 
        return current_time('mysql'); 
    }

    private static function table($key) {
        global $wpdb;
        if (class_exists('PK01_DB') && method_exists('PK01_DB', 't')) {
            $t = PK01_DB::t($key);
            if ($t) return $t;
        }
        return $wpdb->prefix . 'pk01_' . $key;
    }

    private static function admin() { 
        return is_user_logged_in() && current_user_can('manage_options'); 
    }

    /**
     * Pengidentifikasi Pengunjung Unik (Visitor Fingerprint)
     */
    public static function visitor_key() {
        $cookie_name = 'pk01_aff_vkey';
        $cookie = isset($_COOKIE[$cookie_name]) ? sanitize_text_field(wp_unslash($_COOKIE[$cookie_name])) : '';
        
        if (empty($cookie)) {
            $cookie = wp_generate_password(32, false, false);
            self::set_cookie_safe($cookie_name, $cookie, 180 * DAY_IN_SECONDS);
        }
        
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'pk01_aff_salt';
        return substr(hash_hmac('sha256', $cookie, $salt), 0, 80);
    }

    /**
     * Helper Penulisan Cookie Aman (Mencegah Warning Headers Already Sent)
     */
    private static function set_cookie_safe($name, $value, $lifetime = 2592000) {
        if (headers_sent()) return false;
        
        $expire = time() + (int)$lifetime;
        $path = COOKIEPATH ? COOKIEPATH : '/';
        $domain = COOKIE_DOMAIN ? COOKIE_DOMAIN : '';
        $secure = is_ssl();
        $httponly = true;

        if (PHP_VERSION_ID >= 70300) {
            return setcookie($name, $value, [
                'expires'  => $expire,
                'path'     => $path,
                'domain'   => $domain,
                'secure'   => $secure,
                'httponly' => $httponly,
                'samesite' => 'Lax',
            ]);
        } else {
            return setcookie($name, $value, $expire, $path, $domain, $secure, $httponly);
        }
    }

    private static function session_key() {
        $token = function_exists('wp_get_session_token') ? wp_get_session_token() : '';
        $ip = self::get_client_ip();
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'pk01_sess_salt';
        return substr(hash_hmac('sha256', $token . '|' . $ip, $salt), 0, 80);
    }

    private static function get_client_ip() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($parts[0]);
        }
        return sanitize_text_field($ip);
    }

    private static function browser() { 
        return substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 120); 
    }

    public static function channel_label($channel) {
        $map = [
            'facebook'    => 'Facebook',
            'whatsapp'    => 'WhatsApp',
            'instagram'   => 'Instagram',
            'tiktok'      => 'TikTok',
            'youtube'     => 'YouTube',
            'website'     => 'Website / Direct',
            'marketplace' => 'Marketplace',
            'telegram'    => 'Telegram',
            'lainnya'     => 'Lainnya'
        ];
        return $map[$channel] ?? ucfirst((string)$channel);
    }

    public static function marketplaces() {
        return [
            'shopee'    => ['name' => 'Shopee', 'formats' => ['csv', 'zip'], 'mode' => 'export'],
            'tiktok'    => ['name' => 'TikTok Shop', 'formats' => ['csv', 'json', 'zip'], 'mode' => 'export_or_api'],
            'tokopedia' => ['name' => 'Tokopedia', 'formats' => ['csv', 'zip'], 'mode' => 'export'],
            'lazada'    => ['name' => 'Lazada', 'formats' => ['csv', 'json', 'zip'], 'mode' => 'export_or_api'],
            'blibli'    => ['name' => 'Blibli', 'formats' => ['zip'], 'mode' => 'export'],
        ];
    }

    /**
     * Ambil Akun Mitra Seller yang Sedang Login
     */
    public static function seller_account() {
        if (!is_user_logged_in()) return null;
        global $wpdb;
        $t = self::table('sales_accounts');
        if (!$t || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) {
            $t = self::table('sellers');
        }
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$t} WHERE (user_id = %d OR email = %s) AND active = 1 LIMIT 1",
            get_current_user_id(),
            wp_get_current_user()->user_email
        ), ARRAY_A);
    }

    /**
     * Buat Link Afiliasi Per Produk / Varian
     */
    public static function link($seller_id, $variant_id) {
        global $wpdb;
        $t = self::table('affiliate_links');
        $seller_id = (int)$seller_id;
        $variant_id = (int)$variant_id;

        if (!$t) throw new Exception('Tabel affiliate_links belum siap di database.');

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$t} WHERE seller_account_id = %d AND variant_id = %d LIMIT 1",
            $seller_id, $variant_id
        ), ARRAY_A);

        if ($existing) return $existing;

        // Kode Afiliasi Bersih: AFF-{ID SELLER}-{RANDOM}
        $code = 'AFF-' . $seller_id . '-' . strtoupper(wp_generate_password(6, false, false));
        $now = self::now();

        $ok = $wpdb->insert($t, [
            'seller_account_id' => $seller_id,
            'variant_id'        => $variant_id,
            'affiliate_code'    => $code,
            'clicks'            => 0,
            'active'            => 1,
            'created_at'        => $now,
            'updated_at'        => $now
        ]);

        if (!$ok) throw new Exception('Gagal mendaftarkan tautan promosi afiliasi.');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d", $wpdb->insert_id), ARRAY_A);
    }

    /**
     * Bangun URL Tracking Lengkap
     */
    public static function url($link, $channel = 'website', $campaign = '') {
        $code = is_array($link) ? ($link['affiliate_code'] ?? '') : $link;
        $args = ['pk01_aff' => $code];

        if ($channel)  $args['pk01_ch'] = sanitize_key($channel);
        if ($campaign) $args['pk01_campaign'] = sanitize_title($campaign);

        return add_query_arg($args, home_url('/'));
    }

    /**
     * 1. CAPTURE & TRACKING KUNJUNGAN AFILIASI REAL-TIME
     */
    public static function capture_affiliate() {
        if (empty($_GET['pk01_aff'])) return;

        $code = strtoupper(sanitize_text_field(wp_unslash($_GET['pk01_aff'])));
        if (empty($code)) return;

        global $wpdb;
        $t = self::table('affiliate_links');
        if (!$t || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) return;

        // Cari Tautan Aktif
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE affiliate_code = %s AND active = 1 LIMIT 1", $code), ARRAY_A);
        if (!$row) return;

        $channel  = sanitize_key($_GET['pk01_ch'] ?? 'website');
        $campaign = sanitize_text_field(wp_unslash($_GET['pk01_campaign'] ?? ''));
        $visitor  = self::visitor_key();
        $session  = self::session_key();
        $now      = self::now();

        // Update Counter Klik
        $wpdb->query($wpdb->prepare("UPDATE {$t} SET clicks = clicks + 1, updated_at = %s WHERE id = %d", $now, (int)$row['id']));

        // Catat Atribusi Kunjungan (Jika belum tercatat dalam 30 menit terakhir oleh pengunjung yang sama)
        $at = self::table('affiliate_attributions');
        if ($at && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $at)) === $at) {
            $recent = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$at} 
                 WHERE affiliate_link_id = %d AND visit_key = %s 
                 AND created_at > DATE_SUB(%s, INTERVAL 30 MINUTE) 
                 LIMIT 1",
                (int)$row['id'], $visitor, $now
            ));

            if (!$recent) {
                $wpdb->insert($at, [
                    'affiliate_link_id' => (int)$row['id'],
                    'session_key'       => $session,
                    'status'            => 'clicked',
                    'channel'           => $channel,
                    'campaign'          => $campaign,
                    'referrer'          => substr(sanitize_text_field($_SERVER['HTTP_REFERER'] ?? ''), 0, 350),
                    'device'            => self::device_type(),
                    'browser'           => self::browser(),
                    'landing_url'       => esc_url_raw(home_url(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'))),
                    'visit_key'         => $visitor,
                    'created_at'        => $now
                ]);
            }
        }

        // Simpan Jejak Referral di Cookie Pengunjung (30 Hari Attribution Window)
        self::set_cookie_safe('pk01_affiliate_code', $code, 30 * DAY_IN_SECONDS);
        self::set_cookie_safe('pk01_affiliate_channel', $channel, 30 * DAY_IN_SECONDS);
        self::set_cookie_safe('pk01_affiliate_campaign', $campaign, 30 * DAY_IN_SECONDS);
        self::set_cookie_safe('pk01_affiliate_seller', (string)$row['seller_account_id'], 30 * DAY_IN_SECONDS);
    }

    public static function clear_tracking_query() {
        // Sengaja kosong agar query arg tidak diputus di tengah sesi belanja
    }

    public static function device_type() {
        $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (strpos($ua, 'tablet') !== false || strpos($ua, 'ipad') !== false) return 'tablet';
        if (strpos($ua, 'mobile') !== false || strpos($ua, 'android') !== false || strpos($ua, 'iphone') !== false) return 'mobile';
        return 'desktop';
    }

    /**
     * 2. ATRIBUSI PESANAN & PERHITUNGAN KOMISI RIIL (JABAT TANGAN KE ORDER)
     */
    public static function attribute_order($order_id) {
        global $wpdb;
        $id = (int)$order_id;
        if ($id <= 0) return null;

        $so = self::table('sales_orders');
        if (!$so || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $so)) !== $so) {
            $so = self::table('orders');
        }

        $at     = self::table('affiliate_attributions');
        $lt     = self::table('affiliate_links');
        $ledger = self::table('seller_affiliate_ledger');
        $st     = self::table('sales_accounts') ?: self::table('sellers');

        if (!$so || !$lt) return null;

        // Cek apakah pesanan sudah memiliki atribusi seller
        $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$so} WHERE id = %d", $id), ARRAY_A);
        if (!$order || !empty($order['affiliate_seller_id']) || !empty($order['seller_id'])) {
            return null; // Sudah diatribusi sebelumnya
        }

        // Ambil data dari cookie pengunjung
        $code = sanitize_text_field($_COOKIE['pk01_affiliate_code'] ?? '');
        if (empty($code)) return null;

        $link = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$lt} WHERE affiliate_code = %s AND active = 1 LIMIT 1", $code), ARRAY_A);
        if (!$link) return null;

        $seller = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$st} WHERE id = %d AND active = 1 LIMIT 1", (int)$link['seller_account_id']), ARRAY_A);
        if (!$seller) return null;

        // PROTEKSI ANTI-FRAUD: Cegah seller mendapat komisi dari pembelian akunnya sendiri
        $current_u = wp_get_current_user();
        if ($current_u->exists()) {
            if ($current_u->ID == ($seller['user_id'] ?? 0) || strtolower($current_u->user_email) === strtolower($seller['email'] ?? '')) {
                return null; // Self-referral ditolak
            }
        }

        $now = self::now();
        $visitor = self::visitor_key();

        // Cari record atribusi yang cocok dengan pengunjung ini
        $att_id = 0;
        $channel = sanitize_text_field($_COOKIE['pk01_affiliate_channel'] ?? 'website');
        $campaign = sanitize_text_field($_COOKIE['pk01_affiliate_campaign'] ?? '');

        if ($at) {
            $att_row = $wpdb->get_row($wpdb->prepare(
                "SELECT id, channel, campaign FROM {$at} 
                 WHERE affiliate_link_id = %d AND visit_key = %s 
                 AND created_at >= DATE_SUB(%s, INTERVAL 30 DAY) 
                 ORDER BY id DESC LIMIT 1",
                (int)$link['id'], $visitor, $now
            ), ARRAY_A);

            if ($att_row) {
                $att_id   = (int)$att_row['id'];
                $channel  = $att_row['channel'] ?: $channel;
                $campaign = $att_row['campaign'] ?: $campaign;
            }
        }

        // Hitung Besaran Komisi Riil
        $gross  = (float) ($order['total_amount'] ?? ($order['gross'] ?? 0));
        $rate   = max(0, min(100, (float)($seller['affiliate_percent'] ?? ($seller['commission_percent'] ?? 10))));
        $amount = round(($gross * $rate) / 100); // Nominal komisi dalam Rupiah bersih

        // Update Pesanan
        $update_data = [
            'affiliate_link_id'            => (int)$link['id'],
            'affiliate_attribution_id'     => $att_id,
            'affiliate_seller_id'          => (int)$seller['id'],
            'seller_id'                    => (int)$seller['id'],
            'commission'                   => $amount,
            'affiliate_commission_amount'  => $amount,
            'affiliate_commission_rate'    => $rate,
            'affiliate_channel'            => $channel,
            'affiliate_campaign'           => $campaign
        ];

        // Filter kolom yang benar-benar ada di tabel pesanan
        $existing_cols = $wpdb->get_col("DESC `{$so}`", 0);
        $safe_update = array_intersect_key($update_data, array_flip($existing_cols));

        $wpdb->update($so, $safe_update, ['id' => $id]);

        // Tandai Status Atribusi Jadi Converted
        if ($at && $att_id > 0) {
            $wpdb->update($at, ['order_id' => $id, 'status' => 'converted', 'converted_at' => $now], ['id' => $att_id]);
        }

        // C. JABAT TANGAN: CATAT KE BUKU BESAR KOMISI (SELLER AFFILIATE LEDGER)
        if ($ledger && $amount > 0 && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $ledger)) === $ledger) {
            $exists_ledger = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$ledger} WHERE order_id = %d LIMIT 1", $id));
            if (!$exists_ledger) {
                if (class_exists('PK01_Duplicate_Guard')) PK01_Duplicate_Guard::claim('affiliate_ledger', 'order:'.$id, ['seller_id'=>(int)$seller['id'],'amount'=>$amount]);
                $wpdb->insert($ledger, [
                    'seller_account_id' => (int)$seller['id'],
                    'order_id'          => $id,
                    'affiliate_link_id' => (int)$link['id'],
                    'base_amount'       => $gross,
                    'commission_percent'=> $rate,
                    'commission_amount' => $amount,
                    'status'            => 'pending', // Pending sampai pesanan diterima pembeli
                    'created_at'        => $now
                ]);
            }
        }

        return $update_data;
    }

    /**
     * 3. SINKRONISASI STATUS KOMISI (PENDING -> READY / CANCELLED)
     */
    public static function sync_commission_status($order_id) {
        global $wpdb;
        $id = (int)$order_id;
        if ($id <= 0) return;

        $so     = self::table('sales_orders') ?: self::table('orders');
        $ledger = self::table('seller_affiliate_ledger');
        if (!$so || !$ledger) return;

        $o = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$so} WHERE id = %d", $id), ARRAY_A);
        if (!$o) return;

        $seller_id = (int)($o['affiliate_seller_id'] ?? ($o['seller_id'] ?? 0));
        if ($seller_id <= 0) return;

        $status = strtolower((string)($o['status'] ?? ''));
        $ship   = strtolower((string)($o['shipping_status'] ?? ''));
        $pay    = strtolower((string)($o['payment_status'] ?? ''));

        // Syarat Komisi Siap Cair: Pesanan Selesai / Terkirim & Sudah Dibayar
        $is_success = ($status === 'completed' || $status === 'selesai' || $ship === 'delivered');
        $is_paid    = ($pay === 'paid' || $pay === 'lunas' || $status === 'completed' || empty($pay));

        if ($is_success && $is_paid) {
            $new_status = 'ready'; // Siap ditarik oleh seller
        } elseif (in_array($status, ['cancelled', 'batal', 'failed', 'refunded', 'retur'], true)) {
            $new_status = 'cancelled'; // Gugur karena dibatalkan
        } else {
            $new_status = 'pending'; // Masih dalam proses kirim/bayar
        }

        $wpdb->query($wpdb->prepare(
            "UPDATE {$ledger} SET status = %s WHERE order_id = %d AND status NOT IN ('paid')",
            $new_status, $id
        ));
    }

    /**
     * 4. STATISTIK PERFORMA AFILIASI SELLER RIIL (NON-DUMMY)
     */
    public static function seller_stats($seller_id) {
        global $wpdb;
        $id     = (int)$seller_id;
        $links  = self::table('affiliate_links');
        $at     = self::table('affiliate_attributions');
        $ledger = self::table('seller_affiliate_ledger');
        $so     = self::table('sales_orders') ?: self::table('orders');

        $stats = [
            'products'           => 0,
            'clicks'             => 0,
            'visits'             => 0,
            'orders'             => 0,
            'conversion_rate'    => 0,
            'sales'              => 0,
            'commission_pending' => 0,
            'commission_ready'   => 0,
            'commission_paid'    => 0,
            'commission_total'   => 0
        ];

        if (!$links || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $links)) !== $links) {
            return $stats;
        }

        $stats['products'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$links} WHERE seller_account_id = %d AND active = 1", $id));
        $stats['clicks']   = (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(clicks), 0) FROM {$links} WHERE seller_account_id = %d", $id));

        if ($at && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $at)) === $at) {
            $stats['visits'] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT a.visit_key) 
                 FROM {$at} a 
                 INNER JOIN {$links} l ON l.id = a.affiliate_link_id 
                 WHERE l.seller_account_id = %d", 
                $id
            ));
        }

        if ($so && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $so)) === $so) {
            $stats['orders'] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$so} 
                 WHERE (affiliate_seller_id = %d OR seller_id = %d) 
                 AND status NOT IN ('cancelled', 'batal', 'failed')", 
                $id, $id
            ));

            $stats['sales'] = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(total_amount), SUM(gross), 0) FROM {$so} 
                 WHERE (affiliate_seller_id = %d OR seller_id = %d) 
                 AND status NOT IN ('cancelled', 'batal', 'failed')", 
                $id, $id
            ));
            $rt = self::table('returns');
            if ($rt) {
                $ret_adj = (float) $wpdb->get_var($wpdb->prepare(
                    "SELECT COALESCE(SUM(seller_adjustment_amount),0) FROM {$rt} WHERE seller_account_id=%d AND seller_ar_adjustment_status='applied'",
                    $id
                ));
                $stats['sales'] = max(0, $stats['sales'] - $ret_adj);
            }
        }

        // Hitung Conversion Rate (CR %)
        if ($stats['visits'] > 0) {
            $stats['conversion_rate'] = round(($stats['orders'] / $stats['visits']) * 100, 1);
        } elseif ($stats['clicks'] > 0) {
            $stats['conversion_rate'] = round(($stats['orders'] / $stats['clicks']) * 100, 1);
        }

        // Rincian Komisi di Ledger
        if ($ledger && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $ledger)) === $ledger) {
            $stats['commission_pending'] = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(commission_amount), 0) FROM {$ledger} WHERE seller_account_id = %d AND status = 'pending'", $id));
            $stats['commission_ready']   = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(commission_amount), 0) FROM {$ledger} WHERE seller_account_id = %d AND status = 'ready'", $id));
            $stats['commission_paid']    = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(commission_amount), 0) FROM {$ledger} WHERE seller_account_id = %d AND status = 'paid'", $id));
            $stats['commission_total']   = $stats['commission_pending'] + $stats['commission_ready'] + $stats['commission_paid'];
        }

        return $stats;
    }

    /**
     * Rincian Data Tautan Afiliasi Tertentu
     */
    public static function link_details($seller_id, $link_id) {
        global $wpdb;
        $lt = self::table('affiliate_links');
        $at = self::table('affiliate_attributions');
        $so = self::table('sales_orders') ?: self::table('orders');
        $pt = self::table('products');
        $vt = self::table('product_variants') ?: self::table('variants');

        $link = $wpdb->get_row($wpdb->prepare(
            "SELECT l.*, p.name as product_name, p.code as product_code, v.sku 
             FROM {$lt} l 
             INNER JOIN {$vt} v ON v.id = l.variant_id 
             INNER JOIN {$pt} p ON p.id = v.product_id 
             WHERE l.id = %d AND l.seller_account_id = %d LIMIT 1",
            (int)$link_id, (int)$seller_id
        ), ARRAY_A);

        if (!$link) return null;

        $d = $link + ['visits' => 0, 'orders' => 0, 'sales' => 0, 'commission' => 0, 'channels' => []];

        if ($at) {
            $d['visits'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visit_key) FROM {$at} WHERE affiliate_link_id = %d", $link_id));
            $d['channels'] = $wpdb->get_results($wpdb->prepare("SELECT channel, COUNT(*) as visits, MAX(created_at) as last_at FROM {$at} WHERE affiliate_link_id = %d GROUP BY channel ORDER BY visits DESC", $link_id), ARRAY_A) ?: [];
        }

        if ($so) {
            $d['orders'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$so} WHERE affiliate_link_id = %d AND status NOT IN ('cancelled', 'batal')", $link_id));
            $d['sales']  = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total_amount), SUM(gross), 0) FROM {$so} WHERE affiliate_link_id = %d AND status NOT IN ('cancelled', 'batal')", $link_id));
            $d['commission'] = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(commission), SUM(affiliate_commission_amount), 0) FROM {$so} WHERE affiliate_link_id = %d AND status NOT IN ('cancelled', 'batal')", $link_id));
        }

        return $d;
    }

    /**
     * Riwayat Pesanan Masuk Lewat Afiliasi Seller
     */
    public static function seller_orders($seller_id, $limit = 30) {
        global $wpdb;
        $so = self::table('sales_orders') ?: self::table('orders');
        if (!$so) return [];

        return $wpdb->get_results($wpdb->prepare(
            "SELECT id, order_no, status, payment_status, shipping_status, tracking_no, total_amount as gross, commission as affiliate_commission_amount, affiliate_channel, created_at 
             FROM {$so} 
             WHERE (affiliate_seller_id = %d OR seller_id = %d) 
             ORDER BY id DESC LIMIT %d",
            (int)$seller_id, (int)$seller_id, max(1, min(100, (int)$limit))
        ), ARRAY_A) ?: [];
    }

    /**
     * Riwayat Mutasi Komisi Afiliasi (Buku Besar Komisi)
     */
    public static function seller_commissions($seller_id, $limit = 50) {
        global $wpdb;
        $l  = self::table('seller_affiliate_ledger');
        $so = self::table('sales_orders') ?: self::table('orders');
        if (!$l) return [];

        return $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, o.order_no, o.status as order_status, o.created_at as order_created 
             FROM {$l} l 
             LEFT JOIN {$so} o ON o.id = l.order_id 
             WHERE l.seller_account_id = %d 
             ORDER BY l.id DESC LIMIT %d",
            (int)$seller_id, max(1, min(100, (int)$limit))
        ), ARRAY_A) ?: [];
    }

    /**
     * Validasi Kelengkapan Produk untuk Ekspor Katalog Marketplace
     */
    public static function validate($variant_id, $marketplace) {
        $d = self::product_data($variant_id);
        $m = self::marketplaces()[$marketplace] ?? null;
        if (!$m) throw new Exception('Marketplace belum didukung.');

        $missing = [];
        foreach (['name', 'sku'] as $f) {
            if (trim((string)($d[$f] ?? '')) === '') $missing[] = $f;
        }
        if (empty($d['images'])) $missing[] = 'images';
        if ($d['price'] <= 0)    $missing[] = 'price (harga)';

        return ['ready' => empty($missing), 'missing' => $missing, 'data' => $d, 'marketplace' => $m];
    }

    /**
     * Ambil Spesifikasi Lengkap Varian Produk untuk Integrasi
     */
    private static function product_data($variant_id) {
        global $wpdb;
        $vt = self::table('product_variants') ?: self::table('variants');
        $pt = self::table('products');

        $v = $wpdb->get_row($wpdb->prepare(
            "SELECT v.*, p.name as prod_name, p.code as prod_code, p.description, p.image_id 
             FROM {$vt} v 
             INNER JOIN {$pt} p ON p.id = v.product_id 
             WHERE v.id = %d LIMIT 1",
            (int)$variant_id
        ), ARRAY_A);

        if (!$v) throw new Exception('Produk atau varian tidak ditemukan di master database.');

        $images = [];
        if (!empty($v['image_id'])) {
            $u = wp_get_attachment_url((int)$v['image_id']);
            if ($u) $images[] = $u;
        }

        $price = (float)($v['price'] ?? 0);
        if ($price <= 0) {
            $pp = self::table('pricing') ?: self::table('product_prices');
            if ($pp) {
                $price = (float) $wpdb->get_var($wpdb->prepare("SELECT price FROM {$pp} WHERE sku = %s AND status = 'approved' ORDER BY id DESC LIMIT 1", $v['sku']));
            }
        }

        return [
            'product_id'   => (int)$v['product_id'],
            'variant_id'   => (int)$v['id'],
            'product_code' => $v['prod_code'] ?? '',
            'sku'          => $v['sku'],
            'name'         => $v['prod_name'] . (!empty($v['name']) && $v['name'] !== $v['prod_name'] ? ' - ' . $v['name'] : ''),
            'description'  => $v['description'] ?? '',
            'material'     => $v['material'] ?? '',
            'size'         => $v['size'] ?? '',
            'finishing'    => $v['finishing'] ?? '',
            'price'        => $price,
            'hpp'          => (float)($v['hpp'] ?? 0),
            'stock'        => (float)($v['stock'] ?? 0),
            'images'       => $images
        ];
    }

    /**
     * Ekspor Paket Katalog Produk untuk Upload Massal Marketplace (Shopee/TikTok/Tokopedia)
     */
    public static function export_package($seller_id, $variant_id, $marketplace, $format = 'csv') {
        if (!self::admin() && (!self::seller_account() || (int)self::seller_account()['id'] !== (int)$seller_id)) {
            throw new Exception('Anda tidak memiliki hak otorisasi untuk membuat paket ekspor ini.');
        }

        $check = self::validate($variant_id, $marketplace);
        if (!$check['ready']) {
            throw new Exception('Data produk belum lengkap: ' . implode(', ', $check['missing']) . '. Silakan lengkapi di Master Produk.');
        }

        $uploads = wp_upload_dir();
        $base = trailingslashit($uploads['basedir']) . 'pk01-exports';
        $urlbase = trailingslashit($uploads['baseurl']) . 'pk01-exports';

        if (!wp_mkdir_p($base)) throw new Exception('Folder direktori ekspor server tidak dapat dibuat.');

        $d = $check['data'];
        $safe_name = sanitize_file_name($marketplace . '-' . ($d['sku'] ?: 'item') . '-' . gmdate('Ymd-His'));
        $target_file = trailingslashit($base) . $safe_name . '.' . $format;

        if ($format === 'json') {
            file_put_contents($target_file, wp_json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        } else {
            // Default CSV
            $fh = fopen($target_file, 'wb');
            if (!$fh) throw new Exception('File CSV tidak dapat dibuat di server.');
            fputcsv($fh, array_keys($d));
            fputcsv($fh, array_values($d));
            fclose($fh);
        }

        return [
            'path'     => $target_file,
            'url'      => trailingslashit($urlbase) . $safe_name . '.' . $format,
            'filename' => $safe_name . '.' . $format,
            'ready'    => true
        ];
    }
}

// Inisialisasi Engine Afiliasi PK01
