<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Administrator dapat melihat tampilan nyata Seller melalui Pusat Pratinjau.
// Pratinjau hanya memilih data tampilan; tidak boleh menjalankan mutasi.
$pk01_admin_preview = class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview() && current_user_can('manage_options') && PK01_Authorization::normalize_role(sanitize_key(wp_unslash($_GET['pk01_role_preview'] ?? ''))) === 'pk01_seller';

// 1. AUTENTIKASI MITRA SELLER (VIA USER LOGIN ATAU TOKEN PORTAL)
$token = sanitize_text_field($_GET['pk01_seller'] ?? '');
$uid   = get_current_user_id();
$seller = null;

$tbl_sellers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('sales_accounts') 
    : ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}pk01_sellers'") ? $wpdb->prefix . 'pk01_sellers' : $wpdb->prefix . 'pk01_sales_accounts');

if ($uid && $tbl_sellers) {
    $seller = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$tbl_sellers}` WHERE user_id = %d AND type = 'seller' AND active = 1 LIMIT 1", 
        $uid
    ), ARRAY_A);
}

if (!$seller && $token && $tbl_sellers) {
    $seller = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$tbl_sellers}` WHERE portal_token = %s AND type = 'seller' AND active = 1 LIMIT 1", 
        $token
    ), ARRAY_A);
}

// Dalam pratinjau Administrator, ambil satu akun Seller aktif nyata hanya
// sebagai konteks tampilan agar seluruh layout portal dapat terlihat.
// Ini tidak mengubah akun login Administrator dan tidak membuat akun/data baru.
if (!$seller && $pk01_admin_preview && $tbl_sellers) {
    $seller = $wpdb->get_row(
        "SELECT * FROM `{$tbl_sellers}` WHERE type = 'seller' AND active = 1 ORDER BY id ASC LIMIT 1",
        ARRAY_A
    );
}

if (!$seller) {
    echo '<div class="pk01-op-card" style="max-width:500px;margin:60px auto;text-align:center;padding:32px;background:#ffffff;border-radius:14px;box-shadow:0 4px 12px rgba(0,0,0,0.05);">'
       . '<div style="font-size:36px;margin-bottom:8px;">🔒</div>'
       . '<h2 style="color:#0f172a;margin:0 0 6px 0;">Tautan Mitra Tidak Valid</h2>'
       . '<p style="color:#64748b;font-size:13px;margin:0 0 16px 0;">Tautan portal tidak ditemukan atau akun mitra Anda sedang dinonaktifkan oleh Admin.</p>'
       . '<a href="' . esc_url(home_url('/')) . '" style="display:inline-block;padding:8px 16px;background:#0f172a;color:#fff;text-decoration:none;border-radius:6px;font-size:12px;font-weight:700;">Kembali ke Beranda</a>'
       . '</div>';
    return;
}

$notice = '';
if ($pk01_admin_preview) {
    $notice = '<div class="pk01-slr-alert is-info"><strong>Pratinjau Dashboard Seller.</strong> Administrator sedang melihat tampilan Seller menggunakan data nyata. Semua aksi perubahan dinonaktifkan.</div>';
}
$current_month = current_time('Y-m');

// 2. PROSES AJUKAN PENGAMBILAN BARANG KONSINYASI KE GUDANG (LOGIKA LAMA UTUH)
if (!$pk01_admin_preview && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_portal_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_portal_nonce'] ?? '')), 'pk01_portal_save')) {
        $notice = '<div class="pk01-slr-alert is-error">⚠️ Sesi tidak valid atau telah kedaluwarsa. Silakan muat ulang.</div>';
    } else {
        try {
            $action = sanitize_key($_POST['pk01_portal_action'] ?? 'request');
            if ($action === 'marketplace_order') {
                $r = PK01_Engine::seller_submit_marketplace_order((int)$seller['id'], (int)$_POST['variant_id'], (float)$_POST['qty'], sanitize_key($_POST['marketplace'] ?? 'marketplace'), sanitize_text_field($_POST['marketplace_order_no'] ?? ''), strtoupper(sanitize_text_field($_POST['tracking_no'] ?? '')), sanitize_text_field($_POST['seller_sku'] ?? ''));
                $order_tag = !empty($r['order_no']) ? $r['order_no'] : '';
                if ($order_tag === '') throw new Exception('Nomor order Seller tidak diterbitkan oleh registry PK01.');
                $notice = '<div class="pk01-slr-alert is-success">✅ Order <strong>#' . esc_html($order_tag) . '</strong> sudah masuk ke antrean <strong>Kasir PK01</strong>. Stok belum dipotong sampai Kasir menerima order.</div>';
            } else {
                $r = PK01_Engine::seller_create_order((int)$seller['id'], (int)$_POST['variant_id'], (float)$_POST['qty']);
                $order_tag = !empty($r['order_no']) ? $r['order_no'] : '';
                if ($order_tag === '') throw new Exception('Nomor order Seller tidak diterbitkan oleh registry PK01.');
                $notice = '<div class="pk01-slr-alert is-success">✅ Permintaan pengambilan barang <strong>#' . esc_html($order_tag) . '</strong> berhasil dikirimkan ke antrean gudang!</div>';
            }
        } catch (Throwable $e) {
            $notice = '<div class="pk01-slr-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 3. IDENTIFIKASI TABEL SISTEM TERKAIT
$tbl_sales_orders = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('sales_orders') : ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}pk01_orders'") ? $wpdb->prefix . 'pk01_orders' : $wpdb->prefix . 'pk01_sales_orders');
$tbl_shipments    = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('shipments') : $wpdb->prefix . 'pk01_shipments';
$tbl_invoices     = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('seller_invoices') : $wpdb->prefix . 'pk01_seller_invoices';
$tbl_payments     = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('seller_payments') : $wpdb->prefix . 'pk01_seller_payments';
$tbl_stock        = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('seller_stock') : $wpdb->prefix . 'pk01_seller_stock';
$tbl_variants     = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_variants') : $wpdb->prefix . 'pk01_product_variants';
$tbl_products     = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('products') : $wpdb->prefix . 'pk01_products';
$tbl_stock_tx     = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('stock_transactions') : $wpdb->prefix . 'pk01_stock_transactions';
$tbl_targets      = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('seller_targets') : $wpdb->prefix . 'pk01_seller_targets';
$tbl_returns      = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('returns') : $wpdb->prefix . 'pk01_returns';
$tbl_return_items = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('return_items') : $wpdb->prefix . 'pk01_return_items';

/* Seller: harga marketplace per kanal dapat diatur tanpa mengubah HPP/tagihan PK01. */
if (!$pk01_admin_preview && isset($_POST['pk01_marketplace_price_save']) && isset($_POST['pk01_marketplace_price_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_marketplace_price_nonce'])),'pk01_marketplace_price')) {
    try {
        $mp=sanitize_key(wp_unslash($_POST['marketplace']??'')); $vid=absint($_POST['variant_id']??0); $price=(float)($_POST['marketplace_price']??0);
        if(!$vid || !isset(PK01_Marketplace_Catalog::marketplaces()[$mp])) throw new Exception('Marketplace atau produk tidak valid.');
        PK01_Marketplace_Catalog::set_seller_marketplace_price((int)$seller['id'],$mp,$vid,$price);
        $notice='<div class="pk01-slr-alert is-success">✅ Harga marketplace berhasil disimpan. Harga tagihan/HPP PK01 tidak berubah.</div>';
    } catch(Throwable $e){$notice='<div class="pk01-slr-alert is-error">❌ '.esc_html($e->getMessage()).'</div>';}
}

/* Seller: katalog marketplace selalu berasal dari Master PK01. */
if (!$pk01_admin_preview && isset($_GET['pk01_catalog_export']) && sanitize_key($_GET['pk01_catalog_export']) === '1') {
    $mp=sanitize_key($_GET['marketplace']??'generic');
    $profiles=class_exists('PK01_Marketplace_Catalog')?PK01_Marketplace_Catalog::profiles():[];
    if(!isset($profiles[$mp]))$mp='generic';
    try {
        $tpl=PK01_Marketplace_Catalog::get_template($mp); $fmt=strtolower((string)($tpl['format']??'csv'));
        if($fmt==='xlsx'){ $file=PK01_Marketplace_Catalog::export_csv((int)$seller['id'],$mp); if(!is_string($file)||!is_file($file)) throw new Exception('File XLSX tidak berhasil dibuat.'); nocache_headers(); header('Content-Type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename=pk01-'.sanitize_file_name($mp).'-catalog-'.date('Ymd-His').'.xlsx'); readfile($file); @unlink($file); }
        else { nocache_headers(); header('Content-Type:'.($fmt==='tsv'?'text/tab-separated-values':'text/csv').'; charset=utf-8'); header('Content-Disposition: attachment; filename=pk01-'.sanitize_file_name($mp).'-catalog-'.date('Ymd-His').'.'.($fmt==='tsv'?'tsv':'csv')); PK01_Marketplace_Catalog::export_csv((int)$seller['id'],$mp); }
    } catch(Throwable $e) { wp_die(esc_html($e->getMessage()),'Export marketplace',['response'=>409]); }
    exit;
}


// 4. HITUNG PERINGKAT & KOMPARASI DENGAN SELLER LAIN (REAL BENCHMARK)
$leaderboard = [];
if ($tbl_sales_orders) {
    $leaderboard = $wpdb->get_results($wpdb->prepare(
        "SELECT seller_id, COALESCE(SUM(total_amount), 0) AS omzet 
         FROM `{$tbl_sales_orders}` 
         WHERE seller_id > 0 AND status NOT IN ('cancelled','batal','failed') 
         AND DATE_FORMAT(created_at, '%%Y-%%m') = %s 
         GROUP BY seller_id ORDER BY omzet DESC",
        $current_month
    ), ARRAY_A) ?: [];
}

$my_rank = 0;
$my_month_omzet = 0;
$other_sellers_omzet_sum = 0;
$total_active_sellers = count($leaderboard);

foreach ($leaderboard as $idx => $lb) {
    if ((int)$lb['seller_id'] === (int)$seller['id']) {
        $my_rank = $idx + 1;
        $my_month_omzet = (float)$lb['omzet'];
    } else {
        $other_sellers_omzet_sum += (float)$lb['omzet'];
    }
}

$other_sellers_count = max(1, $total_active_sellers - ($my_rank > 0 ? 1 : 0));
$avg_other_sellers   = $other_sellers_omzet_sum / $other_sellers_count;

// Persentase Kinerja Lebih Baik dari Seller Lain
$sellers_below_me   = ($my_rank > 0) ? max(0, $total_active_sellers - $my_rank) : 0;
$outperform_percent = ($total_active_sellers > 1) ? round(($sellers_below_me / ($total_active_sellers - 1)) * 100) : 100;

// Selisih ke Juara 1
$top_omzet = !empty($leaderboard) ? (float)$leaderboard[0]['omzet'] : 0;
$gap_to_top = max(0, $top_omzet - $my_month_omzet);

$rank_badge = ($my_rank === 1) ? '🥇 Juara 1' : (($my_rank === 2) ? '🥈 Juara 2' : (($my_rank === 3) ? '🥉 Juara 3' : ($my_rank > 0 ? '#' . $my_rank : 'Belum Ada Transaksi')));

// 5. HISTORI PENJUALAN SELLER PER BULAN & PER TAHUN (LIFETIME AGGREGATION)
$monthly_sales_history = [];
$yearly_sales_history  = [];
$lifetime_omzet_all    = 0;
$lifetime_orders_all   = 0;
$lifetime_comm_all     = 0;

if ($tbl_sales_orders) {
    $return_join = ($tbl_returns && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_returns)) === $tbl_returns)
        ? "LEFT JOIN (SELECT order_id, COALESCE(SUM(CASE WHEN seller_ar_adjustment_status='applied' THEN seller_adjustment_amount ELSE 0 END),0) AS return_amount FROM `{$tbl_returns}` WHERE status NOT IN ('cancelled') GROUP BY order_id) rr ON rr.order_id = so.id"
        : "LEFT JOIN (SELECT 0 AS order_id, 0 AS return_amount) rr ON rr.order_id = so.id";
    $monthly_sales_history = $wpdb->get_results($wpdb->prepare(
        "SELECT
            DATE_FORMAT(so.created_at, '%%Y-%%m') AS period_key,
            YEAR(so.created_at) AS yr,
            MONTH(so.created_at) AS mo,
            COUNT(so.id) AS total_orders,
            COALESCE(SUM(so.total_amount), 0) AS total_omzet,
            COALESCE(SUM(COALESCE(rr.return_amount,0)), 0) AS total_retur,
            COALESCE(SUM(GREATEST(so.total_amount-COALESCE(rr.return_amount,0),0)), 0) AS total_omzet_net,
            COALESCE(SUM(so.commission), 0) AS total_komisi,
            COALESCE(SUM(CASE WHEN LOWER(COALESCE(so.commission_status, '')) = 'paid' THEN so.commission ELSE 0 END), 0) AS komisi_cair,
            COALESCE(SUM(CASE WHEN LOWER(COALESCE(so.commission_status, 'pending')) IN ('pending', 'unpaid', '') THEN so.commission ELSE 0 END), 0) AS komisi_pending
         FROM `{$tbl_sales_orders}` so
         {$return_join}
         WHERE so.seller_id = %d AND so.status NOT IN ('cancelled', 'batal', 'failed')
         GROUP BY period_key, yr, mo
         ORDER BY period_key DESC",
        (int)$seller['id']
    ), ARRAY_A) ?: [];

    foreach ($monthly_sales_history as $msh) {
        $y = $msh['yr'];
        if (!isset($yearly_sales_history[$y])) {
            $yearly_sales_history[$y] = [
                'year'         => $y,
                'total_orders' => 0,
                'total_omzet'  => 0,
                'total_retur'  => 0,
                'total_omzet_net' => 0,
                'total_komisi' => 0
            ];
        }
        $yearly_sales_history[$y]['total_orders'] += (int)$msh['total_orders'];
        $yearly_sales_history[$y]['total_omzet']  += (float)$msh['total_omzet'];
        $yearly_sales_history[$y]['total_retur']  += (float)($msh['total_retur'] ?? 0);
        $yearly_sales_history[$y]['total_omzet_net'] += (float)($msh['total_omzet_net'] ?? $msh['total_omzet']);
        $yearly_sales_history[$y]['total_komisi'] += (float)$msh['total_komisi'];

        $lifetime_omzet_all  += (float)$msh['total_omzet'];
        $lifetime_orders_all += (int)$msh['total_orders'];
        $lifetime_comm_all   += (float)$msh['total_komisi'];
    }
}

// 6. TAGIHAN KONSINYASI SELLER (HUTANG KE TOKO KITA)
$seller_invoices = [];
$total_invoiced_val  = 0;
$total_paid_to_store = 0;

if ($tbl_invoices && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_invoices)) === $tbl_invoices) {
    $pay_subquery = ($tbl_payments && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_payments)) === $tbl_payments) 
        ? "(SELECT SUM(amount) FROM `{$tbl_payments}` WHERE invoice_id = i.id)" 
        : "0";

    $seller_invoices = $wpdb->get_results($wpdb->prepare(
        "SELECT i.*, COALESCE({$pay_subquery}, 0) AS total_paid 
         FROM `{$tbl_invoices}` i 
         WHERE i.seller_account_id = %d 
         ORDER BY i.id DESC LIMIT 50",
        (int)$seller['id']
    ), ARRAY_A) ?: [];

    foreach ($seller_invoices as $k => $inv) {
        $tot  = (float)($inv['total'] ?? 0);
        $pd   = (float)($inv['total_paid'] ?? 0);
        $rem  = max(0, $tot - $pd);
        $total_invoiced_val  += $tot;
        $total_paid_to_store += $pd;
        $seller_invoices[$k]['remaining_debt'] = $rem;
    }
}
$remaining_debt_to_store = max(0, $total_invoiced_val - $total_paid_to_store);

// 6B. LAPORAN KEUANGAN SELLER — SATU SUMBER DATA DARI ORDER, RETUR, INVOICE & PEMBAYARAN RIIL.
$gross_sales_all = 0.0;
$return_sales_all = 0.0;
$net_sales_all = 0.0;
$return_rows = [];
$tbl_seller_sales = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('seller_sales') : $wpdb->prefix . 'pk01_seller_sales';
if ($tbl_seller_sales && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_seller_sales)) === $tbl_seller_sales) {
    $gross_sales_all = (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN COALESCE(source_type,'seller_order')='return_adjustment' THEN 0 ELSE total END),0) FROM `{$tbl_seller_sales}` WHERE seller_account_id=%d AND COALESCE(status,'pending') NOT IN ('cancelled','failed')",
        (int)$seller['id']
    ));
}
if ($tbl_returns && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_returns)) === $tbl_returns) {
    $return_rows = $wpdb->get_results($wpdb->prepare(
        "SELECT r.*, so.order_no, so.created_at AS order_created_at
         FROM `{$tbl_returns}` r
         LEFT JOIN `{$tbl_sales_orders}` so ON so.id=r.order_id
         WHERE r.seller_account_id=%d AND r.status NOT IN ('cancelled')
         ORDER BY r.id DESC LIMIT 100",
        (int)$seller['id']
    ), ARRAY_A) ?: [];
    $return_sales_all = (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN seller_ar_adjustment_status='applied' THEN seller_adjustment_amount ELSE 0 END),0)
         FROM `{$tbl_returns}` WHERE seller_account_id=%d AND status NOT IN ('cancelled')",
        (int)$seller['id']
    ));
}
$net_sales_all = max(0, $gross_sales_all - $return_sales_all);
$invoice_unpaid = 0.0;
$invoice_paid = 0.0;
if ($seller_invoices) {
    foreach ($seller_invoices as $inv) {
        $invoice_paid += (float)($inv['total_paid'] ?? 0);
        $invoice_unpaid += max(0, (float)($inv['remaining_debt'] ?? 0));
    }
}
$invoice_status_counts = ['paid'=>0,'partial'=>0,'unpaid'=>0];
foreach ($seller_invoices as $inv) {
    $st = strtolower((string)($inv['status'] ?? 'unpaid'));
    if (!isset($invoice_status_counts[$st])) $st = ((float)($inv['remaining_debt'] ?? 0) <= 0) ? 'paid' : (((float)($inv['total_paid'] ?? 0) > 0) ? 'partial' : 'unpaid');
    $invoice_status_counts[$st]++;
}

// 7. KOMISI SELLER (BELUM CAIR VS SUDAH CAIR)
$pending_commissions = 0;
$paid_commissions    = 0;
$my_orders_tracking  = [];

if ($tbl_sales_orders && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_sales_orders)) === $tbl_sales_orders) {
    $pending_commissions = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(commission), 0) FROM `{$tbl_sales_orders}` 
         WHERE seller_id = %d 
         AND LOWER(COALESCE(commission_status, 'pending')) IN ('pending', 'unpaid', '') 
         AND status NOT IN ('cancelled', 'batal', 'failed')",
        (int)$seller['id']
    ));

    $paid_commissions = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(commission), 0) FROM `{$tbl_sales_orders}` 
         WHERE seller_id = %d 
         AND LOWER(COALESCE(commission_status, '')) = 'paid' 
         AND status NOT IN ('cancelled', 'batal', 'failed')",
        (int)$seller['id']
    ));

    // Kueri Pesanan Seller dengan Pelacakan Kurir Real-Time
    $legacy_orders = $wpdb->get_results($wpdb->prepare(
        "SELECT o.id,o.order_no,o.created_at,o.customer_name,o.shipping_address,o.total_amount,o.commission,o.tracking_no,o.shipping_status,o.status,
                sh.tracking_no AS ship_awb, sh.courier AS ship_courier, sh.status AS ship_status, sh.last_event_at, 'company_sale' AS row_type
         FROM `{$tbl_sales_orders}` o
         LEFT JOIN `{$tbl_shipments}` sh ON (sh.sale_id=o.id OR (sh.tracking_no=o.tracking_no AND o.tracking_no<>''))
         WHERE o.seller_id=%d AND o.status NOT IN ('cancelled','failed')", (int)$seller['id']), ARRAY_A) ?: [];
    $seller_rows = [];
    if($tbl_seller_sales && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$tbl_seller_sales))===$tbl_seller_sales){
        $seller_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT ss.id,so.order_no,ss.sold_at AS created_at,sa.name AS customer_name,'' AS shipping_address,ss.total AS total_amount,0 AS commission,
                    COALESCE(sh.tracking_no,ss.tracking_no,so.tracking_no) AS ship_awb,COALESCE(sh.courier,'') AS ship_courier,COALESCE(sh.status,'on_process') AS ship_status,sh.last_event_at,
                    ss.tracking_no,ss.status AS shipping_status,ss.status,'seller_marketplace' AS row_type,ss.marketplace,ss.marketplace_order_no
             FROM `{$tbl_seller_sales}` ss
             LEFT JOIN `".PK01_DB::t('seller_orders')."` so ON so.id=ss.order_id
             LEFT JOIN `".PK01_DB::t('sales_accounts')."` sa ON sa.id=ss.seller_account_id
             LEFT JOIN `{$tbl_shipments}` sh ON sh.seller_sale_id=ss.id
             WHERE ss.seller_account_id=%d AND COALESCE(ss.source_type,'seller_order')<>'return_adjustment'
             ORDER BY ss.id DESC LIMIT 100",(int)$seller['id']),ARRAY_A) ?: [];
    }
    $my_orders_tracking=array_merge($legacy_orders,$seller_rows);
    usort($my_orders_tracking,function($a,$b){return strcmp((string)($b['created_at']??''),(string)($a['created_at']??''));});
    $my_orders_tracking=array_slice($my_orders_tracking,0,100);
}

// 8. STOK FISIK DI TANGAN & KATALOG PENGAMBILAN GUDANG
$my_stock = [];
if ($tbl_stock && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_stock)) === $tbl_stock) {
    $my_stock = $wpdb->get_results($wpdb->prepare(
        "SELECT ss.qty, v.sku, p.name 
         FROM `{$tbl_stock}` ss 
         INNER JOIN `{$tbl_variants}` v ON v.id = ss.variant_id 
         INNER JOIN `{$tbl_products}` p ON p.id = v.product_id 
         WHERE ss.seller_account_id = %d AND ss.qty > 0", 
        (int)$seller['id']
    ), ARRAY_A) ?: [];
}

$catalog = [];
if ($tbl_variants && $tbl_products) {
    $catalog = $wpdb->get_results(
        "SELECT v.id, v.sku, p.name, p.description, 
                COALESCE(SUM(CASE WHEN st.direction='in' THEN st.qty ELSE -st.qty END), 0) AS warehouse_stock 
         FROM `{$tbl_variants}` v 
         INNER JOIN `{$tbl_products}` p ON p.id = v.product_id 
         LEFT JOIN `{$tbl_stock_tx}` st ON st.stock_type='finished' AND st.item_id = v.id 
         WHERE v.status = 'active' AND p.status = 'active' 
         GROUP BY v.id", 
        ARRAY_A
    ) ?: [];
}

$format_money = function($val) {
    return 'Rp ' . number_format((float)$val, 0, ',', '.');
};
?>

<style>
:root {
    --pk-slr-navy: #0f172a;
    --pk-slr-border: #e2e8f0;
    --pk-slr-blue: #2563eb;
    --pk-slr-green: #059669;
    --pk-slr-amber: #d97706;
    --pk-slr-purple: #7c3aed;
    --pk-slr-red: #dc2626;
}

.pk01-seller-portal-hub {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-seller-portal-hub * { box-sizing: border-box; }

/* Hero Banner */
.pk01-portal-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #312e81 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-portal-eyebrow {
    display: inline-block;
    background: rgba(99, 102, 241, 0.2);
    color: #a5b4fc;
    border: 1px solid rgba(165, 180, 252, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-portal-hero h1 { margin: 0 0 6px 0; font-size: 24px; font-weight: 800; color: #f8fafc; }
.pk01-portal-hero p { margin: 0; font-size: 13px; color: #cbd5e1; max-width: 820px; line-height: 1.5; }

/* Rank Badge di Hero */
.pk01-rank-badge {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 10px 18px;
    text-align: right;
    min-width: 170px;
}
.pk01-rank-badge span { display: block; font-size: 10px; font-weight: 700; text-transform: uppercase; color: #94a3b8; }
.pk01-rank-badge strong { display: block; font-size: 16px; color: #fde047; margin-top: 2px; }

/* 5 Executive KPI Cards */
.pk01-portal-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; }
.pk01-kpi-card.c-red    { border-left-color: var(--pk-slr-red); }
.pk01-kpi-card.c-green  { border-left-color: var(--pk-slr-green); }
.pk01-kpi-card.c-amber  { border-left-color: var(--pk-slr-amber); }
.pk01-kpi-card.c-blue   { border-left-color: var(--pk-slr-blue); }
.pk01-kpi-card.c-purple { border-left-color: var(--pk-slr-purple); }

.pk01-kpi-card small { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; display: block; }
.pk01-kpi-card strong { font-size: 22px; font-weight: 800; color: #0f172a; display: block; margin: 6px 0 2px 0; }
.pk01-kpi-card span { font-size: 11px; color: #64748b; }

/* KOTAK KOMPARASI PERFORMA DENGAN SELLER LAIN */
.pk01-benchmark-box {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 14px;
    padding: 18px 22px;
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-benchmark-info h3 { margin: 0 0 4px; font-size: 15px; font-weight: 800; color: #0f172a; }
.pk01-benchmark-info p { margin: 0; font-size: 13px; color: #64748b; }
.pk01-benchmark-stat { display: flex; gap: 18px; align-items: center; flex-wrap: wrap; }
.pk01-benchmark-item { text-align: right; }
.pk01-benchmark-item small { display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 700; }
.pk01-benchmark-item b { font-size: 16px; font-family: monospace; color: #0f172a; }

/* Tabs Layout */
.pk01-portal-tabs {
    display: flex;
    gap: 8px;
    border-bottom: 2px solid var(--pk-slr-border);
    margin-bottom: 22px;
    overflow-x: auto;
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 18px;
    font-size: 13px;
    font-weight: 700;
    color: #64748b;
    border: none;
    background: transparent;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    margin-bottom: -2px;
    transition: all .15s ease;
    white-space: nowrap;
}
.pk01-tab-btn:hover { color: #0f172a; }
.pk01-tab-btn.active { color: var(--pk-slr-blue); border-bottom-color: var(--pk-slr-blue); }

.pk01-tab-pane { display: none; }
.pk01-tab-pane.active { display: block; animation: pk01Fade .2s ease-in-out; }
@keyframes pk01Fade { from { opacity: 0; transform: translateY(3px); } to { opacity: 1; transform: translateY(0); } }

/* Surface Card */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-head h3 { margin: 0; font-size: 17px; font-weight: 800; color: #0f172a; }

/* Table Style */
.pk01-table-wrap { overflow-x: auto; border: 1px solid var(--pk-slr-border); border-radius: 12px; }
.pk01-portal-table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
.pk01-portal-table th { background: #f8fafc; padding: 11px 12px; font-weight: 700; color: #475569; border-bottom: 2px solid var(--pk-slr-border); }
.pk01-portal-table td { padding: 11px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.pk01-portal-table tr:hover td { background: #fbfcfe; }

/* Badges */
.pk01-badge { display: inline-block; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; }
.badge-success { background: #dcfce7; color: #166534; }
.badge-warning { background: #fef3c7; color: #92400e; }
.badge-danger  { background: #fee2e2; color: #991b1b; }
.badge-info    { background: #e0e7ff; color: #3730a3; }

/* Buttons */
.pk01-btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; text-decoration: none !important; }
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-track { background: #2563eb; color: #ffffff !important; padding: 4px 10px; font-size: 11px; border-radius: 6px; }

/* Catalog Grid */
.pk01-catalog-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 16px;
}
.pk01-product-card {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 12px;
    padding: 16px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-product-card small { font-family: monospace; font-size: 11px; color: #64748b; font-weight: 700; }
.pk01-product-card h4 { margin: 4px 0 6px; font-size: 15px; font-weight: 800; color: #0f172a; }

.pk01-slr-alert { padding: 12px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; margin-bottom: 20px; }
.pk01-slr-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-slr-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-seller-portal-hub">
    
    <!-- 1. HERO BANNER PORTAL SELLER -->
    <header class="pk01-portal-hero">
        <div>
            <span class="pk01-portal-eyebrow">PORTAL RESMI MITRA SELLER &amp; AFILIASI</span>
            <h1>Halo, <?php echo esc_html($seller['name']); ?></h1>
            <p>
                Kelola penjualan Anda, pantau pengiriman kurir real-time ke pembeli, cek transparansi tagihan konsinyasi, 
                dan klaim komisi hasil kerja keras Anda dari satu dashboard terpadu.
            </p>
        </div>
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
            <!-- Badge Peringkat Juara Penjualan -->
            <div class="pk01-rank-badge">
                <span>Peringkat Penjualan Anda</span>
                <strong><?php echo esc_html($rank_badge); ?></strong>
            </div>
            <a class="pk01-btn" style="background:rgba(255,255,255,0.15);color:#fff;" href="<?php echo esc_url(home_url('/')); ?>">
                &larr; Kembali ke Toko
            </a>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. KOTAK KOMPARASI KINERJA DENGAN SELLER LAIN (BENCHMARK SELLER) -->
    <section class="pk01-benchmark-box">
        <div class="pk01-benchmark-info">
            <h3>📈 Analisis Posisi Penjualan Anda vs Rekan Seller Lain</h3>
            <p>
                <?php if ($my_rank > 0): ?>
                    Kinerja Anda bulan ini berada di <strong>Peringkat <?php echo esc_html($rank_badge); ?></strong> dari total <strong><?php echo (int)$total_active_sellers; ?> mitra seller aktif</strong>. 
                    <?php if ($outperform_percent > 0): ?>
                        Penjualan Anda <b style="color:#047857;">lebih unggul dari <?php echo $outperform_percent; ?>% seller lainnya</b>! 🚀
                    <?php endif; ?>
                <?php else: ?>
                    Anda belum memiliki transaksi pesanan berhasil di bulan ini. Bagikan tautan referral untuk mulai mencatatkan omzet dan meraih peringkat teratas!
                <?php endif; ?>
            </p>
        </div>
        <div class="pk01-benchmark-stat">
            <div class="pk01-benchmark-item">
                <small>Omzet Anda (Bulan Ini):</small>
                <b style="color:#047857;"><?php echo esc_html($format_money($my_month_omzet)); ?></b>
            </div>
            <div class="pk01-benchmark-item">
                <small>Rata-rata Seller Lain:</small>
                <b style="color:#2563eb;"><?php echo esc_html($format_money($avg_other_sellers)); ?></b>
            </div>
            <?php if ($gap_to_top > 0): ?>
            <div class="pk01-benchmark-item">
                <small>Selisih ke Juara 1:</small>
                <b style="color:#d97706;"><?php echo esc_html($format_money($gap_to_top)); ?></b>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- 3. 5 EXECUTIVE KPI CARDS REAL (HUTANG SELLER KE KITA & SALDO KOMISI) -->
    <div class="pk01-portal-kpis">
        <!-- SISA HUTANG KONSINYASI -->
        <div class="pk01-kpi-card c-red">
            <small>Sisa Tagihan Seller ke Toko</small>
            <strong style="color:#dc2626;"><?php echo $format_money($remaining_debt_to_store); ?></strong>
            <span>Barang diambil yang belum Anda setorkan</span>
        </div>

        <!-- SETORAN DITERIMA TOKO -->
        <div class="pk01-kpi-card c-green">
            <small>Setoran yang Sudah Diterima Toko</small>
            <strong style="color:#059669;"><?php echo $format_money($total_paid_to_store); ?></strong>
            <span>Uang fisik/transfer yang telah disetor</span>
        </div>

        <!-- KOMISI BELUM CAIR -->
        <div class="pk01-kpi-card c-amber">
            <small>Komisi Anda Belum Dicairkan</small>
            <strong style="color:#d97706;"><?php echo $format_money($pending_commissions); ?></strong>
            <span>Hak komisi penjualan menunggu pencairan</span>
        </div>

        <!-- TOTAL OMZET SAYA -->
        <div class="pk01-kpi-card c-blue">
            <small>Total Omzet Penjualan Saya</small>
            <strong style="color:#1d4ed8;"><?php echo $format_money($my_month_omzet); ?></strong>
            <span>Periode Bulan: <?php echo esc_html(date_i18n('F Y')); ?></span>
        </div>

        <!-- PENJUALAN BERSIH SETELAH RETUR -->
        <div class="pk01-kpi-card c-green">
            <small>Penjualan Bersih Setelah Retur</small>
            <strong style="color:#059669;"><?php echo $format_money($net_sales_all); ?></strong>
            <span>Omzet riil setelah retur diterima Gudang</span>
        </div>

        <!-- TOTAL RETUR YANG SUDAH MENGURANGI SELLER -->
        <div class="pk01-kpi-card c-red">
            <small>Nilai Retur Seller</small>
            <strong style="color:#dc2626;"><?php echo $format_money($return_sales_all); ?></strong>
            <span>Sudah mengurangi penjualan/tagihan Seller</span>
        </div>

        <!-- TAGIHAN BELUM DIBAYAR -->
        <div class="pk01-kpi-card c-amber">
            <small>Sisa Tagihan Saya</small>
            <strong style="color:#d97706;"><?php echo $format_money($invoice_unpaid); ?></strong>
            <span>Penjualan harga internal − retur diterima − pembayaran</span>
        </div>

        <!-- TAGIHAN SUDAH DIBAYAR -->
        <div class="pk01-kpi-card c-blue">
            <small>Total Pembayaran Saya</small>
            <strong style="color:#2563eb;"><?php echo $format_money($invoice_paid); ?></strong>
            <span>Setoran ke toko, tidak terkait ke resi tertentu</span>
        </div>

        <!-- STOK DI TANGAN SELLER -->
        <div class="pk01-kpi-card c-purple">
            <small>Stok Fisik di Tangan Saya</small>
            <strong style="color:#7c3aed;"><?php echo number_format(array_sum(array_column($my_stock, 'qty'))); ?> <span style="font-size:13px;font-weight:normal;">pcs</span></strong>
            <span>Barang konsinyasi siap dijual</span>
        </div>
    </div>

    <!-- 4. TABS NAVIGASI WORKSPACE SELLER -->
    <nav class="pk01-portal-tabs" aria-label="Menu Portal Seller">
        <button type="button" class="pk01-tab-btn" data-target="tab-seller-orders">🛍️ Order Penjualan ke Kasir</button>
        <button type="button" class="pk01-tab-btn active" data-target="tab-tracking">
            🚚 Status Pengiriman &amp; Resi Kurir (<?php echo count($my_orders_tracking); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-invoices">
            🧾 Rincian Tagihan &amp; Tagihan Seller (<?php echo count($seller_invoices); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-commissions">
            💰 Komisi Saya (Pending vs Cair)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-period-history">
            📊 Rekap Penjualan per Bulan &amp; Tahun
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-financial-report">📊 Laporan Penjualan, Retur &amp; Tagihan</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-marketplace-catalog">🛒 Katalog Marketplace</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-catalog">
            📦 Ambil Barang Gudang &amp; Link Afiliasi
        </button>
    </nav>

    <!-- TAB 1: PELACAKAN KURIR EKSPEDISI REAL-TIME -->
    <div class="pk01-tab-pane active" id="tab-tracking">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>🚚 Status Pengiriman &amp; Ekspedisi Pesanan Anda</h3>
                    <p>Pantau perjalanan pesanan pembeli Anda secara real-time seperti di platform e-commerce.</p>
                </div>
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-portal-table">
                    <thead>
                        <tr>
                            <th style="width:140px;">No. Pesanan</th>
                            <th>Pelanggan &amp; Tujuan</th>
                            <th>Ekspedisi &amp; No. Resi</th>
                            <th style="text-align:center;width:130px;">Status Kurir</th>
                            <th style="text-align:right;">Nilai Belanja</th>
                            <th style="text-align:right;">Komisi Anda</th>
                            <th style="text-align:center;width:120px;">Lacak Resi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($my_orders_tracking)): ?>
                            <?php foreach ($my_orders_tracking as $ord): 
                                $awb = !empty($ord['ship_awb']) ? $ord['ship_awb'] : ($ord['tracking_no'] ?? '');
                                $courier = !empty($ord['ship_courier']) ? $ord['ship_courier'] : ($ord['courier'] ?? 'jne');
                                $ship_st = strtolower($ord['ship_status'] ?: ($ord['shipping_status'] ?: 'pending'));

                                $badge_class = 'badge-warning';
                                $badge_label = 'Sedang Diproses';
                                if ($ship_st === 'shipped' || $ship_st === 'on_process' || !empty($awb)) {
                                    $badge_class = 'badge-info';
                                    $badge_label = 'Dalam Perjalanan';
                                }
                                if ($ship_st === 'delivered' || $ship_st === 'selesai' || $ord['status'] === 'completed') {
                                    $badge_class = 'badge-success';
                                    $badge_label = 'Paket Diterima';
                                }

                                $direct_track_url = class_exists('PK01_Shipping_Engine') && method_exists('PK01_Shipping_Engine', 'get_direct_tracking_url')
                                    ? PK01_Shipping_Engine::get_direct_tracking_url($courier, $awb)
                                    : 'https://cekresi.com/?noresi=' . urlencode($awb);
                            ?>
                            <tr>
                                <td>
                                    <strong style="font-family:monospace;color:#0f172a;"><?php echo esc_html($ord['order_no']); ?></strong>
                                    <small style="display:block;color:#64748b;"><?php echo esc_html(date('d/m/Y H:i', strtotime($ord['created_at']))); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($ord['customer_name']); ?></strong>
                                    <div style="font-size:11px;color:#64748b;"><?php echo esc_html(mb_strimwidth($ord['shipping_address'] ?: 'Alamat tertera di invoice', 0, 35, '...')); ?></div>
                                </td>
                                <td>
                                    <?php if (!empty($awb)): ?>
                                        <strong style="font-size:12px;display:block;color:#1e40af;"><?php echo esc_html(strtoupper($courier)); ?></strong>
                                        <code style="font-size:11px;font-weight:700;"><?php echo esc_html($awb); ?></code>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;font-size:12px;font-style:italic;">Menunggu nomor resi</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo esc_attr($badge_class); ?>">
                                        <?php echo esc_html($badge_label); ?>
                                    </span>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;">
                                    <?php echo esc_html($format_money($ord['total_amount'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:800;color:#047857;">
                                    <?php echo esc_html($format_money($ord['commission'])); ?>
                                </td>
                                <td style="text-align:center;">
                                    <?php if (!empty($awb)): ?>
                                        <a href="<?php echo esc_url($direct_track_url); ?>" target="_blank" class="pk01-btn-track">
                                            🔗 Web Kurir
                                        </a>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;font-size:11px;">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align:center;padding:32px;color:#94a3b8;">
                                    Belum ada pesanan yang terdaftar melalui akun Anda.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 2: RINCIAN TAGIHAN & HUTANG KONSINYASI KE TOKO -->
    <div class="pk01-tab-pane" id="tab-invoices">
        <section class="pk01-surface" style="border-left:4px solid #dc2626;">
            <div class="pk01-surface-head">
                <div>
                    <h3>🧾 Tagihan Saya ke Toko (Penjualan PK01)</h3>
                    <p>
                        Tagihan dihitung dari penjualan yang tercatat di PK01 dengan harga internal Seller. <strong>Retur yang sudah diterima Gudang mengurangi tagihan</strong>, sedangkan pembayaran mengurangi saldo tagihan secara keseluruhan. Resi hanya untuk monitoring penjualan/retur.
                    </p>
                </div>
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-portal-table">
                    <thead>
                        <tr>
                            <th style="width:140px;">No. Faktur</th>
                            <th>Tanggal Terbit</th>
                            <th>Jatuh Tempo</th>
                            <th style="text-align:right;">Nilai Barang Diambil</th>
                            <th style="text-align:right;">Sudah Saya Setor</th>
                            <th style="text-align:right;">Sisa Hutang ke Toko</th>
                            <th style="text-align:center;width:110px;">Status Tagihan</th>
                            <th>Catatan Barang</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($seller_invoices)): ?>
                            <?php foreach ($seller_invoices as $inv): 
                                $rem = (float)$inv['remaining_debt'];
                                $is_lunas = ($rem <= 0);
                            ?>
                            <tr>
                                <td>
                                    <strong style="font-family:monospace;color:#0f172a;"><?php echo esc_html($inv['invoice_no']); ?></strong>
                                </td>
                                <td style="color:#64748b;font-size:12px;">
                                    <?php echo esc_html(date('d/m/Y', strtotime($inv['created_at']))); ?>
                                </td>
                                <td>
                                    <span style="font-size:12px;color:<?php echo (!empty($inv['due_date']) && strtotime($inv['due_date']) < current_time('timestamp') && !$is_lunas) ? '#dc2626;font-weight:700;' : '#475569;'; ?>">
                                        <?php echo !empty($inv['due_date']) ? esc_html(date('d/m/Y', strtotime($inv['due_date']))) : '—'; ?>
                                    </span>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;">
                                    <?php echo esc_html($format_money($inv['total'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:700;color:#059669;">
                                    <?php echo esc_html($format_money($inv['total_paid'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:800;color:<?php echo $is_lunas ? '#047857;' : '#dc2626;'; ?>">
                                    <?php echo esc_html($format_money($rem)); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo $is_lunas ? 'badge-success' : 'badge-danger'; ?>">
                                        <?php echo $is_lunas ? 'Lunas' : 'Belum Lunas'; ?>
                                    </span>
                                </td>
                                <td style="font-size:12px;color:#64748b;">
                                    <?php echo esc_html($inv['notes'] ?: '—'); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align:center;padding:32px;color:#94a3b8;">
                                    Tidak ada tagihan Seller untuk akun Anda.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 3: STATUS KOMISI SAYA (PENDING VS CAIR) -->
    <div class="pk01-tab-pane" id="tab-commissions">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>💰 Status Pencairan Komisi Penjualan Anda</h3>
                    <p>Komisi otomatis tercatat saat pesanan selesai dibayar oleh pembeli. Admin mencairkan komisi secara berkala ke rekening Anda.</p>
                </div>
            </div>

            <div class="pk01-table-wrap">
                <table class="pk01-portal-table">
                    <thead>
                        <tr>
                            <th>Waktu Order</th>
                            <th>No. Pesanan</th>
                            <th>Produk</th>
                            <th style="text-align:right;">Nilai Belanja</th>
                            <th style="text-align:right;">Hak Komisi Anda</th>
                            <th style="text-align:center;width:130px;">Status Komisi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($my_orders_tracking)): ?>
                            <?php foreach ($my_orders_tracking as $mo): 
                                $comm_amt = (float)($mo['commission'] ?? 0);
                                $comm_st  = strtolower($mo['commission_status'] ?? 'pending');
                                $is_cair  = ($comm_st === 'paid');
                            ?>
                            <tr>
                                <td style="font-family:monospace;font-size:12px;color:#64748b;">
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($mo['created_at']))); ?>
                                </td>
                                <td><strong style="font-family:monospace;"><?php echo esc_html($mo['order_no']); ?></strong></td>
                                <td><?php echo esc_html($mo['product_name'] ?: 'Produk Toko'); ?> (<?php echo (float)$mo['qty']; ?> unit)</td>
                                <td style="text-align:right;font-family:monospace;">
                                    <?php echo esc_html($format_money($mo['total_amount'])); ?>
                                </td>
                                <td style="text-align:right;font-family:monospace;font-weight:800;color:#047857;">
                                    <?php echo esc_html($format_money($comm_amt)); ?>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge <?php echo $is_cair ? 'badge-success' : 'badge-warning'; ?>">
                                        <?php echo $is_cair ? '✓ Sudah Cair' : '⏳ Belum Cair'; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align:center;padding:32px;color:#94a3b8;">
                                    Belum ada transaksi komisi tercatat.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- TAB 4: REKAPITULASI PENJUALAN PER BULAN & PER TAHUN (MASTERPIECE FEATURE) -->
    <div class="pk01-tab-pane" id="tab-period-history">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>📊 Rekapitulasi Penjualan &amp; Komisi per Periode (Tahun &amp; Bulan)</h3>
                    <p>Histori lengkap seluruh omzet dan komisi yang telah Anda peroleh selama bergabung sebagai mitra penjual.</p>
                </div>
                <div style="font-size:12px;background:#f8fafc;border:1px solid #cbd5e1;padding:6px 14px;border-radius:20px;font-weight:700;">
                    Akumulasi Seumur Kerja: <b style="color:#047857;"><?php echo esc_html($format_money($lifetime_omzet_all)); ?></b> (<?php echo (int)$lifetime_orders_all; ?> Order)
                </div>
            </div>

            <!-- TABEL 1: REKAPITULASI PER TAHUN -->
            <div style="margin-bottom:24px;">
                <h4 style="margin:0 0 10px;font-size:14px;color:#0f172a;">📅 Ringkasan Penjualan Tahunan:</h4>
                <div class="pk01-table-wrap">
                    <table class="pk01-portal-table">
                        <thead>
                            <tr>
                                <th style="width:130px;">Tahun</th>
                                <th style="text-align:center;width:140px;">Total Pesanan</th>
                                <th style="text-align:right;">Omzet Bruto</th>
                                <th style="text-align:right;">Retur</th>
                                <th style="text-align:right;">Omzet Bersih</th>
                                <th style="text-align:right;">Total Komisi Diperoleh</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($yearly_sales_history)): ?>
                                <?php foreach ($yearly_sales_history as $yh): ?>
                                <tr>
                                    <td><strong style="font-size:14px;color:#1e40af;">Tahun <?php echo esc_html($yh['year']); ?></strong></td>
                                    <td style="text-align:center;font-weight:700;"><?php echo number_format($yh['total_orders']); ?> Transaksi</td>
                                    <td style="text-align:right;font-family:monospace;font-weight:800;color:#2563eb;font-size:14px;">
                                        <?php echo esc_html($format_money($yh['total_omzet'])); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:800;color:#dc2626;font-size:14px;">
                                        <?php echo esc_html($format_money($yh['total_retur'] ?? 0)); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:800;color:#047857;font-size:14px;">
                                        <?php echo esc_html($format_money($yh['total_omzet_net'] ?? $yh['total_omzet'])); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:800;color:#7c3aed;font-size:14px;">
                                        <?php echo esc_html($format_money($yh['total_komisi'])); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="7" style="text-align:center;padding:24px;color:#94a3b8;">Belum ada catatan tahunan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TABEL 2: RINCIAN BULAN PER BULAN -->
            <div>
                <h4 style="margin:0 0 10px;font-size:14px;color:#0f172a;">🗓️ Rincian Omzet &amp; Komisi Bulanan:</h4>
                <div class="pk01-table-wrap">
                    <table class="pk01-portal-table">
                        <thead>
                            <tr>
                                <th style="width:160px;">Periode Bulan</th>
                                <th style="text-align:center;width:120px;">Jumlah Order</th>
                                <th style="text-align:right;">Omzet Bruto</th>
                                <th style="text-align:right;">Retur</th>
                                <th style="text-align:right;">Omzet Bersih</th>
                                <th style="text-align:right;">Total Komisi</th>
                                <th style="text-align:right;">Komisi Sudah Cair</th>
                                <th style="text-align:right;">Komisi Belum Cair</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($monthly_sales_history)): ?>
                                <?php foreach ($monthly_sales_history as $msh): 
                                    $month_label = date_i18n('F Y', strtotime($msh['period_key'] . '-01'));
                                ?>
                                <tr>
                                    <td><strong><?php echo esc_html($month_label); ?></strong></td>
                                    <td style="text-align:center;font-weight:700;"><?php echo number_format($msh['total_orders']); ?> Order</td>
                                    <td style="text-align:right;font-family:monospace;font-weight:700;color:#2563eb;">
                                        <?php echo esc_html($format_money($msh['total_omzet'])); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:700;color:#dc2626;">
                                        <?php echo esc_html($format_money($msh['total_retur'] ?? 0)); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:800;color:#047857;">
                                        <?php echo esc_html($format_money($msh['total_omzet_net'] ?? $msh['total_omzet'])); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:800;color:#0f172a;">
                                        <?php echo esc_html($format_money($msh['total_komisi'])); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:700;color:#059669;">
                                        <?php echo esc_html($format_money($msh['komisi_cair'])); ?>
                                    </td>
                                    <td style="text-align:right;font-family:monospace;font-weight:700;color:<?php echo (float)$msh['komisi_pending'] > 0 ? '#d97706;' : '#94a3b8;'; ?>">
                                        <?php echo esc_html($format_money($msh['komisi_pending'])); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="8" style="text-align:center;padding:24px;color:#94a3b8;">Belum ada riwayat bulanan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>

    <!-- TAB 5: LAPORAN TERINTEGRASI PENJUALAN + RETUR + TAGIHAN -->
    <div class="pk01-tab-pane" id="tab-financial-report">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>📊 Laporan Penjualan, Retur &amp; Tagihan</h3>
                    <p>Semua angka membaca transaksi PK01 yang sudah tersimpan. Retur baru mengurangi penjualan/tagihan setelah unit dinyatakan diterima Gudang.</p>
                </div>
            </div>
            <div class="pk01-portal-kpis" style="margin-bottom:18px;">
                <div class="pk01-kpi-card c-blue"><small>Penjualan Bruto</small><strong><?php echo $format_money($gross_sales_all); ?></strong><span>Sebelum koreksi retur</span></div>
                <div class="pk01-kpi-card c-red"><small>Retur Diterima Gudang</small><strong style="color:#dc2626;"><?php echo $format_money($return_sales_all); ?></strong><span>Koreksi Seller yang sudah diterapkan</span></div>
                <div class="pk01-kpi-card c-green"><small>Penjualan Bersih</small><strong style="color:#059669;"><?php echo $format_money($net_sales_all); ?></strong><span>Bruto dikurangi retur</span></div>
                <div class="pk01-kpi-card c-amber"><small>Belum Dibayar</small><strong style="color:#d97706;"><?php echo $format_money($invoice_unpaid); ?></strong><span>Sisa tagihan Seller</span></div>
                <div class="pk01-kpi-card c-green"><small>Sudah Dibayar</small><strong style="color:#059669;"><?php echo $format_money($invoice_paid); ?></strong><span>Pembayaran yang tercatat</span></div>
            </div>

            <div style="overflow:auto;margin-bottom:22px;">
                <h4 style="margin:0 0 10px;">🧾 Rincian Retur yang Mengubah Laporan</h4>
                <table class="pk01-portal-table">
                    <thead><tr><th>Retur</th><th>Order</th><th>Status</th><th style="text-align:right;">Nilai Koreksi</th><th>Waktu Diterima</th></tr></thead>
                    <tbody>
                    <?php if (!$return_rows): ?><tr><td colspan="5" style="text-align:center;padding:24px;color:#94a3b8;">Belum ada retur Seller.</td></tr>
                    <?php else: foreach ($return_rows as $rr): $adj=(float)($rr['seller_adjustment_amount']??0); $applied=(strtolower((string)($rr['seller_ar_adjustment_status']??''))==='applied'); ?>
                        <tr>
                            <td><strong><?php echo esc_html($rr['return_no']??'-'); ?></strong><small style="display:block;color:#64748b;"><?php echo esc_html($rr['tracking_no']??'-'); ?></small></td>
                            <td><?php echo esc_html($rr['order_no']??'-'); ?></td>
                            <td><span class="pk01-badge <?php echo $applied ? 'badge-success':'badge-warning'; ?>"><?php echo $applied ? '✓ Sudah Mengurangi Tagihan':'⏳ Menunggu Gudang'; ?></span></td>
                            <td style="text-align:right;font-family:monospace;font-weight:800;color:#dc2626;"><?php echo $applied ? '- '.$format_money($adj) : 'Belum dihitung'; ?></td>
                            <td><?php echo !empty($rr['warehouse_received_at']) ? esc_html(date('d/m/Y H:i',strtotime($rr['warehouse_received_at']))) : '-'; ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="overflow:auto;">
                <h4 style="margin:0 0 10px;">💳 Status Tagihan Seller</h4>
                <table class="pk01-portal-table">
                    <thead><tr><th>Invoice</th><th style="text-align:right;">Nilai Tagihan</th><th style="text-align:right;">Sudah Dibayar</th><th style="text-align:right;">Belum Dibayar</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php if (!$seller_invoices): ?><tr><td colspan="5" style="text-align:center;padding:24px;color:#94a3b8;">Belum ada tagihan Seller.</td></tr>
                    <?php else: foreach ($seller_invoices as $inv): $tot=(float)($inv['total']??0); $pd=(float)($inv['total_paid']??0); $rem=max(0,$tot-$pd); $ist=$rem<=0.01?'paid':($pd>0?'partial':'unpaid'); ?>
                        <tr>
                            <td><strong><?php echo esc_html($inv['invoice_no']?:'INV-'.$inv['id']); ?></strong></td>
                            <td style="text-align:right;"><?php echo $format_money($tot); ?></td>
                            <td style="text-align:right;color:#059669;font-weight:700;"><?php echo $format_money($pd); ?></td>
                            <td style="text-align:right;color:#dc2626;font-weight:700;"><?php echo $format_money($rem); ?></td>
                            <td><span class="pk01-badge <?php echo $ist==='paid'?'badge-success':($ist==='partial'?'badge-warning':'badge-danger'); ?>"><?php echo $ist==='paid'?'Sudah Dibayar':($ist==='partial'?'Sebagian':'Belum Dibayar'); ?></span></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>


<div class="pk01-tab-pane" id="tab-seller-orders">
<section class="pk01-surface"><div class="pk01-surface-head"><div><h3>🛍️ Kirim Order Penjualan ke Kasir</h3><p>Seller memilih produk dari Master PK01. Marketplace hanya menjadi channel. Nomor order dan resi dicatat sebagai referensi; Kasir tetap yang menerima order dan menentukan pemenuhan.</p></div></div>
<form method="post" style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;">
<?php echo wp_nonce_field('pk01_portal_save','pk01_portal_nonce',true,false); ?><input type="hidden" name="pk01_portal_action" value="marketplace_order">
<div><label>Marketplace</label><select name="marketplace" required style="width:100%;padding:8px;"><option value="shopee">Shopee</option><option value="tokopedia">Tokopedia</option><option value="tiktok_shop">TikTok Shop</option><option value="lazada">Lazada</option><option value="marketplace">Lainnya</option></select></div>
<div><label>No. Order Marketplace</label><input name="marketplace_order_no" required style="width:100%;padding:8px;" placeholder="Contoh: 250912ABC"></div>
<div><label>Resi/AWB (boleh menyusul)</label><input name="tracking_no" style="width:100%;padding:8px;" placeholder="JNE123456789"></div>
<div><label>SKU Marketplace Seller</label><input name="seller_sku" style="width:100%;padding:8px;" placeholder="SKU di marketplace"></div>
<div style="grid-column:1/-1"><label>Produk PK01</label><select name="variant_id" required style="width:100%;padding:8px;"><option value="">Pilih produk/varian PK01...</option><?php foreach($catalog as $item): ?><option value="<?php echo (int)$item['id']; ?>"><?php echo esc_html($item['sku'].' — '.$item['name']); ?></option><?php endforeach; ?></select></div>
<div><label>Qty</label><input type="number" name="qty" min="1" step="1" value="1" required style="width:100%;padding:8px;"></div>
<div style="grid-column:span 3;display:flex;align-items:end;"><button class="pk01-btn pk01-btn-primary" type="submit">Kirim Order ke Kasir</button></div>
</form></section>
</div>

<div class="pk01-tab-pane" id="tab-marketplace-catalog"><section class="pk01-surface">
<div class="pk01-surface-head"><div><h3>🛒 Katalog PK01 & Export Marketplace</h3><p>Produk, SKU, ukuran, stok, deskripsi dan gambar berasal dari Master PK01/E-Commerce. Seller hanya mengatur harga marketplace dan mapping SKU Seller. Harga beli/HPP internal tidak mengubah tagihan PK01.</p></div></div>
<?php echo $notice ?? ''; ?>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0;align-items:center;">
<button type="button" class="pk01-btn" id="pk01-mp-select-all">☑ Pilih Semua</button>
<span style="font-size:12px;color:#64748b;">Pilih SKU dari Master PK01 yang ingin diekspor menjadi file mass upload. Ini adalah export katalog untuk Seller Center, bukan upload master produk ke PK01. Produk/SKU tetap berasal dari Master Produk PK01.</span>
<?php foreach(PK01_Marketplace_Catalog::marketplaces() as $mk=>$label): $t=PK01_Marketplace_Catalog::get_template($mk); $ready=!empty($t['verified']); $url=add_query_arg(['pk01_seller'=>$seller['portal_token']??'','pk01_catalog_export'=>'1','marketplace'=>$mk],home_url('/')); ?>
<a data-mp-download="<?php echo esc_attr($mk); ?>" href="<?php echo $ready?esc_url($url):'#'; ?>" class="pk01-btn pk01-btn-primary" <?php echo $ready?'':'aria-disabled="true" style="opacity:.45;pointer-events:none;"'; ?>>⬇ <?php echo esc_html($label); ?> <?php echo $ready?'Mass Upload':'(template belum siap)'; ?></a>
<?php endforeach; ?>
</div></div>
<div style="padding:12px;background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;font-size:12px;margin-bottom:14px;"><b>Alur:</b> Master Produk PK01 → Katalog Seller → Export template marketplace. PK01 tidak membuat master produk baru dari marketplace. <b>Keamanan format:</b> PK01 tidak memakai header buatan untuk export produksi. Admin wajib memasang template resmi terbaru dari Seller Center. Jika template berubah atau ada kolom yang belum dipetakan, tombol download dinonaktifkan.</div>
<div class="pk01-table-wrap"><table class="pk01-portal-table"><thead><tr><th style="width:42px;"><input type="checkbox" id="pk01-mp-all-check" aria-label="Pilih semua SKU"></th><th>Produk / SKU</th><th>Stok Riil</th><th>Harga Beli/HPP</th><th>Harga Seller</th><th>Harga Marketplace</th><th>Marketplace</th></tr></thead><tbody>
<?php $catalog_rows=PK01_Marketplace_Catalog::rows((int)$seller['id'],'generic'); foreach($catalog_rows as $r): foreach(PK01_Marketplace_Catalog::marketplaces() as $mk=>$label): $pm=PK01_Marketplace_Catalog::seller_marketplace_prices((int)$seller['id'],$mk); $mp_price=isset($pm[$r['variant_id']])?(float)$pm[$r['variant_id']]:$r['price_seller']; ?>
<tr><td><input type="checkbox" class="pk01-mp-check" value="<?php echo (int)$r['variant_id']; ?>" aria-label="Pilih SKU"></td><td><strong><?php echo esc_html($r['product_name']); ?></strong><small style="display:block;font-family:monospace;"><?php echo esc_html($r['sku']); ?> · <?php echo esc_html($r['size']); ?></small></td><td><?php echo number_format((float)$r['stock']); ?></td><td><?php echo esc_html($format_money($r['price_buy'])); ?></td><td><?php echo esc_html($format_money($r['price_seller'])); ?></td><td><form method="post" style="display:flex;gap:5px;align-items:center;"><?php wp_nonce_field('pk01_marketplace_price','pk01_marketplace_price_nonce'); ?><input type="hidden" name="pk01_marketplace_price_save" value="1"><input type="hidden" name="variant_id" value="<?php echo (int)$r['variant_id']; ?>"><input type="hidden" name="marketplace" value="<?php echo esc_attr($mk); ?>"><input type="number" name="marketplace_price" min="0" step="1" value="<?php echo esc_attr($mp_price); ?>" style="width:110px;"><button class="pk01-btn" type="submit">Simpan</button></form></td><td><?php echo esc_html($label); ?></td></tr>
<?php endforeach; endforeach; ?>
</tbody></table></div>
<script>(function(){const checks=()=>Array.from(document.querySelectorAll('.pk01-mp-check:checked')).map(x=>x.value).join(',');const all=document.getElementById('pk01-mp-all-check');const sel=document.getElementById('pk01-mp-select-all');function sync(){const ids=checks();document.querySelectorAll('[data-mp-download]').forEach(a=>{const base=a.getAttribute('href')||'#';if(base!=='#'){const u=new URL(base,window.location.href);if(ids)u.searchParams.set('variant_ids',ids);else u.searchParams.delete('variant_ids');a.href=u.toString();}});}if(all){all.addEventListener('change',()=>{document.querySelectorAll('.pk01-mp-check').forEach(c=>c.checked=all.checked);sync();});}if(sel){sel.addEventListener('click',()=>{const boxes=Array.from(document.querySelectorAll('.pk01-mp-check'));const any=boxes.some(c=>!c.checked);boxes.forEach(c=>c.checked=any);if(all)all.checked=any;sync();});}document.querySelectorAll('.pk01-mp-check').forEach(c=>c.addEventListener('change',sync));sync();})();</script>
<div style="margin-top:14px;padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;font-size:12px;"><b>Sumber data:</b> gambar/deskripsi/SKU/ukuran/stok = PK01 E-Commerce + Theme Integration; HPP = Master Variant; harga Seller = pricing PK01; harga Marketplace = pengaturan Seller per marketplace. Sistem tidak membuat data baru dari AI. AI hanya boleh membantu mapping field dan memberi peringatan jika sumber data tidak jelas.</div>
</section></div>

    <!-- TAB 6: KATALOG PENGAMBILAN KONSINYASI & LINK REFERRAL -->
    <div class="pk01-tab-pane" id="tab-catalog">
        <section class="pk01-surface">
            <div class="pk01-surface-head">
                <div>
                    <h3>📦 Pengambilan Stok Barang Konsinyasi &amp; Tautan Afiliasi</h3>
                    <p>Ajukan permohonan pengambilan barang dari gudang atau bagikan tautan referral untuk mendapatkan komisi penjualan online.</p>
                </div>
            </div>

            <div class="pk01-catalog-grid">
                <?php foreach ($catalog as $item): 
                    $s_price = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'seller_price') 
                        ? PK01_Engine::seller_price((int)$seller['id'], (int)$item['id']) 
                        : (float)($item['price'] ?? 0);

                    $aff_url = add_query_arg('pk01_ref', $seller['code'], home_url('/'));
                    $wh_stock = (float)($item['warehouse_stock'] ?? 0);
                ?>
                    <article class="pk01-product-card">
                        <div>
                            <small><?php echo esc_html($item['sku']); ?></small>
                            <h4><?php echo esc_html($item['name']); ?></h4>
                            <div style="font-size:15px;font-family:monospace;font-weight:800;color:#047857;margin-bottom:4px;">
                                Harga Khusus Seller: <?php echo esc_html($format_money($s_price)); ?>
                            </div>
                            <span style="font-size:12px;color:#64748b;display:block;margin-bottom:12px;">
                                Tersedia di Pabrik: <b><?php echo number_format($wh_stock); ?> pcs</b>
                            </span>
                        </div>

                        <div>
                            <!-- FORM PENGAJUAN AMBIL BARANG -->
                            <form method="post" action="" style="margin-top:8px;">
                                <?php echo wp_nonce_field('pk01_portal_save', 'pk01_portal_nonce', true, false); ?>
                                <input type="hidden" name="pk01_portal_action" value="request">
                                <input type="hidden" name="variant_id" value="<?php echo (int)$item['id']; ?>">
                                
                                <div style="display:flex;gap:6px;align-items:center;">
                                    <input type="number" name="qty" min="1" max="<?php echo max(1, (int)$wh_stock); ?>" value="1" style="width:65px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;" required>
                                    <button type="submit" class="pk01-btn pk01-btn-primary" style="flex:1;justify-content:center;" <?php echo $wh_stock < 1 ? 'disabled style="opacity:0.5;"' : ''; ?>>
                                        <?php echo $wh_stock < 1 ? 'Stok Habis' : 'Ajukan Ambil'; ?>
                                    </button>
                                </div>
                            </form>

                            <!-- LINK AFFILIATE -->
                            <div style="margin-top:12px;padding-top:10px;border-top:1px dashed #e2e8f0;">
                                <span style="font-size:11px;font-weight:700;color:#334155;display:block;margin-bottom:4px;">Link Referral Produk Anda:</span>
                                <div style="display:flex;gap:4px;">
                                    <input type="text" readonly value="<?php echo esc_attr($aff_url); ?>" style="width:100%;font-size:10px;padding:4px 6px;background:#f8fafc;border:1px solid #cbd5e1;border-radius:4px;" onclick="this.select()">
                                    <button type="button" class="pk01-btn" style="background:#f1f5f9;color:#0f172a;border:1px solid #cbd5e1;padding:4px 8px;font-size:10px;" onclick="navigator.clipboard.writeText('<?php echo esc_js($aff_url); ?>');this.innerText='✓';setTimeout(()=>{this.innerText='Salin'},1200);">Salin</button>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab Switcher Portal Seller
    var tabBtns  = document.querySelectorAll('.pk01-tab-btn');
    var tabPanes = document.querySelectorAll('.pk01-tab-pane');

    function activateTab(targetId) {
        if (!targetId) return;
        tabBtns.forEach(function(b) { b.classList.remove('active'); });
        tabPanes.forEach(function(p) { p.classList.remove('active'); });
        var targetPane = document.getElementById(targetId);
        var targetBtn = document.querySelector('.pk01-tab-btn[data-target="' + targetId + '"]');
        if (targetPane) targetPane.classList.add('active');
        if (targetBtn) targetBtn.classList.add('active');
    }
    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            activateTab(this.getAttribute('data-target'));
        });
    });
    if (window.location.hash) {
        var hash = window.location.hash.substring(1);
        if (document.getElementById(hash)) activateTab(hash);
    }
});
</script>