<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$registered_success = false;

// 1. IDENTIFIKASI PERAN (SUPERADMIN BYPASS & INTERNAL VS PUBLIK)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$is_staff     = class_exists('PK01_Authorization') && PK01_Authorization::can('seller');
$is_internal  = ($is_admin || $is_staff);
$source       = $is_admin ? 'admin' : ($is_staff ? 'employee' : 'self');

// 2. FUNGSI PENOMORAN OTOMATIS SELLER DARI PENGATURAN SISTEM
if (!function_exists('pk01_generate_seller_code')) {
    function pk01_generate_seller_code() {
        global $wpdb;
        
        $prefix   = get_option('pk01_seller_prefix', 'SLR');          
        $digits   = absint(get_option('pk01_seller_digits', 4));      
        $use_year = (bool) get_option('pk01_seller_use_year', true);  

        $tbl_sellers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
            ? PK01_DB::t('sellers') 
            : $wpdb->prefix . 'pk01_sellers';

        $next_num = 1;
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_sellers)) === $tbl_sellers) {
            $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_sellers}`");
            $next_num = $total + 1;
        }

        $year_tag = $use_year ? current_time('y') . '-' : '';
        return $prefix . '-' . $year_tag . str_pad((string)$next_num, $digits, '0', STR_PAD_LEFT);
    }
}

// 3. STATISTIK REAL PORTAL SELLER (KHUSUS MODE INTERNAL/ADMIN)
$tbl_sellers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('sellers') 
    : $wpdb->prefix . 'pk01_sellers';

$count_total_sellers   = 0;
$count_active_sellers  = 0;
$count_pending_sellers = 0;

if ($is_internal && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_sellers)) === $tbl_sellers) {
    $count_total_sellers   = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_sellers}`");
    $count_active_sellers  = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_sellers}` WHERE status = 'active'");
    $count_pending_sellers = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$tbl_sellers}` WHERE status = 'pending'");
}

$default_generated_code = pk01_generate_seller_code();
$default_commission     = (float) get_option('pk01_default_seller_commission', 10);

// 4. PROSES SUBMIT FORM PENDAFTARAN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_register_seller'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_seller_nonce'] ?? ''));
    
    if (!wp_verify_nonce($nonce, 'pk01_seller_register_action')) {
        $notice = '<div class="pk01-slr-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        $name             = sanitize_text_field(wp_unslash($_POST['seller_name'] ?? ''));
        $code             = sanitize_text_field(wp_unslash($_POST['seller_code'] ?? ''));
        $phone            = sanitize_text_field(wp_unslash($_POST['seller_phone'] ?? ''));
        $email            = sanitize_email(wp_unslash($_POST['seller_email'] ?? ''));
        $password         = (string)($_POST['seller_password'] ?? '');
        $password_confirm = (string)($_POST['seller_password_confirm'] ?? '');

        if (empty($code)) {
            $code = $default_generated_code;
        }

        $affiliate_percent = $is_internal 
            ? (isset($_POST['seller_affiliate_percent']) ? max(0, min(100, (float)$_POST['seller_affiliate_percent'])) : $default_commission)
            : $default_commission;

        // Validasi
        if (empty($name) || empty($email) || empty($password)) {
            $notice = '<div class="pk01-slr-alert is-error">⚠️ Nama lengkap, email login, dan password wajib diisi.</div>';
        } elseif (!is_email($email)) {
            $notice = '<div class="pk01-slr-alert is-error">⚠️ Format alamat email tidak valid.</div>';
        } elseif (strlen($password) < 8) {
            $notice = '<div class="pk01-slr-alert is-error">⚠️ Password minimal 8 karakter demi keamanan akun.</div>';
        } elseif ($password !== $password_confirm) {
            $notice = '<div class="pk01-slr-alert is-error">⚠️ Konfirmasi password tidak cocok dengan password yang dimasukkan.</div>';
        } else {
            try {
                $r = PK01_Engine::seller_register($name, $code, $phone, $email, $password, $affiliate_percent, $source);
                $registered_success = true;

                if (is_array($r) && isset($r['status']) && $r['status'] === 'pending') {
                    $notice = '<div class="pk01-slr-alert is-success">'
                        . '<div class="pk01-alert-title">🎉 Pendaftaran Mitra Berhasil Dikirim!</div>'
                        . '<p style="margin:4px 0 8px;">Kode Unik Anda: <strong class="pk01-badge-code">' . esc_html($code) . '</strong></p>'
                        . '<span style="font-size:13px;">Akun Anda sedang <b>menunggu verifikasi admin</b> sebelum dapat login ke portal penjualan.</span>'
                        . '</div>';
                } else {
                    $login_url = class_exists('PK01_Login') ? PK01_Login::url() : wp_login_url();
                    $notice = '<div class="pk01-slr-alert is-success">'
                        . '<div class="pk01-alert-title">🎉 Mitra Seller Berhasil Didaftarkan &amp; Aktif!</div>'
                        . '<p style="margin:4px 0 10px;">Kode Mitra Resmi: <strong class="pk01-badge-code is-active">' . esc_html($code) . '</strong></p>'
                        . '<a href="' . esc_url($login_url) . '" class="pk01-btn-action">Masuk ke Portal Seller &rarr;</a>'
                        . '</div>';
                }
            } catch (Throwable $e) {
                $notice = '<div class="pk01-slr-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
            }
        }
    }
}
?>

<style>
:root {
    --pk-slr-navy: #0f172a;
    --pk-slr-accent: #4f46e5;
    --pk-slr-accent-hover: #4338ca;
    --pk-slr-border: #e2e8f0;
    --pk-slr-text: #1e293b;
    --pk-slr-muted: #64748b;
}

.pk01-seller-reg-hub {
    max-width: 1200px;
    margin: 10px auto 40px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: var(--pk-slr-text);
}
.pk01-seller-reg-hub * { box-sizing: border-box; }

/* Internal Admin Stats Strip */
.pk01-slr-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    margin-bottom: 22px;
}
.pk01-slr-stat-card {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 12px;
    padding: 14px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    border-left: 4px solid #cbd5e1;
}
.pk01-slr-stat-card.c-blue  { border-left-color: #3b82f6; }
.pk01-slr-stat-card.c-green { border-left-color: #10b981; }
.pk01-slr-stat-card.c-amber { border-left-color: #f59e0b; }
.pk01-slr-stat-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    color: var(--pk-slr-muted);
    letter-spacing: 0.5px;
    display: block;
}
.pk01-slr-stat-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin-top: 4px;
}

/* Split Grid Layout */
.pk01-slr-grid {
    display: grid;
    grid-template-columns: 1.4fr 0.9fr;
    gap: 24px;
    align-items: start;
}
@media (max-width: 920px) {
    .pk01-slr-grid { grid-template-columns: 1fr; }
}

/* Main Form Card */
.pk01-slr-card {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 16px;
    padding: 28px;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03);
}
.pk01-slr-head {
    margin-bottom: 22px;
    padding-bottom: 16px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-badge-role {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--pk-slr-accent);
    background: #eef2ff;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 8px;
}
.pk01-badge-role.is-internal {
    color: #0369a1;
    background: #e0f2fe;
}
.pk01-slr-title {
    margin: 4px 0 6px 0;
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-slr-desc {
    margin: 0;
    font-size: 13px;
    color: var(--pk-slr-muted);
    line-height: 1.5;
}

/* Sections */
.pk01-section-tag {
    font-size: 11px;
    font-weight: 800;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    margin: 22px 0 14px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-section-tag::after {
    content: "";
    flex: 1;
    height: 1px;
    background: #f1f5f9;
}

.pk01-row-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-row-2 { grid-template-columns: 1fr; }
}

.pk01-field-box {
    display: flex;
    flex-direction: column;
    gap: 6px;
    margin-bottom: 14px;
    position: relative;
}
.pk01-field-box label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-field-box input {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 14px;
    background: #f8fafc;
    color: #0f172a;
    transition: all 0.15s ease;
}
.pk01-field-box input:focus {
    outline: none;
    border-color: var(--pk-slr-accent);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
}
.pk01-hint {
    font-size: 11px;
    color: var(--pk-slr-muted);
}

/* Password Eye Button */
.pk01-pass-wrap {
    position: relative;
    display: flex;
    align-items: center;
}
.pk01-pass-wrap input {
    padding-right: 40px;
}
.pk01-toggle-pass {
    position: absolute;
    right: 10px;
    background: transparent;
    border: none;
    cursor: pointer;
    color: #64748b;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Submit Button */
.pk01-btn-submit {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    padding: 13px 22px;
    background: #0f172a;
    color: #ffffff !important;
    font-size: 14px;
    font-weight: 700;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.15s ease, transform 0.1s ease;
    margin-top: 10px;
}
.pk01-btn-submit:hover {
    background: #1e293b;
    transform: translateY(-1px);
}

/* Alerts */
.pk01-slr-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13px;
    line-height: 1.5;
    margin-bottom: 20px;
}
.pk01-slr-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
.pk01-slr-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-badge-code {
    background: #e2e8f0;
    padding: 3px 8px;
    border-radius: 6px;
    font-family: monospace;
    font-size: 14px;
}
.pk01-badge-code.is-active { background: #dcfce7; color: #166534; }
.pk01-btn-action {
    display: inline-block;
    margin-top: 8px;
    padding: 6px 14px;
    background: #166534;
    color: #ffffff !important;
    text-decoration: none !important;
    font-weight: 700;
    font-size: 12px;
    border-radius: 6px;
}

/* LIVE VIRTUAL ID CARD PREVIEW (MASTERPIECE FEATURE) */
.pk01-virtual-card {
    background: linear-gradient(135deg, #1e1b4b 0%, #312e81 60%, #4338ca 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 22px;
    box-shadow: 0 10px 20px -5px rgba(49, 46, 129, 0.3);
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
}
.pk01-card-chip {
    width: 36px;
    height: 26px;
    background: linear-gradient(135deg, #fde047 0%, #ca8a04 100%);
    border-radius: 5px;
    margin-bottom: 16px;
}
.pk01-card-name {
    font-size: 18px;
    font-weight: 800;
    margin: 0 0 4px 0;
    color: #ffffff;
    word-break: break-word;
}
.pk01-card-code {
    font-family: monospace;
    font-size: 13px;
    letter-spacing: 1px;
    color: #c7d2fe;
    display: block;
    margin-bottom: 14px;
}
.pk01-card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid rgba(255,255,255,0.15);
    padding-top: 10px;
    font-size: 11px;
}

/* Sidebar Information */
.pk01-sidebar-deck {
    background: #ffffff;
    border: 1px solid var(--pk-slr-border);
    border-radius: 16px;
    padding: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    margin-bottom: 20px;
}
.pk01-sidebar-deck h3 {
    margin: 0 0 14px 0;
    font-size: 15px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-benefit-row {
    display: flex;
    gap: 12px;
    margin-bottom: 14px;
}
.pk01-benefit-row:last-child { margin-bottom: 0; }
.pk01-icon-badge {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: #f1f5f9;
    color: var(--pk-slr-accent);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    flex-shrink: 0;
}
.pk01-benefit-info strong {
    display: block;
    font-size: 13px;
    color: #0f172a;
    margin-bottom: 2px;
}
.pk01-benefit-info p {
    margin: 0;
    font-size: 12px;
    color: var(--pk-slr-muted);
    line-height: 1.4;
}
</style>

<div class="pk01-seller-reg-hub">

    <!-- 1. KHUSUS ADMIN: RINGKASAN PORTFOLIO MITRA RIIL DARI DATABASE -->
    <?php if ($is_internal): ?>
    <div class="pk01-slr-stats">
        <div class="pk01-slr-stat-card c-blue">
            <small>Total Mitra Seller</small>
            <strong><?php echo number_format($count_total_sellers); ?> <span style="font-size:13px;font-weight:normal;">Mitra</span></strong>
        </div>
        <div class="pk01-slr-stat-card c-green">
            <small>Mitra Aktif Berjualan</small>
            <strong style="color:#059669;"><?php echo number_format($count_active_sellers); ?> <span style="font-size:13px;font-weight:normal;">Akun</span></strong>
        </div>
        <div class="pk01-slr-stat-card c-amber">
            <small>Menunggu Verifikasi</small>
            <strong style="color:#d97706;"><?php echo number_format($count_pending_sellers); ?> <span style="font-size:13px;font-weight:normal;">Pengajuan</span></strong>
        </div>
    </div>
    <?php endif; ?>

    <!-- 2. SPLIT LAYOUT FORM & LIVE PREVIEW -->
    <div class="pk01-slr-grid">
        
        <!-- KOLOM KIRI: FORMULIR -->
        <div class="pk01-slr-card">
            <div class="pk01-slr-head">
                <span class="pk01-badge-role <?php echo $is_internal ? 'is-internal' : ''; ?>">
                    <?php echo $is_internal ? '🛡️ Internal System Portal' : '🤝 Program Kemitraan Resmi'; ?>
                </span>
                <h1 class="pk01-slr-title"><?php echo $is_internal ? 'Daftarkan Seller Baru (Admin)' : 'Pendaftaran Mitra Seller'; ?></h1>
                <p class="pk01-slr-desc">
                    <?php if ($is_internal): ?>
                        Input akun mitra resmi dari kantor pusat. Kode unik mitra di-generate otomatis mengikuti urutan format sistem.
                    <?php else: ?>
                        Lengkapi formulir di bawah ini untuk bergabung menjadi mitra penjual resmi dan nikmati bagi hasil komisi penjualan.
                    <?php endif; ?>
                </p>
            </div>

            <?php echo $notice; ?>

            <?php if (!$registered_success || $is_internal): ?>
            <form method="post" action="" id="pk01-seller-form">
                <?php echo wp_nonce_field('pk01_seller_register_action', 'pk01_seller_nonce', true, false); ?>
                <input type="hidden" name="pk01_register_seller" value="1">

                <div class="pk01-section-tag">1. Identitas &amp; Kontak Mitra</div>

                <div class="pk01-field-box">
                    <label>Nama Lengkap Seller <span style="color:#ef4444;">*</span></label>
                    <input type="text" id="input_seller_name" name="seller_name" value="<?php echo esc_attr($_POST['seller_name'] ?? ''); ?>" required placeholder="Contoh: Budi Santoso">
                </div>

                <div class="pk01-row-2">
                    <div class="pk01-field-box">
                        <label>No. WhatsApp Aktif <span style="color:#ef4444;">*</span></label>
                        <input type="tel" id="input_seller_phone" name="seller_phone" value="<?php echo esc_attr($_POST['seller_phone'] ?? ''); ?>" placeholder="08xxxxxxxxxx" required>
                        <span class="pk01-hint">Digunakan untuk notifikasi penjualan &amp; penarikan komisi</span>
                    </div>

                    <?php if ($is_internal): ?>
                    <div class="pk01-field-box">
                        <label>Kode Unik Seller</label>
                        <input type="text" id="input_seller_code" name="seller_code" value="<?php echo esc_attr($_POST['seller_code'] ?? ''); ?>" placeholder="Auto: <?php echo esc_attr($default_generated_code); ?>">
                        <span class="pk01-hint">Kosongkan untuk penomoran otomatis</span>
                    </div>
                    <?php else: ?>
                    <div class="pk01-field-box">
                        <label>Estimasi Kode Mitra</label>
                        <input type="text" value="<?php echo esc_attr($default_generated_code); ?>" disabled style="background:#f1f5f9; color:#94a3b8; cursor:not-allowed;">
                        <span class="pk01-hint">Ditetapkan otomatis saat akun diverifikasi</span>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="pk01-section-tag">2. Kredensial Login Portal</div>

                <div class="pk01-field-box">
                    <label>Alamat Email Login <span style="color:#ef4444;">*</span></label>
                    <input type="email" name="seller_email" value="<?php echo esc_attr($_POST['seller_email'] ?? ''); ?>" required placeholder="seller@domain.com">
                </div>

                <div class="pk01-row-2">
                    <div class="pk01-field-box">
                        <label>Password Akun <span style="color:#ef4444;">*</span></label>
                        <div class="pk01-pass-wrap">
                            <input type="password" id="input_pass" name="seller_password" minlength="8" required placeholder="Min. 8 karakter">
                            <button type="button" class="pk01-toggle-pass" data-target="input_pass" title="Tampilkan/Sembunyikan">👁️</button>
                        </div>
                    </div>

                    <div class="pk01-field-box">
                        <label>Konfirmasi Password <span style="color:#ef4444;">*</span></label>
                        <div class="pk01-pass-wrap">
                            <input type="password" id="input_pass_confirm" name="seller_password_confirm" minlength="8" required placeholder="Ulangi password">
                            <button type="button" class="pk01-toggle-pass" data-target="input_pass_confirm" title="Tampilkan/Sembunyikan">👁️</button>
                        </div>
                        <span id="pass_match_indicator" style="font-size:11px; margin-top:2px;"></span>
                    </div>
                </div>

                <?php if ($is_internal): ?>
                <div class="pk01-section-tag">3. Skema Komisi &amp; Pembagian Hasil</div>
                <div class="pk01-field-box">
                    <label>Persentase Komisi Affiliate (%)</label>
                    <input type="number" id="input_commission" name="seller_affiliate_percent" min="0" max="100" step="0.1" value="<?php echo esc_attr($_POST['seller_affiliate_percent'] ?? $default_commission); ?>">
                    <span class="pk01-hint">Standar sistem adalah <?php echo esc_html($default_commission); ?>%. Admin berhak menyesuaikan secara khusus per mitra.</span>
                </div>
                <?php endif; ?>

                <button class="pk01-btn-submit" type="submit" id="btn_submit_seller">
                    <?php echo $is_internal ? '⚡ Daftarkan &amp; Aktifkan Seller' : '🚀 Kirim Formulir Kemitraan'; ?>
                </button>
            </form>
            <?php endif; ?>
        </div>

        <!-- KOLOM KANAN: LIVE VIRTUAL ID CARD PREVIEW & PANDUAN -->
        <aside class="pk01-slr-sidebar">
            
            <!-- MASTERPIECE FEATURE: LIVE VIRTUAL ID CARD PREVIEW -->
            <div class="pk01-virtual-card">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div class="pk01-card-chip"></div>
                    <span style="font-size:10px; font-weight:800; letter-spacing:1px; background:rgba(255,255,255,0.2); padding:3px 8px; border-radius:12px; text-transform:uppercase;">
                        <?php echo $is_internal ? 'OFFICIAL MITRA' : 'VERIFIED SELLER'; ?>
                    </span>
                </div>
                
                <h3 class="pk01-card-name" id="card_preview_name">
                    <?php echo esc_html($_POST['seller_name'] ?? 'Nama Mitra Seller'); ?>
                </h3>
                <span class="pk01-card-code" id="card_preview_code">
                    <?php echo esc_html(!empty($_POST['seller_code']) ? $_POST['seller_code'] : $default_generated_code); ?>
                </span>

                <div class="pk01-card-footer">
                    <div>
                        <span style="display:block; font-size:9px; color:#a5b4fc; text-transform:uppercase;">Komisi Affiliate</span>
                        <strong id="card_preview_commission" style="font-size:13px;">
                            <?php echo esc_html($_POST['seller_affiliate_percent'] ?? $default_commission); ?>%
                        </strong>
                    </div>
                    <div style="text-align:right;">
                        <span style="display:block; font-size:9px; color:#a5b4fc; text-transform:uppercase;">Status Akun</span>
                        <strong style="color:#86efac;">
                            <?php echo $is_internal ? '● Aktif Langsung' : '⏳ Review Admin'; ?>
                        </strong>
                    </div>
                </div>
            </div>

            <!-- PANDUAN INTERNAL VS BENEFIT PUBLIK -->
            <?php if ($is_internal): ?>
                <div class="pk01-sidebar-deck">
                    <h3>⚙️ Standar Operasional Kantor</h3>
                    <div class="pk01-benefit-row">
                        <div class="pk01-icon-badge">🏷️</div>
                        <div class="pk01-benefit-info">
                            <strong>Penomoran Bebas Duplikasi</strong>
                            <p>Sistem otomatis menghitung kode berurutan (<code><?php echo esc_html($default_generated_code); ?></code>) sehingga nomor tidak bentrok.</p>
                        </div>
                    </div>
                    <div class="pk01-benefit-row">
                        <div class="pk01-icon-badge">✅</div>
                        <div class="pk01-benefit-info">
                            <strong>Aktivasi Seketika</strong>
                            <p>Akun yang diinput dari menu admin langsung aktif dan dapat digunakan untuk membuat pesanan maupun share link referral.</p>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="pk01-sidebar-deck">
                    <h3>🌟 Keuntungan Mitra Kami</h3>
                    <div class="pk01-benefit-row">
                        <div class="pk01-icon-badge">📈</div>
                        <div class="pk01-benefit-info">
                            <strong>Komisi Terbuka &amp; Real-Time</strong>
                            <p>Setiap transaksi dari link referral Anda otomatis tercatat di dashboard pribadi Anda.</p>
                        </div>
                    </div>
                    <div class="pk01-benefit-row">
                        <div class="pk01-icon-badge">📱</div>
                        <div class="pk01-benefit-info">
                            <strong>Portal Penjualan Mandiri</strong>
                            <p>Pantau status pesanan pelanggan dan saldo komisi yang dapat dicairkan kapan saja.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </aside>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. LIVE VIRTUAL ID CARD SYNC
    var inputName = document.getElementById('input_seller_name');
    var inputCode = document.getElementById('input_seller_code');
    var inputComm = document.getElementById('input_commission');

    var cardName = document.getElementById('card_preview_name');
    var cardCode = document.getElementById('card_preview_code');
    var cardComm = document.getElementById('card_preview_commission');

    var defaultCode = '<?php echo esc_js($default_generated_code); ?>';
    var defaultComm = '<?php echo esc_js($default_commission); ?>';

    if (inputName && cardName) {
        inputName.addEventListener('input', function() {
            cardName.textContent = this.value.trim() || 'Nama Mitra Seller';
        });
    }

    if (inputCode && cardCode) {
        inputCode.addEventListener('input', function() {
            cardCode.textContent = this.value.trim() || defaultCode;
        });
    }

    if (inputComm && cardComm) {
        inputComm.addEventListener('input', function() {
            cardComm.textContent = (this.value || defaultComm) + '%';
        });
    }

    // 2. SHOW / HIDE PASSWORD TOGGLE
    var toggleButtons = document.querySelectorAll('.pk01-toggle-pass');
    toggleButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var targetId = this.getAttribute('data-target');
            var input = document.getElementById(targetId);
            if (input) {
                if (input.type === 'password') {
                    input.type = 'text';
                    this.textContent = '🙈';
                } else {
                    input.type = 'password';
                    this.textContent = '👁️';
                }
            }
        });
    });

    // 3. LIVE PASSWORD MATCH INDICATOR
    var pass1 = document.getElementById('input_pass');
    var pass2 = document.getElementById('input_pass_confirm');
    var matchIndicator = document.getElementById('pass_match_indicator');

    function checkPasswordMatch() {
        if (!pass1 || !pass2 || !matchIndicator) return;
        if (pass2.value.length === 0) {
            matchIndicator.textContent = '';
            return;
        }
        if (pass1.value === pass2.value) {
            matchIndicator.textContent = '✓ Password cocok';
            matchIndicator.style.color = '#16a34a';
        } else {
            matchIndicator.textContent = '✕ Konfirmasi password belum sama';
            matchIndicator.style.color = '#dc2626';
        }
    }

    if (pass1 && pass2) {
        pass1.addEventListener('input', checkPasswordMatch);
        pass2.addEventListener('input', checkPasswordMatch);
    }
});
</script>