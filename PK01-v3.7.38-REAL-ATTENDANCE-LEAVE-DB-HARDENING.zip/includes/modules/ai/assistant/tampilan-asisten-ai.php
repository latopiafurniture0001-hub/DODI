<?php
if (!defined('ABSPATH')) exit;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin && class_exists('PK01_Authorization') && !PK01_Authorization::can('ai_assistant')) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;">Akses Ditolak</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin otorisasi untuk menggunakan Asisten AI Operasional.</p>
          </div>';
    return;
}

// 2. DETEKSI STATUS AI ENGINE (MULTI-FALLBACK: PK01_AI, PK01_AI_Orchestrator, & CENTRAL SETTINGS)
$settings = (array) get_option('pk01_settings', []);
$opt_ai_enabled = !empty($settings['ai_enabled']);
$opt_ai_key     = !empty($settings['ai_api_key']);
$opt_ai_model   = $settings['ai_model'] ?? 'gpt-4o-mini';
$opt_ai_prov    = $settings['ai_provider'] ?? 'OpenAI';

$status = [
    'enabled'    => $opt_ai_enabled,
    'configured' => $opt_ai_key,
    'message'    => ($opt_ai_enabled && $opt_ai_key) ? 'AI Engine Siap & Terhubung' : 'API Key Belum Diisi',
    'provider'   => ucfirst($opt_ai_prov) . ' (' . $opt_ai_model . ')'
];

if (class_exists('PK01_AI') && method_exists('PK01_AI', 'status')) {
    $status = wp_parse_args(PK01_AI::status(), $status);
} elseif (class_exists('PK01_AI_Orchestrator') && method_exists('PK01_AI_Orchestrator', 'status')) {
    $orch = PK01_AI_Orchestrator::status();
    if (!empty($orch['enabled'])) $status['enabled'] = true;
    if (!empty($orch['providers'])) {
        $status['configured'] = true;
        $status['message'] = 'AI Engine Aktif & Siap Menganalisis';
        if (!empty($orch['providers'][0]['name'])) {
            $status['provider'] = $orch['providers'][0]['name'] . ' (' . ($orch['providers'][0]['model'] ?? '') . ')';
        }
    }
}

$is_ready = (!empty($status['enabled']) && !empty($status['configured'])) || (!empty($settings['ai_api_key']));
$nonce_ask = wp_create_nonce('pk01_ai_ask');

// 3. TERIMA PREFILL PROMPT DARI DASHBOARD LAIN
$prefill_prompt = sanitize_textarea_field(wp_unslash($_GET['pk01_ai_prompt'] ?? ''));
$settings_url   = admin_url('admin.php?page=pk01-settings#tab-ai');
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-ai-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-ai-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-ai-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
}
.pk01-ping-dot.online {
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
.pk01-ping-dot.offline {
    background: #f87171;
    box-shadow: none;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Prompt Library Card */
.pk01-prompt-library {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 22px 24px;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-library-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 12px;
}
.pk01-library-head h3 {
    margin: 0;
    font-size: 15px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-prompt-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 14px;
}
.pk01-cat-box {
    background: #f8fafc;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    padding: 14px;
}
.pk01-cat-title {
    font-size: 11px;
    font-weight: 800;
    color: var(--pk-slate-600);
    letter-spacing: 0.5px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: block;
}
.pk01-chip {
    width: 100%;
    text-align: left;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 12.5px;
    color: #334155;
    cursor: pointer;
    margin-bottom: 8px;
    transition: all 0.15s ease;
    line-height: 1.4;
    display: flex;
    align-items: flex-start;
    gap: 6px;
}
.pk01-chip:last-child { margin-bottom: 0; }
.pk01-chip:hover {
    border-color: var(--pk-indigo);
    background: #eef2ff;
    color: #312e81;
    transform: translateX(2px);
}

/* 3. Chat Surface & Input */
.pk01-chat-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-textarea-wrap textarea {
    width: 100%;
    padding: 14px 18px;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    font-size: 14px;
    color: #0f172a;
    background: #f8fafc;
    font-family: inherit;
    line-height: 1.6;
    outline: none;
    resize: vertical;
    transition: border-color 0.2s, box-shadow 0.2s;
}
.pk01-textarea-wrap textarea:focus {
    border-color: var(--pk-indigo);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
}

.pk01-action-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 14px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 22px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary {
    background: var(--pk-indigo);
    color: #ffffff !important;
    box-shadow: 0 2px 4px rgba(79, 70, 229, 0.2);
}
.pk01-btn-primary:hover:not(:disabled) {
    background: var(--pk-indigo-hover);
    transform: translateY(-1px);
}
.pk01-btn-primary:disabled {
    opacity: 0.65;
    cursor: wait;
}
.pk01-btn-subtle {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    color: #334155;
    padding: 8px 14px;
    font-size: 12px;
}
.pk01-btn-subtle:hover { background: #f8fafc; border-color: #94a3b8; }

/* 4. Chat Conversational Stream */
.pk01-chat-stream {
    display: flex;
    flex-direction: column;
    gap: 16px;
    margin-top: 24px;
}
.pk01-msg-bubble {
    display: flex;
    gap: 12px;
    padding: 18px 20px;
    border-radius: 14px;
    font-size: 13.5px;
    line-height: 1.65;
    animation: pkFadeIn 0.25s ease-out;
}
@keyframes pkFadeIn {
    from { opacity: 0; transform: translateY(6px); }
    to { opacity: 1; transform: translateY(0); }
}
.pk01-msg-user {
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    border-left: 4px solid var(--pk-indigo);
}
.pk01-msg-ai {
    background: #fbfcfe;
    border: 1px solid #e2e8f0;
    color: #1e293b;
    border-left: 4px solid var(--pk-emerald);
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}
.pk01-msg-avatar {
    width: 34px;
    height: 34px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    flex-shrink: 0;
}
.pk01-msg-body { flex: 1; overflow-x: auto; }
.pk01-msg-body h4 { margin: 12px 0 6px; font-size: 14px; font-weight: 800; color: #0f172a; }
.pk01-msg-body ul, .pk01-msg-body ol { margin: 8px 0; padding-left: 20px; }
.pk01-msg-body li { margin-bottom: 4px; }
.pk01-msg-body code { background: #e2e8f0; padding: 2px 5px; border-radius: 4px; font-size: 12px; font-family: monospace; }
</style>

<div class="pk01-ai-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-ai-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">AI CONTROL TOWER &bull; ADVISORY ENGINE</span>
            <h1>🤖 Asisten AI Operasional PK01</h1>
            <p>
                Asisten konsultatif untuk analisis mendalam omzet penjualan, efisiensi HPP, deteksi bahan di bawah stok minimum, dan penyusunan draf penagihan faktur otomatis.
            </p>
        </div>
        <div class="pk01-status-widget">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#fff;">
                <span class="pk01-ping-dot <?php echo $is_ready ? 'online' : 'offline'; ?>"></span>
                <span><?php echo $is_ready ? 'AI ENGINE SIAP' : 'API KEY BELUM DIISI'; ?></span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                Provider: <b><?php echo esc_html($status['provider']); ?></b>
            </div>
        </div>
    </header>

    <?php if (!$is_ready): ?>
    <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:12px; padding:16px 20px; margin-bottom:22px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
        <div style="font-size:13px; color:#92400e;">
            ⚠️ <strong>Perhatian:</strong> Kunci API AI (OpenAI / Claude / Gemini) belum dikonfigurasikan di sistem. Silakan masukkan API Key Anda agar AI dapat menganalisis data riil PK01.
        </div>
        <a href="<?php echo esc_url($settings_url); ?>" class="pk01-btn pk01-btn-subtle" style="background:#fff; font-weight:700; color:#b45309; border-color:#fcd34d;">
            ⚙️ Buka Pengaturan AI &rarr;
        </a>
    </div>
    <?php endif; ?>

    <!-- 2. PUSTAKA IDE PERTANYAAN CEPAT (PROMPT CHIPS) -->
    <section class="pk01-prompt-library">
        <div class="pk01-library-head">
            <h3>💡 Ide Pertanyaan Cepat Berdasarkan Modul Usaha</h3>
            <span style="font-size:12px; color:#64748b;">Klik salah satu untuk otomatis mengisi prompt</span>
        </div>
        <div class="pk01-prompt-grid">
            <div class="pk01-cat-box">
                <span class="pk01-cat-title">💰 Keuangan &amp; Arus Kas</span>
                <button type="button" class="pk01-chip">
                    <span>📊</span> <span>Analisis pos pengeluaran biaya operasional terbesar bulan ini dan rekomendasi efisiensinya.</span>
                </button>
                <button type="button" class="pk01-chip">
                    <span>🔍</span> <span>Periksa perbandingan omzet penjualan terhadap kas riil masuk di buku kas.</span>
                </button>
            </div>

            <div class="pk01-cat-box">
                <span class="pk01-cat-title">📦 Stok &amp; Gudang Bahan</span>
                <button type="button" class="pk01-chip">
                    <span>⚠️</span> <span>Identifikasi bahan baku yang berada di bawah batas stok minimum dan perlu segera di-PO.</span>
                </button>
                <button type="button" class="pk01-chip">
                    <span>📈</span> <span>Hitung valuasi total aset persediaan bahan baku yang tersimpan di gudang saat ini.</span>
                </button>
            </div>

            <div class="pk01-cat-box">
                <span class="pk01-cat-title">🏭 Job Produksi &amp; SPK</span>
                <button type="button" class="pk01-chip">
                    <span>⏱️</span> <span>Rekomendasikan prioritas penyelesaian antrean job produksi yang mendekati batas deadline.</span>
                </button>
                <button type="button" class="pk01-chip">
                    <span>💡</span> <span>Evaluasi persentase beban upah borongan terhadap nilai faktur penjualan bulan ini.</span>
                </button>
            </div>

            <div class="pk01-cat-box">
                <span class="pk01-cat-title">💬 Komunikasi &amp; Follow-Up</span>
                <button type="button" class="pk01-chip">
                    <span>✉️</span> <span>Buatkan draf pesan WhatsApp penagihan faktur jatuh tempo ke mitra secara ramah dan tegas.</span>
                </button>
                <button type="button" class="pk01-chip">
                    <span>🎯</span> <span>Susun strategi promo repeat order untuk pelanggan lama yang belum order di bulan ini.</span>
                </button>
            </div>
        </div>
    </section>

    <!-- 3. INPUT PROMPT & ACTION BAR -->
    <section class="pk01-chat-surface">
        <div class="pk01-textarea-wrap">
            <label style="display:block; font-size:13px; font-weight:700; color:#334155; margin-bottom:8px;">
                Pertanyaan, Instruksi, atau Permintaan Analisis:
            </label>
            <textarea id="pk01-ai-question" rows="4" placeholder="Tanyakan apa saja seputar analisis laba, stok, produksi, atau draf surat..."><?php echo esc_textarea($prefill_prompt); ?></textarea>
        </div>

        <div class="pk01-action-bar">
            <div style="display:flex; align-items:center; gap:10px;">
                <!-- Tombol selalu dapat diklik; jika belum ada API key, JS akan menampilkan pesan panduan ramah -->
                <button type="button" class="pk01-btn pk01-btn-primary" id="pk01-ai-ask" 
                        data-nonce="<?php echo esc_attr($nonce_ask); ?>" 
                        data-ready="<?php echo $is_ready ? '1' : '0'; ?>">
                    <span id="pk01-ask-icon">✨</span>
                    <span id="pk01-ask-text">Kirim Pertanyaan ke AI</span>
                </button>
                <button type="button" class="pk01-btn pk01-btn-subtle" id="pk01-ai-clear">
                    Bersihkan
                </button>
            </div>

            <div style="font-size:12px; color:#64748b;">
                <span>🛡️ Mode Konsultatif &bull; Aman &bull; Tekan <b>Ctrl + Enter</b> untuk mengirim</span>
            </div>
        </div>

        <!-- 4. CHAT STREAM / FEED PERCAKAPAN INTERAKTIF -->
        <div class="pk01-chat-stream" id="pk01-chat-stream" style="<?php echo !empty($prefill_prompt) ? 'display:flex;' : 'display:none;'; ?>">
            <?php if (!empty($prefill_prompt)): ?>
                <div class="pk01-msg-bubble pk01-msg-user">
                    <div class="pk01-msg-avatar" style="background:#4f46e5; color:#fff;">👤</div>
                    <div class="pk01-msg-body">
                        <strong>Prompt Permintaan:</strong>
                        <div style="margin-top:4px;"><?php echo nl2br(esc_html($prefill_prompt)); ?></div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

</div>

<script>
(function() {
    function initAIAssistant() {
        var askBtn        = document.getElementById('pk01-ai-ask');
        var questionInput = document.getElementById('pk01-ai-question');
        var chatStream    = document.getElementById('pk01-chat-stream');
        var clearBtn      = document.getElementById('pk01-ai-clear');
        var chips         = document.querySelectorAll('.pk01-chip');
        var askIcon       = document.getElementById('pk01-ask-icon');
        var askText       = document.getElementById('pk01-ask-text');

        if (!askBtn || !questionInput) return;

        // Pastikan atribut disabled dari PHP tidak menonaktifkan tombol
        askBtn.removeAttribute('disabled');

        // Klik Prompt Cepat (Chips)
        chips.forEach(function(chip) {
            chip.addEventListener('click', function() {
                var text = this.innerText.replace(/^[^\w\s]+/, '').trim();
                questionInput.value = text;
                questionInput.focus();
                // Animasi scroll ke input
                questionInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
        });

        // Kosongkan Form
        if (clearBtn) {
            clearBtn.addEventListener('click', function() {
                questionInput.value = '';
                questionInput.focus();
            });
        }

        // Format Markdown Sederhana
        function formatMarkdown(text) {
            if (!text) return '';
            var html = text
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
                .replace(/\*(.*?)\*/g, '<i>$1</i>')
                .replace(/`([^`]+)`/g, '<code>$1</code>')
                .replace(/\n\n/g, '<br><br>')
                .replace(/\n/g, '<br>');
            return html;
        }

        // Tambah Gelembung Chat ke Stream
        function appendBubble(role, content, isHtml) {
            if (!chatStream) return;
            chatStream.style.display = 'flex';

            var bubble = document.createElement('div');
            bubble.className = 'pk01-msg-bubble ' + (role === 'user' ? 'pk01-msg-user' : 'pk01-msg-ai');
            
            var avatar = role === 'user' ? '👤' : '🤖';
            var avatarBg = role === 'user' ? '#4f46e5' : '#059669';
            var title = role === 'user' ? 'Anda' : 'Asisten AI PK01';

            bubble.innerHTML = 
                '<div class="pk01-msg-avatar" style="background:' + avatarBg + '; color:#fff;">' + avatar + '</div>' +
                '<div class="pk01-msg-body">' +
                    '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">' +
                        '<strong style="color:#0f172a;">' + title + '</strong>' +
                        (role === 'ai' ? '<button type="button" class="pk01-btn pk01-btn-subtle copy-bubble-btn" style="padding:2px 8px; font-size:11px;">📋 Salin</button>' : '') +
                    '</div>' +
                    '<div class="bubble-content">' + (isHtml ? content : formatMarkdown(content)) + '</div>' +
                '</div>';

            chatStream.appendChild(bubble);

            // Handler Salin Jawaban
            var cpBtn = bubble.querySelector('.copy-bubble-btn');
            if (cpBtn) {
                cpBtn.addEventListener('click', function() {
                    var plainText = bubble.querySelector('.bubble-content').innerText;
                    navigator.clipboard.writeText(plainText).then(function() {
                        cpBtn.innerText = '✅ Tersalin!';
                        setTimeout(function() { cpBtn.innerText = '📋 Salin'; }, 2000);
                    });
                });
            }

            bubble.scrollIntoView({ behavior: 'smooth', block: 'end' });
        }

        // Kirim Pertanyaan
        function executeAsk() {
            var question = questionInput.value.trim();
            if (!question) {
                questionInput.focus();
                return;
            }

            var isConfigured = askBtn.dataset.ready === '1';
            if (!isConfigured) {
                alert('Konfigurasi API Key AI belum diatur. Silakan atur terlebih dahulu di menu Pengaturan Sentral > Tab AI Assistant.');
                return;
            }

            // Tambahkan pertanyaan pengguna ke layar
            appendBubble('user', question, false);
            questionInput.value = '';

            // Set status loading tombol
            askBtn.disabled = true;
            if (askIcon) askIcon.innerText = '⏳';
            if (askText) askText.innerText = 'Menganalisis...';

            // Elemen loading sementara
            var loadingId = 'ai-loading-' + Date.now();
            var loadingBubble = document.createElement('div');
            loadingBubble.id = loadingId;
            loadingBubble.className = 'pk01-msg-bubble pk01-msg-ai';
            loadingBubble.innerHTML = 
                '<div class="pk01-msg-avatar" style="background:#059669; color:#fff;">🤖</div>' +
                '<div class="pk01-msg-body"><span style="color:#64748b;">⏳ Menghubungkan ke AI Engine... Sedang memproses dan menganalisis basis data operasional PK01...</span></div>';
            chatStream.appendChild(loadingBubble);
            loadingBubble.scrollIntoView({ behavior: 'smooth', block: 'end' });

            // Kirim FormData dengan redundansi key parameter aman
            var fd = new FormData();
            fd.append('action', 'pk01_ai_ask');
            fd.append('security', askBtn.dataset.nonce);
            fd.append('nonce', askBtn.dataset.nonce);
            fd.append('_wpnonce', askBtn.dataset.nonce);
            fd.append('question', question);

            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                body: fd,
                credentials: 'same-origin'
            })
            .then(function(response) {
                return response.text();
            })
            .then(function(rawText) {
                var el = document.getElementById(loadingId);
                if (el) el.remove();

                var res;
                try {
                    res = JSON.parse(rawText);
                } catch(e) {
                    res = { data: rawText };
                }

                var output = '';
                if (res && res.data) {
                    if (typeof res.data === 'string') output = res.data;
                    else if (res.data.message) output = res.data.message;
                    else if (res.data.answer) output = res.data.answer;
                    else output = JSON.stringify(res.data, null, 2);
                } else if (res && res.message) {
                    output = res.message;
                } else if (res && res.answer) {
                    output = res.answer;
                } else if (typeof res === 'string' && res.trim() !== '') {
                    output = res;
                } else {
                    output = 'Analisis selesai, namun tidak ada respons teks yang diterima dari AI Engine.';
                }

                appendBubble('ai', output, false);
            })
            .catch(function(err) {
                var el = document.getElementById(loadingId);
                if (el) el.remove();
                appendBubble('ai', '⚠️ <b>Kendala Koneksi:</b> Gagal menghubungi AI Gateway. Pastikan server terhubung ke internet dan API Key Anda memiliki kuota yang cukup.', true);
            })
            .finally(function() {
                // Selalu aktifkan kembali tombol
                askBtn.disabled = false;
                if (askIcon) askIcon.innerText = '✨';
                if (askText) askText.innerText = 'Kirim Pertanyaan ke AI';
                questionInput.focus();
            });
        }

        askBtn.addEventListener('click', executeAsk);

        // Kirim via Ctrl + Enter atau Cmd + Enter
        questionInput.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                executeAsk();
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAIAssistant);
    } else {
        initAIAssistant();
    }
})();
</script>