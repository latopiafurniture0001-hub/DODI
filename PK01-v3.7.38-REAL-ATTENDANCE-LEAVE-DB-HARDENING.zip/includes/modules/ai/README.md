# PK01 — Modul Ai

Folder canonical: `includes/modules/ai/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/ai/assistant/tampilan-asisten-ai.php`
- `includes/modules/ai/center/tampilan-ai-center.php`
- `includes/modules/ai/core/class-pk01-ai-orchestrator.php`
- `includes/modules/ai/core/class-pk01-ai.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
