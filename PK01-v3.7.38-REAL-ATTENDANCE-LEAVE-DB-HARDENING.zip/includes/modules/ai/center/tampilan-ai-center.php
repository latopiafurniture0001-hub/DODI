<?php
if (!defined('ABSPATH')) exit;

// 1. OTORISASI MUTLAK ADMINISTRATOR (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin && (!class_exists('PK01_Authorization') || !PK01_Authorization::can_action('ai_center', 'view'))) {
    echo '<div class="pk01-ai-alert error" style="max-width:600px;margin:30px auto;padding:18px;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;text-align:center;">
            <div style="font-size:36px;margin-bottom:8px;">🚫</div>
            <h3 style="margin:0 0 6px 0;color:#991b1b;">Akses Dibatasi</h3>
            <p style="margin:0;color:#64748b;font-size:13px;">Anda tidak memiliki wewenang untuk mengelola atau melihat AI Control Center.</p>
          </div>';
    return;
}

// 2. STATUS ENGINE & MULTI-PROVIDER ORCHESTRATOR
$st = class_exists('PK01_AI_Orchestrator') ? PK01_AI_Orchestrator::status() : [];
$is_ai_enabled = !empty($st['enabled']);
$mutation_policy = !empty($st['mutation_policy']) ? $st['mutation_policy'] : 'Draf & Rencana saja (Read-Only Advisor)';
$providers = (array)($st['providers'] ?? []);

// Urutkan provider berdasarkan prioritas (terkecil = prioritas utama)
usort($providers, function($a, $b) {
    return ((int)($a['priority'] ?? 99)) <=> ((int)($b['priority'] ?? 99));
});

$rest_endpoint = esc_url(rest_url('pk01/v1/ai/ask'));
$rest_nonce    = wp_create_nonce('wp_rest');
?>

<style>
:root {
    --pk-ai-navy: #0f172a;
    --pk-ai-card: #1e293b;
    --pk-ai-indigo: #6366f1;
    --pk-ai-indigo-hover: #4f46e5;
    --pk-ai-border: #e2e8f0;
    --pk-ai-text: #1e293b;
    --pk-ai-muted: #64748b;
}

.pk01-ai-hub {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: var(--pk-ai-text);
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-ai-hub * { box-sizing: border-box; }

/* Hero Banner */
.pk01-ai-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #312e81 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 26px 30px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.2);
}
.pk01-ai-eyebrow {
    display: inline-block;
    background: rgba(99, 102, 241, 0.2);
    color: #a5b4fc;
    border: 1px solid rgba(165, 180, 252, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 8px;
}
.pk01-ai-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-ai-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}
.pk01-ai-status-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    background: #1e293b;
    border: 1px solid #334155;
    color: #f1f5f9;
}
.pk01-status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #ef4444;
}
.pk01-status-dot.active {
    background: #10b981;
    box-shadow: 0 0 8px #10b981;
}

/* Pipeline Architecture Strip */
.pk01-pipeline-strip {
    background: #ffffff;
    border: 1px solid var(--pk-ai-border);
    border-radius: 14px;
    padding: 20px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}
.pk01-pipeline-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 14px;
    flex-wrap: wrap;
    gap: 8px;
}
.pk01-pipeline-head h3 {
    margin: 0;
    font-size: 15px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-pipeline-flow {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
}
.pk01-flow-card {
    background: #f8fafc;
    border: 1px solid var(--pk-ai-border);
    border-radius: 10px;
    padding: 14px;
    position: relative;
}
.pk01-flow-card.priority-1 {
    border-color: #a5b4fc;
    background: #eef2ff;
}
.pk01-priority-tag {
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    padding: 2px 6px;
    border-radius: 4px;
    background: #e2e8f0;
    color: #334155;
    display: inline-block;
    margin-bottom: 6px;
}
.pk01-flow-card.priority-1 .pk01-priority-tag {
    background: #6366f1;
    color: #ffffff;
}
.pk01-flow-card strong {
    display: block;
    font-size: 14px;
    color: #0f172a;
    margin-bottom: 3px;
}
.pk01-flow-card span {
    display: block;
    font-size: 12px;
    color: #64748b;
    font-family: monospace;
}

/* Interactive Sandbox / Diagnostics */
.pk01-sandbox-card {
    background: #ffffff;
    border: 1px solid var(--pk-ai-border);
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}
.pk01-sandbox-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 14px;
}
.pk01-sandbox-head h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-terminal-box {
    background: #0f172a;
    color: #e2e8f0;
    border-radius: 10px;
    padding: 14px 18px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 13px;
    line-height: 1.6;
    margin-top: 12px;
    min-height: 70px;
    white-space: pre-wrap;
}

/* Master Form */
.pk01-card {
    background: #ffffff;
    border: 1px solid var(--pk-ai-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}
.pk01-card-head {
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-card-head h3 {
    margin: 0 0 4px 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-card-head p {
    margin: 0;
    font-size: 13px;
    color: #64748b;
}

.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-ai-border);
    border-radius: 10px;
}
.pk01-ai-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-ai-table th {
    background: #f8fafc;
    padding: 11px 12px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-ai-border);
}
.pk01-ai-table td {
    padding: 11px 12px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-input {
    width: 100%;
    padding: 7px 10px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 13px;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: #6366f1;
    background: #ffffff;
}

.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-btn-primary {
    background: #0f172a;
    color: #ffffff !important;
}
.pk01-btn-primary:hover {
    background: #1e293b;
}
.pk01-btn-indigo {
    background: #6366f1;
    color: #ffffff !important;
}
.pk01-btn-indigo:hover {
    background: #4f46e5;
}

/* Guardrails Info Box */
.pk01-guardrail-box {
    background: #f8fafc;
    border: 1px dashed #cbd5e1;
    border-radius: 12px;
    padding: 16px 20px;
    font-size: 13px;
    color: #475569;
    line-height: 1.5;
}
.pk01-guardrail-box strong { color: #0f172a; }
</style>

<div class="pk01-ai-hub">
    
    <!-- 1. HERO COCKPIT -->
    <header class="pk01-ai-hero">
        <div>
            <span class="pk01-ai-eyebrow">INTELLIGENT BUSINESS ENGINE</span>
            <h1>AI Control Center &bull; Multi-Provider Hub</h1>
            <p>
                Pusat orkestrasi kecerdasan buatan PK01. AI membaca data sesuai role pengguna untuk menghasilkan analisis, rekomendasi operasional, dan perencanaan tanpa melangkahi hak otorisasi mutasi keuangan.
            </p>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;">
            <div class="pk01-ai-status-pill">
                <span class="pk01-status-dot <?php echo $is_ai_enabled ? 'active' : ''; ?>"></span>
                <span><?php echo $is_ai_enabled ? 'AI Engine Aktif' : 'AI Engine Nonaktif'; ?></span>
            </div>
            <span style="font-size:11px;color:#94a3b8;">Policy: <?php echo esc_html($mutation_policy); ?></span>
        </div>
    </header>

    <!-- 2. HIGH-AVAILABILITY FAILOVER PIPELINE -->
    <section class="pk01-pipeline-strip">
        <div class="pk01-pipeline-head">
            <h3>Urutan Failover Pipeline Provider (Prioritas Terkecil &rarr; Utama)</h3>
            <span style="font-size:12px;color:#64748b;">Jika provider utama gagal/timeout, sistem otomatis beralih ke cadangan</span>
        </div>
        <div class="pk01-pipeline-flow">
            <?php 
            if (!empty($providers)):
                foreach ($providers as $idx => $p):
                    $is_p_on = !empty($p['enabled']);
                    $has_token = !empty($p['token_configured']) || ($p['type'] ?? '') === 'ollama';
            ?>
                <div class="pk01-flow-card <?php echo $idx === 0 ? 'priority-1' : ''; ?>">
                    <span class="pk01-priority-tag">Prioritas #<?php echo (int)$p['priority']; ?> <?php echo $idx === 0 ? '&bull; UTAMA' : ''; ?></span>
                    <strong><?php echo esc_html($p['name']); ?></strong>
                    <span>Model: <?php echo esc_html($p['model']); ?></span>
                    <div style="margin-top:8px;display:flex;justify-content:space-between;align-items:center;font-size:11px;">
                        <span style="color:<?php echo $has_token ? '#16a34a' : '#d97706'; ?>;font-weight:600;">
                            <?php echo $has_token ? '● Token Siap' : '○ Token Belum'; ?>
                        </span>
                        <span style="color:<?php echo $is_p_on ? '#2563eb' : '#94a3b8'; ?>;font-weight:700;">
                            <?php echo $is_p_on ? 'AKTIF' : 'OFF'; ?>
                        </span>
                    </div>
                </div>
            <?php 
                endforeach;
            else:
            ?>
                <div style="grid-column:1/-1;color:#94a3b8;font-size:13px;padding:12px;">Belum ada provider yang terdaftar di sistem orchestrator.</div>
            <?php endif; ?>
        </div>
    </section>

    <!-- 3. LIVE AI SANDBOX & DIAGNOSTICS TERMINAL -->
    <section class="pk01-sandbox-card" id="pk01-ai-sandbox" data-endpoint="<?php echo $rest_endpoint; ?>" data-nonce="<?php echo $rest_nonce; ?>">
        <div class="pk01-sandbox-head">
            <div>
                <h3>⚡ Konsol Diagnostik &amp; Uji Respons AI Live</h3>
                <span style="font-size:12px;color:#64748b;">Kirim prompt uji untuk memverifikasi provider aktif merespons tanpa masalah</span>
            </div>
            <div style="display:flex;gap:8px;">
                <button type="button" class="pk01-btn pk01-btn-indigo" id="btn_ping_ai" style="padding:6px 14px;font-size:12px;">
                    ▶ Kirim Ping Test
                </button>
            </div>
        </div>

        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <input type="text" id="ai_test_prompt" class="pk01-input" style="flex:1;min-width:280px;" value="Periksa kesehatan sistem PK01 dan berikan rekomendasi operasional singkat hari ini.">
        </div>

        <div class="pk01-terminal-box" id="ai_terminal_result">
> Terminal AI Standby. Klik tombol "Kirim Ping Test" untuk menguji latensi dan konektivitas model AI saat ini.
        </div>
    </section>

    <!-- 4. PENGATURAN PROVIDER & TOKEN (FORM ASLI DILINDUNGI & DIPERTINGGI) -->
    <?php if ($is_admin): ?>
    <section class="pk01-card">
        <div class="pk01-card-head">
            <h3>Konfigurasi Endpoint Provider &amp; Secret Token</h3>
            <p>
                Sistem mencoba provider berdasarkan <strong>angka prioritas terkecil</strong>. Jika provider gagal atau token limit, PK01 otomatis failover ke baris berikutnya. Token yang tersimpan dienkripsi dan tidak ditampilkan kembali demi keamanan.
            </p>
        </div>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('pk01_ai_orchestrator_save'); ?>
            <input type="hidden" name="action" value="pk01_ai_orchestrator_save">

            <div class="pk01-table-wrap">
                <table class="pk01-ai-table">
                    <thead>
                        <tr>
                            <th style="width:170px;">Nama Provider</th>
                            <th>Endpoint URL / Gateway</th>
                            <th style="width:180px;">Model Target</th>
                            <th style="width:200px;">Token / API Key Baru</th>
                            <th style="width:80px;text-align:center;">Prioritas</th>
                            <th style="width:60px;text-align:center;">Aktif</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach ($providers as $p): 
                            $id = sanitize_key($p['id']);
                        ?>
                        <tr>
                            <td>
                                <input class="pk01-input" style="font-weight:700;" name="providers[<?php echo esc_attr($id); ?>][name]" value="<?php echo esc_attr($p['name']); ?>">
                            </td>
                            <td>
                                <input class="pk01-input" style="font-family:monospace;font-size:12px;" name="providers[<?php echo esc_attr($id); ?>][endpoint]" value="<?php echo esc_attr($p['endpoint']); ?>">
                            </td>
                            <td>
                                <input class="pk01-input" style="font-family:monospace;" name="providers[<?php echo esc_attr($id); ?>][model]" value="<?php echo esc_attr($p['model']); ?>">
                            </td>
                            <td>
                                <input type="password" class="pk01-input" name="providers[<?php echo esc_attr($id); ?>][token]" autocomplete="new-password" placeholder="<?php echo !empty($p['token_configured']) ? '•••••••• (Tersimpan)' : 'Belum diatur'; ?>">
                            </td>
                            <td>
                                <input type="number" min="1" max="99" style="text-align:center;" class="pk01-input" name="providers[<?php echo esc_attr($id); ?>][priority]" value="<?php echo (int)$p['priority']; ?>">
                            </td>
                            <td style="text-align:center;">
                                <input type="checkbox" name="providers[<?php echo esc_attr($id); ?>][enabled]" value="1" <?php checked(!empty($p['enabled'])); ?> style="width:16px;height:16px;cursor:pointer;">
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top:16px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
                <div style="font-size:12px;color:#64748b;">
                    💡 <strong>Ollama Lokal:</strong> Endpoint default <code>http://127.0.0.1:11434/api/chat</code>, bebas kuota API token untuk komputasi mandiri tanpa internet.
                </div>
                <button class="pk01-btn pk01-btn-primary" type="submit">💾 Simpan Semua Provider</button>
            </div>
        </form>
    </section>
    <?php endif; ?>

    <!-- 5. GUARDRAILS & ATURAN OTORISASI AKUNTANSI -->
    <section class="pk01-guardrail-box">
        <strong>🛡️ Kebijakan Integritas Data &amp; Guardrails PK01:</strong><br>
        AI diizinkan membaca data agregasi operasional untuk memberikan arahan prioritas, deteksi dini piutang macet, draf surat jalan, dan efisiensi produksi. AI <strong>dilarang keras mengeksekusi mutasi saldo kas atau mengubah jurnal keuangan secara sepihak</strong>. Setiap perubahan fisik transaksi wajib melewati verifikasi otorisasi pengguna dan persetujuan Admin.
    </section>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sandbox = document.getElementById('pk01-ai-sandbox');
    const pingBtn = document.getElementById('btn_ping_ai');
    const promptInput = document.getElementById('ai_test_prompt');
    const terminal = document.getElementById('ai_terminal_result');

    if (pingBtn && sandbox && terminal) {
        pingBtn.addEventListener('click', async function() {
            const prompt = promptInput.value.trim();
            if (!prompt) {
                alert('Silakan ketik pertanyaan uji coba terlebih dahulu.');
                return;
            }

            pingBtn.disabled = true;
            pingBtn.textContent = 'Menghubungi AI...';
            const startTime = performance.now();
            terminal.textContent = '> Mengirim permintaan ke endpoint Orchestrator...\n> Menunggu respons AI Provider aktif...';

            try {
                const response = await fetch(sandbox.dataset.endpoint, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': sandbox.dataset.nonce
                    },
                    body: JSON.stringify({
                        question: prompt,
                        module: 'ai_center_diagnostic'
                    })
                });

                const endTime = performance.now();
                const latency = Math.round(endTime - startTime);
                const data = await response.json();

                if (data && data.message) {
                    terminal.textContent = `[OK] Respons Diterima (${latency} ms) via Provider Aktif:\n\n${data.message}`;
                } else if (data && data.error) {
                    terminal.textContent = `[FAIL] Error (${latency} ms):\n${data.error}`;
                } else {
                    terminal.textContent = `[WARN] Respons diterima (${latency} ms):\n${JSON.stringify(data, null, 2)}`;
                }
            } catch (err) {
                terminal.textContent = `[ERROR] Gagal menghubungi backend API:\n${err.message}\nPastikan provider AI aktif dan endpoint dapat diakses.`;
            }

            pingBtn.disabled = false;
            pingBtn.textContent = '▶ Kirim Ping Test';
        });
    }
});
</script>