<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 AI Orchestrator 1.0
 * Multi-provider, multi-token failover, Ollama/local mode, menu-aware context
 * and safe action planning. AI may propose actions, but transactional mutations
 * must still pass PK01 authorization + engine validation and explicit approval.
 */
class PK01_AI_Orchestrator {
    public static function init(){
        add_action('rest_api_init',[__CLASS__,'routes']);
        add_action('admin_init',[__CLASS__,'protect_wp_admin'],1);
    }

    public static function defaults(){
        return [
            'enabled'=>1,
            'offline_fallback'=>1,
            'active_provider'=>'auto',
            'providers'=>[
                ['id'=>'openai-1','name'=>'OpenAI','type'=>'openai_compatible','endpoint'=>'https://api.openai.com/v1/chat/completions','model'=>'gpt-4o-mini','token'=>'','enabled'=>1,'priority'=>10,'local'=>0],
                ['id'=>'gemini-1','name'=>'Google Gemini','type'=>'gemini','endpoint'=>'https://generativelanguage.googleapis.com/v1beta/models','model'=>'gemini-2.5-flash','token'=>'','enabled'=>0,'priority'=>20,'local'=>0],
                ['id'=>'anthropic-1','name'=>'Anthropic','type'=>'anthropic','endpoint'=>'https://api.anthropic.com/v1/messages','model'=>'claude-3-5-haiku-latest','token'=>'','enabled'=>0,'priority'=>30,'local'=>0],
                ['id'=>'openrouter-1','name'=>'OpenRouter','type'=>'openai_compatible','endpoint'=>'https://openrouter.ai/api/v1/chat/completions','model'=>'','token'=>'','enabled'=>1,'priority'=>40,'local'=>0],
                ['id'=>'ollama-local','name'=>'Ollama Lokal','type'=>'ollama','endpoint'=>'http://127.0.0.1:11434/api/chat','model'=>'llama3.2','token'=>'','enabled'=>1,'priority'=>50,'local'=>1],
            ],
            'role_access'=>['administrator'=>1,'pk01_admin'=>1,'pk01_owner'=>1,'pk01_investor'=>1,'editor'=>1,'shop_manager'=>1,'pk01_employee'=>1,'pk01_seller'=>1,'pk01_gudang'=>1,'pk01_produksi'=>1,'pk01_kasir'=>1,'pk01_keuangan'=>1,'pk01_hr'=>1,'pk01_logistik'=>1],
            'require_admin_for_mutation'=>1,
            'timeout'=>35,
            'provider_health'=>[],
        ];
    }
    private static function cfg(){
        $saved=get_option('pk01_ai_orchestrator',[]); return wp_parse_args(is_array($saved)?$saved:[],self::defaults());
    }
    private static function enc($plain){
        if($plain==='') return '';
        $key=hash('sha256',wp_salt('auth'),true); $iv=random_bytes(16); $c=openssl_encrypt($plain,'AES-256-CBC',$key,OPENSSL_RAW_DATA,$iv); return base64_encode($iv.$c);
    }
    private static function dec($cipher){
        if(!$cipher) return '';
        $raw=base64_decode($cipher,true); if(!$raw||strlen($raw)<17) return '';
        $key=hash('sha256',wp_salt('auth'),true); $iv=substr($raw,0,16); return (string)openssl_decrypt(substr($raw,16),'AES-256-CBC',$key,OPENSSL_RAW_DATA,$iv);
    }
    public static function save_config($input){
        if(!current_user_can('manage_options')) return new WP_Error('forbidden','Hanya Administrator yang boleh mengatur AI.');
        $old=self::cfg(); $in=is_array($input)?$input:[]; $providers=[];
        foreach((array)($in['providers']??[]) as $i=>$p){
            $id=sanitize_key($p['id']??('provider-'.($i+1))); $token=trim((string)($p['token']??''));
            $existing=''; foreach((array)$old['providers'] as $op){if(($op['id']??'')===$id){$existing=$op['token']??'';break;}}
            $providers[]=[
                'id'=>$id,'name'=>sanitize_text_field($p['name']??$id),'type'=>in_array(($p['type']??''),['ollama','openai_compatible','gemini','anthropic'],true)?$p['type']:'openai_compatible',
                'endpoint'=>esc_url_raw($p['endpoint']??''),'model'=>sanitize_text_field($p['model']??''),'token'=>$token!==''?self::enc($token):$existing,
                'enabled'=>empty($p['enabled'])?0:1,'priority'=>max(1,(int)($p['priority']??50)),'local'=>empty($p['local'])?0:1
            ];
        }
        if(!$providers) $providers=$old['providers'];
        $cfg=['enabled'=>empty($in['enabled'])?0:1,'offline_fallback'=>empty($in['offline_fallback'])?0:1,'active_provider'=>sanitize_key($in['active_provider']??'auto'),'providers'=>$providers,'role_access'=>array_map('intval',(array)($in['role_access']??$old['role_access'])),'require_admin_for_mutation'=>1,'timeout'=>max(10,min(90,(int)($in['timeout']??35)))];
        update_option('pk01_ai_orchestrator',$cfg,false); return ['ok'=>true,'message'=>'Konfigurasi AI tersimpan.'];
    }
    public static function status(){
        $c=self::cfg(); $providers=[]; $health=(array)($c['provider_health']??[]);
        foreach((array)$c['providers'] as $p){
            $h=(array)($health[$p['id']]??[]);
            $providers[]=['id'=>$p['id'],'name'=>$p['name'],'type'=>$p['type'],'model'=>$p['model'],'enabled'=>(bool)$p['enabled'],'priority'=>(int)$p['priority'],'local'=>(bool)$p['local'],'token_configured'=>!empty($p['token']),'status'=>$h['status']??(empty($p['enabled'])?'DISABLED':'UNKNOWN'),'last_error'=>$h['last_error']??'','last_test'=>$h['last_test']??null,'usage'=>$h['usage']??0,'daily_limit'=>$h['daily_limit']??null,'monthly_limit'=>$h['monthly_limit']??null];
        }
        return ['enabled'=>(bool)$c['enabled'],'offline_fallback'=>(bool)$c['offline_fallback'],'providers'=>$providers,'active_provider'=>$c['active_provider'],'mutation_policy'=>'AI hanya memberi rekomendasi/draft. Mutasi transaksi tetap melalui authorization PK01, business function existing dan persetujuan eksplisit bila diperlukan.'];
    }
    private static function providers(){
        $c=self::cfg(); $arr=array_values(array_filter((array)$c['providers'],function($p){return !empty($p['enabled']);}));
        usort($arr,function($a,$b){return (int)$a['priority'] <=> (int)$b['priority'];}); return $arr;
    }
    public static function menu_context($module){
        $module=class_exists('PK01_Authorization')?PK01_Authorization::normalize_module($module):sanitize_key($module);
        $map=[
            'sales'=>'Penjualan: invoice, pembayaran, piutang, retur, komisi.', 'materials'=>'Gudang: stok bahan, minimum stok, mutasi.', 'production'=>'Produksi: job/SPK, bahan terpakai, hasil produksi, upah job.',
            'purchase'=>'Pembelian: PO, penerimaan, supplier, hutang, pembayaran.', 'shipments'=>'Logistik: pengiriman, resi, status dan bukti.', 'finance'=>'Keuangan: kas, laba rugi, HPP, biaya, rekonsiliasi.',
            'employees'=>'SDM: karyawan, payroll dan upah job.', 'job_wages'=>'Upah Job: rincian pekerjaan dan pembayaran.', 'assets_inventory'=>'Aset: pembelian aset, nilai buku dan penyusutan.',
            'pricing'=>'Pricing/HPP: spesifikasi, material, waste, upah, overhead dan margin.', 'seller'=>'Seller: penjualan manual, harga internal PK01, resi, tagihan, pembayaran, dan retur.', 'marketplace'=>'Marketplace: input manual penjualan, order/resi, payout perusahaan, serta monitoring payout Seller; payout Seller tidak membuat tagihan baru.',
            'master_data'=>'Master: produk/SKU, bahan, supplier, pelanggan, karyawan.', 'ai_assistant'=>'AI Control Tower dan automasi aman.'
        ];
        return ['module'=>$module,'description'=>$map[$module]??'Modul operasional PK01.','role'=>class_exists('PK01_Authorization')?PK01_Authorization::effective_role():'guest','scope'=>class_exists('PK01_Authorization')?PK01_Authorization::data_scope():'OWN'];
    }
    public static function plan($command,$module='dashboard'){
        $q=sanitize_textarea_field($command); $m=self::menu_context($module); $role=$m['role'];
        $action='analyze'; $target=$module;
        $rules=[['hapus|delete|hapus data','delete'],['edit|koreksi|ubah','edit'],['input|buat|tambah|catat','create'],['bayar|transfer|ambil|bon','payment'],['cetak|print|pdf','print']];
        foreach($rules as $r){if(preg_match('/'.$r[0].'/iu',$q)){$action=$r[1];break;}}
        $mutating=in_array($action,['delete','edit','create','payment'],true);
        return ['ok'=>true,'plan'=>['module'=>$m['module'],'action'=>$action,'target'=>$target,'role'=>$role,'mutating'=>$mutating,'requires_admin_approval'=>$mutating,'command'=>$q,'next'=>'Tinjau lalu setujui melalui menu PK01; AI tidak mengeksekusi SQL langsung.']];
    }
    private static function set_provider_health($id,$status,$error='') {
        $c=self::cfg(); $h=(array)($c['provider_health']??[]); $old=(array)($h[$id]??[]);
        $h[$id]=array_merge($old,['status'=>$status,'last_error'=>sanitize_text_field(substr((string)$error,0,300)),'last_test'=>current_time('mysql')]);
        $c['provider_health']=$h; update_option('pk01_ai_orchestrator',$c,false);
    }

    private static function call_provider($p,$messages,$timeout){
        $endpoint=esc_url_raw($p['endpoint']); if(!$endpoint) return new WP_Error('endpoint','Endpoint kosong',['provider_status'=>'SERVER_ERROR']);
        $type=$p['type']??'openai_compatible'; $token=self::dec($p['token']??'');
        $headers=['Content-Type'=>'application/json'];
        $url=$endpoint;
        if($type==='gemini'){
            $url=rtrim($endpoint,'/').'/'.rawurlencode($p['model']?:'gemini-2.5-flash').':generateContent?key='.rawurlencode($token);
            $parts=[]; foreach($messages as $m){$parts[]=['role'=>($m['role']==='assistant'?'model':'user'),'parts'=>[['text'=>(string)$m['content']]]];}
            $body=['contents'=>$parts,'generationConfig'=>['temperature'=>0.2,'maxOutputTokens'=>1400]];
        } elseif($type==='anthropic'){
            if($token!=='') $headers['x-api-key']=$token; $headers['anthropic-version']='2023-06-01';
            $system=''; $msgs=[]; foreach($messages as $m){if($m['role']==='system'){$system.=(string)$m['content'].'\n';}else{$msgs[]=['role'=>$m['role']==='assistant'?'assistant':'user','content'=>(string)$m['content']];}}
            $body=['model'=>$p['model']?:'claude-3-5-haiku-latest','max_tokens'=>1400,'temperature'=>0.2,'messages'=>$msgs]; if($system!=='')$body['system']=trim($system);
        } elseif($type==='ollama'){
            $body=['model'=>$p['model']?:'llama3.2','messages'=>$messages,'stream'=>false,'options'=>['temperature'=>0.2]];
        } else {
            if($token!=='')$headers['Authorization']='Bearer '.$token;
            $body=['model'=>$p['model']?:'gpt-4o-mini','messages'=>$messages,'temperature'=>0.2,'max_tokens'=>1400];
            if(strpos($endpoint,'openrouter.ai')!==false){$headers['HTTP-Referer']=home_url('/');$headers['X-Title']='PK01 Business OS';}
        }
        $r=wp_remote_post($url,['timeout'=>$timeout,'sslverify'=>true,'headers'=>$headers,'body'=>wp_json_encode($body)]);
        if(is_wp_error($r)) return new WP_Error('provider_transport',$r->get_error_message(),['provider_status'=>stripos($r->get_error_message(),'timed out')!==false?'TIMEOUT':'SERVER_ERROR']);
        $code=wp_remote_retrieve_response_code($r); $raw=wp_remote_retrieve_body($r); $data=json_decode($raw,true);
        if($code<200||$code>=300){
            $status=($code===401||$code===403)?'AUTH_ERROR':(($code===408||$code===504)?'TIMEOUT':(($code===429)?(stripos($raw,'quota')!==false?'QUOTA_EXCEEDED':'RATE_LIMIT'):($code>=500?'SERVER_ERROR':'SERVER_ERROR')));
            return new WP_Error('provider_http','Provider HTTP '.$code,['provider_status'=>$status,'http_code'=>$code]);
        }
        if($type==='gemini') $ans=$data['candidates'][0]['content']['parts'][0]['text']??'';
        elseif($type==='anthropic') $ans=$data['content'][0]['text']??'';
        else $ans=$data['message']['content']??$data['choices'][0]['message']['content']??$data['output'][0]['content'][0]['text']??'';
        if(!is_string($ans)||trim($ans)==='') return new WP_Error('empty','Provider tidak mengembalikan jawaban.',['provider_status'=>'SERVER_ERROR']);
        return trim($ans);
    }
    public static function ask($question,$module='dashboard',$extra=[]){
        $c=self::cfg(); $question=sanitize_textarea_field($question);
        if(empty($c['enabled'])) return ['ok'=>true,'offline'=>true,'message'=>'AI dinonaktifkan oleh konfigurasi.'];
        if($question==='') return new WP_Error('empty_question','Pertanyaan AI tidak boleh kosong.');
        if(class_exists('PK01_Authorization') && !PK01_Authorization::can_action('ai_assistant','view')) return new WP_Error('forbidden','Anda tidak memiliki izin menggunakan AI.');
        $ctx=class_exists('PK01_AI')?PK01_AI::operational_context():[]; $menu=self::menu_context($module);
        $system='Anda adalah PK01 AI Control Tower. Gunakan hanya data database yang disediakan melalui context. Jangan mengarang angka, transaksi, stok, saldo, profit, HPP, komisi, investor atau status eksekusi. AI bersifat advisory; business logic PK01 adalah sumber kebenaran. Modul aktif: '.wp_json_encode($menu,JSON_UNESCAPED_UNICODE)."\nData operasional: ".wp_json_encode($ctx,JSON_UNESCAPED_UNICODE);
        $messages=[['role'=>'system','content'=>$system],['role'=>'user','content'=>$question]]; $errors=[];
        foreach(self::providers() as $p){
            $ans=self::call_provider($p,$messages,(int)$c['timeout']);
            if(!is_wp_error($ans)){ self::set_provider_health($p['id'],'AVAILABLE',''); if(class_exists('PK01_Audit')) PK01_Audit::info('ai_provider_success','ai_assistant','Provider '.$p['id']); return ['ok'=>true,'provider'=>$p['id'],'model'=>$p['model'],'message'=>$ans,'menu'=>$menu,'data'=>$ctx]; }
            $status=is_array($ans->get_error_data())?($ans->get_error_data()['provider_status']??'SERVER_ERROR'):'SERVER_ERROR'; $errors[]=['provider'=>$p['id'],'status'=>$status]; self::set_provider_health($p['id'],$status,$ans->get_error_message());
        }
        if(class_exists('PK01_Audit')) PK01_Audit::warn('ai_unavailable','ai_assistant','Semua provider AI gagal atau tidak tersedia.');
        return ['ok'=>false,'code'=>'ai_unavailable','status'=>'AI_UNAVAILABLE','message'=>'AI tidak tersedia. Tidak ada respons AI yang dapat diverifikasi.','provider_errors'=>$errors,'menu'=>$menu];
    }
    public static function routes(){
        register_rest_route('pk01/v1','/ai/status',['methods'=>'GET','permission_callback'=>function(){return is_user_logged_in();},'callback'=>function(){return rest_ensure_response(self::status());}]);
        register_rest_route('pk01/v1','/ai/ask',['methods'=>'POST','permission_callback'=>function(){return is_user_logged_in() && class_exists('PK01_Authorization') && PK01_Authorization::can_action('ai_assistant','view');},'callback'=>function($r){return rest_ensure_response(self::ask($r->get_param('question')??'',$r->get_param('module')??'dashboard'));}]);
        register_rest_route('pk01/v1','/ai/plan',['methods'=>'POST','permission_callback'=>function(){return is_user_logged_in() && class_exists('PK01_Authorization') && PK01_Authorization::can_action('ai_assistant','view');},'callback'=>function($r){return rest_ensure_response(self::plan($r->get_param('command')??'',$r->get_param('module')??'dashboard'));}]);
    }
    public static function protect_wp_admin(){
        if(!is_admin()||wp_doing_ajax()||wp_doing_cron())return;
        if(defined('REST_REQUEST')&&REST_REQUEST)return;
        if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE)return;
        if(!is_user_logged_in())return;

        // WP Admin adalah area administrasi teknis WordPress: hanya Administrator
        // (dan Super Admin multisite) yang boleh masuk. Semua role operasional PK01
        // tetap bekerja melalui portal frontend sesuai role masing-masing.
        $u=wp_get_current_user();
        $is_wp_admin = in_array('administrator',(array)$u->roles,true) || is_super_admin($u->ID);
        if($is_wp_admin)return;

        if(class_exists('PK01_Admin')){
            wp_safe_redirect(PK01_Admin::get_frontend_url('dashboard'));
            exit;
        }
        wp_safe_redirect(home_url('/'));
        exit;
    }
}
