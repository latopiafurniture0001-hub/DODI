<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Enterprise AI Gateway & Operational Control Tower
 * Lapisan kecerdasan buatan konsultatif dan analitik bisnis.
 * Prinsip: AI tidak pernah menjadi sumber data tunggal dan tidak mengubah database secara langsung.
 */
class PK01_AI {

    /**
     * Inisialisasi Hook AJAX
     */
    public static function init() {
        add_action('wp_ajax_pk01_ai_ask', [__CLASS__, 'ajax_ask']);
        add_action('wp_ajax_pk01_ai_price_recommend', [__CLASS__, 'ajax_price_recommend']);
    }

    /**
     * Ambil Konfigurasi Pengaturan AI dari Database
     */
    public static function settings() {
        $defaults = [
            'ai_enabled'        => 1,
            'provider'          => 'openai',
            'model'             => 'gpt-4o-mini',
            'endpoint'          => '',
            'api_key'           => '',
            'default_profit'    => 30,
            'allocation_method' => 'volume',
            'temperature'       => 0.2
        ];

        $saved = [];
        if (class_exists('PK01_Settings') && method_exists('PK01_Settings', 'get_group')) {
            $saved = PK01_Settings::get_group('ai');
        } elseif (class_exists('PK01_Settings') && method_exists('PK01_Settings', 'get')) {
            $saved = PK01_Settings::get();
        }

        if (empty($saved)) {
            $saved = (array) get_option('pk01_settings', []);
        }

        return wp_parse_args($saved, $defaults);
    }

    /**
     * Cek Kesiapan Status Koneksi API AI
     */
    public static function status() {
        $s = self::settings();
        $has_key = !empty($s['api_key']);
        $has_endpoint = !empty($s['endpoint']) || !empty(self::default_endpoint($s['provider']));
        $configured = (bool)($has_key && $has_endpoint);
        $enabled = (bool)($s['ai_enabled'] ?? false);

        return [
            'enabled'    => $enabled,
            'configured' => $configured,
            'available'  => ($enabled && $configured),
            'provider'   => $s['provider'] ?: 'OpenAI',
            'model'      => $s['model'] ?: 'gpt-4o-mini',
            'message'    => ($enabled && $configured) 
                ? '🟢 Asisten AI siap membantu analisis bisnis dan draf operasional.' 
                : '⚠️ Layanan AI belum dikonfigurasi API Key-nya. Sistem operasional utama tetap berjalan normal.'
        ];
    }

    /**
     * Resolver Endpoint Otomatis Sesuai Provider
     */
    private static function default_endpoint($provider) {
        $p = strtolower(trim((string)$provider));
        if (strpos($p, 'openai') !== false)     return 'https://api.openai.com/v1/chat/completions';
        if (strpos($p, 'openrouter') !== false) return 'https://openrouter.ai/api/v1/chat/completions';
        if (strpos($p, 'deepseek') !== false)   return 'https://api.deepseek.com/chat/completions';
        if (strpos($p, 'groq') !== false)       return 'https://api.groq.com/openai/v1/chat/completions';
        return 'https://api.openai.com/v1/chat/completions';
    }

    /**
     * INJEKSI DATA OPERASIONAL RIIL KE DALAM MEMORI AI (ANTI-HALUSINASI)
     */
    public static function operational_context() {
        global $wpdb;

        // Deteksi tabel-tabel utama PK01
        $tbl = function($k) use ($wpdb) {
            $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
            return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) ? $t : false;
        };

        $t_mat    = $tbl('materials');
        $t_orders = $tbl('sales_orders') ?: $tbl('orders');
        $t_costs  = $tbl('operational_costs');
        $t_jobs   = $tbl('jobs') ?: $tbl('production_jobs');
        $t_ship   = $tbl('shipments');
        $t_seller = $tbl('sales_accounts') ?: $tbl('sellers');
        $t_cash   = $tbl('cash_ledger');
        $t_jm     = $tbl('job_materials');
        $t_jw     = $tbl('job_wages');

        // Nomor dokumen adalah identitas lintas modul: AI selalu melihat invoice/order yang sama, bukan ID database.
        $recent_documents = [];
        if ($t_orders) {
            $recent_documents = $wpdb->get_results("SELECT COALESCE(invoice_no,order_no) AS invoice_no, order_no, customer_name, total_amount, payment_status, status, created_at FROM `{$t_orders}` ORDER BY id DESC LIMIT 12", ARRAY_A) ?: [];
        }

        $cur_month = current_time('Y-m');
        $today     = current_time('Y-m-d');

        // 1. Snapshot Bahan Baku Kritis
        $critical_materials = [];
        if ($t_mat) {
            $critical_materials = $wpdb->get_results(
                "SELECT code, name, stock, min_stock, unit FROM `{$t_mat}` WHERE stock <= min_stock LIMIT 6", 
                ARRAY_A
            ) ?: [];
        }

        // 2. Snapshot Penjualan & Antrean Pesanan
        $sales_month = 0;
        $pending_orders = 0;
        if ($t_orders) {
            $sales_month = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(total_amount) FROM `{$t_orders}` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s AND status NOT IN ('cancelled', 'batal')",
                $cur_month
            ));
            $pending_orders = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM `{$t_orders}` WHERE status IN ('pending', 'processing', 'paid', 'dikemas')"
            );
        }

        // 3. Snapshot Biaya Usaha
        $costs_month = 0;
        if ($t_costs) {
            $costs_month = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(amount) FROM `{$t_costs}` WHERE DATE_FORMAT(cost_date, '%%Y-%%m') = %s",
                $cur_month
            ));
        }

        // 4. Snapshot Job Produksi & Pengiriman
        $active_jobs = 0;
        if ($t_jobs) {
            $active_jobs = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_jobs}` WHERE status NOT IN ('completed', 'selesai', 'cancelled')");
        }

        $active_shipments = 0;
        if ($t_ship) {
            $active_shipments = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_ship}` WHERE status IN ('on_process', 'dikirim')");
        }

        $pending_sellers = 0;
        if ($t_seller) {
            $pending_sellers = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_seller}` WHERE registration_status = 'pending'");
        }

        // 4b. Jejak bahan Job -> pemakaian aktual -> HPP produksi.
        $recent_job_hpp=[];
        if($t_jm && $t_jobs){
            $recent_job_hpp=$wpdb->get_results("SELECT j.job_no, j.id job_id, COALESCE(SUM(jm.used_qty*NULLIF(jm.unit_cost,0)),0) material_hpp, COALESCE(SUM(jm.issued_qty*NULLIF(jm.unit_cost,0)),0) issued_value, COALESCE(SUM(jm.returned_qty*NULLIF(jm.unit_cost,0)),0) returned_value FROM `{$t_jobs}` j LEFT JOIN `{$t_jm}` jm ON jm.job_id=j.id WHERE j.status NOT IN ('cancelled') GROUP BY j.id ORDER BY j.id DESC LIMIT 10", ARRAY_A) ?: [];
        }

        // 5. Snapshot Saldo Kas (Hanya jika user memiliki izin finansial)
        $cash_balance = 0;
        $can_see_finance = current_user_can('manage_options') || 
                           (class_exists('PK01_Authorization') && PK01_Authorization::can('finance'));

        if ($can_see_finance && $t_cash) {
            $cash_balance = (float) $wpdb->get_var("SELECT SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END) FROM `{$t_cash}`");
        }

        // Bangun Struktur Memori Fakta PK01
        $snapshot = [
            'perusahaan' => [
                'nama'    => get_option('pk01_company_name', get_bloginfo('name')),
                'kota'    => get_option('pk01_company_city', 'Jepara'),
                'tanggal' => current_time('d F Y, H:i') . ' WIB'
            ],
            'gudang_material' => [
                'total_kritis' => count($critical_materials),
                'daftar_kritis' => $critical_materials
            ],
            'produksi' => [
                'job_aktif_berjalan' => $active_jobs,
                'jejak_hpp_bahan_job_terbaru' => $recent_job_hpp,
                'aturan_hpp_bahan' => 'HPP bahan dihitung dari bahan yang benar-benar dipakai (used_qty x unit_cost yang disnapshot saat bahan diserahkan). Bahan dikembalikan tidak menjadi HPP. Jika unit_cost legacy kosong, data ditandai estimasi.'
            ],
            'logistik' => [
                'paket_dalam_perjalanan' => $active_shipments
            ],
            'penjualan_dan_seller' => [
                'pesanan_perlu_diproses' => $pending_orders,
                'seller_menunggu_approval' => $pending_sellers,
                'invoice_terbaru' => $recent_documents
            ]
        ];

        // Masukkan data keuangan hanya jika diizinkan
        if ($can_see_finance) {
            $snapshot['keuangan_bulan_ini'] = [
                'omzet_penjualan' => 'Rp ' . number_format($sales_month, 0, ',', '.'),
                'biaya_operasional' => 'Rp ' . number_format($costs_month, 0, ',', '.'),
                'laba_operasional_kotor' => 'Rp ' . number_format($sales_month - $costs_month, 0, ',', '.'),
                'saldo_kas_aktual' => 'Rp ' . number_format($cash_balance, 0, ',', '.')
            ];
        }

        $context_documents = $recent_documents;
        return [
            'peran_ai' => 'Anda adalah Asisten Cerdas Pengendali Operasional (Control Tower) Sistem PK01.',
            'aturan_wajib' => [
                'Gunakan hanya data fakta operasional yang terlampir di bawah ini.',
                'Dilarang mengarang angka, stok, atau saldo yang tidak tercantum.',
                'Bedakan secara tegas antara FAKTA DATABASE dan REKOMENDASI STRATEGIS.',
                'AI tidak memiliki akses langsung untuk mengubah tabel database (read-only).'
            ],
            'fakta_operasional_live' => $snapshot
        ];
    }

    /**
     * Fallback Cerdas Saat Layanan AI Offline
     */
    private static function fallback_answer($q) {
        $ctx = self::operational_context();
        $f = $ctx['fakta_operasional_live'];
        $q_lower = strtolower($q);
        $lines = [];

        $lines[] = "📊 **Ringkasan Operasional Riil PK01 (" . $f['perusahaan']['tanggal'] . "):**\n";

        if (strpos($q_lower, 'stok') !== false || strpos($q_lower, 'bahan') !== false || strpos($q_lower, 'material') !== false) {
            $lines[] = "• **Gudang Material:** Terdapat " . $f['gudang_material']['total_kritis'] . " bahan di batas minimum.";
            foreach ($f['gudang_material']['daftar_kritis'] as $m) {
                $lines[] = "  - " . $m['name'] . " (" . $m['code'] . "): sisa " . $m['stock'] . " " . $m['unit'] . " (Min: " . $m['min_stock'] . ")";
            }
        } elseif (strpos($q_lower, 'omzet') !== false || strpos($q_lower, 'biaya') !== false || strpos($q_lower, 'keuangan') !== false || strpos($q_lower, 'kas') !== false) {
            if (isset($f['keuangan_bulan_ini'])) {
                $lines[] = "• **Omzet Penjualan Bulan Ini:** " . $f['keuangan_bulan_ini']['omzet_penjualan'];
                $lines[] = "• **Biaya Operasional:** " . $f['keuangan_bulan_ini']['biaya_operasional'];
                $lines[] = "• **Laba Operasional:** " . $f['keuangan_bulan_ini']['laba_operasional_kotor'];
                $lines[] = "• **Saldo Kas Aktual:** " . $f['keuangan_bulan_ini']['saldo_kas_aktual'];
            } else {
                $lines[] = "• Informasi keuangan disembunyikan berdasarkan izin hak akses akun Anda.";
            }
        } else {
            $lines[] = "• **Pesanan Perlu Diproses:** " . $f['penjualan_dan_seller']['pesanan_perlu_diproses'] . " transaksi.";
            $lines[] = "• **Job Produksi Aktif:** " . $f['produksi']['job_aktif_berjalan'] . " pekerjaan.";
            $lines[] = "• **Pengiriman Berjalan:** " . $f['logistik']['paket_dalam_perjalanan'] . " paket ekspedisi.";
            $lines[] = "• **Bahan Baku Kritis:** " . $f['gudang_material']['total_kritis'] . " item perlu dipesan ulang.";
        }

        return implode("\n", $lines);
    }

    /**
     * 3. PROSES UTAMA PENGAJUAN PERTANYAAN (CORE ENGINE ASK)
     */
    public static function ask($q, $session = '', $opts = []) {
        $q = sanitize_textarea_field(trim($q));
        if (empty($q)) {
            return ['ok' => false, 'message' => 'Pertanyaan belum diisi.'];
        }

        // Cek Hak Akses User
        if (class_exists('PK01_Authorization') && method_exists('PK01_Authorization', 'can')) {
            if (!PK01_Authorization::can('ai') && !current_user_can('manage_options')) {
                return ['ok' => false, 'message' => 'Anda tidak memiliki hak akses untuk menggunakan Asisten AI.'];
            }
        }

        $status = self::status();
        $ctx    = self::operational_context();

        // FILTER PERINTAH MUTASI DATABASE SECARA LANGSUNG (ANTI-INJECTION/DESTRUCTIVE)
        $destructive_terms = [
            'hapus database', 'drop table', 'truncate', 'delete from', 'format data', 
            'update status menjadi lunas secara paksa', 'reset database'
        ];
        foreach ($destructive_terms as $term) {
            if (strpos(strtolower($q), $term) !== false) {
                return [
                    'ok' => false,
                    'message' => '⚠️ Perintah mutasi langsung ditolak. AI di sistem PK01 beroperasi dalam mode Read-Only / Konsultatif untuk melindungi keamanan basis data transaksi bisnis Anda.'
                ];
            }
        }

        // JIKA API AI BELUM AKTIF / TIDAK ADA INTERNET -> GUNAKAN ENGINE FALLBACK CERDAS
        if (!$status['available']) {
            return [
                'ok' => true,
                'fallback' => true,
                'message' => self::fallback_answer($q),
                'data' => $ctx
            ];
        }

        $s = self::settings();
        $endpoint = esc_url_raw(!empty($s['endpoint']) ? $s['endpoint'] : self::default_endpoint($s['provider']));
        $model    = sanitize_text_field(!empty($s['model']) ? $s['model'] : 'gpt-4o-mini');

        // Rakit Prompt Sistem Enterprise
        $system_instruction = "Anda adalah Asisten Operasional Cerdas untuk sistem ERP & Manufaktur PK01 (" . $ctx['fakta_operasional_live']['perusahaan']['nama'] . ").\n" .
                               "Tugas Anda: Membantu pemilik bisnis dan staf dalam menganalisis kinerja operasional, merancang strategi, draf pesan WhatsApp ke pelanggan/seller, serta rekomendasi efisiensi biaya.\n" .
                               "PANDUAN MENJAWAB:\n" .
                               "1. Rujuk data operasional berikut ini secara akurat: " . wp_json_encode($ctx, JSON_UNESCAPED_UNICODE) . "\n" .
                               "2. Gunakan bahasa Indonesia yang profesional, ramah, dan berorientasi pada solusi praktis.\n" .
                               "3. Jika pengguna meminta draf pesan (misal WhatsApp), berikan format pesan yang siap disalin dan dikirimkan.";

        $payload = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => $system_instruction],
                ['role' => 'user', 'content' => $q]
            ],
            'temperature' => (float)($s['temperature'] ?? 0.2),
            'max_tokens'  => 1200
        ];

        // Headers Khusus
        $headers = [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . trim($s['api_key'])
        ];
        if (strpos($endpoint, 'openrouter') !== false) {
            $headers['HTTP-Referer'] = home_url();
            $headers['X-Title']      = 'PK01 Operational Hub';
        }

        // Eksekusi HTTP Request ke API Provider
        $response = wp_remote_post($endpoint, [
            'timeout'   => 28,
            'sslverify' => false,
            'headers'   => $headers,
            'body'      => wp_json_encode($payload)
        ]);

        if (is_wp_error($response)) {
            self::log($q, 'Koneksi API Error: ' . $response->get_error_message(), 'error');
            return [
                'ok' => true,
                'fallback' => true,
                'message' => "⚠️ Server AI sedang lambat merespons. Berikut ringkasan data internal dari sistem:\n\n" . self::fallback_answer($q),
                'data' => $ctx
            ];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $answer = '';

        if (isset($body['choices'][0]['message']['content'])) {
            $answer = trim((string)$body['choices'][0]['message']['content']);
        } elseif (isset($body['output'][0]['content'][0]['text'])) {
            $answer = trim((string)$body['output'][0]['content'][0]['text']);
        }

        if ($code < 200 || $code >= 300 || empty($answer)) {
            $err_msg = $body['error']['message'] ?? 'API Provider tidak mengembalikan teks jawaban.';
            self::log($q, 'HTTP ' . $code . ': ' . $err_msg, 'error');

            return [
                'ok' => true,
                'fallback' => true,
                'message' => "ℹ️ " . self::fallback_answer($q),
                'data' => $ctx
            ];
        }

        // Catat Log Pertanyaan Sukses
        self::log($q, $answer, 'success');

        return [
            'ok'      => true,
            'message' => $answer,
            'data'    => $ctx
        ];
    }

    /**
     * Catat Jejak Audit Pertanyaan AI ke Database
     */
    private static function log($q, $response, $status) {
        global $wpdb;
        $s = self::settings();
        $tbl_ai_logs = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
            ? PK01_DB::t('ai_logs') 
            : $wpdb->prefix . 'pk01_ai_logs';

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_ai_logs)) === $tbl_ai_logs) {
            $wpdb->insert($tbl_ai_logs, [
                'user_id'    => get_current_user_id(),
                'provider'   => $s['provider'],
                'model'      => $s['model'],
                'action'     => 'ask',
                'prompt'     => $q,
                'response'   => mb_strimwidth($response, 0, 2000, '...'),
                'status'     => $status,
                'created_at' => current_time('mysql')
            ]);
        }
    }

    /**
     * Handler AJAX untuk Tampilan Antarmuka Frontend
     */
    public static function ajax_ask() {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Sesi berakhir. Silakan login kembali.'], 403);
        }

        check_ajax_referer('pk01_ai_ask', 'nonce');

        $question = sanitize_textarea_field($_POST['question'] ?? '');
        $session  = sanitize_key($_POST['session'] ?? '');

        $result = self::ask($question, $session);

        if (!empty($result['ok'])) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    /**
     * Rekomendasi harga AI: AI hanya memilih target markup/range dan memberi alasan.
     * Harga final selalu dihitung Engine dari HPP + fee + biaya tetap.
     */
    public static function price_recommendation($variant_id, $hpp, $channel='direct', $fee_percent=0, $selling_cost_fixed=0) {
        $hpp=max(0,(float)$hpp); $fee_percent=max(0,(float)$fee_percent); $selling_cost_fixed=max(0,(float)$selling_cost_fixed);
        if ($hpp<=0) return ['ok'=>false,'message'=>'HPP harus lebih dari Rp 0.'];
        $settings=self::settings();
        $default_markup=max(0,(float)($settings['default_profit']??30));
        if (empty($settings['ai_enabled'])) {
            $price=class_exists('PK01_Engine')?PK01_Engine::recommended_selling_price($hpp,$default_markup,$fee_percent,$selling_cost_fixed):0;
            return ['ok'=>true,'ai'=>false,'markup_percent'=>$default_markup,'price'=>$price,'message'=>'AI nonaktif. Menggunakan markup manual/default yang tersimpan; harga dihitung Engine.'];
        }
        if (!class_exists('PK01_AI_Orchestrator')) return ['ok'=>false,'message'=>'AI Orchestrator belum tersedia.'];
        $q='Rekomendasikan target markup keuntungan berbasis HPP untuk produk PK01. HPP per unit: Rp '.number_format($hpp,0,',','.').'. Kanal penjualan: '.sanitize_text_field($channel).'. Fee pihak ketiga yang sudah diketahui: '.$fee_percent.'%. Biaya packing/biaya jual tetap per unit: Rp '.number_format($selling_cost_fixed,0,',','.').'. Jangan mengarang tarif fee. Jika fee belum diketahui, katakan perlu diisi. Berikan target_markup_percent yang wajar sebagai angka persen dan alasan singkat. Format JSON satu objek: {"target_markup_percent":angka,"confidence":"low|medium|high","reason":"..."}. Jangan mengubah data.';
        $r=PK01_AI_Orchestrator::ask($q,'pricing');
        if (empty($r['ok'])) return $r;
        $text=(string)($r['message']??''); $obj=null;
        if (preg_match('/\{.*?\}/s',$text,$m)) $obj=json_decode($m[0],true);
        $markup=isset($obj['target_markup_percent'])?(float)$obj['target_markup_percent']:0;
        if ($markup<=0) return ['ok'=>false,'message'=>'AI tidak mengembalikan target markup terstruktur yang dapat diverifikasi.','raw'=>$text];
        $markup=min(500,$markup);
        $price=class_exists('PK01_Engine')?PK01_Engine::recommended_selling_price($hpp,$markup,$fee_percent,$selling_cost_fixed):0;
        return ['ok'=>true,'ai'=>true,'provider'=>$r['provider']??'', 'markup_percent'=>$markup,'confidence'=>$obj['confidence']??'medium','reason'=>$obj['reason']??'','price'=>$price,'message'=>'Rekomendasi AI; harga final dihitung Engine PK01 dari HPP dan biaya kanal.'];
    }

    public static function ajax_price_recommend() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Sesi berakhir.'],403);
        check_ajax_referer('pk01_ai_price_recommend','nonce');
        if (class_exists('PK01_Authorization') && !PK01_Authorization::can_action('pricing','view')) wp_send_json_error(['message'=>'Anda tidak memiliki akses pricing.'],403);
        $r=self::price_recommendation(absint($_POST['variant_id']??0),(float)($_POST['hpp']??0),sanitize_key($_POST['channel']??'direct'),(float)($_POST['fee_percent']??0),(float)($_POST['selling_cost_fixed']??0));
        if (!empty($r['ok'])) wp_send_json_success($r); else wp_send_json_error($r);
    }

    /** AI advisory: explain HPP scale drivers; never writes accounting data. */
    public static function hpp_scale_advice($variant_id, $planned_qty) {
        if (!class_exists('PK01_Engine') || !method_exists('PK01_Engine','estimate_hpp_from_system')) {
            return ['ok'=>false,'message'=>'Engine HPP otomatis belum tersedia.'];
        }
        try {
            $q=(float)$planned_qty;
            $a=PK01_Engine::estimate_hpp_from_system($variant_id,max(1,$q),12);
            return ['ok'=>true,'data'=>$a,'message'=>'Estimasi berbasis data transaksi. AI hanya menjelaskan faktor penggerak biaya; angka final berasal dari Engine HPP.'];
        } catch (Throwable $e) {
            return ['ok'=>false,'message'=>$e->getMessage()];
        }
    }

}

// Inisialisasi Gateway AI PK01
