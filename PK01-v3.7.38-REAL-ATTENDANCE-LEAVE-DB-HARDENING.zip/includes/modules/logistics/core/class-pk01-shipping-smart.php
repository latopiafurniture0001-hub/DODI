<?php
if (!defined('ABSPATH')) exit;

/**
 * Smart Shipping Hub
 * Satu adapter untuk banyak kurir/aggregator.
 * Provider tidak boleh menulis DB secara langsung; hasil dinormalisasi lalu masuk Engine.
 */
class PK01_Shipping_Smart {
    const CRON = 'pk01_tracking_sync';

    public static function init(){
        add_action(self::CRON,[__CLASS__,'sync_all']);
        if (!wp_next_scheduled(self::CRON)) wp_schedule_event(time()+300,'hourly',self::CRON);
        add_action('admin_post_pk01_save_shipping',[__CLASS__,'save_settings']);
    }

    public static function courier_directory(){
        return [
            'jne'=>'JNE','jnt'=>'J&T Express','sicepat'=>'SiCepat','ide'=>'ID Express','sap'=>'SAP Express','ninja'=>'Ninja Xpress','tiki'=>'TIKI','wahana'=>'Wahana','pos'=>'POS Indonesia','lion'=>'Lion Parcel','anteraja'=>'AnterAja','sentral'=>'Sentral Cargo','rex'=>'REX Indonesia','kgx'=>'KGXpress','borzo'=>'Borzo','grab'=>'GrabExpress','gosend'=>'GoSend','lalamove'=>'Lalamove','paxel'=>'Paxel','ncs'=>'NCS','first'=>'First Logistics','rpx'=>'RPX','dakota'=>'Dakota','indah'=>'Indah Cargo','pandu'=>'Pandu Logistics','jet'=>'JET Express','janio'=>'Janio','spx'=>'SPX Express','lex'=>'LEX ID','ninjavan'=>'Ninja Van','idecargo'=>'ID Express Cargo','wahana_cargo'=>'Wahana Cargo','jnt_cargo'=>'J&T Cargo','jne_trucking'=>'JNE Trucking','sicepat_gokil'=>'SiCepat GOKIL','lion_regpacel'=>'Lion RegPack','pos_cargo'=>'Pos Indonesia Cargo','star'=>'STAR Cargo','sap_cargo'=>'SAP Cargo','kamibox'=>'KirimAja/Kamibox','borzo'=>'Borzo','deliveree'=>'Deliveree','paxelbox'=>'Paxel','mr_speedy'=>'MR Speedy'
        ];
    }

    /** Layanan dibuat generik agar operator awam tidak perlu menghafal kode API. */
    public static function service_directory(){
        return [
            'REG'=>'Reguler — pengiriman standar',
            'EXPRESS'=>'Express — lebih cepat',
            'YES'=>'Next/Yes — prioritas',
            'SAME_DAY'=>'Same Day — hari yang sama',
            'INSTANT'=>'Instant — hitungan jam',
            'CARGO'=>'Cargo — barang besar/berat',
            'TRUCKING'=>'Trucking — pengiriman volume besar',
            'ECONOMY'=>'Economy — tarif ekonomis',
            'HEMAT'=>'Hemat — layanan ekonomis',
            'CUSTOM'=>'Layanan lain — isi sendiri'
        ];
    }

    /** URL pelacakan publik. Ini hanya membuka situs pelacak; tidak mengklaim data otomatis masuk PK01. */
    public static function get_direct_tracking_url($courier, $tracking_no){
        $c=self::normalize_courier($courier); $awb=rawurlencode(trim((string)$tracking_no));
        $map=[
            'jne'=>'https://www.jne.co.id/id/tracking/trace',
            'jnt'=>'https://www.jet.co.id/track',
            'sicepat'=>'https://www.sicepat.com/checkAwb',
            'tiki'=>'https://www.tiki.id/id/tracking',
            'pos'=>'https://www.posindonesia.co.id/id/tracking',
            'anteraja'=>'https://anteraja.id/tracking',
            'ninja'=>'https://www.ninjaxpress.co/id-id/tracking',
            'ninjavan'=>'https://www.ninjavan.co/id-id/tracking',
            'wahana'=>'https://www.wahana.com/',
            'ide'=>'https://www.idexpress.com/marking',
            'spx'=>'https://spx.co.id/',
            'lex'=>'https://www.lex.co.id/',
            'lion'=>'https://lionparcel.com/track/stt',
            'paxel'=>'https://paxel.co/id/track',
            'grab'=>'https://www.grab.com/id/',
            'gosend'=>'https://www.gojek.com/gosend/',
            'deliveree'=>'https://www.deliveree.com/id/',
        ];
        if(isset($map[$c])) return add_query_arg(['awb'=>$tracking_no,'waybill'=>$tracking_no,'noresi'=>$tracking_no],$map[$c]);
        return 'https://cekresi.com/?noresi='.$awb;
    }

    public static function courier_info($code){
        $code=self::normalize_courier($code);
        $name=self::courier_directory()[$code]??($code!==''?$code:'Kurir');
        $provider=self::settings()['provider'];
        return ['code'=>$code,'name'=>$name,'provider'=>$provider,'tracking_ready'=>$provider!=='none'];
    }

    public static function normalize_courier($name){
        $raw=strtolower(trim((string)$name));
        $x=preg_replace('/[^a-z0-9]+/','',$raw);
        $map=[
            'jne'=>'jne','jnetrucking'=>'jne_trucking','jnecargo'=>'jne_trucking',
            'jnt'=>'jnt','jtexpress'=>'jnt','j&t'=>'jnt','jntcargo'=>'jnt_cargo','jntcargoexpress'=>'jnt_cargo',
            'sicepat'=>'sicepat','sicepatgokil'=>'sicepat_gokil',
            'ide'=>'ide','idexpress'=>'ide','idexpresscargo'=>'idecargo',
            'sap'=>'sap','sapexpress'=>'sap','sapcargo'=>'sap_cargo',
            'ninja'=>'ninja','ninjaxpress'=>'ninja','ninjavan'=>'ninjavan',
            'tiki'=>'tiki','wahana'=>'wahana','wahanacargo'=>'wahana_cargo',
            'pos'=>'pos','posindonesia'=>'pos','posindonesiacargo'=>'pos_cargo','poscargo'=>'pos_cargo',
            'lion'=>'lion','lionparcel'=>'lion','lionregpack'=>'lion_regpacel',
            'anteraja'=>'anteraja','anterajaexpress'=>'anteraja',
            'sentral'=>'sentral','sentralcargo'=>'sentral','rex'=>'rex','rexindonesia'=>'rex',
            'kgx'=>'kgx','kgxpress'=>'kgx','borzo'=>'borzo','grab'=>'grab','grabexpress'=>'grab','gosend'=>'gosend',
            'lalamove'=>'lalamove','paxel'=>'paxel','paxelbox'=>'paxelbox','ncs'=>'ncs','first'=>'first','firstlogistics'=>'first',
            'rpx'=>'rpx','rpxholding'=>'rpx','dakota'=>'dakota','dakotacargo'=>'dakota','indah'=>'indah','indahcargo'=>'indah',
            'pandu'=>'pandu','pandulogistics'=>'pandu','jet'=>'jet','jetexpress'=>'jet','janio'=>'janio','spx'=>'spx','spxexpress'=>'spx','shopeeexpress'=>'spx',
            'lex'=>'lex','lexid'=>'lex','shopee'=>'spx','star'=>'star','starcargo'=>'star','kamibox'=>'kamibox','kirimaja'=>'kamibox',
            'deliveree'=>'deliveree','mrspeedy'=>'mr_speedy'
        ];
        return $map[$x]??$x;
    }

    public static function settings(){
        if (class_exists('PK01_Settings')) return PK01_Settings::shipping();
        $s=get_option('pk01_shipping_settings',[]);
        $s=is_array($s)?$s:[];
        $defaults=[
            'provider'=>'none','api_key'=>'','base_url'=>'','webhook_secret'=>'','polling'=>'hourly','enabled'=>false,
            'biteship_base'=>'https://api.biteship.com','raja_base'=>'https://rajaongkir.komerce.id/api/v1','courier_routes'=>[],'default_service'=>'REG','auto_sync_minutes'=>60,
            'origin_city'=>'','cache_hours'=>3,'active_couriers'=>[],
            'api_keys'=>[],'provider_enabled'=>[],'webhook_enabled'=>false
        ];
        $out=wp_parse_args($s,$defaults);
        // Backward compatibility: migrate legacy single-key settings into provider map.
        if(empty($out['api_keys']) && !empty($out['api_key']) && !empty($out['provider'])) $out['api_keys']=[sanitize_key($out['provider'])=>(string)$out['api_key']];
        if(empty($out['provider_enabled']) && !empty($out['provider']) && $out['provider']!=='none') $out['provider_enabled']=[sanitize_key($out['provider'])=>true];
        return $out;
    }

    public static function providers(){
        return [
            'none'=>'Belum terhubung',
            'biteship'=>'Biteship — Multi Kurir',
            'rajaongkir'=>'RajaOngkir/Komerce — Tracking',
            'custom'=>'Provider Custom / API Internal'
        ];
    }

    public static function save_settings(){
        if(!current_user_can('manage_options')) wp_die('Akses ditolak.');
        check_admin_referer('pk01_shipping_save');
        $old=self::settings();
        $provider=sanitize_key(wp_unslash($_POST['provider']??'none'));
        $api_keys=is_array($_POST['api_keys']??null)?wp_unslash($_POST['api_keys']):[];
        $clean_keys=[]; foreach($api_keys as $k=>$v){ $k=sanitize_key($k); $v=trim((string)$v); if($k!=='' && $v!=='') $clean_keys[$k]=$v; }
        // Keep existing secret when the password field is left blank.
        if(empty($clean_keys[$provider]) && !empty($old['api_keys'][$provider])) $clean_keys[$provider]=$old['api_keys'][$provider];
        $new=[
            'provider'=>$provider,
            'api_key'=>(string)($clean_keys[$provider]??''),
            'api_keys'=>$clean_keys,
            'provider_enabled'=>is_array($_POST['provider_enabled']??null)?array_fill_keys(array_map('sanitize_key',wp_unslash($_POST['provider_enabled'])),true):[],
            'base_url'=>esc_url_raw(trim((string)wp_unslash($_POST['base_url']??''))),
            'webhook_secret'=>sanitize_text_field(wp_unslash($_POST['webhook_secret']??'')),
            'webhook_enabled'=>!empty($_POST['webhook_enabled']),
            'polling'=>sanitize_key(wp_unslash($_POST['polling']??'hourly')),
            'enabled'=>!empty($_POST['enabled']),
            'default_service'=>sanitize_key(wp_unslash($_POST['default_service']??'REG')),
            'auto_sync_minutes'=>max(15,(int)($_POST['auto_sync_minutes']??60)),
            'courier_routes'=>is_array($_POST['courier_routes']??null)?array_map('sanitize_key',wp_unslash($_POST['courier_routes'])):[],
            'biteship_base'=>esc_url_raw(trim((string)wp_unslash($_POST['biteship_base']??'https://api.biteship.com'))),
            'raja_base'=>esc_url_raw(trim((string)wp_unslash($_POST['raja_base']??'https://rajaongkir.komerce.id/api/v1'))),
            'origin_city'=>sanitize_text_field(wp_unslash($_POST['origin_city']??'')),
            'cache_hours'=>max(1,(int)($_POST['cache_hours']??3)),
            'active_couriers'=>is_array($_POST['active_couriers']??null)?array_map('sanitize_key',wp_unslash($_POST['active_couriers'])):[],
        ];
        update_option('pk01_shipping_settings',$new,false);
        if (class_exists('PK01_Settings')) PK01_Settings::update_group('integration',array('shipping'=>$new));
        PK01_Engine::log('shipping_settings_updated','shipping','settings',0,$old,['provider'=>$new['provider'],'enabled'=>$new['enabled'],'api_providers'=>array_keys($clean_keys)]);
        wp_safe_redirect(add_query_arg(['pk01_view'=>'settings','shipping_saved'=>'1'],PK01_DB::page_url())); exit;
    }

    public static function webhook($request){
        $s=self::settings();
        $secret=(string)$s['webhook_secret'];
        if($secret!=='' && !hash_equals($secret,(string)$request->get_header('x-pk01-webhook-secret'))){
            return new WP_Error('invalid_signature','Webhook signature tidak valid',['status'=>401]);
        }
        $body=$request->get_json_params();
        if(!is_array($body)) return new WP_Error('invalid_payload','Payload harus JSON object',['status'=>400]);
        $result=self::normalize_webhook($body);
        if(!$result['tracking_no']) return new WP_Error('missing_tracking','Nomor resi tidak ditemukan',['status'=>422]);
        try{
            $id=self::apply_tracking($result,'webhook');
            return rest_ensure_response(['ok'=>true,'shipment_id'=>$id,'status'=>$result['status']]);
        }catch(Throwable $e){ return new WP_Error('tracking_error',$e->getMessage(),['status'=>422]); }
    }

    private static function normalize_webhook($b){
        $tracking=$b['tracking_no']??$b['waybill_id']??$b['courier']['waybill_id']??$b['waybill']??'';
        $status=$b['status']??$b['order_status']??$b['tracking_status']??'';
        $courier=$b['courier']??$b['courier_code']??$b['courier']['company']??'';
        if(is_array($courier)) $courier=$courier['code']??$courier['name']??'';
        $desc=$b['description']??$b['note']??$b['message']??'';
        $loc=$b['location']??$b['current_location']??'';
        $time=$b['event_time']??$b['updated_at']??$b['created_at']??current_time('mysql');
        return ['tracking_no'=>sanitize_text_field($tracking),'status'=>self::map_status($status),'event_code'=>sanitize_text_field((string)$status),'description'=>sanitize_text_field((string)$desc),'location'=>sanitize_text_field((string)$loc),'event_time'=>self::normalize_time($time),'courier'=>sanitize_text_field((string)$courier),'raw'=>$b];
    }

    private static function normalize_time($v){
        $v=sanitize_text_field((string)$v); if(!$v)return current_time('mysql');
        $ts=strtotime($v); return $ts?wp_date('Y-m-d H:i:s',$ts):current_time('mysql');
    }

    public static function status_labels(){
        return [
            'label_created'=>'Resi dibuat','picked_up'=>'Sudah diambil kurir','in_transit'=>'Dalam perjalanan','arrived'=>'Tiba di hub','out_for_delivery'=>'Sedang diantar','delivered'=>'Diterima','delivery_failed'=>'Pengiriman gagal','return_to_sender'=>'Dalam proses kembali','returned'=>'Sudah kembali'
        ];
    }
    public static function status_label($status){ return self::status_labels()[$status]??ucwords(str_replace('_',' ',(string)$status)); }

    public static function map_status($raw){
        $s=strtolower(trim((string)$raw));
        $map=[
            'label_created'=>'label_created','created'=>'label_created','pending'=>'label_created','confirmed'=>'label_created','order_received'=>'label_created','processing'=>'label_created','processed'=>'label_created','packed'=>'label_created','ready_to_ship'=>'label_created',
            'picked_up'=>'picked_up','picked'=>'picked_up','picked-up'=>'picked_up','allocated'=>'picked_up','picking_up'=>'picked_up','handed_to_courier'=>'picked_up','picked by courier'=>'picked_up',
            'in_transit'=>'in_transit','in transit'=>'in_transit','on_hold'=>'in_transit','dropping_off'=>'in_transit','shipped'=>'in_transit','manifested'=>'in_transit','departed'=>'in_transit',
            'arrived'=>'arrived','arrived_at_sorting_center'=>'arrived','arrived_at_hub'=>'arrived','received_at_warehouse'=>'arrived','at_sorting_center'=>'arrived',
            'out_for_delivery'=>'out_for_delivery','outfordelivery'=>'out_for_delivery','delivery'=>'out_for_delivery','delivering'=>'out_for_delivery','courier_on_the_way'=>'out_for_delivery',
            'delivered'=>'delivered','success'=>'delivered','completed'=>'delivered',
            'delivery_failed'=>'delivery_failed','failed'=>'delivery_failed','failed_delivery'=>'delivery_failed','cancelled'=>'delivery_failed','canceled'=>'delivery_failed',
            'return_to_sender'=>'return_to_sender','return'=>'return_to_sender','returned_to_sender'=>'return_to_sender','rts'=>'return_to_sender','returning'=>'return_to_sender',
            'returned'=>'returned','return_received'=>'returned','received_return'=>'returned'
        ]; return $map[$s]??'in_transit';
    }

    public static function apply_tracking_for_ui($e,$source='api'){ return self::apply_tracking($e,$source); }

    private static function apply_tracking($e,$source='api'){
        global $wpdb;
        $tracking=$e['tracking_no'];
        $id=(int)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.PK01_DB::t('shipments').' WHERE tracking_no=%s',$tracking));
        if(!$id) return 0;
        $shipment=PK01_Engine::shipment_tracking($id); if(!$shipment) return 0;
        if(!empty($e['courier']) && empty($shipment['courier'])) $wpdb->update(PK01_DB::t('shipments'),['courier'=>$e['courier'],'updated_at'=>current_time('mysql')],['id'=>$id]);
        $last=!empty($shipment['events'][0])?$shipment['events'][0]:null;
        $finger=md5($tracking.'|'.$e['status'].'|'.$e['event_time'].'|'.$e['description'].'|'.$e['location']);
        $duplicate=(bool)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.PK01_DB::t('tracking_events').' WHERE shipment_id=%d AND MD5(CONCAT(shipment_id,"|",status,"|",event_time,"|",COALESCE(description,""),"|",COALESCE(location,"")))=%s LIMIT 1',$id,$finger));
        if(!$duplicate) PK01_Engine::add_tracking_event($id,$e['status'],$e['event_code'],$e['description'],$e['location'],$e['event_time'],$source,$e['raw']);
        self::create_alerts($id,$e['status'],$e['description'],$e['event_time']);
        return $id;
    }

    private static function create_alerts($shipment_id,$status,$desc,$event_time){
        global $wpdb; $t=PK01_DB::t('shipment_alerts'); if(!$t)return;
        $types=[];
        if(in_array($status,['delivery_failed','return_to_sender','returned'],true)) $types[]='return_risk';
        if($status==='delivered') $types[]='delivered';
        foreach($types as $type){
            $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE shipment_id=%d AND alert_type=%s AND event_time=%s",$shipment_id,$type,$event_time));
            if(!$exists){
                $severity=$type==='return_risk'?'high':'info';
                $wpdb->insert($t,['shipment_id'=>$shipment_id,'alert_type'=>$type,'severity'=>$severity,'message'=>sanitize_text_field($desc?:($type==='return_risk'?'Pengiriman berpotensi kembali.':'Barang tercatat diterima.')),'event_time'=>$event_time,'status'=>'open','created_at'=>current_time('mysql')]);
            }
        }
    }

    /** Verify AWB against configured API without fabricating a status. */
    public static function verify_shipment($shipment_id){
        global $wpdb;
        $id=absint($shipment_id); if($id<=0) return ['verified'=>false,'message'=>'Shipment tidak valid.'];
        $t=PK01_DB::t('shipments');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$id),ARRAY_A);
        if(!$row) return ['verified'=>false,'message'=>'Shipment tidak ditemukan.'];
        $route='';
        try {
            $s=self::settings(); $courier=self::normalize_courier($row['courier']);
            $route=!empty($s['courier_routes'][$courier])?sanitize_key($s['courier_routes'][$courier]):sanitize_key($s['provider']??'none');
            if($route===''||$route==='none') throw new Exception('Provider API belum dikonfigurasi untuk kurir ini.');
            $event=self::track_one($row);
            if(!$event) throw new Exception('Resi belum ditemukan oleh provider. Label baru bisa belum terindeks.');
            self::apply_tracking($event,'api');
            $wpdb->update($t,['tracking_verified'=>'verified','tracking_provider'=>$route,'tracking_verified_at'=>current_time('mysql'),'tracking_verification_note'=>'Resi ditemukan provider API dan event tracking disinkronkan.'],['id'=>$id]);
            return ['verified'=>true,'provider'=>$route,'status'=>$event['status']??'in_transit'];
        } catch(Throwable $e) {
            $wpdb->update($t,['tracking_verified'=>'unverified','tracking_provider'=>$route,'tracking_verification_note'=>sanitize_text_field($e->getMessage())],['id'=>$id]);
            PK01_Engine::log('tracking_verification_pending','shipping','shipment',(string)$id,null,['message'=>$e->getMessage(),'tracking_no'=>$row['tracking_no'],'courier'=>$row['courier']],'Verifikasi resi ditunda; status kurir tidak dikarang');
            return ['verified'=>false,'provider'=>$route,'message'=>$e->getMessage()];
        }
    }

    public static function sync_tracking_no($tracking_no){
        global $wpdb; $tracking_no=sanitize_text_field($tracking_no); if($tracking_no==='')return null;
        $row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PK01_DB::t('shipments').' WHERE tracking_no=%s',$tracking_no),ARRAY_A); if(!$row)return null;
        try{$e=self::track_one($row); if($e){self::apply_tracking($e,'api');} }catch(Throwable $e){PK01_Engine::log('tracking_single_error','shipping','shipment',(int)$row['id'],null,['message'=>$e->getMessage()]);}
        return PK01_Engine::shipment_tracking((int)$row['id']);
    }

    public static function sync_all(){
        $s=self::settings();
        $has_routes=!empty(array_filter((array)($s['courier_routes']??[])));
        $has_keys=!empty((array)($s['api_keys']??[])) || !empty($s['api_key']);
        if(empty($s['enabled']) || (!$has_routes && !$has_keys && ($s['provider']??'none')==='none')) return ['checked'=>0,'updated'=>0,'errors'=>0,'skipped'=>true];
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM ".PK01_DB::t('shipments')." WHERE status NOT IN ('delivered','returned') ORDER BY last_event_at ASC LIMIT 100",ARRAY_A)?:[];
        $out=['checked'=>0,'updated'=>0,'errors'=>0];
        foreach($rows as $row){$out['checked']++;try{$r=self::track_one($row);if($r){self::apply_tracking($r,'api');$out['updated']++;}}catch(Throwable $e){$out['errors']++;PK01_Engine::log('tracking_sync_error','shipping','shipment',(int)$row['id'],null,['message'=>$e->getMessage(),'provider'=>$s['provider']]);}}
        update_option('pk01_tracking_last_sync',['at'=>current_time('mysql'),'result'=>$out],false); return $out;
    }

    public static function track_one($row){
        $s=self::settings();
        $courier=self::normalize_courier($row['courier']);
        $route=!empty($s['courier_routes'][$courier])?sanitize_key($s['courier_routes'][$courier]):sanitize_key($s['provider']);
        $keys=(array)($s['api_keys']??[]);
        if(empty($s['api_key']) && !empty($keys[$route])) $s['api_key']=$keys[$route];
        if($route==='biteship') return self::track_biteship($row,$s);
        if($route==='rajaongkir') return self::track_rajaongkir($row,$s);
        if($route==='binderbyte') return self::track_binderbyte($row,$s);
        if($route==='custom') return self::track_custom($row,$s);
        return null;
    }

    private static function track_binderbyte($row,$s){
        if(empty($s['api_key'])) throw new Exception('API Key Binderbyte belum diatur.');
        $url=add_query_arg(['api_key'=>$s['api_key'],'courier'=>self::normalize_courier($row['courier']),'awb'=>$row['tracking_no']], 'https://api.binderbyte.com/v1/track');
        $r=wp_remote_get($url,['timeout'=>20,'sslverify'=>true]);
        if(is_wp_error($r)) throw new Exception($r->get_error_message());
        $code=wp_remote_retrieve_response_code($r); $body=json_decode(wp_remote_retrieve_body($r),true);
        if($code<200||$code>=300||!is_array($body)||((int)($body['status']??0)!==200)) throw new Exception('Tracking Binderbyte gagal (HTTP '.$code.').');
        $d=$body['data']??[]; $history=$d['history']??[]; if(!$history && isset($d['summary'])) $history=[['status'=>$d['summary']['status']??'in_transit','date'=>$d['summary']['date']??current_time('mysql'),'desc'=>'','location'=>'']];
        if(!$history) return null; $last=end($history);
        return self::normalize_webhook(['tracking_no'=>$row['tracking_no'],'status'=>$last['status']??($d['summary']['status']??'in_transit'),'description'=>$last['desc']??$last['description']??'','location'=>$last['location']??'','updated_at'=>$last['date']??current_time('mysql'),'courier'=>$row['courier']]);
    }

    private static function track_biteship($row,$s){
        if(empty($s['api_key'])) throw new Exception('API Key Biteship belum diatur.');
        $courier=self::normalize_courier($row['courier']);
        if($courier==='') throw new Exception('Kode kurir belum tersedia pada resi.');
        $url=rtrim($s['biteship_base'],'/').'/v1/trackings/'.rawurlencode($row['tracking_no']).'/couriers/'.rawurlencode($courier);
        $r=wp_remote_get($url,['timeout'=>20,'headers'=>['Authorization'=>$s['api_key'],'Content-Type'=>'application/json']]);
        if(is_wp_error($r))throw new Exception($r->get_error_message()); $code=wp_remote_retrieve_response_code($r); $body=json_decode(wp_remote_retrieve_body($r),true);
        if($code<200||$code>=300||!is_array($body))throw new Exception('Tracking Biteship gagal (HTTP '.$code.').');
        $data=$body['data']??$body; $history=$data['history']??$data['tracking_history']??[];
        if(!$history && isset($data['status']))$history=[['status'=>$data['status'],'updated_at'=>$data['updated_at']??current_time('mysql'),'note'=>$data['note']??'']];
        if(!$history)return null; $last=end($history);
        return self::normalize_webhook(['tracking_no'=>$row['tracking_no'],'status'=>$last['status']??'in_transit','description'=>$last['note']??$last['description']??'','location'=>$last['location']??'','updated_at'=>$last['updated_at']??current_time('mysql'),'courier'=>$row['courier'],'provider'=>'biteship']);
    }

    private static function track_rajaongkir($row,$s){
        if(empty($s['api_key'])) throw new Exception('API Key RajaOngkir/Komerce belum diatur.');
        $courier=self::normalize_courier($row['courier']); if($courier==='')throw new Exception('Kode kurir belum tersedia pada resi.');
        $url=rtrim($s['raja_base'],'/').'/track/waybill?awb='.rawurlencode($row['tracking_no']).'&courier='.rawurlencode($courier);
        $r=wp_remote_post($url,['timeout'=>20,'headers'=>['key'=>$s['api_key'],'Content-Type'=>'application/x-www-form-urlencoded'],'body'=>['awb'=>$row['tracking_no'],'courier'=>$courier]]);
        if(is_wp_error($r))throw new Exception($r->get_error_message()); $code=wp_remote_retrieve_response_code($r); $body=json_decode(wp_remote_retrieve_body($r),true);
        if($code<200||$code>=300||!is_array($body))throw new Exception('Tracking RajaOngkir gagal (HTTP '.$code.').');
        $d=$body['data']??$body['rajaongkir']['result']??$body; $history=$d['manifest']??$d['history']??[]; if(!$history && isset($d['status']))$history=[['status'=>$d['status'],'manifest_description'=>$d['description']??'','manifest_date'=>$d['updated_at']??current_time('mysql')]]; if(!$history)return null; $last=end($history);
        return self::normalize_webhook(['tracking_no'=>$row['tracking_no'],'status'=>$last['manifest_description']??$last['status']??'in_transit','description'=>$last['manifest_description']??$last['description']??'','location'=>$last['city_name']??$last['location']??'','updated_at'=>($last['manifest_date']??$last['updated_at']??current_time('mysql')),'courier'=>$row['courier'],'provider'=>'rajaongkir']);
    }

    private static function track_custom($row,$s){
        if(empty($s['api_key'])||empty($s['base_url']))throw new Exception('Provider custom membutuhkan Base URL dan API Key.');
        $url=add_query_arg(['tracking_no'=>$row['tracking_no'],'courier'=>$row['courier']],$s['base_url']);
        $r=wp_remote_get($url,['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$s['api_key'],'X-API-Key'=>$s['api_key'],'Content-Type'=>'application/json']]);
        if(is_wp_error($r))throw new Exception($r->get_error_message()); $code=wp_remote_retrieve_response_code($r); $body=json_decode(wp_remote_retrieve_body($r),true); if($code<200||$code>=300||!is_array($body))throw new Exception('Provider custom gagal (HTTP '.$code.').');
        return self::normalize_webhook($body);
    }
}

// Compatibility facade: legacy templates use PK01_Shipping_Engine while the
// canonical service is PK01_Shipping_Smart. Keep one implementation only.
if (!class_exists('PK01_Shipping_Engine')) {
    class PK01_Shipping_Engine {
        public static function get_settings() { return PK01_Shipping_Smart::settings(); }
        public static function track($courier, $waybill) { return PK01_Shipping_Smart::track_one(['courier'=>$courier,'tracking_no'=>$waybill]); }
    }
}
