<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$track_data = null;
$searched_waybill = '';

// 1. HELPER TABEL PENGIRIMAN
$tbl_shipments = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('shipments') 
    : $wpdb->prefix . 'pk01_shipments';

// 2. PROSES PELACAKAN RESI
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_public_track'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_track_nonce'] ?? ''));
    
    // Verifikasi keamanan dasar
    if (!wp_verify_nonce($nonce, 'pk01_public_track_action')) {
        $notice = '<div class="pk01-track-alert alert-error">Sesi pencarian telah berakhir. Silakan muat ulang halaman.</div>';
    } else {
        $searched_waybill = strtoupper(sanitize_text_field(trim($_POST['track_waybill'] ?? '')));
        $courier_input    = strtolower(sanitize_key($_POST['track_courier'] ?? 'auto'));

        if (empty($searched_waybill)) {
            $notice = '<div class="pk01-track-alert alert-error">Silakan masukkan nomor resi pengiriman Anda.</div>';
        } else {
            // A. CEK DATABASE TOKO TERLEBIH DAHULU
            $db_shipment = null;
            if ($tbl_shipments && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_shipments)) === $tbl_shipments) {
                $db_shipment = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM `{$tbl_shipments}` WHERE UPPER(tracking_no) = %s LIMIT 1",
                    $searched_waybill
                ), ARRAY_A);
            }

            // Tentukan Kurir (Otomatis dari DB atau Pilihan Pengguna)
            $resolved_courier = '';
            if ($courier_input !== 'auto') {
                $resolved_courier = $courier_input;
            } elseif ($db_shipment && !empty($db_shipment['courier'])) {
                $resolved_courier = strtolower($db_shipment['courier']);
            }

            // B. LACAK VIA API GATEWAY EKSPEDISI RESMI JIKA TERSEDIA
            $api_success = false;
            if (class_exists('PK01_Shipping_Engine') && !empty($resolved_courier) && !in_array($resolved_courier, ['internal', 'toko', 'kargo_toko'])) {
                $api_res = PK01_Shipping_Engine::track($resolved_courier, $searched_waybill);
                if (!empty($api_res['success'])) {
                    $track_data = $api_res;
                    $api_success = true;

                    // Sinkronkan status baru ke database toko jika ada
                    if ($db_shipment && $tbl_shipments) {
                        $new_db_status = ($api_res['status'] === 'DELIVERED') ? 'delivered' : 'on_process';
                        $wpdb->update($tbl_shipments, [
                            'status'        => $new_db_status,
                            'last_event_at' => current_time('mysql'),
                        ], ['id' => $db_shipment['id']]);
                    }
                }
            }

            // C. PENANGANAN UNTUK KARGO / PENGIRIMAN INTERNAL / JIKA API GATEWAY BELUM UPDATE
            if (!$api_success) {
                if ($db_shipment) {
                    // Resi ada di database toko (Kargo Internal / Ekspedisi Truk)
                    $st_label = ($db_shipment['status'] === 'delivered') ? 'Paket Diterima' : 'Dalam Pengiriman';
                    $track_data = [
                        'success'      => true,
                        'provider'     => 'Logistik Internal',
                        'courier'      => strtoupper($db_shipment['courier'] ?: 'Armada Pabrik'),
                        'waybill'      => $db_shipment['tracking_no'],
                        'status'       => ($db_shipment['status'] === 'delivered') ? 'DELIVERED' : 'ON_PROCESS',
                        'status_label' => $st_label,
                        'shipper'      => get_bloginfo('name'),
                        'origin'       => get_option('pk01_company_city', 'Workshop Jepara'),
                        'receiver'     => $db_shipment['recipient_name'] ?: 'Pelanggan Terdaftar',
                        'destination'  => $db_shipment['destination'] ?: 'Tujuan Pengiriman',
                        'last_update'  => $db_shipment['last_event_at'] ?: $db_shipment['created_at'],
                        'history'      => [
                            [
                                'date'     => date('d M Y H:i', strtotime($db_shipment['created_at'])),
                                'desc'     => 'Barang telah dikemas dan diserahkan ke pihak ekspedisi/supir armada.',
                                'location' => 'Gudang Workshop'
                            ]
                        ]
                    ];
                } else {
                    $notice = '<div class="pk01-track-alert alert-error">Nomor resi <b>' . esc_html($searched_waybill) . '</b> belum terdaftar di sistem. Pastikan nomor resi dan kurir yang dipilih sudah benar.</div>';
                }
            }
        }
    }
}

// Nomor WhatsApp Admin Toko untuk Bantuan
$cs_wa = get_option('pk01_company_whatsapp', '6281234567890');
$cs_wa = preg_replace('/[^0-9]/', '', (string)$cs_wa);
if (strpos($cs_wa, '0') === 0) {
    $cs_wa = '62' . substr($cs_wa, 1);
}
?>

<div class="pk01-public-tracking-wrap">
    <!-- HERO HEADER -->
    <div class="pk01-track-hero">
        <span class="pk01-track-badge">REAL-TIME TRACKING ENGINE</span>
        <h1 style="margin:8px 0 6px 0; font-size:28px; font-weight:800; color:#0f172a;">Lacak Pengiriman Pesanan</h1>
        <p style="margin:0; color:#64748b; font-size:14px;">
            Pantau posisi barang pesanan furnitur & interior Anda secara langsung dari gateway ekspedisi dan armada pengiriman.
        </p>
    </div>

    <?php echo $notice; ?>

    <!-- FORM PENCARIAN RESI NYATA -->
    <div class="pk01-track-card">
        <form method="post" action="" style="display:flex; flex-direction:column; gap:14px;">
            <?php echo wp_nonce_field('pk01_public_track_action', 'pk01_track_nonce', true, false); ?>
            
            <div style="display:grid; grid-template-columns: 2fr 1.2fr auto; gap:10px;">
                <!-- INPUT NOMOR RESI -->
                <input type="text" name="track_waybill" value="<?php echo esc_attr($searched_waybill); ?>" placeholder="Masukkan nomor resi (cth: JP1234567890 / SPK-001)" required class="pk01-track-input" style="text-transform:uppercase; font-family:monospace; font-weight:700;">
                
                <!-- SELECT KURIR / KARGO -->
                <select name="track_courier" class="pk01-track-select">
                    <option value="auto">🔍 Otomatis Deteksi Kurir</option>
                    <optgroup label="Kurir Reguler">
                        <option value="jne">JNE Express</option>
                        <option value="jnt">J&T Express</option>
                        <option value="sicepat">SiCepat Ekspres</option>
                        <option value="pos">POS Indonesia</option>
                        <option value="anteraja">Anteraja</option>
                        <option value="lion">Lion Parcel</option>
                        <option value="ninja">Ninja Xpress</option>
                        <option value="tiki">TIKI</option>
                        <option value="wahana">Wahana</option>
                        <option value="ide">ID Express</option>
                    </optgroup>
                    <optgroup label="Kargo / Mebel / Truk">
                        <option value="jnt_cargo">J&T Cargo</option>
                        <option value="sentral_cargo">Sentral Cargo</option>
                        <option value="dakota">Dakota Cargo</option>
                        <option value="internal">Armada Pengiriman Toko / Pabrik</option>
                    </optgroup>
                </select>

                <!-- TOMBOL SUBMIT -->
                <button type="submit" name="pk01_public_track" value="1" class="pk01-track-button">
                    Lacak Resi
                </button>
            </div>
            
            <div style="font-size:12px; color:#64748b;">
                💡 <i>Mendukung resi kurir reguler (J&T, JNE, SiCepat, dll.) serta pengiriman Kargo / Armada Truk Workshop.</i>
            </div>
        </form>
    </div>

    <!-- HASIL STATUS PELACAKAN NYATA -->
    <?php if ($track_data): 
        $is_delivered = ($track_data['status'] === 'DELIVERED');
        $status_bg = $is_delivered ? '#dcfce7' : '#e0e7ff';
        $status_fg = $is_delivered ? '#15803d' : '#3730a3';
        
        $wa_ask_url = "https://api.whatsapp.com/send?phone={$cs_wa}&text=" . rawurlencode("Halo Admin, saya ingin menanyakan progres pengiriman untuk nomor resi *" . $track_data['waybill'] . "* (" . $track_data['courier'] . ").");
    ?>
    <div class="pk01-track-card" style="margin-top:20px;">
        <!-- KEPALA HASIL -->
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; border-bottom:1px solid #e2e8f0; padding-bottom:16px;">
            <div>
                <span style="font-size:12px; font-weight:700; color:#64748b; text-transform:uppercase;">Ekspedisi Pengiriman</span>
                <div style="font-size:20px; font-weight:800; color:#0f172a; margin-top:2px;">
                    <?php echo esc_html($track_data['courier']); ?> 
                    <span style="font-family:monospace; color:#2563eb; font-size:16px;">#<?php echo esc_html($track_data['waybill']); ?></span>
                </div>
            </div>
            <div>
                <span style="display:inline-block; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:700; background:<?php echo esc_attr($status_bg); ?>; color:<?php echo esc_attr($status_fg); ?>;">
                    <?php echo esc_html($track_data['status_label']); ?>
                </span>
            </div>
        </div>

        <!-- VISUAL STEPPER LOGISTIK -->
        <div class="pk01-stepper-wrap">
            <div class="pk01-step is-done">
                <div class="pk01-step-circle">1</div>
                <div class="pk01-step-text">Pesanan Dikemas</div>
            </div>
            <div class="pk01-step is-done">
                <div class="pk01-step-circle">2</div>
                <div class="pk01-step-text">Diserahkan ke Kurir</div>
            </div>
            <div class="pk01-step <?php echo !$is_delivered ? 'is-active' : 'is-done'; ?>">
                <div class="pk01-step-circle">3</div>
                <div class="pk01-step-text">Dalam Perjalanan</div>
            </div>
            <div class="pk01-step <?php echo $is_delivered ? 'is-done' : ''; ?>">
                <div class="pk01-step-circle">4</div>
                <div class="pk01-step-text">Paket Diterima</div>
            </div>
        </div>

        <!-- INFO RUTE & PENERIMA -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:12px; background:#f8fafc; padding:16px; border-radius:8px; border:1px solid #e2e8f0; margin-bottom:24px; font-size:13px;">
            <div>
                <span style="color:#64748b; font-size:11px; font-weight:700; text-transform:uppercase;">Pengirim (Asal)</span>
                <div style="font-weight:700; color:#0f172a; margin-top:2px;"><?php echo esc_html($track_data['shipper'] ?: 'Workshop'); ?></div>
                <div style="color:#64748b;"><?php echo esc_html($track_data['origin'] ?: '-'); ?></div>
            </div>
            <div>
                <span style="color:#64748b; font-size:11px; font-weight:700; text-transform:uppercase;">Penerima (Tujuan)</span>
                <div style="font-weight:700; color:#0f172a; margin-top:2px;"><?php echo esc_html($track_data['receiver'] ?: 'Pelanggan'); ?></div>
                <div style="color:#64748b;"><?php echo esc_html($track_data['destination'] ?: '-'); ?></div>
            </div>
            <div>
                <span style="color:#64748b; font-size:11px; font-weight:700; text-transform:uppercase;">Waktu Pembaruan Terakhir</span>
                <div style="font-weight:700; color:#0f172a; margin-top:2px;">
                    <?php echo esc_html(!empty($track_data['last_update']) ? date('d M Y, H:i', strtotime($track_data['last_update'])) : 'Baru Dikirim'); ?>
                </div>
            </div>
        </div>

        <!-- TIMELINE RIWAYAT PERJALANAN PAKET (MILESTONES) -->
        <h3 style="margin:0 0 16px 0; font-size:15px; color:#0f172a;">📍 Riwayat Perjalanan Paket</h3>
        
        <div class="pk01-timeline">
            <?php if (!empty($track_data['history'])): ?>
                <?php foreach ($track_data['history'] as $idx => $h): ?>
                    <div class="pk01-timeline-item <?php echo ($idx === 0) ? 'is-latest' : ''; ?>">
                        <div class="pk01-timeline-point"></div>
                        <div class="pk01-timeline-time">
                            <?php echo esc_html($h['date']); ?> <?php echo !empty($h['location']) ? '• ' . esc_html($h['location']) : ''; ?>
                        </div>
                        <div class="pk01-timeline-desc">
                            <?php echo esc_html($h['desc']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="color:#94a3b8; font-size:13px; padding-left:20px;">
                    Resi baru diterbitkan. Informasi transit akan diperbarui otomatis oleh sistem kurir dalam beberapa saat.
                </div>
            <?php endif; ?>
        </div>

        <!-- TOMBOL BANTUAN WHATSAPP -->
        <div style="margin-top:24px; border-top:1px solid #e2e8f0; padding-top:16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <span style="font-size:13px; color:#64748b;">Ada pertanyaan atau kendala seputar pengiriman barang Anda?</span>
            <a href="<?php echo esc_url($wa_ask_url); ?>" target="_blank" class="pk01-btn-whatsapp">
                💬 Hubungi CS via WhatsApp
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- STYLESHEET STANDAR PUBLIC TRACKING -->
<style>
.pk01-public-tracking-wrap {
    max-width: 860px;
    margin: 30px auto;
    padding: 0 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
}
.pk01-track-hero {
    text-align: center;
    margin-bottom: 24px;
}
.pk01-track-badge {
    background: #e0f2fe;
    color: #0369a1;
    font-size: 11px;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 20px;
    letter-spacing: 0.5px;
}
.pk01-track-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03);
}
.pk01-track-input {
    width: 100%;
    padding: 10px 14px;
    font-size: 14px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    background: #f8fafc;
    box-sizing: border-box;
    outline: none;
}
.pk01-track-input:focus, .pk01-track-select:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.12);
    background: #fff;
}
.pk01-track-select {
    padding: 10px 12px;
    font-size: 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    background: #f8fafc;
    outline: none;
    box-sizing: border-box;
}
.pk01-track-button {
    background: #2563eb;
    color: #ffffff;
    font-weight: 700;
    font-size: 14px;
    padding: 10px 22px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s;
    white-space: nowrap;
}
.pk01-track-button:hover {
    background: #1d4ed8;
}
.pk01-track-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 16px;
}
.alert-error {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
}

/* STEPPER PROGRESS */
.pk01-stepper-wrap {
    display: flex;
    justify-content: space-between;
    position: relative;
    margin: 24px 0 28px 0;
}
.pk01-stepper-wrap::before {
    content: '';
    position: absolute;
    top: 14px;
    left: 40px;
    right: 40px;
    height: 3px;
    background: #e2e8f0;
    z-index: 1;
}
.pk01-step {
    position: relative;
    z-index: 2;
    text-align: center;
    flex: 1;
}
.pk01-step-circle {
    width: 28px;
    height: 28px;
    background: #e2e8f0;
    color: #64748b;
    border-radius: 50%;
    margin: 0 auto 6px auto;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 12px;
}
.pk01-step.is-done .pk01-step-circle {
    background: #10b981;
    color: #ffffff;
}
.pk01-step.is-active .pk01-step-circle {
    background: #2563eb;
    color: #ffffff;
    box-shadow: 0 0 0 4px rgba(37,99,235,0.2);
}
.pk01-step-text {
    font-size: 11px;
    font-weight: 600;
    color: #64748b;
}
.pk01-step.is-done .pk01-step-text, .pk01-step.is-active .pk01-step-text {
    color: #0f172a;
}

/* TIMELINE */
.pk01-timeline {
    position: relative;
    padding-left: 20px;
    border-left: 2px solid #e2e8f0;
    margin-left: 10px;
}
.pk01-timeline-item {
    position: relative;
    margin-bottom: 20px;
}
.pk01-timeline-item:last-child {
    margin-bottom: 0;
}
.pk01-timeline-point {
    position: absolute;
    left: -26px;
    top: 3px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #94a3b8;
    border: 2px solid #ffffff;
}
.pk01-timeline-item.is-latest .pk01-timeline-point {
    background: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.25);
}
.pk01-timeline-time {
    font-size: 12px;
    font-weight: 700;
    color: #2563eb;
}
.pk01-timeline-desc {
    font-size: 13px;
    color: #334155;
    margin-top: 3px;
    line-height: 1.5;
}

.pk01-btn-whatsapp {
    background: #10b981;
    color: #ffffff;
    text-decoration: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    transition: all 0.2s;
}
.pk01-btn-whatsapp:hover {
    background: #059669;
    color: #fff;
}

@media (max-width: 680px) {
    div[style*="grid-template-columns: 2fr 1.2fr auto"] {
        grid-template-columns: 1fr !important;
    }
    .pk01-stepper-wrap::before {
        display: none;
    }
}
</style>