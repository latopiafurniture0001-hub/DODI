<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

// 1. AUTENTIKASI & SUPERADMIN BYPASS
if (!is_user_logged_in()) { 
    echo '<div style="max-width:520px;margin:40px auto;padding:26px;background:#fff;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;color:#0f172a;">Login Diperlukan</strong>
            <p style="color:#64748b;font-size:13px;margin:6px 0 16px;">Silakan login terlebih dahulu untuk membuka antrean pengemasan pesanan.</p>
            <a href="' . esc_url(class_exists('PK01_Login') ? PK01_Login::url(get_permalink()) : wp_login_url(get_permalink())) . '" class="pk01-btn pk01-btn-primary">Login Sekarang</a>
          </div>'; 
    return; 
}

$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';

if (!$is_admin && class_exists('PK01_Authorization') && !PK01_Authorization::can('packing')) { 
    echo '<div style="max-width:520px;margin:40px auto;padding:26px;background:#fff;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🚫</div>
            <strong style="font-size:16px;color:#dc2626;">Akses Terbatas</strong>
            <p style="color:#64748b;font-size:13px;">Role Anda (' . esc_html(strtoupper($role)) . ') belum memiliki wewenang untuk membuka proses packing.</p>
          </div>'; 
    return; 
}

$can_mutate = $is_admin || (class_exists('PK01_Authorization') ? PK01_Authorization::can_action('packing', 'edit') : false);
$notice = '';

// Helper Nama Tabel Resmi
$t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('sales_orders') 
    : $wpdb->prefix . 'pk01_sales_orders';

if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) {
    $t = $wpdb->prefix . 'pk01_orders';
}

// 2. PROSES AKSI: SELESAI PACKING SATUAN & BATCH/MASSAL
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // A. Single Order Pack
    if (isset($_POST['pk01_pack_order'])) {
        if (!$can_mutate || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_packing_nonce'] ?? '')), 'pk01_packing_action')) {
            $notice = '<div class="pk01-alert is-error">⚠️ Anda tidak memiliki izin atau sesi keamanan telah kedaluwarsa.</div>';
        } else {
            try { 
                $oid = (int)($_POST['order_id'] ?? 0);
                $notes = sanitize_text_field(wp_unslash($_POST['notes'] ?? ''));
                if (class_exists('PK01_Engine')) {
                    PK01_Engine::mark_order_packed($oid, $notes);
                } else {
                    $wpdb->update($t, ['shipping_status' => 'packed', 'updated_at' => current_time('mysql')], ['id' => $oid]);
                }
                $notice = '<div class="pk01-alert is-success">✅ Order <strong>#' . $oid . '</strong> berhasil ditandai <strong>SUDAH PACKING</strong> dan siap diambil kurir ekspedisi.</div>'; 
            } catch(Throwable $e) { 
                $notice = '<div class="pk01-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>'; 
            }
        }
    }

    // B. Bulk / Batch Orders Pack
    if (isset($_POST['pk01_batch_pack_orders'])) {
        if (!$can_mutate || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_packing_nonce'] ?? '')), 'pk01_packing_action')) {
            $notice = '<div class="pk01-alert is-error">⚠️ Sesi keamanan massal tidak valid.</div>';
        } else {
            $batch_ids = array_filter(array_map('absint', (array)($_POST['selected_orders'] ?? [])));
            $batch_notes = sanitize_text_field(wp_unslash($_POST['batch_notes'] ?? 'Standard Packaging'));
            
            if (empty($batch_ids)) {
                $notice = '<div class="pk01-alert is-error">⚠️ Tidak ada pesanan yang dipilih untuk dikemas massal.</div>';
            } else {
                $success_count = 0;
                foreach ($batch_ids as $b_id) {
                    try {
                        if (class_exists('PK01_Engine')) {
                            PK01_Engine::mark_order_packed($b_id, $batch_notes);
                        } else {
                            $wpdb->update($t, ['shipping_status' => 'packed', 'updated_at' => current_time('mysql')], ['id' => $b_id]);
                        }
                        $success_count++;
                    } catch (Throwable $e) {}
                }
                $notice = '<div class="pk01-alert is-success">✅ Berhasil menandai <strong>' . $success_count . ' pesanan</strong> sekaligus berstatus <strong>SUDAH PACKING</strong>.</div>';
            }
        }
    }

    // C. Ekspor Manifest Packing ke CSV
    if (isset($_POST['pk01_export_packing_manifest']) && check_admin_referer('pk01_export_packing_nonce')) {
        if ($can_mutate) {
            $export_eligible = $wpdb->get_results("
                SELECT * FROM `{$t}` 
                WHERE LOWER(COALESCE(payment_status,'')) = 'paid' 
                AND LOWER(COALESCE(shipping_status,'pending')) IN ('pending','ready_to_pack','packing') 
                AND LOWER(COALESCE(status,'processing')) NOT IN ('cancelled','canceled','failed','refunded','shipped','completed') 
                ORDER BY id ASC LIMIT 300
            ", ARRAY_A) ?: [];

            if (!empty($export_eligible)) {
                $filename = 'pk01-packing-manifest-' . current_time('Y-m-d-His') . '.csv';
                nocache_headers();
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                $out = fopen('php://output', 'w');
                fputcsv($out, ['No. Order', 'Waktu Masuk', 'Nama Produk', 'SKU / Varian', 'Qty', 'Pelanggan', 'No. HP', 'Kurir / Layanan', 'Status Pembayaran']);
                foreach ($export_eligible as $o) {
                    fputcsv($out, [
                        $o['order_no'] ?: '#' . $o['id'],
                        $o['created_at'],
                        $o['product_name'] ?: 'Produk',
                        $o['variant_id'],
                        $o['qty'],
                        $o['customer_name'] ?: 'Pelanggan',
                        $o['customer_phone'] ?: '-',
                        strtoupper($o['courier'] ?? $o['channel'] ?? 'REGULER'),
                        strtoupper($o['payment_status'] ?? 'PAID')
                    ]);
                }
                fclose($out);
                exit;
            }
        }
    }
}

// 3. KUERI DATA REAL ANTREDAN & SUDAH PACKING
$eligible = $wpdb->get_results("
    SELECT * FROM `{$t}` 
    WHERE LOWER(COALESCE(payment_status,'')) = 'paid' 
    AND LOWER(COALESCE(shipping_status,'pending')) IN ('pending','ready_to_pack','packing') 
    AND LOWER(COALESCE(status,'processing')) NOT IN ('cancelled','canceled','failed','refunded','shipped','completed') 
    ORDER BY id ASC LIMIT 200
", ARRAY_A) ?: [];

$packed = $wpdb->get_results("
    SELECT * FROM `{$t}` 
    WHERE LOWER(COALESCE(shipping_status,'')) = 'packed' 
    AND LOWER(COALESCE(status,'processing')) NOT IN ('cancelled','canceled','failed','refunded','delivered') 
    ORDER BY id DESC LIMIT 60
", ARRAY_A) ?: [];

$total_qty_to_pack = 0;
foreach ($eligible as $o) {
    $total_qty_to_pack += (float)($o['qty'] ?? 0);
}

// Hitung Produktivitas Dikemas Hari Ini
$packed_today = (int) $wpdb->get_var($wpdb->prepare("
    SELECT COUNT(*) FROM `{$t}` 
    WHERE LOWER(COALESCE(shipping_status,'')) = 'packed' 
    AND DATE(updated_at) = %s
", current_time('Y-m-d')));

$refresh_url = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('packing')
    : add_query_arg('pk01_view', 'packing', home_url('/'));
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-pck-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-pck-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-pck-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 4 KPI Cards Deck */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-amber::before  { background: var(--pk-amber); }
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-emerald::before{ background: var(--pk-emerald); }
.pk01-kpi-card.c-sky::before    { background: var(--pk-sky); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 24px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; }
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* 3. Barcode Gun Scanner Bar */
.pk01-scanner-bar {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border: 1px solid var(--pk-slate-700);
    border-radius: 14px;
    padding: 16px 22px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    color: #ffffff;
}
.pk01-scanner-input-wrap {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    padding: 6px 12px;
    flex: 1;
    max-width: 460px;
}
.pk01-scanner-input {
    background: transparent;
    border: none;
    outline: none;
    color: #38bdf8;
    font-size: 14px;
    font-weight: 700;
    width: 100%;
    font-family: ui-monospace, SFMono-Regular, monospace;
}
.pk01-scanner-input::placeholder { color: #94a3b8; font-weight: 400; }

/* 4. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover { background: var(--pk-slate-100); color: var(--pk-slate-900); }
.pk01-tab-btn.is-active { background: var(--pk-slate-900); color: #ffffff; }

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Bulk Toolbar */
.pk01-bulk-bar {
    background: #f8fafc;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
    padding: 12px 18px;
    margin-bottom: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

/* Preset Tag Pills */
.pk01-preset-wrap {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    margin-top: 4px;
}
.pk01-pill-preset {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 6px;
    font-size: 10.5px;
    font-weight: 600;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill-preset:hover {
    background: var(--pk-indigo);
    color: #ffffff;
    border-color: var(--pk-indigo);
}

/* Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 16px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
.pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
.pk01-btn-emerald:hover { background: #059669; }
.pk01-btn-sm { padding: 4px 10px; font-size: 11.5px; border-radius: 6px; }

.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 11.5px;
}
.pk01-courier-tag {
    display: inline-block;
    background: #eef2ff;
    color: #3730a3;
    border: 1px solid #c7d2fe;
    font-size: 10.5px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
}

.pk01-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.badge-warning { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.badge-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }

.pk01-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-alert.is-error   { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }
</style>

<div class="pk01-pck-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-pck-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">FULFILLMENT WORKSPACE &bull; ORDER PACKAGING</span>
            <h1>📦 Workspace Antrean Packing &amp; Pengemasan</h1>
            <p>
                Menyaring hanya pesanan berstatus pembayaran <strong>PAID (Lunas)</strong> yang siap dikemas. Dilengkapi barcode scanner gun otomatis, proteksi standar packing, dan pencetakan label ekspedisi langsung.
            </p>
        </div>
        <div class="pk01-status-pill">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>PACKING STATION ONLINE</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;" id="pk01-live-clock">
                <?php echo date_i18n('d M Y'); ?> &bull; Data Real-Time
            </div>
        </div>
    </header>

    <?php if ($notice) echo $notice; ?>

    <!-- 2. EXECUTIVE 4 KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Pesanan Menunggu Packing</div>
            <div class="pk01-kpi-val" style="color:#d97706;"><?php echo number_format(count($eligible)); ?></div>
            <div class="pk01-kpi-sub">Order lunas siap dibungkus</div>
        </div>

        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Total Fisik Kuantitas Produk</div>
            <div class="pk01-kpi-val" style="color:#4f46e5;"><?php echo number_format($total_qty_to_pack); ?> <span style="font-size:14px; font-weight:400; color:#64748b;">Pcs</span></div>
            <div class="pk01-kpi-sub">Volume barang yang harus dikemas</div>
        </div>

        <div class="pk01-kpi-card c-emerald">
            <div class="pk01-kpi-label">Selesai Dikemas Hari Ini</div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo number_format($packed_today); ?></div>
            <div class="pk01-kpi-sub">Produktivitas tim packing hari ini</div>
        </div>

        <div class="pk01-kpi-card c-sky">
            <div class="pk01-kpi-label">Siap Diambil Kurir (Staging)</div>
            <div class="pk01-kpi-val" style="color:#0284c7;"><?php echo number_format(count($packed)); ?></div>
            <div class="pk01-kpi-sub">Paket menunggu serah terima ekspedisi</div>
        </div>
    </section>

    <!-- 3. BARCODE SCANNER BAR (UNTUK GUN SCANNER LAPANGAN) -->
    <div class="pk01-scanner-bar">
        <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-size:20px;">⚡</span>
            <div>
                <strong style="font-size:13.5px; display:block;">Quick Barcode Gun Scanner:</strong>
                <span style="font-size:11.5px; color:#cbd5e1;">Arahkan scanner ke barcode nomor pesanan / invoice untuk mencari instan.</span>
            </div>
        </div>

        <div class="pk01-scanner-input-wrap">
            <span>🔍</span>
            <input type="text" id="barcode_gun_input" class="pk01-scanner-input" placeholder="Scan barcode order di sini..." autofocus autocomplete="off">
        </div>
    </div>

    <!-- 4. TABS NAVIGASI WORKFLOW -->
    <nav class="pk01-nav-tabs" aria-label="Menu Packing">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-pending">
            📦 Antrean Belum Dikemas (<?php echo count($eligible); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-packed">
            ✅ Siap Serah Terima Ekspedisi (<?php echo count($packed); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-sop">
            🛡️ SOP Standar Pengemasan Lapangan
        </button>
    </nav>

    <!-- 5. TAB 1: ANTREAN ORDER BELUM DIKEMAS (MAIN WORKSPACE) -->
    <div class="pk01-pane is-active" id="tab-pending">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📦 Antrean Pesanan Siap Dikemas</h3>
                    <div class="pk01-surface-desc">
                        Cek fisik barang, bungkus sesuai standar keamanan produk, dan tandai selesai packing.
                    </div>
                </div>

                <div style="display:flex; gap:8px; align-items:center;">
                    <a class="pk01-btn pk01-btn-subtle" href="<?php echo esc_url($refresh_url); ?>">
                        ↻ Refresh
                    </a>
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('pk01_export_packing_nonce'); ?>
                        <input type="hidden" name="pk01_export_packing_manifest" value="1">
                        <button type="submit" class="pk01-btn pk01-btn-subtle">
                            📥 Ekspor Manifest (.CSV)
                        </button>
                    </form>
                </div>
            </div>

            <?php if (empty($eligible)): ?>
                <div style="text-align:center; padding:44px 20px; color:#059669; font-size:13px;">
                    <div style="font-size:38px; margin-bottom:8px;">🎉</div>
                    <strong>Luar Biasa! Seluruh Pesanan Selesai Dikemas.</strong>
                    <div style="color:#64748b; margin-top:4px;">Tidak ada pesanan berstatus pembayaran PAID yang tertunda saat ini.</div>
                </div>
            <?php else: ?>
                <!-- BATCH / MASSAL PACKING FORM -->
                <form method="post" id="pk01-batch-packing-form">
                    <?php wp_nonce_field('pk01_packing_action', 'pk01_packing_nonce'); ?>
                    <input type="hidden" name="pk01_batch_pack_orders" value="1">

                    <div class="pk01-bulk-bar">
                        <div style="display:flex; align-items:center; gap:12px;">
                            <label style="display:flex; align-items:center; gap:6px; cursor:pointer; font-size:12.5px; font-weight:700;">
                                <input type="checkbox" id="check_all_orders" style="width:16px; height:16px;">
                                <span>Pilih Semua (<span id="selected_count_badge">0</span> terpilih)</span>
                            </label>
                            <input type="text" name="batch_notes" id="batch_notes_input" placeholder="Catatan kemasan massal..." style="padding:6px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:12px; width:220px;">
                        </div>

                        <div>
                            <button type="submit" id="btn_batch_submit" class="pk01-btn pk01-btn-emerald pk01-btn-sm" disabled onclick="return confirm('Tandai seluruh pesanan yang dicentang sebagai SUDAH PACKING?');">
                                ✓ Tandai Selesai Packing Terpilih
                            </button>
                        </div>
                    </div>

                    <div class="pk01-table-card">
                        <table class="pk01-tbl" id="pk01_packing_tbl">
                            <thead>
                                <tr>
                                    <th style="width:40px; text-align:center;">Pilih</th>
                                    <th style="width:130px;">No. Order</th>
                                    <th>Item Produk &amp; Varian</th>
                                    <th style="text-align:center; width:70px;">Qty</th>
                                    <th>Pelanggan &amp; Tujuan</th>
                                    <th>Kurir / Ekspedisi</th>
                                    <th style="text-align:center; width:90px;">Cetak Label</th>
                                    <th style="width:280px;">Aksi Kemas &amp; Catatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($eligible as $o): 
                                    $raw_qty = rtrim(rtrim((string)$o['qty'], '0'), '.');
                                    $courier_label = strtoupper($o['courier'] ?? $o['channel'] ?? 'REGULER');
                                    $label_print_url = function_exists('pk01_print_url') ? pk01_print_url('pengiriman', (int)$o['id']) : '#';
                                ?>
                                <tr data-order="<?php echo esc_attr(strtolower($o['order_no'] ?: $o['id'])); ?>">
                                    <td style="text-align:center;">
                                        <input type="checkbox" name="selected_orders[]" value="<?php echo (int)$o['id']; ?>" class="pk01-row-checkbox" style="width:16px; height:16px; cursor:pointer;">
                                    </td>
                                    <td>
                                        <span class="pk01-code-badge"><?php echo esc_html($o['order_no'] ?: '#' . $o['id']); ?></span>
                                        <small style="display:block; color:#64748b; font-size:11px; margin-top:2px;">
                                            <?php echo esc_html(date_i18n('d M, H:i', strtotime($o['created_at']))); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <strong style="color:#0f172a;"><?php echo esc_html($o['product_name'] ?: 'Item Produk'); ?></strong>
                                        <?php if (!empty($o['variant_id'])): ?>
                                            <span style="display:block; font-size:11px; color:#64748b; font-family:monospace;">
                                                SKU/Varian: #<?php echo (int)$o['variant_id']; ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align:center; font-weight:800; font-size:14px; font-family:ui-monospace, monospace; color:#0f172a;">
                                        <?php echo esc_html($raw_qty); ?>
                                    </td>
                                    <td>
                                        <strong><?php echo esc_html($o['customer_name'] ?: 'Pelanggan'); ?></strong>
                                        <?php if (!empty($o['customer_phone'])): ?>
                                            <div style="font-size:11px; color:#64748b;"><?php echo esc_html($o['customer_phone']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="pk01-courier-tag"><?php echo esc_html($courier_label); ?></span>
                                    </td>
                                    <td style="text-align:center;">
                                        <?php if ($label_print_url !== '#'): ?>
                                            <a href="<?php echo esc_url($label_print_url); ?>" target="_blank" class="pk01-btn pk01-btn-subtle pk01-btn-sm" title="Cetak label alamat / thermal resi">
                                                🏷️ Cetak
                                            </a>
                                        <?php else: ?>
                                            <span style="color:#94a3b8; font-size:11px;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($can_mutate): ?>
                                            <div style="display:flex; gap:6px; align-items:center;">
                                                <input type="text" id="note_input_<?php echo (int)$o['id']; ?>" class="pk01-single-note" placeholder="Catatan kemasan..." style="padding:6px 10px; border:1px solid #cbd5e1; border-radius:6px; font-size:12px; width:150px;">
                                                <button type="button" class="pk01-btn pk01-btn-emerald pk01-btn-sm pk01-single-pack-btn" data-id="<?php echo (int)$o['id']; ?>">
                                                    ✓ Packed
                                                </button>
                                            </div>
                                            <div class="pk01-preset-wrap">
                                                <span class="pk01-pill-preset" data-id="<?php echo (int)$o['id']; ?>" data-preset="Bubble 3 Lapis">+ Bubble</span>
                                                <span class="pk01-pill-preset" data-id="<?php echo (int)$o['id']; ?>" data-preset="Packing Kayu">+ Kayu</span>
                                                <span class="pk01-pill-preset" data-id="<?php echo (int)$o['id']; ?>" data-preset="Dus Double Wall">+ Dus</span>
                                                <span class="pk01-pill-preset" data-id="<?php echo (int)$o['id']; ?>" data-preset="Stiker Fragile">+ Fragile</span>
                                            </div>
                                        <?php else: ?>
                                            <span style="font-size:12px; color:#94a3b8;">Hanya Lihat (Staf)</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- 6. TAB 2: SUDAH SELESAI PACKING (STAGING AREA MENUNGGU KURIR) -->
    <div class="pk01-pane" id="tab-packed">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>✅ Paket Siap Serah Terima ke Logistik / Kurir</h3>
                    <div class="pk01-surface-desc">
                        Paket telah selesai dibungkus dan diletakkan di area staging gudang menunggu penjemputan ekspedisi.
                    </div>
                </div>
                <span class="pk01-badge badge-success" style="font-size:12px; padding:6px 12px;">
                    <?php echo count($packed); ?> Paket Siap Pick-up
                </span>
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th style="width:140px;">No. Order</th>
                            <th>Item Produk</th>
                            <th>Penerima Paket</th>
                            <th style="text-align:center; width:80px;">Qty</th>
                            <th>Ekspedisi</th>
                            <th style="text-align:center; width:130px;">Status Gudang</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($packed)): ?>
                            <tr>
                                <td colspan="6" style="text-align:center; padding:32px; color:#94a3b8;">
                                    Belum ada paket yang berstatus selesai dikemas pada periode ini.
                                </td>
                            </tr>
                        <?php else: foreach ($packed as $p): ?>
                            <tr>
                                <td><span class="pk01-code-badge"><?php echo esc_html($p['order_no'] ?: '#' . $p['id']); ?></span></td>
                                <td><strong><?php echo esc_html($p['product_name'] ?: 'Produk'); ?></strong></td>
                                <td><?php echo esc_html($p['customer_name'] ?: 'Pelanggan'); ?></td>
                                <td style="text-align:center; font-weight:700; font-family:ui-monospace, monospace;">
                                    <?php echo esc_html(rtrim(rtrim((string)$p['qty'], '0'), '.')); ?>
                                </td>
                                <td><span class="pk01-courier-tag"><?php echo esc_html(strtoupper($p['courier'] ?? 'REGULER')); ?></span></td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge badge-success">● Siap Ekspedisi</span>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 7. TAB 3: SOP STANDAR PENGEMASAN LAPANGAN -->
    <div class="pk01-pane" id="tab-sop">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🛡️ Standar Operasional Prosedur (SOP Pengemasan)</h3>
                    <div class="pk01-surface-desc">Pedoman kualitas packing gudang untuk meminimalkan klaim kerusakan barang dalam perjalanan ekspedisi.</div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:18px;">
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🔍 &bull; Quality Check (QC)</div>
                    <strong style="font-size:14px; color:#0f172a; display:block; margin-bottom:6px;">1. Pemeriksaan Fisik Produk</strong>
                    <p style="font-size:12.5px; color:#64748b; line-height:1.5; margin:0;">
                        Pastikan barang tidak cacat gores, kelengkapan baut/aksesoris lengkap, dan warna/ukuran sesuai dengan invoice sebelum dimasukkan ke dalam kardus.
                    </p>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">📦 &bull; Cushioning Layer</div>
                    <strong style="font-size:14px; color:#0f172a; display:block; margin-bottom:6px;">2. Perlindungan Benturan</strong>
                    <p style="font-size:12.5px; color:#64748b; line-height:1.5; margin:0;">
                        Gunakan minimal 3 lapis bubble wrap untuk barang pecah belah. Isi rongga kosong dengan foam/dudukan agar produk tidak bergeser saat guncangan kargo.
                    </p>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🏷️ &bull; Barcode &amp; Stiker</div>
                    <strong style="font-size:14px; color:#0f172a; display:block; margin-bottom:6px;">3. Tempel Label Jelas</strong>
                    <p style="font-size:12.5px; color:#64748b; line-height:1.5; margin:0;">
                        Pastikan barcode resi ekspedisi tidak terlipat atau tertutup lakban buram agar dapat dipindai dengan cepat oleh kurir saat serah terima.
                    </p>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- HIDDEN SINGLE PACK SUBMIT FORM (BYPASS INTERACTIVE FORM) -->
<form id="pk01_single_pack_hidden_form" method="post" style="display:none;">
    <?php wp_nonce_field('pk01_packing_action', 'pk01_packing_nonce'); ?>
    <input type="hidden" name="pk01_pack_order" value="1">
    <input type="hidden" name="order_id" id="hidden_single_order_id" value="0">
    <input type="hidden" name="notes" id="hidden_single_notes" value="">
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH URL
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. BARCODE GUN SCANNER AUTO-LOOKUP & INSTANT HIGHLIGHT
    const barcodeInput = document.getElementById('barcode_gun_input');
    const tableRows    = document.querySelectorAll('#pk01_packing_tbl tbody tr');

    if (barcodeInput) {
        barcodeInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const code = this.value.trim().toLowerCase().replace('#', '');
                if (!code) return;

                let found = false;
                tableRows.forEach(row => {
                    const orderData = row.getAttribute('data-order') || '';
                    if (orderData.includes(code)) {
                        found = true;
                        row.style.background = '#fef08a';
                        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        
                        // Focus on its packed button
                        const btn = row.querySelector('.pk01-single-pack-btn');
                        if (btn) btn.focus();
                    } else {
                        row.style.background = '';
                    }
                });

                if (!found) {
                    alert('Pesanan dengan barcode/order "' + code + '" tidak ditemukan pada antrean packing.');
                }
                this.value = '';
            }
        });
    }

    // 3. QUICK PACKING PRESET PILLS
    const presetPills = document.querySelectorAll('.pk01-pill-preset');
    presetPills.forEach(pill => {
        pill.addEventListener('click', function() {
            const oid = this.getAttribute('data-id');
            const input = document.getElementById('note_input_' + oid);
            const presetVal = this.getAttribute('data-preset');
            if (input) {
                input.value = input.value ? (input.value + ', ' + presetVal) : presetVal;
                input.focus();
            }
        });
    });

    // 4. SINGLE PACK BUTTON SUBMISSION
    const singlePackBtns = document.querySelectorAll('.pk01-single-pack-btn');
    const hiddenForm     = document.getElementById('pk01_single_pack_hidden_form');
    const hiddenId       = document.getElementById('hidden_single_order_id');
    const hiddenNotes    = document.getElementById('hidden_single_notes');

    singlePackBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const oid = this.getAttribute('data-id');
            const noteInput = document.getElementById('note_input_' + oid);
            const notes = noteInput ? noteInput.value.trim() : '';

            if (confirm('Konfirmasi: Tandai pesanan #' + oid + ' sudah selesai dikemas dan siap ekspedisi?')) {
                hiddenId.value = oid;
                hiddenNotes.value = notes;
                hiddenForm.submit();
            }
        });
    });

    // 5. BULK / BATCH CHECKBOX SELECTION
    const checkAllBox     = document.getElementById('check_all_orders');
    const rowCheckboxes   = document.querySelectorAll('.pk01-row-checkbox');
    const selectedBadge   = document.getElementById('selected_count_badge');
    const batchSubmitBtn  = document.getElementById('btn_batch_submit');

    function updateBulkState() {
        let count = 0;
        rowCheckboxes.forEach(cb => {
            if (cb.checked) count++;
        });

        if (selectedBadge) selectedBadge.textContent = count;
        if (batchSubmitBtn) {
            batchSubmitBtn.disabled = (count === 0);
        }
    }

    if (checkAllBox) {
        checkAllBox.addEventListener('change', function() {
            rowCheckboxes.forEach(cb => cb.checked = checkAllBox.checked);
            updateBulkState();
        });
    }

    rowCheckboxes.forEach(cb => {
        cb.addEventListener('change', function() {
            updateBulkState();
            if (checkAllBox && !this.checked) checkAllBox.checked = false;
        });
    });
});
</script>