<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$track_result = null;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$role = class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
$can_manage = $is_admin || ($role === 'pk01_logistik') || ($role === 'pk01_admin');
$can_monitor = $is_admin || in_array($role, ['pk01_logistik','pk01_gudang','pk01_kasir','pk01_packing','pk01_seller'], true);

// DETEKSI TABEL DATABASE TERKAIT
$tbl_shipments = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('shipments') 
    : $wpdb->prefix . 'pk01_shipments';

$tbl_orders = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('sales_orders') 
    : ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}pk01_orders'") ? $wpdb->prefix . 'pk01_orders' : false);

$tbl_logs = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('activity_logs') 
    : $wpdb->prefix . 'pk01_activity_logs';

// 2. LOGIKA BARU: EKSPOR MANIFEST PENGIRIMAN KE CSV (SERAH TERIMA KURIR)
if (isset($_POST['pk01_export_shipments_csv']) && check_admin_referer('pk01_export_shipments_nonce')) {
    if ($can_manage && $tbl_shipments) {
        $export_rows = $wpdb->get_results(
            "SELECT s.*, COALESCE(o.order_no, CONCAT('#', s.sale_id)) AS order_ref 
             FROM `{$tbl_shipments}` s 
             LEFT JOIN `{$tbl_orders}` o ON o.id = s.sale_id 
             ORDER BY s.id DESC LIMIT 5000", 
            ARRAY_A
        );
        if (!empty($export_rows)) {
            $filename = 'pk01-manifest-pengiriman-' . current_time('Y-m-d-His') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['No. Resi (AWB)', 'Ekspedisi', 'Layanan', 'No. Pesanan', 'Penerima', 'No. WhatsApp', 'Tujuan Lengkap', 'Status', 'Update Terakhir']);
            foreach ($export_rows as $r) {
                fputcsv($out, [
                    $r['tracking_no'],
                    strtoupper($r['courier']),
                    $r['service'] ?: 'REG',
                    $r['order_ref'] ?: '-',
                    $r['recipient_name'],
                    $r['recipient_phone'],
                    $r['destination'],
                    strtoupper($r['status']),
                    $r['last_event_at'] ?: $r['created_at']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. PROSES DAFTARKAN RESI PENGIRIMAN BARU (LOGIKA LAMA UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_create_shipment']) && $can_manage) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_ship_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_create_ship_action')) {
        $notice = '<div class="pk01-ship-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        $source          = sanitize_key($_POST['ship_source'] ?? 'website');
        $courier         = strtolower(sanitize_key($_POST['ship_courier'] ?? ''));
        $service         = sanitize_text_field($_POST['ship_service'] ?? 'REG');
        $tracking_no     = strtoupper(sanitize_text_field(trim($_POST['ship_tracking_no'] ?? '')));
        $recipient_name  = sanitize_text_field($_POST['ship_recipient_name'] ?? '');
        $recipient_phone = sanitize_text_field($_POST['ship_recipient_phone'] ?? '');
        $destination     = sanitize_text_field($_POST['ship_destination'] ?? '');
        $sale_id         = absint($_POST['ship_sale_id'] ?? 0);

        if (empty($tracking_no) || empty($courier)) {
            $notice = '<div class="pk01-ship-alert is-error">⚠️ Kurir ekspedisi dan nomor resi (AWB) wajib diisi.</div>';
        } else {
            try {
                // A. Simpan ke Tabel Shipments
                $saved = false;
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'create_shipment')) {
                    $saved = PK01_Engine::create_shipment($source, $tracking_no, $courier, $service, $sale_id, 0, $recipient_name, $recipient_phone, $destination);
                } else {
                    $saved = $wpdb->insert($tbl_shipments, [
                        'source'          => $source,
                        'tracking_no'     => $tracking_no,
                        'courier'         => $courier,
                        'service'         => $service,
                        'sale_id'         => $sale_id,
                        'recipient_name'  => $recipient_name,
                        'recipient_phone' => $recipient_phone,
                        'destination'     => $destination,
                        'status'          => 'on_process',
                        'last_event_at'   => current_time('mysql'),
                        'created_at'      => current_time('mysql')
                    ]);
                }

                // B. JABAT TANGAN: UPDATE STATUS PESANAN JADI 'DIKIRIM' (SHIPPED)
                if ($sale_id > 0 && $tbl_orders) {
                    $wpdb->update($tbl_orders, [
                        'status'          => 'shipped',
                        'shipping_status' => 'shipped',
                        'tracking_no'     => $tracking_no,
                        'courier'         => strtoupper($courier),
                    ], ['id' => $sale_id]);
                }

                // C. Jabat Tangan ke Log Sistem
                if ($tbl_logs && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
                    $wpdb->insert($tbl_logs, [
                        'user_id'     => get_current_user_id(),
                        'action'      => 'shipment_created',
                        'module'      => 'shipments',
                        'entity'      => strtoupper($courier) . ' - ' . $tracking_no,
                        'description' => "Resi {$tracking_no} diterbitkan untuk {$recipient_name} (" . ($sale_id ? "Order #{$sale_id}" : "Manual") . ")",
                        'created_at'  => current_time('mysql')
                    ]);
                }

                $notice = '<div class="pk01-ship-alert is-success">✅ Resi <strong>' . esc_html($tracking_no) . '</strong> (' . esc_html(strtoupper($courier)) . ') berhasil disimpan dan status pesanan otomatis diperbarui menjadi <b>Dikirim (Shipped)</b>.</div>';
                $_POST = [];
            } catch (Throwable $e) {
                $notice = '<div class="pk01-ship-alert is-error">❌ Gagal menyimpan pengiriman: ' . esc_html($e->getMessage()) . '</div>';
            }
        }
    }
}

// 4. UPDATE MILESTONE MANUAL — MODE ZERO API
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_manual_tracking'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_manual_tracking_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_manual_tracking_action')) {
        $notice = '<div class="pk01-ship-alert is-error">⚠️ Sesi keamanan kedaluwarsa.</div>';
    } elseif (!$can_manage) {
        $notice = '<div class="pk01-ship-alert is-error">⚠️ Anda tidak memiliki izin mengubah milestone pengiriman.</div>';
    } else {
        $shipment_id = absint($_POST['manual_shipment_id'] ?? 0);
        $status = sanitize_key($_POST['manual_status'] ?? '');
        $location = sanitize_text_field(wp_unslash($_POST['manual_location'] ?? ''));
        $description = sanitize_textarea_field(wp_unslash($_POST['manual_description'] ?? ''));
        $event_time = sanitize_text_field(wp_unslash($_POST['manual_event_time'] ?? ''));
        $allowed = ['label_created','picked_up','in_transit','arrived','out_for_delivery','delivered','delivery_failed','return_to_sender','returned'];
        if ($shipment_id <= 0 || !in_array($status, $allowed, true)) {
            $notice = '<div class="pk01-ship-alert is-error">⚠️ Milestone pengiriman tidak valid.</div>';
        } else {
            try {
                if ($event_time === '') $event_time = current_time('mysql');
                if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $event_time)) throw new Exception('Waktu kejadian tidak valid.');
                $desc = $description !== '' ? $description : (class_exists('PK01_Shipping_Smart') ? PK01_Shipping_Smart::status_label($status) : $status);
                PK01_Engine::add_tracking_event($shipment_id, $status, $status, $desc, $location, $event_time, 'manual');
                $notice = '<div class="pk01-ship-alert is-success">✅ Milestone <strong>' . esc_html(class_exists('PK01_Shipping_Smart') ? PK01_Shipping_Smart::status_label($status) : $status) . '</strong> tersimpan sebagai catatan <b>Manual / Tanpa API</b>. Riwayat dan laporan PK01 diperbarui.</div>';
            } catch (Throwable $e) {
                $notice = '<div class="pk01-ship-alert is-error">❌ Gagal mencatat milestone: ' . esc_html($e->getMessage()) . '</div>';
            }
        }
    }
}

// 4. PROSES LIVE TRACKING RESI — SATU ENGINE, STATUS API DISIMPAN SEBAGAI EVENT NYATA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_track_action'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_track_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_track_action_verify')) {
        $notice = '<div class="pk01-ship-alert is-error">⚠️ Sesi tidak valid. Silakan muat ulang halaman.</div>';
    } else {
        $target_awb = strtoupper(sanitize_text_field(trim($_POST['track_tracking_no'] ?? '')));
        $ship_data  = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_shipments}` WHERE tracking_no = %s", $target_awb), ARRAY_A);
        if (!$ship_data) {
            $notice = '<div class="pk01-ship-alert is-error">⚠️ Resi belum terdaftar di PK01. Masukkan melalui Kasir/Import Resi terlebih dahulu agar tidak ada transaksi pelaporan yang mengarang.</div>';
        } elseif (!class_exists('PK01_Shipping_Smart')) {
            $notice = '<div class="pk01-ship-alert is-error">⚠️ Engine Shipping PK01 belum dimuat.</div>';
        } else {
            $event = null;
            try {
                $event = PK01_Shipping_Smart::track_one($ship_data);
                if (!$event) throw new Exception('Provider belum menemukan resi. Bisa jadi AWB baru dan belum terindeks.');
                PK01_Shipping_Smart::apply_tracking_for_ui($event, 'api');
                $track_result = [
                    'success'=>true,'courier'=>strtoupper($ship_data['courier']),'waybill'=>$target_awb,
                    'status'=>$event['status'],'status_label'=>PK01_Shipping_Smart::status_label($event['status']),
                    'message'=>$event['description']??'','history'=>[]
                ];
                $events=$wpdb->get_results($wpdb->prepare("SELECT status,event_time,location,description FROM `".PK01_DB::t('tracking_events')."` WHERE shipment_id=%d ORDER BY event_time DESC,id DESC LIMIT 50",(int)$ship_data['id']),ARRAY_A)?:[];
                foreach($events as $ev)$track_result['history'][]=['date'=>$ev['event_time'],'location'=>$ev['location'],'desc'=>$ev['description']?:PK01_Shipping_Smart::status_label($ev['status'])];
                $notice='<div class="pk01-ship-alert is-success">✅ API kurir berhasil disinkronkan. Status <strong>'.esc_html($track_result['status_label']).'</strong> dan kronologi tersimpan di tracking_events PK01.</div>';
            } catch(Throwable $e) {
                $notice='<div class="pk01-ship-alert is-error">⚠️ Tracking API gagal/tidak menemukan resi: '.esc_html($e->getMessage()).'. Status terakhir PK01 dipertahankan; sistem tidak membuat status palsu.</div>';
            }
        }
    }
}

// 5. AMBIL DATA PESANAN YANG SIAP DIKIRIM (AUTO-FILL FORM)
$pending_orders = [];
if ($tbl_orders && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_orders)) === $tbl_orders) {
    $cols = $wpdb->get_col("DESC `{$tbl_orders}`", 0);
    $c_name = in_array('customer_name', $cols) ? 'customer_name' : 'name';
    $c_phone = in_array('customer_phone', $cols) ? 'customer_phone' : 'phone';
    $c_addr = in_array('shipping_address', $cols) ? 'shipping_address' : (in_array('address', $cols) ? 'address' : 'city');

    $pending_orders = $wpdb->get_results(
        "SELECT id, order_no, {$c_name} AS customer_name, {$c_phone} AS customer_phone, {$c_addr} AS destination 
         FROM `{$tbl_orders}` 
         WHERE payment_status='paid' AND LOWER(COALESCE(shipping_status,'pending')) IN ('packed','label_created') AND status NOT IN ('cancelled','failed','refunded','shipped','completed') 
         ORDER BY id DESC LIMIT 50", 
        ARRAY_A
    ) ?: [];
}

// 6. AMBIL DATA TABEL RIWAYAT RESI
$rows = $wpdb->get_results(
    "SELECT s.*, COALESCE(o.order_no, CONCAT('#', s.sale_id)) AS order_ref 
     FROM `{$tbl_shipments}` s 
     LEFT JOIN `{$tbl_orders}` o ON o.id = s.sale_id 
     ORDER BY s.id DESC LIMIT 150", 
    ARRAY_A
) ?: [];

// Hitung Statistik Resi Riil
$count_active = 0;
$count_delivered = 0;
$count_failed = 0;

foreach ($rows as $r) {
    $st = strtolower($r['status'] ?? '');
    if ($st === 'delivered' || $st === 'selesai') {
        $count_delivered++;
    } elseif (in_array($st, ['delivery_failed', 'returned', 'retur', 'gagal'])) {
        $count_failed++;
    } else {
        $count_active++;
    }
}

// Konfigurasi Ekspedisi Tersimpan
$shipping_cfg = class_exists('PK01_Shipping_Engine') ? PK01_Shipping_Engine::get_settings() : [];
$active_couriers = $shipping_cfg['shipping_active_couriers'] ?? ['jne', 'jnt', 'sicepat', 'pos', 'anteraja', 'lion', 'ninja', 'tiki', 'spx', 'wahana', 'ide'];

$courier_names = [
    'jne'      => 'JNE Express', 
    'jnt'      => 'J&T Express', 
    'sicepat'  => 'SiCepat Ekspres',
    'pos'      => 'POS Indonesia', 
    'anteraja' => 'Anteraja', 
    'lion'     => 'Lion Parcel',
    'ninja'    => 'Ninja Xpress', 
    'tiki'     => 'TIKI', 
    'wahana'   => 'Wahana',
    'ide'      => 'ID Express', 
    'spx'      => 'SPX (Shopee Express)',
    'lalamove' => 'Lalamove / Kargo Toko'
];
?>

<style>
:root {
    --pk-shp-navy: #0f172a;
    --pk-shp-border: #e2e8f0;
    --pk-shp-blue: #2563eb;
    --pk-shp-green: #059669;
    --pk-shp-amber: #d97706;
    --pk-shp-red: #dc2626;
    --pk-shp-purple: #7c3aed;
    --pk-shp-muted: #64748b;
}

.pk01-shipping-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-shipping-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-shp-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-shp-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-shp-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-shp-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-shp-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-shp-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-blue   { border-left-color: var(--pk-shp-blue); }
.pk01-kpi-card.c-green  { border-left-color: var(--pk-shp-green); }
.pk01-kpi-card.c-red    { border-left-color: var(--pk-shp-red); }
.pk01-kpi-card.c-purple { border-left-color: var(--pk-shp-purple); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--pk-shp-muted);
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: var(--pk-shp-muted);
}

/* Surface Card */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-shp-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}
@media (max-width: 900px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: #2563eb;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Live Tracking Result Visualizer */
.pk01-live-track-box {
    background: #0f172a;
    color: #f8fafc;
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 24px;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.2);
}
.pk01-track-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #334155;
    padding-bottom: 14px;
    margin-bottom: 16px;
}
.pk01-timeline-list {
    margin-top: 14px;
    padding-left: 14px;
    border-left: 2px solid #334155;
    max-height: 280px;
    overflow-y: auto;
}
.pk01-timeline-node {
    margin-bottom: 14px;
    position: relative;
}
.pk01-timeline-node strong {
    font-size: 13px;
    color: #38bdf8;
    display: block;
}
.pk01-timeline-node span {
    font-size: 12px;
    color: #cbd5e1;
    display: block;
    margin-top: 2px;
}

/* Table Style */
.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-shp-border);
    border-radius: 12px;
}
.pk01-shp-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-shp-table th {
    background: #f8fafc;
    padding: 11px 12px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-shp-border);
}
.pk01-shp-table td {
    padding: 11px 12px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-shp-table tr:hover td { background: #fbfcfe; }

/* Status Badges */
.pk01-status-pill {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.st-shipping  { background: #e0e7ff; color: #3730a3; }
.st-delivered { background: #dcfce7; color: #166534; }
.st-failed    { background: #fee2e2; color: #991b1b; }

/* Filter Chips Bar */
.pk01-filter-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 14px;
}
.pk01-filter-chips {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.pk01-chip-btn {
    padding: 6px 12px;
    border-radius: 20px;
    border: 1px solid #cbd5e1;
    background: #ffffff;
    font-size: 12px;
    font-weight: 600;
    color: #475569;
    cursor: pointer;
}
.pk01-chip-btn.active {
    background: #0f172a;
    color: #ffffff;
    border-color: #0f172a;
}

/* Action Buttons */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-track   { background: #2563eb; color: #ffffff !important; padding: 4px 8px; font-size: 11px; border-radius: 6px; }
.pk01-btn-wa      { background: #25d366; color: #ffffff !important; padding: 4px 8px; font-size: 11px; border-radius: 6px; }
.pk01-btn-direct  { background: #f1f5f9; color: #0f172a !important; border: 1px solid #cbd5e1; padding: 4px 8px; font-size: 11px; border-radius: 6px; }
.pk01-btn-direct:hover { background: #e2e8f0; }

.pk01-ship-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-ship-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-ship-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-shipping-cockpit"><?php if ($role === 'pk01_kasir'): ?><div style="margin:0 0 18px;padding:14px 16px;border:1px solid #bfdbfe;background:#eff6ff;border-radius:12px;color:#1e40af;font-size:13px;"><b>Mode Kasir — Pantauan Saja.</b> Penjualan dibuat di Kasir. Packing, pembuatan resi, serah-terima ke kurir, dan retur diproses petugas masing-masing. Kasir hanya melihat status order, resi, pengiriman, dan retur.</div><?php endif; ?>
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-shp-hero">
        <div>
            <span class="pk01-shp-eyebrow">LOGISTICS &bull; MULTI-COURIER FULFILLMENT</span>
            <h1>Logistik &amp; Pelacakan Ekspedisi</h1>
            <p>
                Kelola surat jalan pengiriman pesanan, pelacakan real-time bila API tersedia, serta pencatatan milestone manual Zero-API untuk semua kurir/trucking, 
                dan notifikasi pengiriman otomatis ke WhatsApp pelanggan.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_shipments_nonce'); ?>
                <input type="hidden" name="pk01_export_shipments_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Manifest Pengiriman (.CSV)
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-shp-kpis">
        <div class="pk01-kpi-card c-blue">
            <small>Paket Sedang Bergerak (Aktif)</small>
            <strong style="color:#1d4ed8;"><?php echo (int)$count_active; ?> <span style="font-size:13px;font-weight:normal;">Paket</span></strong>
            <span>Dalam perjalanan menuju penerima</span>
        </div>

        <div class="pk01-kpi-card c-green">
            <small>Terkirim &amp; Selesai (Delivered)</small>
            <strong style="color:#059669;"><?php echo (int)$count_delivered; ?> <span style="font-size:13px;font-weight:normal;">Paket</span></strong>
            <span>Paket telah sampai di tangan pembeli</span>
        </div>

        <div class="pk01-kpi-card c-red">
            <small>Gagal / Retur Ekspedisi</small>
            <strong style="color:#dc2626;"><?php echo (int)$count_failed; ?> <span style="font-size:13px;font-weight:normal;">Paket</span></strong>
            <span>Perlu koordinasi kurir atau alamat baru</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Integrasi Gateway &amp; Direct Link</small>
            <strong style="font-size:17px;color:#7c3aed;margin-top:9px;">
                <?php echo !empty($shipping_cfg['shipping_api_key']) ? '🟢 ' . ucfirst($shipping_cfg['shipping_provider'] ?? 'API Gateway') : '🔗 Direct Web Mode'; ?>
            </strong>
            <span>Semua kurir & trucking dapat dicatat tanpa API</span>
        </div>
    </div>

    <!-- 3. HASIL LIVE TRACKING AKTIF (JIKA ADA PERMINTAAN LACAK) -->
    <?php if ($track_result): 
        $direct_web_url = class_exists('PK01_Shipping_Engine') && method_exists('PK01_Shipping_Engine', 'get_direct_tracking_url')
            ? PK01_Shipping_Engine::get_direct_tracking_url($track_result['courier'], $track_result['waybill'])
            : ($track_result['direct_link'] ?? '#');
    ?>
    <section class="pk01-live-track-box">
        <div class="pk01-track-header">
            <div>
                <span style="font-size:18px; font-weight:800; color:#38bdf8;"><?php echo esc_html($track_result['courier']); ?></span>
                <span style="font-family:monospace; margin-left:10px; color:#cbd5e1; font-weight:700;">#<?php echo esc_html($track_result['waybill']); ?></span>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
                <span style="background:#10b981; color:#fff; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:700;">
                    <?php echo esc_html($track_result['status_label'] ?? $track_result['status']); ?>
                </span>
                <?php if ($direct_web_url !== '#'): ?>
                    <a href="<?php echo esc_url($direct_web_url); ?>" target="_blank" class="pk01-btn pk01-btn-export" style="padding:4px 10px;font-size:11px;">
                        🔗 Buka Web Kurir &rarr;
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div style="font-size:13px;color:#cbd5e1;margin-bottom:12px;line-height:1.5;">
            Pengirim: <b><?php echo esc_html($track_result['shipper'] ?? '-'); ?></b> &rarr; Penerima: <b><?php echo esc_html($track_result['receiver'] ?? '-'); ?></b> 
            <?php if (!empty($track_result['destination'])): ?>
                &bull; Tujuan: <b><?php echo esc_html($track_result['destination']); ?></b>
            <?php endif; ?>
        </div>

        <div>
            <strong style="font-size:12px; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px;">Kronologi Riwayat Perjalanan Paket:</strong>
            <div class="pk01-timeline-list">
                <?php if (!empty($track_result['history'])): ?>
                    <?php foreach ($track_result['history'] as $h): ?>
                        <div class="pk01-timeline-node">
                            <strong><?php echo esc_html($h['date']); ?> <?php echo !empty($h['location']) ? '('.esc_html($h['location']).')' : ''; ?></strong>
                            <span><?php echo esc_html($h['desc']); ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="font-size:13px; color:#94a3b8; padding:8px 0;">
                        <?php echo esc_html($track_result['message'] ?? 'Belum ada data pergerakan paket dari gateway ekspedisi.'); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 4. FORM INPUT RESI BARU DENGAN AUTO-FILL PESANAN -->
    <?php if ($can_manage): ?>
    <section class="pk01-surface">
        <div class="pk01-surface-head">
            <h3>📦 Daftarkan Resi Pengiriman Baru</h3>
            <span style="font-size:12px;color:#64748b;">Pilih pesanan siap kirim untuk mengisi data otomatis</span>
        </div>

        <form method="post" action="">
            <?php echo wp_nonce_field('pk01_create_ship_action', 'pk01_ship_nonce', true, false); ?>
            <input type="hidden" name="pk01_create_shipment" value="1">

            <div class="pk01-form-grid">
                <div class="pk01-field-item" style="grid-column: 1 / -1;">
                    <label>Tautkan ke Pesanan Pelanggan (Otomatis Isi Data Nama, HP &amp; Alamat)</label>
                    <select name="ship_sale_id" id="pk01-order-selector" class="pk01-input" required>
                        <option value="0">— Pilih order yang sudah selesai packing —</option>
                        <?php foreach ($pending_orders as $po): ?>
                            <option value="<?php echo (int)$po['id']; ?>" 
                                    data-name="<?php echo esc_attr($po['customer_name']); ?>" 
                                    data-phone="<?php echo esc_attr($po['customer_phone']); ?>" 
                                    data-destination="<?php echo esc_attr($po['destination']); ?>">
                                [<?php echo esc_html($po['order_no'] ?: '#' . $po['id']); ?>] <?php echo esc_html($po['customer_name']); ?> &bull; <?php echo esc_html($po['destination']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pk01-field-item">
                    <label>Saluran Penjualan (Sumber)</label>
                    <select name="ship_source" class="pk01-input">
                        <option value="website">Toko Online / Website</option>
                        <option value="seller">Mitra Seller / Afiliasi</option>
                        <option value="marketplace">Marketplace (Shopee / Tokopedia)</option>
                        <option value="offline">Offline / WhatsApp Langsung</option>
                    </select>
                </div>

                <div class="pk01-field-item">
                    <label>Ekspedisi / Kurir <span style="color:#dc2626;">*</span></label>
                    <select name="ship_courier" id="pk01-courier-select" class="pk01-input" required>
                        <option value="">— Pilih Ekspedisi —</option>
                        <?php 
                        foreach ($active_couriers as $ck):
                            $c_label = $courier_names[$ck] ?? strtoupper($ck);
                        ?>
                            <option value="<?php echo esc_attr($ck); ?>"><?php echo esc_html($c_label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pk01-field-item">
                    <label>Layanan Kurir</label>
                    <input type="text" name="ship_service" class="pk01-input" value="REG" placeholder="REG / JTR Kargo / Best / Yes">
                </div>

                <div class="pk01-field-item">
                    <label>Nomor Resi / AWB <span style="color:#dc2626;">*</span></label>
                    <input type="text" name="ship_tracking_no" class="pk01-input" placeholder="Contoh: JP1234567890 / SOCAG..." required style="font-family:monospace; font-weight:700;">
                </div>

                <div class="pk01-field-item">
                    <label>Nama Penerima <span style="color:#dc2626;">*</span></label>
                    <input type="text" name="ship_recipient_name" id="pk01-rec-name" class="pk01-input" placeholder="Nama penerima paket" required>
                </div>

                <div class="pk01-field-item">
                    <label>No. WhatsApp Penerima <span style="color:#dc2626;">*</span></label>
                    <input type="tel" name="ship_recipient_phone" id="pk01-rec-phone" class="pk01-input" placeholder="08xxxxxxxxxx" required>
                </div>

                <div class="pk01-field-item" style="grid-column: 1 / -1;">
                    <label>Alamat Tujuan Pengiriman Lengkap <span style="color:#dc2626;">*</span></label>
                    <input type="text" name="ship_destination" id="pk01-rec-dest" class="pk01-input" placeholder="Jalan, RT/RW, Kelurahan, Kecamatan, Kota, Provinsi, Kode Pos" required>
                </div>
            </div>

            <div style="margin-top:16px;">
                <button class="pk01-btn pk01-btn-primary" type="submit">
                    🚚 Buat Resi dari Order yang Sudah Packing
                </button>
            </div>
        </form>
    </section>
    <?php endif; ?>

    <!-- 5. FILTER STATUS CHIPS & PENCARIAN RESI -->
    <div class="pk01-filter-bar">
        <div class="pk01-filter-chips">
            <button type="button" class="pk01-chip-btn active" data-filter="all">Semua Resi (<?php echo count($rows); ?>)</button>
            <button type="button" class="pk01-chip-btn" data-filter="active">Dalam Pengiriman (<?php echo (int)$count_active; ?>)</button>
            <button type="button" class="pk01-chip-btn" data-filter="delivered">Terkirim (<?php echo (int)$count_delivered; ?>)</button>
            <button type="button" class="pk01-chip-btn" data-filter="failed">Gagal / Retur (<?php echo (int)$count_failed; ?>)</button>
        </div>
        
        <div>
            <input type="search" id="pk01-search-ship" class="pk01-input" placeholder="🔍 Cari no resi, penerima, kurir..." style="width:260px;">
        </div>
    </div>

    <!-- 6. TABEL DATA RIWAYAT PENGIRIMAN -->
    <div class="pk01-table-wrap">
        <table id="pk01-table-shipments" class="pk01-shp-table">
            <thead>
                <tr>
                    <th style="width:140px;">No. Resi (AWB)</th>
                    <th>Kurir &amp; Layanan</th>
                    <th>Tujuan &amp; Penerima</th>
                    <th>No. Pesanan</th>
                    <th style="text-align:center;width:120px;">Status</th>
                    <th>Terakhir Diperbarui</th>
                    <th style="text-align:center;width:190px;">Aksi Cepat</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($rows)): ?>
                    <?php foreach ($rows as $r): 
                        $st = strtolower($r['status'] ?? 'on_process');
                        $badge_class = 'st-shipping';
                        $badge_label = 'Dalam Pengiriman';
                        $filter_tag  = 'active';

                        if ($st === 'delivered' || $st === 'selesai') {
                            $badge_class = 'st-delivered';
                            $badge_label = 'Terkirim (Selesai)';
                            $filter_tag  = 'delivered';
                        } elseif (in_array($st, ['delivery_failed', 'returned', 'retur', 'gagal'])) {
                            $badge_class = 'st-failed';
                            $badge_label = 'Gagal / Retur';
                            $filter_tag  = 'failed';
                        }

                        // WhatsApp Link & Pesan
                        $wa_phone = preg_replace('/[^0-9]/', '', (string)($r['recipient_phone'] ?? ''));
                        if (strpos($wa_phone, '0') === 0) {
                            $wa_phone = '62' . substr($wa_phone, 1);
                        }
                        $wa_text = rawurlencode("Halo Kak {$r['recipient_name']}, pesanan Anda (" . ($r['order_ref'] ?: 'Order Toko') . ") telah dikirimkan via *" . strtoupper($r['courier']) . "* dengan Nomor Resi: *{$r['tracking_no']}*. Terima kasih telah berbelanja di toko kami!");

                        // Direct Tracking Link Resmi / CekResi
                        $direct_url = class_exists('PK01_Shipping_Engine') && method_exists('PK01_Shipping_Engine', 'get_direct_tracking_url')
                            ? PK01_Shipping_Engine::get_direct_tracking_url($r['courier'], $r['tracking_no'])
                            : 'https://cekresi.com/?noresi=' . urlencode($r['tracking_no']);
                    ?>
                    <tr data-status="<?php echo esc_attr($filter_tag); ?>">
                        <td>
                            <code style="background:#f1f5f9; padding:3px 6px; border-radius:4px; font-weight:700; font-family:monospace; color:#0f172a; border:1px solid #e2e8f0;">
                                <?php echo esc_html($r['tracking_no']); ?>
                            </code>
                        </td>
                        <td>
                            <strong><?php echo esc_html(strtoupper($r['courier'])); ?></strong> 
                            <span style="font-size:11px; color:#64748b;">(<?php echo esc_html($r['service'] ?: 'REG'); ?>)</span>
                        </td>
                        <td>
                            <strong><?php echo esc_html($r['recipient_name']); ?></strong>
                            <div style="font-size:11px; color:#64748b;"><?php echo esc_html($r['destination']); ?></div>
                        </td>
                        <td>
                            <strong style="color:#2563eb;font-family:monospace;"><?php echo esc_html($r['order_ref'] ?: '—'); ?></strong>
                        </td>
                        <td style="text-align:center;">
                            <span class="pk01-status-pill <?php echo esc_attr($badge_class); ?>">
                                <?php echo esc_html($badge_label); ?>
                            </span>
                        </td>
                        <td style="font-size:12px; color:#64748b; font-family:monospace;">
                            <?php echo esc_html(!empty($r['last_event_at']) ? date('d/m/Y H:i', strtotime($r['last_event_at'])) : date('d/m/Y H:i', strtotime($r['created_at']))); ?>
                        </td>
                        <td style="text-align:center;">
                            <div style="display:inline-flex; gap:4px; align-items:center;">
                                <!-- 1. Catat milestone manual (selalu tersedia, tanpa API kurir) -->
                                <details style="display:inline-block;">
                                    <summary class="pk01-btn-track" style="list-style:none;cursor:pointer;">✍️ Update</summary>
                                    <form method="post" action="" style="position:absolute;z-index:20;background:#fff;border:1px solid #cbd5e1;border-radius:10px;padding:10px;width:260px;box-shadow:0 10px 30px rgba(0,0,0,.15);margin-top:6px;">
                                        <?php echo wp_nonce_field('pk01_manual_tracking_action', 'pk01_manual_tracking_nonce', true, false); ?>
                                        <input type="hidden" name="pk01_manual_tracking" value="1">
                                        <input type="hidden" name="manual_shipment_id" value="<?php echo (int)$r['id']; ?>">
                                        <select name="manual_status" required style="width:100%;margin-bottom:6px;">
                                            <?php foreach ((class_exists('PK01_Shipping_Smart') ? PK01_Shipping_Smart::status_labels() : []) as $ms=>$ml): ?><option value="<?php echo esc_attr($ms); ?>"><?php echo esc_html($ml); ?></option><?php endforeach; ?>
                                        </select>
                                        <input type="text" name="manual_location" placeholder="Lokasi/hub (opsional)" style="width:100%;margin-bottom:6px;">
                                        <input type="datetime-local" name="manual_event_time" style="width:100%;margin-bottom:6px;">
                                        <textarea name="manual_description" placeholder="Keterangan, bukti WA/nota/konfirmasi kurir..." rows="3" style="width:100%;margin-bottom:6px;"></textarea>
                                        <button type="submit" class="pk01-btn pk01-btn-primary" style="width:100%;justify-content:center;">Simpan Milestone</button>
                                    </form>
                                </details>

                                <!-- 2. Sinkronisasi API (opsional) (opsional) -->
                                <form method="post" action="" style="margin:0;">
                                    <?php echo wp_nonce_field('pk01_track_action_verify', 'pk01_track_nonce', true, false); ?>
                                    <input type="hidden" name="pk01_track_action" value="1">
                                    <input type="hidden" name="track_tracking_no" value="<?php echo esc_attr($r['tracking_no']); ?>">
                                    <input type="hidden" name="track_courier" value="<?php echo esc_attr($r['courier']); ?>">
                                    <button type="submit" class="pk01-btn-track" title="Sinkronisasi otomatis jika API tersedia">
                                        🔄 API
                                    </button>
                                </form>

                                <!-- 2. Tautan Lacak Langsung Web Kurir Resmi -->
                                <a href="<?php echo esc_url($direct_url); ?>" target="_blank" class="pk01-btn-direct" title="Buka Halaman Web Lacak Kurir Resmi">
                                    🔗 Web
                                </a>

                                <!-- 3. Kirim Resi ke WhatsApp Pelanggan -->
                                <?php if (!empty($wa_phone)): ?>
                                    <a href="https://api.whatsapp.com/send?phone=<?php echo esc_attr($wa_phone); ?>&text=<?php echo $wa_text; ?>" 
                                       target="_blank" 
                                       class="pk01-btn-wa" 
                                       title="Kirim Notifikasi Resi ke WhatsApp Pelanggan">
                                        💬 WA
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align:center; padding:36px; color:#94a3b8;">
                            Belum ada riwayat pengiriman barang. Daftarkan nomor resi baru pada formulir di atas.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. AUTO-FILL DATA PELANGGAN SAAT PESANAN DIPILIH
    var orderSelect = document.getElementById('pk01-order-selector');
    var recName     = document.getElementById('pk01-rec-name');
    var recPhone    = document.getElementById('pk01-rec-phone');
    var recDest     = document.getElementById('pk01-rec-dest');

    if (orderSelect) {
        orderSelect.addEventListener('change', function() {
            var opt = this.options[this.selectedIndex];
            if (opt && opt.value !== '0') {
                if (recName)  recName.value  = opt.getAttribute('data-name') || '';
                if (recPhone) recPhone.value = opt.getAttribute('data-phone') || '';
                if (recDest)  recDest.value  = opt.getAttribute('data-destination') || '';
            }
        });
    }

    // 2. LIVE SEARCH & FILTER STATUS RESI
    var searchInput = document.getElementById('pk01-search-ship');
    var table       = document.getElementById('pk01-table-shipments');
    var chipBtns    = document.querySelectorAll('.pk01-chip-btn');
    var activeFilter = 'all';

    function applyShipmentFilters() {
        if (!table) return;
        var query = searchInput ? searchInput.value.toLowerCase().trim() : '';
        var rows  = table.querySelectorAll('tbody tr');

        rows.forEach(function(row) {
            var rowStatus = row.getAttribute('data-status') || '';
            var text      = row.innerText.toLowerCase();

            var matchesSearch = (text.indexOf(query) > -1);
            var matchesChip   = (activeFilter === 'all' || rowStatus === activeFilter);

            if (matchesSearch && matchesChip) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyShipmentFilters);
    }

    if (chipBtns.length > 0) {
        chipBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                chipBtns.forEach(function(b) { b.classList.remove('active'); });
                this.classList.add('active');
                activeFilter = this.dataset.filter;
                applyShipmentFilters();
            });
        });
    }
});
</script>