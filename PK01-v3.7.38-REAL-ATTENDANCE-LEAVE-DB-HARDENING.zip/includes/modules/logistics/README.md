# PK01 — Modul Logistics

Folder canonical: `includes/modules/logistics/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/logistics/core/class-pk01-shipping-smart.php`
- `includes/modules/logistics/packing/tampilan-packing.php`
- `includes/modules/logistics/shipping/tampilan-pengiriman.php`
- `includes/modules/logistics/tracking/tampilan-lacak-resi.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
