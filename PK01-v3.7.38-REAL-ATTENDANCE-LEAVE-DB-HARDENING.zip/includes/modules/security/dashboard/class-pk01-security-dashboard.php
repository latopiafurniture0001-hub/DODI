<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Canonical Security & CCTV Dashboard Controller
 * Smart Multi-Path Resolver, Strict Role Authorization & Autonomous Built-in Cockpit Engine.
 */
class PK01_Security_Dashboard {

    /**
     * Memeriksa hak akses dan otorisasi role pengguna
     */
    public static function can_access() {
        if (!is_user_logged_in()) return false;
        if (current_user_can('manage_options')) return true;

        if (class_exists('PK01_Authorization')) {
            if (PK01_Authorization::can('security') || PK01_Authorization::can('administration')) {
                return true;
            }
            $eff = PK01_Authorization::effective_role();
            if (in_array($eff, ['administrator', 'pk01_admin', 'pk01_security', 'shop_manager'], true)) {
                return true;
            }
        }

        $roles = (array) wp_get_current_user()->roles;
        return (bool) array_intersect(['administrator', 'pk01_admin', 'pk01_security', 'shop_manager'], $roles);
    }

    /**
     * Render Utama Dashboard Keamanan & CCTV
     */
    public static function render() {
        if (!self::can_access()) {
            return '
            <div style="max-width:540px;margin:40px auto;padding:26px;background:#fff;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
                <div style="font-size:38px;margin-bottom:8px;">🔒</div>
                <strong style="font-size:16px;color:#0f172a;">Akses Dibatasi</strong>
                <p style="color:#64748b;font-size:13px;margin:6px 0 16px;">Anda tidak memiliki hak otorisasi untuk membuka Pos Kendali Keamanan &amp; CCTV.</p>
                ' . (is_user_logged_in() ? '' : '<a href="' . esc_url(wp_login_url()) . '" style="display:inline-block;padding:8px 18px;background:#0f172a;color:#fff;border-radius:8px;text-decoration:none;font-size:12px;font-weight:700;">Login Sekarang</a>') . '
            </div>';
        }

        // 1. SMART MULTI-PATH RESOLVER (Cek file eksternal terlebih dahulu)
        $candidate_paths = [];
        if (defined('PK01_DIR')) {
            $candidate_paths[] = PK01_DIR . 'includes/modules/security/dashboard/tampilan-security.php';
            $candidate_paths[] = PK01_DIR . 'includes/security/tampilan-security.php';
            $candidate_paths[] = PK01_DIR . 'views/tampilan-security.php';
        }

        foreach ($candidate_paths as $path) {
            if ($path && file_exists($path) && is_readable($path)) {
                ob_start();
                include $path;
                return ob_get_clean();
            }
        }

        // 2. AUTONOMOUS BUILT-IN SECURITY COCKPIT (100% NON-DUMMY & MANDIRI)
        return self::render_autonomous_cockpit();
    }

    /**
     * Mesin Mandiri: Menampilkan Antarmuka Keamanan Lengkap dari Basis Data Riil
     */
    private static function render_autonomous_cockpit() {
        global $wpdb;

        $t = function($k) use ($wpdb) {
            $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k;
            return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
        };

        $t_visitors = $t('security_visitors');
        $t_visits   = $t('security_visitor_visits');
        $t_vehicles = $t('security_vehicles');
        $t_goods    = $t('security_goods');
        $t_incident = $t('security_incidents');
        $t_cctv     = $t('security_cctv_cameras');

        // Query Statistik Real-Time
        $stats = [
            'visitors_inside' => ($t_visits) ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_visits}` WHERE status = 'inside'") : 0,
            'vehicles_inside' => ($t_vehicles) ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_vehicles}` WHERE status = 'inside'") : 0,
            'goods_pending'   => ($t_goods) ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_goods}` WHERE status = 'pending'") : 0,
            'open_incidents'  => ($t_incident) ? (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t_incident}` WHERE status = 'open'") : 0,
        ];

        // Data Transaksional Riil
        $visitors_list = [];
        if ($t_visits && $t_visitors) {
            $visitors_list = $wpdb->get_results("
                SELECT vv.id AS visit_id, vv.status AS visit_status, vv.purpose, vv.host_name, vv.vehicle_plate, vv.checkin_at, vv.checkout_at,
                       v.id AS visitor_id, v.visitor_no, v.name, v.phone, v.company, v.ktp_file
                FROM `{$t_visits}` vv
                LEFT JOIN `{$t_visitors}` v ON v.id = vv.visitor_id
                ORDER BY vv.id DESC LIMIT 60
            ", ARRAY_A) ?: [];
        }

        $vehicles_list = ($t_vehicles) ? $wpdb->get_results("SELECT * FROM `{$t_vehicles}` ORDER BY id DESC LIMIT 60", ARRAY_A) ?: [] : [];
        $goods_list    = ($t_goods) ? $wpdb->get_results("SELECT * FROM `{$t_goods}` ORDER BY id DESC LIMIT 60", ARRAY_A) ?: [] : [];
        $incident_list = ($t_incident) ? $wpdb->get_results("SELECT * FROM `{$t_incident}` ORDER BY id DESC LIMIT 60", ARRAY_A) ?: [] : [];
        $cameras_list  = ($t_cctv) ? $wpdb->get_results("SELECT * FROM `{$t_cctv}` ORDER BY id ASC LIMIT 20", ARRAY_A) ?: [] : [];

        $rest_base  = esc_url_raw(rest_url('pk01/v1/security/'));
        $rest_nonce = wp_create_nonce('wp_rest');

        ob_start();
        ?>
        <style>
        :root {
            --pk-slate-950: #090d16;
            --pk-slate-900: #0f172a;
            --pk-slate-800: #1e293b;
            --pk-slate-700: #334155;
            --pk-slate-600: #475569;
            --pk-slate-200: #e2e8f0;
            --pk-slate-100: #f1f5f9;
            --pk-slate-50:  #f8fafc;
            --pk-indigo:    #4f46e5;
            --pk-indigo-hover: #4338ca;
            --pk-emerald:   #10b981;
            --pk-amber:     #f59e0b;
            --pk-rose:      #ef4444;
            --pk-sky:       #0284c7;
            --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
        }

        .pk01-sec-app {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            color: #1e293b;
            max-width: 1440px;
            margin: 15px auto 50px;
        }
        .pk01-sec-app * { box-sizing: border-box; }

        /* 1. Hero Cockpit Header */
        .pk01-sec-hero {
            background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
            border-radius: 18px;
            padding: 26px 32px;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 22px;
            box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .pk01-hero-left h1 {
            font-size: 24px;
            font-weight: 800;
            color: #f8fafc;
            margin: 6px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .pk01-hero-left p {
            font-size: 13.5px;
            color: #94a3b8;
            margin: 0;
            max-width: 780px;
            line-height: 1.5;
        }
        .pk01-hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(99, 102, 241, 0.25);
            border: 1px solid rgba(165, 180, 252, 0.35);
            color: #c7d2fe;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.8px;
            text-transform: uppercase;
        }
        .pk01-status-widget {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 14px;
            padding: 12px 20px;
            text-align: right;
            backdrop-filter: blur(6px);
        }
        .pk01-ping-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #4ade80;
            box-shadow: 0 0 8px #4ade80;
            animation: pkPulseGreen 2s infinite;
        }
        @keyframes pkPulseGreen {
            0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
            70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
            100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
        }

        /* 2. Executive 4 KPI Cards */
        .pk01-kpi-deck {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 22px;
        }
        @media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

        .pk01-kpi-card {
            background: #ffffff;
            border: 1px solid var(--pk-slate-200);
            border-radius: 14px;
            padding: 18px 20px;
            box-shadow: var(--pk-shadow);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .pk01-kpi-card::before {
            content: "";
            position: absolute;
            top: 0; left: 0; bottom: 0; width: 4px;
        }
        .pk01-kpi-card.c-blue::before    { background: var(--pk-indigo); }
        .pk01-kpi-card.c-sky::before     { background: var(--pk-sky); }
        .pk01-kpi-card.c-amber::before   { background: var(--pk-amber); }
        .pk01-kpi-card.c-rose::before    { background: var(--pk-rose); }

        .pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
        .pk01-kpi-val { font-size: 26px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; }
        .pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

        /* 3. Modern Scrollable Tabs */
        .pk01-nav-tabs {
            background: #ffffff;
            border: 1px solid var(--pk-slate-200);
            border-radius: 14px;
            padding: 6px;
            display: flex;
            gap: 6px;
            overflow-x: auto;
            margin-bottom: 22px;
            box-shadow: var(--pk-shadow);
        }
        .pk01-tab-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            font-size: 13px;
            font-weight: 700;
            color: var(--pk-slate-600);
            border: none;
            background: transparent;
            cursor: pointer;
            border-radius: 10px;
            white-space: nowrap;
            transition: all 0.15s ease;
        }
        .pk01-tab-btn:hover { background: var(--pk-slate-100); color: var(--pk-slate-900); }
        .pk01-tab-btn.is-active { background: var(--pk-slate-900); color: #ffffff; }

        /* Panes */
        .pk01-pane { display: none; }
        .pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
        @keyframes pk01FadeIn {
            from { opacity: 0; transform: translateY(4px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Surfaces */
        .pk01-surface {
            background: #ffffff;
            border: 1px solid var(--pk-slate-200);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--pk-shadow);
        }
        .pk01-surface-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--pk-slate-100);
            padding-bottom: 14px;
            margin-bottom: 18px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .pk01-surface-header h3 {
            margin: 0;
            font-size: 17px;
            font-weight: 800;
            color: var(--pk-slate-900);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Forms */
        .pk01-form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
        }
        .pk01-form-group { display: flex; flex-direction: column; gap: 6px; }
        .pk01-form-group label { font-size: 12px; font-weight: 700; color: var(--pk-slate-700); }
        .pk01-ctrl {
            width: 100%;
            padding: 9px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 13px;
            background: #ffffff;
            outline: none;
            transition: all 0.2s;
        }
        .pk01-ctrl:focus {
            border-color: var(--pk-indigo);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
        }

        /* Tables */
        .pk01-table-card {
            overflow-x: auto;
            border: 1px solid var(--pk-slate-200);
            border-radius: 12px;
        }
        .pk01-tbl {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            text-align: left;
        }
        .pk01-tbl th {
            background: #f8fafc;
            padding: 12px 14px;
            font-weight: 700;
            color: #475569;
            border-bottom: 2px solid var(--pk-slate-200);
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
        }
        .pk01-tbl td {
            padding: 12px 14px;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }
        .pk01-tbl tr:hover td { background: #fbfcfe; }

        /* Badges & Buttons */
        .pk01-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 8px 16px;
            font-size: 12.5px;
            font-weight: 700;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            text-decoration: none !important;
            transition: all 0.2s ease;
        }
        .pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
        .pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
        .pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
        .pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
        .pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
        .pk01-btn-danger  { background: var(--pk-rose); color: #ffffff !important; }
        .pk01-btn-sm { padding: 4px 10px; font-size: 11.5px; border-radius: 6px; }

        .pk01-code-badge {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            font-weight: 700;
            background: #f1f5f9;
            padding: 2px 6px;
            border-radius: 4px;
            border: 1px solid #e2e8f0;
            color: #0f172a;
            font-size: 11.5px;
        }
        .pk01-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 700;
        }
        .badge-inside   { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .badge-out      { background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; }
        .badge-pending  { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
        .badge-verified { background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe; }
        .badge-incident { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

        /* CCTV Grid */
        .pk01-cctv-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 18px;
        }
        .pk01-cctv-card {
            background: #090d16;
            border: 1px solid var(--pk-slate-700);
            border-radius: 14px;
            overflow: hidden;
            color: #fff;
            box-shadow: var(--pk-shadow);
        }
        .pk01-cctv-viewport {
            height: 190px;
            background: #020617;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            border-bottom: 1px solid #1e293b;
        }
        .pk01-cctv-info {
            padding: 14px 18px;
            background: #0f172a;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        </style>

        <div class="pk01-sec-app">

            <!-- 1. HERO COCKPIT HEADER -->
            <header class="pk01-sec-hero">
                <div class="pk01-hero-left">
                    <span class="pk01-hero-badge">PHYSICAL SECURITY &bull; GATE &amp; CCTV OPERATIONS</span>
                    <h1>🛡️ Pos Kendali Keamanan &amp; Gerbang Terpadu</h1>
                    <p>
                        Pengawasan terpusat: Registrasi tamu dengan identitas KTP terenkripsi [3], pos gerbang kendaraan logistik, verifikasi muatan keluar/masuk, mitigasi insiden K3, dan CCTV live stream [3].
                    </p>
                </div>
                <div class="pk01-status-widget">
                    <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                        <span class="pk01-ping-dot"></span>
                        <span>POS GERBANG SIAGA</span>
                    </div>
                    <div style="font-size:11px; color:#cbd5e1; margin-top:3px;" id="pk01-sec-live-clock">
                        <?php echo date_i18n('d M Y, H:i'); ?> WIB &bull; Enkripsi AES-256 [3]
                    </div>
                </div>
            </header>

            <!-- 2. EXECUTIVE 4 KPI CARDS -->
            <section class="pk01-kpi-deck">
                <div class="pk01-kpi-card c-blue">
                    <div class="pk01-kpi-label">Tamu Aktif di Lokasi</div>
                    <div class="pk01-kpi-val"><?php echo number_format($stats['visitors_inside']); ?></div>
                    <div class="pk01-kpi-sub">Orang di dalam area pabrik/kantor</div>
                </div>

                <div class="pk01-kpi-card c-sky">
                    <div class="pk01-kpi-label">Kendaraan di Area Gerbang</div>
                    <div class="pk01-kpi-val"><?php echo number_format($stats['vehicles_inside']); ?></div>
                    <div class="pk01-kpi-sub">Truk ekspedisi, pikap &amp; kendaraan operasional</div>
                </div>

                <div class="pk01-kpi-card c-amber">
                    <div class="pk01-kpi-label">Pemeriksaan Barang Pending</div>
                    <div class="pk01-kpi-val" style="color:#d97706;"><?php echo number_format($stats['goods_pending']); ?></div>
                    <div class="pk01-kpi-sub">Menunggu verifikasi fisik surat jalan</div>
                </div>

                <div class="pk01-kpi-card c-rose">
                    <div class="pk01-kpi-label">Laporan Insiden Aktif</div>
                    <div class="pk01-kpi-val" style="<?php echo ($stats['open_incidents'] > 0) ? 'color:#dc2626;' : 'color:#059669;'; ?>">
                        <?php echo number_format($stats['open_incidents']); ?>
                    </div>
                    <div class="pk01-kpi-sub">Insiden keamanan &amp; K3 terbuka</div>
                </div>
            </section>

            <!-- 3. TABS NAVIGASI WORKFLOW -->
            <nav class="pk01-nav-tabs" aria-label="Menu Keamanan">
                <button type="button" class="pk01-tab-btn is-active" data-target="tab-sec-visitors">
                    🎫 Buku Tamu &amp; KTP (<?php echo count($visitors_list); ?>)
                </button>
                <button type="button" class="pk01-tab-btn" data-target="tab-sec-vehicles">
                    🚛 Gerbang Kendaraan (<?php echo count($vehicles_list); ?>)
                </button>
                <button type="button" class="pk01-tab-btn" data-target="tab-sec-goods">
                    📦 Pemeriksaan Muatan Barang (<?php echo count($goods_list); ?>)
                </button>
                <button type="button" class="pk01-tab-btn" data-target="tab-sec-incidents">
                    🚨 Laporan Insiden &amp; K3 (<?php echo count($incident_list); ?>)
                </button>
                <button type="button" class="pk01-tab-btn" data-target="tab-sec-cctv">
                    📹 CCTV Live Grid (<?php echo count($cameras_list); ?>)
                </button>
            </nav>

            <!-- 4. TAB 1: BUKU TAMU & KTP TERENKRIPSI -->
            <div class="pk01-pane is-active" id="tab-sec-visitors">
                <div class="pk01-surface">
                    <div class="pk01-surface-header">
                        <div>
                            <h3>🎫 Registrasi Tamu &amp; Identitas Terenkripsi</h3>
                            <div style="font-size:12px; color:#64748b; margin-top:2px;">
                                Seluruh foto KTP fisik dienkripsi otomatis secara privat dengan sandi AES-256-CBC demi kepatuhan perlindungan data pribadi [3].
                            </div>
                        </div>
                    </div>

                    <!-- Form Checkin Tamu -->
                    <form id="form_pk01_sec_visitor" enctype="multipart/form-data" style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px; margin-bottom:24px;">
                        <div class="pk01-form-grid">
                            <div class="pk01-form-group">
                                <label>Nama Lengkap Tamu <span style="color:#ef4444;">*</span></label>
                                <input name="name" class="pk01-ctrl" required placeholder="Nama tamu">
                            </div>
                            <div class="pk01-form-group">
                                <label>NIK KTP (16 Digit)</label>
                                <input name="nik" class="pk01-ctrl" maxlength="16" placeholder="320xxxxxxxxxxxxx">
                            </div>
                            <div class="pk01-form-group">
                                <label>No. HP / WhatsApp</label>
                                <input name="phone" class="pk01-ctrl" placeholder="08xxxxxxxxxx">
                            </div>
                            <div class="pk01-form-group">
                                <label>Instansi / Perusahaan</label>
                                <input name="company" class="pk01-ctrl" placeholder="Vendor / Supplier / Tamu Pribadi">
                            </div>
                            <div class="pk01-form-group">
                                <label>Tujuan Divisi / Orang yang Ditemui <span style="color:#ef4444;">*</span></label>
                                <input name="host_name" class="pk01-ctrl" placeholder="Contoh: HRD / Bagian Produksi" required>
                            </div>
                            <div class="pk01-form-group">
                                <label>Keperluan Kunjungan <span style="color:#ef4444;">*</span></label>
                                <input name="purpose" class="pk01-ctrl" placeholder="Meeting / Kirim Sampel / Dinas" required>
                            </div>
                            <div class="pk01-form-group">
                                <label>Nomor Polisi Kendaraan</label>
                                <input name="vehicle_plate" class="pk01-ctrl" placeholder="B 1234 XYZ">
                            </div>
                            <div class="pk01-form-group">
                                <label>Foto KTP Fisik (Upload &amp; Enkripsi)</label>
                                <input type="file" name="ktp" accept="image/*" class="pk01-ctrl" style="padding:5px;">
                            </div>
                        </div>
                        <div style="margin-top:16px;">
                            <button type="submit" class="pk01-btn pk01-btn-primary">
                                📥 Catat Check-in Tamu &amp; Kunci Identitas
                            </button>
                        </div>
                    </form>

                    <!-- Tabel Tamu -->
                    <div class="pk01-table-card">
                        <table class="pk01-tbl">
                            <thead>
                                <tr>
                                    <th>No. Tamu</th>
                                    <th>Identitas Tamu</th>
                                    <th>Instansi</th>
                                    <th>Tujuan &amp; Host</th>
                                    <th>Waktu Masuk</th>
                                    <th style="text-align:center;">Foto KTP</th>
                                    <th style="text-align:center;">Status</th>
                                    <th style="text-align:center; width:120px;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($visitors_list)): ?>
                                    <tr><td colspan="8" style="text-align:center; padding:30px; color:#94a3b8;">Belum ada log kunjungan tamu yang tercatat.</td></tr>
                                <?php else: foreach ($visitors_list as $v): ?>
                                    <tr>
                                        <td><span class="pk01-code-badge"><?php echo esc_html($v['visitor_no']); ?></span></td>
                                        <td>
                                            <strong><?php echo esc_html($v['name']); ?></strong>
                                            <?php if (!empty($v['phone'])): ?><div style="font-size:11px; color:#64748b;"><?php echo esc_html($v['phone']); ?></div><?php endif; ?>
                                        </td>
                                        <td><?php echo esc_html($v['company'] ?: 'Pribadi'); ?></td>
                                        <td>
                                            <strong><?php echo esc_html($v['host_name']); ?></strong>
                                            <div style="font-size:11px; color:#64748b;"><?php echo esc_html($v['purpose']); ?></div>
                                        </td>
                                        <td><?php echo esc_html(date_i18n('d M, H:i', strtotime($v['checkin_at']))); ?></td>
                                        <td style="text-align:center;">
                                            <?php if (!empty($v['ktp_file'])): ?>
                                                <button type="button" class="pk01-btn pk01-btn-subtle pk01-btn-sm btn-pk01-view-ktp" data-id="<?php echo (int)$v['visitor_id']; ?>">
                                                    🔒 Buka KTP [3]
                                                </button>
                                            <?php else: ?>
                                                <span style="font-size:11px; color:#94a3b8;">Tanpa Foto</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:center;">
                                            <span class="pk01-badge <?php echo $v['visit_status'] === 'inside' ? 'badge-inside' : 'badge-out'; ?>">
                                                ● <?php echo $v['visit_status'] === 'inside' ? 'Di Area' : 'Keluar'; ?>
                                            </span>
                                        </td>
                                        <td style="text-align:center;">
                                            <?php if ($v['visit_status'] === 'inside'): ?>
                                                <button type="button" class="pk01-btn pk01-btn-emerald pk01-btn-sm btn-pk01-checkout-visitor" data-id="<?php echo (int)$v['visit_id']; ?>">
                                                    ✓ Checkout
                                                </button>
                                            <?php else: ?>
                                                <span style="font-size:11px; color:#94a3b8;">Selesai</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 5. TAB 2: GERBANG KENDARAAN -->
            <div class="pk01-pane" id="tab-sec-vehicles">
                <div class="pk01-surface">
                    <div class="pk01-surface-header">
                        <div>
                            <h3>🚛 Pos Gerbang Keluar Masuk Kendaraan</h3>
                            <div style="font-size:12px; color:#64748b; margin-top:2px;">Pencatatan nopol truk ekspedisi, pikap vendor, dan kendaraan dinas operasional.</div>
                        </div>
                    </div>

                    <form id="form_pk01_sec_vehicle" style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px; margin-bottom:24px;">
                        <div class="pk01-form-grid">
                            <div class="pk01-form-group">
                                <label>Nomor Polisi (Plat Nomor) <span style="color:#ef4444;">*</span></label>
                                <input name="plate" class="pk01-ctrl" required placeholder="B 1234 XYZ" style="text-transform:uppercase; font-weight:700;">
                            </div>
                            <div class="pk01-form-group">
                                <label>Nama Pengemudi / Supir</label>
                                <input name="driver_name" class="pk01-ctrl" placeholder="Nama supir">
                            </div>
                            <div class="pk01-form-group">
                                <label>Perusahaan / Ekspedisi</label>
                                <input name="company" class="pk01-ctrl" placeholder="J&amp;T Cargo / Logistik / Vendor">
                            </div>
                            <div class="pk01-form-group">
                                <label>Keperluan Masuk Gerbang</label>
                                <input name="purpose" class="pk01-ctrl" placeholder="Kirim Bahan Baku / Muat Paket">
                            </div>
                        </div>
                        <button type="submit" class="pk01-btn pk01-btn-primary" style="margin-top:16px;">
                            🚛 Catat Kendaraan Masuk
                        </button>
                    </form>

                    <div class="pk01-table-card">
                        <table class="pk01-tbl">
                            <thead>
                                <tr>
                                    <th>Nomor Polisi</th>
                                    <th>Supir &amp; Perusahaan</th>
                                    <th>Keperluan</th>
                                    <th>Waktu Masuk</th>
                                    <th>Waktu Keluar</th>
                                    <th style="text-align:center;">Status</th>
                                    <th style="text-align:center;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($vehicles_list)): ?>
                                    <tr><td colspan="7" style="text-align:center; padding:30px; color:#94a3b8;">Belum ada antrean kendaraan di gerbang.</td></tr>
                                <?php else: foreach ($vehicles_list as $veh): ?>
                                    <tr>
                                        <td><span class="pk01-code-badge" style="font-size:13px;"><?php echo esc_html($veh['plate']); ?></span></td>
                                        <td>
                                            <strong><?php echo esc_html($veh['driver_name'] ?: 'Supir'); ?></strong>
                                            <div style="font-size:11px; color:#64748b;"><?php echo esc_html($veh['company'] ?: '-'); ?></div>
                                        </td>
                                        <td><?php echo esc_html($veh['purpose']); ?></td>
                                        <td><?php echo esc_html(date_i18n('d M, H:i', strtotime($veh['checkin_at']))); ?></td>
                                        <td><?php echo $veh['checkout_at'] ? esc_html(date_i18n('d M, H:i', strtotime($veh['checkout_at']))) : '-'; ?></td>
                                        <td style="text-align:center;">
                                            <span class="pk01-badge <?php echo $veh['status'] === 'inside' ? 'badge-inside' : 'badge-out'; ?>">
                                                ● <?php echo $veh['status'] === 'inside' ? 'Di Area Gerbang' : 'Sudah Keluar'; ?>
                                            </span>
                                        </td>
                                        <td style="text-align:center;">
                                            <?php if ($veh['status'] === 'inside'): ?>
                                                <button type="button" class="pk01-btn pk01-btn-emerald pk01-btn-sm btn-pk01-checkout-vehicle" data-id="<?php echo (int)$veh['id']; ?>">
                                                    ✓ Keluar
                                                </button>
                                            <?php else: ?>
                                                <span style="font-size:11px; color:#94a3b8;">Selesai</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 6. TAB 3: PEMERIKSAAN BARANG MASUK / KELUAR -->
            <div class="pk01-pane" id="tab-sec-goods">
                <div class="pk01-surface">
                    <div class="pk01-surface-header">
                        <div>
                            <h3>📦 Gate Pass: Pemeriksaan Muatan Barang</h3>
                            <div style="font-size:12px; color:#64748b; margin-top:2px;">Verifikasi fisik muatan barang keluar/masuk agar sesuai surat jalan sebelum palang dibuka.</div>
                        </div>
                    </div>

                    <form id="form_pk01_sec_goods" style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px; margin-bottom:24px;">
                        <div class="pk01-form-grid">
                            <div class="pk01-form-group">
                                <label>Arah Muatan</label>
                                <select name="direction" class="pk01-ctrl" style="font-weight:700;">
                                    <option value="in">📥 Barang Masuk (Bahan Baku Gudang / Retur)</option>
                                    <option value="out">📤 Barang Keluar (Pengiriman Pesanan / Surat Jalan)</option>
                                </select>
                            </div>
                            <div class="pk01-form-group">
                                <label>Nomor Surat Jalan / Referensi</label>
                                <input name="reference_no" class="pk01-ctrl" placeholder="SJ-2026-001 / PO-99">
                            </div>
                            <div class="pk01-form-group" style="grid-column:span 2;">
                                <label>Deskripsi Muatan Barang <span style="color:#ef4444;">*</span></label>
                                <input name="description" class="pk01-ctrl" required placeholder="Contoh: 20 Lembar Plywood 18mm / 5 Box Produk Jadi">
                            </div>
                            <div class="pk01-form-group">
                                <label>Kuantitas &amp; Satuan</label>
                                <div style="display:flex; gap:6px;">
                                    <input type="number" step="any" name="qty" class="pk01-ctrl" placeholder="10" style="flex:1;">
                                    <input name="unit" class="pk01-ctrl" placeholder="pcs/box" value="pcs" style="width:75px;">
                                </div>
                            </div>
                            <div class="pk01-form-group">
                                <label>Nopol Kendaraan Pengangkut</label>
                                <input name="vehicle_plate" class="pk01-ctrl" placeholder="B 1234 CD">
                            </div>
                        </div>
                        <button type="submit" class="pk01-btn pk01-btn-primary" style="margin-top:16px;">
                            📝 Catat Tiket Pemeriksaan Gerbang
                        </button>
                    </form>

                    <div class="pk01-table-card">
                        <table class="pk01-tbl">
                            <thead>
                                <tr>
                                    <th>Kode Tiket</th>
                                    <th>Arah</th>
                                    <th>Muatan Barang</th>
                                    <th>Ref. Surat Jalan</th>
                                    <th>Nopol Kendaraan</th>
                                    <th style="text-align:center;">Status</th>
                                    <th style="text-align:center;">Verifikasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($goods_list)): ?>
                                    <tr><td colspan="7" style="text-align:center; padding:30px; color:#94a3b8;">Belum ada antrean pemeriksaan muatan barang.</td></tr>
                                <?php else: foreach ($goods_list as $gd): ?>
                                    <tr>
                                        <td><span class="pk01-code-badge"><?php echo esc_html($gd['security_code']); ?></span></td>
                                        <td>
                                            <span class="pk01-badge <?php echo $gd['direction'] === 'in' ? 'badge-inside' : 'badge-out'; ?>">
                                                <?php echo $gd['direction'] === 'in' ? '📥 Masuk' : '📤 Keluar'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong><?php echo esc_html($gd['description']); ?></strong>
                                            <div style="font-size:11px; color:#64748b;">Jumlah: <?php echo (float)$gd['qty']; ?> <?php echo esc_html($gd['unit']); ?></div>
                                        </td>
                                        <td><code><?php echo esc_html($gd['reference_no'] ?: '-'); ?></code></td>
                                        <td><?php echo esc_html($gd['vehicle_plate'] ?: '-'); ?></td>
                                        <td style="text-align:center;">
                                            <span class="pk01-badge <?php echo $gd['status'] === 'pending' ? 'badge-pending' : 'badge-verified'; ?>">
                                                ● <?php echo strtoupper($gd['status']); ?>
                                            </span>
                                        </td>
                                        <td style="text-align:center;">
                                            <?php if ($gd['status'] === 'pending'): ?>
                                                <button type="button" class="pk01-btn pk01-btn-emerald pk01-btn-sm btn-pk01-verify-goods" data-id="<?php echo (int)$gd['id']; ?>">
                                                    ✓ Loloskan Gerbang
                                                </button>
                                            <?php else: ?>
                                                <span style="font-size:11px; color:#059669; font-weight:700;">Selesai Terverifikasi</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 7. TAB 4: LAPORAN INSIDEN & K3 -->
            <div class="pk01-pane" id="tab-sec-incidents">
                <div class="pk01-surface">
                    <div class="pk01-surface-header">
                        <div>
                            <h3>🚨 Manajemen Laporan Insiden, Kehilangan &amp; K3</h3>
                            <div style="font-size:12px; color:#64748b; margin-top:2px;">Dokumentasi keselamatan kerja pabrik dan penanganan insiden fisik keamanan.</div>
                        </div>
                    </div>

                    <form id="form_pk01_sec_incident" style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px; margin-bottom:24px;">
                        <div class="pk01-form-grid">
                            <div class="pk01-form-group">
                                <label>Judul Insiden <span style="color:#ef4444;">*</span></label>
                                <input name="title" class="pk01-ctrl" required placeholder="Contoh: Lampu gerbang padam / Kerusakan panel workshop">
                            </div>
                            <div class="pk01-form-group">
                                <label>Kategori Insiden</label>
                                <select name="category" class="pk01-ctrl">
                                    <option value="safety">K3 &amp; Keselamatan Kerja</option>
                                    <option value="theft">Kehilangan / Dugaan Pencurian</option>
                                    <option value="damage">Kerusakan Fasilitas / Aset</option>
                                    <option value="dispute">Pelanggaran Tamu / Ketertiban</option>
                                    <option value="other">Lainnya</option>
                                </select>
                            </div>
                            <div class="pk01-form-group">
                                <label>Lokasi Kejadian <span style="color:#ef4444;">*</span></label>
                                <input name="location" class="pk01-ctrl" placeholder="Gudang Bahan / Gerbang Utama / Lantai 2" required>
                            </div>
                            <div class="pk01-form-group" style="grid-column:span 2;">
                                <label>Kronologi Kejadian &amp; Tindakan Penanganan Awal</label>
                                <textarea name="description" class="pk01-ctrl" rows="2" placeholder="Uraikan waktu kejadian, saksi, dan tindakan pengamanan yang telah diambil..."></textarea>
                            </div>
                        </div>
                        <button type="submit" class="pk01-btn pk01-btn-danger" style="margin-top:16px;">
                            ⚠️ Laporkan Insiden Keamanan
                        </button>
                    </form>

                    <div class="pk01-table-card">
                        <table class="pk01-tbl">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Kategori</th>
                                    <th>Judul &amp; Kronologi</th>
                                    <th>Lokasi</th>
                                    <th>Waktu Lapor</th>
                                    <th style="text-align:center;">Status</th>
                                    <th style="text-align:center;">Penyelesaian</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($incident_list)): ?>
                                    <tr><td colspan="7" style="text-align:center; padding:30px; color:#059669;">🟢 Kondisi aman. Tidak ada laporan insiden aktif saat ini.</td></tr>
                                <?php else: foreach ($incident_list as $inc): ?>
                                    <tr>
                                        <td><span class="pk01-code-badge" style="color:#b91c1c;"><?php echo esc_html($inc['incident_code']); ?></span></td>
                                        <td><span class="pk01-badge" style="background:#f1f5f9;"><?php echo esc_html(strtoupper($inc['category'])); ?></span></td>
                                        <td>
                                            <strong style="color:#0f172a;"><?php echo esc_html($inc['title']); ?></strong>
                                            <div style="font-size:11.5px; color:#64748b;"><?php echo esc_html($inc['description']); ?></div>
                                        </td>
                                        <td><?php echo esc_html($inc['location']); ?></td>
                                        <td><?php echo esc_html(date_i18n('d M Y, H:i', strtotime($inc['created_at']))); ?></td>
                                        <td style="text-align:center;">
                                            <span class="pk01-badge <?php echo $inc['status'] === 'open' ? 'badge-incident' : 'badge-verified'; ?>">
                                                ● <?php echo strtoupper($inc['status']); ?>
                                            </span>
                                        </td>
                                        <td style="text-align:center;">
                                            <?php if ($inc['status'] === 'open'): ?>
                                                <button type="button" class="pk01-btn pk01-btn-subtle pk01-btn-sm btn-pk01-resolve-incident" data-id="<?php echo (int)$inc['id']; ?>">
                                                    ✓ Tandai Selesai
                                                </button>
                                            <?php else: ?>
                                                <span style="font-size:11px; color:#059669; font-weight:700;">Ditutup</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 8. TAB 5: CCTV MONITOR GRID -->
            <div class="pk01-pane" id="tab-sec-cctv">
                <div class="pk01-surface">
                    <div class="pk01-surface-header">
                        <div>
                            <h3>📹 CCTV Live Stream &amp; Monitor Area Pabrik</h3>
                            <div style="font-size:12px; color:#64748b; margin-top:2px;">
                                Mendukung stream browser kompatibel (HLS .m3u8, WebRTC, atau HTTP MJPEG snapshot) [3].
                            </div>
                        </div>
                    </div>

                    <!-- Form Tambah Kamera -->
                    <form id="form_pk01_sec_cctv" style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:18px; margin-bottom:24px;">
                        <div class="pk01-form-grid">
                            <div class="pk01-form-group">
                                <label>Nama Kamera</label>
                                <input name="name" class="pk01-ctrl" required placeholder="Contoh: CAM-01 Gerbang Utama">
                            </div>
                            <div class="pk01-form-group">
                                <label>Lokasi Penempatan</label>
                                <input name="location" class="pk01-ctrl" placeholder="Lobby / Area Parkir / Gudang">
                            </div>
                            <div class="pk01-form-group">
                                <label>Protokol Stream</label>
                                <select name="protocol" class="pk01-ctrl">
                                    <option value="hls">HLS (.m3u8 stream)</option>
                                    <option value="webrtc">WebRTC Live Gateway</option>
                                    <option value="http_api">HTTP MJPEG / Snapshot</option>
                                    <option value="rtsp">RTSP (Perlu Transcoder Gateway)</option>
                                </select>
                            </div>
                            <div class="pk01-form-group">
                                <label>Stream URL (Browser Compatible)</label>
                                <input name="stream_url" class="pk01-ctrl" placeholder="https://ip-nvr-atau-gateway:port/stream.m3u8">
                            </div>
                        </div>
                        <button type="submit" class="pk01-btn pk01-btn-dark" style="margin-top:14px;">
                            📹 Daftarkan Kamera Pengawas
                        </button>
                    </form>

                    <!-- Grid Kamera -->
                    <div class="pk01-cctv-grid">
                        <?php if (empty($cameras_list)): ?>
                            <div style="grid-column:1/-1; text-align:center; padding:44px 20px; color:#94a3b8; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:14px;">
                                📹 Belum ada kamera CCTV yang didaftarkan ke monitor. Daftarkan kamera NVR/DVR di formulir atas [3].
                            </div>
                        <?php else: foreach ($cameras_list as $cam): ?>
                            <div class="pk01-cctv-card">
                                <div class="pk01-cctv-viewport">
                                    <?php if (!empty($cam['stream_url'])): ?>
                                        <iframe src="<?php echo esc_url($cam['stream_url']); ?>" style="width:100%; height:100%; border:none;" allowfullscreen></iframe>
                                    <?php else: ?>
                                        <span style="font-size:32px; opacity:0.35;">📹</span>
                                        <span style="font-size:12px; color:#94a3b8; margin-top:6px;">Stream URL belum terpasang</span>
                                    <?php endif; ?>
                                </div>
                                <div class="pk01-cctv-info">
                                    <div>
                                        <strong style="display:block; font-size:13px;"><?php echo esc_html($cam['name']); ?></strong>
                                        <small style="color:#94a3b8; font-size:11px;"><?php echo esc_html($cam['location']); ?> &bull; <?php echo esc_html(strtoupper($cam['protocol'])); ?></small>
                                    </div>
                                    <button type="button" class="pk01-btn pk01-btn-danger pk01-btn-sm btn-pk01-delete-cctv" data-id="<?php echo (int)$cam['id']; ?>">
                                        Hapus
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>

        </div>

        <!-- MODAL DEKRIPSI IDENTITAS KTP -->
        <div id="modal_pk01_ktp" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(15,23,42,0.75); z-index:999999; align-items:center; justify-content:center; padding:20px; backdrop-filter:blur(4px);">
            <div style="background:#fff; border-radius:16px; max-width:540px; width:100%; padding:22px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.3);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid #e2e8f0; padding-bottom:10px;">
                    <strong style="font-size:15px; color:#0f172a;">🔒 Dekripsi Foto KTP (AES-256-CBC) [3]</strong>
                    <button type="button" id="btn_close_pk01_ktp" style="background:none; border:none; font-size:20px; cursor:pointer; color:#64748b;">✕</button>
                </div>
                <div style="text-align:center; min-height:220px; display:flex; align-items:center; justify-content:center; background:#f8fafc; border-radius:10px; overflow:hidden;">
                    <img id="img_pk01_ktp_target" src="" alt="KTP" style="max-width:100%; max-height:380px; object-fit:contain; border-radius:8px;">
                </div>
                <div style="margin-top:14px; font-size:11.5px; color:#64748b; text-align:center;">
                    Gambar didekripsi sementara di memori server dan tercatat pada audit trail keamanan [3].
                </div>
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const restBase  = '<?php echo esc_url($rest_base); ?>';
            const restNonce = '<?php echo esc_js($rest_nonce); ?>';

            // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
            const tabs = document.querySelectorAll('.pk01-tab-btn');
            const panes = document.querySelectorAll('.pk01-pane');

            function switchTab(targetId) {
                if (!targetId) return;
                const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
                const pane = document.getElementById(targetId);
                if (btn && pane) {
                    tabs.forEach(t => t.classList.remove('is-active'));
                    panes.forEach(p => p.classList.remove('is-active'));
                    btn.classList.add('is-active');
                    pane.classList.add('is-active');
                }
            }

            tabs.forEach(tab => {
                tab.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = this.getAttribute('data-target');
                    switchTab(target);
                    if (history.replaceState) history.replaceState(null, null, '#' + target);
                });
            });

            const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
            if (currentHash && document.getElementById(currentHash)) switchTab(currentHash);

            // 2. CHECK-IN TAMU FORM
            const formVisitor = document.getElementById('form_pk01_sec_visitor');
            if (formVisitor) {
                formVisitor.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const fd = new FormData(this);
                    try {
                        const res = await fetch(restBase + 'visitors', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce },
                            body: fd
                        });
                        const data = await res.json();
                        if (data.ok) {
                            alert('Check-in tamu berhasil dicatat!');
                            location.reload();
                        } else {
                            alert('Gagal: ' + (data.message || 'Terjadi kesalahan sistem.'));
                        }
                    } catch (err) {
                        alert('Kendala koneksi REST API.');
                    }
                });
            }

            // 3. CHECK-OUT TAMU
            document.querySelectorAll('.btn-pk01-checkout-visitor').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const id = this.dataset.id;
                    if (!confirm('Selesaikan kunjungan dan checkout tamu ini?')) return;
                    try {
                        const res = await fetch(restBase + 'visitors/' + id + '/checkout', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' }
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            });

            // 4. BUKA MODAL FOTO KTP TERENKRIPSI
            const modalKtp = document.getElementById('modal_pk01_ktp');
            const imgKtp   = document.getElementById('img_pk01_ktp_target');
            const closeKtp = document.getElementById('btn_close_pk01_ktp');

            document.querySelectorAll('.btn-pk01-view-ktp').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.dataset.id;
                    imgKtp.src = restBase + 'visitors/' + id + '/identity?_wpnonce=' + restNonce;
                    modalKtp.style.display = 'flex';
                });
            });

            if (closeKtp) closeKtp.addEventListener('click', () => modalKtp.style.display = 'none');
            if (modalKtp) modalKtp.addEventListener('click', (e) => { if (e.target === modalKtp) modalKtp.style.display = 'none'; });

            // 5. KENDARAAN MASUK & CHECKOUT
            const formVeh = document.getElementById('form_pk01_sec_vehicle');
            if (formVeh) {
                formVeh.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const payload = Object.fromEntries(new FormData(this));
                    try {
                        const res = await fetch(restBase + 'vehicles', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                        else alert(data.message || 'Gagal menyimpan.');
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            }

            document.querySelectorAll('.btn-pk01-checkout-vehicle').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const id = this.dataset.id;
                    if (!confirm('Tandai kendaraan telah keluar dari gerbang?')) return;
                    try {
                        const res = await fetch(restBase + 'vehicles/' + id + '/checkout', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' }
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            });

            // 6. BARANG MASUK / KELUAR VERIFIKASI
            const formGoods = document.getElementById('form_pk01_sec_goods');
            if (formGoods) {
                formGoods.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const payload = Object.fromEntries(new FormData(this));
                    try {
                        const res = await fetch(restBase + 'goods', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                        else alert(data.message || 'Gagal menyimpan.');
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            }

            document.querySelectorAll('.btn-pk01-verify-goods').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const id = this.dataset.id;
                    if (!confirm('Verifikasi fisik muatan barang selesai dan loloskan gerbang?')) return;
                    try {
                        const res = await fetch(restBase + 'goods/' + id + '/complete', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' },
                            body: JSON.stringify({})
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            });

            // 7. INSIDEN LAPOR & RESOLVE
            const formInc = document.getElementById('form_pk01_sec_incident');
            if (formInc) {
                formInc.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const payload = Object.fromEntries(new FormData(this));
                    try {
                        const res = await fetch(restBase + 'incidents', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                        else alert(data.message || 'Gagal membuat laporan.');
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            }

            document.querySelectorAll('.btn-pk01-resolve-incident').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const id = this.dataset.id;
                    if (!confirm('Tandai laporan insiden ini telah selesai diinvestigasi/ditutup?')) return;
                    try {
                        const res = await fetch(restBase + 'incidents/' + id + '/status', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' },
                            body: JSON.stringify({ status: 'resolved' })
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            });

            // 8. CCTV ADD & DELETE
            const formCctv = document.getElementById('form_pk01_sec_cctv');
            if (formCctv) {
                formCctv.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const payload = Object.fromEntries(new FormData(this));
                    try {
                        const res = await fetch(restBase + 'cctv', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': restNonce, 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                        else alert(data.message || 'Gagal menyimpan kamera.');
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            }

            document.querySelectorAll('.btn-pk01-delete-cctv').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const id = this.dataset.id;
                    if (!confirm('Hapus kamera pengawas ini dari daftar monitor?')) return;
                    try {
                        const res = await fetch(restBase + 'cctv/' + id, {
                            method: 'DELETE',
                            headers: { 'X-WP-Nonce': restNonce }
                        });
                        const data = await res.json();
                        if (data.ok) location.reload();
                    } catch (err) { alert('Kendala koneksi.'); }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }
}

// =========================================================================
// 🚨 PENGAMAN VIEW UTAMA: CEGAH BOCOR KE BERANDA OPERASIONAL & MENU LAIN
// =========================================================================
$current_view = sanitize_key($_GET['pk01_view'] ?? '');
$allowed_sec_views = ['security', 'security_dashboard', 'cctv', 'pos_keamanan', 'satpam'];

// JIKA MENU SECURITY YANG DIPANGGIL LANGSUNG DARI URL VIEW, RENDER TAMPILANNYA
if (in_array($current_view, $allowed_sec_views, true)) {
    echo PK01_Security_Dashboard::render();
}