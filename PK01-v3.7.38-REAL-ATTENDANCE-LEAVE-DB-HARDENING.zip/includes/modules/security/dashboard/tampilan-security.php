<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_security = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('security') || PK01_Authorization::can('administration')));

if (!$can_security) return;

// 2. HELPER NAMA TABEL RESMI & KONEKSI DATABASE RIIL
$T = function($k) use ($wpdb) { 
    $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k; 
    return ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) ? $t : false; 
};

$N = function($table, $where = '1=1') use ($wpdb) { 
    if (!$table) return 0; 
    return (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE {$where}"); 
};

$t_visitors = $T('security_visitors');
$t_visits   = $T('security_visitor_visits');
$t_goods    = $T('security_goods');
$t_vehicles = $T('security_vehicles');
$t_inc      = $T('security_incidents');
$t_cams     = $T('security_cctv_cameras');

// Hitung Statistik Data Riil (Non-Dummy)
$inside          = $N($t_visits, "status = 'inside'");
$goods_pending   = $N($t_goods, "status = 'pending'");
$vehicles_inside = $N($t_vehicles, "status = 'inside'");
$open_incidents  = $N($t_inc, "status = 'open'");
$camera_count    = $N($t_cams, "status <> 'inactive'");

// Helper URL Menuju Halaman Operasional Security
$base = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('security')
    : add_query_arg('pk01_view', 'security', home_url('/'));

// 3. QUERY DATA AKTIF RIIL DI LOKASI (LIVE ON-SITE ROSTER)
// A. Tamu yang Masih di Dalam Area
$active_visitors = [];
if ($t_visits && $t_visitors) {
    $active_visitors = $wpdb->get_results("
        SELECT vv.id, vv.purpose, vv.host_name, vv.vehicle_plate, vv.checkin_at, v.name, v.company, v.phone
        FROM `{$t_visits}` vv
        LEFT JOIN `{$t_visitors}` v ON v.id = vv.visitor_id
        WHERE vv.status = 'inside'
        ORDER BY vv.id DESC LIMIT 5
    ", ARRAY_A) ?: [];
}

// B. Kendaraan yang Masih Parkir di Gerbang
$active_vehicles = [];
if ($t_vehicles) {
    $active_vehicles = $wpdb->get_results("
        SELECT id, plate, driver_name, company, purpose, checkin_at
        FROM `{$t_vehicles}`
        WHERE status = 'inside'
        ORDER BY id DESC LIMIT 5
    ", ARRAY_A) ?: [];
}

// C. Muatan Barang yang Menunggu Pemeriksaan
$pending_goods_list = [];
if ($t_goods) {
    $pending_goods_list = $wpdb->get_results("
        SELECT id, security_code, direction, description, qty, unit, vehicle_plate, reference_no, created_at
        FROM `{$t_goods}`
        WHERE status = 'pending'
        ORDER BY id DESC LIMIT 5
    ", ARRAY_A) ?: [];
}
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-purple:    #8b5cf6;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
    --pk-elevated:  0 12px 24px -4px rgb(0 0 0 / 0.08), 0 4px 8px -2px rgb(0 0 0 / 0.04);
}

.pk01-sec-dash-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-sec-dash-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-dash-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 5 KPI Cards Grid */
.pk01-kpi-deck-5 {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 14px;
    margin-bottom: 24px;
}
@media (max-width: 1200px) { .pk01-kpi-deck-5 { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 768px)  { .pk01-kpi-deck-5 { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px)  { .pk01-kpi-deck-5 { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.pk01-kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--pk-elevated);
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; height: 4px;
}
.pk01-kpi-card.c-emerald::before { background: var(--pk-emerald); }
.pk01-kpi-card.c-sky::before     { background: var(--pk-sky); }
.pk01-kpi-card.c-amber::before   { background: var(--pk-amber); }
.pk01-kpi-card.c-rose::before    { background: var(--pk-rose); }
.pk01-kpi-card.c-purple::before  { background: var(--pk-purple); }

.pk01-kpi-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 11px;
    font-weight: 700;
    color: var(--pk-slate-600);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.pk01-kpi-val {
    font-size: 26px;
    font-weight: 800;
    color: var(--pk-slate-900);
    margin: 8px 0 2px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* 3. Launchpad Action Grid */
.pk01-action-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}
@media (max-width: 960px) { .pk01-action-grid { grid-template-columns: 1fr; } }

.pk01-action-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 20px 22px;
    box-shadow: var(--pk-shadow);
    text-decoration: none !important;
    color: inherit;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    transition: all 0.2s ease;
}
.pk01-action-card:hover {
    transform: translateY(-2px);
    border-color: var(--pk-indigo);
    box-shadow: var(--pk-elevated);
}
.pk01-action-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    background: #f1f5f9;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    flex-shrink: 0;
    margin-right: 14px;
}
.pk01-action-arrow {
    font-size: 16px;
    color: #94a3b8;
    transition: transform 0.2s;
}
.pk01-action-card:hover .pk01-action-arrow {
    transform: translateX(4px);
    color: var(--pk-indigo);
}

/* 4. Live On-Site Split View */
.pk01-split-grid {
    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 20px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 1024px) { .pk01-split-grid { grid-template-columns: 1fr; } }

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 22px 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 12px;
    margin-bottom: 16px;
    flex-wrap: wrap;
    gap: 10px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 10px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 12.5px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 10px 12px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 11px 12px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 11.5px;
}

.pk01-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 10.5px;
    font-weight: 700;
}
.badge-inside   { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.badge-pending  { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.badge-incident { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

.pk01-btn-link {
    font-size: 12px;
    font-weight: 700;
    color: var(--pk-indigo);
    text-decoration: none !important;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
.pk01-btn-link:hover { text-decoration: underline !important; }

/* Footnote */
.pk01-footnote {
    background: #f8fafc;
    border: 1px dashed #cbd5e1;
    border-radius: 12px;
    padding: 14px 20px;
    font-size: 12px;
    color: #64748b;
    line-height: 1.5;
    display: flex;
    align-items: center;
    gap: 10px;
}
</style>

<div class="pk01-sec-dash-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-dash-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">PHYSICAL SECURITY &bull; GATEWAYS &amp; CCTV</span>
            <h1>🛡️ Dashboard Pemantauan Keamanan &amp; Pos Gerbang</h1>
            <p>
                Sentralisasi pengawasan fisik: Kendali lalu lintas tamu beridentitas KTP terenkripsi [3], gerbang armada kendaraan logistik, verifikasi muatan keluar/masuk, penanganan insiden K3, dan monitor CCTV [3].
            </p>
        </div>
        <div class="pk01-status-widget">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>POS GERBANG AKTIF &amp; SIAGA</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;" id="pk01-live-sec-clock">
                <?php echo date_i18n('d M Y, H:i'); ?> WIB &bull; Sistem Terenkripsi [3]
            </div>
        </div>
    </header>

    <!-- 2. EXECUTIVE 5 KPI CARDS -->
    <section class="pk01-kpi-deck-5">
        <div class="pk01-kpi-card c-emerald">
            <div class="pk01-kpi-head">
                <span>Tamu di Lokasi</span>
                <span>👤</span>
            </div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo number_format($inside); ?></div>
            <div class="pk01-kpi-sub">Orang aktif di dalam area</div>
        </div>

        <div class="pk01-kpi-card c-sky">
            <div class="pk01-kpi-head">
                <span>Kendaraan di Gerbang</span>
                <span>🚛</span>
            </div>
            <div class="pk01-kpi-val" style="color:#0284c7;"><?php echo number_format($vehicles_inside); ?></div>
            <div class="pk01-kpi-sub">Truk, pikap &amp; mobil operasional</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-head">
                <span>Muatan Menunggu</span>
                <span>📦</span>
            </div>
            <div class="pk01-kpi-val" style="color:#d97706;"><?php echo number_format($goods_pending); ?></div>
            <div class="pk01-kpi-sub">Verifikasi fisik surat jalan</div>
        </div>

        <div class="pk01-kpi-card c-rose">
            <div class="pk01-kpi-head">
                <span>Insiden K3 Terbuka</span>
                <span>🚨</span>
            </div>
            <div class="pk01-kpi-val" style="<?php echo ($open_incidents > 0) ? 'color:#dc2626;' : 'color:#059669;'; ?>">
                <?php echo number_format($open_incidents); ?>
            </div>
            <div class="pk01-kpi-sub">Butuh penanganan keamanan</div>
        </div>

        <div class="pk01-kpi-card c-purple">
            <div class="pk01-kpi-head">
                <span>Kamera Terdaftar</span>
                <span>📹</span>
            </div>
            <div class="pk01-kpi-val" style="color:#7c3aed;"><?php echo number_format($camera_count); ?></div>
            <div class="pk01-kpi-sub">Channel CCTV live terhubung [3]</div>
        </div>
    </section>

    <!-- 3. MODULAR LAUNCHPAD CARDS (DEEP-LINKING KE TAB OPERASIONAL) -->
    <div class="pk01-action-grid">
        <a class="pk01-action-card" href="<?php echo esc_url($base . '#tab-sec-visitors'); ?>">
            <div style="display:flex; align-items:center;">
                <div class="pk01-action-icon" style="background:#ecfdf5; color:#059669;">🎫</div>
                <div>
                    <h3 style="margin:0 0 3px; font-size:15px; color:#0f172a;">Buku Tamu &amp; Identitas</h3>
                    <p style="margin:0; font-size:12.5px; color:#64748b; line-height:1.4;">Check-in tamu, verifikasi NIK, dan enkripsi foto KTP otomatis [3].</p>
                </div>
            </div>
            <span class="pk01-action-arrow">&rarr;</span>
        </a>

        <a class="pk01-action-card" href="<?php echo esc_url($base . '#tab-sec-goods'); ?>">
            <div style="display:flex; align-items:center;">
                <div class="pk01-action-icon" style="background:#fffbeb; color:#d97706;">📦</div>
                <div>
                    <h3 style="margin:0 0 3px; font-size:15px; color:#0f172a;">Gate Pass Muatan Barang</h3>
                    <p style="margin:0; font-size:12.5px; color:#64748b; line-height:1.4;">Cocokkan fisik muatan barang keluar/masuk dengan surat jalan.</p>
                </div>
            </div>
            <span class="pk01-action-arrow">&rarr;</span>
        </a>

        <a class="pk01-action-card" href="<?php echo esc_url($base . '#tab-sec-cctv'); ?>">
            <div style="display:flex; align-items:center;">
                <div class="pk01-action-icon" style="background:#faf5ff; color:#7c3aed;">📹</div>
                <div>
                    <h3 style="margin:0 0 3px; font-size:15px; color:#0f172a;">Monitoring CCTV Live</h3>
                    <p style="margin:0; font-size:12.5px; color:#64748b; line-height:1.4;">Pantau streaming browser (HLS/WebRTC) seluruh sudut pabrik [3].</p>
                </div>
            </div>
            <span class="pk01-action-arrow">&rarr;</span>
        </a>
    </div>

    <!-- 4. LIVE ON-SITE TRACKING SPLIT VIEW (DATA REAL NON-DUMMY) -->
    <div class="pk01-split-grid">
        
        <!-- Tabel Tamu & Kendaraan yang Masih di Dalam -->
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>👥 Tamu &amp; Kendaraan di Dalam Area</h3>
                </div>
                <a href="<?php echo esc_url($base . '#tab-sec-visitors'); ?>" class="pk01-btn-link">
                    Buka Pos Tamu &rarr;
                </a>
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th>Nama / Supir</th>
                            <th>Tujuan &amp; Keperluan</th>
                            <th>Nopol</th>
                            <th>Jam Masuk</th>
                            <th style="text-align:center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($active_visitors) && empty($active_vehicles)): ?>
                            <tr><td colspan="5" style="text-align:center; padding:30px; color:#94a3b8;">Area steril. Tidak ada tamu atau kendaraan yang sedang berada di dalam lokasi.</td></tr>
                        <?php else: ?>
                            <!-- Roster Tamu -->
                            <?php foreach ($active_visitors as $av): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($av['name']); ?></strong>
                                        <div style="font-size:11px; color:#64748b;"><?php echo esc_html($av['company'] ?: 'Tamu Pribadi'); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo esc_html($av['host_name']); ?></div>
                                        <div style="font-size:11px; color:#64748b;"><?php echo esc_html($av['purpose']); ?></div>
                                    </td>
                                    <td>
                                        <?php if (!empty($av['vehicle_plate'])): ?>
                                            <span class="pk01-code-badge"><?php echo esc_html($av['vehicle_plate']); ?></span>
                                        <?php else: ?>
                                            <span style="color:#94a3b8;">Pejalan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html(date_i18n('H:i', strtotime($av['checkin_at']))); ?> WIB</td>
                                    <td style="text-align:center;">
                                        <span class="pk01-badge badge-inside">● Tamu Di Area</span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                            <!-- Roster Truk/Kendaraan -->
                            <?php foreach ($active_vehicles as $veh): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($veh['driver_name'] ?: 'Supir'); ?></strong>
                                        <div style="font-size:11px; color:#64748b;"><?php echo esc_html($veh['company'] ?: 'Ekspedisi'); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo esc_html($veh['purpose']); ?></div>
                                    </td>
                                    <td><span class="pk01-code-badge" style="color:#0284c7;"><?php echo esc_html($veh['plate']); ?></span></td>
                                    <td><?php echo esc_html(date_i18n('H:i', strtotime($veh['checkin_at']))); ?> WIB</td>
                                    <td style="text-align:center;">
                                        <span class="pk01-badge badge-inside" style="background:#e0f2fe; color:#0369a1; border-color:#bae6fd;">● Truk Parkir</span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tabel Antrean Muatan Barang & Insiden K3 -->
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📦 Muatan Menunggu &amp; Insiden Terbuka</h3>
                </div>
                <a href="<?php echo esc_url($base . '#tab-sec-goods'); ?>" class="pk01-btn-link">
                    Buka Gate Pass &rarr;
                </a>
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Deskripsi Muatan</th>
                            <th>Nopol</th>
                            <th style="text-align:center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($pending_goods_list)): ?>
                            <tr><td colspan="4" style="text-align:center; padding:30px; color:#059669;">🟢 Semua muatan barang telah terverifikasi dan gerbang tertib.</td></tr>
                        <?php else: foreach ($pending_goods_list as $pg): ?>
                            <tr>
                                <td><span class="pk01-code-badge"><?php echo esc_html($pg['security_code']); ?></span></td>
                                <td>
                                    <strong><?php echo esc_html($pg['description']); ?></strong>
                                    <div style="font-size:11px; color:#64748b;"><?php echo (float)$pg['qty']; ?> <?php echo esc_html($pg['unit']); ?> &bull; Ref: <?php echo esc_html($pg['reference_no'] ?: '-'); ?></div>
                                </td>
                                <td><?php echo esc_html($pg['vehicle_plate'] ?: '-'); ?></td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge badge-pending">
                                        ● <?php echo strtoupper($pg['direction']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($open_incidents > 0): ?>
                <div style="margin-top:14px; padding:10px 14px; background:#fef2f2; border:1px solid #fecaca; border-radius:10px; display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-size:12px; color:#991b1b;">
                        🚨 Terdapat <strong><?php echo (int)$open_incidents; ?> laporan insiden</strong> yang masih menunggu tindak lanjut investigasi.
                    </div>
                    <a href="<?php echo esc_url($base . '#tab-sec-incidents'); ?>" class="pk01-btn-link" style="color:#b91c1c; font-size:11.5px;">
                        Tindak Lanjuti &rarr;
                    </a>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- 5. AUDIT FOOTNOTE -->
    <footer class="pk01-footnote">
        <span style="font-size:18px;">🛡️</span>
        <div>
            <b>Kaidah Keamanan Fisik PK01:</b> Setiap orang dan muatan barang yang melintasi perimeter pabrik diverifikasi secara bertahap [2]. Foto KTP tamu otomatis dienkripsi secara privat dengan cipher <code>AES-256-CBC</code> demi kepatuhan Undang-Undang Perlindungan Data Pribadi (UU PDP) [3].
        </div>
    </footer>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Jam Patroli Real-Time WIB
    var clockEl = document.getElementById('pk01-live-sec-clock');
    if (clockEl) {
        function updateSecClock() {
            var now = new Date();
            var timeStr = now.toLocaleTimeString('id-ID', { hour12: false });
            var dateStr = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
            clockEl.innerHTML = dateStr + ', <b>' + timeStr + ' WIB</b> &bull; Sistem Terenkripsi';
        }
        setInterval(updateSecClock, 1000);
    }
});
</script>