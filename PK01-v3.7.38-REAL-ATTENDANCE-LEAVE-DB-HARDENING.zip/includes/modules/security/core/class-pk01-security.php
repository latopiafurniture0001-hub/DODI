<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Security Operations Engine & REST API Controller
 * Gate control, visitor management, AES-256 encrypted identity, goods verification, safety incidents & CCTV grid.
 */
class PK01_Security {
    const NS = 'pk01/v1';

    public static function init() {
        add_action('init', [__CLASS__, 'ensure_role'], 5);
        add_action('init', [__CLASS__, 'ensure_tables'], 6);
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    public static function t($k) { 
        global $wpdb;
        return class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : $wpdb->prefix . 'pk01_' . $k; 
    }

    public static function roles() { 
        return ['administrator', 'pk01_admin', 'pk01_security', 'shop_manager']; 
    }

    public static function allowed() {
        if (!is_user_logged_in()) return false;
        if (current_user_can('manage_options')) return true;
        
        if (class_exists('PK01_Authorization')) {
            if (PK01_Authorization::can('security') || PK01_Authorization::can('administration')) {
                return true;
            }
            $eff = PK01_Authorization::effective_role();
            if (in_array($eff, self::roles(), true)) {
                return true;
            }
        }

        $r = (array) wp_get_current_user()->roles;
        return (bool) array_intersect(self::roles(), $r);
    }

    public static function staff() { 
        return self::allowed(); 
    }

    public static function is_admin_role() { 
        if (current_user_can('manage_options')) return true;
        $r = (array) wp_get_current_user()->roles; 
        return (bool) array_intersect(['administrator', 'pk01_admin', 'shop_manager'], $r); 
    }

    public static function ensure_role() { 
        if (!get_role('pk01_security')) {
            add_role('pk01_security', 'PK01 Security', [
                'read'         => true,
                'upload_files' => true
            ]);
        }
    }

    /**
     * 1. AUTO-MIGRATION DATABASE (SELF-HEALING TABLES)
     */
    public static function ensure_tables() {
        global $wpdb;
        $t_v   = self::t('security_visitors');
        $t_vv  = self::t('security_visitor_visits');
        $t_veh = self::t('security_vehicles');
        $t_g   = self::t('security_goods');
        $t_i   = self::t('security_incidents');
        $t_c   = self::t('security_cctv_cameras');

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t_v)) !== $t_v) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $charset = $wpdb->get_charset_collate();

            $sql = "CREATE TABLE `{$t_v}` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `visitor_no` varchar(50) NOT NULL,
                `name` varchar(255) NOT NULL,
                `nik` varchar(20) DEFAULT '',
                `phone` varchar(50) DEFAULT '',
                `address` text DEFAULT '',
                `company` varchar(255) DEFAULT '',
                `ktp_file` varchar(255) DEFAULT '',
                `ktp_uploaded_at` datetime DEFAULT NULL,
                `notes` text DEFAULT '',
                `created_at` datetime NOT NULL,
                `updated_at` datetime NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `visitor_no` (`visitor_no`),
                KEY `nik` (`nik`)
            ) {$charset};

            CREATE TABLE `{$t_vv}` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `visitor_id` bigint(20) unsigned NOT NULL,
                `purpose` varchar(255) NOT NULL,
                `host_name` varchar(255) NOT NULL,
                `vehicle_plate` varchar(50) DEFAULT '',
                `carried_items` text DEFAULT '',
                `cctv_camera_id` bigint(20) unsigned DEFAULT 0,
                `checkin_at` datetime NOT NULL,
                `checkout_at` datetime DEFAULT NULL,
                `status` varchar(20) NOT NULL DEFAULT 'inside',
                `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                KEY `visitor_id` (`visitor_id`),
                KEY `status` (`status`)
            ) {$charset};

            CREATE TABLE `{$t_veh}` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `plate` varchar(50) NOT NULL,
                `driver_name` varchar(255) DEFAULT '',
                `company` varchar(255) DEFAULT '',
                `purpose` varchar(255) DEFAULT '',
                `checkin_at` datetime NOT NULL,
                `checkout_at` datetime DEFAULT NULL,
                `status` varchar(20) NOT NULL DEFAULT 'inside',
                `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`),
                KEY `plate` (`plate`),
                KEY `status` (`status`)
            ) {$charset};

            CREATE TABLE `{$t_g}` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `security_code` varchar(50) NOT NULL,
                `direction` varchar(10) NOT NULL DEFAULT 'in',
                `reference_no` varchar(100) DEFAULT '',
                `description` text NOT NULL,
                `qty` decimal(15,2) NOT NULL DEFAULT 0.00,
                `verified_qty` decimal(15,2) NOT NULL DEFAULT 0.00,
                `unit` varchar(50) NOT NULL DEFAULT 'pcs',
                `vehicle_plate` varchar(50) DEFAULT '',
                `driver_name` varchar(255) DEFAULT '',
                `status` varchar(20) NOT NULL DEFAULT 'pending',
                `checkin_at` datetime DEFAULT NULL,
                `checkout_at` datetime DEFAULT NULL,
                `verified_by` bigint(20) unsigned DEFAULT NULL,
                `verified_at` datetime DEFAULT NULL,
                `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `security_code` (`security_code`),
                KEY `status` (`status`)
            ) {$charset};

            CREATE TABLE `{$t_i}` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `incident_code` varchar(50) NOT NULL,
                `category` varchar(50) NOT NULL DEFAULT 'safety',
                `title` varchar(255) NOT NULL,
                `location` varchar(255) NOT NULL,
                `description` text DEFAULT '',
                `cctv_camera_id` bigint(20) unsigned DEFAULT 0,
                `status` varchar(20) NOT NULL DEFAULT 'open',
                `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `incident_code` (`incident_code`),
                KEY `status` (`status`)
            ) {$charset};

            CREATE TABLE `{$t_c}` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `name` varchar(255) NOT NULL,
                `location` varchar(255) DEFAULT '',
                `device_type` varchar(50) DEFAULT 'ip_camera',
                `protocol` varchar(50) DEFAULT 'hls',
                `channel` varchar(50) DEFAULT '1',
                `stream_url` text DEFAULT '',
                `source_endpoint` text DEFAULT '',
                `username` varchar(100) DEFAULT '',
                `secret_ref` varchar(100) DEFAULT '',
                `status` varchar(20) NOT NULL DEFAULT 'active',
                `last_checked_at` datetime DEFAULT NULL,
                `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`id`)
            ) {$charset};";

            PK01_DB::dbDelta_safe($sql);
        }
    }

    public static function audit($action, $entity, $id, $text, $level = 'info') {
        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'info')) {
            PK01_Audit::info($action, 'security', $text, $entity, (string)$id);
        }
    }

    /**
     * Helper Ekstraksi Payload (Mendukung JSON dan Multipart Form)
     */
    private static function get_payload($r) {
        $json = $r->get_json_params();
        if (!empty($json) && is_array($json)) {
            return $json;
        }
        return $r->get_params() ?: [];
    }

    /**
     * 2. REGISTRASI REST API ROUTES
     */
    public static function routes() {
        $auth_read  = ['methods' => 'GET',  'permission_callback' => [__CLASS__, 'allowed']];
        $auth_write = ['methods' => 'POST', 'permission_callback' => [__CLASS__, 'allowed']];

        // Dashboard Metrik
        register_rest_route(self::NS, '/security/dashboard', $auth_read + ['callback' => [__CLASS__, 'dashboard']]);

        // Buku Tamu (Visitors)
        register_rest_route(self::NS, '/security/visitors', $auth_read + ['callback' => [__CLASS__, 'visitors']]);
        register_rest_route(self::NS, '/security/visitors', $auth_write + ['callback' => [__CLASS__, 'visitor_create']]);
        register_rest_route(self::NS, '/security/visitors/(?P<id>\d+)/checkout', $auth_write + ['callback' => [__CLASS__, 'visitor_checkout']]);
        register_rest_route(self::NS, '/security/visitors/(?P<id>\d+)/identity', [
            'methods'             => 'GET',
            'permission_callback' => [__CLASS__, 'allowed'],
            'callback'            => [__CLASS__, 'identity_file']
        ]);

        // Gerbang Kendaraan (Vehicles)
        register_rest_route(self::NS, '/security/vehicles', $auth_read + ['callback' => [__CLASS__, 'vehicles']]);
        register_rest_route(self::NS, '/security/vehicles', $auth_write + ['callback' => [__CLASS__, 'vehicle_create']]);
        register_rest_route(self::NS, '/security/vehicles/(?P<id>\d+)/checkout', $auth_write + ['callback' => [__CLASS__, 'vehicle_checkout']]);

        // Pemeriksaan Muatan Barang (Goods Gate Pass)
        register_rest_route(self::NS, '/security/goods', $auth_read + ['callback' => [__CLASS__, 'goods']]);
        register_rest_route(self::NS, '/security/goods', $auth_write + ['callback' => [__CLASS__, 'goods_create']]);
        register_rest_route(self::NS, '/security/goods/(?P<id>\d+)/complete', $auth_write + ['callback' => [__CLASS__, 'goods_complete']]);

        // Laporan Insiden & K3
        register_rest_route(self::NS, '/security/incidents', $auth_read + ['callback' => [__CLASS__, 'incidents']]);
        register_rest_route(self::NS, '/security/incidents', $auth_write + ['callback' => [__CLASS__, 'incident_create']]);
        register_rest_route(self::NS, '/security/incidents/(?P<id>\d+)/status', $auth_write + ['callback' => [__CLASS__, 'incident_update_status']]);

        // CCTV Monitor
        register_rest_route(self::NS, '/security/cctv', $auth_read + ['callback' => [__CLASS__, 'cctv']]);
        register_rest_route(self::NS, '/security/cctv', [
            'methods'             => 'POST',
            'permission_callback' => [__CLASS__, 'is_admin_role'],
            'callback'            => [__CLASS__, 'cctv_create']
        ]);
        register_rest_route(self::NS, '/security/cctv/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'permission_callback' => [__CLASS__, 'is_admin_role'],
            'callback'            => [__CLASS__, 'cctv_delete']
        ]);
    }

    // --- REST HANDLERS OPERASIONAL RIIL ---

    public static function visitors() {
        global $wpdb;
        $v  = self::t('security_visitors');
        $vv = self::t('security_visitor_visits');

        $rows = $wpdb->get_results("
            SELECT vv.id AS visit_id, vv.status AS visit_status, vv.purpose, vv.host_name, vv.vehicle_plate, 
                   vv.carried_items, vv.checkin_at, vv.checkout_at,
                   v.id AS visitor_id, v.visitor_no, v.name, v.nik, v.phone, v.company, v.ktp_file
            FROM `{$vv}` vv
            LEFT JOIN `{$v}` v ON v.id = vv.visitor_id
            ORDER BY vv.id DESC LIMIT 100
        ", ARRAY_A) ?: [];

        return ['ok' => true, 'visitors' => $rows];
    }

    public static function visitor_create($r) {
        global $wpdb;
        $p = self::get_payload($r);

        $name = sanitize_text_field($p['name'] ?? '');
        if ($name === '') {
            return new WP_Error('name_required', 'Nama lengkap tamu wajib diisi.', ['status' => 422]);
        }

        $nik = preg_replace('/\D+/', '', (string)($p['nik'] ?? ''));
        if ($nik !== '' && strlen($nik) !== 16) {
            return new WP_Error('nik_invalid', 'Nomor NIK harus tepat 16 digit.', ['status' => 422]);
        }

        $now = current_time('mysql');
        $visitor_no = class_exists('PK01_Engine') ? PK01_Engine::document_number('security_visitor') : ('VIS-' . wp_date('ymd') . '-' . str_pad((string)wp_rand(100, 9999), 4, '0', STR_PAD_LEFT));
        
        $t_v = self::t('security_visitors');
        $existing = 0;
        if ($nik !== '') {
            $existing = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t_v}` WHERE nik = %s LIMIT 1", $nik));
        }

        if (!$existing) {
            $wpdb->insert($t_v, [
                'visitor_no' => $visitor_no,
                'name'       => $name,
                'nik'        => $nik,
                'phone'      => sanitize_text_field($p['phone'] ?? ''),
                'address'    => sanitize_textarea_field($p['address'] ?? ''),
                'company'    => sanitize_text_field($p['company'] ?? ''),
                'notes'      => sanitize_textarea_field($p['notes'] ?? ''),
                'created_at' => $now,
                'updated_at' => $now
            ]);
            $existing = (int) $wpdb->insert_id;
        }

        $vno = $wpdb->get_var($wpdb->prepare("SELECT visitor_no FROM `{$t_v}` WHERE id = %d", $existing));
        $t_vv = self::t('security_visitor_visits');

        $wpdb->insert($t_vv, [
            'visitor_id'     => $existing,
            'purpose'        => sanitize_text_field($p['purpose'] ?? 'Keperluan Dinas / Kunjungan'),
            'host_name'      => sanitize_text_field($p['host_name'] ?? 'Pimpinan / Divisi Terkait'),
            'vehicle_plate'  => strtoupper(sanitize_text_field($p['vehicle_plate'] ?? '')),
            'carried_items'  => sanitize_textarea_field($p['carried_items'] ?? ''),
            'cctv_camera_id' => (int)($p['cctv_camera_id'] ?? 0),
            'checkin_at'     => $now,
            'status'         => 'inside',
            'created_by'     => get_current_user_id()
        ]);
        $visit_id = (int) $wpdb->insert_id;

        // Enkripsi KTP privat jika ada upload foto
        if (!empty($_FILES['ktp']) && !empty($_FILES['ktp']['tmp_name'])) {
            self::save_private_ktp($existing, $_FILES['ktp']);
        }

        self::audit('visitor_checkin', 'security_visitor', $existing, 'Tamu ' . $name . ' (' . $vno . ') check-in masuk area.');
        return [
            'ok'         => true,
            'visitor_id' => $existing,
            'visit_id'   => $visit_id,
            'visitor_no' => $vno
        ];
    }

    public static function visitor_checkout($r) {
        global $wpdb;
        $id  = (int) $r['id'];
        $t   = self::t('security_visitor_visits');
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d", $id), ARRAY_A);

        if (!$row) {
            return new WP_Error('not_found', 'Log kunjungan tamu tidak ditemukan.', ['status' => 404]);
        }

        $now = current_time('mysql');
        $wpdb->update($t, [
            'checkout_at' => $now,
            'status'      => 'checked_out'
        ], ['id' => $id]);

        self::audit('visitor_checkout', 'security_visitor_visit', $id, 'Kunjungan tamu ID #' . $id . ' selesai (checked-out).');
        return ['ok' => true, 'checkout_at' => $now];
    }

    // --- MANAJEMEN ENKRIPSI IDENTITAS KTP ---

    public static function private_dir() {
        $u   = wp_upload_dir();
        $dir = trailingslashit($u['basedir']) . 'pk01-private-security';
        if (!is_dir($dir)) wp_mkdir_p($dir);
        if (!file_exists($dir . '/.htaccess')) {
            @file_put_contents($dir . '/.htaccess', "Deny from all\n");
        }
        return $dir;
    }

    public static function crypto_key() {
        return hash('sha256', (defined('AUTH_KEY') ? AUTH_KEY : 'pk01_sec') . (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : 'secret_safe'), true);
    }

    public static function save_private_ktp($visitor_id, $file) {
        $raw = @file_get_contents($file['tmp_name']);
        if ($raw === false || strlen($raw) > 8 * 1024 * 1024) return false;

        $iv     = random_bytes(16);
        $cipher = openssl_encrypt($raw, 'AES-256-CBC', self::crypto_key(), OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) return false;

        $path = self::private_dir() . '/visitor-' . $visitor_id . '.bin';
        @file_put_contents($path, $iv . $cipher);

        global $wpdb;
        $wpdb->update(self::t('security_visitors'), [
            'ktp_file'        => basename($path),
            'ktp_uploaded_at' => current_time('mysql')
        ], ['id' => $visitor_id]);

        return true;
    }

    public static function identity_file($r) {
        if (!self::allowed()) {
            return new WP_Error('forbidden', 'Akses ditolak.', ['status' => 403]);
        }

        global $wpdb;
        $id  = (int) $r['id'];
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('security_visitors') . " WHERE id = %d", $id), ARRAY_A);

        if (!$row || empty($row['ktp_file'])) {
            return new WP_Error('not_found', 'Foto KTP belum diunggah.', ['status' => 404]);
        }

        $path = self::private_dir() . '/' . basename($row['ktp_file']);
        if (!is_readable($path)) {
            return new WP_Error('file_missing', 'Berkas identitas fisik tidak ditemukan.', ['status' => 404]);
        }

        $data   = file_get_contents($path);
        $iv     = substr($data, 0, 16);
        $cipher = substr($data, 16);
        $raw    = openssl_decrypt($cipher, 'AES-256-CBC', self::crypto_key(), OPENSSL_RAW_DATA, $iv);

        if ($raw === false) {
            return new WP_Error('decrypt_failed', 'Dekripsi berkas identitas gagal.', ['status' => 500]);
        }

        self::audit('identity_view', 'security_visitor', $id, 'Melihat foto KTP terenkripsi tamu #' . $id, 'info');

        header('Content-Type: image/jpeg');
        header('Content-Disposition: inline; filename="ktp-' . $id . '.jpg"');
        echo $raw;
        exit;
    }

    // --- POS GERBANG KENDARAAN ---

    public static function vehicles() {
        global $wpdb;
        $t = self::t('security_vehicles');
        $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        return ['ok' => true, 'vehicles' => $rows];
    }

    public static function vehicle_create($r) {
        global $wpdb;
        $p = self::get_payload($r);
        $plate = strtoupper(sanitize_text_field($p['plate'] ?? ''));

        if ($plate === '') {
            return new WP_Error('plate_required', 'Nomor polisi kendaraan wajib diisi.', ['status' => 422]);
        }

        $now = current_time('mysql');
        $wpdb->insert(self::t('security_vehicles'), [
            'plate'       => $plate,
            'driver_name' => sanitize_text_field($p['driver_name'] ?? ''),
            'company'     => sanitize_text_field($p['company'] ?? ''),
            'purpose'     => sanitize_text_field($p['purpose'] ?? 'Logistik / Pengiriman'),
            'checkin_at'  => $now,
            'status'      => 'inside',
            'created_by'  => get_current_user_id()
        ]);

        $vid = (int)$wpdb->insert_id;
        self::audit('vehicle_checkin', 'security_vehicle', $vid, 'Kendaraan ' . $plate . ' memasuki area gerbang.');
        return ['ok' => true, 'id' => $vid];
    }

    public static function vehicle_checkout($r) {
        global $wpdb;
        $id = (int) $r['id'];
        $t  = self::t('security_vehicles');
        $now = current_time('mysql');

        $wpdb->update($t, [
            'checkout_at' => $now,
            'status'      => 'checked_out'
        ], ['id' => $id]);

        self::audit('vehicle_checkout', 'security_vehicle', $id, 'Kendaraan ID #' . $id . ' keluar dari gerbang.');
        return ['ok' => true, 'checkout_at' => $now];
    }

    // --- GATE PASS PEMERIKSAAN MUATAN BARANG ---

    public static function goods() {
        global $wpdb;
        $t = self::t('security_goods');
        $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        return ['ok' => true, 'goods' => $rows];
    }

    public static function goods_create($r) {
        global $wpdb;
        $p = self::get_payload($r);

        $direction = in_array(($p['direction'] ?? ''), ['in', 'out'], true) ? $p['direction'] : 'in';
        $desc = sanitize_text_field($p['description'] ?? '');

        if ($desc === '') {
            return new WP_Error('goods_required', 'Deskripsi rincian muatan barang wajib diisi.', ['status' => 422]);
        }

        $code = class_exists('PK01_Engine') ? PK01_Engine::document_number('security_gate') : ('SEC-G-' . wp_date('ymd') . '-' . wp_rand(1000, 9999));
        $now  = current_time('mysql');

        $wpdb->insert(self::t('security_goods'), [
            'security_code' => $code,
            'direction'     => $direction,
            'reference_no'  => sanitize_text_field($p['reference_no'] ?? ''),
            'description'   => $desc,
            'qty'           => max(0, (float)($p['qty'] ?? 0)),
            'verified_qty'  => 0,
            'unit'          => sanitize_text_field($p['unit'] ?? 'pcs'),
            'vehicle_plate' => strtoupper(sanitize_text_field($p['vehicle_plate'] ?? '')),
            'driver_name'   => sanitize_text_field($p['driver_name'] ?? ''),
            'status'        => 'pending',
            'checkin_at'    => $direction === 'in' ? $now : null,
            'created_by'    => get_current_user_id(),
            'created_at'    => $now
        ]);

        $gid = (int)$wpdb->insert_id;
        self::audit('goods_gate_created', 'security_goods', $gid, 'Tiket pemeriksaan muatan ' . $code . ' dibuat.');
        return ['ok' => true, 'id' => $gid, 'security_code' => $code];
    }

    public static function goods_complete($r) {
        global $wpdb;
        $id  = (int) $r['id'];
        $t   = self::t('security_goods');
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d", $id), ARRAY_A);

        if (!$row) {
            return new WP_Error('not_found', 'Pemeriksaan barang tidak ditemukan.', ['status' => 404]);
        }

        $p = self::get_payload($r);
        $now = current_time('mysql');
        $status = ($row['direction'] === 'out') ? 'released' : 'received';

        $wpdb->update($t, [
            'status'       => $status,
            'verified_qty' => isset($p['verified_qty']) ? (float)$p['verified_qty'] : $row['qty'],
            'checkout_at'  => ($row['direction'] === 'out') ? $now : null,
            'verified_by'  => get_current_user_id(),
            'verified_at'  => $now
        ], ['id' => $id]);

        self::audit('goods_gate_verified', 'security_goods', $id, 'Muatan barang ' . $row['security_code'] . ' selesai diverifikasi: ' . $status);
        return ['ok' => true, 'status' => $status];
    }

    // --- LAPORAN INSIDEN & K3 ---

    public static function incidents() {
        global $wpdb;
        $t = self::t('security_incidents');
        $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];
        return ['ok' => true, 'incidents' => $rows];
    }

    public static function incident_create($r) {
        global $wpdb;
        $p = self::get_payload($r);

        $title = sanitize_text_field($p['title'] ?? '');
        if ($title === '') {
            return new WP_Error('title_required', 'Judul laporan insiden wajib diisi.', ['status' => 422]);
        }

        $code = class_exists('PK01_Engine') ? PK01_Engine::document_number('security_incident') : ('INC-' . wp_date('ymd') . '-' . wp_rand(1000, 9999));
        $now  = current_time('mysql');

        $wpdb->insert(self::t('security_incidents'), [
            'incident_code'  => $code,
            'category'       => sanitize_key($p['category'] ?? 'safety'),
            'title'          => $title,
            'location'       => sanitize_text_field($p['location'] ?? ''),
            'description'    => sanitize_textarea_field($p['description'] ?? ''),
            'cctv_camera_id' => (int)($p['cctv_camera_id'] ?? 0),
            'status'         => 'open',
            'created_by'     => get_current_user_id(),
            'created_at'     => $now
        ]);

        $iid = (int)$wpdb->insert_id;
        self::audit('security_incident_created', 'security_incident', $iid, 'Insiden ' . $code . ' dilaporkan.', 'warning');
        return ['ok' => true, 'id' => $iid, 'incident_code' => $code];
    }

    public static function incident_update_status($r) {
        global $wpdb;
        $id = (int)$r['id'];
        $p  = self::get_payload($r);

        $status = in_array(($p['status'] ?? ''), ['open', 'investigating', 'resolved', 'closed'], true) ? $p['status'] : 'resolved';
        $t = self::t('security_incidents');

        $wpdb->update($t, ['status' => $status], ['id' => $id]);
        self::audit('security_incident_status', 'security_incident', $id, 'Status insiden #' . $id . ' diubah ke: ' . $status);

        return ['ok' => true, 'status' => $status];
    }

    // --- CCTV LIVE GRID CONTROLLER ---

    public static function cctv() {
        global $wpdb;
        $t = self::t('security_cctv_cameras');
        $rows = $wpdb->get_results("SELECT id, name, location, device_type, protocol, channel, stream_url, status, last_checked_at FROM `{$t}` ORDER BY id ASC", ARRAY_A) ?: [];
        return ['ok' => true, 'cameras' => $rows];
    }

    public static function cctv_create($r) {
        global $wpdb;
        $p = self::get_payload($r);

        $name = sanitize_text_field($p['name'] ?? '');
        if ($name === '') {
            return new WP_Error('name_required', 'Nama kamera pengawas wajib diisi.', ['status' => 422]);
        }

        $protocol = sanitize_key($p['protocol'] ?? 'hls');
        $wpdb->insert(self::t('security_cctv_cameras'), [
            'name'            => $name,
            'location'        => sanitize_text_field($p['location'] ?? 'Gerbang Utama'),
            'device_type'     => sanitize_key($p['device_type'] ?? 'ip_camera'),
            'protocol'        => in_array($protocol, ['hls', 'webrtc', 'http_api', 'rtsp'], true) ? $protocol : 'hls',
            'channel'         => sanitize_text_field($p['channel'] ?? '1'),
            'stream_url'      => esc_url_raw($p['stream_url'] ?? ''),
            'source_endpoint' => sanitize_text_field($p['source_endpoint'] ?? ''),
            'status'          => 'active',
            'created_by'      => get_current_user_id(),
            'created_at'      => current_time('mysql')
        ]);

        return ['ok' => true, 'id' => (int)$wpdb->insert_id];
    }

    public static function cctv_delete($r) {
        global $wpdb;
        $id = (int)$r['id'];
        $wpdb->delete(self::t('security_cctv_cameras'), ['id' => $id]);
        return ['ok' => true];
    }

    // --- DASHBOARD AGGREGATOR ---

    public static function dashboard() {
        global $wpdb;
        $v   = self::t('security_visitor_visits');
        $g   = self::t('security_goods');
        $veh = self::t('security_vehicles');
        $i   = self::t('security_incidents');

        return [
            'ok' => true,
            'stats' => [
                'visitors_inside' => ($v) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM `{$v}` WHERE status = 'inside'") : 0,
                'goods_pending'   => ($g) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM `{$g}` WHERE status = 'pending'") : 0,
                'vehicles_inside' => ($veh) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM `{$veh}` WHERE status = 'inside'") : 0,
                'open_incidents'  => ($i) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM `{$i}` WHERE status = 'open'") : 0,
            ]
        ];
    }
}

// Inisialisasi Otomatis
PK01_Security::init();