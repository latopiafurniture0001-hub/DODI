# PK01 — Modul Hr

Folder canonical: `includes/modules/hr/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/hr/attendance/tampilan-absensi.php`
- `includes/modules/hr/core/class-pk01-hr-attendance.php`
- `includes/modules/hr/employees/tampilan-karyawan.php`
- `includes/modules/hr/payroll/tampilan-gaji.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
