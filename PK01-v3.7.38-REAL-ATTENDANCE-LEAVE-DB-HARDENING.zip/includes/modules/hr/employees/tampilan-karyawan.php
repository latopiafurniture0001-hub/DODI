<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_url = remove_query_arg(['edit_id', 'action', '_wpnonce', 'target_id']);

// 1. OTORISASI: SUPERADMIN & HR BYPASS
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('hr') || PK01_Authorization::can('employees')));

if (!$can_manage) {
    echo '<div class="notice notice-error"><p>⛔ Anda tidak memiliki izin akses ke modul data karyawan.</p></div>';
    return;
}

// 2. DETEKSI & INISIALISASI TABEL
$table_employees = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('employees') 
    : $wpdb->prefix . 'pk01_employees';

$table_piece_rates = $wpdb->prefix . 'pk01_employee_piece_rates';

$tbl_logs = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('activity_logs') 
    : $wpdb->prefix . 'pk01_activity_logs';

// AUTO-CREATE TABEL TARIF BORONGAN JIKA BELUM ADA
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_piece_rates)) !== $table_piece_rates) {
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `{$table_piece_rates}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `employee_id` bigint(20) unsigned NOT NULL,
        `job_name` varchar(255) NOT NULL,
        `rate` decimal(15,2) NOT NULL DEFAULT 0.00,
        `unit` varchar(50) NOT NULL DEFAULT 'pcs',
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `employee_id` (`employee_id`)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe($sql);
}

// 3. LOGIKA QUICK ACTION: TOGGLE STATUS & HAPUS KARYAWAN
if (isset($_GET['action'], $_GET['target_id']) && check_admin_referer('pk01_emp_quick_action')) {
    $target_id = absint($_GET['target_id']);
    $action    = sanitize_key($_GET['action']);

    if ($target_id > 0) {
        $target_emp = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_employees}` WHERE id = %d", $target_id), ARRAY_A);
        
        if ($target_emp) {
            if ($action === 'toggle_status') {
                $new_status = ($target_emp['status'] === 'active') ? 'inactive' : 'active';
                $wpdb->update($table_employees, ['status' => $new_status, 'updated_at' => current_time('mysql')], ['id' => $target_id]);
                $notice = '<div class="pk01-toast-alert is-success">Status karyawan <strong>' . esc_html($target_emp['name']) . '</strong> berhasil diubah menjadi <strong>' . strtoupper($new_status) . '</strong>.</div>';
            } elseif ($action === 'delete') {
                $wpdb->delete($table_employees, ['id' => $target_id]);
                $wpdb->delete($table_piece_rates, ['employee_id' => $target_id]);
                
                // Catat Log
                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
                    $wpdb->insert($tbl_logs, [
                        'user_id'     => get_current_user_id(),
                        'action'      => 'employee_deleted',
                        'module'      => 'employees',
                        'entity'      => $target_emp['code'] . ' - ' . $target_emp['name'],
                        'description' => "Menghapus data master karyawan {$target_emp['name']} beserta matriks borongan.",
                        'created_at'  => current_time('mysql')
                    ]);
                }
                $notice = '<div class="pk01-toast-alert is-success">Data karyawan <strong>' . esc_html($target_emp['name']) . '</strong> telah berhasil dihapus permanen.</div>';
            }
        }
    }
}

// 4. EKSPOR DATA KE CSV DENGAN INFORMASI LENGKAP
if (isset($_POST['pk01_export_employees_csv']) && check_admin_referer('pk01_export_employees_nonce')) {
    $export_rows = $wpdb->get_results(
        "SELECT e.*, u.user_login 
         FROM `{$table_employees}` e 
         LEFT JOIN `{$wpdb->users}` u ON u.ID = e.user_id 
         ORDER BY e.id DESC", 
        ARRAY_A
    );

    $raw_piece = $wpdb->get_results("SELECT * FROM `{$table_piece_rates}`", ARRAY_A) ?: [];
    $exp_piece_map = [];
    foreach ($raw_piece as $p) {
        $exp_piece_map[$p['employee_id']][] = $p['job_name'] . ': Rp ' . number_format((float)$p['rate'], 0, ',', '.') . '/' . $p['unit'];
    }

    if (!empty($export_rows)) {
        $filename = 'pk01-master-karyawan-' . current_time('Y-m-d-His') . '.csv';
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID', 'Kode Karyawan', 'Nama Lengkap', 'Jabatan', 'Divisi', 'Sistem Gaji', 'Tarif Dasar / Gaji Pokok (Rp)', 'Rincian Borongan', 'Status', 'User WordPress', 'Jam Masuk', 'Jam Pulang', 'ID Biometrik']);
        foreach ($export_rows as $r) {
            $piece_text = !empty($exp_piece_map[$r['id']]) ? implode(' | ', $exp_piece_map[$r['id']]) : '-';
            fputcsv($out, [
                $r['id'],
                $r['code'],
                $r['name'],
                $r['position'] ?: '-',
                $r['division'] ?: '-',
                strtoupper($r['pay_type']),
                $r['rate'],
                $piece_text,
                strtoupper($r['status']),
                $r['user_login'] ?: '-',
                $r['work_start'] ?? '08:00',
                $r['work_end'] ?? '17:00',
                $r['biometric_id'] ?? '-'
            ]);
        }
        fclose($out);
        exit;
    }
}

// 5. PROSES SIMPAN / UPDATE DENGAN ANTI-DUPLIKASI KODE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_employee_save'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_employee_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_employee_save_action')) {
        $notice = '<div class="pk01-toast-alert is-error">⚠️ Sesi tidak valid atau telah kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        $id        = absint($_POST['emp_id'] ?? 0);
        $name      = sanitize_text_field(wp_unslash($_POST['emp_name'] ?? ''));
        $code      = strtoupper(sanitize_text_field(wp_unslash($_POST['emp_code'] ?? '')));
        $position  = sanitize_text_field(wp_unslash($_POST['emp_position'] ?? ''));
        $division  = sanitize_text_field(wp_unslash($_POST['emp_division'] ?? ''));
        $pay_type  = sanitize_text_field(wp_unslash($_POST['emp_pay_type'] ?? 'monthly'));
        $status    = in_array($_POST['emp_status'] ?? '', ['active', 'inactive'], true) ? $_POST['emp_status'] : 'active';
        $user_id   = absint($_POST['emp_user_id'] ?? 0);

        $work_start = sanitize_text_field(wp_unslash($_POST['emp_work_start'] ?? '08:00'));
        $work_end   = sanitize_text_field(wp_unslash($_POST['emp_work_end'] ?? '17:00'));
        $biometric  = sanitize_text_field(wp_unslash($_POST['emp_biometric_id'] ?? ''));

        $rate_raw  = sanitize_text_field(wp_unslash($_POST['emp_rate'] ?? '0'));
        $base_rate = (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', $rate_raw));

        // Generate Kode Otomatis bila dikosongkan
        if (empty($code)) {
            $prefix = get_option('pk01_employee_prefix', 'KRY');
            $digits = absint(get_option('pk01_employee_digits', 3));
            $max_id = (int) $wpdb->get_var("SELECT MAX(id) FROM `{$table_employees}`");
            $code   = $prefix . '-' . str_pad((string)($max_id + 1), $digits, '0', STR_PAD_LEFT);
        }

        // Cek Duplikasi Kode
        $check_code_sql = "SELECT id FROM `{$table_employees}` WHERE code = %s" . ($id > 0 ? " AND id != {$id}" : "");
        $is_duplicate   = (int) $wpdb->get_var($wpdb->prepare($check_code_sql, $code));

        if (empty($name)) {
            $notice = '<div class="pk01-toast-alert is-error">⚠️ Nama lengkap staf karyawan tidak boleh kosong.</div>';
        } elseif ($is_duplicate > 0) {
            $notice = '<div class="pk01-toast-alert is-error">⚠️ Kode Karyawan <strong>' . esc_html($code) . '</strong> sudah digunakan. Mohon pilih kode yang berbeda.</div>';
        } else {
            try {
                $data_payload = [
                    'code'       => $code,
                    'name'       => $name,
                    'position'   => $position,
                    'division'   => $division,
                    'pay_type'   => $pay_type,
                    'rate'       => ($pay_type === 'piece') ? 0 : $base_rate,
                    'status'     => $status,
                    'user_id'    => $user_id,
                    'updated_at' => current_time('mysql'),
                ];

                // Tambahkan jam kerja & bio jika kolom tersedia di tabel
                $cols = $wpdb->get_col("DESC `{$table_employees}`", 0);
                if (in_array('work_start', $cols, true))   $data_payload['work_start'] = $work_start;
                if (in_array('work_end', $cols, true))     $data_payload['work_end'] = $work_end;
                if (in_array('biometric_id', $cols, true)) $data_payload['biometric_id'] = $biometric;

                $saved_emp_id = $id;

                if ($id > 0) {
                    $wpdb->update($table_employees, $data_payload, ['id' => $id]);
                } else {
                    $data_payload['created_at'] = current_time('mysql');
                    $wpdb->insert($table_employees, $data_payload);
                    $saved_emp_id = $wpdb->insert_id;
                }

                // SIMPAN TARIF BORONGAN MULTI-JOB REPEATER
                if ($saved_emp_id > 0) {
                    $wpdb->delete($table_piece_rates, ['employee_id' => $saved_emp_id]);

                    if ($pay_type === 'piece' && !empty($_POST['piece_jobs']) && is_array($_POST['piece_jobs'])) {
                        $job_names = (array) $_POST['piece_jobs'];
                        $job_rates = (array) ($_POST['piece_rates'] ?? []);
                        $job_units = (array) ($_POST['piece_units'] ?? []);

                        foreach ($job_names as $idx => $raw_job_name) {
                            $j_name = sanitize_text_field(wp_unslash($raw_job_name));
                            $j_rate = (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)($job_rates[$idx] ?? 0)));
                            $j_unit = sanitize_text_field(wp_unslash($job_units[$idx] ?? 'pcs'));

                            if (!empty($j_name) && $j_rate > 0) {
                                $wpdb->insert($table_piece_rates, [
                                    'employee_id' => $saved_emp_id,
                                    'job_name'    => $j_name,
                                    'rate'        => $j_rate,
                                    'unit'        => $j_unit ?: 'pcs',
                                    'created_at'  => current_time('mysql'),
                                ]);
                            }
                        }
                    }
                }

                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
                    $wpdb->insert($tbl_logs, [
                        'user_id'     => get_current_user_id(),
                        'action'      => ($id > 0 ? 'employee_updated' : 'employee_created'),
                        'module'      => 'employees',
                        'entity'      => $code . ' - ' . $name,
                        'description' => "Menyimpan data karyawan {$name} ({$pay_type}) beserta konfigurasi tarif upah.",
                        'created_at'  => current_time('mysql')
                    ]);
                }

                $notice = '<div class="pk01-toast-alert is-success">✅ Berhasil menyimpan profil staf <strong>' . esc_html($name) . '</strong> (' . esc_html($code) . ').</div>';
                $_POST = [];
            } catch (Throwable $e) {
                $notice = '<div class="pk01-toast-alert is-error">❌ Gagal menyimpan data: ' . esc_html($e->getMessage()) . '</div>';
            }
        }
    }
}

// 6. AMBIL DATA EDIT & LIST
$edit_id = absint($_GET['edit_id'] ?? 0);
$edit = null;
$existing_piece_rates = [];

if ($edit_id > 0) {
    $edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_employees}` WHERE id = %d", $edit_id), ARRAY_A);
    if ($edit) {
        $existing_piece_rates = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM `{$table_piece_rates}` WHERE employee_id = %d ORDER BY id ASC", $edit_id),
            ARRAY_A
        ) ?: [];
    }
}

$rows = $wpdb->get_results(
    "SELECT e.*, u.user_login, u.display_name 
     FROM `{$table_employees}` e 
     LEFT JOIN `{$wpdb->users}` u ON u.ID = e.user_id 
     ORDER BY e.id DESC LIMIT 400",
    ARRAY_A
) ?: [];

// Pre-fetch piece rates
$all_piece_rates = [];
$raw_piece = $wpdb->get_results("SELECT * FROM `{$table_piece_rates}`", ARRAY_A) ?: [];
foreach ($raw_piece as $p) {
    $all_piece_rates[$p['employee_id']][] = $p;
}

// Hitung Statistik & Divisi
$total_employees  = count($rows);
$active_employees = 0;
$piece_employees  = 0;
$linked_users     = 0;
$divisions_list   = [];

foreach ($rows as $r) {
    if (($r['status'] ?? '') === 'active') $active_employees++;
    if (($r['pay_type'] ?? '') === 'piece') $piece_employees++;
    if (!empty($r['user_id'])) $linked_users++;
    if (!empty($r['division']) && !in_array($r['division'], $divisions_list, true)) {
        $divisions_list[] = $r['division'];
    }
}

$users = get_users(['fields' => ['ID', 'user_login', 'display_name'], 'orderby' => 'display_name', 'order' => 'ASC']);
$quick_action_nonce = wp_create_nonce('pk01_emp_quick_action');
?>

<style>
:root {
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-indigo: #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald: #10b981;
    --pk-amber: #f59e0b;
    --pk-rose: #f43f5e;
    --pk-card-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-app-wrap {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1460px;
    margin: 15px auto 50px;
}
.pk01-app-wrap * { box-sizing: border-box; }

/* Hero Cockpit */
.pk01-hero {
    background: linear-gradient(135deg, #090d16 0%, #111827 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 24px;
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.2);
}
.pk01-hero-badge {
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.4);
    color: #c7d2fe;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1px;
    padding: 4px 10px;
    border-radius: 6px;
    display: inline-block;
    margin-bottom: 8px;
}
.pk01-hero h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 0 0 6px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}

/* KPI Cards */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.pk01-kpi-item {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-card-shadow);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-item::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-item.c-indigo::before { background: var(--pk-indigo); }
.pk01-kpi-item.c-emerald::before { background: var(--pk-emerald); }
.pk01-kpi-item.c-amber::before { background: var(--pk-amber); }
.pk01-kpi-item.c-rose::before { background: var(--pk-rose); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-number { font-size: 26px; font-weight: 800; color: #0f172a; margin: 4px 0 2px; }
.pk01-kpi-sub { font-size: 12px; color: #94a3b8; }

/* Notification Alert */
.pk01-toast-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-toast-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-toast-alert.is-error { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }

/* Two Column Layout */
.pk01-split-grid {
    display: grid;
    grid-template-columns: 1.55fr 0.95fr;
    gap: 22px;
    margin-bottom: 28px;
    align-items: start;
}
@media (max-width: 1024px) {
    .pk01-split-grid { grid-template-columns: 1fr; }
}

.pk01-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    box-shadow: var(--pk-card-shadow);
}
.pk01-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 20px;
}
.pk01-card-title {
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Form Styles */
.pk01-grid-fields {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 640px) {
    .pk01-grid-fields { grid-template-columns: 1fr; }
}
.pk01-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-group label {
    font-size: 12px;
    font-weight: 700;
    color: var(--pk-slate-600);
}
.pk01-ctrl {
    width: 100%;
    padding: 9px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13.5px;
    background: #ffffff;
    transition: all 0.2s ease;
}
.pk01-ctrl:focus {
    outline: none;
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Piece Rate Repeater Box */
.pk01-piece-panel {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 16px;
    margin-top: 18px;
}
.pk01-piece-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}
.pk01-chip-pills {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}
.pk01-pill {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    color: #1e40af;
    border-radius: 6px;
    padding: 4px 9px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill:hover {
    background: var(--pk-indigo);
    color: #fff;
    border-color: var(--pk-indigo);
}

/* Data Table */
.pk01-table-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    box-shadow: var(--pk-card-shadow);
    overflow: hidden;
}
.pk01-filter-deck {
    padding: 18px 22px;
    background: #fbfcfe;
    border-bottom: 1px solid var(--pk-slate-200);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}
.pk01-filter-group {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}
.pk01-tab-filter {
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
    border: 1px solid #cbd5e1;
    background: #fff;
    color: #475569;
    cursor: pointer;
}
.pk01-tab-filter.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
    border-color: var(--pk-slate-900);
}

.pk01-table-scroll {
    overflow-x: auto;
    width: 100%;
}
.pk01-main-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-main-table th {
    background: #f8fafc;
    padding: 12px 16px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-main-table td {
    padding: 12px 16px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-main-table tr:hover td { background: #fbfcfe; }

/* Employee Avatar & Identity */
.pk01-emp-identity {
    display: flex;
    align-items: center;
    gap: 12px;
}
.pk01-avatar {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: linear-gradient(135deg, #4f46e5, #9333ea);
    color: #fff;
    font-weight: 700;
    font-size: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-transform: uppercase;
    flex-shrink: 0;
}

/* Badges & Buttons */
.pk01-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-badge-active { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.pk01-badge-inactive { background: #fff1f2; color: #9f1239; border: 1px solid #fecdd3; }
.pk01-badge-piece { background: #e0e7ff; color: #3730a3; border: 1px solid #c7d2fe; }

.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    font-size: 13px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #fff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-outline { background: #ffffff; border: 1px solid #cbd5e1; color: #334155 !important; }
.pk01-btn-outline:hover { background: #f8fafc; border-color: #94a3b8; }
.pk01-btn-sm { padding: 4px 8px; font-size: 11.5px; border-radius: 6px; }

/* Quick View Modal */
.pk01-modal {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(15, 23, 42, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    padding: 20px;
    backdrop-filter: blur(3px);
}
.pk01-modal-card {
    background: #ffffff;
    border-radius: 16px;
    width: 100%;
    max-width: 520px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    animation: pkModalIn 0.25s ease-out;
}
@keyframes pkModalIn {
    from { opacity: 0; transform: translateY(12px) scale(0.97); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}
</style>

<div class="pk01-app-wrap">

    <!-- 1. HERO BANNER -->
    <div class="pk01-hero">
        <div>
            <span class="pk01-hero-badge">ENTERPRISE WORKFORCE &bull; PAYROLL CORE</span>
            <h1>👥 Master Karyawan &amp; Matriks Borongan</h1>
            <p>
                Sentralisasi profil staf, akun portal kerja, konfigurasi jam kerja presensi biometrik, 
                serta penentuan <strong>Tarif Upah Borongan Universal</strong> yang terhubung langsung ke SPK Job Produksi.
            </p>
        </div>
        <div style="display:flex; gap:10px; align-items:center;">
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_employees_nonce'); ?>
                <input type="hidden" name="pk01_export_employees_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-outline" style="color:#fff!important; background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.25);">
                    📥 Ekspor CSV
                </button>
            </form>
            <a href="#pk01-form-anchor" class="pk01-btn pk01-btn-dark" style="background:#4f46e5;">
                ➕ Tambah Karyawan
            </a>
        </div>
    </div>

    <?php echo $notice; ?>

    <!-- 2. KPI METRICS -->
    <div class="pk01-kpi-deck">
        <div class="pk01-kpi-item c-indigo">
            <div class="pk01-kpi-label">Total Staf Karyawan</div>
            <div class="pk01-kpi-number"><?php echo number_format($total_employees); ?> <span style="font-size:14px;font-weight:400;color:#64748b;">Orang</span></div>
            <div class="pk01-kpi-sub">Terdaftar di seluruh departemen</div>
        </div>
        <div class="pk01-kpi-item c-emerald">
            <div class="pk01-kpi-label">Staf Status Aktif</div>
            <div class="pk01-kpi-number" style="color:#059669;"><?php echo number_format($active_employees); ?> <span style="font-size:14px;font-weight:400;color:#64748b;">Orang</span></div>
            <div class="pk01-kpi-sub">Dapat menerima SPK &amp; Jobsheet</div>
        </div>
        <div class="pk01-kpi-item c-amber">
            <div class="pk01-kpi-label">Tenaga Kerja Borongan</div>
            <div class="pk01-kpi-number" style="color:#d97706;"><?php echo number_format($piece_employees); ?> <span style="font-size:14px;font-weight:400;color:#64748b;">Staf</span></div>
            <div class="pk01-kpi-sub">Menggunakan multi-job rate</div>
        </div>
        <div class="pk01-kpi-item c-rose">
            <div class="pk01-kpi-label">Akun Portal Terhubung</div>
            <div class="pk01-kpi-number" style="color:#e11d48;"><?php echo number_format($linked_users); ?> <span style="font-size:14px;font-weight:400;color:#64748b;">User</span></div>
            <div class="pk01-kpi-sub">Memiliki akses aplikasi web</div>
        </div>
    </div>

    <!-- 3. SPLIT FORM & SYSTEM GUIDE -->
    <div class="pk01-split-grid" id="pk01-form-anchor">
        
        <!-- Form Karyawan & Borongan -->
        <div class="pk01-card">
            <div class="pk01-card-header">
                <h3 class="pk01-card-title">
                    <?php echo $edit ? '✏️ Edit Profil Karyawan: ' . esc_html($edit['name']) : '➕ Tambah Data Karyawan Baru'; ?>
                </h3>
                <?php if ($edit): ?>
                    <a href="<?php echo esc_url($current_url); ?>" style="font-size:12px; color:#ef4444; font-weight:700; text-decoration:none;">✕ Batal Edit</a>
                <?php endif; ?>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('pk01_employee_save_action', 'pk01_employee_nonce'); ?>
                <input type="hidden" name="pk01_employee_save" value="1">
                <input type="hidden" name="emp_id" value="<?php echo (int)($edit['id'] ?? 0); ?>">

                <div class="pk01-grid-fields">
                    <div class="pk01-group">
                        <label>Kode Karyawan</label>
                        <input type="text" name="emp_code" class="pk01-ctrl" value="<?php echo esc_attr($edit['code'] ?? ''); ?>" placeholder="Otomatis (cth: KRY-001)">
                    </div>
                    <div class="pk01-group">
                        <label>Nama Lengkap <span style="color:#ef4444;">*</span></label>
                        <input type="text" name="emp_name" class="pk01-ctrl" required value="<?php echo esc_attr($edit['name'] ?? ''); ?>" placeholder="Nama lengkap staf">
                    </div>
                    <div class="pk01-group">
                        <label>Jabatan / Peran</label>
                        <input type="text" name="emp_position" class="pk01-ctrl" value="<?php echo esc_attr($edit['position'] ?? ''); ?>" placeholder="Cth: Operator Mesin / Staf Finishing">
                    </div>
                    <div class="pk01-group">
                        <label>Divisi / Departemen</label>
                        <input type="text" name="emp_division" list="pk01-div-list" class="pk01-ctrl" value="<?php echo esc_attr($edit['division'] ?? ''); ?>" placeholder="Cth: Produksi / Assembly">
                        <datalist id="pk01-div-list">
                            <?php foreach ($divisions_list as $div): ?>
                                <option value="<?php echo esc_attr($div); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="pk01-group">
                        <label>Sistem Penggajian <span style="color:#ef4444;">*</span></label>
                        <select name="emp_pay_type" id="pk01-pay-select" class="pk01-ctrl" style="font-weight:700;">
                            <option value="monthly" <?php selected($edit['pay_type'] ?? 'monthly', 'monthly'); ?>>Gaji Pokok Bulanan</option>
                            <option value="daily" <?php selected($edit['pay_type'] ?? '', 'daily'); ?>>Upah Harian</option>
                            <option value="piece" <?php selected($edit['pay_type'] ?? '', 'piece'); ?>>Borongan Universal (Multi-Job)</option>
                        </select>
                    </div>

                    <div class="pk01-group" id="pk01-rate-wrap">
                        <label id="pk01-rate-label">Tarif Standar (Rp)</label>
                        <input type="text" name="emp_rate" id="pk01-rate-input" class="pk01-ctrl" value="<?php echo esc_attr(number_format((float)($edit['rate'] ?? 0), 0, ',', '.')); ?>">
                    </div>

                    <div class="pk01-group">
                        <label>Status Karyawan</label>
                        <select name="emp_status" class="pk01-ctrl">
                            <option value="active" <?php selected($edit['status'] ?? 'active', 'active'); ?>>Aktif (Dapat Terima SPK)</option>
                            <option value="inactive" <?php selected($edit['status'] ?? '', 'inactive'); ?>>Nonaktif / Resigned</option>
                        </select>
                    </div>

                    <div class="pk01-group">
                        <label>Akun WordPress (Portal Login)</label>
                        <select name="emp_user_id" class="pk01-ctrl">
                            <option value="0">— Belum Ditautkan —</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?php echo (int)$u->ID; ?>" <?php selected((int)($edit['user_id'] ?? 0), (int)$u->ID); ?>>
                                    <?php echo esc_html($u->display_name . ' (@' . $u->user_login . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Presensi Shift & Bio ID -->
                    <div class="pk01-group">
                        <label>Jam Kerja Presensi (Masuk - Pulang)</label>
                        <div style="display:flex; gap:6px; align-items:center;">
                            <input type="time" name="emp_work_start" class="pk01-ctrl" value="<?php echo esc_attr($edit['work_start'] ?? '08:00'); ?>">
                            <span>s/d</span>
                            <input type="time" name="emp_work_end" class="pk01-ctrl" value="<?php echo esc_attr($edit['work_end'] ?? '17:00'); ?>">
                        </div>
                    </div>
                    <div class="pk01-group">
                        <label>PIN / ID Mesin Biometrik</label>
                        <input type="text" name="emp_biometric_id" class="pk01-ctrl" value="<?php echo esc_attr($edit['biometric_id'] ?? ''); ?>" placeholder="UID Mesin / Kartu RFID">
                    </div>
                </div>

                <!-- MATRIKS TARIF BORONGAN (DYNAMIC REPEATER) -->
                <div id="pk01-piece-matrix-box" class="pk01-piece-panel" style="display:none;">
                    <div class="pk01-piece-toolbar">
                        <div>
                            <strong style="font-size:13.5px; color:#0f172a;">🛠️ Matriks Tarif Borongan Universal</strong>
                            <p style="margin:2px 0 0; font-size:12px; color:#64748b;">Tambahkan daftar pekerjaan &amp; upah borongan satuan yang dikuasai staf ini.</p>
                        </div>
                        <button type="button" id="pk01-add-job-row" class="pk01-btn pk01-btn-sm" style="background:#e0e7ff; color:#3730a3;">
                            + Tambah Pekerjaan
                        </button>
                    </div>

                    <!-- Tidak ada preset pekerjaan/upah hard-coded. Semua pekerjaan dan tarif harus berasal dari data master/konfigurasi nyata. -->

                    <div id="pk01-piece-rows" style="display:grid; gap:8px;">
                        <?php if (!empty($existing_piece_rates)): foreach ($existing_piece_rates as $pr): ?>
                            <div class="pk01-piece-row" style="display:flex; gap:8px; align-items:center;">
                                <input type="text" name="piece_jobs[]" value="<?php echo esc_attr($pr['job_name']); ?>" placeholder="Nama Job (cth: Frame HP)" class="pk01-ctrl" style="flex:2;" required>
                                <input type="number" step="any" min="0" name="piece_rates[]" value="<?php echo esc_attr($pr['rate']); ?>" placeholder="Tarif (Rp)" class="pk01-ctrl" style="flex:1.2;" required>
                                <input type="text" name="piece_units[]" value="<?php echo esc_attr($pr['unit'] ?: 'pcs'); ?>" placeholder="Satuan" class="pk01-ctrl" style="width:85px;">
                                <button type="button" class="pk01-del-row" style="background:#fee2e2; color:#b91c1c; border:none; border-radius:6px; padding:9px 12px; cursor:pointer;" title="Hapus">✕</button>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>

                <div style="margin-top:22px; display:flex; gap:10px;">
                    <button class="pk01-btn pk01-btn-dark" type="submit">
                        <?php echo $edit ? '💾 Perbarui Profil Karyawan' : '💾 Simpan Data Karyawan'; ?>
                    </button>
                    <?php if ($edit): ?>
                        <a class="pk01-btn pk01-btn-outline" href="<?php echo esc_url($current_url); ?>">Batalkan</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- System Architecture Card -->
        <div class="pk01-card" style="background:#f8fafc;">
            <div class="pk01-card-header">
                <h3 class="pk01-card-title">💡 Panduan Ekosistem Kerja PK01</h3>
            </div>
            <div style="font-size:13px; color:#475569; line-height:1.6;">
                <p style="margin-top:0;">
                    <b>Sistem Borongan Universal</b> membebaskan Anda dari pembuatan banyak akun staf untuk orang yang sama. Satu staf dapat menguasai banyak lini kerja sekaligus dengan tarif berbeda.
                </p>
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px; margin-bottom:14px;">
                    <div style="font-weight:700; color:#0f172a; margin-bottom:6px;">Alur Integrasi Otomatis:</div>
                    <ol style="margin:0; padding-left:18px;">
                        <li>Staf ditugaskan pada nomor <b>SPK Job Produksi</b>.</li>
                        <li>Sistem mencocokkan tarif dari matriks borongan karyawan ini.</li>
                        <li>Total hasil kerja per satuan dihitung otomatis ke dalam <b>Slip Payroll</b>.</li>
                    </ol>
                </div>
                <p style="margin-bottom:0; font-size:12px; color:#64748b;">
                    🔒 Staf yang ditautkan ke akun WordPress dapat mengakses modul <i>Mandiri Staf</i> untuk cek absensi, jam lembur, dan histori borongan.
                </p>
            </div>
        </div>

    </div>

    <!-- 4. TABEL DATA MASTER KARYAWAN -->
    <div class="pk01-table-card">
        
        <!-- Filter Deck -->
        <div class="pk01-filter-deck">
            <div class="pk01-filter-group">
                <button type="button" class="pk01-tab-filter is-active" data-filter="status" data-val="all">Semua (<?php echo (int)$total_employees; ?>)</button>
                <button type="button" class="pk01-tab-filter" data-filter="status" data-val="active">Aktif (<?php echo (int)$active_employees; ?>)</button>
                <button type="button" class="pk01-tab-filter" data-filter="pay" data-val="piece">Borongan (<?php echo (int)$piece_employees; ?>)</button>
                <button type="button" class="pk01-tab-filter" data-filter="pay" data-val="standard">Gaji Pokok (<?php echo (int)($total_employees - $piece_employees); ?>)</button>
            </div>
            
            <div style="display:flex; gap:8px;">
                <select id="pk01-filter-division" class="pk01-ctrl" style="width:160px; font-size:12px; padding:6px 10px;">
                    <option value="">-- Semua Divisi --</option>
                    <?php foreach ($divisions_list as $div): ?>
                        <option value="<?php echo esc_attr(strtolower($div)); ?>"><?php echo esc_html($div); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="search" id="pk01-table-search" class="pk01-ctrl" placeholder="🔍 Cari nama, kode, akun..." style="width:220px; font-size:12px; padding:6px 10px;">
            </div>
        </div>

        <div class="pk01-table-scroll">
            <table class="pk01-main-table" id="pk01-emp-table">
                <thead>
                    <tr>
                        <th style="width:80px;">Kode</th>
                        <th>Identitas Karyawan</th>
                        <th>Jabatan &amp; Divisi</th>
                        <th>Sistem Penggajian</th>
                        <th>Tarif Upah Standar / Borongan</th>
                        <th style="text-align:center; width:90px;">Status</th>
                        <th style="text-align:center; width:140px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($rows)): foreach ($rows as $r): 
                        $is_piece  = (($r['pay_type'] ?? '') === 'piece');
                        $is_act    = (($r['status'] ?? '') === 'active');
                        $emp_rates = $all_piece_rates[$r['id']] ?? [];

                        // Inisial Nama
                        $name_parts = explode(' ', trim($r['name']));
                        $initials = count($name_parts) >= 2 
                            ? mb_substr($name_parts[0], 0, 1) . mb_substr($name_parts[1], 0, 1) 
                            : mb_substr($name_parts[0], 0, 2);
                    ?>
                    <tr data-status="<?php echo $is_act ? 'active' : 'inactive'; ?>" 
                        data-pay="<?php echo $is_piece ? 'piece' : 'standard'; ?>" 
                        data-div="<?php echo esc_attr(strtolower($r['division'] ?? '')); ?>">
                        <td>
                            <code style="background:#f1f5f9; padding:2px 6px; border-radius:4px; font-weight:700; color:#0f172a; border:1px solid #e2e8f0;">
                                <?php echo esc_html($r['code']); ?>
                            </code>
                        </td>
                        <td>
                            <div class="pk01-emp-identity">
                                <div class="pk01-avatar"><?php echo esc_html($initials); ?></div>
                                <div>
                                    <strong style="color:#0f172a; font-size:13.5px;"><?php echo esc_html($r['name']); ?></strong>
                                    <?php if (!empty($r['user_login'])): ?>
                                        <div style="font-size:11.5px; color:#6366f1; font-weight:600;">@<?php echo esc_html($r['user_login']); ?></div>
                                    <?php else: ?>
                                        <div style="font-size:11px; color:#94a3b8;">Tanpa Akun Login</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div style="font-weight:600; color:#334155;"><?php echo esc_html($r['position'] ?: '—'); ?></div>
                            <div style="font-size:11.5px; color:#64748b;"><?php echo esc_html($r['division'] ?: 'Umum'); ?></div>
                        </td>
                        <td>
                            <?php if ($is_piece): ?>
                                <span class="pk01-badge pk01-badge-piece">⚡ Borongan Universal</span>
                            <?php else: ?>
                                <span class="pk01-badge" style="background:#f1f5f9; color:#475569;">
                                    <?php echo esc_html(strtoupper($r['pay_type'])); ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($is_piece): ?>
                                <?php if (!empty($emp_rates)): ?>
                                    <button type="button" class="pk01-btn pk01-btn-outline pk01-btn-sm pk01-view-rates" 
                                        data-name="<?php echo esc_attr($r['name']); ?>" 
                                        data-rates="<?php echo esc_attr(wp_json_encode($emp_rates)); ?>">
                                        🔍 Lihat <?php echo count($emp_rates); ?> Tarif Borongan
                                    </button>
                                <?php else: ?>
                                    <span style="color:#94a3b8; font-size:12px;">Belum diatur</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <strong style="color:#047857; font-family:monospace; font-size:13.5px;">
                                    Rp <?php echo number_format((float)$r['rate'], 0, ',', '.'); ?>
                                </strong>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center;">
                            <span class="pk01-badge <?php echo $is_act ? 'pk01-badge-active' : 'pk01-badge-inactive'; ?>">
                                ● <?php echo $is_act ? 'Aktif' : 'Nonaktif'; ?>
                            </span>
                        </td>
                        <td style="text-align:center;">
                            <div style="display:flex; justify-content:center; gap:4px;">
                                <a class="pk01-btn pk01-btn-outline pk01-btn-sm" href="<?php echo esc_url(add_query_arg('edit_id', (int)$r['id'])); ?>" title="Edit">
                                    ✏️
                                </a>
                                <a class="pk01-btn pk01-btn-outline pk01-btn-sm" 
                                   href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action' => 'toggle_status', 'target_id' => (int)$r['id']]), 'pk01_emp_quick_action')); ?>" 
                                   title="<?php echo $is_act ? 'Nonaktifkan' : 'Aktifkan'; ?>"
                                   onclick="return confirm('Ubah status aktif staf ini?');">
                                    <?php echo $is_act ? '⏸️' : '▶️'; ?>
                                </a>
                                <a class="pk01-btn pk01-btn-outline pk01-btn-sm" style="color:#ef4444!important;" 
                                   href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action' => 'delete', 'target_id' => (int)$r['id']]), 'pk01_emp_quick_action')); ?>" 
                                   title="Hapus"
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus data karyawan ini secara permanen?');">
                                    🗑️
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="7" style="text-align:center; padding:35px; color:#94a3b8;">Belum ada basis data karyawan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- MODAL QUICK VIEW TARIF BORONGAN -->
<div id="pk01-rates-modal" class="pk01-modal">
    <div class="pk01-modal-card">
        <div style="padding:18px 22px; border-bottom:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center;">
            <h4 style="margin:0; font-size:16px; font-weight:800; color:#0f172a;" id="pk01-modal-emp-name">Matriks Tarif Borongan</h4>
            <button type="button" id="pk01-close-modal" style="background:none; border:none; font-size:18px; cursor:pointer; color:#64748b;">✕</button>
        </div>
        <div style="padding:20px; max-height:400px; overflow-y:auto;" id="pk01-modal-body">
            <!-- Rendered by JS -->
        </div>
        <div style="padding:14px 20px; background:#f8fafc; border-top:1px solid #e2e8f0; text-align:right;">
            <button type="button" class="pk01-btn pk01-btn-dark pk01-btn-sm" id="pk01-close-modal-btn">Tutup</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var paySelect   = document.getElementById('pk01-pay-select');
    var rateWrap    = document.getElementById('pk01-rate-wrap');
    var matrixBox   = document.getElementById('pk01-piece-matrix-box');
    var addBtn      = document.getElementById('pk01-add-job-row');
    var rowsBox     = document.getElementById('pk01-piece-rows');
    var rateLabel   = document.getElementById('pk01-rate-label');
    var rateInput   = document.getElementById('pk01-rate-input');
    var presetPills = document.querySelectorAll('.pk01-pill');

    // Format Number to Rupiah Format Live
    if (rateInput) {
        rateInput.addEventListener('input', function(e) {
            var val = this.value.replace(/[^0-9]/g, '');
            this.value = val ? parseInt(val, 10).toLocaleString('id-ID') : '0';
        });
    }

    function togglePayTypeUI() {
        if (!paySelect) return;
        var pType = paySelect.value;
        if (pType === 'piece') {
            if (rateWrap) rateWrap.style.display = 'none';
            if (matrixBox) matrixBox.style.display = 'block';
            if (rowsBox && rowsBox.children.length === 0) {
                appendPieceRow('Frame HP', 3500, 'pcs');
            }
        } else {
            if (rateWrap) rateWrap.style.display = 'flex';
            if (matrixBox) matrixBox.style.display = 'none';
            if (rateLabel) {
                rateLabel.innerText = (pType === 'daily') ? 'Tarif Upah Harian (Rp)' : 'Gaji Pokok Bulanan (Rp)';
            }
        }
    }

    function appendPieceRow(jobName, rateVal, unitVal) {
        if (!rowsBox) return;
        var row = document.createElement('div');
        row.className = 'pk01-piece-row';
        row.style.display = 'flex';
        row.style.gap = '8px';
        row.style.alignItems = 'center';

        row.innerHTML = 
            '<input type="text" name="piece_jobs[]" value="' + (jobName || '') + '" placeholder="Nama Pekerjaan (cth: Amplas Halus)" class="pk01-ctrl" style="flex:2;" required>' +
            '<input type="number" step="any" min="0" name="piece_rates[]" value="' + (rateVal || '') + '" placeholder="Tarif (Rp)" class="pk01-ctrl" style="flex:1.2;" required>' +
            '<input type="text" name="piece_units[]" value="' + (unitVal || 'pcs') + '" placeholder="Satuan" class="pk01-ctrl" style="width:85px;">' +
            '<button type="button" class="pk01-del-row" style="background:#fee2e2; color:#b91c1c; border:none; border-radius:6px; padding:9px 12px; cursor:pointer;">✕</button>';

        rowsBox.appendChild(row);
    }

    if (paySelect) {
        paySelect.addEventListener('change', togglePayTypeUI);
        togglePayTypeUI();
    }

    if (addBtn) {
        addBtn.addEventListener('click', function() {
            appendPieceRow('', '', 'pcs');
        });
    }

    if (presetPills.length > 0) {
        presetPills.forEach(function(p) {
            p.addEventListener('click', function() {
                appendPieceRow(this.dataset.job, this.dataset.rate, this.dataset.unit);
            });
        });
    }

    if (rowsBox) {
        rowsBox.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('pk01-del-row')) {
                var row = e.target.closest('.pk01-piece-row');
                if (row) row.remove();
            }
        });
    }

    // Modal Rates Viewer
    var modal     = document.getElementById('pk01-rates-modal');
    var modalName = document.getElementById('pk01-modal-emp-name');
    var modalBody = document.getElementById('pk01-modal-body');
    var viewBtns  = document.querySelectorAll('.pk01-view-rates');

    viewBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var name = this.dataset.name;
            var rates = JSON.parse(this.dataset.rates || '[]');
            
            modalName.innerText = 'Matriks Upah: ' + name;
            var html = '<table style="width:100%; border-collapse:collapse; font-size:13px;">';
            html += '<tr style="background:#f8fafc;"><th style="padding:8px; border-bottom:1px solid #e2e8f0; text-align:left;">Item Pekerjaan</th><th style="padding:8px; border-bottom:1px solid #e2e8f0; text-align:right;">Tarif Upah</th></tr>';
            
            rates.forEach(function(r) {
                var rateFmt = parseInt(r.rate, 10).toLocaleString('id-ID');
                html += '<tr><td style="padding:8px; border-bottom:1px solid #f1f5f9; font-weight:600;">' + r.job_name + '</td><td style="padding:8px; border-bottom:1px solid #f1f5f9; text-align:right; color:#059669; font-family:monospace; font-weight:700;">Rp ' + rateFmt + ' / ' + (r.unit || 'pcs') + '</td></tr>';
            });
            html += '</table>';
            modalBody.innerHTML = html;
            modal.style.display = 'flex';
        });
    });

    function closeModal() { if (modal) modal.style.display = 'none'; }
    var cBtn = document.getElementById('pk01-close-modal');
    var cBtn2 = document.getElementById('pk01-close-modal-btn');
    if (cBtn) cBtn.addEventListener('click', closeModal);
    if (cBtn2) cBtn2.addEventListener('click', closeModal);

    // Live Multi-Filter
    var searchBox   = document.getElementById('pk01-table-search');
    var divSelect   = document.getElementById('pk01-filter-division');
    var filterTabs  = document.querySelectorAll('.pk01-tab-filter');
    var tableEl     = document.getElementById('pk01-emp-table');
    var currentFilter = { type: 'status', val: 'all' };

    function runFilters() {
        if (!tableEl) return;
        var q = searchBox ? searchBox.value.toLowerCase().trim() : '';
        var divVal = divSelect ? divSelect.value.toLowerCase() : '';
        var rows = tableEl.querySelectorAll('tbody tr');

        rows.forEach(function(row) {
            var status  = row.getAttribute('data-status') || '';
            var pay     = row.getAttribute('data-pay') || '';
            var div     = row.getAttribute('data-div') || '';
            var content = row.innerText.toLowerCase();

            var matchSearch = (content.indexOf(q) > -1);
            var matchDiv    = (!divVal || div === divVal);
            var matchTab    = true;

            if (currentFilter.type === 'status') {
                if (currentFilter.val !== 'all') matchTab = (status === currentFilter.val);
            } else if (currentFilter.type === 'pay') {
                matchTab = (pay === currentFilter.val);
            }

            if (matchSearch && matchDiv && matchTab) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    if (searchBox) searchBox.addEventListener('input', runFilters);
    if (divSelect) divSelect.addEventListener('change', runFilters);

    filterTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            filterTabs.forEach(function(t) { t.classList.remove('is-active'); });
            this.classList.add('is-active');
            currentFilter.type = this.dataset.filter;
            currentFilter.val  = this.dataset.val;
            runFilters();
        });
    });
});
</script>