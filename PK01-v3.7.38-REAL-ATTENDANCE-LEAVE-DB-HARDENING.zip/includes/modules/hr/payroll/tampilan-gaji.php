<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || 
              (class_exists('PK01_Authorization') && (PK01_Authorization::can('payroll') || PK01_Authorization::can('hrd') || PK01_Authorization::can('finance')));

// 2. DETEKSI TABEL-TABEL TERKAIT
$get_table = function($key) use ($wpdb) {
    $t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t) ? $t : false;
};

$tbl_payroll   = $get_table('payroll');
$tbl_employees = $get_table('employees');
$tbl_costs     = $get_table('operational_costs');
$tbl_logs      = $get_table('logs');

$current_period = current_time('Y-m');

// 3. LOGIKA BARU: EKSPOR PAYROLL PERIODE INI KE CSV (BATCH TRANSFER BANK)
if (isset($_POST['pk01_export_payroll_csv']) && check_admin_referer('pk01_export_payroll_nonce')) {
    if ($can_manage && $tbl_payroll) {
        $export_data = $wpdb->get_results($wpdb->prepare(
            "SELECT p.id, COALESCE(NULLIF(p.name, ''), e.name) AS emp_name, e.position, p.period, p.amount, p.payment_method, p.status, p.created_at
             FROM `{$tbl_payroll}` p
             LEFT JOIN `{$tbl_employees}` e ON e.id = p.employee_id
             WHERE p.period = %s
             ORDER BY p.id DESC",
            $current_period
        ), ARRAY_A);

        if (!empty($export_data)) {
            $filename = 'pk01-payroll-disbursal-' . $current_period . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID Slip', 'Nama Karyawan', 'Jabatan', 'Periode', 'Gaji Bersih (Rp)', 'Metode Pembayaran', 'Status', 'Tanggal Input']);
            foreach ($export_data as $row) {
                fputcsv($out, $row);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. PROSES SIMPAN / BAYAR GAJI KARYAWAN (LOGIKA LAMA TETAP UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_process_payroll'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-pay-alert is-error">⚠️ Anda tidak memiliki izin otorisasi untuk memproses payroll.</div>';
    } else {
        $nonce = sanitize_text_field(wp_unslash($_POST['pk01_payroll_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'pk01_payroll_save')) {
            $notice = '<div class="pk01-pay-alert is-error">⚠️ Sesi tidak valid atau telah kedaluwarsa. Silakan muat ulang halaman.</div>';
        } else {
            $employee_id    = absint($_POST['employee_id'] ?? 0);
            $custom_name    = sanitize_text_field(wp_unslash($_POST['employee_name'] ?? ''));
            $period         = sanitize_text_field(wp_unslash($_POST['period'] ?? $current_period));
            $amount_raw     = sanitize_text_field(wp_unslash($_POST['amount'] ?? '0'));
            $amount         = (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', $amount_raw));
            $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method'] ?? 'Transfer Bank'));
            $status         = sanitize_text_field(wp_unslash($_POST['status'] ?? 'paid'));
            $description    = sanitize_textarea_field(wp_unslash($_POST['description'] ?? ''));
            $paid_at        = ($status === 'paid') ? current_time('Y-m-d') : null;

            // Cari nama karyawan riil dari database
            $emp_name = $custom_name;
            if ($employee_id > 0 && $tbl_employees) {
                $db_emp_name = $wpdb->get_var($wpdb->prepare("SELECT name FROM `{$tbl_employees}` WHERE id = %d", $employee_id));
                if ($db_emp_name) $emp_name = $db_emp_name;
            }

            if ($employee_id <= 0) {
                $notice = '<div class="pk01-pay-alert is-error">⚠️ Pilih karyawan dari master SDM agar payroll dan slip gaji terhubung ke staf yang benar.</div>';
            } elseif (empty($emp_name)) {
                $notice = '<div class="pk01-pay-alert is-error">⚠️ Tentukan nama karyawan penerima gaji.</div>';
            } else {
                try {
                    $components = [];
                    $component_map = [
                        ['code'=>'uang_makan',      'name'=>'Uang Makan',       'field'=>'uang_makan',      'type'=>'earning'],
                        ['code'=>'transport',       'name'=>'Transport',        'field'=>'transport',       'type'=>'earning'],
                        ['code'=>'tunjangan',       'name'=>'Tunjangan',        'field'=>'tunjangan',       'type'=>'earning'],
                        ['code'=>'bonus_kehadiran', 'name'=>'Bonus Kehadiran',  'field'=>'bonus_kehadiran', 'type'=>'earning'],
                        ['code'=>'bonus_lain',      'name'=>'Bonus Lainnya',    'field'=>'bonus_lain',      'type'=>'earning'],
                        ['code'=>'kasbon',          'name'=>'Potongan Kasbon',  'field'=>'kasbon',          'type'=>'deduction'],
                        ['code'=>'potongan_lain',   'name'=>'Potongan Lainnya', 'field'=>'potongan_lain',   'type'=>'deduction'],
                    ];
                    
                    foreach ($component_map as $cm) { 
                        $v = (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)($_POST[$cm['field']] ?? 0))); 
                        if ($v > 0) {
                            $components[] = ['code'=>$cm['code'], 'name'=>$cm['name'], 'type'=>$cm['type'], 'amount'=>$v]; 
                        }
                    }
                    
                    if ($employee_id > 0) { 
                        $emp_rate = (float) $wpdb->get_var($wpdb->prepare("SELECT rate FROM `{$tbl_employees}` WHERE id=%d", $employee_id)); 
                        if ($emp_rate <= 0 && $amount > 0) {
                            $components[] = ['code'=>'gaji_pokok_manual', 'name'=>'Gaji Pokok Manual', 'type'=>'earning', 'amount'=>$amount]; 
                        }
                    }
                    
                    $result = PK01_Engine::create_payroll($employee_id, $period, $status, $payment_method, $description, $components);
                    $payroll_id = (int)($result['id'] ?? 0);

                    $notice = '<div class="pk01-pay-alert is-success">✅ Pembayaran gaji untuk <strong>' . esc_html($emp_name) . '</strong> sebesar <b>Rp ' . number_format($amount, 0, ',', '.') . '</b> berhasil dibukukan dan disinkronkan ke laporan Biaya Operasional.</div>';
                    $_POST = [];
                } catch (Throwable $e) {
                    $notice = '<div class="pk01-pay-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
                }
            }
        }
    }
}

// 5. KUERI DATA REAL: REKAP PAYROLL BULAN INI
$total_paid_month = 0;
$pending_payroll_count = 0;
$total_employees_count = 0;
$count_paid_employees = 0;
$avg_payroll = 0;

if ($tbl_payroll) {
    $paid_val = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM `{$tbl_payroll}` WHERE status = 'paid' AND period = %s",
        $current_period
    ));
    $total_paid_month = (float) $paid_val;

    $pending_payroll_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM `{$tbl_payroll}` WHERE status = 'pending' AND period = %s",
        $current_period
    );

    $count_paid_employees = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT employee_id) FROM `{$tbl_payroll}` WHERE status = 'paid' AND period = %s",
        $current_period
    ));

    if ($count_paid_employees > 0) {
        $avg_payroll = $total_paid_month / $count_paid_employees;
    }
}

// Ambil daftar karyawan riil aktif
$employee_options = [];
if ($tbl_employees) {
    $employee_options = $wpdb->get_results("SELECT id, name, position, pay_type, rate FROM `{$tbl_employees}` ORDER BY name ASC", ARRAY_A) ?: [];
    $total_employees_count = count($employee_options);
}

// Slip Gaji & Upah Riil Terbaru
$slip_rows = [];
if ($tbl_payroll) {
    $slip_rows = $wpdb->get_results(
        "SELECT p.id, p.name, p.period, p.amount, p.status, e.name AS employee_master, e.position 
         FROM `{$tbl_payroll}` p 
         LEFT JOIN `{$tbl_employees}` e ON e.id = p.employee_id 
         ORDER BY p.id DESC LIMIT 25", 
        ARRAY_A
    ) ?: [];
}
?>

<style>
:root {
    --pk-pay-navy: #0f172a;
    --pk-pay-border: #e2e8f0;
    --pk-pay-green: #059669;
    --pk-pay-amber: #d97706;
    --pk-pay-blue: #2563eb;
    --pk-pay-red: #dc2626;
}

.pk01-payroll-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-payroll-cockpit * { box-sizing: border-box; }

/* Header Banner */
.pk01-pay-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #064e3b 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-pay-eyebrow {
    display: inline-block;
    background: rgba(52, 211, 153, 0.15);
    color: #34d399;
    border: 1px solid rgba(52, 211, 153, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-pay-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-pay-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-pay-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-pay-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-green::before { background: var(--pk-pay-green); }
.pk01-kpi-card.c-amber::before { background: var(--pk-pay-amber); }
.pk01-kpi-card.c-blue::before  { background: var(--pk-pay-blue); }
.pk01-kpi-card.c-navy::before  { background: #475569; }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: #64748b;
}

/* Card Surface */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-pay-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h2 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-surface-head p {
    margin: 4px 0 0 0;
    font-size: 13px;
    color: #64748b;
}

/* Grid Form */
.pk01-pay-form-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}
@media (max-width: 900px) {
    .pk01-pay-form-grid { grid-template-columns: 1fr; }
}

.pk01-form-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-form-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: #059669;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.15);
}

/* Components Box */
.pk01-comp-box {
    grid-column: 1 / -1;
    background: #f8fafc;
    border: 1px solid var(--pk-pay-border);
    border-radius: 12px;
    padding: 16px 18px;
    margin-top: 6px;
}
.pk01-comp-title {
    font-size: 12px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.6px;
    color: #475569;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.pk01-comp-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 12px;
}

/* Live Take-Home Pay (THP) Calculation Bar */
.pk01-thp-live-bar {
    grid-column: 1 / -1;
    background: #f0fdf4;
    border: 1px dashed #86efac;
    border-radius: 10px;
    padding: 14px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 14px;
    margin-top: 8px;
}
.pk01-thp-item {
    font-size: 12px;
    color: #166534;
}
.pk01-thp-item b {
    font-size: 15px;
    font-family: monospace;
    color: #14532d;
    display: block;
    margin-top: 2px;
}

/* Slip Table */
.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-pay-border);
    border-radius: 10px;
}
.pk01-slip-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-slip-table th {
    background: #f8fafc;
    padding: 11px 12px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-pay-border);
}
.pk01-slip-table td {
    padding: 11px 12px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-slip-table tr:hover td { background: #fbfcfe; }

/* Status Badges */
.pk01-pay-status {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.st-paid    { background: #dcfce7; color: #166534; }
.st-pending { background: #fef3c7; color: #92400e; }

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }
.pk01-btn-pdf {
    background: #eff6ff;
    color: #2563eb !important;
    border: 1px solid #bfdbfe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.pk01-btn-pdf:hover {
    background: #2563eb;
    color: #ffffff !important;
}

.pk01-pay-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-pay-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-pay-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-payroll-cockpit">
    
    <!-- 1. HERO COCKPIT -->
    <header class="pk01-pay-hero">
        <div>
            <span class="pk01-pay-eyebrow">HUMAN CAPITAL &bull; COMPENSATION ENGINE</span>
            <h1>Penggajian Karyawan &amp; Slip Payroll</h1>
            <p>
                Kelola gaji reguler, tunjangan, uang makan, insentif lembur, dan potongan kasbon. 
                Gaji berstatus <strong>Lunas</strong> otomatis memotong kas pembayaran dan tersinkronisasi ke laporan Laba Rugi tanpa input ganda.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_payroll_nonce'); ?>
                <input type="hidden" name="pk01_export_payroll_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Payroll Periode (.CSV)
                </button>
            </form>
        </div>
    </header>

    <!-- 2. 4 EXECUTIVE KPI CARDS -->
    <div class="pk01-pay-kpis">
        <div class="pk01-kpi-card c-green">
            <small>Total Gaji Terbayar (Bulan Ini)</small>
            <strong style="color:#059669;">Rp <?php echo number_format($total_paid_month, 0, ',', '.'); ?></strong>
            <span>Periode: <?php echo esc_html($current_period); ?></span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Gaji Menunggu Pembayaran</small>
            <strong style="color:#d97706;"><?php echo (int)$pending_payroll_count; ?> <span style="font-size:13px;font-weight:normal;">Slip</span></strong>
            <span>Terjadwal belum dicairkan</span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Tenaga Kerja Terdata</small>
            <strong><?php echo (int)$total_employees_count; ?> <span style="font-size:13px;font-weight:normal;">Karyawan</span></strong>
            <span>Basis data master SDM aktif</span>
        </div>

        <div class="pk01-kpi-card c-navy">
            <small>Rata-rata Gaji Bersih</small>
            <strong>Rp <?php echo number_format($avg_payroll, 0, ',', '.'); ?></strong>
            <span>Rata-rata THP per karyawan</span>
        </div>
    </div>

    <?php echo $notice; ?>

    <!-- 3. FORM INPUT PENGGAJIAN & KALKULATOR LIVE -->
    <?php if ($can_manage): ?>
    <section class="pk01-surface">
        <div class="pk01-surface-head">
            <div>
                <h2>➕ Proses Penggajian / Payroll Baru</h2>
                <p>Gaji pokok diambil otomatis dari master karyawan, dan dapat ditambah komponen kompensasi harian atau potongan kasbon.</p>
            </div>
            <span style="font-size:11px;background:#f1f5f9;border:1px solid #cbd5e1;padding:4px 10px;border-radius:12px;font-weight:600;color:#475569;">
                Otomatis Sync ke Beban Usaha
            </span>
        </div>

        <form method="post" action="">
            <?php echo wp_nonce_field('pk01_payroll_save', 'pk01_payroll_nonce', true, false); ?>
            <input type="hidden" name="pk01_process_payroll" value="1">

            <div class="pk01-pay-form-grid">
                
                <!-- Karyawan -->
                <div class="pk01-form-item">
                    <label>Pilih Karyawan <span style="color:#dc2626;">*</span></label>
                    <?php if (!empty($employee_options)): ?>
                        <select name="employee_id" id="pk01-select-emp" class="pk01-input" required>
                            <option value="">— Pilih Karyawan Master —</option>
                            <?php foreach ($employee_options as $emp): ?>
                                <option value="<?php echo (int)$emp['id']; ?>" data-rate="<?php echo esc_attr($emp['rate'] ?? 0); ?>" <?php selected($_POST['employee_id'] ?? '', $emp['id']); ?>>
                                    <?php echo esc_html($emp['name']); ?> (<?php echo esc_html($emp['position'] ?: 'Staf'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <input type="text" name="employee_name" class="pk01-input" placeholder="Ketik nama karyawan..." value="<?php echo esc_attr($_POST['employee_name'] ?? ''); ?>" required>
                    <?php endif; ?>
                </div>

                <!-- Periode -->
                <div class="pk01-form-item">
                    <label>Periode Pembayaran <span style="color:#dc2626;">*</span></label>
                    <input type="month" name="period" class="pk01-input" value="<?php echo esc_attr($_POST['period'] ?? $current_period); ?>" required>
                </div>

                <!-- Gaji Pokok -->
                <div class="pk01-form-item">
                    <label>Gaji Pokok / Penyesuaian (Rp)</label>
                    <input type="number" step="any" min="0" id="pk01-payroll-amount" name="amount" class="pk01-input" value="<?php echo esc_attr($_POST['amount'] ?? ''); ?>" placeholder="Otomatis dari master tarif">
                </div>

                <!-- Komponen Kompensasi Terstruktur -->
                <div class="pk01-comp-box">
                    <div class="pk01-comp-title">
                        <span>💵 Rincian Tunjangan &amp; Potongan Payroll:</span>
                    </div>

                    <div class="pk01-comp-grid">
                        <div class="pk01-form-item">
                            <label>Uang Makan (Rp)</label>
                            <input type="number" min="0" step="any" name="uang_makan" class="pk01-input pk01-comp-earning" value="<?php echo esc_attr($_POST['uang_makan'] ?? ''); ?>" placeholder="0">
                        </div>

                        <div class="pk01-form-item">
                            <label>Uang Transport (Rp)</label>
                            <input type="number" min="0" step="any" name="transport" class="pk01-input pk01-comp-earning" value="<?php echo esc_attr($_POST['transport'] ?? ''); ?>" placeholder="0">
                        </div>

                        <div class="pk01-form-item">
                            <label>Tunjangan Jabatan/Lain (Rp)</label>
                            <input type="number" min="0" step="any" name="tunjangan" class="pk01-input pk01-comp-earning" value="<?php echo esc_attr($_POST['tunjangan'] ?? ''); ?>" placeholder="0">
                        </div>

                        <div class="pk01-form-item">
                            <label>Bonus Kehadiran/Target (Rp)</label>
                            <input type="number" min="0" step="any" name="bonus_kehadiran" class="pk01-input pk01-comp-earning" value="<?php echo esc_attr($_POST['bonus_kehadiran'] ?? ''); ?>" placeholder="0">
                        </div>

                        <div class="pk01-form-item">
                            <label>Bonus Lainnya (Rp)</label>
                            <input type="number" min="0" step="any" name="bonus_lain" class="pk01-input pk01-comp-earning" value="<?php echo esc_attr($_POST['bonus_lain'] ?? ''); ?>" placeholder="0">
                        </div>

                        <div class="pk01-form-item">
                            <label style="color:#dc2626;">Potongan Kasbon (Rp)</label>
                            <input type="number" min="0" step="any" name="kasbon" class="pk01-input pk01-comp-deduction" value="<?php echo esc_attr($_POST['kasbon'] ?? ''); ?>" placeholder="0">
                        </div>

                        <div class="pk01-form-item">
                            <label style="color:#dc2626;">Potongan Lain (Rp)</label>
                            <input type="number" min="0" step="any" name="potongan_lain" class="pk01-input pk01-comp-deduction" value="<?php echo esc_attr($_POST['potongan_lain'] ?? ''); ?>" placeholder="0">
                        </div>
                    </div>
                </div>

                <!-- LIVE TAKE-HOME PAY (THP) SUMMARY BAR -->
                <div class="pk01-thp-live-bar">
                    <div class="pk01-thp-item">
                        Gaji Pokok Terpilih: <b id="calc_basic_salary">Rp 0</b>
                    </div>
                    <div class="pk01-thp-item">
                        Total Tunjangan &amp; Bonus: <b id="calc_total_allowance" style="color:#16a34a;">+ Rp 0</b>
                    </div>
                    <div class="pk01-thp-item">
                        Total Potongan: <b id="calc_total_deduction" style="color:#dc2626;">- Rp 0</b>
                    </div>
                    <div class="pk01-thp-item">
                        Estimasi Gaji Bersih (THP): <b id="calc_net_thp" style="font-size:17px;color:#047857;">Rp 0</b>
                    </div>
                </div>

                <!-- Metode Bayar -->
                <div class="pk01-form-item">
                    <label>Metode Pembayaran</label>
                    <select name="payment_method" class="pk01-input">
                        <option value="Transfer Bank BCA" <?php selected($_POST['payment_method'] ?? '', 'Transfer Bank BCA'); ?>>Transfer Bank BCA</option>
                        <option value="Transfer Bank Mandiri" <?php selected($_POST['payment_method'] ?? '', 'Transfer Bank Mandiri'); ?>>Transfer Bank Mandiri</option>
                        <option value="Transfer Bank Lainnya" <?php selected($_POST['payment_method'] ?? '', 'Transfer Bank Lainnya'); ?>>Transfer Bank Lainnya</option>
                        <option value="Kas Tunai" <?php selected($_POST['payment_method'] ?? '', 'Kas Tunai'); ?>>Kas Kecil / Tunai (Petty Cash)</option>
                    </select>
                </div>

                <!-- Status -->
                <div class="pk01-form-item">
                    <label>Status Pembayaran</label>
                    <select name="status" class="pk01-input">
                        <option value="paid" <?php selected($_POST['status'] ?? 'paid', 'paid'); ?>>✅ Lunas (Langsung Catat ke Beban Usaha)</option>
                        <option value="pending" <?php selected($_POST['status'] ?? '', 'pending'); ?>>⏳ Pending (Jadwal Penggajian)</option>
                    </select>
                </div>

                <!-- Keterangan -->
                <div class="pk01-form-item">
                    <label>Keterangan / Catatan Slip</label>
                    <input type="text" name="description" class="pk01-input" placeholder="Rincian lembur, insentif, atau target..." value="<?php echo esc_attr($_POST['description'] ?? ''); ?>">
                </div>

                <div style="grid-column: 1 / -1; margin-top: 6px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        💾 Bukukan Penggajian Karyawan
                    </button>
                </div>
            </div>
        </form>
    </section>
    <?php endif; ?>

    <!-- 4. TABEL SLIP GAJI TERAKHIR & CETAK PDF -->
    <section class="pk01-surface">
        <div class="pk01-surface-head">
            <div>
                <h2>📋 Slip Gaji &amp; Upah Karyawan Terbaru</h2>
                <p>Setiap slip otomatis mengonsolidasikan gaji pokok, kompensasi tambahan, dan rincian upah SPK produksi yang selesai.</p>
            </div>
        </div>

        <div class="pk01-table-wrap">
            <table class="pk01-slip-table">
                <thead>
                    <tr>
                        <th style="width:70px;">ID Slip</th>
                        <th>Nama Karyawan</th>
                        <th>Jabatan</th>
                        <th>Periode</th>
                        <th style="text-align:right;">Total Payroll (THP)</th>
                        <th style="text-align:center;">Status</th>
                        <th style="text-align:center;width:120px;">Cetak Slip</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($slip_rows)): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;padding:32px;color:#94a3b8;">
                                Belum ada slip gaji yang tercatat di sistem.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($slip_rows as $sr): 
                            $st = strtolower($sr['status'] ?? 'paid');
                            $emp_title = $sr['name'] ?: ($sr['employee_master'] ?: '—');
                            $print_slip_url = function_exists('pk01_print_url') 
                                ? pk01_print_url('slip-gaji', (int)$sr['id']) 
                                : add_query_arg(['pk01_print'=>'slip-gaji', 'id'=>(int)$sr['id']], home_url('/'));
                        ?>
                        <tr>
                            <td style="font-family:monospace;font-weight:700;color:#64748b;">#<?php echo esc_html($sr['id']); ?></td>
                            <td><strong style="color:#0f172a;"><?php echo esc_html($emp_title); ?></strong></td>
                            <td><span style="font-size:12px;color:#64748b;"><?php echo esc_html($sr['position'] ?? 'Staf'); ?></span></td>
                            <td><span style="font-family:monospace;font-weight:600;"><?php echo esc_html($sr['period']); ?></span></td>
                            <td style="text-align:right;font-family:monospace;font-weight:700;color:#047857;">
                                Rp <?php echo number_format((float)$sr['amount'], 0, ',', '.'); ?>
                            </td>
                            <td style="text-align:center;">
                                <span class="pk01-pay-status <?php echo ($st === 'paid') ? 'st-paid' : 'st-pending'; ?>">
                                    <?php echo esc_html(strtoupper($st)); ?>
                                </span>
                            </td>
                            <td style="text-align:center;">
                                <a class="pk01-btn-pdf" target="_blank" href="<?php echo esc_url($print_slip_url); ?>">
                                    🖨️ Cetak PDF
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var empSelect    = document.getElementById('pk01-select-emp');
    var amountInput  = document.getElementById('pk01-payroll-amount');

    var earningInputs   = document.querySelectorAll('.pk01-comp-earning');
    var deductionInputs = document.querySelectorAll('.pk01-comp-deduction');

    var calcBasic = document.getElementById('calc_basic_salary');
    var calcAllow = document.getElementById('calc_total_allowance');
    var calcDeduct= document.getElementById('calc_total_deduction');
    var calcNet   = document.getElementById('calc_net_thp');

    function formatRupiah(num) {
        return 'Rp ' + Math.round(num).toLocaleString('id-ID');
    }

    function calculateLiveTHP() {
        var basic = parseFloat(amountInput ? amountInput.value : 0) || 0;
        var totalAllow = 0;
        var totalDeduct = 0;

        earningInputs.forEach(function(inp) {
            totalAllow += parseFloat(inp.value) || 0;
        });

        deductionInputs.forEach(function(inp) {
            totalDeduct += parseFloat(inp.value) || 0;
        });

        var netTHP = Math.max(0, basic + totalAllow - totalDeduct);

        if (calcBasic)  calcBasic.textContent  = formatRupiah(basic);
        if (calcAllow)  calcAllow.textContent  = '+ ' + formatRupiah(totalAllow);
        if (calcDeduct) calcDeduct.textContent = '- ' + formatRupiah(totalDeduct);
        if (calcNet)    calcNet.textContent    = formatRupiah(netTHP);
    }

    if (empSelect && amountInput) {
        empSelect.addEventListener('change', function() {
            var opt = this.options[this.selectedIndex];
            var rate = opt.getAttribute('data-rate');
            if (rate && parseFloat(rate) > 0) {
                amountInput.value = parseFloat(rate);
            }
            calculateLiveTHP();
        });
    }

    if (amountInput) {
        amountInput.addEventListener('input', calculateLiveTHP);
    }

    earningInputs.forEach(function(inp) {
        inp.addEventListener('input', calculateLiveTHP);
    });

    deductionInputs.forEach(function(inp) {
        inp.addEventListener('input', calculateLiveTHP);
    });

    calculateLiveTHP();
});
</script>

<?php
// 6. PEMUATAN TABEL RIWAYAT MODUL DENGAN MULTI-PATH RESOLVER AMAN
$loaded = false;
$candidates = [];

if (defined('PK01_DIR')) {
    $candidates[] = trailingslashit(PK01_DIR) . 'includes/core/view/tampilan-data-modul.php';
}


foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        require_once $cand;
        $loaded = true;
        break;
    }
}

if (function_exists('pk01_tampilkan_data_modul')) {
    pk01_tampilkan_data_modul('payroll', 'Riwayat Payroll Karyawan', 'SDM & KEUANGAN', 'Daftar riwayat seluruh penggajian dan bukti pencairan upah karyawan.');
} elseif (!$loaded) {
    echo '<div style="background:#ffffff;border:1px dashed #cbd5e1;border-radius:12px;padding:26px;text-align:center;color:#64748b;font-size:13px;">
            📁 Modul antarmuka tabel <code>tampilan-data-modul.php</code> belum ditemukan di folder <code>includes/</code>.
          </div>';
}