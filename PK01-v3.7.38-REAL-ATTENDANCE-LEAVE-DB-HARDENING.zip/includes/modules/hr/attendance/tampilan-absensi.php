<?php
if (!defined('ABSPATH')) exit;
if (!is_user_logged_in() || !class_exists('PK01_Authorization') || !PK01_Authorization::can('attendance')) return;

global $wpdb;
$user_id     = get_current_user_id();
$role        = PK01_Authorization::effective_role();
$is_hr       = (bool) array_intersect([$role], ['administrator', 'pk01_admin', 'pk01_hr', 'pk01_keuangan', 'shop_manager']);

// Data Karyawan Login
$me = $wpdb->get_row($wpdb->prepare(
    "SELECT id, code, name, biometric_id, work_start, work_end FROM " . PK01_DB::t('employees') . " WHERE user_id = %d LIMIT 1",
    $user_id
), ARRAY_A);
$employee_id = $me ? (int)$me['id'] : 0;

// Filter Tanggal
$today      = current_time('Y-m-d');
$filter_from = isset($_GET['from']) ? sanitize_text_field($_GET['from']) : current_time('Y-m-01');
$filter_to   = isset($_GET['to']) ? sanitize_text_field($_GET['to']) : $today;
$filter_emp  = isset($_GET['emp_id']) ? (int)$_GET['emp_id'] : 0;

// Data Master
$employees = $is_hr 
    ? $wpdb->get_results("SELECT id, code, name, biometric_id, work_start, work_end, status FROM " . PK01_DB::t('employees') . " WHERE status='active' ORDER BY name ASC", ARRAY_A) 
    : [];

$devices = $is_hr 
    ? $wpdb->get_results("SELECT id, device_code, name, device_type, vendor, model, status, last_seen_at FROM " . PK01_DB::t('attendance_devices') . " ORDER BY id DESC", ARRAY_A) 
    : [];

$types = $wpdb->get_results("SELECT id, code, name, annual_days, paid FROM " . PK01_DB::t('leave_types') . " WHERE active=1 ORDER BY id ASC", ARRAY_A) ?: [];

// Query Attendance Records
$att_where = [];
if (!$is_hr) {
    $att_where[] = $wpdb->prepare("a.employee_id = %d", $employee_id);
} elseif ($filter_emp > 0) {
    $att_where[] = $wpdb->prepare("a.employee_id = %d", $filter_emp);
}
$att_where[] = $wpdb->prepare("a.work_date BETWEEN %s AND %s", $filter_from, $filter_to);
$att_sql_where = implode(' AND ', $att_where);

$records = $wpdb->get_results("
    SELECT a.*, e.name AS employee_name, e.code AS employee_code, e.work_start, d.name AS device_name
    FROM " . PK01_DB::t('attendance_records') . " a
    LEFT JOIN " . PK01_DB::t('employees') . " e ON e.id = a.employee_id
    LEFT JOIN " . PK01_DB::t('attendance_devices') . " d ON d.id = a.device_id
    WHERE {$att_sql_where}
    ORDER BY a.punch_at DESC
    LIMIT 200
", ARRAY_A) ?: [];

// Query Leave Requests
$leave_where = $is_hr ? "1=1" : $wpdb->prepare("lr.employee_id = %d", $employee_id);
$reqs = $wpdb->get_results("
    SELECT lr.*, e.name AS employee_name, e.code AS employee_code, lt.name AS leave_type
    FROM " . PK01_DB::t('leave_requests') . " lr
    LEFT JOIN " . PK01_DB::t('employees') . " e ON e.id = lr.employee_id
    LEFT JOIN " . PK01_DB::t('leave_types') . " lt ON lt.id = lr.leave_type_id
    WHERE {$leave_where}
    ORDER BY lr.id DESC
    LIMIT 150
", ARRAY_A) ?: [];

// Perhitungan KPI
$total_punches_month = count($records);
$pending_leaves      = count(array_filter($reqs, fn($x) => $x['status'] === 'pending'));
$today_records       = array_filter($records, fn($x) => substr($x['punch_at'], 0, 10) === $today);
$today_punches       = count($today_records);

// Cek Presensi Hari ini bagi yang login
$my_today_in = null;
$my_today_out = null;
foreach ($today_records as $r) {
    if ((int)$r['employee_id'] === $employee_id) {
        if ($r['punch_type'] === 'in' && !$my_today_in) $my_today_in = $r['punch_at'];
        if ($r['punch_type'] === 'out') $my_today_out = $r['punch_at'];
    }
}

$nonce = wp_create_nonce('wp_rest');
$api   = esc_url_raw(rest_url('pk01/v1'));
?>

<!-- STYLESHEET MODERN MASTERPIECE -->
<style>
:root {
  --pk-primary: #4f46e5;
  --pk-primary-hover: #4338ca;
  --pk-primary-light: #eef2ff;
  --pk-success: #10b981;
  --pk-success-light: #ecfdf5;
  --pk-warning: #f59e0b;
  --pk-warning-light: #fffbeb;
  --pk-danger: #ef4444;
  --pk-danger-light: #fef2f2;
  --pk-dark: #0f172a;
  --pk-slate: #64748b;
  --pk-border: #e2e8f0;
  --pk-bg: #f8fafc;
  --pk-card-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-wrap {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color: #1e293b;
  margin: 20px 0;
}

/* Header & Breadcrumb */
.pk01-header {
  background: #ffffff;
  padding: 24px 28px;
  border-radius: 16px;
  border: 1px solid var(--pk-border);
  box-shadow: var(--pk-card-shadow);
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 24px;
}
.pk01-header h1 {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 10px;
  color: var(--pk-dark);
}
.pk01-header p {
  margin: 4px 0 0;
  color: var(--pk-slate);
  font-size: 13.5px;
}

/* Metric Cards */
.pk01-kpi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 18px;
  margin-bottom: 24px;
}
.pk01-kpi-card {
  background: #ffffff;
  border: 1px solid var(--pk-border);
  border-radius: 14px;
  padding: 18px 22px;
  box-shadow: var(--pk-card-shadow);
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.pk01-kpi-card::before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0; height: 4px;
  background: var(--pk-border);
}
.pk01-kpi-card.c-primary::before { background: var(--pk-primary); }
.pk01-kpi-card.c-success::before { background: var(--pk-success); }
.pk01-kpi-card.c-warning::before { background: var(--pk-warning); }
.pk01-kpi-card.c-danger::before { background: var(--pk-danger); }

.pk01-kpi-title { font-size: 13px; font-weight: 600; color: var(--pk-slate); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 28px; font-weight: 800; color: var(--pk-dark); margin: 6px 0 2px; }
.pk01-kpi-sub { font-size: 12px; color: var(--pk-slate); display: flex; align-items: center; gap: 5px; }

/* Tabs Menu */
.pk01-nav-tabs {
  display: flex;
  gap: 8px;
  border-bottom: 2px solid var(--pk-border);
  margin-bottom: 24px;
  overflow-x: auto;
  padding-bottom: 2px;
}
.pk01-tab-btn {
  background: transparent;
  border: none;
  padding: 12px 18px;
  font-size: 14px;
  font-weight: 600;
  color: var(--pk-slate);
  cursor: pointer;
  border-radius: 8px 8px 0 0;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s ease;
  white-space: nowrap;
  position: relative;
}
.pk01-tab-btn:hover {
  color: var(--pk-primary);
  background: var(--pk-primary-light);
}
.pk01-tab-btn.is-active {
  color: var(--pk-primary);
}
.pk01-tab-btn.is-active::after {
  content: "";
  position: absolute;
  bottom: -4px;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--pk-primary);
  border-radius: 3px 3px 0 0;
}

/* Card Box */
.pk01-box {
  background: #ffffff;
  border-radius: 16px;
  border: 1px solid var(--pk-border);
  box-shadow: var(--pk-card-shadow);
  padding: 24px;
  margin-bottom: 24px;
}
.pk01-box-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 20px;
  padding-bottom: 14px;
  border-bottom: 1px solid var(--pk-border);
}
.pk01-box-title {
  font-size: 17px;
  font-weight: 700;
  color: var(--pk-dark);
  margin: 0;
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Clock / Self Check-in Card */
.pk01-self-clock {
  background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
  color: #ffffff;
  border-radius: 16px;
  padding: 28px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 20px;
  margin-bottom: 24px;
}
.pk01-digital-clock {
  font-size: 38px;
  font-weight: 800;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  letter-spacing: 2px;
  color: #38bdf8;
}

/* Forms & Inputs */
.pk01-form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 16px;
}
.pk01-form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.pk01-form-group label {
  font-size: 12.5px;
  font-weight: 600;
  color: #475569;
}
.pk01-form-group input, 
.pk01-form-group select, 
.pk01-form-group textarea {
  width: 100%;
  border: 1px solid var(--pk-border);
  border-radius: 8px;
  padding: 9px 12px;
  font-size: 13.5px;
  outline: none;
  background: #ffffff;
  transition: border-color 0.2s;
}
.pk01-form-group input:focus, 
.pk01-form-group select:focus, 
.pk01-form-group textarea:focus {
  border-color: var(--pk-primary);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Buttons */
.pk01-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  padding: 9px 16px;
  font-size: 13px;
  font-weight: 600;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  text-decoration: none;
}
.pk01-btn-primary { background: var(--pk-primary); color: #fff; }
.pk01-btn-primary:hover { background: var(--pk-primary-hover); }
.pk01-btn-success { background: var(--pk-success); color: #fff; }
.pk01-btn-success:hover { background: #059669; }
.pk01-btn-danger { background: var(--pk-danger); color: #fff; }
.pk01-btn-danger:hover { background: #dc2626; }
.pk01-btn-subtle { background: var(--pk-bg); color: var(--pk-dark); border: 1px solid var(--pk-border); }
.pk01-btn-subtle:hover { background: #e2e8f0; }
.pk01-btn-sm { padding: 5px 10px; font-size: 12px; border-radius: 6px; }

/* Modern Table */
.pk01-table-responsive {
  width: 100%;
  overflow-x: auto;
  border-radius: 10px;
  border: 1px solid var(--pk-border);
}
.pk01-table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
  font-size: 13.5px;
}
.pk01-table th {
  background: #f8fafc;
  color: #475569;
  font-weight: 600;
  padding: 12px 16px;
  border-bottom: 1px solid var(--pk-border);
  text-transform: uppercase;
  font-size: 11.5px;
  letter-spacing: 0.5px;
}
.pk01-table td {
  padding: 13px 16px;
  border-bottom: 1px solid var(--pk-border);
  color: #334155;
}
.pk01-table tbody tr:hover {
  background: #f8fafc;
}
.pk01-table tbody tr:last-child td {
  border-bottom: none;
}

/* Status Badges */
.pk01-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  font-size: 11.5px;
  font-weight: 600;
  border-radius: 9999px;
  text-transform: capitalize;
}
.pk01-badge-in { background: var(--pk-success-light); color: var(--pk-success); border: 1px solid rgba(16,185,129,0.3); }
.pk01-badge-out { background: var(--pk-danger-light); color: var(--pk-danger); border: 1px solid rgba(239,68,68,0.3); }
.pk01-badge-pending { background: var(--pk-warning-light); color: var(--pk-warning); border: 1px solid rgba(245,158,11,0.3); }
.pk01-badge-approved { background: var(--pk-success-light); color: var(--pk-success); border: 1px solid rgba(16,185,129,0.3); }
.pk01-badge-rejected { background: var(--pk-danger-light); color: var(--pk-danger); border: 1px solid rgba(239,68,68,0.3); }

/* Pulse Indicator for Device */
.pk01-pulse {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--pk-success);
  box-shadow: 0 0 0 rgba(16,185,129, 0.4);
  animation: pkPulse 2s infinite;
}
.pk01-pulse-offline {
  background: #94a3b8;
  box-shadow: none;
  animation: none;
}
@keyframes pkPulse {
  0% { box-shadow: 0 0 0 0 rgba(16,185,129, 0.7); }
  70% { box-shadow: 0 0 0 8px rgba(16,185,129, 0); }
  100% { box-shadow: 0 0 0 0 rgba(16,185,129, 0); }
}

/* Floating Toast */
#pk01-toast-container {
  position: fixed;
  top: 40px;
  right: 25px;
  z-index: 999999;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.pk01-toast {
  min-width: 280px;
  padding: 14px 18px;
  border-radius: 10px;
  background: #1e293b;
  color: #fff;
  font-size: 13.5px;
  box-shadow: 0 10px 15px -3px rgba(0,0,0,0.2);
  display: flex;
  align-items: center;
  justify-content: space-between;
  animation: pkSlideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.pk01-toast.is-success { background: #065f46; border-left: 4px solid var(--pk-success); }
.pk01-toast.is-error { background: #991b1b; border-left: 4px solid var(--pk-danger); }
@keyframes pkSlideIn {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

@media (max-width: 768px) {
  .pk01-self-clock { text-align: center; justify-content: center; }
  .pk01-header { flex-direction: column; align-items: flex-start; }
}
</style>

<div class="pk01-wrap">

  <!-- HEADER -->
  <div class="pk01-header">
    <div>
      <h1>🕘 Presensi & Manajemen Cuti</h1>
      <p>Pusat kendali biometrik (Fingerprint/Face), absensi mandiri web, serta persetujuan cuti karyawan.</p>
    </div>
    <div>
      <span class="pk01-badge pk01-badge-approved" style="font-size:12.5px; padding:6px 14px;">
        👤 <?php echo esc_html($me ? $me['name'] : wp_get_current_user()->display_name); ?> 
        (<?php echo esc_html(strtoupper($role)); ?>)
      </span>
    </div>
  </div>

  <!-- STATISTIK KPI -->
  <div class="pk01-kpi-grid">
    <div class="pk01-kpi-card c-primary">
      <div class="pk01-kpi-title">Presensi Hari Ini</div>
      <div class="pk01-kpi-val"><?php echo (int)$today_punches; ?></div>
      <div class="pk01-kpi-sub">📅 <?php echo esc_html(date_i18n('d M Y', strtotime($today))); ?></div>
    </div>
    <div class="pk01-kpi-card c-success">
      <div class="pk01-kpi-title">Total Log Periode Ini</div>
      <div class="pk01-kpi-val"><?php echo (int)$total_punches_month; ?></div>
      <div class="pk01-kpi-sub">Dari <?php echo esc_html($filter_from); ?> s/d <?php echo esc_html($filter_to); ?></div>
    </div>
    <div class="pk01-kpi-card c-warning">
      <div class="pk01-kpi-title">Pengajuan Cuti Pending</div>
      <div class="pk01-kpi-val"><?php echo (int)$pending_leaves; ?></div>
      <div class="pk01-kpi-sub">Menunggu konfirmasi HR</div>
    </div>
    <?php if ($is_hr): ?>
    <div class="pk01-kpi-card c-danger">
      <div class="pk01-kpi-title">Perangkat Aktif</div>
      <div class="pk01-kpi-val"><?php echo count($devices); ?></div>
      <div class="pk01-kpi-sub">Mesin Terhubung API</div>
    </div>
    <?php endif; ?>
  </div>

  <!-- NAVIGASI SUB-MENU (TABS) -->
  <div class="pk01-nav-tabs">
    <button class="pk01-tab-btn is-active" data-target="tab-overview">⚡ Presensi Mandiri</button>
    <button class="pk01-tab-btn" data-target="tab-logs">📋 Riwayat & Log Presensi</button>
    <button class="pk01-tab-btn" data-target="tab-leaves">🏖️ Permohonan Cuti</button>
    <?php if ($is_hr): ?>
    <button class="pk01-tab-btn" data-target="tab-devices">🔌 Perangkat & Biometrik</button>
    <?php endif; ?>
  </div>

  <!-- TAB 1: OVERVIEW & PRESENSI MANDIRI -->
  <div id="tab-overview" class="pk01-tab-content">
    <?php if ($employee_id): ?>
    <div class="pk01-self-clock">
      <div>
        <div style="font-size:14px; opacity:0.8; font-weight:500;">Waktu Server Indonesia</div>
        <div class="pk01-digital-clock" id="pk01-live-clock">--:--:--</div>
        <div style="font-size:13px; margin-top:4px; opacity:0.9;">
          Jadwal Kerja Anda: <b><?php echo esc_html($me['work_start'] ?? '08:00'); ?> - <?php echo esc_html($me['work_end'] ?? '17:00'); ?></b>
        </div>
      </div>
      <div style="display:flex; flex-direction:column; gap:10px; align-items:flex-end;">
        <div style="display:flex; gap:10px;">
          <button class="pk01-btn pk01-btn-success" style="padding:12px 24px; font-size:14px;" onclick="pk01SelfPunch('in')" <?php echo $my_today_in ? 'disabled' : ''; ?> >
            🟢 Absen Masuk (Clock In)
          </button>
          <button class="pk01-btn pk01-btn-danger" style="padding:12px 24px; font-size:14px;" onclick="pk01SelfPunch('out')" <?php echo (!$my_today_in || $my_today_out) ? 'disabled' : ''; ?> >
            🔴 Absen Pulang (Clock Out)
          </button>
        </div>
        <div style="font-size:12px; opacity:0.8;">
          Status Hari Ini: 
          <?php if($my_today_in): ?>
            <span style="color:#6ee7b7;">Masuk: <?php echo esc_html(substr($my_today_in, 11, 5)); ?></span>
          <?php else: ?>
            <span style="color:#cbd5e1;">Belum Masuk</span>
          <?php endif; ?>
          <?php if($my_today_out): ?>
            • <span style="color:#fca5a5;">Pulang: <?php echo esc_html(substr($my_today_out, 11, 5)); ?></span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">📌 Presensi Terbaru Hari Ini</h3>
      </div>
      <div class="pk01-table-responsive">
        <table class="pk01-table">
          <thead>
            <tr>
              <th>Waktu</th>
              <th>Karyawan</th>
              <th>Status</th>
              <th>Metode</th>
              <th>Perangkat / Gateway</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $recent_today = array_slice($today_records, 0, 10);
            if (!empty($recent_today)): 
              foreach ($recent_today as $row): 
            ?>
              <tr>
                <td><strong><?php echo esc_html(substr($row['punch_at'], 11, 8)); ?></strong></td>
                <td>
                  <strong><?php echo esc_html($row['employee_name'] ?? 'Self/ID: '.$row['employee_id']); ?></strong>
                  <div style="font-size:11.5px; color:#64748b;"><?php echo esc_html($row['employee_code'] ?? '-'); ?></div>
                </td>
                <td>
                  <span class="pk01-badge pk01-badge-<?php echo esc_attr($row['punch_type']); ?>">
                    <?php echo $row['punch_type'] === 'in' ? '🟢 Clock In' : '🔴 Clock Out'; ?>
                  </span>
                </td>
                <td><?php echo esc_html(strtoupper($row['source'] ?? 'WEB')); ?></td>
                <td><?php echo esc_html($row['device_name'] ?? 'Web Punch Portal'); ?></td>
              </tr>
            <?php 
              endforeach; 
            else: 
            ?>
              <tr><td colspan="5" style="text-align:center; padding:30px; color:#64748b;">Belum ada presensi yang tercatat hari ini.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 2: RIWAYAT & LOG PRESENSI -->
  <div id="tab-logs" class="pk01-tab-content" style="display:none;">
    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">🔍 Filter & Eksplorasi Presensi</h3>
      </div>
      <form method="GET" style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end; margin-bottom:20px;">
        <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page'] ?? ''); ?>">
        <div class="pk01-form-group">
          <label>Dari Tanggal</label>
          <input type="date" name="from" value="<?php echo esc_attr($filter_from); ?>">
        </div>
        <div class="pk01-form-group">
          <label>Sampai Tanggal</label>
          <input type="date" name="to" value="<?php echo esc_attr($filter_to); ?>">
        </div>
        <?php if ($is_hr): ?>
        <div class="pk01-form-group" style="min-width:200px;">
          <label>Pilih Karyawan</label>
          <select name="emp_id">
            <option value="0">-- Semua Karyawan --</option>
            <?php foreach ($employees as $e): ?>
              <option value="<?php echo (int)$e['id']; ?>" <?php selected($filter_emp, $e['id']); ?>>
                <?php echo esc_html($e['code'].' — '.$e['name']); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>
        <button type="submit" class="pk01-btn pk01-btn-primary" style="height:38px;">Filter Log</button>
        <a href="?page=<?php echo esc_attr($_GET['page'] ?? ''); ?>" class="pk01-btn pk01-btn-subtle" style="height:38px;">Reset</a>
      </form>

      <div class="pk01-table-responsive">
        <table class="pk01-table">
          <thead>
            <tr>
              <th>Tanggal & Waktu</th>
              <th>Karyawan</th>
              <th>Aksi Presensi</th>
              <th>Sumber</th>
              <th>Perangkat</th>
              <th>Keterangan Jadwal</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($records)): foreach ($records as $r): 
              $is_late = false;
              if ($r['punch_type'] === 'in' && !empty($r['work_start'])) {
                $punch_time = substr($r['punch_at'], 11, 5);
                if ($punch_time > $r['work_start']) {
                  $is_late = true;
                }
              }
            ?>
              <tr>
                <td><strong><?php echo esc_html($r['punch_at']); ?></strong></td>
                <td>
                  <strong><?php echo esc_html($r['employee_name'] ?? 'User #'.$r['employee_id']); ?></strong>
                  <div style="font-size:11px; color:#64748b;"><?php echo esc_html($r['employee_code'] ?? ''); ?></div>
                </td>
                <td>
                  <span class="pk01-badge pk01-badge-<?php echo esc_attr($r['punch_type']); ?>">
                    <?php echo $r['punch_type'] === 'in' ? '🟢 Clock In' : '🔴 Clock Out'; ?>
                  </span>
                </td>
                <td><?php echo esc_html(strtoupper($r['source'])); ?></td>
                <td><?php echo esc_html($r['device_name'] ?: 'Web / Manual'); ?></td>
                <td>
                  <?php if ($is_late): ?>
                    <span class="pk01-badge pk01-badge-rejected" style="font-size:11px;">⚠️ Terlambat (> <?php echo esc_html($r['work_start']); ?>)</span>
                  <?php elseif ($r['punch_type'] === 'in'): ?>
                    <span class="pk01-badge pk01-badge-approved" style="font-size:11px;">✓ Tepat Waktu</span>
                  <?php else: ?>
                    <span style="color:#94a3b8;">-</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="6" style="text-align:center; padding:30px; color:#64748b;">Tidak ada data presensi pada rentang tanggal ini.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 3: MANAJEMEN CUTI -->
  <div id="tab-leaves" class="pk01-tab-content" style="display:none;">
    <?php if ($employee_id || $is_hr): ?>
    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">📝 Ajukan Permohonan Cuti Baru</h3>
      </div>
      <form id="pk01-leave" class="pk01-form-grid">
        <?php if ($is_hr): ?>
        <div class="pk01-form-group">
          <label>Karyawan</label>
          <select name="employee_id" required>
            <?php foreach ($employees as $e): ?>
              <option value="<?php echo (int)$e['id']; ?>" <?php selected($employee_id, $e['id']); ?>>
                <?php echo esc_html($e['code'].' — '.$e['name']); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php else: ?>
          <input type="hidden" name="employee_id" value="<?php echo $employee_id; ?>">
        <?php endif; ?>

        <div class="pk01-form-group">
          <label>Jenis Cuti</label>
          <select name="leave_type_id" required <?php disabled(!$types); ?> >
            <?php foreach ($types as $t): ?>
              <option value="<?php echo (int)$t['id']; ?>">
                <?php echo esc_html($t['name'].' (Kuota '.$t['annual_days'].' Hari/Thn)'); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="pk01-form-group">
          <label>Tanggal Mulai</label>
          <input type="date" name="start_date" required value="<?php echo esc_attr($today); ?>">
        </div>

        <div class="pk01-form-group">
          <label>Tanggal Selesai</label>
          <input type="date" name="end_date" required value="<?php echo esc_attr($today); ?>">
        </div>

        <div class="pk01-form-group" style="grid-column: 1 / -1;">
          <label>Keperluan / Alasan Cuti</label>
          <textarea name="reason" rows="2" placeholder="Tuliskan keterangan detail permohonan izin atau cuti..." required></textarea>
        </div>

        <div style="grid-column: 1 / -1; display:flex; justify-content:flex-end;">
          <button class="pk01-btn pk01-btn-primary" type="submit">✈️ Kirim Pengajuan Cuti</button>
        </div>
      </form>
    </div>
    <?php endif; ?>

    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">📑 Status & Riwayat Pengajuan Cuti</h3>
      </div>
      <div class="pk01-table-responsive">
        <table class="pk01-table">
          <thead>
            <tr>
              <th>No Pengajuan</th>
              <th>Karyawan</th>
              <th>Tipe Cuti</th>
              <th>Periode</th>
              <th>Durasi</th>
              <th>Alasan</th>
              <th>Status</th>
              <?php if ($is_hr): ?><th>Tindakan HR</th><?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($reqs)): foreach ($reqs as $r): ?>
              <tr>
                <td><strong>#<?php echo esc_html($r['request_no'] ?: $r['id']); ?></strong></td>
                <td>
                  <strong><?php echo esc_html($r['employee_name']); ?></strong>
                  <div style="font-size:11px; color:#64748b;"><?php echo esc_html($r['employee_code'] ?? ''); ?></div>
                </td>
                <td><?php echo esc_html($r['leave_type']); ?></td>
                <td><?php echo esc_html(date_i18n('d M Y', strtotime($r['start_date']))); ?> s/d <?php echo esc_html(date_i18n('d M Y', strtotime($r['end_date']))); ?></td>
                <td><strong><?php echo esc_html($r['days'] ?? '1'); ?> Hari</strong></td>
                <td style="max-width:220px; font-size:12.5px; color:#64748b;"><?php echo esc_html($r['reason'] ?: '-'); ?></td>
                <td>
                  <span class="pk01-badge pk01-badge-<?php echo esc_attr($r['status']); ?>">
                    ● <?php echo esc_html(ucfirst($r['status'])); ?>
                  </span>
                </td>
                <?php if ($is_hr): ?>
                <td>
                  <?php if ($r['status'] === 'pending'): ?>
                    <div style="display:flex; gap:6px;">
                      <button class="pk01-btn pk01-btn-success pk01-btn-sm" onclick="pk01LeaveDecision(<?php echo (int)$r['id']; ?>, 'approved')">✓ Setujui</button>
                      <button class="pk01-btn pk01-btn-danger pk01-btn-sm" onclick="pk01LeaveDecision(<?php echo (int)$r['id']; ?>, 'rejected')">✕ Tolak</button>
                    </div>
                  <?php else: ?>
                    <span style="font-size:12px; color:#94a3b8;">Selesai</span>
                  <?php endif; ?>
                </td>
                <?php endif; ?>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="<?php echo $is_hr ? '8' : '7'; ?>" style="text-align:center; padding:30px; color:#64748b;">Belum ada data pengajuan cuti.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 4: PERANGKAT & BIOMETRIK (HR ONLY) -->
  <?php if ($is_hr): ?>
  <div id="tab-devices" class="pk01-tab-content" style="display:none;">
    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">🔌 Daftarkan Terminal Mesin / Cloud Gateway</h3>
      </div>
      <form id="pk01-att-device" class="pk01-form-grid">
        <div class="pk01-form-group">
          <label>Kode Terminal (Device Code)</label>
          <input name="device_code" required placeholder="Contoh: FP-LOBBY-01">
        </div>
        <div class="pk01-form-group">
          <label>Nama Terminal</label>
          <input name="name" required placeholder="Contoh: Fingerprint Lobby Utama">
        </div>
        <div class="pk01-form-group">
          <label>Jenis Teknologi</label>
          <select name="device_type">
            <option value="fingerprint">Fingerprint Biometric</option>
            <option value="face">Face Recognition AI</option>
            <option value="rfid">RFID Proximity Card</option>
            <option value="app">Mobile App Gateway</option>
            <option value="dvr_bridge">CCTV / Hardware Bridge</option>
          </select>
        </div>
        <div class="pk01-form-group">
          <label>Vendor / Merk</label>
          <input name="vendor" placeholder="ZKTeco / Hikvision / Solution">
        </div>
        <div class="pk01-form-group">
          <label>Model / Tipe Perangkat</label>
          <input name="model" placeholder="K40 / FaceStation / DS-K1T">
        </div>
        <div class="pk01-form-group">
          <label>Webhook / Endpoint (Opsional)</label>
          <input name="endpoint" placeholder="https://ip-mesin-atau-gateway:port">
        </div>
        <div class="pk01-form-group" style="grid-column: 1 / -1;">
          <label>Device Secret Token (Untuk Header Auth X-PK01-Attendance-Key)</label>
          <input name="secret" required type="password" placeholder="Kombinasi sandi kuat untuk handshake mesin">
        </div>
        <div style="grid-column: 1 / -1; display:flex; justify-content:flex-end;">
          <button class="pk01-btn pk01-btn-primary" type="submit">Hubungkan Perangkat</button>
        </div>
      </form>
    </div>

    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">📟 Mesin Absensi Terdaftar</h3>
      </div>
      <div class="pk01-table-responsive">
        <table class="pk01-table">
          <thead>
            <tr>
              <th>Status</th>
              <th>Kode & Nama</th>
              <th>Tipe</th>
              <th>Merk / Model</th>
              <th>Terakhir Terkoneksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($devices)): foreach ($devices as $dev): ?>
              <tr>
                <td>
                  <span class="pk01-pulse <?php echo (strtotime($dev['last_seen_at']) > strtotime('-30 minutes')) ? '' : 'pk01-pulse-offline'; ?>"></span>
                  <span style="font-size:12px; margin-left:6px;"><?php echo (strtotime($dev['last_seen_at']) > strtotime('-30 minutes')) ? 'Online' : 'Standby / Offline'; ?></span>
                </td>
                <td>
                  <strong><?php echo esc_html($dev['name']); ?></strong>
                  <div style="font-size:11px; color:#64748b;">Code: <code><?php echo esc_html($dev['device_code']); ?></code></div>
                </td>
                <td><span class="pk01-badge" style="background:#f1f5f9;"><?php echo esc_html(strtoupper($dev['device_type'])); ?></span></td>
                <td><?php echo esc_html(($dev['vendor'] ?: '-') . ' / ' . ($dev['model'] ?: '-')); ?></td>
                <td><?php echo $dev['last_seen_at'] ? esc_html($dev['last_seen_at']) : '<span style="color:#94a3b8;">Belum pernah ping</span>'; ?></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="5" style="text-align:center; padding:24px; color:#64748b;">Belum ada perangkat absensi yang didaftarkan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">🏖️ Master Jenis Cuti</h3>
        <span style="font-size:12px;color:#64748b;">Tidak ada jenis cuti contoh yang dibuat otomatis.</span>
      </div>
      <div class="pk01-table-responsive" style="margin-bottom:16px;">
        <table class="pk01-table"><thead><tr><th>Kode</th><th>Nama</th><th>Kuota / Tahun</th><th>Dibayar</th><th>Persetujuan</th></tr></thead><tbody>
        <?php if($types): foreach($types as $t): ?>
          <tr><td><code><?php echo esc_html($t['code']); ?></code></td><td><?php echo esc_html($t['name']); ?></td><td><?php echo esc_html($t['annual_days']); ?></td><td><?php echo !empty($t['paid'])?'Ya':'Tidak'; ?></td><td><?php echo !empty($t['requires_approval'])?'Ya':'Tidak'; ?></td></tr>
        <?php endforeach; else: ?><tr><td colspan="5" style="text-align:center;color:#64748b;padding:20px;">Belum ada jenis cuti. Tambahkan kebijakan cuti perusahaan di bawah.</td></tr><?php endif; ?>
        </tbody></table>
      </div>
      <form id="pk01-leave-type" class="pk01-form-grid">
        <div class="pk01-form-group"><label>Kode</label><input name="code" required placeholder="ANNUAL"></div>
        <div class="pk01-form-group"><label>Nama Jenis Cuti</label><input name="name" required placeholder="Cuti Tahunan"></div>
        <div class="pk01-form-group"><label>Kuota Hari / Tahun</label><input name="annual_days" type="number" min="0" step="0.5" value="0" required></div>
        <div class="pk01-form-group"><label>Dibayar</label><select name="paid"><option value="1">Ya</option><option value="0">Tidak</option></select></div>
        <div class="pk01-form-group"><label>Perlu Persetujuan</label><select name="requires_approval"><option value="1">Ya</option><option value="0">Tidak</option></select></div>
        <div style="grid-column:1/-1;display:flex;justify-content:flex-end;"><button class="pk01-btn pk01-btn-primary" type="submit">Simpan Jenis Cuti</button></div>
      </form>
    </div>

    <div class="pk01-box">
      <div class="pk01-box-header">
        <h3 class="pk01-box-title">🔗 Sinkronisasi ID Mesin & Shift Jam Kerja Karyawan</h3>
      </div>
      <div class="pk01-table-responsive">
        <table class="pk01-table">
          <thead>
            <tr>
              <th>Karyawan</th>
              <th>ID Biometrik Mesin</th>
              <th>Jam Masuk - Jam Pulang</th>
              <th>Aksi Simpan</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($employees as $e): ?>
              <tr>
                <td>
                  <strong><?php echo esc_html($e['name']); ?></strong>
                  <div style="font-size:11px; color:#64748b;"><?php echo esc_html($e['code']); ?></div>
                </td>
                <td style="max-width:160px;">
                  <input id="bio-<?php echo (int)$e['id']; ?>" value="<?php echo esc_attr($e['biometric_id']); ?>" style="padding:6px 10px; font-size:12.5px; width:100%;" placeholder="PIN/UID Mesin">
                </td>
                <td>
                  <div style="display:flex; align-items:center; gap:6px;">
                    <input id="start-<?php echo (int)$e['id']; ?>" type="time" value="<?php echo esc_attr($e['work_start'] ?? '08:00'); ?>" style="padding:4px 8px; font-size:12.5px;">
                    <span>s/d</span>
                    <input id="end-<?php echo (int)$e['id']; ?>" type="time" value="<?php echo esc_attr($e['work_end'] ?? '17:00'); ?>" style="padding:4px 8px; font-size:12.5px;">
                  </div>
                </td>
                <td>
                  <button class="pk01-btn pk01-btn-primary pk01-btn-sm" onclick="pk01MapEmployee(<?php echo (int)$e['id']; ?>)">
                    💾 Simpan
                  </button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="margin-top:16px; padding:14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; font-size:12.5px; color:#475569;">
        💡 <b>Dokumentasi REST API:</b> Mesin/ADMS mengirim payload JSON ke <code><?php echo esc_html($api); ?>/attendance/punch</code> via <code>POST</code> dengan header otorisasi <code>X-PK01-Attendance-Key</code>.<br>
        Contoh format data: <code>{"employee_code":"EMP-01","biometric_id":"105","punch_at":"2026-09-12 08:01:00","punch_type":"in","source":"device"}</code>.
      </div>
    </div>
  </div>
  <?php endif; ?>

</div>

<!-- TOAST CONTAINER -->
<div id="pk01-toast-container"></div>

<!-- LOGIKA JAVASCRIPT MASTERPIECE -->
<script>
(function() {
  const api   = <?php echo wp_json_encode($api); ?>;
  const nonce = <?php echo wp_json_encode($nonce); ?>;
  const myEmpId = <?php echo (int)$employee_id; ?>;

  // Toast Notifier Modern
  function showToast(message, type = 'success') {
    const container = document.getElementById('pk01-toast-container');
    const toast = document.createElement('div');
    toast.className = `pk01-toast is-${type}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // HTTP POST Helper
  function post(path, data) {
    return fetch(api + path, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': nonce
      },
      body: JSON.stringify(data)
    })
    .then(async r => {
      const res = await r.json();
      if (!r.ok || res.code) throw new Error(res.message || res.code || 'Terjadi kesalahan sistem');
      return res;
    });
  }

  // Tab Switcher Logic
  const tabs = document.querySelectorAll('.pk01-tab-btn');
  const contents = document.querySelectorAll('.pk01-tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('is-active'));
      contents.forEach(c => c.style.display = 'none');

      tab.classList.add('is-active');
      const target = document.getElementById(tab.dataset.target);
      if (target) target.style.display = 'block';
    });
  });

  // Jam Digital Real-time
  const clockEl = document.getElementById('pk01-live-clock');
  if (clockEl) {
    function updateClock() {
      const now = new Date();
      clockEl.innerText = now.toLocaleTimeString('id-ID', { hour12: false });
    }
    updateClock();
    setInterval(updateClock, 1000);
  }

  // Presensi Mandiri Web
  window.pk01SelfPunch = function(type) {
    if (!myEmpId) {
      showToast('Profil karyawan Anda tidak terhubung.', 'error');
      return;
    }
    const label = type === 'in' ? 'Masuk' : 'Pulang';
    if (!confirm(`Konfirmasi lakukan Absen ${label} sekarang?`)) return;

    post('/attendance/punch', {
      employee_id: myEmpId,
      punch_type: type,
      source: 'web'
    })
    .then(() => {
      showToast(`Absensi ${label} berhasil dicatat!`, 'success');
      setTimeout(() => location.reload(), 1200);
    })
    .catch(err => showToast(err.message, 'error'));
  };

  // Master Jenis Cuti — dibuat hanya oleh HR/Admin, tanpa data kebijakan contoh.
  const leaveTypeForm = document.getElementById('pk01-leave-type');
  if (leaveTypeForm) {
    leaveTypeForm.addEventListener('submit', e => {
      e.preventDefault();
      const payload = Object.fromEntries(new FormData(leaveTypeForm));
      post('/leave/types', payload).then(() => {
        showToast('Jenis cuti berhasil disimpan.', 'success');
        setTimeout(() => location.reload(), 800);
      }).catch(err => showToast(err.message, 'error'));
    });
  }

  // Daftarkan Perangkat
  const devForm = document.getElementById('pk01-att-device');
  if (devForm) {
    devForm.addEventListener('submit', e => {
      e.preventDefault();
      const payload = Object.fromEntries(new FormData(devForm));
      post('/attendance/devices', payload)
        .then(() => {
          showToast('Perangkat baru berhasil didaftarkan!', 'success');
          setTimeout(() => location.reload(), 1200);
        })
        .catch(err => showToast(err.message, 'error'));
    });
  }

  // Pengajuan Cuti
  const leaveForm = document.getElementById('pk01-leave');
  if (leaveForm) {
    leaveForm.addEventListener('submit', e => {
      e.preventDefault();
      const payload = Object.fromEntries(new FormData(leaveForm));
      post('/leave/requests', payload)
        .then(res => {
          showToast(`Pengajuan ${res.request_no || 'cuti'} berhasil diajukan!`, 'success');
          setTimeout(() => location.reload(), 1200);
        })
        .catch(err => showToast(err.message, 'error'));
    });
  }

  // Mapping Biometrik Karyawan
  window.pk01MapEmployee = function(id) {
    const payload = {
      biometric_id: document.getElementById('bio-' + id).value,
      work_start: document.getElementById('start-' + id).value,
      work_end: document.getElementById('end-' + id).value
    };
    post('/attendance/employees/' + id + '/mapping', payload)
      .then(() => showToast('Sinkronisasi ID & Shift berhasil diperbarui!', 'success'))
      .catch(err => showToast(err.message, 'error'));
  };

  // Keputusan Cuti (Approve / Reject)
  window.pk01LeaveDecision = function(id, status) {
    const label = status === 'approved' ? 'menyetujui' : 'menolak';
    if (!confirm(`Apakah Anda yakin ingin ${label} permohonan ini?`)) return;

    post('/leave/requests/' + id + '/decision', { status })
      .then(() => {
        showToast('Status permohonan telah diperbarui.', 'success');
        setTimeout(() => location.reload(), 1000);
      })
      .catch(err => showToast(err.message, 'error'));
  };

})();
</script>