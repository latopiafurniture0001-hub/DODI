<?php
if (!defined('ABSPATH')) exit;
/**
 * PK01 HR Attendance & Leave Engine.
 * Receives punches from fingerprint/face/RFID devices and third-party attendance apps
 * through one normalized API. Fingerprint templates are NEVER stored in PK01; only the
 * employee biometric_id reference is stored. Leave balances are server-calculated.
 */
class PK01_HR_Attendance {
    const NS = 'pk01/v1';
    public static function init(){
        add_action('rest_api_init',[__CLASS__,'routes']);
    }
    static function t($k){ return class_exists('PK01_DB') ? PK01_DB::t($k) : ''; }
    static function roles(){ return ['administrator','pk01_admin','pk01_hr','pk01_keuangan','shop_manager']; }
    static function allowed($write=false){
        if(!is_user_logged_in()) return false;
        if(current_user_can('manage_options')) return true;
        $r=(array)wp_get_current_user()->roles;
        if($write) return (bool)array_intersect(['pk01_admin','pk01_hr','shop_manager'], $r);
        return (bool)array_intersect(array_merge(self::roles(),['pk01_employee']), $r);
    }
    static function routes(){
        register_rest_route(self::NS,'/attendance/punch',[
            'methods'=>'POST','permission_callback'=>[__CLASS__,'punch_permission'],'callback'=>[__CLASS__,'punch']
        ]);
        register_rest_route(self::NS,'/attendance/records',[
            'methods'=>'GET','permission_callback'=>function(){return self::allowed(false);},'callback'=>[__CLASS__,'records']
        ]);
        register_rest_route(self::NS,'/attendance/employees/(?P<id>\d+)/mapping',[
            'methods'=>'POST','permission_callback'=>function(){return self::allowed(true);},'callback'=>[__CLASS__,'employee_mapping']
        ]);
        register_rest_route(self::NS,'/attendance/devices',[
            'methods'=>'GET','permission_callback'=>function(){return self::allowed(true);},'callback'=>[__CLASS__,'devices']
        ]);
        register_rest_route(self::NS,'/attendance/devices',[
            'methods'=>'POST','permission_callback'=>function(){return self::allowed(true);},'callback'=>[__CLASS__,'device_create']
        ]);
        register_rest_route(self::NS,'/attendance/import',[
            'methods'=>'POST','permission_callback'=>function(){return self::allowed(true);},'callback'=>[__CLASS__,'import_rows']
        ]);
        register_rest_route(self::NS,'/leave/types',[
            'methods'=>'GET','permission_callback'=>function(){return self::allowed(false);},'callback'=>[__CLASS__,'leave_types']
        ]);
        register_rest_route(self::NS,'/leave/types',[
            'methods'=>'POST','permission_callback'=>function(){return self::allowed(true);},'callback'=>[__CLASS__,'leave_type_create']
        ]);
        register_rest_route(self::NS,'/leave/requests',[
            'methods'=>'GET','permission_callback'=>function(){return self::allowed(false);},'callback'=>[__CLASS__,'leave_requests']
        ]);
        register_rest_route(self::NS,'/leave/requests',[
            'methods'=>'POST','permission_callback'=>function(){return self::allowed(false);},'callback'=>[__CLASS__,'leave_create']
        ]);
        register_rest_route(self::NS,'/leave/requests/(?P<id>\d+)/decision',[
            'methods'=>'POST','permission_callback'=>function(){return self::allowed(true);},'callback'=>[__CLASS__,'leave_decision']
        ]);
        register_rest_route(self::NS,'/leave/balance/(?P<employee_id>\d+)',[
            'methods'=>'GET','permission_callback'=>function(){return self::allowed(false);},'callback'=>[__CLASS__,'balance']
        ]);
    }
    static function punch_permission($r){
        if(is_user_logged_in() && self::allowed(false)) return true;
        $key=trim((string)$r->get_header('X-PK01-Attendance-Key'));
        if($key==='') return false;
        global $wpdb; $t=self::t('attendance_devices');
        $rows=$wpdb->get_results("SELECT id,secret_hash,status FROM {$t} WHERE status='active'",ARRAY_A)?:[];
        foreach($rows as $row){ if($row['secret_hash'] && wp_check_password($key,$row['secret_hash'])) return true; }
        return false;
    }
    static function payload($r){ return $r->get_json_params() ?: []; }
    static function find_employee($p){
        global $wpdb; $e=self::t('employees');
        $code=sanitize_text_field($p['employee_code']??''); $bio=sanitize_text_field($p['biometric_id']??''); $id=absint($p['employee_id']??0);
        if($id) return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$e} WHERE id=%d",$id),ARRAY_A);
        if($bio!=='') { $x=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$e} WHERE biometric_id=%s LIMIT 1",$bio),ARRAY_A); if($x)return $x; }
        if($code!=='') return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$e} WHERE code=%s LIMIT 1",$code),ARRAY_A);
        return null;
    }
    static function punch($r){
        global $wpdb;
        $p=self::payload($r);
        $is_device = trim((string)$r->get_header('X-PK01-Attendance-Key')) !== '';
        $current_emp_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('employees')." WHERE user_id=%d AND status='active' LIMIT 1",get_current_user_id()));
        // Web self-punch hanya boleh mencatat akun karyawan yang sedang login.
        // Gateway perangkat boleh mengirim employee_code/biometric_id/employee_id.
        if(!$is_device && is_user_logged_in() && !current_user_can('manage_options')){
            $posted=(int)($p['employee_id']??0);
            if(!$current_emp_id) return new WP_Error('employee_profile_missing','Akun Anda belum terhubung ke data Karyawan PK01. Hubungi HR.', ['status'=>422]);
            if($posted && $posted!==$current_emp_id) return new WP_Error('employee_forbidden','Anda hanya boleh melakukan presensi untuk akun Anda sendiri.',['status'=>403]);
            $p['employee_id']=$current_emp_id;
        }
        $emp=self::find_employee($p);
        if(!$emp || (isset($emp['status']) && $emp['status']!=='active')) return new WP_Error('employee_not_found','Karyawan aktif tidak ditemukan. Hubungkan akun/biometric ID terlebih dahulu.',['status'=>404]);
        $at=sanitize_text_field($p['punch_at']??'');
        $ts=$at ? strtotime($at) : current_time('timestamp');
        if(!$ts) return new WP_Error('invalid_time','Waktu absensi tidak valid.',['status'=>422]);
        $local=wp_date('Y-m-d H:i:s',$ts); $date=wp_date('Y-m-d',$ts); $type=sanitize_key($p['punch_type']??'auto');
        if(!in_array($type,['auto','in','out','break_in','break_out'],true))$type='auto';
        $device_id=0; $key=trim((string)$r->get_header('X-PK01-Attendance-Key'));
        if($key!==''){ $dev=$wpdb->get_results("SELECT id,secret_hash FROM ".self::t('attendance_devices')." WHERE status='active'",ARRAY_A)?:[]; foreach($dev as $d){if($d['secret_hash']&&wp_check_password($key,$d['secret_hash'])){$device_id=(int)$d['id'];$wpdb->update(self::t('attendance_devices'),['last_seen_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$device_id]);break;}} }
        $source=sanitize_key($p['source']??($device_id?'device':'web')) ?: 'web';
        $ref=sanitize_text_field($p['raw_reference']??'');
        $where="employee_id=%d AND punch_at=%s AND source=%s"; $args=[$emp['id'],$local,$source];
        if($ref!==''){ $where.=' AND raw_reference=%s'; $args[]=$ref; }
        $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('attendance_records')." WHERE {$where} LIMIT 1",...$args));
        if($exists) return ['ok'=>true,'duplicate'=>true,'record_id'=>(int)$exists,'employee_id'=>(int)$emp['id']];

        // Validasi urutan presensi supaya log tidak menjadi kumpulan klik ganda.
        $last=$wpdb->get_row($wpdb->prepare("SELECT punch_type,punch_at FROM ".self::t('attendance_records')." WHERE employee_id=%d AND work_date=%s AND status='accepted' ORDER BY punch_at DESC,id DESC LIMIT 1",$emp['id'],$date),ARRAY_A);
        if($type==='in' && $last && in_array($last['punch_type'],['in','break_in'],true)) return new WP_Error('already_clocked_in','Karyawan sudah tercatat Clock In hari ini.',['status'=>409]);
        if($type==='out' && (!$last || !in_array($last['punch_type'],['in','break_in'],true))) return new WP_Error('clock_in_required','Clock Out hanya dapat dilakukan setelah Clock In.',['status'=>409]);
        if($type==='break_out' && (!$last || $last['punch_type']!=='break_in')) return new WP_Error('break_sequence','Break Out harus mengikuti Break In.',['status'=>409]);
        if($type==='break_in' && $last && $last['punch_type']==='break_in') return new WP_Error('break_duplicate','Break In sudah tercatat.',['status'=>409]);

        $wpdb->insert(self::t('attendance_records'),[
            'employee_id'=>(int)$emp['id'],'employee_code'=>$emp['code'],'biometric_id'=>sanitize_text_field($p['biometric_id']??$emp['biometric_id']??''),
            'device_id'=>$device_id,'punch_type'=>$type,'punch_at'=>$local,'work_date'=>$date,'source'=>$source,'raw_reference'=>$ref,
            'status'=>'accepted','late_minutes'=>0,'notes'=>sanitize_textarea_field($p['notes']??''),'created_at'=>current_time('mysql')
        ]);
        if(!$wpdb->insert_id) return new WP_Error('attendance_save_failed','Presensi gagal disimpan ke database PK01.',['status'=>500]);
        $id=(int)$wpdb->insert_id;
        self::audit('attendance_punch','attendance_record',$id,'Absensi diterima untuk '.$emp['name'].' pada '.$local);
        return ['ok'=>true,'record_id'=>$id,'employee_id'=>(int)$emp['id'],'employee_name'=>$emp['name'],'work_date'=>$date,'punch_at'=>$local,'punch_type'=>$type];
    }
    static function employee_mapping($r){ global $wpdb; $id=absint($r['id']); $p=self::payload($r); $bio=sanitize_text_field($p['biometric_id']??''); $start=sanitize_text_field($p['work_start']??''); $end=sanitize_text_field($p['work_end']??''); $days=preg_replace('/[^1-7,]/','',sanitize_text_field($p['work_days']??'')); if($bio==='') return new WP_Error('biometric_required','ID biometrik wajib diisi.',['status'=>422]); $dup=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('employees')." WHERE biometric_id=%s AND id<>%d LIMIT 1",$bio,$id)); if($dup)return new WP_Error('biometric_duplicate','ID biometrik sudah dipakai karyawan lain.',['status'=>409]); $data=['biometric_id'=>$bio,'updated_at'=>current_time('mysql')]; if($start!=='')$data['work_start']=$start;if($end!=='')$data['work_end']=$end;if($days!=='')$data['work_days']=$days;$wpdb->update(self::t('employees'),$data,['id'=>$id]); self::audit('employee_biometric_mapping','employee',$id,'Mapping biometrik karyawan diperbarui'); return ['ok'=>true,'employee_id'=>$id,'biometric_id'=>$bio]; }
    static function devices(){ global $wpdb; return ['ok'=>true,'devices'=>$wpdb->get_results("SELECT id,device_code,name,device_type,vendor,model,endpoint,status,last_seen_at,created_at FROM ".self::t('attendance_devices')." ORDER BY id DESC",ARRAY_A)?:[]]; }
    static function device_create($r){
        global $wpdb; $p=self::payload($r); $code=sanitize_key($p['device_code']??''); $name=sanitize_text_field($p['name']??''); $secret=(string)($p['secret']??'');
        if($code===''||$name===''||$secret==='') return new WP_Error('device_required','Kode perangkat, nama, dan secret wajib diisi.',['status'=>422]);
        $wpdb->insert(self::t('attendance_devices'),['device_code'=>$code,'name'=>$name,'device_type'=>sanitize_key($p['device_type']??'fingerprint'),'vendor'=>sanitize_text_field($p['vendor']??''),'model'=>sanitize_text_field($p['model']??''),'endpoint'=>esc_url_raw($p['endpoint']??''),'secret_hash'=>wp_hash_password($secret),'status'=>'active','created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);
        return ['ok'=>true,'id'=>(int)$wpdb->insert_id,'device_code'=>$code,'secret'=>($secret)];
    }
    static function records($r){
        global $wpdb; $p=$r->get_params(); $from=sanitize_text_field($p['from']??wp_date('Y-m-01')); $to=sanitize_text_field($p['to']??wp_date('Y-m-d')); $employee=absint($p['employee_id']??0); $roles=(array)wp_get_current_user()->roles; $staff=(bool)array_intersect(self::roles(),$roles);
        if(!$staff){ $employee=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('employees')." WHERE user_id=%d LIMIT 1",get_current_user_id())); if(!$employee) return ['ok'=>true,'from'=>$from,'to'=>$to,'records'=>[]]; }
        $sql="SELECT a.*,e.name AS employee_name,e.position,e.division FROM ".self::t('attendance_records')." a LEFT JOIN ".self::t('employees')." e ON e.id=a.employee_id WHERE a.work_date BETWEEN %s AND %s"; $args=[$from,$to];
        if($employee){$sql.=' AND a.employee_id=%d';$args[]=$employee;} $sql.=' ORDER BY a.punch_at DESC LIMIT 1000';
        return ['ok'=>true,'from'=>$from,'to'=>$to,'records'=>$wpdb->get_results($wpdb->prepare($sql,...$args),ARRAY_A)?:[]];
    }
    static function import_rows($r){
        $p=self::payload($r); $rows=$p['rows']??[]; if(!is_array($rows)) return new WP_Error('rows_required','rows harus berupa array.',['status'=>422]);
        $ok=0;$bad=0;$errors=[]; foreach(array_slice($rows,0,5000) as $row){$fake=new WP_REST_Request('POST','/pk01/v1/attendance/punch');$fake->set_body(wp_json_encode($row));$res=self::punch($fake);if(is_wp_error($res)){$bad++;$errors[]=$res->get_error_message();}else{$ok++;}}
        global $wpdb; $wpdb->insert(self::t('attendance_import_logs'),['device_id'=>absint($p['device_id']??0),'source'=>sanitize_key($p['source']??'api'),'file_name'=>sanitize_file_name($p['file_name']??''),'rows_received'=>count($rows),'rows_accepted'=>$ok,'rows_rejected'=>$bad,'error_summary'=>wp_json_encode(array_slice($errors,0,20)),'imported_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        return ['ok'=>true,'received'=>count($rows),'accepted'=>$ok,'rejected'=>$bad,'errors'=>array_slice($errors,0,20)];
    }
    static function leave_types(){ global $wpdb; return ['ok'=>true,'types'=>$wpdb->get_results("SELECT * FROM ".self::t('leave_types')." WHERE active=1 ORDER BY id",ARRAY_A)?:[]]; }
    static function leave_type_create($r){
        global $wpdb; $p=self::payload($r); $code=strtoupper(preg_replace('/[^A-Z0-9_-]/','',sanitize_text_field($p['code']??''))); $name=sanitize_text_field($p['name']??''); $annual=max(0,(float)($p['annual_days']??0)); $paid=!empty($p['paid'])?1:0; $approval=array_key_exists('requires_approval',$p)?(!empty($p['requires_approval'])?1:0):1;
        if($code===''||$name==='') return new WP_Error('leave_type_required','Kode dan nama jenis cuti wajib diisi.',['status'=>422]);
        if((int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('leave_types')." WHERE code=%s LIMIT 1",$code))) return new WP_Error('leave_type_exists','Kode jenis cuti sudah digunakan.',['status'=>409]);
        $ok=$wpdb->insert(self::t('leave_types'),['code'=>$code,'name'=>$name,'annual_days'=>$annual,'requires_approval'=>$approval,'paid'=>$paid,'active'=>1,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);
        if(!$ok) return new WP_Error('leave_type_save_failed','Jenis cuti gagal disimpan.',['status'=>500]);
        self::audit('leave_type_created','leave_type',(int)$wpdb->insert_id,'Jenis cuti '.$code.' dibuat'); return ['ok'=>true,'id'=>(int)$wpdb->insert_id,'code'=>$code];
    }
    static function leave_requests($r){
        global $wpdb; $p=$r->get_params(); $where='1=1';$args=[]; $roles=(array)wp_get_current_user()->roles;
        if(!array_intersect(['administrator','pk01_admin','pk01_hr','pk01_keuangan','shop_manager'],$roles)){
            $emp=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('employees')." WHERE user_id=%d LIMIT 1",get_current_user_id())); if(!$emp)return ['ok'=>true,'requests'=>[]]; $where.=' AND lr.employee_id=%d';$args[]=$emp;
        } elseif(!empty($p['employee_id'])){$where.=' AND lr.employee_id=%d';$args[]=absint($p['employee_id']);}
        $sql="SELECT lr.*,e.name employee_name,e.code employee_code,lt.name leave_type FROM ".self::t('leave_requests')." lr LEFT JOIN ".self::t('employees')." e ON e.id=lr.employee_id LEFT JOIN ".self::t('leave_types')." lt ON lt.id=lr.leave_type_id WHERE {$where} ORDER BY lr.id DESC LIMIT 500";
        return ['ok'=>true,'requests'=>$args?$wpdb->get_results($wpdb->prepare($sql,...$args),ARRAY_A):($wpdb->get_results($sql,ARRAY_A)?:[])];
    }
    static function leave_create($r){
        global $wpdb; $p=self::payload($r); $employee_id=absint($p['employee_id']??0);
        $staff_roles=['administrator','pk01_admin','pk01_hr','pk01_keuangan','shop_manager'];
        if(!array_intersect($staff_roles,(array)wp_get_current_user()->roles)) $employee_id=0;
        if(!$employee_id){$employee_id=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('employees')." WHERE user_id=%d LIMIT 1",get_current_user_id()));}
        $type=absint($p['leave_type_id']??0); $start=sanitize_text_field($p['start_date']??''); $end=sanitize_text_field($p['end_date']??'');
        if(!$employee_id||!$type||!$start||!$end) return new WP_Error('leave_required','Karyawan, jenis cuti, tanggal mulai dan selesai wajib diisi.',['status'=>422]);
        $days=self::business_days($start,$end,$employee_id); if($days<=0)return new WP_Error('leave_dates','Rentang tanggal cuti tidak valid.',['status'=>422]);
        $overlap=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::t('leave_requests')." WHERE employee_id=%d AND status IN ('pending','approved') AND start_date<=%s AND end_date>=%s",$employee_id,$end,$start)); if($overlap)return new WP_Error('leave_overlap','Sudah ada pengajuan cuti pada rentang tanggal tersebut.',['status'=>409]);
        $lt=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::t('leave_types')." WHERE id=%d AND active=1 LIMIT 1",$type),ARRAY_A); if(!$lt) return new WP_Error('leave_type_not_found','Jenis cuti tidak aktif atau tidak ditemukan.',['status'=>404]); $bal=self::balance_row($employee_id,$type,(int)substr($start,0,4)); if((float)$lt['annual_days']>0 && $bal['remaining']<$days) return new WP_Error('leave_insufficient','Saldo cuti tidak mencukupi.',['status'=>422]);
        $no='CUTI-'.wp_date('ymd',current_time('timestamp')).'-'.wp_rand(1000,9999); $wpdb->insert(self::t('leave_requests'),['request_no'=>$no,'employee_id'=>$employee_id,'leave_type_id'=>$type,'start_date'=>$start,'end_date'=>$end,'days'=>$days,'reason'=>sanitize_textarea_field($p['reason']??''),'attachment_id'=>absint($p['attachment_id']??0),'status'=>'pending','created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);
        self::audit('leave_created','leave_request',(int)$wpdb->insert_id,'Pengajuan '.$no.' selama '.$days.' hari'); return ['ok'=>true,'id'=>(int)$wpdb->insert_id,'request_no'=>$no,'days'=>$days,'status'=>'pending'];
    }
    static function leave_decision($r){
        global $wpdb; $id=absint($r['id']); $p=self::payload($r); $decision=in_array(($p['status']??''),['approved','rejected','cancelled'],true)?$p['status']:''; if(!$decision)return new WP_Error('decision_required','Status keputusan tidak valid.',['status'=>422]);
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::t('leave_requests')." WHERE id=%d",$id),ARRAY_A); if(!$row)return new WP_Error('not_found','Pengajuan cuti tidak ditemukan.',['status'=>404]);
        // Saldo terpakai dihitung dari pengajuan berstatus approved sebagai source of truth.

        $wpdb->update(self::t('leave_requests'),['status'=>$decision,'approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['id'=>$id]); self::audit('leave_decision','leave_request',$id,'Pengajuan cuti '.$row['request_no'].' => '.$decision); return ['ok'=>true,'status'=>$decision];
    }
    static function business_days($start,$end,$employee_id=0){ $a=strtotime($start);$b=strtotime($end);if(!$a||!$b||$b<$a)return 0;$days='1,2,3,4,5,6'; if($employee_id){global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT work_days FROM ".self::t('employees')." WHERE id=%d",$employee_id));if($v)$days=$v;} $allowed=array_filter(array_map('intval',explode(',',$days)));$n=0;for($d=$a;$d<=$b;$d+=86400){$w=(int)wp_date('N',$d);if(in_array($w,$allowed,true))$n++;}return $n; }
    static function balance_row($employee_id,$type,$year){
        global $wpdb; $t=self::t('leave_balances');
        $row=$wpdb->get_row($wpdb->prepare("SELECT b.*,lt.name,lt.annual_days FROM {$t} b LEFT JOIN ".self::t('leave_types')." lt ON lt.id=b.leave_type_id WHERE b.employee_id=%d AND b.leave_type_id=%d AND b.year=%d LIMIT 1",$employee_id,$type,$year),ARRAY_A);
        $lt=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::t('leave_types')." WHERE id=%d AND active=1",$type),ARRAY_A);
        if(!$lt) return ['employee_id'=>$employee_id,'leave_type_id'=>$type,'year'=>$year,'entitlement'=>0,'used'=>0,'remaining'=>0,'name'=>''];
        $base=$row ? (float)$row['entitlement'] : (float)$lt['annual_days'];
        if($row) $base+=(float)$row['carryover']+(float)$row['adjustment'];
        $approved=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(days),0) FROM ".self::t('leave_requests')." WHERE employee_id=%d AND leave_type_id=%d AND status='approved' AND YEAR(start_date)=%d",$employee_id,$type,$year));
        return ['employee_id'=>$employee_id,'leave_type_id'=>$type,'year'=>$year,'entitlement'=>$base,'used'=>$approved,'remaining'=>max(0,$base-$approved),'name'=>$lt['name'],'paid'=>(int)$lt['paid']];
    }
    static function balance($r){ global $wpdb; $eid=absint($r['employee_id']); $staff=(bool)array_intersect(self::roles(),(array)wp_get_current_user()->roles); if(!$staff){$eid=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('employees')." WHERE user_id=%d LIMIT 1",get_current_user_id()));} if(!$eid) return new WP_Error('employee_profile_missing','Profil karyawan belum terhubung.',['status'=>422]); $year=absint($r->get_param('year')?:current_time('Y'));$types=$wpdb->get_results("SELECT id,name FROM ".self::t('leave_types')." WHERE active=1 ORDER BY id",ARRAY_A)?:[];$out=[];foreach($types as $t)$out[]=self::balance_row($eid,(int)$t['id'],$year);return ['ok'=>true,'employee_id'=>$eid,'year'=>$year,'balances'=>$out]; }
    static function audit($action,$entity,$id,$text){if(class_exists('PK01_Audit')&&method_exists('PK01_Audit','info'))PK01_Audit::info($action,'hr_attendance',$text,$entity,(string)$id);}
}
