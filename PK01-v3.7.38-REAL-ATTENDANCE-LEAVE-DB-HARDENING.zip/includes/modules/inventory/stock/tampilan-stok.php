<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$notice = '';
$action = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('stock')
    : esc_url($_SERVER['REQUEST_URI'] ?? '');

// ==========================================================================
// 1. PROSES PENYESUAIAN STOK OPNAME (LOGIKA LAMA UTUH & TERJAGA)
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_stock_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_stock_nonce'] ?? '')), 'pk01_stock_save')) {
        $notice = '<div class="pk-alert pk-alert-error"><div class="pk-alert-icon">⚠️</div><div>Sesi keamanan tidak valid atau kedaluwarsa. Silakan muat ulang halaman.</div></div>';
    } else {
        try {
            $stock_type = sanitize_key($_POST['type'] ?? 'finished');
            $variant_id = absint($_POST['variant_id'] ?? 0);
            $qty        = floatval($_POST['qty'] ?? 0);
            $reason     = sanitize_text_field($_POST['reason'] ?? '');

            if ($variant_id <= 0) {
                throw new Exception('Silakan pilih SKU / Barang yang akan di-opname.');
            }
            if ($qty < 0) {
                throw new Exception('Jumlah fisik tidak boleh kurang dari 0.');
            }
            if (empty($reason)) {
                throw new Exception('Alasan penyesuaian wajib diisi.');
            }

            // Eksekusi Pemanggilan Mesin PK01 Engine
            PK01_Engine::adjust_stock($stock_type, $variant_id, $qty, $reason);

            $loc_label = ($stock_type === 'damaged') ? 'Gudang Rusak / Karantina' : 'Gudang Jadi (Siap Jual)';
            $notice = '<div class="pk-alert pk-alert-success"><div class="pk-alert-icon">✓</div><div><strong>Stok Opname Berhasil Disimpan!</strong> Saldo fisik di <u>' . esc_html($loc_label) . '</u> telah disesuaikan menjadi <strong>' . number_format($qty, 0) . ' pcs</strong>.</div></div>';
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error"><div class="pk-alert-icon">✕</div><div><strong>Gagal:</strong> ' . esc_html($e->getMessage()) . '</div></div>';
        }
    }
}

// ==========================================================================
// 2. QUERY POSISI STOK FISIK (LOGIKA QUERY LAMA LENGKAP)
// ==========================================================================
$tbl_variants = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_variants') : $wpdb->prefix . 'pk01_product_variants';
$tbl_products = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('products') : $wpdb->prefix . 'pk01_products';
$tbl_tx       = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('stock_transactions') : $wpdb->prefix . 'pk01_stock_transactions';

$variants = $wpdb->get_results("
    SELECT v.id, v.sku, p.name, 
    COALESCE(v.stock, 0) AS stock_ready,
    COALESCE(SUM(CASE 
        WHEN st.direction = 'in' AND st.stock_type = 'damaged' THEN st.qty 
        WHEN st.direction = 'out' AND st.stock_type = 'damaged' THEN -st.qty 
        ELSE 0 
    END), 0) AS stock_damaged
    FROM {$tbl_variants} v 
    INNER JOIN {$tbl_products} p ON p.id = v.product_id 
    LEFT JOIN {$tbl_tx} st ON st.item_id = v.id 
    GROUP BY v.id 
    ORDER BY v.sku ASC
", ARRAY_A) ?: [];

// Kalkulasi Metrik KPI Cockpit
$kpi_total_sku     = count($variants);
$kpi_total_ready   = 0;
$kpi_total_damaged = 0;
$kpi_out_of_stock  = 0;
$kpi_has_damaged   = 0;

foreach ($variants as $row) {
    $r_qty = (float)$row['stock_ready'];
    $d_qty = (float)$row['stock_damaged'];
    $kpi_total_ready   += $r_qty;
    $kpi_total_damaged += $d_qty;

    if ($r_qty <= 0) $kpi_out_of_stock++;
    if ($d_qty > 0)  $kpi_has_damaged++;
}
?>

<style>
/* ==========================================================================
   MASTERPIECE GUDANG & INVENTARIS STOK OPNAME DESIGN
   ========================================================================== */
.pk-stock-wrap {
    --pk-primary: #0f172a;
    --pk-accent: #2563eb;
    --pk-accent-hover: #1d4ed8;
    --pk-surface: #ffffff;
    --pk-bg: #f8fafc;
    --pk-border: #e2e8f0;
    --pk-text-main: #0f172a;
    --pk-text-muted: #64748b;
    --pk-green: #10b981;
    --pk-green-dark: #047857;
    --pk-amber: #f59e0b;
    --pk-red: #ef4444;
    --pk-red-dark: #b91c1c;
    --pk-radius: 14px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: var(--pk-text-main);
    margin-top: 15px;
}
.pk-stock-wrap * { box-sizing: border-box; }

/* Alert Notifikasi */
.pk-alert {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 18px;
    border-radius: var(--pk-radius);
    margin-bottom: 22px;
    font-size: 14px;
    line-height: 1.5;
}
.pk-alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk-alert-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
.pk-alert-icon { font-weight: bold; font-size: 18px; line-height: 1; }

/* Hero Cockpit Banner */
.pk-hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: var(--pk-radius);
    padding: 24px 28px;
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk-hero-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk-hero-banner h2 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk-hero-banner p {
    color: #cbd5e1;
    font-size: 13px;
    margin: 0;
    max-width: 650px;
    line-height: 1.5;
}
.pk-btn-pdf {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.25);
    color: #ffffff;
    text-decoration: none !important;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    transition: all 0.2s ease;
}
.pk-btn-pdf:hover {
    background: #ffffff;
    color: #0f172a !important;
    transform: translateY(-1px);
}

/* KPI Scorecards */
.pk-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 14px;
    margin-bottom: 24px;
}
.pk-kpi-card {
    background: var(--pk-surface);
    border: 1px solid var(--pk-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    border-left: 4px solid #cbd5e1;
}
.pk-kpi-card.c-blue  { border-left-color: #3b82f6; }
.pk-kpi-card.c-green { border-left-color: #10b981; background: #fafdfc; }
.pk-kpi-card.c-red   { border-left-color: #ef4444; background: #fffdfd; }
.pk-kpi-card.c-amber { border-left-color: #f59e0b; background: #fffdf5; }

.pk-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    color: var(--pk-text-muted);
    display: block;
}
.pk-kpi-card strong {
    font-size: 24px;
    font-weight: 800;
    color: var(--pk-text-main);
    display: block;
    margin: 4px 0 2px 0;
}
.pk-kpi-card span { font-size: 11px; color: var(--pk-text-muted); }

/* Main Grid Layout */
.pk-main-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 22px;
    align-items: start;
    margin-bottom: 26px;
}
@media (max-width: 960px) {
    .pk-main-grid { grid-template-columns: 1fr; }
}

/* Panel Design */
.pk-panel {
    background: var(--pk-surface);
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-panel-head {
    padding: 16px 20px;
    background: #fafbfc;
    border-bottom: 1px solid var(--pk-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk-panel-head h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 700;
    color: var(--pk-text-main);
}
.pk-panel-body { padding: 20px; }

/* Form Controls */
.pk-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
}
.pk-field {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk-field.is-wide { grid-column: 1 / -1; }
.pk-field label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk-field input, 
.pk-field select {
    width: 100%;
    border: 1px solid var(--pk-border);
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 13px;
    background: #fff;
    color: var(--pk-text-main);
    transition: all 0.2s ease;
}
.pk-field input:focus, 
.pk-field select:focus {
    border-color: var(--pk-accent);
    outline: none;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

/* Kotak Live Kalkulasi Selisih Opname */
.pk-calc-preview {
    display: none;
    grid-column: 1 / -1;
    background: #f1f5f9;
    border: 1px dashed #cbd5e1;
    border-radius: 10px;
    padding: 12px 16px;
    margin-top: 4px;
    font-size: 12px;
}
.pk-calc-flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}
.pk-diff-tag {
    font-weight: 800;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 12px;
}
.diff-plus  { background: #dcfce7; color: #15803d; }
.diff-minus { background: #fee2e2; color: #991b1b; }
.diff-zero  { background: #e2e8f0; color: #475569; }

.pk-submit-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: var(--pk-primary);
    color: white;
    border: none;
    font-weight: 700;
    font-size: 13px;
    padding: 12px 20px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    margin-top: 16px;
    width: 100%;
}
.pk-submit-btn:hover {
    background: #1e293b;
    transform: translateY(-1px);
}

/* Sidebar Protocol Box */
.pk-info-sidebar {
    background: #ffffff;
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-protocol-item {
    display: flex;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 12px;
}
.pk-proto-ready {
    background: #ecfdf5;
    border: 1px solid #a7f3d0;
}
.pk-proto-damaged {
    background: #fef2f2;
    border: 1px solid #fecaca;
}
.pk-proto-icon { font-size: 22px; line-height: 1; }
.pk-proto-text strong {
    display: block;
    font-size: 13px;
    margin-bottom: 3px;
}
.pk-proto-ready strong   { color: #065f46; }
.pk-proto-damaged strong { color: #991b1b; }
.pk-proto-text p {
    margin: 0;
    font-size: 12px;
    color: #475569;
    line-height: 1.4;
}

/* Tabel Inventaris & Controls */
.pk-table-panel {
    background: var(--pk-surface);
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-table-toolbar {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    background: #fafbfc;
    border-bottom: 1px solid var(--pk-border);
}
.pk-filter-chips {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.pk-filter-chip {
    padding: 6px 14px;
    border-radius: 20px;
    border: 1px solid var(--pk-border);
    background: #fff;
    font-size: 12px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk-filter-chip.is-active {
    background: var(--pk-primary);
    color: #ffffff;
    border-color: var(--pk-primary);
}
.pk-search-box {
    position: relative;
    width: 260px;
}
.pk-search-box input {
    width: 100%;
    padding: 8px 12px 8px 32px;
    font-size: 13px;
    border: 1px solid var(--pk-border);
    border-radius: 8px;
}
.pk-search-box::before {
    content: "🔍";
    position: absolute;
    left: 10px;
    top: 8px;
    font-size: 12px;
    opacity: 0.5;
}

/* Real Table Styling */
.pk-table-responsive { width: 100%; overflow-x: auto; }
.pk-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk-table th {
    background: #f8fafc;
    color: var(--pk-text-muted);
    font-weight: 700;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.05em;
    padding: 12px 18px;
    border-bottom: 1px solid var(--pk-border);
    white-space: nowrap;
}
.pk-table td {
    padding: 13px 18px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk-table tr:hover td { background: #fbfcfe; }

.pk-sku-badge {
    font-family: monospace;
    font-size: 12px;
    font-weight: 700;
    background: #f1f5f9;
    padding: 3px 8px;
    border-radius: 6px;
    border: 1px solid #e2e8f0;
    color: #334155;
    display: inline-block;
}

.pk-stock-status-pill {
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    padding: 2px 7px;
    border-radius: 4px;
    margin-left: 6px;
}
.pill-green { background: #dcfce7; color: #166534; }
.pill-amber { background: #fef3c7; color: #92400e; }
.pill-red   { background: #fee2e2; color: #991b1b; }

.pk-btn-quick-adjust {
    padding: 5px 10px;
    font-size: 11px;
    font-weight: 700;
    background: #f1f5f9;
    color: #334155;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.15s ease;
    white-space: nowrap;
}
.pk-btn-quick-adjust:hover {
    background: var(--pk-accent);
    color: #ffffff;
    border-color: var(--pk-accent);
}
</style>

<div class="pk-stock-wrap">
    
    <!-- 1. HERO BANNER & CETAK PDF -->
    <header class="pk-hero-banner">
        <div>
            <span class="pk-hero-eyebrow">PHYSICAL INVENTORY AUDIT &bull; STOCK OPNAME</span>
            <h2>Gudang &amp; Stok Opname Fisik</h2>
            <p>Pusat rekonsiliasi kuantitas fisik. Kontrol saldo barang siap jual pada <strong>Gudang Jadi</strong> dan isolasi barang cacat/retur pada <strong>Gudang Rusak / Karantina</strong>.</p>
        </div>
        <div>
            <?php 
                $print_url = function_exists('pk01_print_url') ? pk01_print_url('stok') : '#'; 
            ?>
            <a class="pk-btn-pdf" target="_blank" href="<?php echo esc_url($print_url); ?>">
                🖨️ Cetak Rekap Stok PDF
            </a>
        </div>
    </header>

    <!-- NOTIFIKASI OPERASIONAL -->
    <?php echo $notice; ?>

    <!-- 2. KPI OVERVIEW COCKPIT (METRIK KELAYAKAN STOK) -->
    <div class="pk-kpi-grid">
        <div class="pk-kpi-card c-blue">
            <small>Total SKU Terdaftar</small>
            <strong><?php echo number_format($kpi_total_sku, 0); ?></strong>
            <span>Varian produk aktif</span>
        </div>
        <div class="pk-kpi-card c-green">
            <small>Fisik Siap Jual (Gudang Jadi)</small>
            <strong style="color:#10b981;"><?php echo number_format($kpi_total_ready, 0); ?> <span style="font-size:14px;font-weight:normal;">pcs</span></strong>
            <span>Siap didistribusikan</span>
        </div>
        <div class="pk-kpi-card c-red">
            <small>Stok Rusak / Karantina</small>
            <strong style="color:#ef4444;"><?php echo number_format($kpi_total_damaged, 0); ?> <span style="font-size:14px;font-weight:normal;">pcs</span></strong>
            <span><?php echo (int)$kpi_has_damaged; ?> SKU memiliki barang cacat</span>
        </div>
        <div class="pk-kpi-card c-amber">
            <small>Stok Habis / Kritis (0 pcs)</small>
            <strong style="color:#d97706;"><?php echo (int)$kpi_out_of_stock; ?> <span style="font-size:14px;font-weight:normal;">SKU</span></strong>
            <span>Perlu penjadwalan produksi</span>
        </div>
    </div>

    <!-- 3. FORMULIR PENYESUAIAN OPNAME & PANDUAN PROTOKOL GUDANG -->
    <div class="pk-main-grid">
        <!-- Form Penyesuaian Fisik -->
        <div class="pk-panel" id="pk-opname-form-panel">
            <div class="pk-panel-head">
                <h3>📝 Formulir Penyesuaian Fisik Opname</h3>
            </div>
            <div class="pk-panel-body">
                <form method="post" action="<?php echo esc_url($action); ?>" id="pk-stock-adjust-form">
                    <?php echo wp_nonce_field('pk01_stock_save', 'pk01_stock_nonce', true, false); ?>
                    <input type="hidden" name="pk01_stock_action" value="adjust">

                    <div class="pk-form-grid">
                        <div class="pk-field">
                            <label>Pilih Lokasi Gudang *</label>
                            <select name="type" id="in-stock-type" required>
                                <option value="finished">🟢 Gudang Jadi (Siap Jual)</option>
                                <option value="damaged">🔴 Gudang Karantina / Rusak</option>
                            </select>
                        </div>

                        <div class="pk-field">
                            <label>Pilih SKU / Varian Produk *</label>
                            <select name="variant_id" id="in-variant-id" required>
                                <option value="">-- Pilih Barang Target --</option>
                                <?php foreach ($variants as $v): ?>
                                    <option value="<?php echo (int)$v['id']; ?>" 
                                            data-sku="<?php echo esc_attr($v['sku']); ?>"
                                            data-name="<?php echo esc_attr($v['name']); ?>"
                                            data-ready="<?php echo (float)$v['stock_ready']; ?>"
                                            data-damaged="<?php echo (float)$v['stock_damaged']; ?>">
                                        <?php echo esc_html($v['sku'] . ' — ' . $v['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk-field">
                            <label>Jumlah Fisik Sebenarnya (pcs) *</label>
                            <input type="number" name="qty" id="in-stock-qty" min="0" step="1" required placeholder="0">
                        </div>

                        <div class="pk-field">
                            <label>Alasan Penyesuaian *</label>
                            <input type="text" name="reason" id="in-stock-reason" placeholder="Contoh: Hasil audit mingguan / barang susut" required>
                        </div>

                        <!-- Kotak Kalkulasi Live Selisih Audit -->
                        <div class="pk-calc-preview" id="pk-diff-box">
                            <div class="pk-calc-flex">
                                <div>
                                    <span style="color:#64748b;">Saldo Sistem Saat Ini:</span>
                                    <strong id="prev-current-stock">0 pcs</strong>
                                </div>
                                <div>
                                    <span style="color:#64748b;">Hasil Hitung Fisik:</span>
                                    <strong id="prev-new-stock">0 pcs</strong>
                                </div>
                                <div>
                                    <span style="color:#64748b;">Selisih Opname:</span>
                                    <span class="pk-diff-tag diff-zero" id="prev-diff-badge">0 pcs</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="pk-submit-btn">
                        💾 Simpan Hasil Opname Fisik
                    </button>
                </form>
            </div>
        </div>

        <!-- Smart Guidance / SOP Gudang -->
        <div class="pk-info-sidebar">
            <h3 style="margin:0 0 14px 0;font-size:15px;font-weight:800;color:var(--pk-text-main);">
                🛡️ Protokol Pemisahan Fisik Gudang
            </h3>

            <div class="pk-protocol-item pk-proto-ready">
                <div class="pk-proto-icon">📦</div>
                <div class="pk-proto-text">
                    <strong>Gudang Jadi (Siap Jual)</strong>
                    <p>Produk lolos QC pabrik &amp; utuh. Saldo di gudang ini yang disinkronkan ke etalase toko dan siap dikirim ke pembeli.</p>
                </div>
            </div>

            <div class="pk-protocol-item pk-proto-damaged">
                <div class="pk-proto-icon">⚠️</div>
                <div class="pk-proto-text">
                    <strong>Gudang Rusak / Karantina</strong>
                    <p>Barang cacat produksi, patah, atau retur rusak diisolasi di sini agar <strong>tidak sengaja terjual</strong> ke konsumen.</p>
                </div>
            </div>

            <div style="font-size:12px;color:#64748b;line-height:1.5;margin-top:14px;">
                💡 <em>Tips: Lakukan penyesuaian opname berkala minimal 1 minggu sekali guna mencocokkan stok software dengan rak fisik.</em>
            </div>
        </div>
    </div>

    <!-- 4. TABEL POSISI STOK FISIK & AUDIT QUICK-ACTION -->
    <div class="pk-table-panel">
        <div class="pk-table-toolbar">
            <div class="pk-filter-chips">
                <button type="button" class="pk-filter-chip is-active" data-filter="all">
                    Semua SKU (<?php echo (int)$kpi_total_sku; ?>)
                </button>
                <button type="button" class="pk-filter-chip" data-filter="ready">
                    Siap Jual (>0)
                </button>
                <button type="button" class="pk-filter-chip" data-filter="empty">
                    Stok Habis (<?php echo (int)$kpi_out_of_stock; ?>)
                </button>
                <button type="button" class="pk-filter-chip" data-filter="damaged">
                    Ada Stok Rusak (<?php echo (int)$kpi_has_damaged; ?>)
                </button>
            </div>

            <div class="pk-search-box">
                <input type="text" id="pk-stock-search" placeholder="Cari kode SKU atau nama produk...">
            </div>
        </div>

        <div class="pk-table-responsive">
            <table class="pk-table" id="pk-stock-table">
                <thead>
                    <tr>
                        <th style="width:130px;">Kode SKU</th>
                        <th>Nama Produk</th>
                        <th style="text-align:right;width:150px;">Stok Siap Jual</th>
                        <th style="text-align:right;width:150px;color:#ef4444;">Stok Rusak / Cacat</th>
                        <th style="text-align:right;width:120px;">Total Fisik</th>
                        <th style="text-align:center;width:120px;">Aksi Cepat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($variants)): foreach ($variants as $row): 
                        $r_qty = (float)$row['stock_ready'];
                        $d_qty = (float)$row['stock_damaged'];
                        $total_pcs = $r_qty + $d_qty;
                        $search_meta = strtolower($row['sku'] . ' ' . $row['name']);

                        // Status Badge
                        if ($r_qty <= 0) {
                            $status_pill = '<span class="pk-stock-status-pill pill-red">Habis</span>';
                        } elseif ($r_qty <= 5) {
                            $status_pill = '<span class="pk-stock-status-pill pill-amber">Menipis</span>';
                        } else {
                            $status_pill = '<span class="pk-stock-status-pill pill-green">Aman</span>';
                        }
                    ?>
                        <tr class="pk-stock-row" 
                            data-ready="<?php echo ($r_qty > 0) ? 'yes' : 'no'; ?>"
                            data-empty="<?php echo ($r_qty <= 0) ? 'yes' : 'no'; ?>"
                            data-damaged="<?php echo ($d_qty > 0) ? 'yes' : 'no'; ?>"
                            data-search="<?php echo esc_attr($search_meta); ?>">
                            <td>
                                <span class="pk-sku-badge"><?php echo esc_html($row['sku']); ?></span>
                            </td>
                            <td>
                                <strong style="color:var(--pk-text-main);"><?php echo esc_html($row['name']); ?></strong>
                            </td>
                            <td style="text-align:right;">
                                <span style="font-weight:800;font-size:14px;color:#10b981;">
                                    <?php echo number_format($r_qty, 0); ?>
                                </span>
                                <small style="color:#64748b;">pcs</small>
                                <?php echo $status_pill; ?>
                            </td>
                            <td style="text-align:right;">
                                <?php if ($d_qty > 0): ?>
                                    <span style="font-weight:800;font-size:14px;color:#ef4444;">
                                        <?php echo number_format($d_qty, 0); ?>
                                    </span>
                                    <small style="color:#64748b;">pcs</small>
                                <?php else: ?>
                                    <span style="color:#94a3b8;font-size:12px;">0 pcs</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:right;font-weight:700;color:var(--pk-text-main);">
                                <?php echo number_format($total_pcs, 0); ?> <small style="color:#64748b;font-weight:normal;">pcs</small>
                            </td>
                            <td style="text-align:center;">
                                <button type="button" 
                                        class="pk-btn-quick-adjust" 
                                        onclick="quickPickSku(<?php echo (int)$row['id']; ?>, 'finished')" 
                                        title="Sesuaikan stok SKU ini">
                                    ⚙️ Opname
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr id="pk-empty-stock-row">
                            <td colspan="6" style="text-align:center;padding:36px;color:var(--pk-text-muted);">
                                Belum ada data inventaris produk di database.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- JAVASCRIPT: REALTIME SEARCH, FILTER CHIPS & LIVE CALCULATION -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var searchInput  = document.getElementById('pk-stock-search');
    var filterChips  = document.querySelectorAll('.pk-filter-chip');
    var activeFilter = 'all';

    // 1. Filter & Search Table
    function applyStockFilters() {
        var q = searchInput ? searchInput.value.toLowerCase().trim() : '';
        var rows = document.querySelectorAll('#pk-stock-table tbody tr.pk-stock-row');

        rows.forEach(function(row) {
            var searchTxt = row.getAttribute('data-search') || '';
            var isReady   = row.getAttribute('data-ready') === 'yes';
            var isEmpty   = row.getAttribute('data-empty') === 'yes';
            var isDamaged = row.getAttribute('data-damaged') === 'yes';

            var matchSearch = (searchTxt.indexOf(q) > -1);
            var matchChip   = true;

            if (activeFilter === 'ready')   matchChip = isReady;
            if (activeFilter === 'empty')   matchChip = isEmpty;
            if (activeFilter === 'damaged') matchChip = isDamaged;

            if (matchSearch && matchChip) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    if (searchInput) searchInput.addEventListener('input', applyStockFilters);

    filterChips.forEach(function(chip) {
        chip.addEventListener('click', function() {
            filterChips.forEach(function(c) { c.classList.remove('is-active'); });
            this.classList.add('is-active');
            activeFilter = this.getAttribute('data-filter') || 'all';
            applyStockFilters();
        });
    });

    // 2. Kalkulasi Live Selisih Fisik di Form
    var variantSelect = document.getElementById('in-variant-id');
    var typeSelect    = document.getElementById('in-stock-type');
    var qtyInput      = document.getElementById('in-stock-qty');
    var diffBox       = document.getElementById('pk-diff-box');
    var currentEl     = document.getElementById('prev-current-stock');
    var newEl         = document.getElementById('prev-new-stock');
    var diffBadge     = document.getElementById('prev-diff-badge');

    function calculateDiff() {
        if (!variantSelect || !variantSelect.value) {
            if (diffBox) diffBox.style.display = 'none';
            return;
        }

        var opt = variantSelect.options[variantSelect.selectedIndex];
        if (!opt) return;

        var loc = typeSelect ? typeSelect.value : 'finished';
        var currentStock = (loc === 'damaged') 
            ? parseFloat(opt.getAttribute('data-damaged') || 0) 
            : parseFloat(opt.getAttribute('data-ready') || 0);

        var newStock = parseFloat(qtyInput.value || 0);
        var diff = newStock - currentStock;

        if (diffBox) diffBox.style.display = 'block';
        if (currentEl) currentEl.innerText = currentStock.toLocaleString('id-ID') + ' pcs';
        if (newEl) newEl.innerText = newStock.toLocaleString('id-ID') + ' pcs';

        if (diffBadge) {
            diffBadge.className = 'pk-diff-tag';
            if (diff > 0) {
                diffBadge.classList.add('diff-plus');
                diffBadge.innerText = '+' + diff.toLocaleString('id-ID') + ' pcs (Kelebihan Fisik)';
            } else if (diff < 0) {
                diffBadge.classList.add('diff-minus');
                diffBadge.innerText = diff.toLocaleString('id-ID') + ' pcs (Kekurangan/Susut)';
            } else {
                diffBadge.classList.add('diff-zero');
                diffBadge.innerText = '0 pcs (Sesuai / Pas)';
            }
        }
    }

    if (variantSelect) variantSelect.addEventListener('change', calculateDiff);
    if (typeSelect)    typeSelect.addEventListener('change', calculateDiff);
    if (qtyInput)      qtyInput.addEventListener('input', calculateDiff);
});

// 3. Tombol Cepat Opname dari Tabel
function quickPickSku(variantId, defaultType) {
    var vSelect = document.getElementById('in-variant-id');
    var tSelect = document.getElementById('in-stock-type');
    var qtyIn   = document.getElementById('in-stock-qty');
    var panel   = document.getElementById('pk-opname-form-panel');

    if (vSelect) {
        vSelect.value = variantId;
        vSelect.dispatchEvent(new Event('change'));
    }
    if (tSelect && defaultType) {
        tSelect.value = defaultType;
        tSelect.dispatchEvent(new Event('change'));
    }
    if (panel) {
        panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (qtyIn) {
        setTimeout(function() { qtyIn.focus(); }, 400);
    }
}
</script>