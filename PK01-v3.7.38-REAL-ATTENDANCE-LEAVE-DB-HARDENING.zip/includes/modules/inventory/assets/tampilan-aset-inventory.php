<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can = $is_admin || (class_exists('PK01_Authorization') && PK01_Authorization::can('assets_inventory'));

if (!$can) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;">Akses Dibatasi</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin otorisasi untuk mengelola register aset tetap dan depresiasi.</p>
          </div>';
    return;
}

$msg = '';
$err = '';

// Helper Nama Tabel Aset & Depresiasi
$t = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('fixed_assets') : $wpdb->prefix . 'pk01_fixed_assets';
$d = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('asset_depreciation') : $wpdb->prefix . 'pk01_asset_depreciation';

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t);
// Self-heal schema aset lama: jangan tampilkan SQL error mentah kepada pengguna.
if (!$table_exists && class_exists('PK01_DB') && method_exists('PK01_DB', 'ensure_fixed_asset_tables')) {
    $table_exists = (bool) PK01_DB::ensure_fixed_asset_tables();
    $t = PK01_DB::t('fixed_assets');
    $d = PK01_DB::t('asset_depreciation');
} 

// 2. EKSPOR REGISTER ASET KE CSV
if (isset($_POST['pk01_export_assets_csv']) && check_admin_referer('pk01_export_assets_nonce')) {
    if ($table_exists) {
        $export_rows = $wpdb->get_results("
            SELECT a.*, 
                   COALESCE((SELECT SUM(ad.depreciation_amount) FROM {$d} ad WHERE ad.asset_id = a.id AND ad.status = 'posted'), 0) AS accumulated 
            FROM {$t} a 
            ORDER BY a.id DESC
        ", ARRAY_A);

        if (!empty($export_rows)) {
            $filename = 'pk01-fixed-assets-register-' . current_time('Y-m-d-His') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Kode Aset', 'Nama Aset', 'Kategori', 'Tanggal Pembelian', 'Harga Perolehan (Rp)', 'Nilai Residu (Rp)', 'Tarif Tahunan (%)', 'Umur (Bulan)', 'Akumulasi Penyusutan (Rp)', 'Nilai Buku Bersih (Rp)', 'Metode Bayar', 'Status']);
            
            foreach ($export_rows as $r) {
                $book_val = max(0, (float)$r['purchase_cost'] - (float)$r['accumulated']);
                fputcsv($out, [
                    $r['asset_code'],
                    $r['name'],
                    $r['category'],
                    $r['purchase_date'],
                    $r['purchase_cost'],
                    $r['residual_value'],
                    $r['annual_rate'],
                    $r['useful_life_months'],
                    $r['accumulated'],
                    $book_val,
                    $r['payment_method'],
                    $r['status']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. ACTION HANDLERS: INPUT ASET & POSTING DEPRESIASI
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_asset_action'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_asset_nonce'] ?? '')), 'pk01_asset')) {
        $err = 'Sesi keamanan telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        try {
            $action = sanitize_key($_POST['pk01_asset_action']);
            if ($action === 'create' && class_exists('PK01_Engine')) {
                $id = PK01_Engine::create_fixed_asset(
                    sanitize_text_field(wp_unslash($_POST['asset_code'] ?? '')),
                    sanitize_text_field(wp_unslash($_POST['name'] ?? '')),
                    sanitize_text_field(wp_unslash($_POST['category'] ?? 'Alat Kerja')),
                    sanitize_text_field($_POST['purchase_date'] ?? current_time('Y-m-d')),
                    (float)$_POST['purchase_cost'],
                    (float)$_POST['residual_value'],
                    (float)$_POST['annual_rate'],
                    (int)$_POST['useful_life_months'],
                    sanitize_text_field(wp_unslash($_POST['payment_method'] ?? 'Transfer Bank')),
                    sanitize_textarea_field(wp_unslash($_POST['notes'] ?? ''))
                );
                $msg = 'Aset tetap berhasil dicatat ke Neraca Aktiva. Kas dipotong sesuai harga perolehan dan beban diamortisasi secara berkala tanpa membebani laba instan.';
            } elseif ($action === 'depreciate' && class_exists('PK01_Engine')) {
                PK01_Engine::post_asset_depreciation(
                    (int)$_POST['asset_id'],
                    sanitize_text_field($_POST['period_key'] ?? current_time('Y-m'))
                );
                $msg = 'Penyusutan periode ' . esc_html($_POST['period_key'] ?? '') . ' berhasil diposting ke Laporan Laba Rugi sebagai beban non-kas.';
            }
        } catch (Throwable $e) {
            $err = $e->getMessage();
        }
    }
}

// 4. PENGAMBILAN DATA REAL DARI DATABASE
$rows = [];
$depr_history = [];
if ($table_exists) {
    $rows = $wpdb->get_results("
        SELECT a.*, 
               COALESCE((SELECT SUM(ad.depreciation_amount) FROM {$d} ad WHERE ad.asset_id = a.id AND ad.status = 'posted'), 0) AS accumulated 
        FROM {$t} a 
        ORDER BY a.id DESC 
        LIMIT 250
    ", ARRAY_A) ?: [];

    // Ambil Riwayat 50 Jurnal Penyusutan Terakhir
    $has_d_table = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $d)) === $d);
    if ($has_d_table) {
        $depr_history = $wpdb->get_results("
            SELECT ad.*, a.name AS asset_name, a.asset_code 
            FROM {$d} ad 
            LEFT JOIN {$t} a ON a.id = ad.asset_id 
            ORDER BY ad.id DESC 
            LIMIT 50
        ", ARRAY_A) ?: [];
    }
}

// 5. KALKULASI METRIK PORTOFOLIO ASET REAL (ZERO-DUMMY)
$total_cost       = 0;
$total_depr       = 0;
$total_book       = 0;
$est_monthly_depr = 0;
$categories_count = [];

foreach ($rows as $r) {
    $cost = (float)($r['purchase_cost'] ?? 0);
    $acc  = (float)($r['accumulated'] ?? 0);
    $res  = (float)($r['residual_value'] ?? 0);
    $rate = (float)($r['annual_rate'] ?? 0);
    $book = max(0, $cost - $acc);
    
    $total_cost += $cost;
    $total_depr += $acc;
    $total_book += $book;
    
    if (($r['status'] ?? '') === 'active' && $book > $res) {
        $depreciable_base = max(0, $cost - $res);
        $est_monthly_depr += ($depreciable_base * ($rate / 100)) / 12;
    }

    $cat = $r['category'] ?: 'Lainnya';
    $categories_count[$cat] = ($categories_count[$cat] ?? 0) + 1;
}

$cats_preset = [
    'Mobil/Kendaraan'               => 10,
    'Mesin Produksi'                => 12.5,
    'Komputer/Elektronik'           => 25,
    'Alat Kerja'                    => 20,
    'Perabot/Kantor'                => 10,
    'Unit Barang/Aset Operasional'  => 10,
    'Lainnya'                       => 0
];

// Rekomendasi Kode Aset Otomatis
$next_seq = count($rows) + 1;
$suggested_code = 'AST-' . str_pad((string)$next_seq, 4, '0', STR_PAD_LEFT);
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-ast-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-ast-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-ast-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-health-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 4 KPI Cards Deck */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-amber); }
.pk01-kpi-card.c-green::before  { background: var(--pk-emerald); }
.pk01-kpi-card.c-purple::before { background: #8b5cf6; }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 22px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Grid Forms */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
}
.pk01-form-group { display: flex; flex-direction: column; gap: 6px; }
.pk01-form-group label { font-size: 12.5px; font-weight: 700; color: var(--pk-slate-700); }
.pk01-ctrl {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13.5px;
    background: #ffffff;
    transition: all 0.2s ease;
}
.pk01-ctrl:focus {
    outline: none;
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Live Calculator Banner */
.pk01-calc-banner {
    grid-column: 1 / -1;
    background: linear-gradient(135deg, #ecfdf5 0%, #f0fdf4 100%);
    border: 1px dashed #86efac;
    border-radius: 12px;
    padding: 14px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
    margin: 4px 0;
}
.pk01-calc-stat { font-size: 12.5px; color: #166534; }
.pk01-calc-stat b {
    font-size: 16px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    color: #14532d;
    display: block;
    margin-top: 2px;
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

/* Progress Bar Depresiasi */
.pk01-progress-bg {
    width: 100%;
    max-width: 130px;
    background: #e2e8f0;
    height: 7px;
    border-radius: 4px;
    overflow: hidden;
    margin-top: 5px;
}
.pk01-progress-fill {
    background: linear-gradient(90deg, #f59e0b, #d97706);
    height: 100%;
    border-radius: 4px;
}

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 9px 16px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
.pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
.pk01-btn-emerald:hover { background: #059669; }
.pk01-btn-sm { padding: 4px 10px; font-size: 11.5px; border-radius: 6px; }

.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 11.5px;
}

.pk01-money {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    color: #0f172a;
}

.pk01-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-alert.is-error   { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }

.pk01-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.badge-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.badge-warning { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.badge-neutral { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }
</style>

<div class="pk01-ast-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-ast-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">FIXED ASSETS &bull; CAPEX AMORTIZATION</span>
            <h1>🏢 Register Aset Tetap &amp; Buku Depresiasi</h1>
            <p>
                Sentralisasi kapitalisasi aktiva tetap, pemantauan nilai buku bersih (Net Book Value), dan penjadwalan pembebanan depresiasi non-kas secara akrual ke laporan Laba Rugi [1].
            </p>
        </div>
        <div class="pk01-health-widget">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>NERACA AKTIVA SYNCHRONIZED</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                Standar: <b>Penyusutan Garis Lurus (Straight-Line)</b>
            </div>
        </div>
    </header>

    <?php if ($msg): ?><div class="pk01-alert is-success">✅ <?php echo esc_html($msg); ?></div><?php endif; ?>
    <?php if ($err): ?><div class="pk01-alert is-error">❌ <?php echo esc_html($err); ?></div><?php endif; ?>

    <!-- 2. EXECUTIVE 4 KPI CARDS DECK -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Total Investasi Aset (CapEx)</div>
            <div class="pk01-kpi-val">Rp <?php echo number_format($total_cost, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Dari <?php echo count($rows); ?> aset terkapitalisasi di neraca [1]</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Akumulasi Penyusutan</div>
            <div class="pk01-kpi-val" style="color:#d97706;">Rp <?php echo number_format($total_depr, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Beban amortisasi terposting ke laba rugi [1]</div>
        </div>

        <div class="pk01-kpi-card c-green">
            <div class="pk01-kpi-label">Nilai Buku Bersih (NBV)</div>
            <div class="pk01-kpi-val" style="color:#059669;">Rp <?php echo number_format($total_book, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Valuasi sisa manfaat aset aktif [1]</div>
        </div>

        <div class="pk01-kpi-card c-purple">
            <div class="pk01-kpi-label">Beban Depresiasi Bulanan</div>
            <div class="pk01-kpi-val" style="color:#7c3aed;">Rp <?php echo number_format($est_monthly_depr, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Amortisasi non-kas rutin per bulan [1]</div>
        </div>
    </section>

    <!-- 3. TABS NAVIGASI UTAMA -->
    <nav class="pk01-nav-tabs" aria-label="Menu Aset Tetap">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-register">
            📋 Buku Register Aset (<?php echo count($rows); ?>)
        </button>
        <?php if ($can): ?>
        <button type="button" class="pk01-tab-btn" data-target="tab-create">
            ➕ Kapitalisasi Aset Baru
        </button>
        <?php endif; ?>
        <button type="button" class="pk01-tab-btn" data-target="tab-history">
            📜 Riwayat Jurnal Penyusutan (<?php echo count($depr_history); ?>)
        </button>
    </nav>

    <!-- 4. TAB 1: BUKU REGISTER ASET TETAP -->
    <div class="pk01-pane is-active" id="tab-register">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📋 Buku Register Aktiva &amp; Nilai Buku Bersih</h3>
                    <div class="pk01-surface-desc">
                        Amortisasi penyusutan diposting secara berkala per periode tanpa memotong saldo kas fisik [1].
                    </div>
                </div>

                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('pk01_export_assets_nonce'); ?>
                        <input type="hidden" name="pk01_export_assets_csv" value="1">
                        <button type="submit" class="pk01-btn pk01-btn-subtle" title="Unduh data aktiva ke file Excel/CSV">
                            📥 Ekspor CSV
                        </button>
                    </form>

                    <input type="search" id="pk01_asset_search" class="pk01-ctrl" placeholder="🔍 Cari nama/kode aset..." style="width:230px; font-size:12px; padding:7px 12px;">
                </div>
            </div>

            <!-- TABEL DATA REGISTER ASET -->
            <div class="pk01-table-card">
                <table class="pk01-tbl" id="pk01_asset_table">
                    <thead>
                        <tr>
                            <th style="width:110px;">Kode Aset</th>
                            <th>Deskripsi Aktiva &amp; Pembelian</th>
                            <th>Kategori</th>
                            <th style="text-align:right;">Harga Perolehan</th>
                            <th style="text-align:center;">Tarif / Thn</th>
                            <th style="text-align:right;">Akumulasi Susut</th>
                            <th style="text-align:right;">Nilai Buku (NBV)</th>
                            <th style="text-align:center; width:190px;">Posting Depresiasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rows)): ?>
                            <tr>
                                <td colspan="8" style="text-align:center; padding:36px; color:#94a3b8;">
                                    📁 Belum ada aktiva tetap yang tercatat di neraca sistem [1].
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($rows as $r): 
                                $cost = (float)$r['purchase_cost'];
                                $acc  = (float)$r['accumulated'];
                                $res  = (float)$r['residual_value'];
                                $book = max(0, $cost - $acc);
                                
                                $depreciable_base = max(1, $cost - $res);
                                $pct_depreciated  = min(100, max(0, ($acc / $depreciable_base) * 100));
                            ?>
                            <tr data-cat="<?php echo esc_attr(strtolower($r['category'])); ?>">
                                <td>
                                    <span class="pk01-code-badge"><?php echo esc_html($r['asset_code']); ?></span>
                                </td>
                                <td>
                                    <strong style="color:#0f172a; font-size:13.5px;"><?php echo esc_html($r['name']); ?></strong>
                                    <div style="font-size:11.5px; color:#64748b; margin-top:2px;">
                                        📅 <?php echo esc_html(date_i18n('d M Y', strtotime($r['purchase_date']))); ?> &bull; <?php echo esc_html($r['payment_method']); ?> [1]
                                    </div>
                                </td>
                                <td>
                                    <span class="pk01-badge badge-neutral"><?php echo esc_html($r['category']); ?></span>
                                </td>
                                <td style="text-align:right;">
                                    <span class="pk01-money">Rp <?php echo number_format($cost, 0, ',', '.'); ?></span>
                                </td>
                                <td style="text-align:center; font-weight:700;">
                                    <?php echo number_format((float)$r['annual_rate'], 1); ?>%
                                </td>
                                <td style="text-align:right;">
                                    <span class="pk01-money" style="color:#d97706;">Rp <?php echo number_format($acc, 0, ',', '.'); ?></span>
                                    <div class="pk01-progress-bg" title="Tersusutkan: <?php echo number_format($pct_depreciated, 1); ?>%">
                                        <div class="pk01-progress-fill" style="width:<?php echo $pct_depreciated; ?>%;"></div>
                                    </div>
                                </td>
                                <td style="text-align:right;">
                                    <span class="pk01-money" style="color:#059669; font-size:14px;">
                                        Rp <?php echo number_format($book, 0, ',', '.'); ?>
                                    </span>
                                </td>
                                <td style="text-align:center;">
                                    <?php if ($can && ($r['status'] ?? 'active') === 'active' && $book > $res): ?>
                                        <form method="post" style="display:inline-flex; align-items:center; gap:4px; margin:0;" onsubmit="return confirm('Posting beban penyusutan periode ini untuk aktiva <?php echo esc_js($r['name']); ?>? Tindakan ini mencatat beban ke Laba Rugi tanpa pengeluaran kas [1].');">
                                            <?php wp_nonce_field('pk01_asset', 'pk01_asset_nonce'); ?>
                                            <input type="hidden" name="pk01_asset_action" value="depreciate">
                                            <input type="hidden" name="asset_id" value="<?php echo (int)$r['id']; ?>">
                                            <input type="month" name="period_key" value="<?php echo esc_attr(current_time('Y-m')); ?>" required style="padding:4px 6px; font-size:11px; border:1px solid #cbd5e1; border-radius:6px;">
                                            <button type="submit" class="pk01-btn pk01-btn-primary pk01-btn-sm">
                                                Post
                                            </button>
                                        </form>
                                    <?php elseif ($book <= $res): ?>
                                        <span class="pk01-badge badge-success">● Nilai Residu</span>
                                    <?php else: ?>
                                        <span class="pk01-badge badge-neutral">● Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top:18px; padding:12px 16px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; font-size:12px; color:#64748b; line-height:1.5;">
                ℹ️ <b>Kaidah Akuntansi Aktiva:</b> Belanja modal (CapEx) dicatat sebagai aset di neraca dan didepresiasikan setiap bulan [1]. Amortisasi ini memotong laba bersih riil secara proporsional namun <strong>tidak mengurangi saldo kas fisik</strong> karena kas telah dibayarkan saat pembelian awal [1].
            </div>
        </div>
    </div>

    <!-- 5. TAB 2: KAPITALISASI BELANJA ASET BARU -->
    <?php if ($can): ?>
    <div class="pk01-pane" id="tab-create">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>➕ Catat Kapitalisasi Belanja Aset Baru</h3>
                    <div class="pk01-surface-desc">
                        Pencatatan aktiva tetap memotong saldo kas toko dan menambah saldo aset pada neraca pembukuan [1].
                    </div>
                </div>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('pk01_asset', 'pk01_asset_nonce'); ?>
                <input type="hidden" name="pk01_asset_action" value="create">

                <div class="pk01-form-grid">
                    <div class="pk01-form-group">
                        <label>Kode Aset (Tag / Barcode)</label>
                        <input type="text" name="asset_code" class="pk01-ctrl" value="<?php echo esc_attr($suggested_code); ?>" required placeholder="Contoh: AST-0001" [1]>
                    </div>

                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Nama Aktiva / Mesin / Kendaraan <span style="color:#ef4444;">*</span></label>
                        <input type="text" name="name" class="pk01-ctrl" required placeholder="Contoh: Mesin CNC Router / Mobil Operasional Carry Pickup" [1]>
                    </div>

                    <div class="pk01-form-group">
                        <label>Kategori Aktiva</label>
                        <select name="category" id="pk01-asset-category" class="pk01-ctrl">
                            <?php foreach ($cats_preset as $c => $r): ?>
                                <option value="<?php echo esc_attr($c); ?>">
                                    <?php echo esc_html($c); ?><?php echo $r ? ' (' . $r . '% / thn)' : ''; ?> [1]
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-form-group">
                        <label>Tanggal Pembelian</label>
                        <input type="date" name="purchase_date" class="pk01-ctrl" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" required [1]>
                    </div>

                    <div class="pk01-form-group">
                        <label>Metode Pembayaran (Sumber Kas)</label>
                        <select name="payment_method" class="pk01-ctrl">
                            <option value="Transfer Bank">Transfer Bank (Buku Kas Bank)</option>
                            <option value="Kas Tunai">Kas Tunai (Petty Cash)</option>
                        </select>
                    </div>

                    <div class="pk01-form-group">
                        <label>Harga Perolehan / Beli (Rp) <span style="color:#ef4444;">*</span></label>
                        <input type="number" id="pk01-cost" name="purchase_cost" step="0.01" min="1" class="pk01-ctrl" required placeholder="Contoh: 25000000" [1]>
                    </div>

                    <div class="pk01-form-group">
                        <label>Nilai Residu / Sisa (Rp)</label>
                        <input type="number" id="pk01-residual" name="residual_value" step="0.01" min="0" value="0" class="pk01-ctrl" [1]>
                    </div>

                    <div class="pk01-form-group">
                        <label>Tarif Depresiasi Tahunan (%)</label>
                        <input type="number" name="annual_rate" id="pk01-annual-rate" step="0.01" min="0" max="100" value="10" class="pk01-ctrl" required [1]>
                    </div>

                    <div class="pk01-form-group">
                        <label>Masa Manfaat Ekonomis (Bulan)</label>
                        <input type="number" name="useful_life_months" id="pk01-life" min="1" value="120" class="pk01-ctrl" required [1]>
                    </div>

                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Keterangan Teknis / Penanggung Jawab / Lokasi</label>
                        <input type="text" name="notes" class="pk01-ctrl" placeholder="No. polisi, lokasi workshop, atau penanggung jawab..." [1]>
                    </div>

                    <!-- LIVE CALCULATOR ESTIMATOR BANNER -->
                    <div class="pk01-calc-banner">
                        <div class="pk01-calc-stat">
                            Dasar Nilai Disusutkan:
                            <b id="calc_depreciable_base">Rp 0</b>
                        </div>
                        <div class="pk01-calc-stat">
                            Beban Penyusutan per Tahun:
                            <b id="calc_yearly_depr">Rp 0</b>
                        </div>
                        <div class="pk01-calc-stat">
                            Beban Non-Kas per Bulan:
                            <b id="calc_monthly_depr" style="color:#059669;">Rp 0</b>
                        </div>
                    </div>

                    <div style="grid-column: 1 / -1; margin-top: 10px;">
                        <button type="submit" class="pk01-btn pk01-btn-primary" style="padding:11px 24px;">
                            💾 Simpan &amp; Kapitalisasi Belanja Aset
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- 6. TAB 3: RIWAYAT JURNAL PENYUSUTAN (POSTED DEPRECIATION) -->
    <div class="pk01-pane" id="tab-history">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📜 Buku Riwayat Jurnal Penyusutan Terposting</h3>
                    <div class="pk01-surface-desc">
                        Dokumentasi pembebanan amortisasi depresiasi non-kas yang telah dicatatkan ke Laporan Laba Rugi [1].
                    </div>
                </div>
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th>No. Referensi</th>
                            <th>Waktu Posting</th>
                            <th>Nama Aktiva Tetap</th>
                            <th>Periode Akuntansi</th>
                            <th style="text-align:right;">Nominal Beban Non-Kas</th>
                            <th style="text-align:center;">Status Jurnal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($depr_history)): ?>
                            <tr>
                                <td colspan="6" style="text-align:center; padding:36px; color:#94a3b8;">
                                    Belum ada jurnal penyusutan yang pernah diposting.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($depr_history as $dh): ?>
                            <tr>
                                <td>
                                    <span class="pk01-code-badge">DEP-#<?php echo esc_html($dh['id']); ?></span>
                                </td>
                                <td>
                                    <?php echo esc_html($dh['created_at'] ? date_i18n('d M Y, H:i', strtotime($dh['created_at'])) : '-'); ?>
                                </td>
                                <td>
                                    <strong><?php echo esc_html($dh['asset_name'] ?: 'Aset #' . $dh['asset_id']); ?></strong>
                                    <?php if (!empty($dh['asset_code'])): ?>
                                        <div style="font-size:11px; color:#64748b;"><?php echo esc_html($dh['asset_code']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="pk01-badge badge-neutral"><?php echo esc_html($dh['period_key']); ?></span>
                                </td>
                                <td style="text-align:right;">
                                    <span class="pk01-money" style="color:#d97706;">
                                        Rp <?php echo number_format((float)$dh['depreciation_amount'], 0, ',', '.'); ?>
                                    </span>
                                </td>
                                <td style="text-align:center;">
                                    <span class="pk01-badge badge-success">● POSTED</span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. PRESET TARIF KATEGORI & KALKULATOR LIVE
    const catSelect = document.getElementById('pk01-asset-category');
    const rateInput = document.getElementById('pk01-annual-rate');
    const lifeInput = document.getElementById('pk01-life');

    const ratesMap = {
        'Mobil/Kendaraan': 10,
        'Mesin Produksi': 12.5,
        'Komputer/Elektronik': 25,
        'Alat Kerja': 20,
        'Perabot/Kantor': 10,
        'Unit Barang/Aset Operasional': 10,
        'Lainnya': 0
    };

    if (catSelect && rateInput && lifeInput) {
        catSelect.addEventListener('change', function() {
            const r = ratesMap[this.value] || 0;
            if (r > 0) {
                rateInput.value = r;
                lifeInput.value = Math.ceil(1200 / r);
            }
            updateLiveDepreciationCalc();
        });
    }

    const costIn   = document.getElementById('pk01-cost');
    const resIn    = document.getElementById('pk01-residual');
    const outBase  = document.getElementById('calc_depreciable_base');
    const outYear  = document.getElementById('calc_yearly_depr');
    const outMonth = document.getElementById('calc_monthly_depr');

    function formatRupiah(num) {
        return 'Rp ' + Math.round(num).toLocaleString('id-ID');
    }

    function updateLiveDepreciationCalc() {
        if (!costIn || !rateInput) return;
        const cost = parseFloat(costIn.value) || 0;
        const res  = parseFloat(resIn.value) || 0;
        const rate = parseFloat(rateInput.value) || 0;

        const base    = Math.max(0, cost - res);
        const yearly  = base * (rate / 100);
        const monthly = yearly / 12;

        if (outBase)  outBase.textContent  = formatRupiah(base);
        if (outYear)  outYear.textContent  = formatRupiah(yearly);
        if (outMonth) outMonth.textContent = formatRupiah(monthly);
    }

    [costIn, resIn, rateInput, lifeInput].forEach(inp => {
        if (inp) inp.addEventListener('input', updateLiveDepreciationCalc);
    });

    // 3. SEARCH FILTER INSTAN UNTUK REGISTER ASET
    const assetSearch = document.getElementById('pk01_asset_search');
    if (assetSearch) {
        assetSearch.addEventListener('input', function() {
            const q = this.value.toLowerCase().trim();
            const rows = document.querySelectorAll('#pk01_asset_table tbody tr');
            rows.forEach(r => {
                const text = r.textContent.toLowerCase();
                r.style.display = text.includes(q) ? '' : 'none';
            });
        });
    }
});
</script>