<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

// Migrasi aman: tandai secara eksplisit apakah produk memang membutuhkan CNC.
$pk01_prod_table = PK01_DB::t('products');
if ($pk01_prod_table && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $pk01_prod_table)) === $pk01_prod_table) {
    $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$pk01_prod_table}`", 0);
    if (!in_array('cnc_required', $cols, true)) {
        $wpdb->query("ALTER TABLE `{$pk01_prod_table}` ADD `cnc_required` tinyint(1) NOT NULL DEFAULT 0 AFTER `status`");
    }
    if (!in_array('prema_required', $cols, true)) {
        $wpdb->query("ALTER TABLE `{$pk01_prod_table}` ADD `prema_required` tinyint(1) NOT NULL DEFAULT 0 AFTER `cnc_required`");
    }
}

$notice = '';
$action = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('products')
    : esc_url($_SERVER['REQUEST_URI'] ?? '');

if (function_exists('wp_enqueue_media')) {
    wp_enqueue_media();
}

/* Product Master CSV: satu pintu import produk/SKU. Tidak membuat data contoh. */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_product_master_import'])) {
    if (!current_user_can('manage_options')) { $notice='<div class="pk-alert pk-alert-error"><strong>Akses ditolak.</strong> Hanya Admin/Owner yang dapat mengimpor Product Master.</div>'; }
    elseif (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_product_master_nonce']??'')),'pk01_product_master_import')) { $notice='<div class="pk-alert pk-alert-error"><strong>Keamanan:</strong> sesi import tidak valid.</div>'; }
    else { try { $r=PK01_Product_Master::import_csv($_FILES['product_master_csv']??[]); $notice='<div class="pk-alert pk-alert-success"><strong>Product Master berhasil diproses.</strong> '.$r['created'].' produk baru, '.$r['updated'].' produk diperbarui, '.$r['variants'].' SKU diproses dari '.$r['total'].' baris.'; if($r['errors'])$notice.='<br><small>'.esc_html(implode(' | ',array_slice($r['errors'],0,10))).'</small>'; $notice.='</div>'; } catch(Throwable $e){$notice='<div class="pk-alert pk-alert-error"><strong>Import gagal:</strong> '.esc_html($e->getMessage()).'</div>'; } }
}

/* ==========================================================================
   LOGIKA BACKEND (DIPERKUAT DENGAN SANITASI KETAT & LOGIKA BARU)
   ========================================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_prod_action']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_prod_nonce'] ?? '')), 'pk01_prod_save')) {
    try {
        // [LOGIKA LAMA DIJAGA + LOGIKA SANITASI TERSTRUKTUR]
        $spec = [
            'image_id'                => absint($_POST['image_id'] ?? 0),
            'category'                => sanitize_text_field($_POST['category'] ?? ''),
            'product_description'     => sanitize_textarea_field($_POST['description'] ?? ''),
            'production_notes'        => sanitize_textarea_field($_POST['production_notes'] ?? ''),
            'production_instructions' => sanitize_textarea_field($_POST['production_instructions'] ?? ''),
            'product_length'          => floatval($_POST['product_length'] ?? 0),
            'product_width'           => floatval($_POST['product_width'] ?? 0),
            'product_height'          => floatval($_POST['product_height'] ?? 0),
            'product_thickness'       => floatval($_POST['product_thickness'] ?? 0),
            'product_weight'          => floatval($_POST['product_weight'] ?? 0),
            'dimension_unit'          => sanitize_text_field($_POST['dimension_unit'] ?? 'cm'),
            'weight_unit'             => sanitize_text_field($_POST['weight_unit'] ?? 'kg'),
            'finishing'               => sanitize_text_field($_POST['finishing'] ?? ''),
            'color'                   => sanitize_text_field($_POST['color'] ?? ''),
            'spec_status'             => 'complete'
        ];

        $code        = sanitize_text_field($_POST['code'] ?? '');
        $name        = sanitize_text_field($_POST['name'] ?? '');
        $notes       = sanitize_textarea_field($_POST['notes'] ?? '');
        $description = !empty($_POST['description']) ? sanitize_textarea_field($_POST['description']) : $spec['product_description'];
        $sku         = sanitize_text_field($_POST['sku'] ?? '');
        $material    = sanitize_text_field($_POST['material'] ?? '');
        $brand       = sanitize_text_field($_POST['brand'] ?? '');
        $hpp         = (float)($_POST['hpp'] ?? 0);
        $price       = (float)($_POST['price'] ?? 0);
        $opening_stock = max(0, (float)($_POST['opening_stock'] ?? 0));
        $cnc_required = !empty($_POST['cnc_required']) ? 1 : 0;
        $prema_required = !empty($_POST['prema_required']) ? 1 : 0;

        if (empty($code) || empty($name) || empty($sku)) {
            throw new Exception('Kode Produk, Nama Produk, dan SKU wajib diisi.');
        }
        if ($price < 0 || $hpp < 0) throw new Exception('Harga dan HPP tidak boleh negatif.');
        if ($spec['product_weight'] < 0) throw new Exception('Berat tidak boleh negatif.');

        // Eksekusi Logika Inti PK01 Engine
        $pid = PK01_Engine::create_product($code, $name, $notes, $description, $spec);
        
        $dimension_str = $spec['product_length'] . 'x' . $spec['product_width'] . 'x' . $spec['product_height'] . ' ' . $spec['dimension_unit'];
        $variant_id = PK01_Engine::create_variant($pid, $sku, $name, $dimension_str, $material, $spec['finishing'], $hpp, $price, 0);
        if ($variant_id <= 0) throw new Exception('SKU gagal dibuat. Produk belum dipublikasikan.');
        // Opening stock must enter the real stock ledger; otherwise a later stock transaction
        // would make the storefront calculated stock ignore the opening balance.
        if ($opening_stock > 0) PK01_Engine::adjust_stock('finished', $variant_id, $opening_stock, 'Stok awal Master Produk ' . $sku);
        // Category/brand are catalog metadata stored in the PK01 product master itself.
        $wpdb->update(PK01_DB::t('products'), ['category'=>$spec['category'], 'brand'=>$brand, 'cnc_required'=>$cnc_required, 'prema_required'=>$prema_required, 'updated_at'=>current_time('mysql')], ['id'=>$pid]);
        // Only a complete commerce record is published to the Theme/E-Commerce feed.
        $commerce_ready = !empty($spec['image_id']) && $description !== '' && $price > 0 && $sku !== '';
        $product_table = PK01_DB::t('products');
        $wpdb->update($product_table, ['status' => $commerce_ready ? 'active' : 'draft', 'updated_at' => current_time('mysql')], ['id' => $pid]);

        // Eksekusi Galeri Media
        $g = array_filter(array_map('intval', (array)($_POST['gallery_ids'] ?? [])));
        foreach ($g as $aid) {
            PK01_Engine::add_product_image($pid, $aid, ((int)$aid === $spec['image_id']) ? 'main' : 'additional');
        }

        $notice = '<div class="pk-alert pk-alert-success"><div class="pk-alert-icon">✓</div><div><strong>Berhasil!</strong> Produk <code>' . esc_html($code) . '</code> dan spesifikasi teknis berhasil dikomit ke sistem.</div></div>';
    } catch (Throwable $e) {
        $notice = '<div class="pk-alert pk-alert-error"><div class="pk-alert-icon">✕</div><div><strong>Gagal Menyimpan:</strong> ' . esc_html($e->getMessage()) . '</div></div>';
    }
}

/* ==========================================================================
   DATA FETCHING (QUERY LAMA LENGKAP)
   ========================================================================== */
$p = PK01_DB::t('products'); 
$v = PK01_DB::t('product_variants'); 
$g = PK01_DB::t('product_gallery');

$rows = $wpdb->get_results("
    SELECT p.id, p.code, p.name, p.image_id, p.status, p.brand, p.category, p.cnc_required, p.prema_required, p.product_length, p.product_width, p.product_height, 
           p.product_thickness, p.dimension_unit, p.finishing, p.color, p.product_description, 
           p.spec_status, v.sku, v.hpp, v.status variant_status, v.material, v.size 
    FROM $p p 
    INNER JOIN $v v ON v.product_id = p.id 
    ORDER BY p.id DESC 
    LIMIT 50
", ARRAY_A) ?: [];

// Hitung Statistik Mini untuk KPI Bar
$total_products = count($rows);
$complete_specs = count(array_filter($rows, function($r){return ($r['spec_status'] ?? '') === 'complete';}));
?>

<div style="margin:0 0 16px;padding:14px 16px;border:1px solid #dbeafe;border-radius:12px;background:#eff6ff;color:#1e3a8a;font-size:13px;">
<strong>🔗 Product Master adalah sumber utama PK01.</strong> Produk yang disimpan di sini menjadi sumber E-Commerce/Theme, katalog Seller, Job Produksi dan routing CNC/Prema. Marketplace tidak membuat master produk baru. <span style="color:#475569;">Jika produk tidak membutuhkan CNC, biarkan CNC tidak dicentang; G-code tidak akan diminta.</span>
</div>

<div id="pk01-product-upload" class="pk-form-section" style="margin:0 0 16px;padding:16px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;">
  <div class="pk-form-section-title">📥 Import Product Master — Satu Data Master</div>
  <p style="margin:4px 0 12px;color:#64748b;font-size:13px;">Upload satu CSV untuk membuat/memperbarui Produk + SKU. Data ini menjadi sumber Theme/E-Commerce, Seller, Order, Produksi dan CNC. Tidak membuat produk marketplace terpisah.</p>
  <form method="post" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <?php wp_nonce_field('pk01_product_master_import','pk01_product_master_nonce'); ?>
    <input type="hidden" name="pk01_product_master_import" value="1">
    <input type="file" name="product_master_csv" accept=".csv,text/csv" required>
    <button type="submit" class="pk-btn-primary" style="border:0;padding:10px 14px;border-radius:8px;cursor:pointer;">⬆ Import Product Master</button>
    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pk01_product_master_template'),'pk01_product_master_template')); ?>" style="padding:9px 12px;border:1px solid #cbd5e1;border-radius:8px;text-decoration:none;">⬇ Template CSV</a>
  </form>
  <small style="display:block;margin-top:8px;color:#64748b;">Kolom minimum: <code>code,name,sku</code>. Stok awal hanya dicatat satu kali ke stock ledger; gambar memakai <code>image_id</code> WordPress yang benar-benar ada.</small>
</div>

<!-- STYLE SHEET TAMPILAN MODERN MASTERPIECE -->
<style>
.pk-modern-wrap {
  --pk-primary: #2563eb;
  --pk-primary-hover: #1d4ed8;
  --pk-surface: #ffffff;
  --pk-bg: #f8fafc;
  --pk-border: #e2e8f0;
  --pk-text-main: #0f172a;
  --pk-text-muted: #64748b;
  --pk-success: #10b981;
  --pk-radius: 12px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  color: var(--pk-text-main);
  margin-top: 15px;
}
.pk-modern-wrap * { box-sizing: border-box; }

/* Alert Styles */
.pk-alert {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 18px;
  border-radius: var(--pk-radius);
  margin-bottom: 20px;
  font-size: 14px;
}
.pk-alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk-alert-error { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
.pk-alert-icon { font-weight: bold; font-size: 18px; line-height: 1; }

/* Header & Stat Cards */
.pk-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: flex-end;
  background: var(--pk-surface);
  padding: 24px;
  border-radius: var(--pk-radius);
  border: 1px solid var(--pk-border);
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);
  margin-bottom: 24px;
  gap: 16px;
}
.pk-eyebrow {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--pk-primary);
  display: block;
  margin-bottom: 4px;
}
.pk-header h1 {
  font-size: 24px;
  font-weight: 800;
  margin: 0;
  color: var(--pk-text-main);
  letter-spacing: -0.02em;
}
.pk-header p {
  color: var(--pk-text-muted);
  font-size: 14px;
  margin: 6px 0 0 0;
  max-width: 600px;
}
.pk-kpi-bar {
  display: flex;
  gap: 12px;
}
.pk-kpi-pill {
  background: var(--pk-bg);
  border: 1px solid var(--pk-border);
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  min-width: 100px;
}
.pk-kpi-pill span { font-size: 11px; color: var(--pk-text-muted); }
.pk-kpi-pill strong { font-size: 18px; color: var(--pk-text-main); }

/* Main Grid Layout */
.pk-layout-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 24px;
  align-items: start;
}
@media (max-width: 980px) {
  .pk-layout-grid { grid-template-columns: 1fr; }
}

/* Card Elements */
.pk-panel {
  background: var(--pk-surface);
  border-radius: var(--pk-radius);
  border: 1px solid var(--pk-border);
  box-shadow: 0 1px 3px rgba(0,0,0,0.02);
  overflow: hidden;
}
.pk-panel-header {
  padding: 16px 20px;
  border-bottom: 1px solid var(--pk-border);
  background: #fafbfc;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.pk-panel-header h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
  color: var(--pk-text-main);
}
.pk-panel-body { padding: 20px; }

/* Subsections in Form */
.pk-form-section {
  margin-bottom: 24px;
  padding-bottom: 20px;
  border-bottom: 1px dashed var(--pk-border);
}
.pk-form-section:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}
.pk-form-section-title {
  font-size: 13px;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--pk-text-muted);
  letter-spacing: 0.05em;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 6px;
}

/* Form Controls */
.pk-input-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 14px;
}
.pk-field {
  display: flex;
  flex-direction: column;
  gap: 5px;
}
.pk-field label {
  font-size: 12px;
  font-weight: 600;
  color: #334155;
}
.pk-field input, 
.pk-field select, 
.pk-field textarea {
  width: 100%;
  border: 1px solid var(--pk-border);
  border-radius: 8px;
  padding: 9px 12px;
  font-size: 13px;
  background: #fff;
  transition: all 0.2s ease;
  color: var(--pk-text-main);
}
.pk-field input:focus, 
.pk-field select:focus, 
.pk-field textarea:focus {
  border-color: var(--pk-primary);
  outline: none;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}
.pk-input-group {
  display: flex;
  gap: 6px;
}
.pk-input-group input { flex: 1; }
.pk-input-group select { width: 90px; }

/* Media Gallery Picker Box */
.pk-media-box {
  background: var(--pk-bg);
  border: 2px dashed #cbd5e1;
  border-radius: 10px;
  padding: 16px;
  text-align: center;
}
.pk-media-preview-container {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 12px;
  justify-content: center;
}
.pk-thumb-card {
  position: relative;
  width: 82px;
  height: 82px;
  border-radius: 8px;
  overflow: hidden;
  border: 2px solid transparent;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.pk-thumb-card.is-main {
  border-color: var(--pk-primary);
}
.pk-thumb-card img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.pk-thumb-badge {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: var(--pk-primary);
  color: white;
  font-size: 9px;
  text-transform: uppercase;
  font-weight: bold;
  padding: 2px 0;
}

/* Primary Submit Button */
.pk-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: var(--pk-primary);
  color: white;
  border: none;
  font-weight: 600;
  font-size: 14px;
  padding: 12px 20px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  width: 100%;
}
.pk-btn:hover { background: var(--pk-primary-hover); transform: translateY(-1px); }
.pk-btn-secondary {
  background: #f1f5f9;
  color: #334155;
  border: 1px solid var(--pk-border);
  padding: 7px 12px;
  font-size: 12px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
}
.pk-btn-secondary:hover { background: #e2e8f0; }

/* Interactive Live Preview Box */
.pk-live-preview-box {
  background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
  color: white;
  border-radius: var(--pk-radius);
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.25);
}
.pk-live-preview-box h4 {
  margin: 0 0 12px;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: #94a3b8;
}
.pk-preview-title {
  font-size: 18px;
  font-weight: 700;
  color: #f8fafc;
  line-height: 1.2;
}
.pk-preview-code {
  font-size: 12px;
  color: #38bdf8;
  font-family: monospace;
  margin-top: 4px;
}
.pk-preview-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  margin-top: 14px;
  font-size: 12px;
}
.pk-preview-grid div {
  background: rgba(255,255,255,0.06);
  padding: 8px;
  border-radius: 6px;
}
.pk-preview-grid span { display: block; font-size: 10px; color: #94a3b8; }

/* Table Container & Filter */
.pk-table-container {
  background: var(--pk-surface);
  border-radius: var(--pk-radius);
  border: 1px solid var(--pk-border);
  margin-top: 24px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-table-header-tools {
  padding: 16px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  background: #fafbfc;
  border-bottom: 1px solid var(--pk-border);
}
.pk-table-header-tools h3 { margin: 0; font-size: 16px; font-weight: 700; }
.pk-search-box {
  width: 260px;
  position: relative;
}
.pk-search-box input {
  width: 100%;
  padding: 8px 12px 8px 30px;
  font-size: 13px;
  border: 1px solid var(--pk-border);
  border-radius: 8px;
}
.pk-search-box::before {
  content: "🔍";
  position: absolute;
  left: 9px;
  top: 8px;
  font-size: 12px;
  opacity: 0.5;
}

/* Real Table Design */
.pk-table-responsive { width: 100%; overflow-x: auto; }
.pk-table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
  font-size: 13px;
}
.pk-table th {
  background: #f8fafc;
  color: var(--pk-text-muted);
  font-weight: 600;
  text-transform: uppercase;
  font-size: 11px;
  letter-spacing: 0.05em;
  padding: 12px 16px;
  border-bottom: 1px solid var(--pk-border);
}
.pk-table td {
  padding: 12px 16px;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
}
.pk-table tr:hover td { background: #fbfcfe; }

/* Badges & Chips */
.pk-badge {
  display: inline-block;
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
}
.pk-badge-success { background: #dcfce7; color: #15803d; }
.pk-badge-draft { background: #f1f5f9; color: #475569; }

.pk-sku-chip {
  background: #f1f5f9;
  font-family: monospace;
  padding: 3px 6px;
  border-radius: 4px;
  font-size: 12px;
  color: #334155;
  border: 1px solid #e2e8f0;
}
.pk-btn-pdf {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 5px 10px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  text-decoration: none;
  background: #fee2e2;
  color: #b91c1c;
  transition: all 0.15s;
}
.pk-btn-pdf:hover { background: #fca5a5; color: #7f1d1d; }
</style>

<div class="pk-modern-wrap">
  <!-- NOTIFIKASI -->
  <?php echo $notice; ?>

  <!-- HEADER & KPI STATS -->
  <div class="pk-header">
    <div>
      <span class="pk-eyebrow">Production Master Control</span>
      <h1>Produk & Spesifikasi Produksi</h1>
      <p>Manajemen parameter produk, kalkulasi HPP, instruksi SOP fabrikasi, dan standarisasi visual referensi Job.</p>
    </div>
    <div class="pk-kpi-bar">
      <div class="pk-kpi-pill">
        <span>Total Produk</span>
        <strong><?php echo esc_html($total_products); ?></strong>
      </div>
      <div class="pk-kpi-pill">
        <span>Spesifikasi Siap</span>
        <strong><?php echo esc_html($complete_specs); ?></strong>
      </div>
    </div>
  </div>

  <div class="pk-layout-grid">
    <!-- FORMULIR INPUT UTAMA -->
    <div class="pk-panel" id="pk01-manual-product">
      <div class="pk-panel-header">
        <h3>Input Data Produk & Parameter Baru</h3>
      </div>
      <div class="pk-panel-body">
        <div style="margin-bottom:18px;padding:14px 16px;border:1px solid #bfdbfe;background:#eff6ff;border-radius:12px;color:#1e3a8a;font-size:13px;line-height:1.55">
          <strong>MASTER PRODUK TERPUSAT</strong><br>
          Produk yang disimpan di sini adalah sumber data resmi PK01 untuk E-Commerce/Theme, katalog Seller, dan Produksi. Jika foto + deskripsi + SKU + harga belum lengkap, produk disimpan sebagai <strong>DRAFT</strong> sehingga tidak tampil ke E-Commerce/Seller dan tidak ikut mass upload marketplace.
        </div>
        <form method="post" action="<?php echo esc_url($action); ?>" id="pk01-main-form">
          <?php echo wp_nonce_field('pk01_prod_save', 'pk01_prod_nonce', true, false); ?>
          <input type="hidden" name="pk01_prod_action" value="save">

          <!-- KELOMPOK 1: IDENTITAS PRODUK -->
          <div class="pk-form-section">
            <div class="pk-form-section-title">📦 Identitas & Finansial Produk</div>
            <div class="pk-input-grid">
              <div class="pk-field">
                <label>Kode Produk *</label>
                <input id="in-code" name="code" placeholder="PRD-001" required>
              </div>
              <div class="pk-field">
                <label>Nama Produk *</label>
                <input id="in-name" name="name" placeholder="Misal: Meja Rapat Industrial" required>
              </div>
              <div class="pk-field">
                <label>Kategori</label>
                <input id="in-cat" name="category" placeholder="Furniture, Rak, dsb.">
              </div>
              <div class="pk-field">
                <label>Merek / Brand</label>
                <input id="in-brand" name="brand" placeholder="Brand toko">
              </div>
              <div class="pk-field">
                <label>SKU Utama *</label>
                <input id="in-sku" name="sku" placeholder="BDTV-001" required>
              </div>
              <div class="pk-field">
                <label>HPP / Biaya Bahan (Rp) *</label>
                <input id="in-hpp" type="number" name="hpp" min="0" step=".01" placeholder="0" required>
              </div>
              <div class="pk-field">
                <label>Harga Jual E-Commerce (Rp) *</label>
                <input id="in-price" type="number" name="price" min="0" step=".01" placeholder="0" required>
              </div>
              <div class="pk-field">
                <label>Stok Awal</label>
                <input id="in-opening-stock" type="number" name="opening_stock" min="0" step=".001" value="0">
              </div>
              <div class="pk-field">
                <label>Bahan Utama</label>
                <input id="in-material" name="material" placeholder="Plywood 18mm / Hollow Steel">
              </div>
              <div class="pk-field" style="align-self:end;padding:10px 12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc">
                <label style="display:flex;gap:8px;align-items:center;cursor:pointer"><input type="checkbox" name="cnc_required" value="1"> <strong>Produk membutuhkan proses CNC</strong></label>
                <small style="display:block;margin-top:5px;color:#64748b">Jika tidak dicentang, PK01 tidak akan membuat assignment CNC dan tidak akan menuntut G-code.</small>
              </div>
              <div class="pk-field" style="align-self:end;padding:10px 12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc">
                <label style="display:flex;gap:8px;align-items:center;cursor:pointer"><input type="checkbox" name="prema_required" value="1"> <strong>Produk membutuhkan Prema / Finishing</strong></label>
                <small style="display:block;margin-top:5px;color:#64748b">Routing eksplisit. PK01 tidak menebak kebutuhan Prema dari nama/deskripsi produk.</small>
              </div>
            </div>
          </div>

          <!-- KELOMPOK 2: DIMENSI & SPESIFIKASI FISIK -->
          <div class="pk-form-section">
            <div class="pk-form-section-title">📐 Dimensi & Atribut Fisik</div>
            <div class="pk-input-grid">
              <div class="pk-field">
                <label>Panjang</label>
                <input id="in-length" type="number" name="product_length" min="0" step=".001" placeholder="0">
              </div>
              <div class="pk-field">
                <label>Lebar</label>
                <input id="in-width" type="number" name="product_width" min="0" step=".001" placeholder="0">
              </div>
              <div class="pk-field">
                <label>Tinggi</label>
                <input id="in-height" type="number" name="product_height" min="0" step=".001" placeholder="0">
              </div>
              <div class="pk-field">
                <label>Tebal Material</label>
                <input id="in-thickness" type="number" name="product_thickness" min="0" step=".001" placeholder="0">
              </div>
              <div class="pk-field">
                <label>Satuan Ukuran</label>
                <select id="in-dim-unit" name="dimension_unit">
                  <option value="cm" selected>Centimeter (cm)</option>
                  <option value="mm">Milimeter (mm)</option>
                  <option value="m">Meter (m)</option>
                </select>
              </div>
              <div class="pk-field">
                <label>Berat & Satuan</label>
                <div class="pk-input-group">
                  <input type="number" name="product_weight" min="0" step=".001" placeholder="0">
                  <select name="weight_unit">
                    <option value="kg" selected>kg</option>
                    <option value="gram">gram</option>
                  </select>
                </div>
              </div>
              <div class="pk-field">
                <label>Finishing</label>
                <input id="in-finishing" name="finishing" placeholder="HPL Doff / Cat Duco">
              </div>
              <div class="pk-field">
                <label>Warna</label>
                <input id="in-color" name="color" placeholder="Natural Oak / Matte Black">
              </div>
            </div>
          </div>

          <!-- KELOMPOK 3: INSTRUKSI TEKNIS & PRODUKSI -->
          <div class="pk-form-section">
            <div class="pk-form-section-title">⚙️ Deskripsi & SOP Produksi</div>
            <div class="pk-field" style="margin-bottom: 12px;">
              <label>Deskripsi & Fungsi Produk</label>
              <textarea name="description" rows="3" placeholder="Jelaskan ergonomi, fungsi, dan karakteristik produk..."></textarea>
            </div>
            <div class="pk-field" style="margin-bottom: 12px;">
              <label>Catatan Kritis Produksi</label>
              <textarea name="production_notes" rows="3" placeholder="Peringatan khusus untuk QC/Workshop (misal: sambungan bevel 45 derajat)..."></textarea>
            </div>
            <div class="pk-field" style="margin-bottom: 12px;">
              <label>Instruksi Kerja (Flow Pengerjaan)</label>
              <textarea name="production_instructions" rows="4" placeholder="1. Potong bahan sesuai cutting list&#10;2. Edging sisi samping&#10;3. Perakitan bodi&#10;4. Finishing dan QC akhir"></textarea>
            </div>
            <div class="pk-field">
              <label>Catatan Internal (Office Only)</label>
              <textarea name="notes" rows="2" placeholder="Catatan internal pengadaan/desain..."></textarea>
            </div>
          </div>

          <!-- KELOMPOK 4: REFERENSI MEDIA -->
          <div class="pk-form-section">
            <div class="pk-form-section-title">🖼️ Gambar Referensi Visual SPK</div>
            <div class="pk-media-box">
              <input type="hidden" id="pk01_product_image_id" name="image_id" value="">
              <div id="pk01_gallery_inputs"></div>
              
              <div id="pk01-product-preview" class="pk-media-preview-container">
                <span id="pk01-no-media-notice" style="font-size:12px;color:var(--pk-text-muted);">Belum ada gambar yang dipilih.</span>
              </div>
              
              <div style="margin-top: 14px;">
                <button type="button" class="pk-btn-secondary" id="pk01-pick-product-images">
                  + Pilih Gambar dari Media Library
                </button>
              </div>
            </div>
          </div>

          <button type="submit" class="pk-btn" style="margin-top: 10px;">
            Simpan Produk & Spesifikasi Standar
          </button>
        </form>
      </div>
    </div>

    <!-- SIDEBAR: LIVE SPK CARD & PANDUAN -->
    <div>
      <div class="pk-live-preview-box">
        <h4>👁️ Live SPK Card Preview</h4>
        <div class="pk-preview-title" id="prev-title">Nama Produk</div>
        <div class="pk-preview-code"><span id="prev-code">KODE-000</span> &bull; <span id="prev-sku">SKU-000</span></div>
        <div class="pk-preview-grid">
          <div>
            <span>Dimensi</span>
            <strong id="prev-dim">0 × 0 × 0 cm</strong>
          </div>
          <div>
            <span>Material</span>
            <strong id="prev-material">-</strong>
          </div>
          <div>
            <span>Finishing</span>
            <strong id="prev-finishing">-</strong>
          </div>
          <div>
            <span>Est. HPP</span>
            <strong id="prev-hpp">Rp 0</strong>
          </div>
        </div>
      </div>

      <div class="pk-panel">
        <div class="pk-panel-header">
          <h3>📌 Standarisasi SOP</h3>
        </div>
        <div class="pk-panel-body" style="font-size: 13px; line-height: 1.6; color: #475569;">
          <p style="margin-top:0;">Informasi yang tersimpan di panel ini adalah blueprint digital untuk divisi produksi:</p>
          <ul style="padding-left: 18px; margin: 0;">
            <li><strong>Gambar Pertama:</strong> Menjadi foto utama dokumen cetak SPK.</li>
            <li><strong>Dimensi & Toleransi:</strong> Terhubung otomatis ke cutting list kalkulator.</li>
            <li><strong>Instruksi Kerja:</strong> Mencegah rework dan salah rakit di lapangan.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- TABEL DATABASE PRODUK -->
  <div class="pk-table-container">
    <div class="pk-table-header-tools">
      <h3>Daftar Produk & Spesifikasi Terdaftar</h3>
      <div class="pk-search-box">
        <input type="text" id="pk-search-input" placeholder="Cari nama, SKU, atau kode...">
      </div>
    </div>

    <div class="pk-table-responsive">
      <table class="pk-table" id="pk-product-table">
        <thead>
          <tr>
            <th style="width: 70px;">Gambar</th>
            <th>Info Produk</th>
            <th>Dimensi (P × L × T)</th>
            <th>Material & Finishing</th>
            <th>SKU</th>
            <th>HPP</th>
            <th>Proses CNC</th>
            <th>Routing</th><th>Status</th>
            <th style="text-align: right;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): 
            $img = $r['image_id'] ? wp_get_attachment_image_url((int)$r['image_id'], 'thumbnail') : '';
          ?>
          <tr>
            <td>
              <?php if ($img): ?>
                <img src="<?php echo esc_url($img); ?>" alt="Preview" style="width:52px;height:52px;object-fit:cover;border-radius:6px;border:1px solid #e2e8f0;">
              <?php else: ?>
                <div style="width:52px;height:52px;border-radius:6px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:10px;">No IMG</div>
              <?php endif; ?>
            </td>
            <td>
              <strong style="color:var(--pk-text-main);"><?php echo esc_html($r['name']); ?></strong>
              <div style="font-size: 11px; color: var(--pk-text-muted); margin-top: 2px;">
                Kode: <code><?php echo esc_html($r['code']); ?></code>
              </div>
            </td>
            <td>
              <div><?php echo esc_html($r['product_length'] . ' × ' . $r['product_width'] . ' × ' . $r['product_height'] . ' ' . $r['dimension_unit']); ?></div>
              <?php if ((float)$r['product_thickness'] > 0): ?>
                <span style="font-size: 11px; color: var(--pk-text-muted);">Tebal: <?php echo esc_html($r['product_thickness'] . ' ' . $r['dimension_unit']); ?></span>
              <?php endif; ?>
            </td>
            <td>
              <div><?php echo esc_html($r['material'] ?: '-'); ?></div>
              <small style="color: var(--pk-text-muted);"><?php echo esc_html($r['finishing'] ?: '-'); ?></small>
            </td>
            <td>
              <span class="pk-sku-chip"><?php echo esc_html($r['sku']); ?></span>
            </td>
            <td>
              <strong>Rp <?php echo number_format((float)($r['hpp'] ?? 0), 0, ',', '.'); ?></strong>
            </td>
            <td>
              <?php if (!empty($r['cnc_required'])): ?>
                <span class="pk-badge pk-badge-success">⚙️ CNC DIBUTUHKAN</span>
              <?php else: ?>
                <span class="pk-badge">Tidak perlu CNC</span>
              <?php endif; ?>
            </td>
            <td>
              <small><?php echo !empty($r['cnc_required']) ? '⚙️ CNC' : ''; ?><?php echo !empty($r['prema_required']) ? (!empty($r['cnc_required']) ? ' · 🎨 Prema' : '🎨 Prema') : ''; ?><?php if(empty($r['cnc_required']) && empty($r['prema_required'])) echo 'Tidak ada tahap khusus'; ?></small>
            </td>
            <td>
              <span class="pk-badge <?php echo (($r['status'] ?? '') === 'active') ? 'pk-badge-success' : 'pk-badge-draft'; ?>">
                <?php echo (($r['status'] ?? '') === 'active') ? 'LIVE E-COMMERCE' : 'DRAFT — BELUM SIAP JUAL'; ?>
              </span>
            </td>
            <td style="text-align: right;">
              <?php 
                $pdf_url = function_exists('pk01_print_url') 
                  ? esc_url(pk01_print_url('produk', $r['id'])) 
                  : '#';
              ?>
              <a class="pk-btn-pdf" target="_blank" href="<?php echo $pdf_url; ?>">
                📄 Cetak SPK
              </a>
            </td>
          </tr>
          <?php endforeach; ?>

          <?php if (empty($rows)): ?>
          <tr id="pk-empty-row">
            <td colspan="9" style="text-align:center;padding:32px;color:var(--pk-text-muted);">
              Belum ada data produk tersimpan di database.
            </td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- CLIENT JAVASCRIPT MASTERPIECE: LIVE PREVIEWS, SEARCH & MEDIA GALLERY -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  // 1. Sinkronisasi Live Preview Box
  const nameIn = document.getElementById('in-name');
  const codeIn = document.getElementById('in-code');
  const skuIn = document.getElementById('in-sku');
  const lIn = document.getElementById('in-length');
  const wIn = document.getElementById('in-width');
  const hIn = document.getElementById('in-height');
  const uIn = document.getElementById('in-dim-unit');
  const matIn = document.getElementById('in-material');
  const finIn = document.getElementById('in-finishing');
  const hppIn = document.getElementById('in-hpp');

  function updatePreview() {
    document.getElementById('prev-title').innerText = nameIn.value || 'Nama Produk';
    document.getElementById('prev-code').innerText = codeIn.value || 'KODE-000';
    document.getElementById('prev-sku').innerText = skuIn.value || 'SKU-000';
    
    const l = lIn.value || '0';
    const w = wIn.value || '0';
    const h = hIn.value || '0';
    const u = uIn.value || 'cm';
    document.getElementById('prev-dim').innerText = `${l} × ${w} × ${h} ${u}`;
    document.getElementById('prev-material').innerText = matIn.value || '-';
    document.getElementById('prev-finishing').innerText = finIn.value || '-';
    
    const hppVal = parseFloat(hppIn.value) || 0;
    document.getElementById('prev-hpp').innerText = 'Rp ' + hppVal.toLocaleString('id-ID');
  }

  [nameIn, codeIn, skuIn, lIn, wIn, hIn, uIn, matIn, finIn, hppIn].forEach(el => {
    if (el) el.addEventListener('input', updatePreview);
  });

  // 2. Real-time Search Tabel Produk
  const searchInput = document.getElementById('pk-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const q = this.value.toLowerCase();
      const rows = document.querySelectorAll('#pk-product-table tbody tr:not(#pk-empty-row)');
      
      rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(q) ? '' : 'none';
      });
    });
  }

  // 3. Media Picker Uploader dengan Auto Container
  const pickerBtn = document.getElementById('pk01-pick-product-images');
  if (pickerBtn && typeof wp !== 'undefined' && wp.media) {
    pickerBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      const frame = wp.media({
        title: 'Pilih Gambar Produk & Referensi Teknis',
        button: { text: 'Gunakan Gambar Terpilih' },
        multiple: true,
        library: { type: 'image' }
      });

      frame.on('select', function() {
        const selection = frame.state().get('selection');
        const previewContainer = document.getElementById('pk01-product-preview');
        const inputsContainer = document.getElementById('pk01_gallery_inputs');
        const mainImageInput = document.getElementById('pk01_product_image_id');
        
        previewContainer.innerHTML = '';
        inputsContainer.innerHTML = '';
        
        let isFirst = true;

        selection.each(function(att) {
          const d = att.toJSON();
          const id = parseInt(d.id, 10);

          // Tambah hidden input gallery_ids[]
          const h = document.createElement('input');
          h.type = 'hidden';
          h.name = 'gallery_ids[]';
          h.value = id;
          inputsContainer.appendChild(h);

          // Render thumbnail
          const thumbCard = document.createElement('div');
          thumbCard.className = 'pk-thumb-card' + (isFirst ? ' is-main' : '');
          
          const img = document.createElement('img');
          img.src = (d.sizes && d.sizes.thumbnail) ? d.sizes.thumbnail.url : d.url;
          thumbCard.appendChild(img);

          if (isFirst) {
            mainImageInput.value = id;
            const badge = document.createElement('div');
            badge.className = 'pk-thumb-badge';
            badge.innerText = 'Utama';
            thumbCard.appendChild(badge);
            isFirst = false;
          }

          previewContainer.appendChild(thumbCard);
        });
      });

      frame.open();
    });
  }
});
</script>