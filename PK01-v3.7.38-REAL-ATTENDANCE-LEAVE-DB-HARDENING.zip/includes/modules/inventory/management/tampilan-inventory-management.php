<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage   = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('inventory') || PK01_Authorization::can('assets_inventory')));

if (!$can_manage) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🚫</div>
            <strong style="font-size:16px;">Akses Dibatasi</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin otorisasi untuk mengelola inventori bahan dan aset.</p>
          </div>';
    return;
}

// 2. HELPER NAMA TABEL RESMI PK01
$tm = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('materials') : $wpdb->prefix . 'pk01_materials';
$ta = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('fixed_assets') : $wpdb->prefix . 'pk01_fixed_assets';
$tv = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('inventory_valuation_adjustments') : $wpdb->prefix . 'pk01_inventory_valuation_adjustments';
$td = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('asset_depreciation') : $wpdb->prefix . 'pk01_asset_depreciation';

$msg = ''; 
$err = '';

// 3. PROSES AKSI: PENERIMAAN STOK, PEMBELIAN ASET, POSTING DEPRESIASI & WRITE-DOWN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_inv_action'])) {
    check_admin_referer('pk01_inv_action', 'pk01_inv_nonce');
    try {
        $a = sanitize_key($_POST['pk01_inv_action']);

        if ($a === 'receipt') {
            $mid   = (int)($_POST['material_id'] ?? 0);
            $qty   = (float)($_POST['qty'] ?? 0);
            $cost  = (float)($_POST['unit_cost'] ?? 0);
            $paid  = !empty($_POST['paid']);
            $notes = sanitize_text_field(wp_unslash($_POST['notes'] ?? ''));

            if (!$mid || $qty <= 0) {
                throw new Exception('Pilih bahan baku dan masukkan kuantitas barang masuk.');
            }

            if (class_exists('PK01_Engine')) {
                PK01_Engine::record_inventory_receipt($mid, $qty, $cost, $paid, $notes);
            }
            $msg = 'Persediaan bahan baku berhasil diterima dan ditambahkan ke stok gudang. Nilai persediaan dicatat sebagai aktiva lancar.';
            
        } elseif ($a === 'asset') {
            $name = sanitize_text_field(wp_unslash($_POST['asset_name'] ?? ''));
            $cost = (float)($_POST['asset_cost'] ?? 0);
            $life = (int)($_POST['useful_life'] ?? 0);
            $res  = (float)($_POST['residual_value'] ?? 0);

            if (!$name || $cost <= 0 || $life <= 0) {
                throw new Exception('Nama aset, harga perolehan, dan umur manfaat (bulan) wajib diisi.');
            }

            $code = 'AST-' . current_time('YmdHis') . '-' . wp_rand(10, 99);
            $wpdb->insert($ta, [
                'asset_code'          => $code,
                'name'                => $name,
                'purchase_date'       => sanitize_text_field($_POST['purchase_date'] ?? current_time('Y-m-d')),
                'purchase_cost'       => $cost,
                'residual_value'      => max(0, $res),
                'useful_life_months'  => $life,
                'status'              => 'active',
                'created_by'          => get_current_user_id(),
                'created_at'          => current_time('mysql')
            ]);

            $id = $wpdb->insert_id;
            if (!$id) {
                throw new Exception($wpdb->last_error ?: 'Aset gagal disimpan ke database.');
            }

            if (class_exists('PK01_Engine')) {
                PK01_Engine::cash('out', $cost, 'Pembelian Aset Tetap', 'fixed_asset', $id, $name, 'Kas Tunai Toko', $code);
            }
            $msg = 'Aset tetap berhasil dikapitalisasi ke Neraca Aktiva. Kas pembayaran dipotong dan beban disusutkan secara berkala tanpa memotong laba instan.';

        } elseif ($a === 'depreciate') {
            $aid = (int)($_POST['asset_id'] ?? 0);
            if (class_exists('PK01_Engine')) {
                PK01_Engine::post_asset_depreciation($aid, current_time('Y-m'));
            }
            $msg = 'Beban penyusutan periode ini berhasil diposting ke Laporan Laba Rugi tanpa pengeluaran kas baru.';

        } elseif ($a === 'write_down') {
            $mid    = (int)($_POST['material_id'] ?? 0);
            $value  = (float)($_POST['write_down'] ?? 0);
            $reason = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));

            if (!$mid || $value <= 0) {
                throw new Exception('Pilih bahan baku dan masukkan nominal penurunan nilai yang valid.');
            }

            $m = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tm} WHERE id = %d", $mid));
            if (!$m) {
                throw new Exception('Bahan baku tidak ditemukan di master gudang.');
            }

            $wpdb->insert($tv, [
                'item_type'       => 'material',
                'item_id'         => $mid,
                'adjustment_type' => 'write_down',
                'amount'          => $value,
                'reason'          => $reason,
                'status'          => 'approved',
                'created_by'      => get_current_user_id(),
                'created_at'      => current_time('mysql')
            ]);

            if (!$wpdb->insert_id) {
                throw new Exception($wpdb->last_error ?: 'Penyesuaian nilai gagal disimpan.');
            }

            $msg = 'Penurunan nilai persediaan (write-down) berhasil dibukukan. Kerugian penilaian ini tidak memotong kas fisik.';
        }
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

// 4. PENGAMBILAN DATA REAL DARI DATABASE
$materials = $wpdb->get_results("SELECT * FROM {$tm} ORDER BY name ASC") ?: [];

// Ambil aset tetap dengan akumulasi penyusutan riil
$assets = $wpdb->get_results("
    SELECT a.*, 
           COALESCE((SELECT SUM(ad.depreciation_amount) FROM {$td} ad WHERE ad.asset_id = a.id AND ad.status = 'posted'), 0) AS accumulated 
    FROM {$ta} a 
    ORDER BY a.id DESC LIMIT 100
") ?: [];

// 5. METRIK FINANSIAL & PORTOFOLIO NILAI RIIL
$total_inventory_val = 0;
foreach ($materials as $m) {
    $total_inventory_val += ((float)($m->stock ?? 0) * (float)($m->cost ?? 0));
}

$total_asset_capex = 0;
$total_asset_book  = 0;
foreach ($assets as $a) {
    $c  = (float)($a->purchase_cost ?? 0);
    $ac = (float)($a->accumulated ?? 0);
    $total_asset_capex += $c;
    $total_asset_book  += max(0, $c - $ac);
}

$month_write_down = 0;
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tv)) === $tv) {
    $month_write_down = (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM `{$tv}` WHERE DATE_FORMAT(created_at, '%%Y-%%m') = %s",
        current_time('Y-m')
    ));
}
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-inv-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-inv-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-inv-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 4 KPI Cards */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-green  { background: #ffffff; }
.pk01-kpi-card.c-green::before  { background: var(--pk-emerald); }
.pk01-kpi-card.c-blue   { background: #ffffff; }
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-amber  { background: #ffffff; }
.pk01-kpi-card.c-amber::before  { background: var(--pk-amber); }
.pk01-kpi-card.c-rose   { background: #ffffff; }
.pk01-kpi-card.c-rose::before   { background: var(--pk-rose); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 22px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Grid Forms */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
}
.pk01-form-group { display: flex; flex-direction: column; gap: 6px; }
.pk01-form-group label { font-size: 12.5px; font-weight: 700; color: var(--pk-slate-700); }
.pk01-ctrl {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13.5px;
    background: #ffffff;
    transition: all 0.2s ease;
}
.pk01-ctrl:focus {
    outline: none;
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Real-Time Live Calculation Banners */
.pk01-live-calc-box {
    background: linear-gradient(135deg, #ecfdf5 0%, #f0fdf4 100%);
    border: 1px dashed #86efac;
    border-radius: 12px;
    padding: 14px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 16px;
}
.pk01-live-calc-box span { font-size: 12.5px; color: #166534; font-weight: 600; }
.pk01-live-calc-box strong {
    font-size: 18px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    color: #14532d;
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

/* Progress Bar Depresiasi */
.pk01-progress-bg {
    width: 100%;
    max-width: 130px;
    background: #e2e8f0;
    height: 7px;
    border-radius: 4px;
    overflow: hidden;
    margin-top: 5px;
}
.pk01-progress-fill {
    background: linear-gradient(90deg, #f59e0b, #d97706);
    height: 100%;
    border-radius: 4px;
}

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 9px 16px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
.pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-danger  { background: var(--pk-rose); color: #ffffff !important; }
.pk01-btn-danger:hover { background: #dc2626; }
.pk01-btn-sm { padding: 4px 10px; font-size: 11.5px; border-radius: 6px; }

.pk01-money {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    color: #0f172a;
}
.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 11.5px;
}

.pk01-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-alert.is-error   { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }
</style>

<div class="pk01-inv-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-inv-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">INVENTORY &bull; CAPITAL ASSETS CONTROL</span>
            <h1>📦 Input Inventori &amp; Aset Investasi</h1>
            <p>
                Pemisahan tegas akuntansi: <strong>Persediaan Masuk</strong> (aktiva lancar yang baru menjadi HPP saat terjual) vs 
                <strong>Aset Tetap</strong> (investasi mesin/kendaraan yang diamortisasi berkala tanpa memotong laba instan).
            </p>
        </div>
        <div class="pk01-status-pill">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>STANDAR AKUNTANSI AKTIF</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                Audit: <b>Pemisahan CapEx &amp; Persediaan</b>
            </div>
        </div>
    </header>

    <?php if ($msg): ?><div class="pk01-alert is-success">✅ <?php echo esc_html($msg); ?></div><?php endif; ?>
    <?php if ($err): ?><div class="pk01-alert is-error">❌ <?php echo esc_html($err); ?></div><?php endif; ?>

    <!-- 2. EXECUTIVE 4 KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-green">
            <div class="pk01-kpi-label">Valuasi Persediaan Bahan</div>
            <div class="pk01-kpi-val" style="color:#059669;">Rp <?php echo number_format($total_inventory_val, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Total stok fisik &times; harga pokok</div>
        </div>

        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Total Belanja Aset (CapEx)</div>
            <div class="pk01-kpi-val" style="color:#4f46e5;">Rp <?php echo number_format($total_asset_capex, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Investasi mesin, kendaraan &amp; alat</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Nilai Buku Bersih (NBV)</div>
            <div class="pk01-kpi-val" style="color:#d97706;">Rp <?php echo number_format($total_asset_book, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Setelah dikurangi akumulasi susut</div>
        </div>

        <div class="pk01-kpi-card c-rose">
            <div class="pk01-kpi-label">Write-Down Bulan Ini</div>
            <div class="pk01-kpi-val" style="color:#dc2626;">Rp <?php echo number_format($month_write_down, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Kerugian bahan rusak / usang</div>
        </div>
    </section>

    <!-- 3. TABS NAVIGASI WORKFLOW -->
    <nav class="pk01-nav-tabs" aria-label="Navigasi Inventori dan Aset">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-receipt">
            📦 Penerimaan Bahan Baku
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-asset">
            🏭 Pembelian Mesin &amp; Aset Tetap
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-writedown">
            📉 Penurunan Nilai (Write-Down)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-register">
            📋 Register Aset Tetap (<?php echo count($assets); ?>)
        </button>
    </nav>

    <!-- 4. TAB 1: PENERIMAAN PERSEDIAAN MASUK -->
    <div class="pk01-pane is-active" id="tab-receipt">
        <section class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📦 Catat Persediaan Masuk / Restock Bahan Baku</h3>
                    <div class="pk01-surface-desc">
                        Stok gudang otomatis bertambah. Pembelian bahan baku tidak langsung memotong laba bersih, melainkan dicatat sebagai persediaan sampai terjual dalam pekerjaan produksi.
                    </div>
                </div>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('pk01_inv_action', 'pk01_inv_nonce'); ?>
                <input type="hidden" name="pk01_inv_action" value="receipt">

                <div class="pk01-form-grid">
                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Pilih Bahan Baku <span style="color:#ef4444;">*</span></label>
                        <select name="material_id" id="rcpt_material_select" class="pk01-ctrl" required>
                            <option value="">-- Pilih Bahan di Gudang --</option>
                            <?php foreach ($materials as $m): ?>
                                <option value="<?php echo (int)$m->id; ?>" 
                                        data-cost="<?php echo esc_attr($m->cost ?? 0); ?>"
                                        data-unit="<?php echo esc_attr($m->unit ?? 'pcs'); ?>"
                                        data-stock="<?php echo esc_attr($m->stock ?? 0); ?>">
                                    <?php echo esc_html($m->name); ?> (Stok: <?php echo esc_html($m->stock); ?> <?php echo esc_html($m->unit ?? 'pcs'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-form-group">
                        <label>Kuantitas Masuk <span style="color:#ef4444;">*</span> <span id="rcpt_unit_badge" style="font-size:11px;color:#64748b;">(Unit)</span></label>
                        <input name="qty" id="rcpt_qty" type="number" step="0.0001" min="0.0001" class="pk01-ctrl" placeholder="Contoh: 10" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Harga Pokok Satuan (Rp) <span style="color:#ef4444;">*</span></label>
                        <input name="unit_cost" id="rcpt_cost" type="number" step="0.01" min="0" class="pk01-ctrl" placeholder="Contoh: 150000" required>
                    </div>

                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>No. Faktur / Referensi Supplier</label>
                        <input name="notes" class="pk01-ctrl" placeholder="No. Invoice vendor, supplier, atau catatan penerimaan...">
                    </div>

                    <div class="pk01-form-group" style="justify-content:center;">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin-top:20px;">
                            <input type="checkbox" name="paid" value="1" checked style="width:16px; height:16px;">
                            <span style="font-weight:700; font-size:13px;">Dibayar Sekarang (Potong Kas)</span>
                        </label>
                    </div>
                </div>

                <!-- LIVE SUB-TOTAL KALKULATOR -->
                <div class="pk01-live-calc-box">
                    <span>Estimasi Total Nilai Pembelian Masuk:</span>
                    <strong id="rcpt_total_preview">Rp 0</strong>
                </div>

                <div style="margin-top:18px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        📥 Simpan &amp; Tambah Persediaan
                    </button>
                </div>
            </form>
        </section>
    </div>

    <!-- 5. TAB 2: PEMBELIAN MESIN / ASET TETAP -->
    <div class="pk01-pane" id="tab-asset">
        <section class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🏭 Belanja Modal &amp; Pembelian Aset Tetap (CapEx)</h3>
                    <div class="pk01-surface-desc">
                        Biaya perolehan aset tetap masuk ke neraca aktiva dan saldo kas terpotong. Beban diserap secara akrual melalui depresiasi periodik.
                    </div>
                </div>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('pk01_inv_action', 'pk01_inv_nonce'); ?>
                <input type="hidden" name="pk01_inv_action" value="asset">

                <div class="pk01-form-grid">
                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Nama Aset / Mesin / Kendaraan <span style="color:#ef4444;">*</span></label>
                        <input name="asset_name" class="pk01-ctrl" placeholder="Contoh: Mesin CNC Router / Mobil Operasional GrandMax" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Tanggal Pembelian</label>
                        <input name="purchase_date" type="date" class="pk01-ctrl" value="<?php echo esc_attr(current_time('Y-m-d')); ?>">
                    </div>

                    <div class="pk01-form-group">
                        <label>Harga Perolehan Pembelian (Rp) <span style="color:#ef4444;">*</span></label>
                        <input name="asset_cost" id="ast_cost" type="number" step="0.01" min="0.01" class="pk01-ctrl" placeholder="30000000" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Masa Manfaat (Bulan) <span style="color:#ef4444;">*</span></label>
                        <input name="useful_life" id="ast_life" type="number" min="1" class="pk01-ctrl" value="60" placeholder="Contoh: 60 (5 Tahun)" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Estimasi Nilai Residu / Sisa (Rp)</label>
                        <input name="residual_value" id="ast_res" type="number" step="0.01" min="0" value="0" class="pk01-ctrl" placeholder="0">
                    </div>
                </div>

                <!-- LIVE DEPRECIATION CALCULATION PREVIEW -->
                <div class="pk01-live-calc-box">
                    <span>Estimasi Beban Penyusutan per Bulan (Non-Kas):</span>
                    <strong id="ast_monthly_preview" style="color:#4f46e5;">Rp 0 / bulan</strong>
                </div>

                <div style="margin-top:18px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        💾 Simpan &amp; Kapitalisasi Aset Tetap
                    </button>
                </div>
            </form>
        </section>
    </div>

    <!-- 6. TAB 3: PENURUNAN NILAI PERSEDIAAN (WRITE-DOWN) -->
    <div class="pk01-pane" id="tab-writedown">
        <section class="pk01-surface" style="border-left:4px solid #ef4444;">
            <div class="pk01-surface-header">
                <div>
                    <h3 style="color:#b91c1c;">📉 Penurunan Nilai Persediaan (Write-Down)</h3>
                    <div class="pk01-surface-desc">
                        Persediaan barang tidak disusutkan berkala seperti mesin. Gunakan formulir ini bila bahan baku rusak, usang, atau mengalami penurunan harga pasar wajar tanpa kas keluar fisik.
                    </div>
                </div>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('pk01_inv_action', 'pk01_inv_nonce'); ?>
                <input type="hidden" name="pk01_inv_action" value="write_down">

                <div class="pk01-form-grid">
                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Pilih Bahan yang Mengalami Penurunan <span style="color:#ef4444;">*</span></label>
                        <select name="material_id" class="pk01-ctrl" required>
                            <option value="">-- Pilih Bahan Baku --</option>
                            <?php foreach ($materials as $m): ?>
                                <option value="<?php echo (int)$m->id; ?>">
                                    <?php echo esc_html($m->name); ?> (Stok Saat Ini: <?php echo esc_html($m->stock); ?> <?php echo esc_html($m->unit ?? 'pcs'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="pk01-form-group">
                        <label>Nominal Penurunan Nilai (Rp) <span style="color:#ef4444;">*</span></label>
                        <input name="write_down" type="number" step="0.01" min="0.01" class="pk01-ctrl" placeholder="Contoh: 250000" required>
                    </div>

                    <div class="pk01-form-group" style="grid-column: 1 / -1;">
                        <label>Alasan / Penyebab Kerusakan <span style="color:#ef4444;">*</span></label>
                        <input name="reason" class="pk01-ctrl" placeholder="Contoh: Kayu melengkung / basah / cacat pabrik" required>
                    </div>
                </div>

                <div style="margin-top:18px;">
                    <button class="pk01-btn pk01-btn-danger" type="submit">
                        📉 Catat Penurunan Nilai (Write-Down)
                    </button>
                </div>
            </form>
        </section>
    </div>

    <!-- 7. TAB 4: REGISTER ASET TETAP & DEPRESIASI -->
    <div class="pk01-pane" id="tab-register">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📋 Register Aset Tetap &amp; Posting Depresiasi Bulanan</h3>
                    <div class="pk01-surface-desc">
                        Pembebanan depresiasi mencatatkan beban non-kas ke Laporan Laba Rugi tanpa kas keluar baru.
                    </div>
                </div>

                <div>
                    <input type="search" id="pk01_asset_tbl_search" class="pk01-ctrl" placeholder="🔍 Cari nama/kode aset..." style="width:230px; font-size:12px; padding:7px 12px;">
                </div>
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl" id="pk01_asset_tbl">
                    <thead>
                        <tr>
                            <th style="width:130px;">Kode Aset</th>
                            <th>Nama Aktiva</th>
                            <th style="text-align:right;">Harga Perolehan</th>
                            <th style="text-align:right;">Akumulasi Susut</th>
                            <th style="text-align:right;">Nilai Buku (NBV)</th>
                            <th style="text-align:center;">Umur</th>
                            <th>Tgl Beli</th>
                            <th style="text-align:center; width:150px;">Posting Depresiasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($assets)): ?>
                            <tr>
                                <td colspan="8" style="text-align:center; padding:32px; color:#94a3b8;">
                                    Belum ada aset tetap yang tercatat di register.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($assets as $a): 
                                $cost = (float)($a->purchase_cost ?? 0);
                                $acc  = (float)($a->accumulated ?? 0);
                                $book = max(0, $cost - $acc);
                                $depreciable_base = max(1, $cost - (float)($a->residual_value ?? 0));
                                $pct = min(100, max(0, ($acc / $depreciable_base) * 100));
                            ?>
                                <tr>
                                    <td><span class="pk01-code-badge"><?php echo esc_html($a->asset_code); ?></span></td>
                                    <td><strong><?php echo esc_html($a->name); ?></strong></td>
                                    <td style="text-align:right;"><span class="pk01-money">Rp <?php echo number_format($cost, 0, ',', '.'); ?></span></td>
                                    <td style="text-align:right;">
                                        <span class="pk01-money" style="color:#d97706;">Rp <?php echo number_format($acc, 0, ',', '.'); ?></span>
                                        <div class="pk01-progress-bg" title="Tersusutkan: <?php echo number_format($pct, 1); ?>%">
                                            <div class="pk01-progress-fill" style="width:<?php echo $pct; ?>%;"></div>
                                        </div>
                                    </td>
                                    <td style="text-align:right;"><span class="pk01-money" style="color:#059669; font-size:13.5px;">Rp <?php echo number_format($book, 0, ',', '.'); ?></span></td>
                                    <td style="text-align:center; font-size:12px;"><?php echo (int)($a->useful_life_months ?? 0); ?> bln</td>
                                    <td style="font-size:12px; color:#64748b;"><?php echo esc_html(date_i18n('d M Y', strtotime($a->purchase_date))); ?></td>
                                    <td style="text-align:center;">
                                        <form method="post" style="margin:0;" onsubmit="return confirm('Posting penyusutan bulan ini untuk aset <?php echo esc_js($a->name); ?>? Tindakan ini mencatat beban ke Laba Rugi tanpa kas keluar.');">
                                            <?php wp_nonce_field('pk01_inv_action', 'pk01_inv_nonce'); ?>
                                            <input type="hidden" name="pk01_inv_action" value="depreciate">
                                            <input type="hidden" name="asset_id" value="<?php echo (int)$a->id; ?>">
                                            <button class="pk01-btn pk01-btn-primary pk01-btn-sm" type="submit">
                                                Post Bulan Ini
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH URL
    const tabBtns = document.querySelectorAll('.pk01-tab-btn');
    const tabPanes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabBtns.forEach(b => b.classList.remove('is-active'));
            tabPanes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. AUTO-POPULATE HPP & LIVE SUB-TOTAL KALKULATOR PENERIMAAN
    const matSelect   = document.getElementById('rcpt_material_select');
    const rcptQty     = document.getElementById('rcpt_qty');
    const rcptCost    = document.getElementById('rcpt_cost');
    const rcptPreview = document.getElementById('rcpt_total_preview');
    const unitBadge   = document.getElementById('rcpt_unit_badge');

    if (matSelect) {
        matSelect.addEventListener('change', function() {
            const opt = this.options[this.selectedIndex];
            if (opt && opt.value) {
                const defaultCost = opt.dataset.cost || 0;
                const unitName    = opt.dataset.unit || 'pcs';
                
                if (rcptCost && (!rcptCost.value || parseFloat(rcptCost.value) === 0)) {
                    rcptCost.value = defaultCost;
                }
                if (unitBadge) {
                    unitBadge.textContent = '(' + unitName + ')';
                }
            }
            updateReceiptSubtotal();
        });
    }

    function updateReceiptSubtotal() {
        const q = parseFloat(rcptQty?.value) || 0;
        const c = parseFloat(rcptCost?.value) || 0;
        const total = q * c;
        if (rcptPreview) {
            rcptPreview.textContent = 'Rp ' + Math.round(total).toLocaleString('id-ID');
        }
    }

    if (rcptQty && rcptCost) {
        rcptQty.addEventListener('input', updateReceiptSubtotal);
        rcptCost.addEventListener('input', updateReceiptSubtotal);
    }

    // 3. LIVE DEPRECIATION KALKULATOR ASET
    const astCost    = document.getElementById('ast_cost');
    const astLife    = document.getElementById('ast_life');
    const astRes     = document.getElementById('ast_res');
    const astPreview = document.getElementById('ast_monthly_preview');

    function updateAssetMonthlyPreview() {
        const cost = parseFloat(astCost?.value) || 0;
        const life = parseInt(astLife?.value) || 1;
        const res  = parseFloat(astRes?.value) || 0;

        const base = Math.max(0, cost - res);
        const monthly = life > 0 ? (base / life) : 0;

        if (astPreview) {
            astPreview.textContent = 'Rp ' + Math.round(monthly).toLocaleString('id-ID') + ' / bulan';
        }
    }

    if (astCost && astLife && astRes) {
        astCost.addEventListener('input', updateAssetMonthlyPreview);
        astLife.addEventListener('input', updateAssetMonthlyPreview);
        astRes.addEventListener('input', updateAssetMonthlyPreview);
    }

    // 4. INSTANT SEARCH REGISTER ASET TETAP
    const assetSearch = document.getElementById('pk01_asset_tbl_search');
    const assetTable  = document.getElementById('pk01_asset_tbl');

    if (assetSearch && assetTable) {
        assetSearch.addEventListener('input', function() {
            const q = this.value.toLowerCase().trim();
            const rows = assetTable.querySelectorAll('tbody tr');
            rows.forEach(r => {
                r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
            });
        });
    }
});
</script>