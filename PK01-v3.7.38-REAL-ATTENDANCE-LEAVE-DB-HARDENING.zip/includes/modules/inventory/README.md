# PK01 — Modul Inventory

Folder canonical: `includes/modules/inventory/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/inventory/assets/tampilan-aset-inventory.php`
- `includes/modules/inventory/management/tampilan-inventory-management.php`
- `includes/modules/inventory/materials/tampilan-bahan.php`
- `includes/modules/inventory/products/tampilan-produk.php`
- `includes/modules/inventory/stock/tampilan-stok.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
