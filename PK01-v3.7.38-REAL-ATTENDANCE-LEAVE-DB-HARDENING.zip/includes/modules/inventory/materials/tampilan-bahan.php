<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin     = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage   = $is_admin || (class_exists('PK01_Authorization') && PK01_Authorization::can('inventory'));

if (!$can_manage) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🚫</div>
            <strong style="font-size:16px;">Akses Dibatasi</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin otorisasi untuk mengelola master bahan baku gudang.</p>
          </div>';
    return;
}

$notice = '';

// Helper URL Aman Lintas Modul
$url_helper = function($slug) {
    if (class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')) {
        return PK01_Shortcodes::frontend_url_public($slug);
    }
    return add_query_arg('pk01_view', $slug, home_url('/'));
};

$current_page_url = remove_query_arg(['edit_id', 'action', '_wpnonce']);
$receipt_hub_url  = $url_helper('inventory') . '#tab-receipt';

// Helper Deteksi Tabel Resmi
$tbl_materials = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('materials') : $wpdb->prefix . 'pk01_materials';
$tbl_suppliers = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('suppliers') : $wpdb->prefix . 'pk01_suppliers';

// 2. EKSPOR DATA BAHAN BAKU KE CSV (AUDIT PERSEDIAAN)
if (isset($_POST['pk01_export_materials_csv']) && check_admin_referer('pk01_export_materials_nonce')) {
    if ($can_manage) {
        $export_rows = $wpdb->get_results("
            SELECT m.*, COALESCE(s.name, '—') AS supplier_name 
            FROM `{$tbl_materials}` m 
            LEFT JOIN `{$tbl_suppliers}` s ON s.id = m.supplier_id 
            ORDER BY m.id DESC
        ", ARRAY_A);

        if (!empty($export_rows)) {
            $filename = 'pk01-materials-inventory-' . current_time('Y-m-d-His') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Kode Bahan', 'Nama Bahan Baku', 'Satuan', 'Harga Pokok (Rp)', 'Stok Saat Ini', 'Stok Minimum', 'Total Valuasi (Rp)', 'Pemasok / Vendor']);
            foreach ($export_rows as $r) {
                $stk = (float)($r['stock'] ?? 0);
                $cst = (float)($r['cost'] ?? 0);
                fputcsv($out, [
                    $r['code'],
                    $r['name'],
                    $r['unit'],
                    $cst,
                    $stk,
                    (float)($r['min_stock'] ?? 0),
                    $stk * $cst,
                    $r['supplier_name']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. PROSES SIMPAN / EDIT BAHAN BAKU
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_material_action'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_material_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_material_save')) {
        $notice = '<div class="pk01-alert is-error">Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        try {
            $id          = absint($_POST['material_id'] ?? 0);
            $code        = strtoupper(sanitize_text_field(wp_unslash($_POST['code'] ?? '')));
            $name        = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
            $unit        = sanitize_text_field(wp_unslash($_POST['unit'] ?? 'pcs'));
            $cost        = (float) sanitize_text_field(wp_unslash($_POST['cost'] ?? 0));
            $min_stock   = (float) sanitize_text_field(wp_unslash($_POST['min_stock'] ?? 0));
            $supplier_id = absint($_POST['supplier_id'] ?? 0);

            if (empty($name)) {
                throw new Exception('Nama bahan baku wajib diisi.');
            }

            if ($id > 0) {
                // Update Bahan
                $wpdb->update($tbl_materials, [
                    'code'        => $code,
                    'name'        => $name,
                    'unit'        => $unit,
                    'cost'        => $cost,
                    'min_stock'   => $min_stock,
                    'supplier_id' => $supplier_id,
                    'updated_at'  => current_time('mysql')
                ], ['id' => $id]);
                $notice = '<div class="pk01-alert is-success">✅ Data bahan baku <strong>' . esc_html($name) . '</strong> berhasil diperbarui.</div>';
            } else {
                // Create Bahan Baru
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'create_material')) {
                    PK01_Engine::create_material($code, $name, $unit, $cost, $min_stock, $supplier_id);
                } else {
                    $wpdb->insert($tbl_materials, [
                        'code'        => $code,
                        'name'        => $name,
                        'unit'        => $unit,
                        'cost'        => $cost,
                        'stock'       => 0,
                        'min_stock'   => $min_stock,
                        'supplier_id' => $supplier_id,
                        'created_at'  => current_time('mysql')
                    ]);
                }
                $notice = '<div class="pk01-alert is-success">✅ Bahan baku baru <strong>' . esc_html($name) . '</strong> berhasil didaftarkan ke gudang.</div>';
            }
        } catch (Throwable $e) {
            $notice = '<div class="pk01-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// Mode Edit
$edit_id = absint($_GET['edit_id'] ?? 0);
$edit_item = null;
if ($edit_id > 0) {
    $edit_item = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_materials}` WHERE id = %d", $edit_id), ARRAY_A);
}

// 4. AMBIL DATA BAHAN & PEMASOK
$rows = $wpdb->get_results("
    SELECT m.*, COALESCE(s.name, '—') AS supplier_name 
    FROM `{$tbl_materials}` m 
    LEFT JOIN `{$tbl_suppliers}` s ON s.id = m.supplier_id 
    ORDER BY m.id DESC 
    LIMIT 400
", ARRAY_A) ?: [];

$suppliers = $wpdb->get_results("SELECT id, name FROM `{$tbl_suppliers}` WHERE status = 'active' ORDER BY name ASC", ARRAY_A) ?: [];

// 5. METRIK DAN STATISTIK REAL
$total_items       = count($rows);
$low_stock         = 0;
$out_of_stock      = 0;
$safe_stock        = 0;
$total_asset_value = 0;

foreach ($rows as $r) {
    $stk = (float) ($r['stock'] ?? 0);
    $min = (float) ($r['min_stock'] ?? 0);
    $cst = (float) ($r['cost'] ?? 0);

    $total_asset_value += ($stk * $cst);

    if ($stk <= 0) {
        $out_of_stock++;
        $low_stock++;
    } elseif ($stk <= $min) {
        $low_stock++;
    } else {
        $safe_stock++;
    }
}

if (!function_exists('pk01_format_qty')) {
    function pk01_format_qty($qty) {
        return rtrim(rtrim(number_format((float)$qty, 2, ',', '.'), '0'), ',');
    }
}

$mat_prefix = get_option('pk01_material_prefix', 'MAT');
$suggested_code = $mat_prefix . '-' . str_pad((string)($total_items + 1), 4, '0', STR_PAD_LEFT);
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-mat-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-mat-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Header */
.pk01-mat-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #064e3b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(16, 185, 129, 0.25);
    border: 1px solid rgba(110, 231, 183, 0.35);
    color: #6ee7b7;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 4 KPI Cards */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-blue::before  { background: var(--pk-indigo); }
.pk01-kpi-card.c-green::before { background: var(--pk-emerald); }
.pk01-kpi-card.c-amber::before { background: var(--pk-amber); }
.pk01-kpi-card.c-dark::before  { background: var(--pk-slate-900); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 22px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover {
    background: var(--pk-slate-100);
    color: var(--pk-slate-900);
}
.pk01-tab-btn.is-active {
    background: var(--pk-slate-900);
    color: #ffffff;
}

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Form Controls */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 16px;
}
.pk01-form-group { display: flex; flex-direction: column; gap: 6px; }
.pk01-form-group label { font-size: 12.5px; font-weight: 700; color: var(--pk-slate-700); }
.pk01-ctrl {
    width: 100%;
    padding: 9px 13px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13.5px;
    background: #ffffff;
    transition: all 0.2s ease;
}
.pk01-ctrl:focus {
    outline: none;
    border-color: var(--pk-indigo);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}

/* Quick Unit Pills */
.pk01-unit-pills {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 6px;
}
.pk01-pill-unit {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 600;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill-unit:hover {
    background: var(--pk-indigo);
    color: #ffffff;
    border-color: var(--pk-indigo);
}

/* Tables */
.pk01-table-card {
    overflow-x: auto;
    border: 1px solid var(--pk-slate-200);
    border-radius: 12px;
}
.pk01-tbl {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-tbl th {
    background: #f8fafc;
    padding: 12px 14px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-slate-200);
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}
.pk01-tbl td {
    padding: 12px 14px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-tbl tr:hover td { background: #fbfcfe; }

/* Filter Bar */
.pk01-filter-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 16px;
}
.pk01-chip-btn {
    padding: 6px 14px;
    border-radius: 20px;
    border: 1px solid #cbd5e1;
    background: #ffffff;
    font-size: 12px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-chip-btn.active {
    background: var(--pk-slate-900);
    color: #ffffff;
    border-color: var(--pk-slate-900);
}

/* Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 9px 16px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-primary { background: var(--pk-indigo); color: #ffffff !important; }
.pk01-btn-primary:hover { background: var(--pk-indigo-hover); }
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
.pk01-btn-emerald:hover { background: #059669; }
.pk01-btn-sm { padding: 4px 10px; font-size: 11.5px; border-radius: 6px; }

.pk01-code-badge {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #e2e8f0;
    color: #0f172a;
    font-size: 11.5px;
}
.pk01-money {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    color: #0f172a;
}

.pk01-badge-stk {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.badge-habis   { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.badge-menipis { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.badge-aman    { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }

.pk01-alert {
    padding: 14px 18px;
    border-radius: 10px;
    font-size: 13.5px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
}
.pk01-alert.is-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk01-alert.is-error   { background: #fff1f2; border: 1px solid #fecdd3; color: #9f1239; }
</style>

<div class="pk01-mat-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-mat-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">RAW MATERIALS &bull; WAREHOUSE CORE</span>
            <h1>🪵 Master Bahan Baku &amp; Persediaan Gudang</h1>
            <p>
                Sentralisasi stok fisik bahan baku, ambang batas *buffer stock*, HPP perolehan, dan relasi pemasok. Terhubung otomatis ke pemotongan bahan pada Surat Perintah Kerja (SPK) lantai produksi.
            </p>
        </div>
        <div class="pk01-status-pill">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>WAREHOUSE ENGINE SYNCED</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                Total Stok: <b><?php echo number_format($total_items); ?> SKU Bahan</b>
            </div>
        </div>
    </header>

    <?php if ($notice) echo $notice; ?>

    <!-- 2. EXECUTIVE 4 KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Total Jenis Material</div>
            <div class="pk01-kpi-val"><?php echo number_format($total_items); ?></div>
            <div class="pk01-kpi-sub">Terdaftar di master gudang aktif</div>
        </div>

        <div class="pk01-kpi-card c-green">
            <div class="pk01-kpi-label">Stok Status Aman</div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo number_format($safe_stock); ?></div>
            <div class="pk01-kpi-sub">Stok fisik di atas batas minimum</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Perlu Restock / Kritis</div>
            <div class="pk01-kpi-val" style="color:#d97706;"><?php echo number_format($low_stock); ?></div>
            <div class="pk01-kpi-sub"><?php echo number_format($out_of_stock); ?> bahan bersaldo kosong (0)</div>
        </div>

        <div class="pk01-kpi-card c-dark">
            <div class="pk01-kpi-label">Total Valuasi Aset Gudang</div>
            <div class="pk01-kpi-val" style="color:#0f172a;">Rp <?php echo number_format($total_asset_value, 0, ',', '.'); ?></div>
            <div class="pk01-kpi-sub">Nilai persediaan (Stok &times; HPP)</div>
        </div>
    </section>

    <!-- 3. TABS NAVIGASI WORKFLOW -->
    <nav class="pk01-nav-tabs" aria-label="Menu Bahan Baku">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-catalog">
            📋 Katalog Bahan Baku (<?php echo count($rows); ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-create">
            <?php echo $edit_item ? '✏️ Edit Bahan: ' . esc_html($edit_item['name']) : '➕ Tambah Bahan Baru'; ?>
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-critical">
            🚨 Radar Restock Kritis (<?php echo (int)$low_stock; ?>)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-ecosystem">
            🔗 Integrasi Alur Kerja (BOM &amp; SPK)
        </button>
    </nav>

    <!-- 4. TAB 1: KATALOG BAHAN BAKU -->
    <div class="pk01-pane is-active" id="tab-catalog">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📋 Katalog Inventori &amp; Valuasi Bahan Baku</h3>
                    <div class="pk01-surface-desc">
                        Stok gudang disinkronkan secara otomatis saat penerimaan bahan masuk atau pemotongan bahan pada SPK job produksi.
                    </div>
                </div>

                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('pk01_export_materials_nonce'); ?>
                        <input type="hidden" name="pk01_export_materials_csv" value="1">
                        <button type="submit" class="pk01-btn pk01-btn-subtle" title="Unduh data stok ke file CSV">
                            📥 Ekspor CSV
                        </button>
                    </form>
                    <a href="<?php echo esc_url($receipt_hub_url); ?>" class="pk01-btn pk01-btn-emerald">
                        📦 + Penerimaan Bahan Masuk &rarr;
                    </a>
                </div>
            </div>

            <!-- FILTER BAR -->
            <div class="pk01-filter-bar">
                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                    <button type="button" class="pk01-chip-btn active" data-filter="all">Semua (<?php echo (int)$total_items; ?>)</button>
                    <button type="button" class="pk01-chip-btn" data-filter="menipis" style="color:#d97706;">Perlu Restock (<?php echo (int)$low_stock; ?>)</button>
                    <button type="button" class="pk01-chip-btn" data-filter="habis" style="color:#dc2626;">Stok Kosong (<?php echo (int)$out_of_stock; ?>)</button>
                    <button type="button" class="pk01-chip-btn" data-filter="aman" style="color:#059669;">Stok Aman (<?php echo (int)$safe_stock; ?>)</button>
                </div>
                
                <div>
                    <input type="search" id="pk01_search_material" class="pk01-ctrl" placeholder="🔍 Cari nama, kode, pemasok..." style="width:260px; font-size:12px; padding:7px 12px;">
                </div>
            </div>

            <!-- TABEL REGISTER BAHAN -->
            <div class="pk01-table-card">
                <table class="pk01-tbl" id="pk01_materials_tbl">
                    <thead>
                        <tr>
                            <th style="width:110px;">Kode</th>
                            <th>Nama Bahan Baku</th>
                            <th style="width:110px; text-align:center;">Status</th>
                            <th style="text-align:right; width:130px;">Stok Fisik</th>
                            <th style="text-align:right; width:110px;">Min. Stok</th>
                            <th style="width:80px;">Satuan</th>
                            <th style="text-align:right; width:130px;">HPP Standar</th>
                            <th style="text-align:right; width:140px;">Total Valuasi</th>
                            <th>Pemasok Utama</th>
                            <th style="text-align:center; width:100px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($rows)): foreach ($rows as $r): 
                            $stk      = (float)($r['stock'] ?? 0);
                            $min      = (float)($r['min_stock'] ?? 0);
                            $cost     = (float)($r['cost'] ?? 0);
                            $subtotal = $stk * $cost;

                            if ($stk <= 0) {
                                $status_key = 'habis';
                                $badge = '<span class="pk01-badge-stk badge-habis">● Kosong (0)</span>';
                            } elseif ($stk <= $min) {
                                $status_key = 'menipis';
                                $badge = '<span class="pk01-badge-stk badge-menipis">● Menipis</span>';
                            } else {
                                $status_key = 'aman';
                                $badge = '<span class="pk01-badge-stk badge-aman">● Aman</span>';
                            }

                            $edit_url = add_query_arg('edit_id', (int)$r['id'], $current_page_url) . '#tab-create';
                        ?>
                        <tr data-status="<?php echo esc_attr($status_key); ?>">
                            <td>
                                <span class="pk01-code-badge"><?php echo esc_html($r['code']); ?></span>
                            </td>
                            <td>
                                <strong style="color:#0f172a; font-size:13.5px;"><?php echo esc_html($r['name']); ?></strong>
                            </td>
                            <td style="text-align:center;"><?php echo $badge; ?></td>
                            <td style="text-align:right; font-weight:800; font-size:14px; font-family:ui-monospace, monospace; <?php echo ($stk <= $min) ? 'color:#dc2626;' : 'color:#0f172a;'; ?>">
                                <?php echo esc_html(pk01_format_qty($stk)); ?>
                            </td>
                            <td style="text-align:right; color:#64748b; font-family:ui-monospace, monospace;">
                                <?php echo esc_html(pk01_format_qty($min)); ?>
                            </td>
                            <td><span class="pk01-code-badge" style="background:#fff;"><?php echo esc_html($r['unit']); ?></span></td>
                            <td style="text-align:right;">
                                <span class="pk01-money">Rp <?php echo number_format($cost, 0, ',', '.'); ?></span>
                            </td>
                            <td style="text-align:right;">
                                <span class="pk01-money" style="color:#059669;">Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></span>
                            </td>
                            <td>
                                <span style="font-size:12px; color:#475569;"><?php echo esc_html($r['supplier_name']); ?></span>
                            </td>
                            <td style="text-align:center;">
                                <a href="<?php echo esc_url($edit_url); ?>" class="pk01-btn pk01-btn-subtle pk01-btn-sm" title="Edit bahan">
                                    ✏️ Edit
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="10" style="text-align:center; padding:36px; color:#94a3b8;">Belum ada master bahan baku tersimpan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 5. TAB 2: TAMBAH / EDIT BAHAN BAKU -->
    <div class="pk01-pane" id="tab-create">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3><?php echo $edit_item ? '✏️ Perbarui Master Bahan: ' . esc_html($edit_item['name']) : '➕ Tambah Master Bahan Baku Baru'; ?></h3>
                    <div class="pk01-surface-desc">
                        Tentukan harga pokok standar dan ambang batas minimum notifikasi pengadaan barang.
                    </div>
                </div>
                <?php if ($edit_item): ?>
                    <a href="<?php echo esc_url($current_page_url); ?>#tab-catalog" style="font-size:12px; color:#ef4444; font-weight:700; text-decoration:none;">
                        ✕ Batal Edit
                    </a>
                <?php endif; ?>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field('pk01_material_save', 'pk01_material_nonce'); ?>
                <input type="hidden" name="pk01_material_action" value="save_material">
                <input type="hidden" name="material_id" value="<?php echo (int)($edit_item['id'] ?? 0); ?>">

                <div class="pk01-form-grid">
                    <div class="pk01-form-group">
                        <label>Kode Bahan Baku</label>
                        <input name="code" class="pk01-ctrl" value="<?php echo esc_attr($edit_item['code'] ?? $suggested_code); ?>" required placeholder="Contoh: PLY-12MM">
                    </div>

                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Nama Bahan Baku <span style="color:#ef4444;">*</span></label>
                        <input name="name" class="pk01-ctrl" value="<?php echo esc_attr($edit_item['name'] ?? ''); ?>" placeholder="Contoh: Plywood Meranti Tebal 12mm Grade A" required>
                    </div>

                    <div class="pk01-form-group">
                        <label>Satuan Satuan Stok (Unit) <span style="color:#ef4444;">*</span></label>
                        <input name="unit" id="pk01_unit_input" class="pk01-ctrl" value="<?php echo esc_attr($edit_item['unit'] ?? 'pcs'); ?>" required>
                        <div class="pk01-unit-pills">
                            <span class="pk01-pill-unit" data-unit="pcs">pcs</span>
                            <span class="pk01-pill-unit" data-unit="lembar">lembar</span>
                            <span class="pk01-pill-unit" data-unit="kg">kg</span>
                            <span class="pk01-pill-unit" data-unit="meter">meter</span>
                            <span class="pk01-pill-unit" data-unit="batang">batang</span>
                            <span class="pk01-pill-unit" data-unit="roll">roll</span>
                            <span class="pk01-pill-unit" data-unit="liter">liter</span>
                            <span class="pk01-pill-unit" data-unit="box">box</span>
                        </div>
                    </div>

                    <div class="pk01-form-group">
                        <label>Harga Pokok Satuan / HPP Standar (Rp)</label>
                        <input type="number" step="any" min="0" name="cost" class="pk01-ctrl" value="<?php echo esc_attr($edit_item['cost'] ?? 0); ?>" placeholder="0">
                    </div>

                    <div class="pk01-form-group">
                        <label>Batas Minimum Alert (Warning Restock)</label>
                        <input type="number" step="any" min="0" name="min_stock" class="pk01-ctrl" value="<?php echo esc_attr($edit_item['min_stock'] ?? 5); ?>" placeholder="5">
                    </div>

                    <div class="pk01-form-group" style="grid-column: span 2;">
                        <label>Pemasok Utama (Vendor Supplier Rekanan)</label>
                        <select name="supplier_id" class="pk01-ctrl">
                            <option value="0">— Tanpa Pemasok Utama —</option>
                            <?php foreach ($suppliers as $sp): ?>
                                <option value="<?php echo (int)$sp['id']; ?>" <?php selected((int)($edit_item['supplier_id'] ?? 0), (int)$sp['id']); ?>>
                                    <?php echo esc_html($sp['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div style="margin-top:20px; display:flex; gap:10px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit" style="padding:10px 24px;">
                        <?php echo $edit_item ? '💾 Simpan Perubahan Bahan' : '💾 Daftarkan Bahan Baku'; ?>
                    </button>
                    <?php if ($edit_item): ?>
                        <a href="<?php echo esc_url($current_page_url); ?>#tab-catalog" class="pk01-btn pk01-btn-subtle">
                            Batal
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- 6. TAB 3: RADAR RESTOCK KRITIS -->
    <div class="pk01-pane" id="tab-critical">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3 style="color:#b91c1c;">🚨 Radar Restock &amp; Peringatan Bahan Kritis</h3>
                    <div class="pk01-surface-desc">
                        Daftar bahan yang telah melampaui atau mendekati batas persediaan minimum aman (*buffer stock*). Segera jadwalkan pembelian ke vendor untuk mencegah kemacetan lantai produksi SPK.
                    </div>
                </div>
                <a href="<?php echo esc_url($receipt_hub_url); ?>" class="pk01-btn pk01-btn-emerald">
                    📦 Buka Form Penerimaan Stok &rarr;
                </a>
            </div>

            <div class="pk01-table-card">
                <table class="pk01-tbl">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Bahan</th>
                            <th>Status Gudang</th>
                            <th style="text-align:right;">Stok Saat Ini</th>
                            <th style="text-align:right;">Batas Minimum</th>
                            <th>Pemasok Utama</th>
                            <th style="text-align:center;">Tindakan Cepat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $critical_items = array_filter($rows, function($item) {
                            return (float)($item['stock'] ?? 0) <= (float)($item['min_stock'] ?? 0);
                        });
                        if (empty($critical_items)): 
                        ?>
                            <tr>
                                <td colspan="7" style="text-align:center; padding:36px; color:#059669; font-size:13px;">
                                    🟢 <strong>Kondisi Gudang Optimal:</strong> Seluruh stok bahan baku berada dalam batas aman persediaan.
                                </td>
                            </tr>
                        <?php else: foreach ($critical_items as $c): 
                            $c_stk = (float)($c['stock'] ?? 0);
                            $c_min = (float)($c['min_stock'] ?? 0);
                            $is_empty = ($c_stk <= 0);
                        ?>
                            <tr>
                                <td><span class="pk01-code-badge"><?php echo esc_html($c['code']); ?></span></td>
                                <td><strong style="color:#0f172a;"><?php echo esc_html($c['name']); ?></strong></td>
                                <td>
                                    <?php if ($is_empty): ?>
                                        <span class="pk01-badge-stk badge-habis">● Kosong (0)</span>
                                    <?php else: ?>
                                        <span class="pk01-badge-stk badge-menipis">● Menipis</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:right; font-weight:800; font-family:monospace; color:#dc2626;">
                                    <?php echo esc_html(pk01_format_qty($c_stk)); ?> <?php echo esc_html($c['unit']); ?>
                                </td>
                                <td style="text-align:right; font-family:monospace; color:#64748b;">
                                    <?php echo esc_html(pk01_format_qty($c_min)); ?> <?php echo esc_html($c['unit']); ?>
                                </td>
                                <td><?php echo esc_html($c['supplier_name']); ?></td>
                                <td style="text-align:center;">
                                    <a href="<?php echo esc_url($receipt_hub_url); ?>" class="pk01-btn pk01-btn-primary pk01-btn-sm" title="Catat barang masuk sekarang">
                                        📥 Restock Cepat
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 7. TAB 4: INTEGRASI ALUR KERJA (BOM & SPK) -->
    <div class="pk01-pane" id="tab-ecosystem">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🔗 Ekosistem Alur Bahan Baku (Saling Bersalaman)</h3>
                    <div class="pk01-surface-desc">
                        Bagaimana data bahan baku ini mengalir otomatis ke modul-modul lain di dalam sistem PK01.
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:18px;">
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">📦 &rarr; 🏭</div>
                    <h4 style="margin:0 0 6px; font-size:15px; font-weight:800; color:#0f172a;">Pemotongan Otomatis SPK</h4>
                    <p style="font-size:12.5px; color:#64748b; line-height:1.5; margin:0 0 12px;">
                        Saat Surat Perintah Kerja (SPK) dirilis di lantai produksi, sistem secara otomatis memotong stok fisik bahan sesuai rasio *Bill of Materials* (BOM).
                    </p>
                    <a href="<?php echo esc_url($url_helper('production_hub')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">
                        Buka Lantai Produksi SPK &rarr;
                    </a>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🏢 &rarr; 💰</div>
                    <h4 style="margin:0 0 6px; font-size:15px; font-weight:800; color:#0f172a;">Kalkulasi HPP &amp; Valuasi Laba</h4>
                    <p style="font-size:12.5px; color:#64748b; line-height:1.5; margin:0 0 12px;">
                        Harga Pokok Satuan (HPP) yang diatur di menu ini menjadi acuan kalkulasi margin laba kotor pada pesanan kasir dan laporan keuangan eksekutif.
                    </p>
                    <a href="<?php echo esc_url($url_helper('dashboard')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">
                        Pantau Margin di Dashboard &rarr;
                    </a>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🤝 &rarr; 📥</div>
                    <h4 style="margin:0 0 6px; font-size:15px; font-weight:800; color:#0f172a;">Sinkronisasi Vendor Pemasok</h4>
                    <p style="font-size:12.5px; color:#64748b; line-height:1.5; margin:0 0 12px;">
                        Pemasok utama yang terhubung mempermudah pembuatan Purchase Order (PO) saat stok bahan menipis atau kosong.
                    </p>
                    <a href="<?php echo esc_url($url_helper('suppliers')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">
                        Kelola Master Supplier &rarr;
                    </a>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }

    // 2. QUICK UNIT SELECTOR PILLS
    const unitInput = document.getElementById('pk01_unit_input');
    const unitPills = document.querySelectorAll('.pk01-pill-unit');
    if (unitInput && unitPills.length > 0) {
        unitPills.forEach(pill => {
            pill.addEventListener('click', function() {
                unitInput.value = this.dataset.unit;
            });
        });
    }

    // 3. LIVE SEARCH & STATUS FILTER
    const searchInput = document.getElementById('pk01_search_material');
    const table = document.getElementById('pk01_materials_tbl');
    const chipBtns = document.querySelectorAll('.pk01-chip-btn');
    let currentFilter = 'all';

    function applyFilters() {
        if (!table) return;
        const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
        const rows = table.querySelectorAll('tbody tr');

        rows.forEach(row => {
            const rowStatus = row.getAttribute('data-status') || '';
            const text = row.innerText.toLowerCase();

            const matchesSearch = (text.indexOf(query) > -1);
            const matchesChip   = (currentFilter === 'all' || 
                                  (currentFilter === 'menipis' && (rowStatus === 'menipis' || rowStatus === 'habis')) ||
                                  (rowStatus === currentFilter));

            if (matchesSearch && matchesChip) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }

    if (chipBtns.length > 0) {
        chipBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                chipBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                currentFilter = this.dataset.filter;
                applyFilters();
            });
        });
    }
});
</script>