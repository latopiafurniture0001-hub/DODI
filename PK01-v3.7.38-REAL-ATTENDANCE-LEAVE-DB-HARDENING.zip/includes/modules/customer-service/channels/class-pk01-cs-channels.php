<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * PK01 Customer Service Channel Registry.
 *
 * Mengelola pendaftaran, metadata, warna, dan status kanal komunikasi tiket CS.
 * Terbuka untuk ekstensi via filter hook 'pk01_cs_channels'.
 *
 * @package PK01\CustomerService
 * @version 2.0.0
 */
final class PK01_CS_Channels {

    /**
     * Kanal bawaan (fallback)
     */
    public const DEFAULT_CHANNEL = 'customer';

    /**
     * Cache memori lokal agar filter tidak dieksekusi berkali-kali dalam 1 lifecycle request.
     *
     * @var array<string, array<string, mixed>>|null
     */
    private static ?array $cached_channels = null;

    /**
     * Mengambil seluruh kanal yang terdaftar beserta metadatanya.
     *
     * @return array<string, array{
     *     label: string,
     *     description: string,
     *     color: string,
     *     icon: string,
     *     active: bool
     * }>
     */
    public static function all(): array {
        if (self::$cached_channels !== null) {
            return self::$cached_channels;
        }

        $channels = [
            'customer' => [
                'label'       => __('Pelanggan', 'pk01'),
                'description' => __('Pertanyaan dan komplain dari akun pembeli web.', 'pk01'),
                'color'       => '#2563eb', // Blue
                'icon'        => 'user',
                'active'      => true,
            ],
            'whatsapp' => [
                'label'       => __('WhatsApp', 'pk01'),
                'description' => __('Percakapan atau komplain yang masuk via integrasi WhatsApp.', 'pk01'),
                'color'       => '#16a34a', // Emerald Green
                'icon'        => 'whatsapp',
                'active'      => true,
            ],
            'seller' => [
                'label'       => __('Seller', 'pk01'),
                'description' => __('Kendala pesanan, setoran, komisi, dan koordinasi mitra penjual.', 'pk01'),
                'color'       => '#d97706', // Amber
                'icon'        => 'store',
                'active'      => true,
            ],
            'marketplace' => [
                'label'       => __('Marketplace', 'pk01'),
                'description' => __('Komplain dan layanan terkait order Shopee, Tokopedia, TikTok, dll.', 'pk01'),
                'color'       => '#9333ea', // Purple
                'icon'        => 'shopping-bag',
                'active'      => true,
            ],
        ];

        /**
         * Filter memungkinkan plugin eksternal / add-on menambahkan kanal baru
         * Contoh: menambah kanal 'email', 'telegram', atau 'walk_in'.
         */
        $filtered = apply_filters('pk01_cs_channels', $channels);

        self::$cached_channels = is_array($filtered) ? $filtered : $channels;

        return self::$cached_channels;
    }

    /**
     * Mengambil daftar kanal yang hanya berstatus aktif saja.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function active(): array {
        return array_filter(self::all(), static function (array $meta): bool {
            return !isset($meta['active']) || (bool) $meta['active'] === true;
        });
    }

    /**
     * Cek apakah key kanal terdaftar dan valid.
     *
     * @param string $channel
     * @return bool
     */
    public static function exists(string $channel): bool {
        $channel = sanitize_key($channel);
        return !empty($channel) && isset(self::all()[$channel]);
    }

    /**
     * Mengambil metadata lengkap satu kanal tertentu.
     *
     * @param string $channel
     * @return array<string, mixed>|null
     */
    public static function get(string $channel): ?array {
        $all = self::all();
        $channel = sanitize_key($channel);
        return $all[$channel] ?? null;
    }

    /**
     * Mendapatkan label tampilan untuk kanal.
     *
     * @param string $channel
     * @return string
     */
    public static function label(string $channel): string {
        $data = self::get($channel);
        if ($data && !empty($data['label'])) {
            return (string) $data['label'];
        }
        return ucfirst(str_replace(['_', '-'], ' ', $channel));
    }

    /**
     * Mendapatkan kode warna tema kanal (Hex).
     *
     * @param string $channel
     * @param string $fallback
     * @return string
     */
    public static function color(string $channel, string $fallback = '#64748b'): string {
        $data = self::get($channel);
        return !empty($data['color']) ? (string) $data['color'] : $fallback;
    }

    /**
     * Mengambil seluruh kunci (slug) kanal yang valid.
     * Sangat berguna untuk validasi skema REST API atau SQL WHERE IN.
     *
     * @return string[]
     */
    public static function keys(): array {
        return array_keys(self::all());
    }

    /**
     * Mengambil pasangan [slug => Label] yang siap di-loop pada tag HTML <select>.
     *
     * @param bool $active_only Hanya sertakan yang aktif saja.
     * @return array<string, string>
     */
    public static function options(bool $active_only = true): array {
        $channels = $active_only ? self::active() : self::all();
        $options = [];

        foreach ($channels as $key => $meta) {
            $options[$key] = $meta['label'] ?? ucfirst($key);
        }

        return $options;
    }

    /**
     * Mendapatkan kanal default sistem.
     *
     * @return string
     */
    public static function default(): string {
        return self::exists(self::DEFAULT_CHANNEL) ? self::DEFAULT_CHANNEL : (self::keys()[0] ?? 'customer');
    }

    /**
     * Merender badge HTML kecil yang siap pakai di tabel dashboard.
     *
     * @param string $channel
     * @return string HTML Badge
     */
    public static function render_badge(string $channel): string {
        $label = self::label($channel);
        $color = self::color($channel);

        return sprintf(
            '<span class="pk01-cs-channel-badge" style="display:inline-flex;align-items:center;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700;color:%s;background:%s15;border:1px solid %s30;">%s</span>',
            esc_attr($color),
            esc_attr($color),
            esc_attr($color),
            esc_html($label)
        );
    }
}