<?php
/**
 * View Template: PK01 Customer Service Dashboard
 * Modern, High-Performance, and Scalable UI.
 */
if (!defined('ABSPATH')) {
    exit;
}

// 1. Validasi Autorisasi & Keamanan
if (!is_user_logged_in() || !class_exists('PK01_Authorization') || !PK01_Authorization::can('customer_service')) {
    echo '<div class="pk01-cs-alert pk01-cs-alert--warning">' . 
         esc_html__('Akses Ditolak: Anda tidak memiliki izin untuk mengelola Customer Service.', 'pk01') . 
         '</div>';
    return;
}

global $wpdb;

// 2. Query Efisien: Periksa Tabel & Agregasi Semua Metrik dalam 1 Kali Query
$ticket_table = class_exists('PK01_DB') ? PK01_DB::t('cs_tickets') : '';
$table_exists = false;

if (!empty($ticket_table)) {
    $table_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $ticket_table)) === $ticket_table);
}

$metrics = [
    'total'    => 0,
    'open'     => 0,
    'answered' => 0,
    'urgent'   => 0,
    'closed'   => 0,
];

if ($table_exists) {
    $raw_counts = $wpdb->get_row("
        SELECT 
            COUNT(*) AS total,
            COUNT(CASE WHEN status = 'open' THEN 1 END) AS `open`,
            COUNT(CASE WHEN status = 'answered' THEN 1 END) AS `answered`,
            COUNT(CASE WHEN priority = 'urgent' AND status != 'closed' THEN 1 END) AS `urgent`,
            COUNT(CASE WHEN status = 'closed' THEN 1 END) AS `closed`
        FROM `{$ticket_table}`
    ", ARRAY_A);

    if ($raw_counts) {
        $metrics = array_map('intval', $raw_counts);
    }
}

// 3. Resolusi URL Target
$base_url = class_exists('PK01_Shortcodes') ? PK01_Shortcodes::frontend_url_public('') : home_url('/');
$cs_url   = add_query_arg('pk01_view', 'customer_service', $base_url);
$sales_url = add_query_arg('pk01_view', 'sales_hub', $base_url);
$seller_url = add_query_arg('pk01_view', 'seller', $base_url);
?>

<div class="pk01-cs-scope">
    <style>
        .pk01-cs-scope {
            --pk-bg-page: #f8fafc;
            --pk-surface: #ffffff;
            --pk-border: #e2e8f0;
            --pk-text-head: #0f172a;
            --pk-text-body: #475569;
            --pk-text-muted: #64748b;
            --pk-primary: #2563eb;
            --pk-primary-hover: #1d4ed8;
            --pk-radius-lg: 16px;
            --pk-radius-md: 10px;
            --pk-shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --pk-shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.06), 0 2px 4px -2px rgba(0, 0, 0, 0.06);

            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            max-width: 1400px;
            margin: 0 auto 40px;
            color: var(--pk-text-head);
            box-sizing: border-box;
        }

        .pk01-cs-scope * {
            box-sizing: border-box;
        }

        /* Hero Banner */
        .pk01-cs-hero {
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            border-radius: var(--pk-radius-lg);
            padding: 32px;
            color: #ffffff;
            box-shadow: var(--pk-shadow-md);
            margin-bottom: 24px;
        }

        .pk01-cs-hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 9999px;
            background: rgba(255, 255, 255, 0.1);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: #38bdf8;
            margin-bottom: 12px;
        }

        .pk01-cs-hero-badge .pk-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background-color: #38bdf8;
            box-shadow: 0 0 8px #38bdf8;
        }

        .pk01-cs-hero h2 {
            font-size: 26px;
            font-weight: 800;
            margin: 0 0 8px 0;
            color: #ffffff;
            letter-spacing: -0.02em;
        }

        .pk01-cs-hero p {
            margin: 0;
            font-size: 14px;
            line-height: 1.6;
            color: #94a3b8;
            max-width: 760px;
        }

        /* KPI Cards Grid */
        .pk01-cs-kpis {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .pk01-cs-card {
            background: var(--pk-surface);
            border: 1px solid var(--pk-border);
            border-radius: var(--pk-radius-md);
            padding: 20px;
            box-shadow: var(--pk-shadow-sm);
            transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .pk01-cs-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--pk-shadow-md);
            border-color: #cbd5e1;
        }

        .pk01-cs-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
        }

        .pk01-cs-card-header span {
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.03em;
            color: var(--pk-text-muted);
            text-transform: uppercase;
        }

        .pk01-cs-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .pk01-cs-icon svg {
            width: 18px;
            height: 18px;
            stroke-width: 2;
        }

        .pk01-cs-card-value {
            font-size: 28px;
            font-weight: 800;
            color: var(--pk-text-head);
            line-height: 1;
            letter-spacing: -0.03em;
        }

        /* KPI Status Accents */
        .pk01-cs-card--total .pk01-cs-icon { background: #f1f5f9; color: #475569; }
        .pk01-cs-card--open .pk01-cs-icon { background: #eff6ff; color: #2563eb; }
        .pk01-cs-card--answered .pk01-cs-icon { background: #fefce8; color: #ca8a04; }
        .pk01-cs-card--urgent .pk01-cs-icon { background: #fff1f2; color: #e11d48; }
        .pk01-cs-card--urgent .pk01-cs-card-value { color: #e11d48; }
        .pk01-cs-card--closed .pk01-cs-icon { background: #ecfdf5; color: #059669; }

        /* Panel Content */
        .pk01-cs-panel {
            background: var(--pk-surface);
            border: 1px solid var(--pk-border);
            border-radius: var(--pk-radius-lg);
            padding: 24px;
            box-shadow: var(--pk-shadow-sm);
        }

        .pk01-cs-panel h3 {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 6px 0;
            color: var(--pk-text-head);
        }

        .pk01-cs-panel p {
            margin: 0 0 20px 0;
            color: var(--pk-text-body);
            font-size: 14px;
            line-height: 1.5;
        }

        /* Action Buttons */
        .pk01-cs-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .pk01-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            border-radius: var(--pk-radius-md);
            font-size: 13.5px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.15s ease-in-out;
            cursor: pointer;
            border: 1px solid transparent;
        }

        .pk01-btn-primary {
            background-color: var(--pk-primary);
            color: #ffffff !important;
        }

        .pk01-btn-primary:hover {
            background-color: var(--pk-primary-hover);
        }

        .pk01-btn-secondary {
            background-color: #ffffff;
            color: var(--pk-text-head) !important;
            border-color: var(--pk-border);
        }

        .pk01-btn-secondary:hover {
            background-color: #f8fafc;
            border-color: #cbd5e1;
        }

        /* Note Callout */
        .pk01-cs-note {
            margin-top: 20px;
            padding: 14px 18px;
            border-radius: var(--pk-radius-md);
            background: #f8fafc;
            border: 1px dashed #cbd5e1;
            display: flex;
            align-items: flex-start;
            gap: 10px;
            color: var(--pk-text-muted);
            font-size: 13px;
            line-height: 1.5;
        }

        .pk01-cs-note svg {
            flex-shrink: 0;
            margin-top: 2px;
        }

        /* Responsive Breakpoints */
        @media (max-width: 1024px) {
            .pk01-cs-kpis {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }
        }

        @media (max-width: 640px) {
            .pk01-cs-hero {
                padding: 24px;
            }
            .pk01-cs-kpis {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px;
            }
            .pk01-cs-actions {
                flex-direction: column;
            }
            .pk01-btn {
                justify-content: center;
                width: 100%;
            }
        }

        @media (max-width: 420px) {
            .pk01-cs-kpis {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <!-- Hero Section -->
    <header class="pk01-cs-hero">
        <div class="pk01-cs-hero-badge">
            <span class="pk-dot"></span>
            <?php esc_html_e('Sistem Tiket & Komunikasi Terpadu', 'pk01'); ?>
        </div>
        <h2><?php esc_html_e('Pusat Layanan Pelanggan', 'pk01'); ?></h2>
        <p><?php esc_html_e('Data tiket dan percakapan disinkronisasi langsung dari transaksi, seller, dan pembeli secara real-time tanpa data dummy.', 'pk01'); ?></p>
    </header>

    <!-- KPI Cards Grid -->
    <section class="pk01-cs-kpis">
        <!-- Total Tiket -->
        <div class="pk01-cs-card pk01-cs-card--total">
            <div class="pk01-cs-card-header">
                <span><?php esc_html_e('Total Tiket', 'pk01'); ?></span>
                <div class="pk01-cs-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                </div>
            </div>
            <div class="pk01-cs-card-value"><?php echo esc_html(number_format_i18n($metrics['total'])); ?></div>
        </div>

        <!-- Open Tickets -->
        <div class="pk01-cs-card pk01-cs-card--open">
            <div class="pk01-cs-card-header">
                <span><?php esc_html_e('Tiket Baru', 'pk01'); ?></span>
                <div class="pk01-cs-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
            </div>
            <div class="pk01-cs-card-value"><?php echo esc_html(number_format_i18n($metrics['open'])); ?></div>
        </div>

        <!-- Waiting Reply -->
        <div class="pk01-cs-card pk01-cs-card--answered">
            <div class="pk01-cs-card-header">
                <span><?php esc_html_e('Menunggu Balasan', 'pk01'); ?></span>
                <div class="pk01-cs-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
            </div>
            <div class="pk01-cs-card-value"><?php echo esc_html(number_format_i18n($metrics['answered'])); ?></div>
        </div>

        <!-- Urgent -->
        <div class="pk01-cs-card pk01-cs-card--urgent">
            <div class="pk01-cs-card-header">
                <span><?php esc_html_e('Prioritas Tinggi', 'pk01'); ?></span>
                <div class="pk01-cs-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                </div>
            </div>
            <div class="pk01-cs-card-value"><?php echo esc_html(number_format_i18n($metrics['urgent'])); ?></div>
        </div>

        <!-- Resolved / Closed -->
        <div class="pk01-cs-card pk01-cs-card--closed">
            <div class="pk01-cs-card-header">
                <span><?php esc_html_e('Terselesaikan', 'pk01'); ?></span>
                <div class="pk01-cs-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
            </div>
            <div class="pk01-cs-card-value"><?php echo esc_html(number_format_i18n($metrics['closed'])); ?></div>
        </div>
    </section>

    <!-- Navigation & Action Panel -->
    <section class="pk01-cs-panel">
        <h3><?php esc_html_e('Aksi Cepat & Navigasi Layanan', 'pk01'); ?></h3>
        <p><?php esc_html_e('Akses antrean tiket, pantau kendala dari kanal WhatsApp/marketplace, atau verifikasi status pesanan pelanggan.', 'pk01'); ?></p>
        
        <div class="pk01-cs-actions">
            <a href="<?php echo esc_url($cs_url); ?>" class="pk01-btn pk01-btn-primary">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                <?php esc_html_e('Buka Meja Layanan (CS)', 'pk01'); ?>
            </a>
            <a href="<?php echo esc_url($sales_url); ?>" class="pk01-btn pk01-btn-secondary">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
                <?php esc_html_e('Pusat Penjualan (Sales Hub)', 'pk01'); ?>
            </a>
            <a href="<?php echo esc_url($seller_url); ?>" class="pk01-btn pk01-btn-secondary">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                <?php esc_html_e('Daftar Seller', 'pk01'); ?>
            </a>
        </div>

        <div class="pk01-cs-note">
            <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="#64748b"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <div>
                <strong><?php esc_html_e('Catatan Integritas Data:', 'pk01'); ?></strong>
                <?php esc_html_e(' Jika tabel database CS belum dibuat, sistem akan aman menampilkan angka 0 secara elegan tanpa menimbulkan error pada dashboard.', 'pk01'); ?>
            </div>
        </div>
    </section>
</div>