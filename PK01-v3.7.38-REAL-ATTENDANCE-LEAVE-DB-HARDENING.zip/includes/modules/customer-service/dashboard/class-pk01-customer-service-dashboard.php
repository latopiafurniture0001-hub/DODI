<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Canonical Customer Service Dashboard Controller.
 * 
 * Bertanggung jawab menangani resolusi template, isolasi variabel,
 * dan rendering UI yang aman dan ekstensibel.
 *
 * @package PK01\CustomerService
 * @version 2.0.0
 */
final class PK01_Customer_Service_Dashboard {

    /**
     * Path relatif template bawaan di dalam plugin.
     */
    private const TEMPLATE_FILE = 'includes/modules/customer-service/dashboard/tampilan-customer-service.php';

    /**
     * Render UI Dashboard dengan isolasi scope dan proteksi buffer.
     *
     * @param array<string, mixed> $data Data kontekstual yang ingin dioper ke file view/UI.
     * @return string Output HTML.
     */
    public static function render(array $data = []): string {
        // Filter data sebelum dikirim ke view (memungkinkan modul lain menyuntikkan data)
        $data = apply_filters('pk01_cs_dashboard_data', $data);

        $template_path = self::locate_template();

        if (!$template_path || !is_readable($template_path)) {
            return self::render_notice(
                esc_html__('Tampilan Customer Service belum tersedia atau tidak dapat dibaca.', 'pk01-textdomain'),
                'is-error'
            );
        }

        // Mulai Output Buffering dengan perlindungan Try-Catch
        ob_start();

        try {
            /**
             * Action hook sebelum template dirender.
             */
            do_action('pk01_before_cs_dashboard_render', $data);

            // Scope Isolation: Menjalankan template dalam closure terisolasi
            // Mencegah kebocoran variabel controller ke dalam template UI
            (static function(string $file_path, array $data): void {
                // Ekstrak data agar bisa langsung dipanggil sebagai variabel di tampilan
                // Contoh: $data['nama'] -> bisa dipanggil sebagai $nama di UI
                extract($data, EXTR_SKIP);
                include $file_path;
            })($template_path, $data);

            /**
             * Action hook setelah template dirender.
             */
            do_action('pk01_after_cs_dashboard_render', $data);

            return (string) ob_get_clean();

        } catch (\Throwable $e) {
            // Tangkap semua Throwable/Error agar buffer tidak merusak tampilan WordPress
            ob_end_clean();

            // Log error jika WP_DEBUG aktif
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf(
                    '[PK01 CS Dashboard Error] %s in %s:%d',
                    $e->getMessage(),
                    $e->getFile(),
                    $e->getLine()
                ));
            }

            return self::render_notice(
                esc_html__('Terjadi kesalahan saat memuat tampilan Customer Service.', 'pk01-textdomain'),
                'is-error'
            );
        }
    }

    /**
     * Mencari path template dengan fitur Theme Override (Hierarki tema ala WooCommerce).
     *
     * @return string Path absolut file template atau string kosong jika tidak ada.
     */
    public static function locate_template(): string {
        $default_path = defined('PK01_DIR') 
            ? trailingslashit(PK01_DIR) . self::TEMPLATE_FILE 
            : '';

        // Izinkan developer menimpa UI dari folder child theme / active theme
        // Contoh: wp-content/themes/your-theme/pk01/customer-service/tampilan-customer-service.php
        $theme_override = locate_template([
            'pk01/customer-service/tampilan-customer-service.php',
            'pk01/tampilan-customer-service.php',
        ]);

        $final_path = !empty($theme_override) ? $theme_override : $default_path;

        /**
         * Filter untuk mengubah path template jika diperlukan.
         */
        return (string) apply_filters('pk01_cs_dashboard_template_path', $final_path);
    }

    /**
     * Komponen helper untuk merender pesan/notice terstandarisasi.
     *
     * @param string $message Pesan yang sudah di-escape.
     * @param string $type Class CSS modifier (misal: 'is-error', 'is-warning').
     * @return string HTML notice.
     */
    private static function render_notice(string $message, string $type = 'is-error'): string {
        return sprintf(
            '<div class="pk01-op-notice %s"><p>%s</p></div>',
            esc_attr($type),
            $message
        );
    }
}