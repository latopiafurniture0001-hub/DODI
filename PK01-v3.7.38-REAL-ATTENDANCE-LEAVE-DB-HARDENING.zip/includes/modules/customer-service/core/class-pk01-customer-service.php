<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * PK01 Customer Service
 * Ticket + conversation hub for customers, sellers, and marketplace operations.
 */
class PK01_Customer_Service {

    const NS = 'pk01/v1';

    /**
     * Inisialisasi hook API
     */
    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    /**
     * Helper nama tabel DB
     */
    public static function t($k) {
        return class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($k) : '';
    }

    /**
     * Skema Database & Instalasi Tabel
     */
    public static function install() {
        global $wpdb;

        $tt = self::t('cs_tickets');
        $tm = self::t('cs_messages');

        if (!$tt || !$tm) {
            return;
        }

        // Cek jika kedua tabel sudah eksis
        $tt_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tt)) === $tt);
        $tm_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tm)) === $tm);

        if ($tt_exists && $tm_exists) {
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();

        // Standar dbDelta: 2 spasi setelah PRIMARY KEY dan tipe data eksplisit
        $sql_tickets = "CREATE TABLE {$tt} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_no varchar(40) NOT NULL,
            channel varchar(30) NOT NULL DEFAULT 'customer',
            subject varchar(180) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'open',
            priority varchar(20) NOT NULL DEFAULT 'normal',
            customer_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            seller_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            assigned_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            order_ref varchar(80) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ticket_no (ticket_no),
            KEY status (status),
            KEY customer_user_id (customer_user_id),
            KEY seller_user_id (seller_user_id)
        ) {$charset_collate};";

        $sql_messages = "CREATE TABLE {$tm} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            sender_id bigint(20) unsigned NOT NULL,
            message longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_created (ticket_id, created_at)
        ) {$charset_collate};";

        PK01_DB::dbDelta_safe($sql_tickets);
        PK01_DB::dbDelta_safe($sql_messages);
    }

    /**
     * Cek apakah user berhak mengakses fitur Customer Service.
     * (Ditambahkan 'customer' dan 'subscriber' agar user/pembeli bisa mengakses tiket mereka)
     */
    public static function allowed() {
        if (!is_user_logged_in()) {
            return false;
        }

        if (current_user_can('manage_options')) {
            return true;
        }

        $user = wp_get_current_user();
        $roles = (array) $user->roles;

        $allowed_roles = [
            'administrator', 'pk01_admin', 'pk01_owner', 'shop_manager',
            'pk01_customer_service', 'pk01_seller', 'pk01_kasir',
            'pk01_produksi', 'pk01_employee', 'pk01_gudang',
            'pk01_logistik', 'pk01_packing', 'pk01_hr',
            'pk01_keuangan', 'pk01_security', 'customer', 'subscriber'
        ];

        return (bool) array_intersect($allowed_roles, $roles);
    }

    /**
     * Cek apakah user adalah internal staff/admin/CS agent
     */
    public static function staff() {
        if (current_user_can('manage_options')) {
            return true;
        }

        $roles = (array) wp_get_current_user()->roles;
        $staff_roles = ['administrator', 'pk01_admin', 'pk01_customer_service', 'shop_manager'];

        return (bool) array_intersect($staff_roles, $roles);
    }

    /**
     * Pendaftaran REST Routes
     */
    public static function routes() {
        register_rest_route(self::NS, '/customer-service/tickets', [
            [
                'methods'             => 'GET',
                'permission_callback' => [__CLASS__, 'allowed'],
                'callback'            => [__CLASS__, 'list'],
            ],
            [
                'methods'             => 'POST',
                'permission_callback' => [__CLASS__, 'allowed'],
                'callback'            => [__CLASS__, 'create'],
            ]
        ]);

        register_rest_route(self::NS, '/customer-service/tickets/(?P<id>\d+)', [
            'methods'             => 'GET',
            'permission_callback' => function($r) {
                return self::can_ticket((int) $r['id']);
            },
            'callback'            => [__CLASS__, 'get'],
        ]);

        register_rest_route(self::NS, '/customer-service/tickets/(?P<id>\d+)/reply', [
            'methods'             => 'POST',
            'permission_callback' => function($r) {
                return self::can_ticket((int) $r['id']);
            },
            'callback'            => [__CLASS__, 'reply'],
        ]);

        register_rest_route(self::NS, '/customer-service/tickets/(?P<id>\d+)/close', [
            'methods'             => 'POST',
            'permission_callback' => [__CLASS__, 'staff'],
            'callback'            => [__CLASS__, 'close'],
        ]);
    }

    /**
     * Memeriksa otorisasi spesifik untuk tiket ID tertentu
     */
    public static function can_ticket($id) {
        if (!self::allowed() || $id <= 0) {
            return false;
        }

        if (self::staff()) {
            return true;
        }

        global $wpdb;
        $t = self::t('cs_tickets');
        if (!$t) {
            return false;
        }

        $uid = get_current_user_id();
        $is_owner = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$t} WHERE id = %d AND (customer_user_id = %d OR seller_user_id = %d) LIMIT 1",
            $id, $uid, $uid
        ));

        return (bool) $is_owner;
    }

    /**
     * Mengambil daftar tiket (Dengan opsi filter status/channel)
     */
    public static function list($r) {
        global $wpdb;
        $t = self::t('cs_tickets');

        if (!$t) {
            return new WP_Error('db_error', 'Tabel tiket tidak tersedia.', ['status' => 500]);
        }

        $uid = get_current_user_id();
        $where_clauses = [];

        // Scope kepemilikan data
        if (!self::staff()) {
            $where_clauses[] = $wpdb->prepare('(customer_user_id = %d OR seller_user_id = %d)', $uid, $uid);
        }

        // Filter opsional via query param tanpa merusak struktur default
        $status = sanitize_key($r->get_param('status') ?? '');
        if (!empty($status) && in_array($status, ['open', 'answered', 'closed'], true)) {
            $where_clauses[] = $wpdb->prepare('status = %s', $status);
        }

        $channel = sanitize_key($r->get_param('channel') ?? '');
        if (!empty($channel)) {
            $where_clauses[] = $wpdb->prepare('channel = %s', $channel);
        }

        $where_sql = !empty($where_clauses) ? implode(' AND ', $where_clauses) : '1=1';

        $limit = min(absint($r->get_param('limit') ?: 100), 100);
        $rows = $wpdb->get_results(
            "SELECT * FROM {$t} WHERE {$where_sql} ORDER BY id DESC LIMIT {$limit}",
            ARRAY_A
        ) ?: [];

        return [
            'ok'      => true,
            'tickets' => $rows
        ];
    }

    /**
     * Membuat tiket baru beserta pesan pertamanya
     */
    public static function create($r) {
        global $wpdb;
        $t = self::t('cs_tickets');

        if (!$t) {
            return new WP_Error('db_error', 'Tabel tiket belum dikonfigurasi.', ['status' => 500]);
        }

        $p = $r->get_json_params() ?: [];

        $subject = trim(sanitize_text_field($p['subject'] ?? ''));
        if ($subject === '') {
            return new WP_Error('subject_required', 'Subjek tiket wajib diisi.', ['status' => 422]);
        }

        $message = trim(sanitize_textarea_field($p['message'] ?? ''));
        if ($message === '') {
            return new WP_Error('message_required', 'Pesan pertama tiket wajib diisi.', ['status' => 422]);
        }

        // Channel validation
        $channel = sanitize_key($p['channel'] ?? 'customer');
        $valid_channels = class_exists('PK01_CS_Channels') && method_exists('PK01_CS_Channels', 'exists')
            ? PK01_CS_Channels::exists($channel)
            : in_array($channel, ['customer', 'whatsapp', 'seller', 'marketplace'], true);

        if (!$valid_channels) {
            $channel = 'customer';
        }

        // Priority validation
        $priority = sanitize_key($p['priority'] ?? 'normal');
        if (!in_array($priority, ['low', 'normal', 'high', 'urgent'], true)) {
            $priority = 'normal';
        }

        // Order reference (sekarang tersimpan dengan benar)
        $order_ref = sanitize_text_field($p['order_ref'] ?? '');

        $now = current_time('mysql');
        $uid = get_current_user_id();

        $ticket_no = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'document_number')
            ? PK01_Engine::document_number('cs_ticket')
            : 'CS-' . wp_date('ymd', current_time('timestamp')) . '-' . wp_rand(1000, 9999);

        // Assign user ID berdasarkan channel
        $customer_uid = in_array($channel, ['customer', 'whatsapp'], true) ? $uid : 0;
        $seller_uid   = ($channel === 'seller') ? $uid : 0;

        // Jika staff yang membuat atas nama customer/seller
        if (self::staff()) {
            if (!empty($p['customer_user_id'])) {
                $customer_uid = absint($p['customer_user_id']);
            }
            if (!empty($p['seller_user_id'])) {
                $seller_uid = absint($p['seller_user_id']);
            }
        }

        $inserted = $wpdb->insert($t, [
            'ticket_no'        => $ticket_no,
            'channel'          => $channel,
            'subject'          => $subject,
            'status'           => 'open',
            'priority'         => $priority,
            'customer_user_id' => $customer_uid,
            'seller_user_id'   => $seller_uid,
            'order_ref'        => $order_ref,
            'created_at'       => $now,
            'updated_at'       => $now
        ]);

        if (!$inserted) {
            return new WP_Error('insert_failed', 'Gagal membuat tiket.', ['status' => 500]);
        }

        $id = (int) $wpdb->insert_id;
        self::add_message($id, $message);

        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'info')) {
            PK01_Audit::info('customer_service_ticket', 'customer_service', 'Ticket ' . $ticket_no . ' dibuat', 'cs_ticket', (string) $id);
        }

        return [
            'ok'        => true,
            'id'        => $id,
            'ticket_no' => $ticket_no
        ];
    }

    /**
     * Tambah pesan ke dalam percakapan tiket
     */
    public static function add_message($id, $msg) {
        $clean_msg = trim((string) $msg);
        if ($clean_msg === '' || $id <= 0) {
            return 0;
        }

        global $wpdb;
        $m = self::t('cs_messages');
        if (!$m) {
            return 0;
        }

        $wpdb->insert($m, [
            'ticket_id'  => $id,
            'sender_id'  => get_current_user_id(),
            'message'    => $clean_msg,
            'created_at' => current_time('mysql')
        ]);

        return (int) $wpdb->insert_id;
    }

    /**
     * Mengambil detail tiket dan seluruh pesan percakapan
     */
    public static function get($r) {
        $id = (int) ($r['id'] ?? 0);
        if (!self::can_ticket($id)) {
            return new WP_Error('forbidden', 'Akses tiket ditolak.', ['status' => 403]);
        }

        global $wpdb;
        $t = self::t('cs_tickets');
        $m = self::t('cs_messages');

        $ticket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d", $id), ARRAY_A);
        if (!$ticket) {
            return new WP_Error('not_found', 'Tiket tidak ditemukan.', ['status' => 404]);
        }

        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT m.*, u.display_name 
             FROM {$m} m 
             LEFT JOIN {$wpdb->users} u ON u.ID = m.sender_id 
             WHERE m.ticket_id = %d 
             ORDER BY m.id ASC",
            $id
        ), ARRAY_A) ?: [];

        return [
            'ok'       => true,
            'ticket'   => $ticket,
            'messages' => $messages
        ];
    }

    /**
     * Membalas tiket dan memperbarui status secara cerdas
     */
    public static function reply($r) {
        $id = (int) ($r['id'] ?? 0);
        if (!self::can_ticket($id)) {
            return new WP_Error('forbidden', 'Akses ditolak.', ['status' => 403]);
        }

        global $wpdb;
        $t = self::t('cs_tickets');

        // Pastikan tiket ada
        $ticket = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM {$t} WHERE id = %d", $id));
        if (!$ticket) {
            return new WP_Error('not_found', 'Tiket tidak ditemukan.', ['status' => 404]);
        }

        $params = $r->get_json_params() ?: [];
        $msg = trim(wp_strip_all_tags((string) ($params['message'] ?? '')));

        if ($msg === '') {
            return new WP_Error('empty_message', 'Pesan balasan tidak boleh kosong.', ['status' => 422]);
        }

        $msg_id = self::add_message($id, $msg);

        // Update status & waktu:
        // Jika staf membalas -> 'answered'
        // Jika customer/seller membalas (bahkan jika tiket sudah closed) -> dibuka kembali ('open')
        $new_status = self::staff() ? 'answered' : 'open';

        $wpdb->update($t, [
            'status'     => $new_status,
            'updated_at' => current_time('mysql')
        ], ['id' => $id]);

        return [
            'ok' => true,
            'id' => $msg_id
        ];
    }

    /**
     * Menutup tiket (Hanya staf/admin)
     */
    public static function close($r) {
        if (!self::staff()) {
            return new WP_Error('forbidden', 'Hanya staf yang dapat menutup tiket.', ['status' => 403]);
        }

        $id = (int) ($r['id'] ?? 0);
        global $wpdb;
        $t = self::t('cs_tickets');

        // Pastikan tiket ada sebelum update
        $ticket = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE id = %d", $id));
        if (!$ticket) {
            return new WP_Error('not_found', 'Tiket tidak ditemukan.', ['status' => 404]);
        }

        $wpdb->update($t, [
            'status'     => 'closed',
            'updated_at' => current_time('mysql')
        ], ['id' => $id]);

        if (class_exists('PK01_Audit') && method_exists('PK01_Audit', 'info')) {
            PK01_Audit::info('customer_service_ticket', 'customer_service', 'Ticket #' . $id . ' ditutup', 'cs_ticket', (string) $id);
        }

        return ['ok' => true];
    }
}