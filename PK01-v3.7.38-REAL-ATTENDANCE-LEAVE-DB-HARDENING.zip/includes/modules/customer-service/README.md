# PK01 — Modul Customer Service

Folder canonical: `includes/modules/customer-service/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/customer-service/channels/class-pk01-cs-channels.php`
- `includes/modules/customer-service/core/class-pk01-customer-service.php`
- `includes/modules/customer-service/dashboard/class-pk01-customer-service-dashboard.php`
- `includes/modules/customer-service/dashboard/tampilan-customer-service.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
