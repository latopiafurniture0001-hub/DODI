# PK01 — Modul Finance

Folder canonical: `includes/modules/finance/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/finance/capital/tampilan-modal.php`
- `includes/modules/finance/cash/tampilan-kas.php`
- `includes/modules/finance/closing/tampilan-tutup-periode.php`
- `includes/modules/finance/core/class-pk01-expense-workflow.php`
- `includes/modules/finance/core/class-pk01-finance.php`
- `includes/modules/finance/operational-costs/tampilan-biaya-usaha.php`
- `includes/modules/finance/overview/tampilan-keuangan.php`
- `includes/modules/finance/reports/tampilan-laporan-keuangan.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.
