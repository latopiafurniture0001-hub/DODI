<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. AKSES ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);

if (!$is_admin && class_exists('PK01_Authorization') && !PK01_Authorization::can('finance')) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">🔒</div>
            <strong style="font-size:16px;">Akses Ditolak</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki wewenang otorisasi untuk membuka laporan laba rugi dan keuangan.</p>
          </div>';
    return;
}

// 2. LOGIKA PERIODE CEPAT (PRESET DATE LOGIC)
$today  = current_time('Y-m-d');
$preset = sanitize_key($_GET['preset'] ?? '');

if ($preset === 'today') {
    $from = $today;
    $to   = $today;
} elseif ($preset === 'last_month') {
    $from = date('Y-m-01', strtotime('-1 month', current_time('timestamp')));
    $to   = date('Y-m-t', strtotime('-1 month', current_time('timestamp')));
} elseif ($preset === 'year') {
    $from = current_time('Y-01-01');
    $to   = $today;
} elseif ($preset === 'this_month' || empty($_GET['from'])) {
    $from = current_time('Y-m-01');
    $to   = $today;
    $preset = 'this_month';
} else {
    $from = sanitize_text_field(wp_unslash($_GET['from'] ?? current_time('Y-m-01')));
    $to   = sanitize_text_field(wp_unslash($_GET['to'] ?? current_time('Y-m-d')));
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = current_time('Y-m-01');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = current_time('Y-m-d');

// Helper Deteksi Tabel Database PK01
$get_table = function($key) use ($wpdb) {
    $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
};

// Helper URL Aman Lintas Modul (Saling Bersalaman)
$url_helper = function($slug, $args = []) {
    if (class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')) {
        $base = PK01_Shortcodes::frontend_url_public($slug);
    } else {
        $base = add_query_arg('pk01_view', $slug, home_url('/'));
    }
    return !empty($args) ? add_query_arg($args, $base) : $base;
};

$tbl_orders   = $get_table('sales_orders') ?: ($get_table('orders') ?: $wpdb->prefix . 'pk01_orders');
$tbl_costs    = $get_table('operational_costs');
$tbl_payroll  = $get_table('payroll');
$tbl_ledger   = $get_table('cash_ledger');
$tbl_invoices = $get_table('seller_invoices');
$tbl_sellers  = $get_table('sales_accounts');
$tbl_payments = $get_table('seller_payments');
$tbl_cashier_deposits = $get_table('cashier_deposits');

// 2B. PENERIMAAN SETORAN KASIR OLEH KEUANGAN.
$cashier_deposit_notice='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_approve_cashier_deposit']) && ($is_admin || (class_exists('PK01_Authorization') && PK01_Authorization::can('finance')))){
    if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_cashier_deposit_approval_nonce']??'')),'pk01_approve_cashier_deposit')) $cashier_deposit_notice='<div style="padding:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px">Sesi persetujuan tidak valid.</div>';
    else try{PK01_Engine::approve_cashier_deposit(absint($_POST['deposit_id']??0),sanitize_textarea_field(wp_unslash($_POST['approval_note']??'')));$cashier_deposit_notice='<div style="padding:10px;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;border-radius:10px">✅ Nilai setoran disetujui. Sekarang Keuangan dapat menerima/membukukan setoran.</div>';}catch(Throwable $e){$cashier_deposit_notice='<div style="padding:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px">❌ Persetujuan gagal: '.esc_html($e->getMessage()).'</div>';}
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_receive_cashier_deposit']) && ($is_admin || (class_exists('PK01_Authorization') && PK01_Authorization::can('finance')))){
    if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_cashier_deposit_receive_nonce']??'')),'pk01_receive_cashier_deposit')) $cashier_deposit_notice='<div style="padding:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px">Sesi penerimaan tidak valid.</div>';
    else try{PK01_Engine::receive_cashier_deposit(absint($_POST['deposit_id']??0),sanitize_text_field(wp_unslash($_POST['destination_account']??'Kas/Bank Keuangan')));$cashier_deposit_notice='<div style="padding:10px;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;border-radius:10px">✅ Setoran diterima Keuangan dan statusnya dikunci.</div>';}catch(Throwable $e){$cashier_deposit_notice='<div style="padding:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px">❌ Setoran belum diterima: '.esc_html($e->getMessage()).'</div>';}
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_reject_cashier_deposit']) && ($is_admin || (class_exists('PK01_Authorization') && PK01_Authorization::can('finance')))){
    if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_cashier_deposit_receive_nonce']??'')),'pk01_receive_cashier_deposit')) $cashier_deposit_notice='<div style="padding:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px">Sesi penerimaan tidak valid.</div>';
    else try{PK01_Engine::reject_cashier_deposit(absint($_POST['deposit_id']??0),sanitize_textarea_field(wp_unslash($_POST['rejection_reason']??'')));$cashier_deposit_notice='<div style="padding:10px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:10px">⚠️ Setoran ditolak dan dikembalikan ke Kasir untuk diperbaiki.</div>';}catch(Throwable $e){$cashier_deposit_notice='<div style="padding:10px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:10px">❌ Setoran belum diproses: '.esc_html($e->getMessage()).'</div>';}
}
$pending_cashier_deposits=[];
if($tbl_cashier_deposits){$pending_cashier_deposits=$wpdb->get_results("SELECT d.*,u.display_name cashier_name,s.name seller_name,i.invoice_no FROM `{$tbl_cashier_deposits}` d LEFT JOIN `{$wpdb->users}` u ON u.ID=d.cashier_user_id LEFT JOIN `{$tbl_sellers}` s ON s.id=d.seller_account_id LEFT JOIN `{$tbl_invoices}` i ON i.id=d.invoice_id WHERE d.status IN ('submitted','approved') ORDER BY d.id DESC LIMIT 50",ARRAY_A)?:[];}

// 3. PENGAMBILAN DATA REAL DARI FINANCIAL ENGINE PUSAT (NON-DUMMY)
$report = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'financial_report')
    ? PK01_Engine::financial_report($from, $to)
    : [];

$gross_sales          = (float)($report['gross_sales'] ?? 0);
$sales_company        = (float)($report['sales_company'] ?? 0);
$sales_seller         = (float)($report['sales_seller'] ?? 0);
$returns_amount       = (float)($report['returns'] ?? 0);
$total_hpp            = (float)($report['hpp'] ?? 0);
$affiliate_commission = (float)($report['affiliate_commission'] ?? 0);
$sales_commission     = (float)($report['sales_commission'] ?? 0);
$marketplace_fees     = (float)($report['marketplace_fees'] ?? 0);
$operational_cost     = (float)($report['operational_cost'] ?? 0);
$payroll_total        = (float)($report['payroll'] ?? 0);
$job_wages_total      = (float)($report['job_wages'] ?? 0);
$net_sales            = (float)($report['net_sales'] ?? ($gross_sales - $returns_amount));
$gross_profit         = (float)($report['gross_profit'] ?? ($net_sales - $total_hpp));
$net_profit           = (float)($report['net_profit'] ?? 0);
$depreciation         = (float)($report['depreciation'] ?? 0);
$inventory_write_down = (float)($report['inventory_write_down'] ?? 0);
$margin_percent       = (float)($report['margin'] ?? 0);
$cash_in_period       = (float)($report['cash_in'] ?? 0);
$cash_out_period      = (float)($report['cash_out'] ?? 0);
$cash_balance_now     = (float)($report['cash_balance'] ?? 0);
$selling_expenses     = $affiliate_commission + $sales_commission + $marketplace_fees;
$total_operating_cost = $operational_cost + $payroll_total + $job_wages_total + $selling_expenses;

// Piutang Seller Riil
$seller_invoiced = 0; $seller_paid = 0; $seller_receivable = 0;
if ($tbl_invoices) { 
    $seller_invoiced = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM `{$tbl_invoices}` WHERE DATE(created_at) BETWEEN %s AND %s", $from, $to)); 
}
if ($tbl_payments) { 
    $seller_paid = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$tbl_payments}` WHERE DATE(paid_at) BETWEEN %s AND %s", $from, $to)); 
}
$seller_receivable = max(0, $seller_invoiced - $seller_paid);

// Kalkulasi Rasio Finansial (Zero-Division Safe)
$gpm_percent       = $net_sales > 0 ? ($gross_profit / $net_sales) * 100 : 0;
$npm_percent       = $net_sales > 0 ? ($net_profit / $net_sales) * 100 : $margin_percent;
$hpp_percent       = $net_sales > 0 ? min(100, ($total_hpp / $net_sales) * 100) : 0;
$opex_percent      = $net_sales > 0 ? min(100, ($total_operating_cost / $net_sales) * 100) : 0;
$net_cash_flow     = $cash_in_period - $cash_out_period;
$seller_share_pct  = $gross_sales > 0 ? ($sales_seller / $gross_sales) * 100 : 0;

$rp = function($v) {
    if (class_exists('PK01_Settings') && method_exists('PK01_Settings', 'money')) {
        return PK01_Settings::money($v);
    }
    return 'Rp ' . number_format((float)$v, 0, ',', '.');
};

$print_url = function_exists('pk01_print_url') 
    ? pk01_print_url('keuangan', 0, ['from' => $from, 'to' => $to]) 
    : '';
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-purple:    #8b5cf6;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-fin-masterpiece {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-fin-masterpiece * { box-sizing: border-box; }

/* 1. Hero Cockpit Glassmorphism */
.pk01-fin-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-pill {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Filter Deck & Preset Chips */
.pk01-filter-deck {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 14px 18px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
    box-shadow: var(--pk-shadow);
}
.pk01-preset-chips {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.pk01-chip {
    padding: 6px 12px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    background: #ffffff;
    font-size: 12px;
    font-weight: 700;
    color: var(--pk-slate-600);
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-chip:hover { background: var(--pk-slate-100); color: var(--pk-slate-900); }
.pk01-chip.is-active { background: var(--pk-slate-900); color: #ffffff; border-color: var(--pk-slate-900); }

.pk01-date-form {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}
.pk01-ctrl-date {
    padding: 6px 10px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 12.5px;
    background: #f8fafc;
}

/* 3. Executive 4 KPI Cards Deck */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-amber); }
.pk01-kpi-card.c-purple::before { background: var(--pk-purple); }
.pk01-kpi-card.c-green::before  { background: var(--pk-emerald); }
.pk01-kpi-card.c-red::before    { background: var(--pk-rose); }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 22px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* 4. Visual Revenue Allocation Bar */
.pk01-alloc-banner {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 16px 20px;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-alloc-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    font-weight: 700;
    color: var(--pk-slate-800);
    margin-bottom: 8px;
}
.pk01-alloc-bar-wrap {
    height: 12px;
    border-radius: 6px;
    background: #e2e8f0;
    display: flex;
    overflow: hidden;
    margin-bottom: 8px;
}
.pk01-alloc-seg { height: 100%; transition: width 0.3s ease; }
.pk01-alloc-legend {
    display: flex;
    gap: 16px;
    font-size: 11.5px;
    color: var(--pk-slate-600);
    flex-wrap: wrap;
}

/* 5. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover { background: var(--pk-slate-100); color: var(--pk-slate-900); }
.pk01-tab-btn.is-active { background: var(--pk-slate-900); color: #ffffff; }

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Financial Structured List */
.pk01-pl-table {
    display: flex;
    flex-direction: column;
}
.pk01-pl-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #f1f5f9;
    font-size: 13px;
}
.pk01-pl-row span {
    color: var(--pk-slate-700);
    display: flex;
    align-items: center;
    gap: 6px;
}
.pk01-pl-row strong, .pk01-pl-row b {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}
.pk01-pl-row.is-highlight {
    background: #f8fafc;
    padding: 10px 12px;
    border-radius: 8px;
    font-weight: 700;
    color: #0f172a;
}
.pk01-pl-row.is-gross {
    background: #ecfdf5;
    padding: 12px 14px;
    border-radius: 8px;
    color: #065f46;
    font-weight: 800;
    font-size: 13.5px;
}
.pk01-pl-row.is-net {
    background: #eff6ff;
    padding: 16px 18px;
    border-radius: 12px;
    margin-top: 12px;
    border: 1px solid #bfdbfe;
}
.pk01-pl-row.is-net.loss {
    background: #fef2f2;
    border-color: #fecaca;
}

/* Interconnected Quick Action Button */
.pk01-link-pill {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 7px;
    border-radius: 4px;
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
    color: #475569;
    font-size: 11px;
    font-weight: 600;
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-link-pill:hover {
    background: var(--pk-indigo);
    color: #ffffff;
    border-color: var(--pk-indigo);
}

/* Buttons */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 16px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }
.pk01-btn-emerald { background: var(--pk-emerald); color: #ffffff !important; }
.pk01-btn-emerald:hover { background: #059669; }

.pk01-pill-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.badge-green { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.badge-red   { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
</style>

<div class="pk01-fin-masterpiece">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-fin-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">FINANCIAL CORE &bull; GENERAL LEDGER CONSOLIDATION</span>
            <h1>📈 Laporan Laba Rugi &amp; Arus Kas Bisnis</h1>
            <p>
                Konsolidasi finansial terpadu dan saling bersalaman dengan alur <strong>Penjualan Kasir, Gudang HPP, Beban Operasional, Payroll Gaji, Aset Tetap, dan Bagi Hasil Kemitraan [2].</strong>
            </p>
        </div>
        <div class="pk01-status-pill">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>FINANCIAL ENGINE SYNCHRONIZED</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;" id="pk01-live-clock">
                <?php echo date_i18n('d M Y'); ?> &bull; Data Riil Non-Dummy [2]
            </div>
        </div>
    </header>

    <!-- 2. DATE FILTER & PRESET CHIPS -->
    <div class="pk01-filter-deck">
        <div class="pk01-preset-chips">
            <span style="font-size:12px; font-weight:700; color:#64748b; align-self:center; margin-right:4px;">Pilih Periode:</span>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'today'])); ?>" class="pk01-chip <?php echo ($preset === 'today') ? 'is-active' : ''; ?>">Hari Ini [2]</a>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'this_month'])); ?>" class="pk01-chip <?php echo ($preset === 'this_month') ? 'is-active' : ''; ?>">Bulan Ini [2]</a>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'last_month'])); ?>" class="pk01-chip <?php echo ($preset === 'last_month') ? 'is-active' : ''; ?>">Bulan Lalu [2]</a>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'year'])); ?>" class="pk01-chip <?php echo ($preset === 'year') ? 'is-active' : ''; ?>">Tahun Ini [2]</a>
        </div>

        <form class="pk01-date-form" method="get">
            <input type="hidden" name="pk01_view" value="<?php echo esc_attr($_GET['pk01_view'] ?? 'finance'); ?>">
            <input type="date" name="from" class="pk01-ctrl-date" value="<?php echo esc_attr($from); ?>" required>
            <span style="font-size:12px; color:#64748b;">s/d</span>
            <input type="date" name="to" class="pk01-ctrl-date" value="<?php echo esc_attr($to); ?>" required>
            <button type="submit" class="pk01-btn pk01-btn-dark">Filter</button>
            <?php if ($print_url): ?>
                <a href="<?php echo esc_url($print_url); ?>" target="_blank" class="pk01-btn pk01-btn-subtle">
                    🖨️ Cetak PDF [2]
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- 3. EXECUTIVE 4 SCORECARDS DECK -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Penjualan Bersih (Net Revenue)</div>
            <div class="pk01-kpi-val" style="color:#4f46e5;"><?php echo esc_html($rp($net_sales)); ?></div>
            <div class="pk01-kpi-sub">Bruto <?php echo esc_html($rp($gross_sales)); ?> &minus; Retur <?php echo esc_html($rp($returns_amount)); ?> [2]</div>
        </div>

        <div class="pk01-kpi-card c-amber">
            <div class="pk01-kpi-label">Beban Pokok Penjualan (HPP)</div>
            <div class="pk01-kpi-val" style="color:#d97706;"><?php echo esc_html($rp($total_hpp)); ?></div>
            <div class="pk01-kpi-sub">Porsi Modal: <b><?php echo number_format($hpp_percent, 1); ?>%</b> dari omzet bersih [2]</div>
        </div>

        <div class="pk01-kpi-card c-purple">
            <div class="pk01-kpi-label">Total Beban Usaha (OPEX)</div>
            <div class="pk01-kpi-val" style="color:#7c3aed;"><?php echo esc_html($rp($total_operating_cost)); ?></div>
            <div class="pk01-kpi-sub">Operasional, Gaji Tim &amp; Fee Penjualan [2]</div>
        </div>

        <div class="pk01-kpi-card <?php echo ($net_profit >= 0) ? 'c-green' : 'c-red'; ?>">
            <div class="pk01-kpi-label">Laba Bersih Operasional</div>
            <div class="pk01-kpi-val" style="color:<?php echo ($net_profit >= 0) ? '#059669' : '#dc2626'; ?>;">
                <?php echo esc_html($rp($net_profit)); ?>
            </div>
            <div class="pk01-kpi-sub">
                <span class="pk01-pill-badge <?php echo ($net_profit >= 0) ? 'badge-green' : 'badge-red'; ?>">
                    ● Margin Bersih: <?php echo number_format($npm_percent, 1); ?>% [2]
                </span>
            </div>
        </div>
    </section>

    <!-- 4. VISUAL REVENUE ALLOCATION BANNER -->
    <?php if ($net_sales > 0): ?>
    <section class="pk01-alloc-banner">
        <div class="pk01-alloc-head">
            <span>Dekomposisi Penyerapan Omzet Bersih:</span>
            <span>Distribusi Setiap Rp 100 Penjualan [2]</span>
        </div>
        <div class="pk01-alloc-bar-wrap">
            <div class="pk01-alloc-seg" style="width:<?php echo $hpp_percent; ?>%; background:#d97706;" title="HPP: <?php echo number_format($hpp_percent, 1); ?>%"></div>
            <div class="pk01-alloc-seg" style="width:<?php echo min(100 - $hpp_percent, $opex_percent); ?>%; background:#7c3aed;" title="Opex & Gaji: <?php echo number_format($opex_percent, 1); ?>%"></div>
            <div class="pk01-alloc-seg" style="width:<?php echo max(0, min(100, $npm_percent)); ?>%; background:#10b981;" title="Laba Bersih: <?php echo number_format($npm_percent, 1); ?>%"></div>
        </div>
        <div class="pk01-alloc-legend">
            <span><b style="color:#d97706;">■</b> Modal HPP Produk (<?php echo number_format($hpp_percent, 1); ?>%) [2]</span>
            <span><b style="color:#7c3aed;">■</b> Beban Operasional &amp; Gaji (<?php echo number_format($opex_percent, 1); ?>%) [2]</span>
            <span><b style="color:#10b981;">■</b> Margin Laba Bersih (<?php echo number_format($npm_percent, 1); ?>%) [2]</span>
        </div>
    </section>
    <?php endif; ?>

    <!-- 5. TABS NAVIGASI SUB-MENU -->
    <nav class="pk01-nav-tabs" aria-label="Menu Keuangan">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-pl">
            📑 Laporan Laba Rugi Komprehensif
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-cash">
            💳 Arus Kas &amp; Likuiditas Riil
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-seller">
            🤝 Rekonsiliasi Mitra Seller &amp; Piutang
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-cashier-deposits">💰 Setoran Kasir</button>
        <button type="button" class="pk01-tab-btn" data-target="tab-ecosystem">
            🔗 Peta Interkoneksi Modul (Saling Bersalaman)
        </button>
    </nav>

    <!-- 6. TAB 1: LAPORAN LABA RUGI KOMPREHENSIF -->
    <div class="pk01-pane is-active" id="tab-pl">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📑 Laporan Laba Rugi Komprehensif (P&amp;L Statement)</h3>
                    <div style="font-size:12.5px; color:#64748b; margin-top:3px;">
                        Setiap pos akun terhubung langsung ke modul transaksional masing-masing.
                    </div>
                </div>
                <span class="pk01-pill-badge badge-green" style="font-size:12px; padding:6px 12px;">
                    Laba Bersih: <?php echo esc_html($rp($net_profit)); ?> [2]
                </span>
            </div>

            <div class="pk01-pl-table">
                <!-- Pendapatan -->
                <div class="pk01-pl-row">
                    <span>
                        🛒 Penjualan Kotor (Gross Sales)
                        <a href="<?php echo esc_url($url_helper('sales_hub')); ?>" class="pk01-link-pill">Lihat Order &rarr;</a>
                    </span>
                    <strong><?php echo esc_html($rp($gross_sales)); ?></strong>
                </div>
                <div class="pk01-pl-row">
                    <span>↩️ Retur Barang &amp; Pengembalian Dana</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($returns_amount)); ?></strong>
                </div>
                <div class="pk01-pl-row is-highlight">
                    <span>🛒 Penjualan Bersih (Net Revenue)</span>
                    <strong style="color:#4f46e5; font-size:14.5px;"><?php echo esc_html($rp($net_sales)); ?></strong>
                </div>

                <!-- HPP -->
                <div class="pk01-pl-row" style="margin-top:6px;">
                    <span>
                        🧱 Harga Pokok Penjualan (HPP Bahan &amp; Produk Jadi)
                        <a href="<?php echo esc_url($url_helper('materials')); ?>" class="pk01-link-pill">Gudang Bahan &rarr;</a> [2]
                    </span>
                    <strong style="color:#d97706;">&minus; <?php echo esc_html($rp($total_hpp)); ?></strong>
                </div>
                <div class="pk01-pl-row">
                    <span>🏷️ Fee Transaksi &amp; Layanan Marketplace</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($marketplace_fees)); ?></strong>
                </div>
                <div class="pk01-pl-row">
                    <span>🤝 Komisi Mitra Seller &amp; Afiliasi</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($selling_expenses - $marketplace_fees)); ?></strong>
                </div>

                <!-- Laba Kotor -->
                <div class="pk01-pl-row is-gross" style="margin-top:6px;">
                    <span>Laba Kotor Penjualan (Gross Profit)</span>
                    <span><?php echo esc_html($rp($gross_profit)); ?></span>
                </div>

                <!-- Beban Operasional -->
                <div class="pk01-pl-row" style="margin-top:8px;">
                    <span>
                        🏢 Biaya Usaha &amp; Operasional Kantor
                        <a href="<?php echo esc_url($url_helper('operational_costs')); ?>" class="pk01-link-pill">Buku Biaya &rarr;</a>
                    </span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($operational_cost)); ?></strong>
                </div>
                <div class="pk01-pl-row">
                    <span>
                        👥 Gaji Staf Karyawan (Payroll)
                        <a href="<?php echo esc_url($url_helper('payroll')); ?>" class="pk01-link-pill">Payroll Staf &rarr;</a>
                    </span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($payroll_total)); ?></strong>
                </div>
                <div class="pk01-pl-row">
                    <span>
                        🔧 Upah Borongan Job Produksi SPK
                        <a href="<?php echo esc_url($url_helper('production_hub')); ?>" class="pk01-link-pill">SPK Pabrik &rarr;</a>
                    </span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($job_wages_total)); ?></strong>
                </div>

                <?php if ($depreciation > 0): ?>
                <div class="pk01-pl-row">
                    <span>
                        🏭 Penyusutan Aset Tetap (Amortisasi Non-Kas)
                        <a href="<?php echo esc_url($url_helper('fixed_assets')); ?>" class="pk01-link-pill">Register Aset &rarr;</a> [1]
                    </span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($depreciation)); ?></strong>
                </div>
                <?php endif; ?>

                <?php if ($inventory_write_down > 0): ?>
                <div class="pk01-pl-row">
                    <span>📉 Penurunan Nilai Persediaan (Write-Down)</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($inventory_write_down)); ?></strong>
                </div>
                <?php endif; ?>

                <!-- Laba Bersih Akhir -->
                <div class="pk01-pl-row is-net <?php echo ($net_profit < 0) ? 'loss' : ''; ?>">
                    <div>
                        <strong style="font-size:16px; color:<?php echo ($net_profit >= 0) ? '#065f46' : '#991b1b'; ?>; display:block;">
                            Laba Bersih Operasional (Net Profit) [2]
                        </strong>
                        <div style="font-size:12px; color:#64748b; margin-top:2px;">
                            Siap dialokasikan ke pembagian laba kemitraan [2].
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <strong style="font-size:22px; color:<?php echo ($net_profit >= 0) ? '#059669' : '#dc2626'; ?>;">
                            <?php echo esc_html($rp($net_profit)); ?>
                        </strong>
                        <div style="margin-top:4px;">
                            <a href="<?php echo esc_url($url_helper('equity')); ?>" class="pk01-btn pk01-btn-dark" style="font-size:11px; padding:4px 10px;">
                                ⚖️ Eksekusi Bagi Hasil Kemitraan &rarr;
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 7. TAB 2: BUKU KAS & LIKUIDITAS RIIL -->
    <div class="pk01-pane" id="tab-cash">
        <div style="display:grid; grid-template-columns:1.2fr 1fr; gap:20px; align-items:start;">
            
            <!-- Aliran Kas Masuk & Keluar -->
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>💳 Arus Kas Masuk &amp; Keluar (Cash Ledger) [2]</h3>
                        <div style="font-size:12px; color:#64748b; margin-top:2px;">Mutasi fisik kas tunai &amp; rekening bank toko [2].</div>
                    </div>
                </div>

                <div class="pk01-pl-table">
                    <div class="pk01-pl-row">
                        <span>Total Uang Masuk Kas (Inflow) [2]</span>
                        <strong style="color:#059669;">+ <?php echo esc_html($rp($cash_in_period)); ?></strong>
                    </div>
                    <div class="pk01-pl-row">
                        <span>Total Uang Keluar Kas (Outflow) [2]</span>
                        <strong style="color:#dc2626;">&minus; <?php echo esc_html($rp($cash_out_period)); ?></strong>
                    </div>
                    <div class="pk01-pl-row is-highlight" style="margin-top:6px;">
                        <span>Surplus / Defisit Kas Berjalan [2]</span>
                        <strong style="color:<?php echo ($net_cash_flow >= 0) ? '#059669' : '#dc2626'; ?>;">
                            <?php echo ($net_cash_flow >= 0 ? '+' : '') . esc_html($rp($net_cash_flow)); ?> [2]
                        </strong>
                    </div>
                    
                    <div class="pk01-pl-row is-net" style="margin-top:14px;">
                        <div>
                            <strong style="font-size:14px; color:#0f172a; display:block;">Saldo Kas &amp; Bank Terkini [2]</strong>
                            <small style="color:#64748b;">Akumulasi seluruh akun kas toko [2]</small>
                        </div>
                        <strong style="font-size:20px; color:#0284c7;">
                            <?php echo esc_html($rp($cash_balance_now)); ?> [2]
                        </strong>
                    </div>
                </div>
            </div>

            <!-- Panduan Kas vs Laba -->
            <div class="pk01-surface" style="background:#f8fafc;">
                <div class="pk01-surface-header">
                    <div>
                        <h3>💡 Pemisahan Kas vs Laba Bersih [2]</h3>
                    </div>
                </div>
                <div style="font-size:13px; color:#475569; line-height:1.6;">
                    <p style="margin-top:0;">
                        <b>Mengapa Saldo Kas Berbeda dengan Laba Bersih?</b> [2]
                    </p>
                    <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px; margin-bottom:12px;">
                        <ul style="margin:0; padding-left:18px;">
                            <li><b>Belanja Aset Mesin:</b> Memotong kas sekarang, tetapi disusutkan bertahap tiap bulan [1, 2].</li>
                            <li><b>Stok Bahan Baku:</b> Memotong kas saat dibeli, tetapi baru menjadi beban (HPP) saat terjual [2].</li>
                            <li><b>Piutang Pelanggan:</b> Sudah terhitung omzet penjualan, namun kas fisik belum diterima [2].</li>
                        </ul>
                    </div>
                    <a href="<?php echo esc_url($url_helper('finance_hub')); ?>" class="pk01-btn pk01-btn-dark" style="width:100%; text-align:center;">
                        Buka Buku Kas Harian &rarr;
                    </a>
                </div>
            </div>

        </div>
    </div>

    <!-- 8. TAB 3: REKONSILIASI MITRA SELLER & PIUTANG -->
    <div class="pk01-pane" id="tab-seller">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🤝 Rekonsiliasi Mitra Seller &amp; Piutang Konsinyasi [2]</h3>
                    <div style="font-size:12px; color:#64748b; margin-top:2px;">
                        Pengawasan penjualan melalui channel reseller, afiliasi, dan konsinyasi [2].
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
                <!-- Komposisi Kanal -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px;">
                    <h4 style="margin:0 0 12px; font-size:15px; font-weight:800; color:#0f172a;">Komposisi Sumber Omzet [2]</h4>
                    <div class="pk01-pl-table">
                        <div class="pk01-pl-row">
                            <span>Penjualan Langsung Toko &amp; Web [2]</span>
                            <strong><?php echo esc_html($rp($sales_company)); ?></strong>
                        </div>
                        <div class="pk01-pl-row">
                            <span>Penjualan Mitra Seller &amp; Konsinyasi [2]</span>
                            <strong><?php echo esc_html($rp($sales_seller)); ?></strong>
                        </div>
                        <div class="pk01-pl-row is-highlight" style="margin-top:8px;">
                            <span>Kontribusi Omzet Jalur Mitra [2]</span>
                            <strong style="color:#4f46e5;"><?php echo number_format($seller_share_pct, 1); ?>% [2]</strong>
                        </div>
                    </div>
                </div>

                <!-- Piutang Seller -->
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:14px; padding:20px;">
                    <h4 style="margin:0 0 12px; font-size:15px; font-weight:800; color:#0f172a;">Status Piutang Invoice Seller [2]</h4>
                    <div class="pk01-pl-table">
                        <div class="pk01-pl-row">
                            <span>Tagihan Invoice Seller Diterbitkan [2]</span>
                            <strong><?php echo esc_html($rp($seller_invoiced)); ?></strong>
                        </div>
                        <div class="pk01-pl-row">
                            <span>Setoran Dana Kas Masuk dari Seller [2]</span>
                            <strong style="color:#059669;">&minus; <?php echo esc_html($rp($seller_paid)); ?></strong>
                        </div>
                        <div class="pk01-pl-row is-net loss" style="margin-top:8px;">
                            <div>
                                <strong style="font-size:14px; color:#991b1b; display:block;">Sisa Piutang Belum Disetor [2]</strong>
                                <small style="color:#64748b;">Dana tertahan pada reseller [2]</small>
                            </div>
                            <strong style="font-size:18px; color:#dc2626;">
                                <?php echo esc_html($rp($seller_receivable)); ?> [2]
                            </strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SETORAN KASIR -> KEUANGAN -->
    <div class="pk01-pane" id="tab-cashier-deposits">
        <div class="pk01-surface">
            <div class="pk01-surface-header"><div><h3>💰 Setoran Kasir → Penerimaan Keuangan</h3><div style="font-size:12px;color:#64748b;margin-top:2px">Maker-checker: Kasir mengajukan nominal → Keuangan menyetujui nilai → Keuangan menerima/membukukan. Transfer Seller baru menjadi pembayaran resmi setelah Keuangan menerima.</div></div></div>
            <?php echo $cashier_deposit_notice; ?>
            <?php if(empty($pending_cashier_deposits)): ?><div style="padding:16px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:10px;color:#64748b">Belum ada setoran Kasir yang menunggu penerimaan.</div><?php else: ?>
            <div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr><th>Setoran</th><th>Kasir</th><th>Jenis</th><th>Referensi</th><th>Nominal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
            <?php foreach($pending_cashier_deposits as $d): ?><tr><td style="padding:9px;border-bottom:1px solid #e2e8f0"><b><?php echo esc_html($d['deposit_no']); ?></b><small style="display:block;color:#64748b"><?php echo esc_html($d['submitted_at']); ?></small></td><td style="padding:9px;border-bottom:1px solid #e2e8f0"><?php echo esc_html($d['cashier_name']?:'-'); ?></td><td style="padding:9px;border-bottom:1px solid #e2e8f0"><?php echo esc_html($d['deposit_type']==='cash'?'Kas Tunai':'Transfer Seller'); ?></td><td style="padding:9px;border-bottom:1px solid #e2e8f0"><?php echo esc_html($d['reference_no']?:($d['invoice_no']?:'-')); ?></td><td style="padding:9px;border-bottom:1px solid #e2e8f0"><b>Rp <?php echo number_format((float)$d['amount'],0,',','.'); ?></b></td><td style="padding:9px;border-bottom:1px solid #e2e8f0"><?php echo esc_html($d['status']==='approved'?'Disetujui':'Menunggu Persetujuan'); ?><?php if(!empty($d['approved_by'])): ?><small style="display:block;color:#64748b">Oleh #<?php echo (int)$d['approved_by']; ?></small><?php endif; ?></td><td style="padding:9px;border-bottom:1px solid #e2e8f0"><div style="display:flex;gap:5px;flex-wrap:wrap"><?php if($d['status']==='submitted'): ?><form method="post"><?php echo wp_nonce_field('pk01_approve_cashier_deposit','pk01_cashier_deposit_approval_nonce',true,false); ?><input type="hidden" name="deposit_id" value="<?php echo (int)$d['id']; ?>"><input name="approval_note" placeholder="Catatan persetujuan" style="width:150px;padding:6px;border:1px solid #cbd5e1;border-radius:7px"><button class="pk01-op-button is-small" name="pk01_approve_cashier_deposit" value="1" type="submit">✓ Setujui Nilai</button></form><?php else: ?><form method="post" style="display:flex;gap:5px;flex-wrap:wrap"><?php echo wp_nonce_field('pk01_receive_cashier_deposit','pk01_cashier_deposit_receive_nonce',true,false); ?><input type="hidden" name="deposit_id" value="<?php echo (int)$d['id']; ?>"><input name="destination_account" value="<?php echo esc_attr($d['destination_account']); ?>" style="width:150px;padding:6px;border:1px solid #cbd5e1;border-radius:7px"><button class="pk01-op-button is-small" name="pk01_receive_cashier_deposit" value="1" type="submit">✓ Terima &amp; Bukukan</button></form><?php endif; ?><form method="post" style="display:flex;gap:5px;flex-wrap:wrap"><?php echo wp_nonce_field('pk01_receive_cashier_deposit','pk01_cashier_deposit_receive_nonce',true,false); ?><input type="hidden" name="deposit_id" value="<?php echo (int)$d['id']; ?>"><input name="rejection_reason" placeholder="Alasan jika ditolak" style="width:150px;padding:6px;border:1px solid #cbd5e1;border-radius:7px"><button class="pk01-op-button is-small" name="pk01_reject_cashier_deposit" value="1" type="submit" style="background:#fff7ed;color:#9a3412">Tolak</button></form></div></td></tr><?php endforeach; ?>
            </tbody></table></div><?php endif; ?>
            <div style="margin-top:12px;padding:12px;background:#f8fafc;border-radius:10px;font-size:12px;color:#475569"><b>Aturan:</b> penerimaan cash adalah perpindahan internal dari akun Kasir ke akun Keuangan, bukan pendapatan baru. Transfer Seller yang sudah masuk Buku Kas tidak boleh dibuatkan kas masuk kedua.</div>
        </div>
    </div>

    <!-- 9. TAB 4: PETA INTEGRASI (SALING BERSALAMAN) -->
    <div class="pk01-pane" id="tab-ecosystem">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🔗 Peta Alur Finansial PK01 (Saling Bersalaman) [2]</h3>
                    <div style="font-size:12px; color:#64748b; margin-top:2px;">
                        Setiap modul saling menyalurkan data secara otomatis tanpa input ganda.
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:18px;">
                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🛒 &rarr; 📈</div>
                    <h4 style="margin:0 0 6px; font-size:14px; font-weight:800; color:#0f172a;">Kasir &amp; Faktur Penjualan</h4>
                    <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0 0 10px;">
                        Pesanan selesai otomatis mengalir ke baris <strong>Penjualan Bersih</strong> dan mencatat uang masuk ke Buku Kas [2].
                    </p>
                    <a href="<?php echo esc_url($url_helper('sales_hub')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">Buka Penjualan &rarr;</a>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🪵 &rarr; 🧱</div>
                    <h4 style="margin:0 0 6px; font-size:14px; font-weight:800; color:#0f172a;">Gudang Bahan &amp; HPP</h4>
                    <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0 0 10px;">
                        Bahan yang dikeluarkan untuk pesanan otomatis dikalkulasikan sebagai <strong>Beban HPP Pokok</strong> [2].
                    </p>
                    <a href="<?php echo esc_url($url_helper('materials')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">Buka Master Bahan &rarr; [2]</a>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">👥 &rarr; 💰</div>
                    <h4 style="margin:0 0 6px; font-size:14px; font-weight:800; color:#0f172a;">Payroll &amp; Borongan</h4>
                    <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0 0 10px;">
                        Gaji bulanan dan upah borongan SPK tercatat otomatis sebagai <strong>Beban Gaji Tenaga Kerja</strong> [2].
                    </p>
                    <a href="<?php echo esc_url($url_helper('payroll')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">Buka Payroll Gaji &rarr;</a>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px;">
                    <div style="font-size:24px; margin-bottom:8px;">🏆 &rarr; 🤝</div>
                    <h4 style="margin:0 0 6px; font-size:14px; font-weight:800; color:#0f172a;">Bagi Hasil Kemitraan 50:50</h4>
                    <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0 0 10px;">
                        Laba bersih riil dialirkan langsung ke modul <strong>Bagi Hasil Kemitraan</strong> untuk dibagikan antara Pengelola &amp; Investor.
                    </p>
                    <a href="<?php echo esc_url($url_helper('equity')); ?>" style="font-size:12px; font-weight:700; color:var(--pk-indigo); text-decoration:none;">Buka Bagi Hasil &rarr;</a>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }
});
</script>