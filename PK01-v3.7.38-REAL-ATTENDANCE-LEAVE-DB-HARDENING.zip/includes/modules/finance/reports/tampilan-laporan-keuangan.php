<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array)$current_user->roles, true);
if (!$is_admin && (!class_exists('PK01_Authorization') || !PK01_Authorization::can_action('finance_reports', 'view'))) {
    echo '<div style="max-width:540px;margin:40px auto;padding:24px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.05);font-family:sans-serif;">
            <div style="font-size:36px;margin-bottom:8px;">⚠️</div>
            <strong style="font-size:16px;">Akses Ditolak</strong>
            <p style="margin:6px 0 0;font-size:13px;color:#7f1d1d;">Anda tidak memiliki izin otorisasi untuk melihat laporan keuangan usaha.</p>
          </div>'; 
    return;
}

// 2. LOGIKA PERIODE CEPAT (PRESET DATE LOGIC)
$today  = current_time('Y-m-d');
$preset = sanitize_key($_GET['preset'] ?? '');

if ($preset === 'today') {
    $from = $today;
    $to   = $today;
} elseif ($preset === 'last_month') {
    $from = date('Y-m-01', strtotime('-1 month', current_time('timestamp')));
    $to   = date('Y-m-t', strtotime('-1 month', current_time('timestamp')));
} elseif ($preset === 'year') {
    $from = current_time('Y-01-01');
    $to   = $today;
} elseif ($preset === 'this_month' || empty($_GET['from'])) {
    $from = current_time('Y-m-01');
    $to   = $today;
    $preset = 'this_month';
} else {
    $from = sanitize_text_field(wp_unslash($_GET['from'] ?? current_time('Y-m-01')));
    $to   = sanitize_text_field(wp_unslash($_GET['to'] ?? current_time('Y-m-d')));
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = current_time('Y-m-01');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = current_time('Y-m-d');

// Helper DB & Finansial
$T = function($k) use ($wpdb) { return class_exists('PK01_DB') && method_exists('PK01_DB','t') ? PK01_DB::t($k) : $wpdb->prefix.'pk01_'.$k; };
$exists = function($t) use ($wpdb) { return $t && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t; };
$money = function($v) { return 'Rp ' . number_format((float)$v, 0, ',', '.'); };

$start = $from . ' 00:00:00'; 
$end   = $to . ' 23:59:59';
$report = (class_exists('PK01_Engine') && method_exists('PK01_Engine','financial_report')) ? PK01_Engine::financial_report($from, $to) : [];

// 3. KUERI ARUS KAS RIIL (CASH LEDGER TRANSAKSI)
$cash = $T('cash_ledger');
$in_rows = []; 
$out_rows = [];

if ($exists($cash)) {
    $in_rows = $wpdb->get_results($wpdb->prepare(
        "SELECT COALESCE(NULLIF(category,''),'Lainnya') AS category, SUM(amount) AS total 
         FROM `{$cash}` 
         WHERE direction='in' AND created_at BETWEEN %s AND %s 
         GROUP BY category ORDER BY total DESC",
        $start, $end
    ), ARRAY_A) ?: [];

    $out_rows = $wpdb->get_results($wpdb->prepare(
        "SELECT COALESCE(NULLIF(category,''),'Lainnya') AS category, SUM(amount) AS total 
         FROM `{$cash}` 
         WHERE direction='out' AND created_at BETWEEN %s AND %s 
         GROUP BY category ORDER BY total DESC",
        $start, $end
    ), ARRAY_A) ?: [];
}

$cash_in  = (float)($report['cash_in'] ?? 0); 
$cash_out = (float)($report['cash_out'] ?? 0); 
$cash_net = $cash_in - $cash_out;

// 4. METRIK LABA RUGI RIIL
$operational = (float)($report['operational_cost'] ?? 0);
$payroll     = (float)($report['payroll'] ?? 0);
$job_wages   = (float)($report['job_wages'] ?? 0);
$hpp         = (float)($report['hpp'] ?? 0);
$net_sales   = (float)($report['net_sales'] ?? 0);
$gross_profit= (float)($report['gross_profit'] ?? ($net_sales - $hpp));
$profit      = (float)($report['net_profit'] ?? 0);

// Kalkulasi Rasio & Margin Laba Bersih
$margin_pct = ($net_sales > 0) ? round(($profit / $net_sales) * 100, 1) : 0;
$total_expenses = $hpp + $operational + $payroll + $job_wages;

$pct_hpp  = ($total_expenses > 0) ? min(100, round(($hpp / $total_expenses) * 100)) : 0;
$pct_team = ($total_expenses > 0) ? min(100, round((($payroll + $job_wages) / $total_expenses) * 100)) : 0;
$pct_ops  = ($total_expenses > 0) ? max(0, 100 - $pct_hpp - $pct_team) : 0;

// URL Cetak PDF Aman
$pdf_url = function_exists('pk01_print_url') ? pk01_print_url('keuangan', 0, ['from' => $from, 'to' => $to]) : '';
?>

<style>
:root {
    --pk-slate-950: #090d16;
    --pk-slate-900: #0f172a;
    --pk-slate-800: #1e293b;
    --pk-slate-700: #334155;
    --pk-slate-600: #475569;
    --pk-slate-200: #e2e8f0;
    --pk-slate-100: #f1f5f9;
    --pk-slate-50:  #f8fafc;
    --pk-indigo:    #4f46e5;
    --pk-indigo-hover: #4338ca;
    --pk-emerald:   #10b981;
    --pk-amber:     #f59e0b;
    --pk-rose:      #ef4444;
    --pk-sky:       #0284c7;
    --pk-shadow:    0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
}

.pk01-fin-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 15px auto 50px;
}
.pk01-fin-app * { box-sizing: border-box; }

/* 1. Hero Cockpit Glassmorphism */
.pk01-fin-hero {
    background: linear-gradient(135deg, var(--pk-slate-950) 0%, var(--pk-slate-900) 50%, #1e1b4b 100%);
    border-radius: 18px;
    padding: 26px 32px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 22px;
    box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.pk01-hero-left h1 {
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
    margin: 6px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.pk01-hero-left p {
    font-size: 13.5px;
    color: #94a3b8;
    margin: 0;
    max-width: 780px;
    line-height: 1.5;
}
.pk01-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(99, 102, 241, 0.25);
    border: 1px solid rgba(165, 180, 252, 0.35);
    color: #c7d2fe;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
.pk01-status-widget {
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 12px 20px;
    text-align: right;
    backdrop-filter: blur(6px);
}
.pk01-ping-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #4ade80;
    box-shadow: 0 0 8px #4ade80;
    animation: pkPulseGreen 2s infinite;
}
@keyframes pkPulseGreen {
    0% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(74, 222, 128, 0); }
    100% { box-shadow: 0 0 0 0 rgba(74, 222, 128, 0); }
}

/* 2. Executive 4 KPI Cards */
.pk01-kpi-deck {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}
@media (max-width: 992px) { .pk01-kpi-deck { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 540px) { .pk01-kpi-deck { grid-template-columns: 1fr; } }

.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 18px 20px;
    box-shadow: var(--pk-shadow);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; width: 4px;
}
.pk01-kpi-card.c-green::before  { background: var(--pk-emerald); }
.pk01-kpi-card.c-red::before    { background: var(--pk-rose); }
.pk01-kpi-card.c-blue::before   { background: var(--pk-indigo); }
.pk01-kpi-card.c-purple::before { background: #8b5cf6; }

.pk01-kpi-label { font-size: 11px; font-weight: 700; color: var(--pk-slate-600); text-transform: uppercase; letter-spacing: 0.5px; }
.pk01-kpi-val { font-size: 22px; font-weight: 800; color: var(--pk-slate-900); margin: 6px 0 2px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.pk01-kpi-sub { font-size: 11.5px; color: var(--pk-slate-600); }

/* Filter Toolbar */
.pk01-filter-deck {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 14px 18px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
    box-shadow: var(--pk-shadow);
}
.pk01-preset-chips {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.pk01-chip {
    padding: 6px 12px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    background: #ffffff;
    font-size: 12px;
    font-weight: 700;
    color: var(--pk-slate-600);
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.pk01-chip:hover { background: var(--pk-slate-100); color: var(--pk-slate-900); }
.pk01-chip.is-active { background: var(--pk-slate-900); color: #ffffff; border-color: var(--pk-slate-900); }

.pk01-filter-custom {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}
.pk01-ctrl-date {
    padding: 6px 10px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 12.5px;
    background: #f8fafc;
}

/* 3. Modern Scrollable Tabs */
.pk01-nav-tabs {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 14px;
    padding: 6px;
    display: flex;
    gap: 6px;
    overflow-x: auto;
    margin-bottom: 22px;
    box-shadow: var(--pk-shadow);
}
.pk01-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 700;
    color: var(--pk-slate-600);
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 10px;
    white-space: nowrap;
    transition: all 0.15s ease;
}
.pk01-tab-btn:hover { background: var(--pk-slate-100); color: var(--pk-slate-900); }
.pk01-tab-btn.is-active { background: var(--pk-slate-900); color: #ffffff; }

/* Panes */
.pk01-pane { display: none; }
.pk01-pane.is-active { display: block; animation: pk01FadeIn 0.25s ease-out; }
@keyframes pk01FadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Surfaces */
.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-slate-200);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: var(--pk-shadow);
}
.pk01-surface-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--pk-slate-100);
    padding-bottom: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
    gap: 12px;
}
.pk01-surface-header h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: var(--pk-slate-900);
    display: flex;
    align-items: center;
    gap: 8px;
}
.pk01-surface-desc {
    font-size: 12.5px;
    color: var(--pk-slate-600);
    margin-top: 3px;
}

/* Insight Comparison Box */
.pk01-insight-box {
    background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
    border: 1px solid #c7d2fe;
    border-radius: 14px;
    padding: 18px 22px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}
.pk01-insight-text { font-size: 13px; color: #334155; line-height: 1.6; max-width: 820px; }

/* Financial Row Lists */
.pk01-flow-list {
    display: flex;
    flex-direction: column;
}
.pk01-flow-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f1f5f9;
    font-size: 13px;
}
.pk01-flow-row:last-child { border-bottom: none; }
.pk01-flow-row span { color: var(--pk-slate-700); font-weight: 600; display: flex; align-items: center; gap: 8px; }
.pk01-flow-row strong {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 14px;
    color: var(--pk-slate-900);
}
.pk01-flow-row.total-row {
    margin-top: 8px;
    padding-top: 14px;
    border-top: 2px solid var(--pk-slate-200);
    font-weight: 800;
}

/* Spending Visual Bar */
.pk01-spend-bar-wrap {
    height: 14px;
    border-radius: 7px;
    background: #e2e8f0;
    display: flex;
    overflow: hidden;
    margin: 12px 0 10px;
}
.pk01-spend-segment { height: 100%; transition: width 0.3s ease; }
.pk01-spend-legend {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    color: #64748b;
    flex-wrap: wrap;
    gap: 10px;
}

/* Buttons & Badges */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 16px;
    font-size: 12.5px;
    font-weight: 700;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
    transition: all 0.2s ease;
}
.pk01-btn-dark { background: var(--pk-slate-900); color: #ffffff !important; }
.pk01-btn-dark:hover { background: var(--pk-slate-800); }
.pk01-btn-subtle { background: #ffffff; color: var(--pk-slate-700) !important; border: 1px solid #cbd5e1; }
.pk01-btn-subtle:hover { background: var(--pk-slate-50); border-color: #94a3b8; }

.pk01-pill {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
}
.pill-green { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.pill-amber { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
.pill-red   { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
</style>

<div class="pk01-fin-app">

    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-fin-hero">
        <div class="pk01-hero-left">
            <span class="pk01-hero-badge">EXECUTIVE FINANCE &bull; CASH &amp; PROFIT MONITOR</span>
            <h1>📊 Laporan Keuangan Sederhana</h1>
            <p>
                Dirancang khusus untuk pemilik usaha non-akuntansi. Menjawab 4 pertanyaan inti: <strong>Dari mana uang masuk, ke mana uang keluar, berapa sisa kas fisik, dan apakah usaha menghasilkan untung atau rugi.</strong>
            </p>
        </div>
        <div class="pk01-status-widget">
            <div style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#4ade80;">
                <span class="pk01-ping-dot"></span>
                <span>LAPORAN FINANSIAL TERVERIFIKASI</span>
            </div>
            <div style="font-size:11px; color:#cbd5e1; margin-top:3px;" id="pk01-fin-clock">
                <?php echo date_i18n('d M Y'); ?> &bull; Data Riil
            </div>
        </div>
    </header>

    <!-- 2. PILIHAN PERIODE CEPAT (PRESET TOOLBAR) -->
    <div class="pk01-filter-deck">
        <div class="pk01-preset-chips">
            <span style="font-size:12px; font-weight:700; color:#64748b; align-self:center; margin-right:4px;">Periode Kilat:</span>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'today'])); ?>" class="pk01-chip <?php echo ($preset === 'today') ? 'is-active' : ''; ?>">Hari Ini</a>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'this_month'])); ?>" class="pk01-chip <?php echo ($preset === 'this_month') ? 'is-active' : ''; ?>">Bulan Ini</a>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'last_month'])); ?>" class="pk01-chip <?php echo ($preset === 'last_month') ? 'is-active' : ''; ?>">Bulan Lalu</a>
            <a href="<?php echo esc_url(add_query_arg(['preset' => 'year'])); ?>" class="pk01-chip <?php echo ($preset === 'year') ? 'is-active' : ''; ?>">Tahun Ini</a>
        </div>

        <form class="pk01-filter-custom" method="get">
            <?php foreach ($_GET as $k => $v) { 
                if (in_array($k, ['from', 'to', 'preset'], true)) continue; 
                if (is_scalar($v)) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr(wp_unslash($v)) . '">'; 
            } ?>
            <input type="date" name="from" class="pk01-ctrl-date" value="<?php echo esc_attr($from); ?>">
            <span style="font-size:12px; color:#64748b;">s/d</span>
            <input type="date" name="to" class="pk01-ctrl-date" value="<?php echo esc_attr($to); ?>">
            <button type="submit" class="pk01-btn pk01-btn-dark">Tampilkan</button>
            <?php if ($pdf_url): ?>
                <a href="<?php echo esc_url($pdf_url); ?>" target="_blank" class="pk01-btn pk01-btn-subtle">
                    🖨️ Cetak PDF
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- 3. EXECUTIVE 4 KPI CARDS -->
    <section class="pk01-kpi-deck">
        <div class="pk01-kpi-card c-green">
            <div class="pk01-kpi-label">Total Uang Masuk Kas</div>
            <div class="pk01-kpi-val" style="color:#059669;"><?php echo esc_html($money($cash_in)); ?></div>
            <div class="pk01-kpi-sub">Penerimaan kas/bank nyata</div>
        </div>

        <div class="pk01-kpi-card c-red">
            <div class="pk01-kpi-label">Total Uang Keluar Kas</div>
            <div class="pk01-kpi-val" style="color:#dc2626;"><?php echo esc_html($money($cash_out)); ?></div>
            <div class="pk01-kpi-sub">Pengeluaran kas/bank fisik</div>
        </div>

        <div class="pk01-kpi-card c-blue">
            <div class="pk01-kpi-label">Perubahan Sisa Kas Fisik</div>
            <div class="pk01-kpi-val" style="<?php echo ($cash_net >= 0) ? 'color:#4f46e5;' : 'color:#dc2626;'; ?>">
                <?php echo esc_html($money($cash_net)); ?>
            </div>
            <div class="pk01-kpi-sub">Uang Masuk &minus; Uang Keluar</div>
        </div>

        <div class="pk01-kpi-card c-purple">
            <div class="pk01-kpi-label">Laba Bersih Usaha (Net Profit)</div>
            <div class="pk01-kpi-val" style="<?php echo ($profit >= 0) ? 'color:#7c3aed;' : 'color:#dc2626;'; ?>">
                <?php echo esc_html($money($profit)); ?>
            </div>
            <div class="pk01-kpi-sub">
                <?php if ($profit > 0): ?>
                    <span class="pk01-pill pill-green">● Margin: +<?php echo $margin_pct; ?>% (Untung)</span>
                <?php else: ?>
                    <span class="pk01-pill pill-red">● Defisit / Rugi</span>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 4. INSIGHT BOX: KAS VS LABA (PANDUAN NON-AKUNTANSI) -->
    <div class="pk01-insight-box">
        <div class="pk01-insight-text">
            💡 <strong>Penting Dipahami:</strong> <u>Perubahan Uang Kas (<?php echo esc_html($money($cash_net)); ?>)</u> berbeda dengan <u>Laba Bersih Usaha (<?php echo esc_html($money($profit)); ?>)</u>. Uang kas adalah saldo fisik yang ada di rekening/dompet toko, sedangkan laba adalah nilai penjualan bersih setelah dikurangi modal bahan pokok (HPP), beban operasional, dan gaji tim.
        </div>
        <span class="pk01-pill <?php echo ($profit >= 0) ? 'pill-green' : 'pill-red'; ?>" style="font-size:12px; padding:6px 12px;">
            <?php echo ($profit >= 0) ? '🟢 Status: Usaha Sehat & Untung' : '🔴 Status: Evaluasi Beban Usaha'; ?>
        </span>
    </div>

    <!-- 5. TABS NAVIGASI SUB-MENU -->
    <nav class="pk01-nav-tabs" aria-label="Menu Laporan Keuangan">
        <button type="button" class="pk01-tab-btn is-active" data-target="tab-cashflow">
            📥 Sumber Uang Masuk &amp; Keluar (Arus Kas)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-profitloss">
            🏭 Dari Mana Laba Terbentuk? (Laba Rugi)
        </button>
        <button type="button" class="pk01-tab-btn" data-target="tab-composition">
            📊 Komposisi Biaya &amp; Alur Kas
        </button>
    </nav>

    <!-- 6. TAB 1: ARUS KAS NYATA (DARI MANA & DIPAKAI APA) -->
    <div class="pk01-pane is-active" id="tab-cashflow">
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(340px, 1fr)); gap:20px;">
            
            <!-- Uang Masuk -->
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>📥 Uang Masuk — Dari Mana Saja?</h3>
                        <div class="pk01-surface-desc">Sumber uang nyata yang masuk ke rekening kas &amp; bank toko.</div>
                    </div>
                </div>

                <div class="pk01-flow-list">
                    <?php if (!empty($in_rows)): foreach ($in_rows as $r): ?>
                        <div class="pk01-flow-row">
                            <span>🛒 <?php echo esc_html($r['category']); ?></span>
                            <strong style="color:#059669;"><?php echo esc_html($money($r['total'])); ?></strong>
                        </div>
                    <?php endforeach; else: ?>
                        <div class="pk01-flow-row" style="color:#94a3b8;">
                            <span>Belum ada transaksi uang masuk pada periode ini.</span>
                            <strong>Rp 0</strong>
                        </div>
                    <?php endif; ?>

                    <div class="pk01-flow-row total-row">
                        <span>Total Seluruh Uang Masuk:</span>
                        <strong style="color:#059669; font-size:16px;"><?php echo esc_html($money($cash_in)); ?></strong>
                    </div>
                </div>
            </div>

            <!-- Uang Keluar -->
            <div class="pk01-surface">
                <div class="pk01-surface-header">
                    <div>
                        <h3>📤 Uang Keluar — Dipakai Untuk Apa?</h3>
                        <div class="pk01-surface-desc">Pengeluaran nyata dari rekening kas &amp; bank toko.</div>
                    </div>
                </div>

                <div class="pk01-flow-list">
                    <?php if (!empty($out_rows)): foreach ($out_rows as $r): ?>
                        <div class="pk01-flow-row">
                            <span>💸 <?php echo esc_html($r['category']); ?></span>
                            <strong style="color:#dc2626;"><?php echo esc_html($money($r['total'])); ?></strong>
                        </div>
                    <?php endforeach; else: ?>
                        <div class="pk01-flow-row" style="color:#94a3b8;">
                            <span>Belum ada transaksi uang keluar pada periode ini.</span>
                            <strong>Rp 0</strong>
                        </div>
                    <?php endif; ?>

                    <div class="pk01-flow-row total-row">
                        <span>Total Seluruh Uang Keluar:</span>
                        <strong style="color:#dc2626; font-size:16px;"><?php echo esc_html($money($cash_out)); ?></strong>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- 7. TAB 2: PERHITUNGAN LABA RUGI SEDERHANA -->
    <div class="pk01-pane" id="tab-profitloss">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>🏭 Bagaimana Keuntungan Usaha Dihitung?</h3>
                    <div class="pk01-surface-desc">
                        Urutan sederhana: Penjualan Bersih dikurangi modal barang dan seluruh biaya operasional.
                    </div>
                </div>
                <span class="pk01-pill pill-green" style="font-size:12px; padding:6px 12px;">
                    Margin Laba Bersih: <?php echo $margin_pct; ?>%
                </span>
            </div>

            <div class="pk01-flow-list" style="max-width:800px; margin:0 auto;">
                <div class="pk01-flow-row">
                    <span>🛒 1. Penjualan Bersih (Omzet Toko &amp; Pesanan)</span>
                    <strong style="color:#059669;"><?php echo esc_html($money($net_sales)); ?></strong>
                </div>

                <div class="pk01-flow-row">
                    <span>🧱 2. Modal Bahan Baku / Barang Terjual (HPP)</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($money($hpp)); ?></strong>
                </div>

                <div class="pk01-flow-row" style="background:#f8fafc; padding:10px 12px; border-radius:8px;">
                    <span style="font-weight:700; color:#0f172a;">= Laba Kotor (Hasil Penjualan Setelah Modal Pokok):</span>
                    <strong style="color:#0f172a; font-size:15px;"><?php echo esc_html($money($gross_profit)); ?></strong>
                </div>

                <div class="pk01-flow-row" style="margin-top:10px;">
                    <span>🏢 3. Biaya Operasional Kantor &amp; Usaha</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($money($operational)); ?></strong>
                </div>

                <div class="pk01-flow-row">
                    <span>👥 4. Gaji Karyawan Tetap</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($money($payroll)); ?></strong>
                </div>

                <div class="pk01-flow-row">
                    <span>🔧 5. Upah Borongan Pekerjaan Produksi</span>
                    <strong style="color:#dc2626;">&minus; <?php echo esc_html($money($job_wages)); ?></strong>
                </div>

                <div class="pk01-flow-row total-row" style="background:#f8fafc; padding:16px; border-radius:10px; margin-top:14px;">
                    <span style="font-size:15px; color:#0f172a;">🏆 Laba Bersih Akhir Usaha (Net Profit):</span>
                    <strong style="font-size:22px; color:<?php echo ($profit >= 0) ? '#059669' : '#dc2626'; ?>;">
                        <?php echo esc_html($money($profit)); ?>
                    </strong>
                </div>
            </div>
        </div>
    </div>

    <!-- 8. TAB 3: KOMPOSISI BIAYA & ALUR UANG -->
    <div class="pk01-pane" id="tab-composition">
        <div class="pk01-surface">
            <div class="pk01-surface-header">
                <div>
                    <h3>📊 Ke Mana Saja Uang Belanja Usaha Mengalir?</h3>
                    <div class="pk01-surface-desc">
                        Persentase penyerapan biaya usaha dari total pengeluaran belanja periode ini (<?php echo esc_html($money($total_expenses)); ?>).
                    </div>
                </div>
            </div>

            <!-- Visual Spending Bar -->
            <div style="background:#f8fafc; border:1px solid var(--pk-slate-200); border-radius:12px; padding:18px; margin-bottom:24px;">
                <div style="font-size:12.5px; font-weight:700; color:#0f172a;">Komposisi Alokasi Biaya:</div>
                
                <div class="pk01-spend-bar-wrap">
                    <div class="pk01-spend-segment" style="width:<?php echo $pct_hpp; ?>%; background:#4f46e5;" title="Modal Bahan (HPP): <?php echo $pct_hpp; ?>%"></div>
                    <div class="pk01-spend-segment" style="width:<?php echo $pct_team; ?>%; background:#10b981;" title="Gaji & Upah Tim: <?php echo $pct_team; ?>%"></div>
                    <div class="pk01-spend-segment" style="width:<?php echo $pct_ops; ?>%; background:#f59e0b;" title="Biaya Kantor & Operasional: <?php echo $pct_ops; ?>%"></div>
                </div>

                <div class="pk01-spend-legend">
                    <span><b style="color:#4f46e5;">■</b> Modal Bahan Baku / HPP (<?php echo $pct_hpp; ?>%)</span>
                    <span><b style="color:#10b981;">■</b> Gaji &amp; Upah Tenaga Kerja (<?php echo $pct_team; ?>%)</span>
                    <span><b style="color:#f59e0b;">■</b> Biaya Kantor &amp; Operasional (<?php echo $pct_ops; ?>%)</span>
                </div>
            </div>

            <!-- Step by Step Journey -->
            <h4 style="margin:0 0 12px; font-size:15px; font-weight:800; color:#0f172a;">5 Prinsip Alur Uang Usaha PK01:</h4>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:14px;">
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
                    <strong style="color:#4f46e5; display:block; margin-bottom:4px;">1. Uang Masuk</strong>
                    <span style="font-size:12.5px; color:#64748b;">Berasal dari penjualan toko, faktur online, atau modal investor.</span>
                </div>
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
                    <strong style="color:#0284c7; display:block; margin-bottom:4px;">2. Disimpan Aman</strong>
                    <span style="font-size:12.5px; color:#64748b;">Tersimpan di brankas kas fisik atau rekening bank resmi usaha.</span>
                </div>
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
                    <strong style="color:#d97706; display:block; margin-bottom:4px;">3. Dibelanjakan</strong>
                    <span style="font-size:12.5px; color:#64748b;">Dipakai untuk bahan baku, gaji karyawan, dan operasional harian.</span>
                </div>
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
                    <strong style="color:#10b981; display:block; margin-bottom:4px;">4. Dicatat Otomatis</strong>
                    <span style="font-size:12.5px; color:#64748b;">Setiap rupiah memiliki tanggal, kategori, nama staf, dan nota rujukan.</span>
                </div>
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
                    <strong style="color:#7c3aed; display:block; margin-bottom:4px;">5. Dilaporkan Transparan</strong>
                    <span style="font-size:12.5px; color:#64748b;">Pemilik langsung melihat laba bersih riil tanpa repot hitung manual.</span>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. TAB SWITCHER DENGAN SINKRONISASI HASH URL
    const tabs = document.querySelectorAll('.pk01-tab-btn');
    const panes = document.querySelectorAll('.pk01-pane');

    function switchTab(targetId) {
        if (!targetId) return;
        const btn = document.querySelector(`.pk01-tab-btn[data-target="${targetId}"]`);
        const pane = document.getElementById(targetId);

        if (btn && pane) {
            tabs.forEach(t => t.classList.remove('is-active'));
            panes.forEach(p => p.classList.remove('is-active'));
            btn.classList.add('is-active');
            pane.classList.add('is-active');
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            switchTab(target);
            if (history.replaceState) {
                history.replaceState(null, null, '#' + target);
            }
        });
    });

    const currentHash = window.location.hash ? window.location.hash.substring(1) : '';
    if (currentHash && document.getElementById(currentHash)) {
        switchTab(currentHash);
    }
});
</script>