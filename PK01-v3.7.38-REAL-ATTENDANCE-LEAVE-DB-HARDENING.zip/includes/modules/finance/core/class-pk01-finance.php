<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 Finance Engine 1.0
 * General Ledger berbasis transaksi nyata PK01.
 * Tidak menggantikan financial_report() lama; GL menjadi lapisan posting/reconciliation.
 */
class PK01_Finance {
    public static function init() {
        add_action('init',[__CLASS__,'ensure_current_period'],35);
    }

    public static function ensure_current_period($date='') {
        global $wpdb;
        $date=$date?:current_time('Y-m-d'); $period=substr($date,0,7);
        $t=PK01_DB::t('financial_periods');
        if(!$t || $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t))!==$t) return false;
        if(!$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE period_key=%s",$period))) {
            $from=$period.'-01'; $to=date('Y-m-t',strtotime($from));
            $wpdb->insert($t,['period_key'=>$period,'date_from'=>$from,'date_to'=>$to,'status'=>'open','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        }
        return true;
    }

    private static function period($from,$to) {
        $from=$from?:current_time('Y-m-01'); $to=$to?:current_time('Y-m-d');
        if($from>$to) throw new Exception('Periode tidak valid: tanggal awal lebih besar dari tanggal akhir.');
        return [$from,$to];
    }

    public static function is_closed($date) {
        global $wpdb; $t=PK01_DB::t('financial_periods'); $p=substr($date,0,7);
        return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE period_key=%s AND status='closed'",$p));
    }

    /**
     * Self-heal tabel akuntansi inti. Instalasi plugin lama dapat memiliki
     * schema PK01 parsial walaupun modul Finance sudah aktif. Jangan biarkan
     * halaman melempar fatal error hanya karena journal table belum dibuat.
     */
    private static function ensure_finance_tables() {
        global $wpdb;
        if (!class_exists('PK01_DB')) return false;
        PK01_DB::init();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $fp = PK01_DB::t('financial_periods');
        $je = PK01_DB::t('journal_entries');
        $jl = PK01_DB::t('journal_lines');

        PK01_DB::dbDelta_safe("CREATE TABLE {$fp} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            period_key varchar(7) NOT NULL,
            date_from date NOT NULL,
            date_to date NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'open',
            closed_by bigint(20) unsigned DEFAULT 0,
            closed_at datetime DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY period_key(period_key), KEY status(status)
        ) {$c};");
        PK01_DB::dbDelta_safe("CREATE TABLE {$je} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            entry_no varchar(100) NOT NULL DEFAULT '',
            entry_date date NOT NULL,
            period_key varchar(7) NOT NULL,
            source_type varchar(60) NOT NULL DEFAULT 'manual',
            source_id bigint(20) unsigned DEFAULT 0,
            source_key varchar(160) NOT NULL DEFAULT '',
            description text DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'posted',
            created_by bigint(20) unsigned DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY source_key(source_key), KEY entry_date(entry_date), KEY period_key(period_key), KEY source(source_type,source_id)
        ) {$c};");
        PK01_DB::dbDelta_safe("CREATE TABLE {$jl} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            journal_entry_id bigint(20) unsigned NOT NULL,
            account_code varchar(30) NOT NULL DEFAULT '',
            account_name varchar(190) NOT NULL DEFAULT '',
            debit decimal(18,2) NOT NULL DEFAULT 0.00,
            credit decimal(18,2) NOT NULL DEFAULT 0.00,
            memo varchar(255) DEFAULT '',
            PRIMARY KEY(id), KEY journal_entry_id(journal_entry_id), KEY account_code(account_code)
        ) {$c};");

        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $je)) === $je
            && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $jl)) === $jl;
    }

    private static function add_entry($date,$source_type,$source_id,$description,$lines,$source_key='') {
        global $wpdb;
        if (!self::ensure_finance_tables()) throw new Exception('Tabel akuntansi PK01 belum tersedia dan gagal dipulihkan.');
        $sumD=$sumC=0; foreach($lines as $l){$sumD+=round((float)($l['debit']??0),2);$sumC+=round((float)($l['credit']??0),2);}
        if($sumD<=0 || abs($sumD-$sumC)>0.01) throw new Exception('Jurnal tidak seimbang.');
        $period=substr($date,0,7); self::ensure_current_period($date);
        if(self::is_closed($date)) return ['ok'=>false,'closed'=>true];
        $t=PK01_DB::t('journal_entries'); $tl=PK01_DB::t('journal_lines');
        $key=$source_key?:($source_type.':'.(int)$source_id.':'.$date);
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE source_key=%s",$key));
        if($existing) return ['ok'=>true,'id'=>(int)$existing,'duplicate'=>true];
        $entry_no=PK01_Engine::document_number('journal','JNL',6,'{PREFIX}/{YYYY}{MM}/{SEQ}');
        $ok=$wpdb->insert($t,['entry_no'=>$entry_no,'entry_date'=>$date,'period_key'=>$period,'source_type'=>sanitize_key($source_type),'source_id'=>(int)$source_id,'source_key'=>sanitize_text_field($key),'description'=>sanitize_textarea_field($description),'status'=>'posted','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        if(!$ok) throw new Exception($wpdb->last_error?:'Gagal membuat jurnal.');
        $eid=(int)$wpdb->insert_id;
        foreach($lines as $l){
            $wpdb->insert($tl,['journal_entry_id'=>$eid,'account_code'=>sanitize_text_field($l['code']),'account_name'=>sanitize_text_field($l['name']),'debit'=>round((float)$l['debit'],2),'credit'=>round((float)$l['credit'],2),'memo'=>sanitize_text_field($l['memo']??'')]);
            if(!$wpdb->insert_id) throw new Exception($wpdb->last_error?:'Gagal membuat baris jurnal.');
        }
        if(class_exists('PK01_Kernel')) PK01_Kernel::event('finance_journal_posted','finance','journal_entry',$eid,['source_type'=>$source_type,'source_id'=>$source_id,'source_key'=>$key]);
        if(class_exists('PK01_Audit')) PK01_Audit::info('finance_journal_posted','finance','journal_entry',(string)$eid,'Jurnal General Ledger diposting',['source_type'=>$source_type,'source_id'=>$source_id]);
        return ['ok'=>true,'id'=>$eid];
    }

    /** Rekonsiliasi sumber nyata ke GL. Idempotent; tidak mengubah transaksi sumber. */
    public static function sync($from='',$to='') {
        global $wpdb;
        if (!self::ensure_finance_tables()) return ['posted'=>0,'duplicates'=>0,'blocked'=>0,'errors'=>['Tabel akuntansi PK01 belum tersedia.']];
        list($from,$to)=self::period($from,$to);
        $result=['posted'=>0,'duplicates'=>0,'blocked'=>0,'errors'=>[]];
        $add=function($r)use(&$result){if(!empty($r['closed'])){$result['blocked']++;return;}if(!empty($r['duplicate']))$result['duplicates']++;elseif(!empty($r['ok']))$result['posted']++;};
        $T=function($k){return PK01_DB::t($k);};

        // 1) PENJUALAN: satu order = satu revenue + satu HPP. Seller attribution bukan revenue kedua.
        $so=$T('sales_orders');
        if($so){
            $orders=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$so}` WHERE status NOT IN ('cancelled','batal','failed') AND DATE(created_at) BETWEEN %s AND %s ORDER BY id",$from,$to),ARRAY_A)?:[];
            foreach($orders as $o){
                $total=round((float)$o['total_amount'],2); $cash=min($total,max(0,(float)($o['paid_amount']??0))); $ar=max(0,$total-$cash);
                if($total>0){$lines=[];if($cash>0)$lines[]=['code'=>'1100','name'=>'Kas/Bank','debit'=>$cash,'credit'=>0,'memo'=>'Pembayaran penjualan'];if($ar>0){$channel=strtolower((string)($o['channel']??''));$is_marketplace=(strpos($channel,'shopee')!==false||strpos($channel,'tokopedia')!==false||strpos($channel,'marketplace')!==false);$lines[]=['code'=>$is_marketplace?'1210':'1200','name'=>$is_marketplace?'Piutang Marketplace':'Piutang Usaha','debit'=>$ar,'credit'=>0,'memo'=>'Sisa piutang penjualan'];}$lines[]=['code'=>'4100','name'=>'Pendapatan Penjualan','debit'=>0,'credit'=>$total,'memo'=>$o['invoice_no']?:$o['order_no']];$add(self::add_entry(substr($o['created_at'],0,10),'sale',(int)$o['id'],'Penjualan '.$o['invoice_no'],$lines,'sale:'.$o['id'].':revenue'));}
                $hpp=round((float)$o['hpp']*(float)$o['qty'],2); if($hpp>0)$add(self::add_entry(substr($o['created_at'],0,10),'sale_hpp',(int)$o['id'],'HPP penjualan '.$o['invoice_no'],[['code'=>'5100','name'=>'Harga Pokok Penjualan','debit'=>$hpp,'credit'=>0,'memo'=>'HPP barang terjual'],['code'=>'1300','name'=>'Persediaan Barang Jadi','debit'=>0,'credit'=>$hpp,'memo'=>'Persediaan keluar']],'sale:'.$o['id'].':hpp'));
            }
        }

        // 1A) MUTASI KAS MANUAL yang tidak punya sumber bisnis lain. Masuk ke akun penampung,
        // sehingga saldo GL tetap sama dengan kas riil tanpa mengarang pendapatan/biaya.
        $clm=$T('cash_ledger'); $oc0=$T('operational_costs'); if($clm){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$clm}` WHERE reference_type='manual' AND created_at BETWEEN %s AND %s ORDER BY id",$from.' 00:00:00',$to.' 23:59:59'),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['amount'];if($a<=0)continue;if($r['direction']==='out' && $oc0 && !empty($r['reference_no']) && $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$oc0}` WHERE reference_no=%s LIMIT 1",$r['reference_no'])))continue;$in=$r['direction']==='in';$lines=$in?[['code'=>'1100','name'=>'Kas/Bank','debit'=>$a,'credit'=>0,'memo'=>$r['description']],['code'=>'3990','name'=>'Penyesuaian Kas Manual','debit'=>0,'credit'=>$a,'memo'=>$r['category']]]:[['code'=>'3990','name'=>'Penyesuaian Kas Manual','debit'=>$a,'credit'=>0,'memo'=>$r['category']],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$a,'memo'=>$r['description']]];$add(self::add_entry(substr($r['created_at'],0,10),'manual_cash',(int)$r['id'],'Mutasi kas manual '.$r['category'],$lines,'manual_cash:'.$r['id']));}}

        // 1B) PEMBELIAN PERSEDIAAN langsung: stok adalah aset, bukan biaya pada saat beli.
        $st=$T('stock_transactions'); $mat=$T('materials'); $cl=$T('cash_ledger');
        if($st&&$mat){$rows=$wpdb->get_results($wpdb->prepare("SELECT st.*,m.name material_name FROM `{$st}` st LEFT JOIN `{$mat}` m ON m.id=st.material_id WHERE st.reference_type='inventory_receipt' AND st.direction='in' AND DATE(st.created_at) BETWEEN %s AND %s ORDER BY st.id",$from,$to),ARRAY_A)?:[];foreach($rows as $r){$value=(float)($r['total_value']??0);if($value<=0)$value=round((float)$r['qty']*(float)($r['unit_cost']??0),2);if($value<=0)continue;$paid=$cl?(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$cl}` WHERE reference_type='inventory_receipt' AND reference_id=%d AND direction='out'",(int)$r['id'])):0;$lines=[['code'=>'1400','name'=>'Persediaan Bahan - '.$r['material_name'],'debit'=>$value,'credit'=>0,'memo'=>$r['reference_no']]];if($paid>0)$lines[]=['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$value,'memo'=>'Pembelian dibayar'];else $lines[]=['code'=>'2000','name'=>'Utang Usaha','debit'=>0,'credit'=>$value,'memo'=>'Pembelian belum dibayar'];$add(self::add_entry(substr($r['created_at'],0,10),'inventory_receipt',(int)$r['id'],'Penerimaan persediaan '.$r['material_name'],$lines,'inventory_receipt:'.$r['id']));}}

        // 2) BIAYA OPERASIONAL. Kategori gaji/upah dikecualikan karena punya sumber payroll/job_wage sendiri.
        $oc=$T('operational_costs');
        if($oc){$costs=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$oc}` WHERE cost_date BETWEEN %s AND %s AND category NOT IN ('Gaji & Upah','Gaji Karyawan','Upah Pekerjaan','Fee Layanan Marketplace') ORDER BY id",$from,$to),ARRAY_A)?:[];foreach($costs as $c){$a=round((float)$c['amount'],2);if($a<=0)continue;$add(self::add_entry($c['cost_date'],'operational_cost',(int)$c['id'],'Biaya operasional: '.$c['category'],[['code'=>'6100','name'=>'Beban Operasional - '.$c['category'],'debit'=>$a,'credit'=>0,'memo'=>$c['description']??''],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$a,'memo'=>$c['payment_method']??'']], 'operational_cost:'.$c['id']));}}

        // 3) PAYROLL. Beban memakai gross; kas hanya net; selisih menjadi kewajiban potongan.
        $t=$T('payroll');
        if($t){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$t}` WHERE status='paid' AND ((paid_at BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s)) ORDER BY id",$from,$to,$from,$to),ARRAY_A)?:[];foreach($rows as $r){$gross=(float)($r['gross_amount']??$r['amount']);$net=(float)$r['amount'];$ded=max(0,$gross-$net);if($gross<=0)continue;$lines=[['code'=>'6200','name'=>'Beban Gaji Karyawan','debit'=>$gross,'credit'=>0,'memo'=>$r['description']??'']];if($net>0)$lines[]=['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$net,'memo'=>$r['payment_method']??''];if($ded>0)$lines[]=['code'=>'2100','name'=>'Utang Potongan Payroll','debit'=>0,'credit'=>$ded,'memo'=>'Potongan payroll'];$add(self::add_entry(substr((string)($r['paid_at']?:$r['created_at']),0,10),'payroll',(int)$r['id'],'Payroll '.$r['name'],$lines,'payroll:'.$r['id'].':paid'));}}

        // 4) UPAH JOB. operational_costs yang dibuat oleh pembayaran upah dikecualikan di atas.
        $t=$T('job_wages');
        if($t){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$t}` WHERE status IN ('paid','partial') AND ((paid_at BETWEEN %s AND %s) OR (created_at BETWEEN %s AND %s)) ORDER BY id",$from,$to,$from,$to),ARRAY_A)?:[];foreach($rows as $r){$paid=(float)($r['paid_amount']??0);if($paid<=0)continue;$add(self::add_entry(substr((string)($r['paid_at']?:$r['created_at']),0,10),'job_wage',(int)$r['id'],'Pembayaran Upah Job',[['code'=>'6200','name'=>'Beban Upah Pekerjaan','debit'=>$paid,'credit'=>0,'memo'=>$r['notes']??''],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$paid,'memo'=>$r['payment_method']??'']], 'job_wage:'.$r['id'].':paid_total'));}}

        // 5) ASET TETAP. Pembelian aset bukan beban laba.
        $ta=$T('fixed_assets'); if($ta){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$ta}` WHERE purchase_date BETWEEN %s AND %s ORDER BY id",$from,$to),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['purchase_cost'];if($a<=0)continue;$add(self::add_entry($r['purchase_date'],'fixed_asset',(int)$r['id'],'Pembelian aset '.$r['name'],[['code'=>'1600','name'=>'Aset Tetap - '.$r['category'],'debit'=>$a,'credit'=>0,'memo'=>$r['asset_code']],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$a,'memo'=>'Pembelian aset']], 'fixed_asset:'.$r['id']));}}

        // 6) PENYUSUTAN non-kas.
        $dep=$T('asset_depreciation'); if($dep){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$dep}` WHERE period_key BETWEEN %s AND %s AND status='posted'",substr($from,0,7),substr($to,0,7)),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['depreciation_amount'];if($a<=0)continue;$date=$r['period_key'].'-01';$add(self::add_entry($date,'depreciation',(int)$r['id'],'Penyusutan aset periode '.$r['period_key'],[['code'=>'6300','name'=>'Beban Penyusutan','debit'=>$a,'credit'=>0,'memo'=>''],['code'=>'1700','name'=>'Akumulasi Penyusutan','debit'=>0,'credit'=>$a,'memo'=>'']], 'depreciation:'.$r['id']));}}

        // 7) MODAL masuk. Bukan pendapatan.
        $cap=$T('capital_transactions'); if($cap){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$cap}` WHERE DATE(created_at) BETWEEN %s AND %s",$from,$to),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['amount'];if($a<=0)continue;$add(self::add_entry(substr($r['created_at'],0,10),'capital',(int)$r['id'],'Penerimaan modal',[['code'=>'1100','name'=>'Kas/Bank','debit'=>$a,'credit'=>0,'memo'=>$r['source']],['code'=>(($r['capital_type']??'')==='loan'?'2000':'3100'),'name'=>(($r['capital_type']??'')==='loan'?'Utang Pendanaan':'Modal Pemilik/Investor'),'debit'=>0,'credit'=>$a,'memo'=>$r['description']]],'capital:'.$r['id']));}}

        // 8) RETUR selesai: refund mengurangi pendapatan; HPP dikembalikan ke persediaan jika kondisi baik.
        $tr=$T('returns'); $tri=$T('return_items'); $tv=$T('product_variants');
        if($tr){$rows=$wpdb->get_results($wpdb->prepare("SELECT r.*,ri.variant_id,ri.qty,ri.condition_status,COALESCE(v.hpp,0) hpp FROM `{$tr}` r LEFT JOIN `{$tri}` ri ON ri.return_id=r.id LEFT JOIN `{$tv}` v ON v.id=ri.variant_id WHERE r.status='completed' AND DATE(COALESCE(r.completed_at,r.created_at)) BETWEEN %s AND %s ORDER BY r.id",$from,$to),ARRAY_A)?:[];foreach($rows as $r){$refund=(float)$r['refund_amount'];if($refund>0)$add(self::add_entry(substr((string)($r['completed_at']?:$r['created_at']),0,10),'return',(int)$r['id'],'Refund retur '.$r['return_no'],[['code'=>'4200','name'=>'Retur Penjualan','debit'=>$refund,'credit'=>0,'memo'=>$r['reason']??''],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$refund,'memo'=>'Refund retur']], 'return:'.$r['id'].':refund'));if(($r['condition_status']??'')==='good'){ $rh=round((float)$r['qty']*(float)$r['hpp'],2);if($rh>0)$add(self::add_entry(substr((string)($r['completed_at']?:$r['created_at']),0,10),'return_hpp',(int)$r['id'],'Pembalikan HPP retur',[['code'=>'1300','name'=>'Persediaan Barang Jadi','debit'=>$rh,'credit'=>0,'memo'=>'Barang kembali'],['code'=>'5100','name'=>'Harga Pokok Penjualan','debit'=>0,'credit'=>$rh,'memo'=>'Pembalikan HPP']], 'return:'.$r['id'].':hpp'));}}}

        // 9) SELLER SUBLEDGER B2B. Hanya seller_orders yang menjadi revenue seller; cashier seller attribution tidak diposting kedua.
        $ss=$T('seller_sales'); $so2=$T('seller_orders'); $si=$T('seller_invoices'); $sp=$T('seller_payments');
        if($ss&&$so2){$rows=$wpdb->get_results($wpdb->prepare("SELECT ss.*,so.order_no FROM `{$ss}` ss JOIN `{$so2}` so ON so.id=ss.order_id WHERE (ss.source_type='seller_order' OR ss.source_type IS NULL OR ss.source_type='') AND ss.sold_at BETWEEN %s AND %s ORDER BY ss.id",$from.' 00:00:00',$to.' 23:59:59'),ARRAY_A)?:[];foreach($rows as $r){$total=(float)$r['total'];if($total>0)$add(self::add_entry(substr($r['sold_at'],0,10),'seller_sale',(int)$r['id'],'Penjualan seller '.$r['order_no'],[['code'=>'1220','name'=>'Piutang Seller','debit'=>$total,'credit'=>0,'memo'=>$r['order_no']],['code'=>'4200','name'=>'Pendapatan Penjualan Seller','debit'=>0,'credit'=>$total,'memo'=>$r['order_no']]],'seller_sale:'.$r['id'].':revenue'));$hpp=round((float)$r['hpp']*(float)$r['qty'],2);if($hpp>0)$add(self::add_entry(substr($r['sold_at'],0,10),'seller_sale_hpp',(int)$r['id'],'HPP penjualan seller '.$r['order_no'],[['code'=>'5100','name'=>'Harga Pokok Penjualan','debit'=>$hpp,'credit'=>0,'memo'=>$r['order_no']],['code'=>'1300','name'=>'Persediaan Barang Jadi','debit'=>0,'credit'=>$hpp,'memo'=>$r['order_no']]],'seller_sale:'.$r['id'].':hpp'));}}
        // Pembayaran seller langsung mengurangi AR dan menambah kas. Alokasi kasir (order_id= sales_orders.id) dilewati agar kas tidak dua kali.
        if($si&&$sp){$rows=$wpdb->get_results($wpdb->prepare("SELECT p.*,i.invoice_no,i.order_id FROM `{$sp}` p JOIN `{$si}` i ON i.id=p.invoice_id WHERE p.paid_at BETWEEN %s AND %s ORDER BY p.id",$from.' 00:00:00',$to.' 23:59:59'),ARRAY_A)?:[];foreach($rows as $r){$order_id=(int)($r['order_id']??0);$is_cashier=$order_id>0&&$so&&$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$so}` WHERE id=%d",$order_id));if($is_cashier)continue;$a=(float)$r['amount'];if($a<=0)continue;$add(self::add_entry(substr($r['paid_at'],0,10),'seller_payment',(int)$r['id'],'Pembayaran piutang seller '.$r['invoice_no'],[['code'=>'1100','name'=>'Kas/Bank','debit'=>$a,'credit'=>0,'memo'=>$r['payment_method']],['code'=>'1220','name'=>'Piutang Seller','debit'=>0,'credit'=>$a,'memo'=>$r['invoice_no']]],'seller_payment:'.$r['id']));}}

        // 10) KOMISI/INSENTIF yang benar-benar dibayar. Setiap kas keluar punya pasangan beban.
        $sc=$T('sales_commissions'); if($sc){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$sc}` WHERE status='paid' AND paid_at BETWEEN %s AND %s",$from.' 00:00:00',$to.' 23:59:59'),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['commission_amount'];if($a>0)$add(self::add_entry(substr($r['paid_at'],0,10),'sales_commission',(int)$r['id'],'Pembayaran komisi sales',[['code'=>'6400','name'=>'Beban Komisi Sales','debit'=>$a,'credit'=>0,'memo'=>$r['reference_no']],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$a,'memo'=>$r['reference_no']]],'sales_commission:'.$r['id']));}}
        $af=$T('seller_affiliate_ledger'); if($af){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$af}` WHERE status='paid' AND paid_at BETWEEN %s AND %s",$from.' 00:00:00',$to.' 23:59:59'),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['commission_amount'];if($a>0)$add(self::add_entry(substr($r['paid_at'],0,10),'affiliate_payment',(int)$r['id'],'Pembayaran komisi affiliate',[['code'=>'6500','name'=>'Beban Komisi Affiliate','debit'=>$a,'credit'=>0,'memo'=>''],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$a,'memo'=>'']], 'affiliate_payment:'.$r['id']));}}
        $sb=$T('seller_bonus_ledger'); if($sb){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$sb}` WHERE status='paid' AND paid_at BETWEEN %s AND %s",$from.' 00:00:00',$to.' 23:59:59'),ARRAY_A)?:[];foreach($rows as $r){$a=(float)$r['bonus_amount'];if($a>0)$add(self::add_entry(substr($r['paid_at'],0,10),'seller_target_bonus',(int)$r['id'],'Pembayaran bonus target seller',[['code'=>'6600','name'=>'Beban Bonus Seller','debit'=>$a,'credit'=>0,'memo'=>$r['reference_no']],['code'=>'1100','name'=>'Kas/Bank','debit'=>0,'credit'=>$a,'memo'=>$r['reference_no']]], 'seller_target_bonus:'.$r['id']));}}

        // 9) MARKETPLACE payout: kas masuk hanya net. Fee sudah menjadi biaya dari payout, bukan kas keluar.
        $mp=$T('marketplace_payouts'); if($mp){
            $mp_cols=$wpdb->get_col("DESC `{$mp}`",0); $has_owner=in_array('owner_type',$mp_cols,true);
            $owner_filter=$has_owner?" AND COALESCE(owner_type,'company')='company'":'';
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `{$mp}` WHERE status='completed' {$owner_filter} AND payout_date BETWEEN %s AND %s ORDER BY id",$from,$to),ARRAY_A)?:[];
            foreach($rows as $r){$net=(float)$r['net_received'];$fee=(float)$r['deductions'];$gross=(float)$r['gross'];if($gross>0)$add(self::add_entry($r['payout_date'],'marketplace_payout',(int)$r['id'],'Payout marketplace '.$r['payout_no'],[['code'=>'1100','name'=>'Kas/Bank','debit'=>$net,'credit'=>0,'memo'=>$r['account_id']],['code'=>'6100','name'=>'Fee Marketplace','debit'=>$fee,'credit'=>0,'memo'=>'Potongan payout'],['code'=>'1210','name'=>'Piutang Marketplace','debit'=>0,'credit'=>$gross,'memo'=>$r['payout_no']]], 'marketplace_payout:'.$r['id']));}
        }

        return $result;
    }

    public static function ledger($from='',$to='',$account='') {global $wpdb; list($from,$to)=self::period($from,$to); self::sync($from,$to);$where='WHERE je.entry_date BETWEEN %s AND %s';$args=[$from,$to];if($account!==''){$where.=' AND (jl.account_code=%s OR jl.account_name LIKE %s)';$args[]=$account;$args[]='%'.$wpdb->esc_like($account).'%';}$sql="SELECT je.entry_no,je.entry_date,je.source_type,je.source_id,je.description,jl.account_code,jl.account_name,jl.debit,jl.credit,jl.memo FROM `".PK01_DB::t('journal_entries')."` je JOIN `".PK01_DB::t('journal_lines')."` jl ON jl.journal_entry_id=je.id {$where} ORDER BY je.entry_date,je.id,jl.id";return $wpdb->get_results($wpdb->prepare($sql,$args),ARRAY_A)?:[];}

    public static function trial_balance($from='',$to='') { $rows=self::ledger($from,$to);$out=[];foreach($rows as $r){$k=$r['account_code'].'|'.$r['account_name'];if(!isset($out[$k]))$out[$k]=['account_code'=>$r['account_code'],'account_name'=>$r['account_name'],'debit'=>0,'credit'=>0];$out[$k]['debit']+=(float)$r['debit'];$out[$k]['credit']+=(float)$r['credit'];}return array_values($out);}

    public static function close_period($period_key) {global $wpdb;$period_key=sanitize_text_field($period_key);$t=PK01_DB::t('financial_periods');$p=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE period_key=%s",$period_key),ARRAY_A);if(!$p)throw new Exception('Periode belum tersedia.');if($p['status']==='closed')return true;self::sync($p['date_from'],$p['date_to']);$wpdb->update($t,['status'=>'closed','closed_by'=>get_current_user_id(),'closed_at'=>current_time('mysql')],['id'=>(int)$p['id']]);if(class_exists('PK01_Audit'))PK01_Audit::info('finance_period_closed','finance','financial_period',(string)$p['id'],'Periode keuangan ditutup',['period_key'=>$period_key]);return true;}


    public static function ai_job_role_advice($job_id) {
        $candidates=self::job_role_recommendations($job_id);
        $prompt='Tentukan penugasan pekerjaan paling cocok berdasarkan data kandidat nyata berikut. Jangan membuat kandidat baru. Kembalikan kandidat terbaik, role_code, alasan singkat, risiko, dan confidence. Ini hanya rekomendasi; eksekusi tetap melalui permission dan business engine PK01. DATA: '.wp_json_encode(['job_id'=>(int)$job_id,'candidates'=>array_slice($candidates,0,20)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(class_exists('PK01_AI_Orchestrator')) {
            $ai=PK01_AI_Orchestrator::ask($prompt,'job_role_engine');
            if(is_array($ai) && !empty($ai['ok'])) return ['ok'=>true,'source'=>'ai','answer'=>$ai['message'],'candidates'=>$candidates];
        }
        return ['ok'=>true,'source'=>'rule_fallback','answer'=>'AI tidak tersedia. Rekomendasi menggunakan kecocokan data job dengan posisi/divisi karyawan yang tersimpan di PK01.','candidates'=>$candidates];
    }

    public static function job_role_recommendations($job_id) {global $wpdb;$job=$wpdb->get_row($wpdb->prepare("SELECT j.*,p.name product_name FROM `".PK01_DB::t('jobs')."` j LEFT JOIN `".PK01_DB::t('products')."` p ON p.id=j.product_id WHERE j.id=%d",$job_id),ARRAY_A);if(!$job)throw new Exception('Job tidak ditemukan.');$roles=$wpdb->get_results("SELECT * FROM `".PK01_DB::t('job_role_catalog')."` WHERE active=1 ORDER BY id",ARRAY_A)?:[];$emps=$wpdb->get_results("SELECT e.*,u.display_name FROM `".PK01_DB::t('employees')."` e LEFT JOIN `".$wpdb->users."` u ON u.ID=e.user_id WHERE e.status='active'",ARRAY_A)?:[];$text=strtolower(($job['instructions']??'').' '.($job['product_name']??''));$scores=[];foreach($emps as $e){$et=strtolower(($e['position']??'').' '.($e['division']??''));$best=['role_code'=>'','score'=>0,'role_name'=>''];foreach($roles as $r){$score=0;foreach(array_filter(array_map('trim',explode(',',$r['keywords']??''))) as $kw){if($kw!=='' && (strpos($text,$kw)!==false||strpos($et,$kw)!==false))$score+=strpos($text,$kw)!==false?3:2;}if($score>$best['score'])$best=['role_code'=>$r['role_code'],'score'=>$score,'role_name'=>$r['role_name']];}if($best['score']<=0){$map=['produksi'=>'produksi_perakitan','gudang'=>'gudang','logistik'=>'logistik','packing'=>'packing','sales'=>'sales','keuangan'=>'keuangan','finance'=>'keuangan','hr'=>'sdm','sdm'=>'sdm','kasir'=>'kasir'];foreach($map as $k=>$rc){if(strpos($et,$k)!==false){foreach($roles as $r)if($r['role_code']===$rc)$best=['role_code'=>$rc,'score'=>1,'role_name'=>$r['role_name']];break;}}}$scores[]=['employee_id'=>(int)$e['id'],'employee_name'=>$e['name'],'position'=>$e['position'],'division'=>$e['division'],'role_code'=>$best['role_code'],'role_name'=>$best['role_name'],'confidence'=>min(1,round($best['score']/8,4)),'basis'=>'kecocokan job + posisi/divisi karyawan'];}usort($scores,function($a,$b){return $b['confidence']<=>$a['confidence'];});return $scores;}
}
