<?php
if (!defined('ABSPATH')) exit;
class PK01_Expense_Workflow {
    public static function init(){
        add_action('admin_post_pk01_expense_receipt',[__CLASS__,'pdf_receipt']);
        add_action('admin_post_nopriv_pk01_expense_receipt',[__CLASS__,'pdf_receipt']);
    }
    private static function table(){ return class_exists('PK01_DB')?PK01_DB::t('operational_costs'):''; }
    private static function can_approve(){ return current_user_can('manage_options') || (class_exists('PK01_Authorization') && in_array(PK01_Authorization::effective_role(),['pk01_admin','pk01_keuangan'],true)); }
    private static function can_pay(){ return current_user_can('manage_options') || (class_exists('PK01_Authorization') && in_array(PK01_Authorization::effective_role(),['pk01_admin','pk01_keuangan','pk01_kasir'],true)); }
    public static function create($data){
        global $wpdb; $t=self::table(); if(!$t) throw new Exception('Tabel biaya operasional belum tersedia.');
        $amount=round((float)($data['amount']??0),2); if($amount<=0) throw new Exception('Nominal harus lebih dari 0.');
        $ref=sanitize_text_field($data['reference_no']??'');
        if($ref && $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t}` WHERE reference_no=%s LIMIT 1",$ref))) throw new Exception('Nomor referensi sudah digunakan.');
        $now=current_time('mysql'); $uid=get_current_user_id();
        $ok=$wpdb->insert($t,[
            'cost_date'=>sanitize_text_field($data['cost_date']??current_time('Y-m-d')),
            'category'=>sanitize_text_field($data['category']??'Operasional Kantor'), 'amount'=>$amount,
            'payment_method'=>sanitize_text_field($data['payment_method']??'Kas Tunai'), 'reference_no'=>$ref,
            'description'=>sanitize_textarea_field($data['description']??''), 'created_by'=>$uid,'created_at'=>$now,
            'status'=>'pending_approval','requested_by'=>$uid,'recipient_name'=>sanitize_text_field($data['recipient_name']??''),
            'recipient_user_id'=>(int)($data['recipient_user_id']??0), 'receipt_no'=>(class_exists('PK01_Engine') ? PK01_Engine::document_number('expense','KK',5,'{PREFIX}/{YYYY}{MM}/{SEQ}') : 'KK-'.current_time('ymd').'-'.str_pad((string)wp_rand(1,9999),4,'0',STR_PAD_LEFT))
        ]);
        if(!$ok) throw new Exception($wpdb->last_error?:'Gagal menyimpan permintaan pengeluaran.');
        $id=(int)$wpdb->insert_id;
        if(class_exists('PK01_Audit')) PK01_Audit::log('expense_request_created','finance','operational_costs',(string)$id,null,['amount'=>$amount,'category'=>$data['category']??'']);
        return $id;
    }
    public static function approve($id){
        global $wpdb; if(!self::can_approve()) throw new Exception('Anda tidak berwenang menyetujui pengeluaran.'); $t=self::table();
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$id),ARRAY_A); if(!$r) throw new Exception('Pengeluaran tidak ditemukan.');
        if($r['status']!=='pending_approval') throw new Exception('Pengeluaran bukan lagi dalam status menunggu persetujuan.');
        $wpdb->update($t,['status'=>'approved','approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql')],['id'=>$id]);
        return true;
    }
    public static function reject($id,$reason=''){
        global $wpdb; if(!self::can_approve()) throw new Exception('Anda tidak berwenang menolak pengeluaran.'); $t=self::table();
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$id),ARRAY_A); if(!$r) throw new Exception('Pengeluaran tidak ditemukan.');
        if(!in_array($r['status'],['pending_approval','approved'],true)) throw new Exception('Status tidak dapat ditolak.');
        $desc=$r['description']; if($reason) $desc.="\nAlasan ditolak: ".sanitize_textarea_field($reason);
        $wpdb->update($t,['status'=>'rejected','description'=>$desc],['id'=>$id]); return true;
    }
    public static function pay($id){
        global $wpdb; if(!self::can_pay()) throw new Exception('Anda tidak berwenang membayar pengeluaran.'); $t=self::table();
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$id),ARRAY_A); if(!$r) throw new Exception('Pengeluaran tidak ditemukan.');
        if($r['status']!=='approved') throw new Exception('Pengeluaran harus disetujui sebelum dibayar.');
        if(class_exists('PK01_Finance') && PK01_Finance::is_closed($r['cost_date'])) throw new Exception('Periode keuangan sudah ditutup.');
        if(!class_exists('PK01_Engine')) throw new Exception('Engine keuangan tidak tersedia.');
        // Gunakan ledger kas yang sama dengan transaksi PK01, tetapi hanya SEKALI setelah approval.
        PK01_Engine::cash('out',(float)$r['amount'],$r['category'],'operational_cost',(int)$id,$r['description'],$r['payment_method'],$r['reference_no']);
        $wpdb->update($t,['status'=>'paid','paid_by'=>get_current_user_id(),'paid_at'=>current_time('mysql')],['id'=>$id]);
        return true;
    }
    public static function confirm_recipient($id){
        global $wpdb;
        $t=self::table();
        if(!$t) throw new Exception('Tabel biaya operasional belum tersedia.');
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id=%d",$id),ARRAY_A);
        if(!$r) throw new Exception('Pengeluaran tidak ditemukan.');
        if($r['status']!=='paid') throw new Exception('Tanda terima hanya dapat dibuat setelah kasir membayar.');
        $uid=get_current_user_id();
        $is_admin=current_user_can('manage_options');
        $role=class_exists('PK01_Authorization') ? PK01_Authorization::effective_role() : '';
        $is_finance=in_array($role,['pk01_admin','pk01_keuangan'],true);
        $recipient_user=(int)($r['recipient_user_id']??0);
        if(!$is_admin && !$is_finance && $recipient_user>0 && $recipient_user!==$uid){
            throw new Exception('Tanda terima hanya dapat dikonfirmasi oleh penerima yang ditunjuk.');
        }
        if(!$is_admin && !$is_finance && $recipient_user<=0){
            throw new Exception('Penerima belum ditentukan. Tetapkan penerima sebelum membuat tanda terima.');
        }
        $updated=$wpdb->update($t,[
            'status'=>'received',
            'recipient_confirmed_at'=>current_time('mysql'),
            'recipient_confirmed_by'=>$uid
        ],['id'=>$id],['%s','%s','%d'],['%d']);
        if($updated===false) throw new Exception($wpdb->last_error?:'Gagal menyimpan tanda terima.');
        return true;
    }
    public static function pdf_receipt(){
        if(!is_user_logged_in()) wp_die('Akses ditolak.');
        $id=absint($_GET['id']??0); $nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));
        if(!wp_verify_nonce($nonce,'pk01_expense_receipt_'.$id)) wp_die('Tautan dokumen tidak valid.');
        if(function_exists('pk01_pdf_prepare_validation')) { global $wpdb; $t=class_exists('PK01_DB')?PK01_DB::t('operational_costs'):''; $r=$t?$wpdb->get_row($wpdb->prepare("SELECT receipt_no,reference_no FROM `{$t}` WHERE id=%d",$id),ARRAY_A):[]; pk01_pdf_prepare_validation('biaya-operasional',$id,$r['receipt_no']??($r['reference_no']??'')); } if(function_exists('pk01_pdf_print_expense_receipt')) { pk01_pdf_print_expense_receipt($id); }
        wp_die('Mesin PDF PK01 belum tersedia.',500);
    }
}
