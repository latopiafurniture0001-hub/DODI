<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$table_name = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('operational_costs') 
    : $wpdb->prefix . 'pk01_operational_costs';

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) === $table_name);

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('finance') || PK01_Authorization::can('operational_costs')));

// 2. LOGIKA BARU: EKSPOR REKAPAN BIAYA KE CSV (AUDIT PAJAK & KEUANGAN)
if (isset($_POST['pk01_export_costs_csv']) && check_admin_referer('pk01_export_costs_nonce')) {
    if ($can_manage && $table_exists) {
        $export_costs = $wpdb->get_results(
            "SELECT cost_date, category, amount, payment_method, reference_no, description, created_at 
             FROM `{$table_name}` ORDER BY cost_date DESC, id DESC LIMIT 5000",
            ARRAY_A
        );
        if (!empty($export_costs)) {
            $filename = 'pk01-biaya-operasional-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Tanggal', 'Kategori Biaya', 'Nominal (Rp)', 'Metode Bayar', 'No. Referensi', 'Keterangan', 'Waktu Input']);
            foreach ($export_costs as $row) {
                fputcsv($out, $row);
            }
            fclose($out);
            exit;
        }
    }
}

// 3. PROSES SIMPAN PENGELUARAN BIAYA USAHA (LOGIKA LAMA TETAP UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_operational_cost'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-cost-alert is-error">⚠️ Anda tidak memiliki izin untuk mencatat biaya usaha.</div>';
    } else {
        $nonce = sanitize_text_field(wp_unslash($_POST['pk01_cost_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'pk01_add_operational_cost')) {
            $notice = '<div class="pk01-cost-alert is-error">⚠️ Sesi telah berakhir atau tidak valid. Silakan muat ulang halaman.</div>';
        } else {
            $cost_date      = sanitize_text_field(wp_unslash($_POST['cost_date'] ?? current_time('Y-m-d')));
            $category       = sanitize_text_field(wp_unslash($_POST['category'] ?? 'Lain-lain'));
            $amount_raw     = sanitize_text_field(wp_unslash($_POST['amount'] ?? '0'));
            $amount         = (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', $amount_raw));
            
            // Pencegahan Pencatatan Ganda Gaji/Upah (Sesuai Aturan Akuntansi PK01)
            if (in_array($category, ['Gaji & Upah', 'Gaji Karyawan', 'Upah Pekerjaan'], true)) { 
                $category = ''; 
            }
            
            $payment_method = sanitize_text_field(wp_unslash($_POST['payment_method'] ?? 'Kas Tunai'));
            $reference_no   = sanitize_text_field(wp_unslash($_POST['reference_no'] ?? ''));
            $description    = sanitize_textarea_field(wp_unslash($_POST['description'] ?? ''));
            $created_by     = get_current_user_id();
            $recipient_name = sanitize_text_field(wp_unslash($_POST['recipient_name'] ?? ''));
            $recipient_user_id = (int)($_POST['recipient_user_id'] ?? 0);

            // Validasi Input
            if ($amount <= 0) {
                $notice = '<div class="pk01-cost-alert is-error">⚠️ Nominal pengeluaran harus lebih besar dari Rp 0.</div>';
            } elseif ($category === '') {
                $notice = '<div class="pk01-cost-alert is-error">⚠️ Gaji dan upah tidak dicatat di menu Biaya Usaha. Gunakan modul <b>Payroll Gaji</b> atau <b>Upah Job Produksi</b> agar pembukuan tidak ganda.</div>';
            } elseif (empty($description)) {
                $notice = '<div class="pk01-cost-alert is-error">⚠️ Keterangan pengeluaran wajib diisi.</div>';
            } else {
                try {
                    $saved = false;
                    if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'add_operational_cost')) {
                        $saved = PK01_Expense_Workflow::create([
                            'cost_date'      => $cost_date,
                            'category'       => $category,
                            'amount'         => $amount,
                            'payment_method' => $payment_method,
                            'reference_no'   => $reference_no,
                            'description'    => $description,
                            'created_by'     => $created_by,
                            'recipient_name' => $recipient_name,
                            'recipient_user_id' => $recipient_user_id,
                        ]);
                    } else {
                        $saved = $wpdb->insert(
                            $table_name,
                            [
                                'cost_date'      => $cost_date,
                                'category'       => $category,
                                'amount'         => $amount,
                                'payment_method' => $payment_method,
                                'reference_no'   => $reference_no,
                                'description'    => $description,
                                'created_by'     => $created_by,
                                'created_at'     => current_time('mysql'),
                            ],
                            ['%s', '%s', '%f', '%s', '%s', '%s', '%d', '%s']
                        );
                    }

                    if ($saved !== false) {
                        $notice = '<div class="pk01-cost-alert is-success">✅ Permintaan pengeluaran sebesar <b>Rp ' . number_format($amount, 0, ',', '.') . '</b> berhasil dibuat dan menunggu persetujuan. Kas belum berkurang sebelum disetujui dan dibayar.</div>';
                        $_POST = [];
                    } else {
                        $notice = '<div class="pk01-cost-alert is-error">❌ Gagal menyimpan pengeluaran: ' . esc_html($wpdb->last_error) . '</div>';
                    }
                } catch (Throwable $e) {
                    $notice = '<div class="pk01-cost-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
                }
            }
        }
    }
}


// 3B. WORKFLOW PERSETUJUAN → PEMBAYARAN KASIR → TANDA TERIMA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_expense_action'])) {
    $id = absint($_POST['expense_id'] ?? 0);
    $act = sanitize_key($_POST['pk01_expense_action'] ?? '');
    $nonce = sanitize_text_field(wp_unslash($_POST['expense_action_nonce'] ?? ''));
    if (!$id || !wp_verify_nonce($nonce, 'pk01_expense_action_' . $id)) {
        $notice = '<div class="pk01-cost-alert is-error">❌ Sesi tidak valid atau dokumen tidak ditemukan. Silakan muat ulang halaman.</div>';
    } else {
        try {
            if (!class_exists('PK01_Expense_Workflow')) {
                throw new Exception('Workflow biaya operasional belum tersedia.');
            }
            if ($act === 'approve') {
                PK01_Expense_Workflow::approve($id);
            } elseif ($act === 'reject') {
                PK01_Expense_Workflow::reject($id, sanitize_textarea_field(wp_unslash($_POST['reason'] ?? '')));
            } elseif ($act === 'pay') {
                PK01_Expense_Workflow::pay($id);
            } elseif ($act === 'receive') {
                PK01_Expense_Workflow::confirm_recipient($id);
            } else {
                throw new Exception('Tindakan biaya tidak dikenali.');
            }
            $notice = '<div class="pk01-cost-alert is-success">✅ Tindakan berhasil diproses.</div>';
        } catch (Throwable $e) {
            $notice = '<div class="pk01-cost-alert is-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

$workflow_rows = [];
if ($table_exists) {
    $workflow_rows = $wpdb->get_results("SELECT * FROM `{$table_name}` ORDER BY id DESC LIMIT 30", ARRAY_A);
}

// 4. HITUNG REKAP BIAYA RIIL DARI DATABASE
$total_today = 0;
$total_month = 0;
$count_month = 0;
$avg_transaction = 0;
$top_category_name = 'Belum ada';
$top_category_amount = 0;

if ($table_exists) {
    $today_str = current_time('Y-m-d');
    $month_str = current_time('Y-m');

    $total_today = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM `{$table_name}` WHERE DATE(cost_date) = %s", $today_str));
    $stats_month = $wpdb->get_row($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) as total, COUNT(id) as jml FROM `{$table_name}` WHERE DATE_FORMAT(cost_date, '%%Y-%%m') = %s", $month_str));

    if ($stats_month) {
        $total_month = (float) ($stats_month->total ?? 0);
        $count_month = (int) ($stats_month->jml ?? 0);
        if ($count_month > 0) {
            $avg_transaction = $total_month / $count_month;
        }
    }

    // Ambil Top Kategori Bulan Ini
    $top_cat_row = $wpdb->get_row($wpdb->prepare(
        "SELECT category, SUM(amount) as cat_total 
         FROM `{$table_name}` 
         WHERE DATE_FORMAT(cost_date, '%%Y-%%m') = %s 
         GROUP BY category ORDER BY cat_total DESC LIMIT 1",
        $month_str
    ));
    if ($top_cat_row) {
        $top_category_name = $top_cat_row->category;
        $top_category_amount = (float) $top_cat_row->cat_total;
    }
}

// Rekomendasi No. Referensi Dinamis
$suggested_ref = 'EXP-' . current_time('ym') . '-' . str_pad((string)($count_month + 1), 3, '0', STR_PAD_LEFT);
?>

<style>
:root {
    --pk-cost-navy: #0f172a;
    --pk-cost-border: #e2e8f0;
    --pk-cost-red: #dc2626;
    --pk-cost-blue: #2563eb;
    --pk-cost-green: #059669;
    --pk-cost-amber: #d97706;
}

.pk01-costs-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 0 auto 30px;
}
.pk01-costs-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-cost-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #450a0a 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-cost-eyebrow {
    display: inline-block;
    background: rgba(239, 68, 68, 0.2);
    color: #fca5a5;
    border: 1px solid rgba(239, 68, 68, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-cost-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-cost-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-cost-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-box {
    background: #ffffff;
    border: 1px solid var(--pk-cost-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-box::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-box.c-red::before   { background: var(--pk-cost-red); }
.pk01-kpi-box.c-blue::before  { background: var(--pk-cost-blue); }
.pk01-kpi-box.c-amber::before { background: var(--pk-cost-amber); }
.pk01-kpi-box.c-green::before { background: var(--pk-cost-green); }

.pk01-kpi-box small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    display: block;
}
.pk01-kpi-box strong {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-box span {
    font-size: 11px;
    color: #64748b;
}

/* Form Card */
.pk01-cost-card {
    background: #ffffff;
    border: 1px solid var(--pk-cost-border);
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-cost-card-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-cost-card-head h2 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}
.pk01-cost-card-head p {
    margin: 4px 0 0 0;
    font-size: 13px;
    color: #64748b;
}

/* Grid Form */
.pk01-cost-form-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}
@media (max-width: 900px) {
    .pk01-cost-form-grid { grid-template-columns: 1fr; }
}

.pk01-form-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-form-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-cost-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-cost-input:focus {
    outline: none;
    border-color: #2563eb;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Quick Amount Pills */
.pk01-amount-pills {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 4px;
}
.pk01-amount-pill {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 10px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
}
.pk01-amount-pill:hover {
    background: #e2e8f0;
    color: #0f172a;
}

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }

.pk01-cost-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-cost-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-cost-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-costs-cockpit">
    
    <!-- 1. HERO COCKPIT -->
    <header class="pk01-cost-hero">
        <div>
            <span class="pk01-cost-eyebrow">OPERATIONAL EXPENDITURE &bull; OPEX</span>
            <h1>Biaya Usaha &amp; Beban Operasional</h1>
            <p>
                Pencatatan pengeluaran beban usaha rutin seperti listrik, sewa tempat, internet, perlengkapan toko, transport, perizinan, dan pemasaran. 
                Gaji karyawan dan upah job dicatat terpisah agar pembukuan tidak tercampur ganda.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_costs_nonce'); ?>
                <input type="hidden" name="pk01_export_costs_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Rekap Biaya (.CSV)
                </button>
            </form>
        </div>
    </header>

    <!-- 2. 4 EXECUTIVE KPI CARDS -->
    <div class="pk01-cost-kpis">
        <div class="pk01-kpi-box c-red">
            <small>Pengeluaran Hari Ini</small>
            <strong style="color:#dc2626;">Rp <?php echo number_format($total_today, 0, ',', '.'); ?></strong>
            <span>Kas operasional terpakai hari ini</span>
        </div>

        <div class="pk01-kpi-box c-blue">
            <small>Total Biaya Bulan Ini</small>
            <strong style="color:#1d4ed8;">Rp <?php echo number_format($total_month, 0, ',', '.'); ?></strong>
            <span><?php echo (int)$count_month; ?> transaksi pengeluaran tercatat</span>
        </div>

        <div class="pk01-kpi-box c-amber">
            <small>Rata-rata per Transaksi</small>
            <strong style="color:#b45309;">Rp <?php echo number_format($avg_transaction, 0, ',', '.'); ?></strong>
            <span>Rata-rata nominal pengeluaran</span>
        </div>

        <div class="pk01-kpi-box c-green">
            <small>Pos Biaya Terbesar (Bulan Ini)</small>
            <strong style="font-size:16px;margin-top:10px;color:#0f172a;">
                <?php echo esc_html($top_category_name); ?>
            </strong>
            <span style="color:#047857;font-weight:700;">Rp <?php echo number_format($top_category_amount, 0, ',', '.'); ?></span>
        </div>
    </div>

    <?php echo $notice; ?>

    <!-- 3. FORM CATAT BIAYA BARU -->
    <?php if ($can_manage): ?>
    <section class="pk01-cost-card">
        <div class="pk01-cost-card-head">
            <div>
                <h2>➕ Catat Pengeluaran Biaya Usaha Baru</h2>
                <p>Pengeluaran langsung memotong saldo Buku Kas dan mengurangi Laba Bersih di Laporan Laba Rugi.</p>
            </div>
            <span style="font-size:11px;background:#f1f5f9;border:1px solid #cbd5e1;padding:4px 10px;border-radius:12px;font-weight:600;color:#475569;">
                Otomatis Sync ke GL
            </span>
        </div>

        <form method="post" action="">
            <?php echo wp_nonce_field('pk01_add_operational_cost', 'pk01_cost_nonce', true, false); ?>
            <input type="hidden" name="pk01_save_operational_cost" value="1">

            <div class="pk01-cost-form-grid">
                <div class="pk01-form-item">
                    <label>Tanggal Pengeluaran <span style="color:#dc2626;">*</span></label>
                    <input type="date" name="cost_date" class="pk01-cost-input" value="<?php echo esc_attr($_POST['cost_date'] ?? current_time('Y-m-d')); ?>" required>
                </div>

                <div class="pk01-form-item">
                    <label>Kategori Biaya <span style="color:#dc2626;">*</span></label>
                    <select name="category" class="pk01-cost-input" required>
                        <?php 
                        $categories = [
                            'Operasional Toko'       => 'Operasional Toko / Kantor',
                            'Listrik & Internet'     => 'Listrik, Air & Internet',
                            'Sewa Tempat'            => 'Sewa Tempat / Bangunan',
                            'Logistik & Pengiriman'  => 'Logistik, Bensin & Transport',
                            'Pemasaran & Iklan'      => 'Pemasaran, Iklan & Promosi',
                            'Peralatan & Maintenance'=> 'Peralatan, ATK & Servis Mesin',
                            'Pajak & Legalitas'      => 'Pajak & Biaya Legalitas Usaha',
                            'Lain-lain'              => 'Pengeluaran Lain-lain',
                        ];
                        $selected_cat = $_POST['category'] ?? 'Operasional Toko';
                        foreach ($categories as $key => $label): 
                        ?>
                            <option value="<?php echo esc_attr($key); ?>" <?php selected($selected_cat, $key); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pk01-form-item">
                    <label>Sumber Dana / Metode Pembayaran <span style="color:#dc2626;">*</span></label>
                    <select name="payment_method" class="pk01-cost-input">
                        <option value="Kas Tunai" <?php selected($_POST['payment_method'] ?? '', 'Kas Tunai'); ?>>Kas Kecil / Tunai (Petty Cash)</option>
                        <option value="Transfer Bank" <?php selected($_POST['payment_method'] ?? '', 'Transfer Bank'); ?>>Transfer Bank (Buku Kas Bank)</option>
                        <option value="Kartu Debit/Kredit" <?php selected($_POST['payment_method'] ?? '', 'Kartu Debit/Kredit'); ?>>Kartu Debit / Kredit</option>
                    </select>
                </div>

                <div class="pk01-form-item">
                    <label>Nominal Pengeluaran (Rp) <span style="color:#dc2626;">*</span></label>
                    <input type="number" id="pk01-cost-amount" name="amount" min="1" step="any" class="pk01-cost-input" value="<?php echo esc_attr($_POST['amount'] ?? ''); ?>" placeholder="Contoh: 150000" required>
                    <div class="pk01-amount-pills">
                        <span class="pk01-amount-pill" data-amt="50000">+50 rb</span>
                        <span class="pk01-amount-pill" data-amt="100000">+100 rb</span>
                        <span class="pk01-amount-pill" data-amt="250000">+250 rb</span>
                        <span class="pk01-amount-pill" data-amt="500000">+500 rb</span>
                        <span class="pk01-amount-pill" data-amt="1000000">+1 jt</span>
                    </div>
                </div>

                <div class="pk01-form-item" style="grid-column: span 2;">
                    <label>No. Referensi / Bukti / Nota (Opsional)</label>
                    <input type="text" name="reference_no" class="pk01-cost-input" value="<?php echo esc_attr($_POST['reference_no'] ?? ''); ?>" placeholder="Contoh: <?php echo esc_attr($suggested_ref); ?>">
                </div>

                <div class="pk01-form-item" style="grid-column: 1 / -1;">
                    <label>Keterangan / Keperluan Pengeluaran <span style="color:#dc2626;">*</span></label>
                    <textarea name="description" rows="2" class="pk01-cost-input" placeholder="Rincian kebutuhan pengeluaran operasional..." required><?php echo esc_textarea($_POST['description'] ?? ''); ?></textarea>
                </div>

                <div style="grid-column: 1 / -1; margin-top: 6px;">
                    <button class="pk01-btn pk01-btn-primary" type="submit">
                        💾 Simpan Biaya Usaha
                    </button>
                </div>
            </div>
        </form>
    </section>
    <?php endif; ?>


<?php if (!empty($workflow_rows)): ?>
<section class="pk01-cost-card" style="margin-top:24px;">
    <div class="pk01-cost-card-head">
        <div>
            <h2>Alur Persetujuan &amp; Tanda Terima</h2>
            <p>Setiap pengeluaran bergerak dari permintaan → persetujuan → pembayaran → tanda terima. Kas tidak berkurang sebelum pembayaran benar-benar diproses.</p>
        </div>
    </div>
    <div style="overflow:auto;">
        <table style="width:100%;border-collapse:collapse;min-width:760px;">
            <thead><tr><th>Dokumen</th><th>Nominal</th><th>Status</th><th>Penerima</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($workflow_rows as $r):
                $id = (int)($r['id'] ?? 0);
                $status = sanitize_key($r['status'] ?? '');
                $nonce = wp_create_nonce('pk01_expense_action_' . $id);
            ?>
                <tr>
                    <td><strong><?php echo esc_html($r['receipt_no'] ?? ($r['reference_no'] ?? '-')); ?></strong><br><small><?php echo esc_html(($r['category'] ?? '-') . ' · ' . ($r['cost_date'] ?? '-')); ?></small></td>
                    <td>Rp <?php echo number_format((float)($r['amount'] ?? 0), 0, ',', '.'); ?></td>
                    <td><?php echo esc_html(strtoupper(str_replace('_', ' ', $status))); ?></td>
                    <td><?php echo esc_html($r['recipient_name'] ?? '-'); ?></td>
                    <td style="white-space:nowrap;">
                        <?php if ($status === 'pending_approval' && (current_user_can('manage_options') || (class_exists('PK01_Authorization') && in_array(PK01_Authorization::effective_role(), ['pk01_admin','pk01_keuangan'], true)))): ?>
                            <form method="post" style="display:inline-block;margin:0 4px 4px 0;">
                                <input type="hidden" name="pk01_expense_action" value="approve">
                                <input type="hidden" name="expense_id" value="<?php echo esc_attr($id); ?>">
                                <input type="hidden" name="expense_action_nonce" value="<?php echo esc_attr($nonce); ?>">
                                <button type="submit">Setujui</button>
                            </form>
                        <?php endif; ?>
                        <?php if ($status === 'approved' && (current_user_can('manage_options') || (class_exists('PK01_Authorization') && in_array(PK01_Authorization::effective_role(), ['pk01_admin','pk01_keuangan','pk01_kasir'], true)))): ?>
                            <form method="post" style="display:inline-block;margin:0 4px 4px 0;">
                                <input type="hidden" name="pk01_expense_action" value="pay">
                                <input type="hidden" name="expense_id" value="<?php echo esc_attr($id); ?>">
                                <input type="hidden" name="expense_action_nonce" value="<?php echo esc_attr($nonce); ?>">
                                <button type="submit">Kasir Bayar</button>
                            </form>
                        <?php endif; ?>
                        <?php if ($status === 'paid' && (current_user_can('manage_options') || get_current_user_id() > 0)): ?>
                            <form method="post" style="display:inline-block;margin:0 4px 4px 0;">
                                <input type="hidden" name="pk01_expense_action" value="receive">
                                <input type="hidden" name="expense_id" value="<?php echo esc_attr($id); ?>">
                                <input type="hidden" name="expense_action_nonce" value="<?php echo esc_attr($nonce); ?>">
                                <button type="submit">Tanda Terima</button>
                            </form>
                        <?php endif; ?>
                        <?php if (in_array($status, ['paid','received'], true) && function_exists('pk01_print_url')): ?>
                            <a target="_blank" rel="noopener" href="<?php echo esc_url(pk01_print_url('biaya-operasional', $id)); ?>">PDF Profesional</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php endif; ?>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var amtInput = document.getElementById('pk01-cost-amount');
    var pills = document.querySelectorAll('.pk01-amount-pill');

    if (amtInput && pills.length > 0) {
        pills.forEach(function(p) {
            p.addEventListener('click', function() {
                var cur = parseFloat(amtInput.value) || 0;
                var add = parseFloat(this.dataset.amt) || 0;
                amtInput.value = cur + add;
                amtInput.focus();
            });
        });
    }
});
</script>

<?php
// 4. PEMUATAN TABEL RIWAYAT MODUL DENGAN MULTI-PATH RESOLVER AMAN
$loaded = false;
$candidates = [];

if (defined('PK01_DIR')) {
    $candidates[] = trailingslashit(PK01_DIR) . 'includes/core/view/tampilan-data-modul.php';
}


foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        require_once $cand;
        $loaded = true;
        break;
    }
}

if (function_exists('pk01_tampilkan_data_modul')) {
    pk01_tampilkan_data_modul('operational_costs', 'Biaya Usaha', 'KEUANGAN', 'Daftar riwayat seluruh pengeluaran operasional yang tersimpan di sistem.');
} elseif (!$loaded) {
    echo '<div style="background:#ffffff;border:1px dashed #cbd5e1;border-radius:12px;padding:26px;text-align:center;color:#64748b;font-size:13px;">
            📁 Modul antarmuka tabel <code>tampilan-data-modul.php</code> belum ditemukan di folder <code>includes/</code>.
          </div>';
}