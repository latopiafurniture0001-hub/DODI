<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$current_user  = wp_get_current_user();
$is_superadmin = current_user_can('manage_options') || in_array('administrator', (array)$current_user->roles, true);
$notice        = '';
$action        = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('closing')
    : esc_url($_SERVER['REQUEST_URI'] ?? '');

// Helper Nama Tabel Resmi PK01
$tbl_closings = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('closings') : $wpdb->prefix . 'pk01_closings';
$tbl_wages    = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('job_wages') : $wpdb->prefix . 'pk01_job_wages';
$tbl_tx       = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('cash_ledger') : $wpdb->prefix . 'pk01_cash_ledger';
$tbl_orders   = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('orders') : $wpdb->prefix . 'pk01_orders';
$tbl_financial_periods = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('financial_periods') : $wpdb->prefix . 'pk01_financial_periods';

// AUTO-MIGRATION TABEL TUTUP PERIODE BUKU
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_closings)) !== $tbl_closings) {
    $wpdb->query("CREATE TABLE IF NOT EXISTS `{$tbl_closings}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `period_code` varchar(10) NOT NULL,
        `period_name` varchar(64) NOT NULL,
        `start_date` date NOT NULL,
        `end_date` date NOT NULL,
        `reference_no` varchar(100) NOT NULL DEFAULT '',
        `total_revenue` decimal(15,2) NOT NULL DEFAULT 0.00,
        `total_expense` decimal(15,2) NOT NULL DEFAULT 0.00,
        `net_profit` decimal(15,2) NOT NULL DEFAULT 0.00,
        `cash_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
        `bank_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
        `status` varchar(20) NOT NULL DEFAULT 'closed',
        `notes` text DEFAULT NULL,
        `closed_by` bigint(20) unsigned DEFAULT 0,
        `closed_at` datetime DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `period_code` (`period_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
}

$closing_ref_col = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$tbl_closings}` LIKE %s", 'reference_no'));
if (!$closing_ref_col) { $wpdb->query("ALTER TABLE `{$tbl_closings}` ADD `reference_no` varchar(100) NOT NULL DEFAULT '' AFTER `end_date`"); }

// ==========================================================================
// 1. PROSES EKSEKUSI TUTUP BUKU & RE-OPEN (LOGIKA BACKEND)
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_closing_action'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_closing_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_closing_save')) {
        $notice = '<div class="pk-alert pk-alert-error">⚠️ Sesi keamanan tidak valid atau kedaluwarsa. Silakan muat ulang.</div>';
    } else {
        try {
            $act = sanitize_key($_POST['pk01_closing_action']);

            if ($act === 'close_period') {
                if (!$is_superadmin && class_exists('PK01_Authorization') && !PK01_Authorization::can_action('finance_reports', 'approve')) {
                    throw new Exception('Anda tidak memiliki wewenang untuk menutup periode keuangan.');
                }

                $month       = str_pad((string)absint($_POST['period_month'] ?? date('m')), 2, '0', STR_PAD_LEFT);
                $year        = (string)absint($_POST['period_year'] ?? date('Y'));
                if ((int)$month < 1 || (int)$month > 12 || (int)$year < 2020 || (int)$year > ((int)current_time('Y') + 1)) {
                    throw new Exception('Periode tutup buku tidak valid.');
                }
                $period_code = sprintf('%04d-%02d', (int)$year, (int)$month);
                $start_date  = $period_code . '-01';
                $end_date    = date('Y-m-t', strtotime($start_date));
                $period_name = date_i18n('F Y', strtotime($start_date));
                $notes       = sanitize_textarea_field($_POST['notes'] ?? '');
                $cash_balance = max(0, (float)($_POST['cash_balance'] ?? 0));
                $bank_balance = max(0, (float)($_POST['bank_balance'] ?? 0));

                // SOURCE OF TRUTH: financial_periods + PK01_Finance. Jangan membuat
                // closing berjalan sendiri di luar General Ledger.
                if (!class_exists('PK01_Finance') || !method_exists('PK01_Finance', 'close_period')) {
                    throw new Exception('Finance Engine untuk tutup buku belum tersedia.');
                }
                PK01_Finance::ensure_current_period($start_date);
                PK01_Finance::close_period($period_code);

                // Ambil angka resmi setelah GL disinkronkan, bukan angka dari hidden input.
                $official = class_exists('PK01_Engine') && method_exists('PK01_Engine', 'financial_report')
                    ? PK01_Engine::financial_report($start_date, $end_date) : [];
                $total_rev = (float)($official['gross_sales'] ?? $official['sales'] ?? 0);
                $total_exp = (float)(($official['hpp'] ?? 0) + ($official['operational_cost'] ?? $official['operational_costs'] ?? 0) + ($official['payroll'] ?? 0) + ($official['job_wages'] ?? 0) + ($official['affiliate_commission'] ?? 0) + ($official['sales_commission'] ?? 0) + ($official['marketplace_fees'] ?? 0));
                $net_profit = (float)($official['net_profit'] ?? ($total_rev - $total_exp));

                // closings tetap dipertahankan sebagai snapshot/audit legacy, tetapi status
                // canonical dikendalikan oleh financial_periods.
                $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$tbl_closings}` WHERE period_code = %s", $period_code));
                $closing_no = class_exists('PK01_Engine') ? PK01_Engine::document_number('closing') : ('CLOSE-'.$period_code);
                $existing_no = $existing ? $wpdb->get_var($wpdb->prepare("SELECT reference_no FROM `{$tbl_closings}` WHERE id=%d",(int)$existing)) : '';
                if ($existing_no) $closing_no = $existing_no;
                $data = [
                    'period_code'=>$period_code,'period_name'=>$period_name,'start_date'=>$start_date,'end_date'=>$end_date,'reference_no'=>$closing_no,
                    'total_revenue'=>$total_rev,'total_expense'=>$total_exp,'net_profit'=>$net_profit,
                    'cash_balance'=>$cash_balance,'bank_balance'=>$bank_balance,'status'=>'closed','notes'=>$notes,
                    'closed_by'=>get_current_user_id(),'closed_at'=>current_time('mysql')
                ];
                if ($existing) $wpdb->update($tbl_closings, $data, ['id'=>(int)$existing]);
                else $wpdb->insert($tbl_closings, $data);

                $notice = '<div class="pk-alert pk-alert-success">🔒 <strong>Periode ' . esc_html($period_name) . ' berhasil ditutup dan dikunci.</strong> General Ledger sudah disinkronkan terlebih dahulu; Laporan Keuangan dan Tutup Buku sekarang memakai periode yang sama.</div>';
            } elseif ($act === 'reopen_period' && $is_superadmin) {
                $close_id = absint($_POST['closing_id'] ?? 0);
                if ($close_id <= 0) throw new Exception('ID Tutup Buku tidak valid.');

                $close_row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_closings}` WHERE id = %d", $close_id), ARRAY_A);
                if (!$close_row) throw new Exception('Data Tutup Buku tidak ditemukan.');
                $period_code = sanitize_text_field($close_row['period_code']);
                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_financial_periods)) === $tbl_financial_periods) {
                    $wpdb->update($tbl_financial_periods, ['status'=>'open','closed_by'=>0,'closed_at'=>null], ['period_key'=>$period_code]);
                }
                $wpdb->update($tbl_closings, [
                    'status' => 'reopened',
                    'notes'  => ($close_row['notes'] ?? '') . ' [DIBUKA KEMBALI oleh ' . $current_user->display_name . ' pada ' . current_time('d/m/Y H:i') . ']'
                ], ['id' => $close_id]);
                if (class_exists('PK01_Audit')) PK01_Audit::info('finance_period_reopened','finance','financial_period',$period_code,'Periode keuangan dibuka kembali',['period_key'=>$period_code]);

                $notice = '<div class="pk-alert pk-alert-success">🔓 <strong>Kunci Buku Berhasil Dibuka!</strong> Status periode Finance Engine juga dikembalikan menjadi terbuka.</div>';
            }
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error">❌ <strong>Gagal:</strong> ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// ==========================================================================
// 2. HITUNG METRIK KEUANGAN PERIODE AKTIF (INTEGRASI LAPORAN REAL-TIME)
// ==========================================================================
$cur_m = sanitize_text_field($_GET['sel_month'] ?? current_time('m'));
$cur_y = sanitize_text_field($_GET['sel_year'] ?? current_time('Y'));
$cur_period_code = sprintf('%04d-%02d', $cur_y, $cur_m);

$start_cur = sprintf('%04d-%02d-01', $cur_y, $cur_m);
$end_cur   = date('Y-m-t', strtotime($start_cur));

// A. Hitung Pendapatan (Penjualan / Invoice / Cash In)
$cur_revenue = 0.0;
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_orders)) === $tbl_orders) {
    $cur_revenue += (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(total_amount), 0) FROM `{$tbl_orders}` 
         WHERE status IN ('completed','delivered','paid') 
         AND DATE(created_at) BETWEEN %s AND %s", 
        $start_cur, $end_cur
    ));
} elseif ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_tx)) === $tbl_tx) {
    $cur_revenue += (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_tx}` 
         WHERE direction = 'in' AND status = 'cleared' 
         AND DATE(created_at) BETWEEN %s AND %s", 
        $start_cur, $end_cur
    ));
}

// B. Hitung Beban Upah Tukang & Tenaga Kerja (Dari Modul Job PK01)
$cur_wages = 0.0;
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_wages)) === $tbl_wages) {
    $cur_wages = (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_wages}` 
         WHERE status = 'paid' 
         AND DATE(COALESCE(paid_at, created_at)) BETWEEN %s AND %s", 
        $start_cur, $end_cur
    ));
}

// C. Hitung Beban Operasional / Kas Keluar Lainnya
$cur_expenses = $cur_wages;
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_tx)) === $tbl_tx) {
    $other_exp = (float)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_tx}` 
         WHERE direction = 'out' 
         AND DATE(created_at) BETWEEN %s AND %s", 
        $start_cur, $end_cur
    ));
    $cur_expenses += $other_exp;
}

// D. Estimasi Laba/Rugi Bersih Sebelum Closing
$cur_net_profit = $cur_revenue - $cur_expenses;

// E. Cek Apakah Periode Terpilih Sudah Berstatus Terkunci
$active_closing_record = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM `{$tbl_closings}` WHERE period_code = %s LIMIT 1", $cur_period_code
), ARRAY_A);
$canonical_period = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM `{$tbl_financial_periods}` WHERE period_key = %s LIMIT 1", $cur_period_code
), ARRAY_A);
if ($canonical_period) {
    $active_closing_record = array_merge($active_closing_record ?: [], [
        'period_code'=>$cur_period_code,
        'period_name'=>date_i18n('F Y', strtotime($start_cur)),
        'closed_at'=>$canonical_period['closed_at'] ?? ($active_closing_record['closed_at'] ?? null),
        'status'=>$canonical_period['status'],
    ]);
}
$is_period_closed = ($canonical_period && ($canonical_period['status'] ?? '') === 'closed');

// Riwayat Semua Periode yang Pernah Ditutup
$closings_history = $wpdb->get_results(
    "SELECT c.*, u.display_name AS closer_name 
     FROM `{$tbl_closings}` c 
     LEFT JOIN {$wpdb->users} u ON u.ID = c.closed_by 
     ORDER BY c.period_code DESC LIMIT 24", 
    ARRAY_A
) ?: [];

// URL Tautan Pintas ke Modul Laporan Keuangan Terpadu
$url_laporan_keuangan = class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes', 'frontend_url_public')
    ? PK01_Shortcodes::frontend_url_public('finance')
    : admin_url('admin.php?page=pk01-finance');
?>

<style>
/* ==========================================================================
   MASTERPIECE CLOSING DASHBOARD STYLES
   ========================================================================== */
.pk-close-wrap {
    --pk-navy: #0f172a;
    --pk-surface: #ffffff;
    --pk-bg: #f8fafc;
    --pk-border: #e2e8f0;
    --pk-accent: #2563eb;
    --pk-accent-hover: #1d4ed8;
    --pk-green: #10b981;
    --pk-green-dark: #047857;
    --pk-red: #ef4444;
    --pk-amber: #f59e0b;
    --pk-radius: 14px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    margin-top: 15px;
}
.pk-close-wrap * { box-sizing: border-box; }

.pk-alert {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 18px;
    border-radius: var(--pk-radius);
    margin-bottom: 22px;
    font-size: 14px;
    line-height: 1.5;
}
.pk-alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk-alert-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }

/* Hero Banner */
.pk-hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: var(--pk-radius);
    padding: 24px 28px;
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk-hero-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk-hero-banner h2 { margin: 0 0 6px 0; font-size: 24px; font-weight: 800; color: #f8fafc; }
.pk-hero-banner p { color: #cbd5e1; font-size: 13px; margin: 0; max-width: 650px; line-height: 1.5; }

/* Tombol Ekosistem Laporan Keuangan */
.pk-fin-hub-bar {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 24px;
}
.pk-hub-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: #ffffff;
    border: 1px solid var(--pk-border);
    padding: 10px 16px;
    border-radius: 10px;
    font-size: 12px;
    font-weight: 700;
    color: #334155;
    text-decoration: none !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    transition: all 0.2s ease;
}
.pk-hub-link:hover {
    border-color: var(--pk-accent);
    color: var(--pk-accent);
    transform: translateY(-1px);
}
.pk-hub-link.primary-hub {
    background: #eff6ff;
    border-color: #bfdbfe;
    color: #1e40af;
}

/* Scorecards Finansial */
.pk-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 14px;
    margin-bottom: 24px;
}
.pk-kpi-card {
    background: var(--pk-surface);
    border: 1px solid var(--pk-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    border-left: 4px solid #cbd5e1;
}
.pk-kpi-card.c-green { border-left-color: #10b981; }
.pk-kpi-card.c-red   { border-left-color: #ef4444; }
.pk-kpi-card.c-blue  { border-left-color: #3b82f6; }
.pk-kpi-card.c-gold  { border-left-color: #f59e0b; background: #fffdf5; }
.pk-kpi-card small { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #64748b; display: block; }
.pk-kpi-card strong { font-size: 22px; font-weight: 900; color: #0f172a; display: block; margin: 4px 0 2px 0; }
.pk-kpi-card span { font-size: 11px; color: #64748b; }

/* Grid Form Closing & Checklist */
.pk-main-grid {
    display: grid;
    grid-template-columns: 1.8fr 1.2fr;
    gap: 22px;
    align-items: start;
    margin-bottom: 26px;
}
@media (max-width: 960px) {
    .pk-main-grid { grid-template-columns: 1fr; }
}

.pk-panel {
    background: var(--pk-surface);
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-panel-head {
    padding: 16px 20px;
    background: #fafbfc;
    border-bottom: 1px solid var(--pk-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk-panel-head h3 { margin: 0; font-size: 16px; font-weight: 800; color: #0f172a; }
.pk-panel-body { padding: 20px; }

/* Form Controls */
.pk-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 14px;
}
.pk-field { display: flex; flex-direction: column; gap: 5px; }
.pk-field label { font-size: 12px; font-weight: 700; color: #334155; }
.pk-field input, .pk-field select, .pk-field textarea {
    width: 100%;
    border: 1px solid var(--pk-border);
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 13px;
    background: #fff;
    color: #0f172a;
}
.pk-field input:focus, .pk-field select:focus, .pk-field textarea:focus {
    border-color: var(--pk-accent);
    outline: none;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.pk-btn-close-action {
    width: 100%;
    padding: 14px;
    font-size: 14px;
    font-weight: 800;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    background: #0f172a;
    color: #ffffff;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    margin-top: 16px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
}
.pk-btn-close-action:hover { background: #1e293b; }

/* Audit Checklist Card */
.pk-checklist-card {
    background: #ffffff;
    border: 1px solid var(--pk-border);
    border-radius: var(--pk-radius);
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-check-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    margin-bottom: 8px;
    font-size: 12px;
}
.pk-check-icon { font-size: 16px; line-height: 1; }

/* Tabel Riwayat Closing */
.pk-table-panel {
    background: var(--pk-surface);
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-table-responsive { width: 100%; overflow-x: auto; }
.pk-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk-table th {
    background: #f8fafc;
    color: #64748b;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.05em;
    padding: 12px 16px;
    border-bottom: 1px solid var(--pk-border);
}
.pk-table td {
    padding: 13px 16px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk-table tr:hover td { background: #fbfcfe; }

.pk-badge-closed {
    background: #dcfce7;
    color: #15803d;
    font-size: 11px;
    font-weight: 800;
    padding: 3px 8px;
    border-radius: 6px;
}
.pk-badge-open {
    background: #fef3c7;
    color: #b45309;
    font-size: 11px;
    font-weight: 800;
    padding: 3px 8px;
    border-radius: 6px;
}
</style>

<div class="pk-close-wrap">
    
    <!-- 1. HERO BANNER -->
    <header class="pk-hero-banner">
        <div>
            <span class="pk-hero-eyebrow">FINANCIAL CLOSING &bull; AKUNTANSI TERPADU</span>
            <h2>Tutup Buku Periode &amp; Penguncian Laporan Keuangan</h2>
            <p>Kunci transaksi bulanan/tahunan untuk membukukan Laba Bersih ke Ekuitas/Laba Ditahan, memverifikasi rekonsiliasi kas/bank, dan mencegah perubahan data masa lampau.</p>
        </div>
        <div>
            <span style="font-size:12px;font-weight:bold;background:rgba(255,255,255,0.15);padding:6px 12px;border-radius:8px;">
                🗓️ Periode Aktif: <?php echo esc_html(date('F Y', strtotime($start_cur))); ?>
            </span>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. PINTASAN EKOSISTEM LAPORAN KEUANGAN RESMI (INTEGRASI PENUH) -->
    <div class="pk-fin-hub-bar">
        <a href="<?php echo esc_url(add_query_arg(['pk01_view' => 'finance', 'report' => 'profit_loss'], $url_laporan_keuangan)); ?>" class="pk-hub-link primary-hub" target="_blank">
            📈 Buka Laporan Laba Rugi Resmi
        </a>
        <a href="<?php echo esc_url(add_query_arg(['pk01_view' => 'finance', 'report' => 'balance_sheet'], $url_laporan_keuangan)); ?>" class="pk-hub-link" target="_blank">
            🏛️ Neraca Saldo &amp; Keuangan
        </a>
        <a href="<?php echo esc_url(add_query_arg(['pk01_view' => 'finance', 'report' => 'cash_flow'], $url_laporan_keuangan)); ?>" class="pk-hub-link" target="_blank">
            💸 Laporan Arus Kas
        </a>
        <a href="<?php echo esc_url(function_exists('pk01_print_url') ? pk01_print_url('laporan-keuangan') : '#'); ?>" class="pk-hub-link" target="_blank">
            🖨️ Cetak PDF Laporan Keuangan
        </a>
    </div>

    <!-- 3. SCORECARD ESTIMASI FINANSIAL PERIODE AKTIF -->
    <div class="pk-kpi-grid">
        <div class="pk-kpi-card c-green">
            <small>Total Pendapatan (Omzet)</small>
            <strong style="color:#059669;">Rp <?php echo number_format($cur_revenue, 0, ',', '.'); ?></strong>
            <span>Pesanan lunas &amp; kas masuk</span>
        </div>
        <div class="pk-kpi-card c-red">
            <small>Total Beban &amp; Upah Tukang</small>
            <strong style="color:#dc2626;">Rp <?php echo number_format($cur_expenses, 0, ',', '.'); ?></strong>
            <span>Upah Job: Rp <?php echo number_format($cur_wages, 0, ',', '.'); ?></span>
        </div>
        <div class="pk-kpi-card c-blue">
            <small>Estimasi Laba/Rugi Bersih</small>
            <strong style="color:<?php echo $cur_net_profit >= 0 ? '#2563eb' : '#dc2626'; ?>;">
                Rp <?php echo number_format($cur_net_profit, 0, ',', '.'); ?>
            </strong>
            <span><?php echo $cur_net_profit >= 0 ? 'Surplus (Profit)' : 'Defisit (Rugi Operasional)'; ?></span>
        </div>
        <div class="pk-kpi-card c-gold">
            <small>Status Buku Periode Ini</small>
            <strong style="font-size:18px;color:#d97706;">
                <?php echo $is_period_closed ? '🔒 SUDAH DIKUNCI' : '⏳ BELUM DITUTUP'; ?>
            </strong>
            <span><?php echo $is_period_closed ? 'Buku resmi telah dikunci' : 'Siap diverifikasi dan ditutup'; ?></span>
        </div>
    </div>

    <!-- 4. FORM PENUTUPAN BUKU & CHECKLIST PRA-CLOSING -->
    <div class="pk-main-grid">
        <!-- FORMULIR EKSEKUSI CLOSING -->
        <div class="pk-panel">
            <div class="pk-panel-head">
                <h3>Formulir Tutup Periode (Closing Buku)</h3>
                <?php if ($is_period_closed): ?>
                    <span class="pk-badge-closed">✓ Status: Dikunci</span>
                <?php else: ?>
                    <span class="pk-badge-open">Draft / Berjalan</span>
                <?php endif; ?>
            </div>
            <div class="pk-panel-body">
                <?php if ($is_period_closed): ?>
                    <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:16px;margin-bottom:14px;">
                        <strong style="color:#15803d;display:block;font-size:14px;margin-bottom:4px;">
                            🔒 Periode Buku <?php echo esc_html($active_closing_record['period_name']); ?> Telah Ditutup!
                        </strong>
                        <p style="font-size:12px;color:#475569;margin:0 0 10px 0;">
                            Ditutup pada <strong><?php echo esc_html(date('d F Y &bull; H:i', strtotime($active_closing_record['closed_at']))); ?> WIB</strong>.<br>
                            Laba Bersih yang dibukukan: <strong style="color:#059669;">Rp <?php echo number_format((float)$active_closing_record['net_profit'], 0, ',', '.'); ?></strong>
                        </p>
                        <?php if ($is_superadmin): ?>
                            <form method="post" style="margin:0;">
                                <?php echo wp_nonce_field('pk01_closing_save', 'pk01_closing_nonce', true, false); ?>
                                <input type="hidden" name="pk01_closing_action" value="reopen_period">
                                <input type="hidden" name="closing_id" value="<?php echo (int)$active_closing_record['id']; ?>">
                                <button type="submit" onclick="return confirm('Buka kembali buku periode ini? Pembukuan akan berstatus terbuka.');" style="background:#dc2626;color:#fff;border:none;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:bold;cursor:pointer;">
                                    🔓 Buka Kembali Kunci Buku (Khusus Superadmin)
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?php echo esc_url($action); ?>">
                    <?php echo wp_nonce_field('pk01_closing_save', 'pk01_closing_nonce', true, false); ?>
                    <input type="hidden" name="pk01_closing_action" value="close_period">
                    <input type="hidden" name="total_revenue" value="<?php echo esc_attr($cur_revenue); ?>">
                    <input type="hidden" name="total_expense" value="<?php echo esc_attr($cur_expenses); ?>">

                    <div class="pk-form-grid">
                        <div class="pk-field">
                            <label>Bulan Periode Tutup Buku</label>
                            <select name="period_month" onchange="window.location='<?php echo esc_url($action); ?>&sel_month='+this.value+'&sel_year='+document.getElementById('f_year').value">
                                <?php 
                                $mnames = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
                                foreach ($mnames as $m_num => $m_name): 
                                ?>
                                    <option value="<?php echo esc_attr($m_num); ?>" <?php selected($cur_m, $m_num); ?>>
                                        <?php echo esc_html($m_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk-field">
                            <label>Tahun Periode</label>
                            <select name="period_year" id="f_year" onchange="window.location='<?php echo esc_url($action); ?>&sel_month='+document.querySelector('select[name=period_month]').value+'&sel_year='+this.value">
                                <?php for ($y = (int)current_time('Y'); $y >= 2024; $y--): ?>
                                    <option value="<?php echo (int)$y; ?>" <?php selected($cur_y, (string)$y); ?>>Tahun <?php echo (int)$y; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="pk-field">
                            <label>Opname Kas Fisik Akhir (Rp)</label>
                            <input type="number" name="cash_balance" min="0" step="0.01" value="<?php echo esc_attr($active_closing_record['cash_balance'] ?? 0); ?>" placeholder="0" required>
                        </div>

                        <div class="pk-field">
                            <label>Rekonsiliasi Saldo Bank Akhir (Rp)</label>
                            <input type="number" name="bank_balance" min="0" step="0.01" value="<?php echo esc_attr($active_closing_record['bank_balance'] ?? 0); ?>" placeholder="0" required>
                        </div>

                        <div class="pk-field" style="grid-column: 1 / -1;">
                            <label>Catatan &amp; Memo Penutupan Buku</label>
                            <textarea name="notes" rows="2" placeholder="Catatan audit, selisih kurs, atau persetujuan direktur..."><?php echo esc_textarea($active_closing_record['notes'] ?? ''); ?></textarea>
                        </div>
                    </div>

                    <?php if (!$is_period_closed): ?>
                        <button type="submit" class="pk-btn-close-action" onclick="return confirm('PERINGATAN: Menutup periode akan mengunci periode Finance Engine dan jurnal General Ledger. Lanjutkan Tutup Buku?');">
                            🔒 Kunci &amp; Eksekusi Tutup Periode Buku
                        </button>
                    <?php else: ?>
                        <div style="padding:12px 14px;border:1px solid #fecaca;background:#fef2f2;border-radius:8px;color:#991b1b;font-size:12px;font-weight:700;">🔒 Periode sudah dikunci oleh Finance Engine. Untuk perubahan, gunakan <b>Buka Kembali</b> sesuai wewenang.</div>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- PRA-CLOSING CHECKLIST AUDIT -->
        <div class="pk-checklist-card">
            <h3 style="margin:0 0 12px 0;font-size:15px;font-weight:800;color:#0f172a;">
                📋 Checklist Verifikasi Pra-Closing
            </h3>
            <p style="font-size:12px;color:#64748b;margin:0 0 14px 0;">
                Pastikan transaksi operasional telah memenuhi standar sebelum periode resmi dikunci:
            </p>

            <div class="pk-check-item">
                <span class="pk-check-icon">✓</span>
                <div>
                    <strong>Seluruh SPK Produksi Selesai:</strong>
                    <span>Job yang selesai di bengkel sudah dicatat hasil fisik &amp; reject-nya.</span>
                </div>
            </div>

            <div class="pk-check-item">
                <span class="pk-check-icon">✓</span>
                <div>
                    <strong>Upah Karyawan Telah Dibukukan:</strong>
                    <span>Total gaji terbayar bulan ini: <b style="color:#059669;">Rp <?php echo number_format($cur_wages, 0, ',', '.'); ?></b>.</span>
                </div>
            </div>

            <div class="pk-check-item">
                <span class="pk-check-icon">✓</span>
                <div>
                    <strong>Stok Opname Fisik Telah Selesai:</strong>
                    <span>Kuantitas gudang jadi dan karantina telah disinkronkan.</span>
                </div>
            </div>

            <div class="pk-check-item">
                <span class="pk-check-icon">✓</span>
                <div>
                    <strong>Faktur &amp; Retur Barang Terverifikasi:</strong>
                    <span>Tidak ada invoice gantung yang belum diselesaikan statusnya.</span>
                </div>
            </div>
        </div>
    </div>

    <!-- 5. TABEL RIWAYAT PENUTUPAN PERIODE BUKU -->
    <div class="pk-table-panel">
        <div class="pk-panel-head">
            <h3>Arsip Riwayat Tutup Periode Resmi</h3>
        </div>
        <div class="pk-table-responsive">
            <table class="pk-table">
                <thead>
                    <tr>
                        <th>Kode Periode</th>
                        <th>Bulan &amp; Tahun</th>
                        <th>Omzet (Pendapatan)</th>
                        <th>Total Beban</th>
                        <th>Laba / Rugi Bersih</th>
                        <th>Kas / Bank Akhir</th>
                        <th>Status</th>
                        <th style="text-align:right;">Laporan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($closings_history)): foreach ($closings_history as $row): 
                        $is_closed = ($row['status'] === 'closed');
                    ?>
                        <tr>
                            <td><code><?php echo esc_html($row['period_code']); ?></code></td>
                            <td>
                                <strong><?php echo esc_html($row['period_name']); ?></strong>
                                <div style="font-size:11px;color:#64748b;">Oleh: <?php echo esc_html($row['closer_name'] ?: 'Sistem/Admin'); ?></div>
                            </td>
                            <td><strong>Rp <?php echo number_format((float)$row['total_revenue'], 0, ',', '.'); ?></strong></td>
                            <td style="color:#dc2626;">Rp <?php echo number_format((float)$row['total_expense'], 0, ',', '.'); ?></td>
                            <td>
                                <strong style="color:<?php echo (float)$row['net_profit'] >= 0 ? '#15803d' : '#dc2626'; ?>;">
                                    Rp <?php echo number_format((float)$row['net_profit'], 0, ',', '.'); ?>
                                </strong>
                            </td>
                            <td style="font-size:12px;">
                                Kas: Rp <?php echo number_format((float)$row['cash_balance'], 0, ',', '.'); ?><br>
                                Bank: Rp <?php echo number_format((float)$row['bank_balance'], 0, ',', '.'); ?>
                            </td>
                            <td>
                                <span class="<?php echo $is_closed ? 'pk-badge-closed' : 'pk-badge-open'; ?>">
                                    <?php echo $is_closed ? '🔒 DIKUNCI' : '🔓 DIBUKA'; ?>
                                </span>
                            </td>
                            <td style="text-align:right;">
                                <?php 
                                    $pdf_url = function_exists('pk01_print_url') 
                                        ? esc_url(pk01_print_url('closing', $row['id'])) 
                                        : '#';
                                ?>
                                <a href="<?php echo $pdf_url; ?>" target="_blank" style="display:inline-block;padding:5px 10px;background:#f1f5f9;border:1px solid #cbd5e1;border-radius:6px;font-size:11px;font-weight:bold;text-decoration:none;color:#0f172a;">
                                    📄 Cetak Bukti PDF
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr>
                            <td colspan="8" style="text-align:center;padding:36px;color:#64748b;">
                                Belum ada riwayat penutupan periode buku yang tersimpan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>