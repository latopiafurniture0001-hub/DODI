<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_month = current_time('Y-m');

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('finance') || PK01_Authorization::can('capital')));

// 2. DETEKSI & INISIALISASI TABEL MODAL USAHA
$get_table = function($key) use ($wpdb) {
    $tbl = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t($key) : $wpdb->prefix . 'pk01_' . $key;
    return ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl)) === $tbl) ? $tbl : false;
};

$tbl_capital = $get_table('capital') ?: ($get_table('capital_ledger') ?: $wpdb->prefix . 'pk01_capital');
$tbl_ledger  = $get_table('cash_ledger');
$tbl_logs    = $get_table('logs') ?: $get_table('activity_logs');

$table_exists = ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_capital)) === $tbl_capital);

// AUTO-CREATE TABEL MODAL JIKA BELUM TERSEDIA
if (!$table_exists) {
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `{$tbl_capital}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `capital_no` varchar(100) NOT NULL DEFAULT '',
        `source_type` varchar(50) NOT NULL DEFAULT 'owner',
        `contributor_name` varchar(255) NOT NULL DEFAULT '',
        `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
        `deposit_date` date NOT NULL,
        `target_account` varchar(100) NOT NULL DEFAULT 'Kas Tunai Toko',
        `notes` text DEFAULT NULL,
        `created_by` bigint(20) unsigned DEFAULT 0,
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `source_type` (`source_type`),
        KEY `deposit_date` (`deposit_date`)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe($sql);
    $table_exists = true;
}

// 3. LOGIKA BARU: EKSPOR ARSIP MODAL USAHA KE CSV
if (isset($_POST['pk01_export_capital_csv']) && check_admin_referer('pk01_export_capital_nonce')) {
    if ($can_manage && $table_exists) {
        $export_data = $wpdb->get_results(
            "SELECT capital_no, source_type, contributor_name, amount, deposit_date, target_account, notes, created_at 
             FROM `{$tbl_capital}` ORDER BY deposit_date DESC, id DESC LIMIT 5000",
            ARRAY_A
        );
        if (!empty($export_data)) {
            $filename = 'pk01-modal-usaha-' . current_time('Y-m-d') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['No. Bukti Modal', 'Jenis Sumber Dana', 'Nama Penyetor', 'Nominal Modal (Rp)', 'Tanggal Setor', 'Akun Penerima Kas', 'Keterangan', 'Waktu Catat']);
            foreach ($export_data as $row) {
                fputcsv($out, [
                    $row['capital_no'],
                    ucfirst($row['source_type']),
                    $row['contributor_name'],
                    $row['amount'],
                    $row['deposit_date'],
                    $row['target_account'],
                    $row['notes'],
                    $row['created_at']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. PROSES CATAT PENAMBAHAN MODAL BARU (OTOMATIS HANDSHAKE KE BUKU KAS)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_capital'])) {
    if (!$can_manage) {
        $notice = '<div class="pk01-cap-alert is-error">⚠️ Anda tidak memiliki izin otorisasi untuk membukukan modal usaha.</div>';
    } else {
        $nonce = sanitize_text_field(wp_unslash($_POST['pk01_capital_nonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'pk01_capital_save_action')) {
            $notice = '<div class="pk01-cap-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
        } else {
            $clean_num = function($val) {
                return (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)$val));
            };

            $source_type      = sanitize_key($_POST['source_type'] ?? 'owner');
            $contributor_name = sanitize_text_field(wp_unslash($_POST['contributor_name'] ?? ''));
            $amount           = $clean_num($_POST['amount'] ?? 0);
            $deposit_date     = sanitize_text_field($_POST['deposit_date'] ?? current_time('Y-m-d'));
            $target_account   = sanitize_text_field(wp_unslash($_POST['target_account'] ?? 'Kas Tunai Toko'));
            $capital_no       = strtoupper(sanitize_text_field(trim($_POST['capital_no'] ?? '')));
            $notes            = sanitize_textarea_field(wp_unslash($_POST['notes'] ?? ''));
            $user_id          = get_current_user_id();

            if (empty($contributor_name)) {
                $contributor_name = ($source_type === 'owner') ? 'Pemilik Usaha' : 'Investor';
            }

            if (empty($capital_no)) {
                $capital_no = 'CAP-' . current_time('ym') . '-' . wp_rand(100, 999);
            }

            if ($amount <= 0) {
                $notice = '<div class="pk01-cap-alert is-error">⚠️ Nominal setoran modal harus lebih besar dari Rp 0.</div>';
            } else {
                try {
                    // A-B. MODAL + KAS DIBUKUKAN MELALUI ENGINE SEBAGAI SATU TRANSAKSI
                    if (!class_exists('PK01_Engine') || !method_exists('PK01_Engine','record_capital_deposit')) throw new Exception('Mesin modal PK01 tidak tersedia.');
                    $capital_id=PK01_Engine::record_capital_deposit($amount,$source_type,$contributor_name,$deposit_date,$target_account,$capital_no,$notes);

                    // C. JABAT TANGAN: CATAT KE AUDIT LOG SISTEM
                    if ($tbl_logs && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
                        $wpdb->insert($tbl_logs, [
                            'user_id'     => $user_id,
                            'action'      => 'capital_deposit',
                            'module'      => 'capital',
                            'entity'      => $capital_no,
                            'description' => "Membukukan setoran modal {$contributor_name} sebesar Rp " . number_format($amount, 0, ',', '.') . " ke {$target_account}",
                            'created_at'  => current_time('mysql')
                        ]);
                    }

                    $notice = '<div class="pk01-cap-alert is-success">✅ Setoran modal <strong>' . esc_html($contributor_name) . '</strong> sebesar <b>Rp ' . number_format($amount, 0, ',', '.') . '</b> berhasil dibukukan! Dana otomatis menambah saldo di Buku Kas (' . esc_html($target_account) . ').</div>';
                    $_POST = [];
                } catch (Throwable $e) {
                    $notice = '<div class="pk01-cap-alert is-error">❌ Gagal membukukan modal: ' . esc_html($e->getMessage()) . '</div>';
                }
            }
        }
    }
}

// 5. STATISTIK MODAL REAL DARI DATABASE (NON-DUMMY)
$total_capital_all      = 0;
$total_capital_owner    = 0;
$total_capital_external = 0;
$total_capital_month    = 0;

if ($table_exists) {
    $total_capital_all = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_capital}`");
    $total_capital_owner = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_capital}` WHERE source_type = 'owner'");
    $total_capital_external = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_capital}` WHERE source_type IN ('investor', 'loan')");
    $total_capital_month = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_capital}` WHERE DATE_FORMAT(deposit_date, '%%Y-%%m') = %s",
        $current_month
    ));
}

// Fallback: jika tabel baru dan kosong, cek dari cash_ledger mutasi modal
if ($total_capital_all <= 0 && $tbl_ledger) {
    $total_capital_all = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_ledger}` WHERE direction = 'in' AND category LIKE '%modal%'");
    $total_capital_owner = $total_capital_all;
}

// Informasi Akun Bank dari Pengaturan
$central_settings = (array) get_option('pk01_settings', []);
$bank_account_default = !empty($central_settings['bank_name']) 
    ? $central_settings['bank_name'] . ' (' . ($central_settings['bank_account_number'] ?? '') . ')' 
    : 'Rekening Bank Resmi Perusahaan';

$format_money = function($val) {
    return class_exists('PK01_Settings') && method_exists('PK01_Settings', 'money')
        ? PK01_Settings::money($val) 
        : 'Rp ' . number_format((float)$val, 0, ',', '.');
};

$suggested_code = 'CAP-' . current_time('ym') . '-' . wp_rand(100, 999);
?>

<style>
:root {
    --pk-cap-navy: #0f172a;
    --pk-cap-border: #e2e8f0;
    --pk-cap-green: #059669;
    --pk-cap-blue: #2563eb;
    --pk-cap-purple: #7c3aed;
    --pk-cap-amber: #d97706;
}

.pk01-capital-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 30px;
}
.pk01-capital-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-cap-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #064e3b 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-cap-eyebrow {
    display: inline-block;
    background: rgba(52, 211, 153, 0.15);
    color: #34d399;
    border: 1px solid rgba(52, 211, 153, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-cap-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-cap-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive Scorecards */
.pk01-cap-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-cap-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-green::before  { background: var(--pk-cap-green); }
.pk01-kpi-card.c-blue::before   { background: var(--pk-cap-blue); }
.pk01-kpi-card.c-purple::before { background: var(--pk-cap-purple); }
.pk01-kpi-card.c-amber::before  { background: var(--pk-cap-amber); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: #64748b;
}

/* Split Form & Guidelines */
.pk01-cap-split {
    display: grid;
    grid-template-columns: 1.4fr 0.9fr;
    gap: 20px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 960px) {
    .pk01-cap-split { grid-template-columns: 1fr; }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-cap-border);
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: #059669;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.15);
}

/* Quick Increment Pills */
.pk01-amount-pills {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 4px;
}
.pk01-pill-amt {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 10px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill-amt:hover {
    background: #0f172a;
    color: #ffffff;
    border-color: #0f172a;
}

/* Buttons & Alerts */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }

.pk01-cap-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-cap-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-cap-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-capital-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-cap-hero">
        <div>
            <span class="pk01-cap-eyebrow">EQUITY &bull; CAPITAL STRUCTURE</span>
            <h1>Modal Usaha &amp; Ekuitas Bisnis</h1>
            <p>
                Pusat pengelolaan struktur modal awal, penambahan ekuitas pemilik, dan investasi modal kerja. 
                Penyetoran modal dicatat sebagai <strong>Ekuitas</strong> di neraca dan otomatis menambah saldo kas likuid di <strong>Buku Kas</strong>.
            </p>
        </div>
        <div>
            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_capital_nonce'); ?>
                <input type="hidden" name="pk01_export_capital_csv" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Mutasi Modal (.CSV)
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-cap-kpis">
        <div class="pk01-kpi-card c-green">
            <small>Total Modal Disetor (Semua Sumber)</small>
            <strong style="color:#059669;"><?php echo $format_money($total_capital_all); ?></strong>
            <span>Akumulasi dana investasi terbukukan</span>
        </div>

        <div class="pk01-kpi-card c-blue">
            <small>Modal Pemilik Pribadi (Owner Equity)</small>
            <strong style="color:#1d4ed8;"><?php echo $format_money($total_capital_owner); ?></strong>
            <span>Penyertaan dana mandiri pendiri</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Modal Investor &amp; Pinjaman Luar</small>
            <strong style="color:#7c3aed;"><?php echo $format_money($total_capital_external); ?></strong>
            <span>Dana eksternal / rekanan pemodal</span>
        </div>

        <div class="pk01-kpi-card c-amber">
            <small>Penambahan Modal Bulan Ini</small>
            <strong style="color:#d97706;"><?php echo $format_money($total_capital_month); ?></strong>
            <span>Inflow modal periode: <?php echo esc_html($current_month); ?></span>
        </div>
    </div>

    <!-- 3. SPLIT FORM & KAIDAH PERMODALAN -->
    <?php if ($can_manage): ?>
    <div class="pk01-cap-split">
        
        <div class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>➕ Bukukan Setoran / Penambahan Modal Usaha</h3>
            </div>

            <form method="post" action="">
                <?php echo wp_nonce_field('pk01_capital_save_action', 'pk01_capital_nonce', true, false); ?>
                <input type="hidden" name="pk01_save_capital" value="1">

                <div class="pk01-form-grid">
                    <div class="pk01-field-item">
                        <label>Jenis Sumber Permodalan <span style="color:#dc2626;">*</span></label>
                        <select name="source_type" class="pk01-input" style="font-weight:700;" required>
                            <option value="owner">Pemilik Usaha (Owner Equity)</option>
                            <option value="investor">Penyertaan Pemodal / Investor</option>
                            <option value="loan">Pinjaman Lunak / Modal Kerja</option>
                            <option value="retained_earnings">Alokasi Laba Ditahan</option>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Nama Penyetor / Pihak Pemodal <span style="color:#dc2626;">*</span></label>
                        <input type="text" name="contributor_name" class="pk01-input" placeholder="Nama Pemilik / Investor" required>
                    </div>

                    <div class="pk01-field-item" style="grid-column: span 2;">
                        <label>Nominal Setoran Modal (Rp) <span style="color:#dc2626;">*</span></label>
                        <input type="number" step="any" min="1000" id="pk01-cap-amount" name="amount" class="pk01-input" placeholder="Contoh: 25000000" required>
                        <div class="pk01-amount-pills">
                            <span class="pk01-pill-amt" data-amt="1000000">+1 jt</span>
                            <span class="pk01-pill-amt" data-amt="5000000">+5 jt</span>
                            <span class="pk01-pill-amt" data-amt="10000000">+10 jt</span>
                            <span class="pk01-pill-amt" data-amt="25000000">+250 jt</span>
                            <span class="pk01-pill-amt" data-amt="50000000">+50 jt</span>
                            <span class="pk01-pill-amt" data-amt="100000000">+100 jt</span>
                        </div>
                    </div>

                    <div class="pk01-field-item">
                        <label>Tanggal Masuk Dana <span style="color:#dc2626;">*</span></label>
                        <input type="date" name="deposit_date" class="pk01-input" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" required>
                    </div>

                    <div class="pk01-field-item">
                        <label>Akun Kas / Bank Penerima <span style="color:#dc2626;">*</span></label>
                        <select name="target_account" class="pk01-input">
                            <option value="<?php echo esc_attr($bank_account_default); ?>"><?php echo esc_html($bank_account_default); ?></option>
                            <option value="Kas Tunai Toko">Kas Tunai Toko / Workshop</option>
                            <option value="Kas Kecil / Petikem">Kas Kecil (Petty Cash)</option>
                        </select>
                    </div>

                    <div class="pk01-field-item" style="grid-column: span 2;">
                        <label>No. Bukti / Referensi Setoran</label>
                        <input type="text" name="capital_no" class="pk01-input" value="<?php echo esc_attr($suggested_code); ?>" placeholder="Contoh: CAP-2609-001">
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>Keterangan / Alokasi Penggunaan Modal</label>
                        <textarea name="notes" rows="2" class="pk01-input" placeholder="Contoh: Suntikan modal awal pembelian mesin router dan bahan baku kayu..."></textarea>
                    </div>
                </div>

                <div style="margin-top:16px;">
                    <button type="submit" class="pk01-btn pk01-btn-primary">
                        💾 Bukukan Setoran Modal Usaha
                    </button>
                </div>
            </form>
        </div>

        <!-- Box Kaidah Akuntansi Modal -->
        <div class="pk01-surface" style="background:#f8fafc;">
            <div class="pk01-surface-head">
                <h3>💡 Kaidah Akuntansi Modal Usaha</h3>
            </div>
            <p style="font-size:13px; color:#475569; line-height:1.6; margin:0 0 14px 0;">
                Dalam akuntansi profesional, <strong>Modal Usaha BUKAN pendapatan omzet penjualan</strong> dan tidak dikenakan pajak laba operasional:
            </p>
            <div style="background:#ffffff; border:1px solid #cbd5e1; border-radius:8px; padding:14px; font-size:13px; margin-bottom:12px;">
                <ul style="margin:0; padding-left:18px; line-height:1.6; color:#1e293b;">
                    <li><b>Suntikan Modal:</b> Menambah kas dan dicatat sebagai Ekuitas di neraca.</li>
                    <li><b>Tidak Membiaskan Margin:</b> Laba bersih penjualan murni dihitung dari Omzet dikurangi HPP &amp; Biaya operasional.</li>
                    <li><b>Audit Dividen:</b> Mempermudah pembagian hasil laba investor secara proporsional.</li>
                </ul>
            </div>
            <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0;">
                ℹ️ Setiap modal yang dibukukan di sini langsung otomatis menambah saldo riil di modul <strong>Buku Kas</strong>.
            </p>
        </div>

    </div>
    <?php endif; ?>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var amtInput = document.getElementById('pk01-cap-amount');
    var amtPills = document.querySelectorAll('.pk01-pill-amt');

    if (amtInput && amtPills.length > 0) {
        amtPills.forEach(function(pill) {
            pill.addEventListener('click', function() {
                var cur = parseFloat(amtInput.value) || 0;
                var add = parseFloat(this.dataset.amt) || 0;
                amtInput.value = cur + add;
                amtInput.focus();
            });
        });
    }
});
</script>

<?php
// 6. TAMPILKAN TABEL MODUL BAWAAN MENGGUNAKAN MULTI-PATH RESOLVER AMAN (LOGIKA LAMA 100% TERJAGA)
$loaded = false;
$candidates = [];

if (defined('PK01_DIR')) {
    $candidates[] = trailingslashit(PK01_DIR) . 'includes/core/view/tampilan-data-modul.php';
}


foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        require_once $cand;
        $loaded = true;
        break;
    }
}

if (function_exists('pk01_tampilkan_data_modul')) {
    pk01_tampilkan_data_modul('capital', 'Modal Usaha', 'KEUANGAN', 'Catatan modal usaha dan sumber dana masuk.');
} elseif (!$loaded) {
    echo '<div style="background:#ffffff;border:1px dashed #cbd5e1;border-radius:12px;padding:26px;text-align:center;color:#64748b;font-size:13px;">
            📁 Modul antarmuka tabel <code>tampilan-data-modul.php</code> belum ditemukan di folder <code>includes/</code>.
          </div>';
}