<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$notice = '';
$current_month = current_time('Y-m');

// 1. OTORISASI: ADMINISTRATOR MUTLAK DIIZINKAN (SUPERADMIN BYPASS)
$current_user = wp_get_current_user();
$is_admin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$can_manage = $is_admin || (class_exists('PK01_Authorization') && (PK01_Authorization::can('cash') || PK01_Authorization::can('finance')));

// 2. DETEKSI & INISIALISASI TABEL BUKU KAS
$tbl_ledger = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('cash_ledger') 
    : $wpdb->prefix . 'pk01_cash_ledger';

$tbl_costs = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('operational_costs') 
    : $wpdb->prefix . 'pk01_operational_costs';

$tbl_logs = class_exists('PK01_DB') && method_exists('PK01_DB', 't') 
    ? PK01_DB::t('activity_logs') 
    : $wpdb->prefix . 'pk01_activity_logs';

// AUTO-CREATE TABEL KAS JIKA BELUM TERSEDIA
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_ledger)) !== $tbl_ledger) {
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `{$tbl_ledger}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `direction` varchar(10) NOT NULL DEFAULT 'in',
        `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
        `account` varchar(100) NOT NULL DEFAULT 'Kas Tunai Toko',
        `category` varchar(100) NOT NULL DEFAULT 'Operasional',
        `reference_type` varchar(50) DEFAULT 'manual',
        `reference_id` bigint(20) unsigned DEFAULT 0,
        `reference_no` varchar(100) DEFAULT '',
        `description` text DEFAULT NULL,
        `created_by` bigint(20) unsigned DEFAULT 0,
        `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `direction` (`direction`),
        KEY `category` (`category`),
        KEY `created_at` (`created_at`)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    PK01_DB::dbDelta_safe($sql);
}

// 3. LOGIKA BARU: EKSPOR SERVER-SIDE CSV KOMPREHENSIF (HINGGA 5.000 MUTASI)
if (isset($_POST['pk01_export_cash_csv_server']) && check_admin_referer('pk01_export_cash_nonce')) {
    if ($can_manage && $tbl_ledger) {
        $export_records = $wpdb->get_results(
            "SELECT id, created_at, direction, account, category, amount, reference_no, description 
             FROM `{$tbl_ledger}` ORDER BY id DESC LIMIT 5000",
            ARRAY_A
        );
        if (!empty($export_records)) {
            $filename = 'pk01-buku-kas-' . current_time('Y-m-d-His') . '.csv';
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID Mutasi', 'Waktu Transaksi', 'Arah (IN/OUT)', 'Akun / Dompet', 'Kategori', 'Nominal (Rp)', 'No. Referensi', 'Keterangan']);
            foreach ($export_records as $r) {
                fputcsv($out, [
                    $r['id'],
                    $r['created_at'],
                    strtoupper($r['direction']),
                    $r['account'],
                    $r['category'],
                    $r['amount'],
                    $r['reference_no'],
                    $r['description']
                ]);
            }
            fclose($out);
            exit;
        }
    }
}

// 4. PROSES CATAT MUTASI KAS MASUK / KELUAR (LOGIKA LAMA UTUH)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_save_cash_mutation'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_cash_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_cash_save_action')) {
        $notice = '<div class="pk01-cash-alert is-error">⚠️ Sesi keamanan kedaluwarsa. Silakan muat ulang halaman.</div>';
    } else {
        $clean_num = function($val) {
            return (float) preg_replace('/[^0-9.]/', '', str_replace(',', '.', (string)$val));
        };

        $direction    = sanitize_key($_POST['cash_direction'] ?? 'in');
        $amount       = $clean_num($_POST['cash_amount'] ?? 0);
        $account      = sanitize_text_field(wp_unslash($_POST['cash_account'] ?? 'Kas Tunai Toko'));
        $category     = sanitize_text_field(wp_unslash($_POST['cash_category'] ?? 'Operasional'));
        $reference_no = sanitize_text_field(wp_unslash($_POST['cash_reference_no'] ?? ''));
        $description  = sanitize_textarea_field(wp_unslash($_POST['cash_description'] ?? ''));
        $user_id      = get_current_user_id();

        if ($amount <= 0) {
            $notice = '<div class="pk01-cash-alert is-error">⚠️ Nominal mutasi kas harus lebih besar dari Rp 0.</div>';
        } elseif (empty($description)) {
            $notice = '<div class="pk01-cash-alert is-error">⚠️ Keterangan keperluan mutasi kas wajib diisi.</div>';
        } else {
            try {
                if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'record_cash_mutation')) {
                    PK01_Engine::record_cash_mutation($direction,$amount,$account,$category,$reference_no,$description);
                } elseif (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'cash')) {
                    PK01_Engine::cash($direction,$amount,$category,'manual',0,$description,$account,$reference_no);
                } else {
                    throw new Exception('Mesin kas PK01 tidak tersedia.');
                }

                // AUDIT LOG JABAT TANGAN
                if ($tbl_logs && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_logs)) === $tbl_logs) {
                    $wpdb->insert($tbl_logs, [
                        'user_id'     => $user_id,
                        'action'      => 'cash_' . $direction,
                        'module'      => 'cash',
                        'entity'      => strtoupper($direction) . ' - ' . $category,
                        'description' => ($direction === 'in' ? 'Kas Masuk' : 'Kas Keluar') . " sebesar Rp " . number_format($amount, 0, ',', '.') . " ({$account}): {$description}",
                        'created_at'  => current_time('mysql')
                    ]);
                }

                $dir_label = ($direction === 'in') ? 'Kas Masuk (+)' : 'Kas Keluar (-)';
                $notice = '<div class="pk01-cash-alert is-success">✅ Transaksi <b>' . $dir_label . '</b> sebesar <b>Rp ' . number_format($amount, 0, ',', '.') . '</b> berhasil dibukukan ke ' . esc_html($account) . '.</div>';
                $_POST = [];
            } catch (Throwable $e) {
                $notice = '<div class="pk01-cash-alert is-error">❌ Gagal menyimpan mutasi: ' . esc_html($e->getMessage()) . '</div>';
            }
        }
    }
}

// 5. STATISTIK KAS REAL DARI DATABASE (NON-DUMMY)
$saldo_aktual = 0;
if (class_exists('PK01_Engine') && method_exists('PK01_Engine', 'cash_balance')) {
    $saldo_aktual = (float) PK01_Engine::cash_balance();
} else {
    $saldo_db = $wpdb->get_var("SELECT SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END) FROM `{$tbl_ledger}`");
    $saldo_aktual = (float) $saldo_db;
}

// Kas Masuk Bulan Ini
$kas_masuk_month = (float) $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_ledger}` WHERE direction = 'in' AND reference_type <> 'cashier_deposit_transfer' AND DATE_FORMAT(created_at, '%%Y-%%m') = %s",
    $current_month
));

// Kas Keluar Bulan Ini
$kas_keluar_month = (float) $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(amount), 0) FROM `{$tbl_ledger}` WHERE direction = 'out' AND reference_type <> 'cashier_deposit_transfer' AND DATE_FORMAT(created_at, '%%Y-%%m') = %s",
    $current_month
));

$net_cashflow = $kas_masuk_month - $kas_keluar_month;

// Ambil Saldo Riil per Akun / Dompet (Real Database Breakdown)
$account_balances = $wpdb->get_results(
    "SELECT account, SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END) AS balance 
     FROM `{$tbl_ledger}` GROUP BY account ORDER BY balance DESC",
    ARRAY_A
) ?: [];

// 100 Mutasi Terakhir
$rows = $wpdb->get_results("SELECT * FROM `{$tbl_ledger}` ORDER BY id DESC LIMIT 100", ARRAY_A) ?: [];

// Informasi Rekening dari Pengaturan Sentral
$central_settings = (array) get_option('pk01_settings', []);
$bank_label = !empty($central_settings['bank_name']) 
    ? $central_settings['bank_name'] . ' (' . ($central_settings['bank_account_number'] ?? '') . ')' 
    : 'Rekening Bank Resmi';

$format_money = function($val) {
    return class_exists('PK01_Settings') && method_exists('PK01_Settings', 'money')
        ? PK01_Settings::money($val) 
        : 'Rp ' . number_format((float)$val, 0, ',', '.');
};
?>

<style>
:root {
    --pk-cash-navy: #0f172a;
    --pk-cash-border: #e2e8f0;
    --pk-cash-blue: #2563eb;
    --pk-cash-green: #059669;
    --pk-cash-red: #dc2626;
    --pk-cash-purple: #7c3aed;
    --pk-cash-muted: #64748b;
}

.pk01-cash-cockpit {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #1e293b;
    max-width: 1440px;
    margin: 10px auto 40px;
}
.pk01-cash-cockpit * { box-sizing: border-box; }

/* Hero Banner */
.pk01-cash-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 65%, #064e3b 100%);
    color: #ffffff;
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk01-cash-eyebrow {
    display: inline-block;
    background: rgba(52, 211, 153, 0.15);
    color: #34d399;
    border: 1px solid rgba(52, 211, 153, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk01-cash-hero h1 {
    margin: 0 0 6px 0;
    font-size: 24px;
    font-weight: 800;
    color: #f8fafc;
}
.pk01-cash-hero p {
    margin: 0;
    font-size: 13px;
    color: #cbd5e1;
    max-width: 820px;
    line-height: 1.5;
}

/* 4 Executive KPI Cards */
.pk01-cash-kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}
.pk01-kpi-card {
    background: #ffffff;
    border: 1px solid var(--pk-cash-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    position: relative;
    overflow: hidden;
}
.pk01-kpi-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
}
.pk01-kpi-card.c-blue::before   { background: var(--pk-cash-blue); }
.pk01-kpi-card.c-green::before  { background: var(--pk-cash-green); }
.pk01-kpi-card.c-red::before    { background: var(--pk-cash-red); }
.pk01-kpi-card.c-purple::before { background: var(--pk-cash-purple); }

.pk01-kpi-card small {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    display: block;
}
.pk01-kpi-card strong {
    font-size: 22px;
    font-weight: 800;
    display: block;
    margin: 6px 0 2px 0;
}
.pk01-kpi-card span {
    font-size: 11px;
    color: #64748b;
}

/* Saldo per Rekening / Dompet Strip */
.pk01-wallets-strip {
    background: #ffffff;
    border: 1px solid var(--pk-cash-border);
    border-radius: 14px;
    padding: 16px 20px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-wallets-head {
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: #64748b;
    margin-bottom: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk01-wallets-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
}
.pk01-wallet-pill {
    background: #f8fafc;
    border: 1px solid var(--pk-cash-border);
    border-radius: 10px;
    padding: 12px 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk01-wallet-pill span {
    font-size: 12px;
    font-weight: 600;
    color: #334155;
}
.pk01-wallet-pill strong {
    font-size: 14px;
    font-family: monospace;
}

/* Split Form & Guidelines */
.pk01-cash-split {
    display: grid;
    grid-template-columns: 1.4fr 0.9fr;
    gap: 20px;
    align-items: start;
    margin-bottom: 24px;
}
@media (max-width: 960px) {
    .pk01-cash-split { grid-template-columns: 1fr; }
}

.pk01-surface {
    background: #ffffff;
    border: 1px solid var(--pk-cash-border);
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk01-surface-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f1f5f9;
}
.pk01-surface-head h3 {
    margin: 0;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

/* Grid Form */
.pk01-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
}
@media (max-width: 600px) {
    .pk01-form-grid { grid-template-columns: 1fr; }
}

.pk01-field-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.pk01-field-item label {
    font-size: 12px;
    font-weight: 700;
    color: #334155;
}
.pk01-input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 13px;
    color: #0f172a;
    background: #f8fafc;
}
.pk01-input:focus {
    outline: none;
    border-color: #2563eb;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

/* Quick Amount Increment Pills */
.pk01-amount-pills {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 4px;
}
.pk01-pill-amt {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 10px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk01-pill-amt:hover {
    background: #0f172a;
    color: #ffffff;
    border-color: #0f172a;
}

/* Table Style */
.pk01-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pk-cash-border);
    border-radius: 12px;
}
.pk01-cash-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
}
.pk01-cash-table th {
    background: #f8fafc;
    padding: 11px 12px;
    font-weight: 700;
    color: #475569;
    border-bottom: 2px solid var(--pk-cash-border);
}
.pk01-cash-table td {
    padding: 11px 12px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}
.pk01-cash-table tr:hover td { background: #fbfcfe; }

/* Filter Chips Bar */
.pk01-filter-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 14px;
}
.pk01-filter-chips {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.pk01-chip-btn {
    padding: 6px 12px;
    border-radius: 20px;
    border: 1px solid #cbd5e1;
    background: #ffffff;
    font-size: 12px;
    font-weight: 600;
    color: #475569;
    cursor: pointer;
}
.pk01-chip-btn.active {
    background: #0f172a;
    color: #ffffff;
    border-color: #0f172a;
}

/* Badges & Buttons */
.pk01-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 9px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk01-btn-primary { background: #0f172a; color: #ffffff !important; }
.pk01-btn-primary:hover { background: #1e293b; }
.pk01-btn-export  { background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; }
.pk01-btn-export:hover  { background: #f8fafc; }

.pk01-dir-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}
.dir-in  { background: #dcfce7; color: #166534; }
.dir-out { background: #fee2e2; color: #991b1b; }

.pk01-cash-alert {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 20px;
}
.pk01-cash-alert.is-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
.pk01-cash-alert.is-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
</style>

<div class="pk01-cash-cockpit">
    
    <!-- 1. HERO COCKPIT HEADER -->
    <header class="pk01-cash-hero">
        <div>
            <span class="pk01-cash-eyebrow">TREASURY &bull; LIQUIDITY CONTROL</span>
            <h1>Buku Kas &amp; Mutasi Saldo Usaha</h1>
            <p>
                Pusat pencatatan seluruh pergerakan kas riil bisnis: uang tunai kasir, saldo petty cash, dan mutasi perbankan. 
                Pengeluaran kas operasional otomatis disinkronkan ke laporan laba rugi.
            </p>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
            <?php if (function_exists('pk01_print_url')): ?>
                <a class="pk01-btn pk01-btn-export" target="_blank" href="<?php echo esc_url(pk01_print_url('kas')); ?>">
                    🖨️ Cetak Buku Kas PDF
                </a>
            <?php endif; ?>

            <form method="post" style="margin:0;">
                <?php wp_nonce_field('pk01_export_cash_nonce'); ?>
                <input type="hidden" name="pk01_export_cash_csv_server" value="1">
                <button type="submit" class="pk01-btn pk01-btn-export">
                    📥 Ekspor Full CSV
                </button>
            </form>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 2. 4 EXECUTIVE KPI CARDS REAL DATABASE -->
    <div class="pk01-cash-kpis">
        <div class="pk01-kpi-card c-blue">
            <small>Saldo Kas &amp; Bank Aktual</small>
            <strong style="color:#1d4ed8;"><?php echo $format_money($saldo_aktual); ?></strong>
            <span>Akumulasi saldo kas riil seluruh akun</span>
        </div>

        <div class="pk01-kpi-card c-green">
            <small>Kas Masuk (Bulan Ini)</small>
            <strong style="color:#059669;">+ <?php echo $format_money($kas_masuk_month); ?></strong>
            <span>Penjualan tunai, pelunasan piutang &amp; setoran</span>
        </div>

        <div class="pk01-kpi-card c-red">
            <small>Kas Keluar (Bulan Ini)</small>
            <strong style="color:#dc2626;">- <?php echo $format_money($kas_keluar_month); ?></strong>
            <span>Beban operasional, belanja bahan &amp; payroll</span>
        </div>

        <div class="pk01-kpi-card c-purple">
            <small>Arus Kas Bersih (Net Cashflow)</small>
            <strong style="color:<?php echo $net_cashflow >= 0 ? '#059669' : '#dc2626'; ?>;">
                <?php echo ($net_cashflow >= 0 ? '+ ' : '') . $format_money($net_cashflow); ?>
            </strong>
            <span>Selisih dana masuk terhadap dana keluar</span>
        </div>
    </div>

    <!-- 3. REAL BREAKDOWN: SALDO PER REKENING / DOMPET (MASTERPIECE FEATURE) -->
    <?php if (!empty($account_balances)): ?>
    <section class="pk01-wallets-strip">
        <div class="pk01-wallets-head">
            <span>💼 Rincian Saldo Nyata per Akun / Dompet Dana:</span>
            <span>Total Akun: <?php echo count($account_balances); ?></span>
        </div>
        <div class="pk01-wallets-grid">
            <?php foreach ($account_balances as $ab): 
                $bal = (float)$ab['balance'];
            ?>
                <div class="pk01-wallet-pill">
                    <span><?php echo esc_html($ab['account'] ?: 'Kas Tunai'); ?></span>
                    <strong style="color:<?php echo $bal >= 0 ? '#047857' : '#b91c1c'; ?>;">
                        <?php echo $format_money($bal); ?>
                    </strong>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- 4. FORM PENCATATAN MUTASI KAS BARU -->
    <?php if ($can_manage): ?>
    <div class="pk01-cash-split">
        
        <div class="pk01-surface">
            <div class="pk01-surface-head">
                <h3>💵 Catat Transaksi Mutasi Kas Baru</h3>
            </div>

            <form method="post" action="">
                <?php echo wp_nonce_field('pk01_cash_save_action', 'pk01_cash_nonce', true, false); ?>
                <input type="hidden" name="pk01_save_cash_mutation" value="1">

                <div class="pk01-form-grid">
                    <div class="pk01-field-item">
                        <label>Arah Aliran Dana <span style="color:#dc2626;">*</span></label>
                        <select name="cash_direction" id="pk01-cash-dir" class="pk01-input" style="font-weight:700;" required>
                            <option value="in">🟢 Kas Masuk (+) [Pemasukan / Setoran]</option>
                            <option value="out">🔴 Kas Keluar (-) [Pengeluaran / Biaya]</option>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Nominal Mutasi (Rp) <span style="color:#dc2626;">*</span></label>
                        <input type="number" step="any" min="100" id="pk01-cash-amount" name="cash_amount" class="pk01-input" placeholder="Contoh: 500000" required>
                        <div class="pk01-amount-pills">
                            <span class="pk01-pill-amt" data-amt="50000">+50 rb</span>
                            <span class="pk01-pill-amt" data-amt="100000">+100 rb</span>
                            <span class="pk01-pill-amt" data-amt="250000">+250 rb</span>
                            <span class="pk01-pill-amt" data-amt="500000">+500 rb</span>
                            <span class="pk01-pill-amt" data-amt="1000000">+1 jt</span>
                            <span class="pk01-pill-amt" data-amt="5000000">+5 jt</span>
                        </div>
                    </div>

                    <div class="pk01-field-item">
                        <label>Akun Sumber / Tujuan Dana <span style="color:#dc2626;">*</span></label>
                        <select name="cash_account" class="pk01-input">
                            <option value="Kas Tunai Toko">Kas Tunai Toko / Workshop</option>
                            <option value="<?php echo esc_attr($bank_label); ?>"><?php echo esc_html($bank_label); ?></option>
                            <option value="Kas Kecil / Petikem">Kas Kecil (Petty Cash)</option>
                            <option value="E-Wallet / QRIS Usaha">E-Wallet / QRIS Usaha</option>
                        </select>
                    </div>

                    <div class="pk01-field-item">
                        <label>Kategori Transaksi <span style="color:#dc2626;">*</span></label>
                        <input type="text" name="cash_category" id="pk01-cash-cat" class="pk01-input" list="pk01-cat-list" placeholder="Ketik atau pilih kategori..." required>
                        <datalist id="pk01-cat-list">
                            <option value="Penjualan Offline">
                            <option value="Operasional Toko">
                            <option value="Listrik, Air &amp; Internet">
                            <option value="Logistik &amp; Pengiriman">
                            <option value="Gaji &amp; Upah">
                            <option value="Pembelian Bahan Baku">
                            <option value="Sewa Tempat">
                            <option value="Penyetoran Modal">
                            <option value="Peralatan &amp; Maintenance">
                        </datalist>
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>No. Referensi / Bukti Transfer / Nota (Opsional)</label>
                        <input type="text" name="cash_reference_no" class="pk01-input" placeholder="Contoh: NOTA-0926 / BUKTI-TF-01">
                    </div>

                    <div class="pk01-field-item" style="grid-column: 1 / -1;">
                        <label>Rincian Keterangan Transaksi <span style="color:#dc2626;">*</span></label>
                        <textarea name="cash_description" rows="2" class="pk01-input" placeholder="Tuliskan keterangan detail transaksi kas ini..." required></textarea>
                    </div>
                </div>

                <div style="margin-top:16px;">
                    <button type="submit" class="pk01-btn pk01-btn-primary">
                        💾 Simpan Mutasi Kas
                    </button>
                </div>
            </form>
        </div>

        <!-- Box Panduan Perbendaharaan -->
        <div class="pk01-surface" style="background:#f8fafc;">
            <div class="pk01-surface-head">
                <h3>💡 Kaidah Buku Kas Terpadu</h3>
            </div>
            <p style="font-size:13px; color:#475569; line-height:1.6; margin:0 0 14px 0;">
                Buku Kas adalah <strong>Pusat Likuiditas Tunggal</strong> yang menjaga akurasi uang tunai fisik dan saldo rekening bank bisnis:
            </p>
            <div style="background:#ffffff; border:1px solid #cbd5e1; border-radius:8px; padding:14px; font-size:13px; margin-bottom:12px;">
                <ul style="margin:0; padding-left:18px; line-height:1.6; color:#1e293b;">
                    <li><b>Penjualan:</b> Kasir atau pembayaran pesanan menambah kas riil.</li>
                    <li><b>Biaya Operasional:</b> Kas keluar otomatis mengurangi laba bersih.</li>
                    <li><b>Gaji &amp; Pengiriman:</b> Terhubung langsung ke pencairan payroll dan ongkir kurir.</li>
                </ul>
            </div>
            <p style="font-size:12px; color:#64748b; line-height:1.5; margin:0;">
                ℹ️ Saldo kas yang akurat adalah pondasi utama agar rekomendasi <strong>AI Control Tower</strong> memberikan sinyal risiko likuiditas yang presisi.
            </p>
        </div>

    </div>
    <?php endif; ?>

    <!-- 5. FILTER STATUS CHIPS & SEARCH TOOLBAR -->
    <div class="pk01-filter-bar">
        <div class="pk01-filter-chips">
            <button type="button" class="pk01-chip-btn active" data-dir="all">Semua Mutasi (<?php echo count($rows); ?>)</button>
            <button type="button" class="pk01-chip-btn" data-dir="in" style="border-color:#10b981;color:#166534;">🟢 Kas Masuk Saja (+)</button>
            <button type="button" class="pk01-chip-btn" data-dir="out" style="border-color:#ef4444;color:#991b1b;">🔴 Kas Keluar Saja (-)</button>
        </div>
        
        <div style="display:flex; gap:8px;">
            <input type="search" id="pk01-search-cash" class="pk01-input" placeholder="🔍 Cari kategori, akun, ket..." style="width:240px;">
            <button type="button" id="pk01-export-cash-csv" class="pk01-btn pk01-btn-export" style="padding:7px 12px;font-size:12px;">
                📋 CSV Tabel
            </button>
        </div>
    </div>

    <!-- 6. TABEL DATA 100 MUTASI TERAKHIR -->
    <div class="pk01-table-wrap">
        <table id="pk01-table-cash" class="pk01-cash-table">
            <thead>
                <tr>
                    <th style="width:130px;">Waktu Transaksi</th>
                    <th style="text-align:center;width:90px;">Aliran</th>
                    <th>Akun / Dompet</th>
                    <th>Kategori</th>
                    <th>Keterangan &amp; Bukti</th>
                    <th style="text-align:right;width:160px;">Nominal Mutasi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($rows)): ?>
                    <?php foreach ($rows as $r): 
                        $is_in = ($r['direction'] === 'in');
                        $badge_class = $is_in ? 'dir-in' : 'dir-out';
                        $nominal_color = $is_in ? '#047857' : '#dc2626';
                        $nominal_prefix = $is_in ? '+ ' : '- ';
                    ?>
                    <tr data-direction="<?php echo esc_attr($r['direction']); ?>">
                        <td style="color:#64748b; font-size:12px; font-family:monospace;">
                            <?php echo esc_html(date('d/m/Y H:i', strtotime($r['created_at']))); ?>
                        </td>
                        <td style="text-align:center;">
                            <span class="pk01-dir-badge <?php echo esc_attr($badge_class); ?>">
                                <?php echo $is_in ? 'MASUK' : 'KELUAR'; ?>
                            </span>
                        </td>
                        <td>
                            <strong style="color:#0f172a;"><?php echo esc_html($r['account'] ?: 'Kas Tunai'); ?></strong>
                        </td>
                        <td>
                            <span style="background:#f1f5f9; padding:3px 8px; border-radius:4px; font-weight:600; font-size:11px; border:1px solid #e2e8f0;">
                                <?php echo esc_html($r['category']); ?>
                            </span>
                        </td>
                        <td>
                            <div style="font-weight:600; color:#1e293b;"><?php echo esc_html($r['description'] ?: '-'); ?></div>
                            <?php if (!empty($r['reference_no'])): ?>
                                <small style="color:#64748b; font-family:monospace;">Ref: <?php echo esc_html($r['reference_no']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:right; font-weight:800; font-size:14px; font-family:monospace; color:<?php echo esc_attr($nominal_color); ?>;">
                            <?php echo $nominal_prefix . $format_money($r['amount']); ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:36px; color:#94a3b8;">
                            Belum ada transaksi mutasi kas yang tercatat di sistem.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. QUICK AMOUNT INCREMENT PILLS
    var amtInput = document.getElementById('pk01-cash-amount');
    var amtPills = document.querySelectorAll('.pk01-pill-amt');

    if (amtInput && amtPills.length > 0) {
        amtPills.forEach(function(pill) {
            pill.addEventListener('click', function() {
                var cur = parseFloat(amtInput.value) || 0;
                var add = parseFloat(this.dataset.amt) || 0;
                amtInput.value = cur + add;
                amtInput.focus();
            });
        });
    }

    // 2. LIVE SEARCH & DIRECTION FILTER CHIPS
    var searchInput = document.getElementById('pk01-search-cash');
    var table       = document.getElementById('pk01-table-cash');
    var chipBtns    = document.querySelectorAll('.pk01-chip-btn');
    var activeDir   = 'all';

    function applyCashFilters() {
        if (!table) return;
        var query = searchInput ? searchInput.value.toLowerCase().trim() : '';
        var rows  = table.querySelectorAll('tbody tr');

        rows.forEach(function(row) {
            var rowDir = row.getAttribute('data-direction') || '';
            var text   = row.innerText.toLowerCase();

            var matchesSearch = (text.indexOf(query) > -1);
            var matchesChip   = (activeDir === 'all' || rowDir === activeDir);

            if (matchesSearch && matchesChip) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyCashFilters);
    }

    if (chipBtns.length > 0) {
        chipBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                chipBtns.forEach(function(b) { b.classList.remove('active'); });
                this.classList.add('active');
                activeDir = this.dataset.dir;
                applyCashFilters();
            });
        });
    }

    // 3. EXPORT CSV CLIENT TABLE
    var exportBtn = document.getElementById('pk01-export-cash-csv');
    if (exportBtn && table) {
        exportBtn.addEventListener('click', function() {
            var csv = [];
            var rows = table.querySelectorAll('tr');
            rows.forEach(function(row) {
                if (row.style.display === 'none') return;
                var cols = row.querySelectorAll('th, td');
                var line = [];
                cols.forEach(function(col) {
                    var text = col.innerText.replace(/"/g, '""').trim();
                    line.push('"' + text + '"');
                });
                csv.push(line.join(','));
            });
            var blob = new Blob(["\uFEFF" + csv.join("\r\n")], { type: 'text/csv;charset=utf-8;' });
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.setAttribute('download', 'PK01_Buku_Kas_' + new Date().toISOString().slice(0,10) + '.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    }
});
</script>