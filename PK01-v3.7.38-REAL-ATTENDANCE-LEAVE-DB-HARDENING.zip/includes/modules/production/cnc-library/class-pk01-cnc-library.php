<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 CNC G-code Master Library.
 * Menyimpan file G-code yang sudah tervalidasi sebagai MASTER per produk/varian.
 * G-code tidak dibuat oleh modul ini; DODI/OpenBuilds tetap menjadi sumber CAM.
 */
class PK01_CNC_Library {
    const CAP = 'manage_options';
    public static function init() {
        add_action('admin_post_pk01_cnc_library_upload', [__CLASS__, 'upload']);
        add_action('admin_post_pk01_cnc_library_download', [__CLASS__, 'download']);
        add_action('admin_init', [__CLASS__, 'ensure_schema']);
    }
    public static function t(){ return PK01_DB::t('cnc_gcode_library'); }
    public static function ensure_schema(){
        static $done=false; if($done) return; $done=true;
        global $wpdb; $t=self::t();
        if(!$t) return;
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t))===$t) return;
        if(!function_exists('dbDelta')) require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $c=$wpdb->get_charset_collate();
        PK01_DB::dbDelta_safe("CREATE TABLE $t (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, code varchar(80) NOT NULL DEFAULT '', name varchar(190) NOT NULL DEFAULT '', product_id bigint(20) unsigned NOT NULL DEFAULT 0, variant_id bigint(20) unsigned NOT NULL DEFAULT 0, material varchar(120) NOT NULL DEFAULT '', machine_profile varchar(120) NOT NULL DEFAULT '', tool_profile varchar(120) NOT NULL DEFAULT '', width decimal(18,4) NOT NULL DEFAULT 0, height decimal(18,4) NOT NULL DEFAULT 0, depth decimal(18,4) NOT NULL DEFAULT 0, version varchar(40) NOT NULL DEFAULT '1.0', status varchar(20) NOT NULL DEFAULT 'active', attachment_id bigint(20) unsigned NOT NULL DEFAULT 0, file_name varchar(255) NOT NULL DEFAULT '', notes text DEFAULT NULL, created_by bigint(20) unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL, updated_at datetime DEFAULT NULL, PRIMARY KEY(id), UNIQUE KEY code(code), KEY product_id(product_id), KEY variant_id(variant_id), KEY status(status), KEY material(material)) $c;");
    }
    public static function can_manage(){ return current_user_can(self::CAP) || current_user_can('edit_posts') || current_user_can('pk01_produksi'); }
    public static function best_match($product_id=0,$variant_id=0,$material=''){
        global $wpdb; self::ensure_schema(); $t=self::t();
        if(!$t || (!$product_id && !$variant_id)) return null;
        $material=sanitize_text_field($material);
        $candidates=[];
        // Exact variant first, then product-wide master. A product-wide master is valid
        // only when it belongs to the same product; no unrelated product fallback exists.
        if($variant_id){
            $where='status=%s AND variant_id=%d'; $args=['active',(int)$variant_id];
            if($material!==''){$where.=' AND (material=%s OR material=\'\')';$args[]=$material;}
            $candidates=$wpdb->get_results($wpdb->prepare("SELECT * FROM `$t` WHERE $where ORDER BY CASE WHEN material=%s THEN 0 ELSE 1 END,id DESC LIMIT 20",array_merge($args,[$material])),ARRAY_A)?:[];
        }
        if(!$candidates && $product_id){
            $where='status=%s AND product_id=%d AND variant_id=0'; $args=['active',(int)$product_id];
            if($material!==''){$where.=' AND (material=%s OR material=\'\')';$args[]=$material;}
            $candidates=$wpdb->get_results($wpdb->prepare("SELECT * FROM `$t` WHERE $where ORDER BY CASE WHEN material=%s THEN 0 ELSE 1 END,id DESC LIMIT 20",array_merge($args,[$material])),ARRAY_A)?:[];
        }
        foreach($candidates as $c){
            if(self::compatible_dimensions($c,$product_id,$variant_id)) return $c;
        }
        return null;
    }
    private static function compatible_dimensions($g,$product_id,$variant_id){
        global $wpdb;
        if(!$product_id) return true;
        $p=PK01_DB::t('products'); $v=PK01_DB::t('product_variants');
        $row=$wpdb->get_row($wpdb->prepare("SELECT p.product_length,p.product_width FROM `$p` p WHERE p.id=%d",(int)$product_id),ARRAY_A);
        if(!$row) return true;
        $a=(float)($row['product_length']??0); $b=(float)($row['product_width']??0); $x=(float)($g['width']??0); $y=(float)($g['height']??0);
        if($a<=0||$b<=0||$x<=0||$y<=0) return true;
        $tol=max(0.5,min(5.0,max($a,$b)*0.01));
        return (abs($a-$x)<=$tol && abs($b-$y)<=$tol) || (abs($a-$y)<=$tol && abs($b-$x)<=$tol);
    }
    /** Produk yang secara eksplisit membutuhkan CNC tetapi belum memiliki Master G-code aktif. */
    public static function missing_products($limit=200){
        global $wpdb; self::ensure_schema();
        $p=PK01_DB::t('products'); $v=PK01_DB::t('product_variants'); $g=self::t();
        if(!$p || !$v || !$g) return [];
        $sql="SELECT p.id product_id,p.code product_code,p.name product_name,v.id variant_id,v.sku,v.name variant_name,v.material
              FROM `{$p}` p JOIN `{$v}` v ON v.product_id=p.id
              WHERE p.cnc_required=1 AND p.status IN ('active','draft')
                AND NOT EXISTS (SELECT 1 FROM `{$g}` gx WHERE gx.status='active' AND (gx.variant_id=v.id OR (gx.variant_id=0 AND gx.product_id=p.id)))
              ORDER BY p.name,v.name LIMIT %d";
        return $wpdb->get_results($wpdb->prepare($sql,max(1,(int)$limit)),ARRAY_A)?:[];
    }

    public static function upload(){
        if(!self::can_manage()) wp_die('Tidak diizinkan.');
        check_admin_referer('pk01_cnc_library_upload');
        self::ensure_schema(); global $wpdb;
        $variant_id=absint($_POST['variant_id']??0); $product_id=absint($_POST['product_id']??0);
        if($variant_id){
            $linked=(int)$wpdb->get_var($wpdb->prepare("SELECT product_id FROM `".PK01_DB::t('product_variants')."` WHERE id=%d",$variant_id));
            if(!$linked) wp_die('Variant/SKU tidak ditemukan.');
            if($product_id && $linked!==$product_id) wp_die('Variant/SKU bukan milik produk yang dipilih.');
            $product_id=$linked;
        }
        if(!$product_id) wp_die('Produk wajib dipilih untuk Master G-code.');
        $code=sanitize_text_field($_POST['code']??''); $name=sanitize_text_field($_POST['name']??'');
        if(!$code||!$name||empty($_FILES['gcode_file']['tmp_name'])) wp_die('Kode, nama, dan file G-code wajib diisi.');
        $f=$_FILES['gcode_file']; $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
        if(!in_array($ext,['gcode','nc','ngc','tap','txt'],true)) wp_die('Format G-code harus .gcode, .nc, .ngc, .tap atau .txt.');
        if((int)$f['error']!==UPLOAD_ERR_OK) wp_die('Upload file gagal.');
        $up=wp_upload_dir(); $dir=trailingslashit($up['basedir']).'pk01-cnc'; if(!wp_mkdir_p($dir)) wp_die('Folder penyimpanan CNC tidak dapat dibuat.');
        $safe=sanitize_file_name($f['name']); $dest=trailingslashit($dir).wp_unique_filename($dir,$safe);
        if(!move_uploaded_file($f['tmp_name'],$dest)) wp_die('File G-code tidak dapat disimpan.');
        $material=sanitize_text_field($_POST['material']??''); $machine=sanitize_text_field($_POST['machine_profile']??''); $tool=sanitize_text_field($_POST['tool_profile']??'');
        $data=['code'=>$code,'name'=>$name,'product_id'=>$product_id,'variant_id'=>$variant_id,'material'=>$material,'machine_profile'=>$machine,'tool_profile'=>$tool,'width'=>(float)($_POST['width']??0),'height'=>(float)($_POST['height']??0),'depth'=>(float)($_POST['depth']??0),'version'=>sanitize_text_field($_POST['version']??'1.0'),'status'=>'active','attachment_id'=>0,'file_name'=>basename($dest),'notes'=>sanitize_textarea_field($_POST['notes']??''),'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')];
        $ok=$wpdb->insert(self::t(),$data); if(!$ok){@unlink($dest); wp_die('G-code gagal disimpan: '.esc_html($wpdb->last_error));}
        $url=add_query_arg(['pk01_view'=>'cnc_library'],PK01_Shortcodes::frontend_url_public('production_hub'));
        wp_safe_redirect(add_query_arg('saved',1,$url)); exit;
    }
    public static function download(){
        if(!self::can_manage()) wp_die('Tidak diizinkan.'); self::ensure_schema(); global $wpdb; $id=absint($_GET['id']??0); $r=$wpdb->get_row($wpdb->prepare('SELECT * FROM `'.self::t().'` WHERE id=%d',$id),ARRAY_A); if(!$r) wp_die('G-code tidak ditemukan.');
        $up=wp_upload_dir(); $path=trailingslashit($up['basedir']).'pk01-cnc/'.basename($r['file_name']); if(!is_file($path)) wp_die('File G-code tidak ditemukan di penyimpanan.');
        nocache_headers(); header('Content-Type: text/plain; charset=utf-8'); header('Content-Disposition: attachment; filename="'.basename($r['file_name']).'"'); header('Content-Length: '.filesize($path)); readfile($path); exit;
    }
    public static function render(){
        if(!self::can_manage()) return '<div class="pk01-op-card"><h3>Akses terbatas</h3><p>Master G-code CNC hanya untuk pengguna Produksi/Admin yang berwenang.</p></div>';
        self::ensure_schema(); global $wpdb; $t=self::t();
        $products=$wpdb->get_results('SELECT id,code,name FROM `'.PK01_DB::t('products').'` ORDER BY name LIMIT 500',ARRAY_A)?:[];
        $rows=$wpdb->get_results('SELECT g.*,p.name product_name,v.sku,v.name variant_name FROM `'.$t.'` g LEFT JOIN `'.PK01_DB::t('products').'` p ON p.id=g.product_id LEFT JOIN `'.PK01_DB::t('product_variants').'` v ON v.id=g.variant_id ORDER BY g.id DESC LIMIT 100',ARRAY_A)?:[];
        $base=PK01_Shortcodes::frontend_url_public('production_hub'); ob_start();
        echo '<section class="pk01-op-card"><div class="pk01-op-card-head"><span class="pk01-op-eyebrow">PRODUCTION / CNC</span><h2>Database G-code CNC</h2><p>Simpan G-code MASTER yang sudah benar untuk produk. Saat Job baru dibuat, PK01 mencocokkan G-code berdasarkan <strong>varian → produk → material</strong>. File kemudian diberikan ke operator CNC secara manual.</p></div>';
        if(isset($_GET['saved'])) echo '<div class="pk01-op-notice is-success">G-code MASTER berhasil disimpan.</div>';
        echo '<div style="padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;margin-bottom:18px"><strong>Aturan otomatis</strong><ol style="margin:8px 0 0 20px"><li>Varian/SKU cocok = prioritas tertinggi.</li><li>Jika belum ada, cari Master berdasarkan produk.</li><li>Material yang sama diprioritaskan; material kosong dianggap umum.</li><li>Jika tidak ada kecocokan, Job diberi status <strong>G-code belum tersedia</strong> dan operator tidak boleh menganggap file lain sebagai pengganti.</li></ol></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data" class="pk01-op-form-grid">'.wp_nonce_field('pk01_cnc_library_upload','_wpnonce',true,false).'<input type="hidden" name="action" value="pk01_cnc_library_upload">';
        echo '<div><label>Kode Master</label><input name="code" required placeholder="CNC-PROD-001-V1"></div><div><label>Nama G-code</label><input name="name" required placeholder="Panel Bunga 600x800"></div>';
        echo '<div><label>Produk</label><select name="product_id"><option value="0">— Pilih produk —</option>'; foreach($products as $p) echo '<option value="'.(int)$p['id'].'">'.esc_html($p['name'].' ['.$p['code'].']').'</option>'; echo '</select></div>';
        echo '<div><label>Variant ID / SKU</label><input name="variant_id" type="number" min="0" placeholder="ID varian jika sudah diketahui"></div>';
        echo '<div><label>Material</label><input name="material" placeholder="PVC 3mm"></div><div><label>Profil Mesin</label><input name="machine_profile" placeholder="CNC Router 1200x500"></div><div><label>Tool</label><input name="tool_profile" placeholder="V-bit / Endmill"></div><div><label>Versi</label><input name="version" value="1.0"></div>';
        echo '<div><label>Lebar G-code (mm)</label><input name="width" type="number" step="0.01"></div><div><label>Tinggi G-code (mm)</label><input name="height" type="number" step="0.01"></div><div><label>Kedalaman (mm)</label><input name="depth" type="number" step="0.01"></div><div><label>File G-code</label><input name="gcode_file" type="file" accept=".gcode,.nc,.ngc,.tap,.txt" required></div>';
        echo '<div style="grid-column:1/-1"><label>Catatan</label><textarea name="notes" rows="3" placeholder="Setting OpenBuilds/CAM yang dipakai, asal file, catatan operator..."></textarea></div><div style="grid-column:1/-1"><button class="pk01-op-button" type="submit">💾 Simpan G-code Master</button></div></form></section>';
        $missing=self::missing_products();
        echo '<section class="pk01-op-card" style="margin-top:18px;border:1px solid '.($missing?'#fecaca':'#bbf7d0').';background:'.($missing?'#fff7f7':'#f0fdf4').'"><div class="pk01-op-card-head"><span class="pk01-op-eyebrow">COVERAGE CNC</span><h3>'.($missing?'⚠️ Produk CNC Belum Memiliki G-code':'✅ Semua Produk CNC Memiliki Master').'</h3><p>'.($missing?'Daftar ini hanya berasal dari produk yang secara eksplisit ditandai <strong>membutuhkan CNC</strong>. Produk non-CNC tidak masuk daftar dan tidak dituntut memiliki G-code.':'Tidak ada produk aktif/draft yang ditandai membutuhkan CNC tetapi belum memiliki Master G-code aktif.').'</p></div>';
        if($missing){ echo '<div style="overflow:auto"><table class="pk01-prod-table"><thead><tr><th>Produk</th><th>SKU</th><th>Material</th><th>Status</th></tr></thead><tbody>'; foreach($missing as $m){ echo '<tr><td><b>'.esc_html($m['product_name']).'</b><br><small>'.esc_html($m['product_code']).'</small></td><td>'.esc_html($m['sku']).'</td><td>'.esc_html($m['material']?:'-').'</td><td><strong style="color:#b91c1c">G-code belum tersedia</strong></td></tr>'; } echo '</tbody></table></div>'; }
        echo '</section>';

        echo '<section class="pk01-op-card" style="margin-top:18px"><div class="pk01-op-card-head"><span class="pk01-op-eyebrow">MASTER AKTIF</span><h3>Database G-code</h3></div><div style="overflow:auto"><table class="pk01-prod-table"><thead><tr><th>Kode</th><th>Produk / SKU</th><th>Material</th><th>Ukuran</th><th>Versi</th><th>Status</th><th>File</th></tr></thead><tbody>';
        foreach($rows as $r){$download=wp_nonce_url(add_query_arg(['action'=>'pk01_cnc_library_download','id'=>(int)$r['id']],admin_url('admin-post.php')),'pk01_cnc_library_download'); echo '<tr><td><b>'.esc_html($r['code']).'</b><br><small>'.esc_html($r['name']).'</small></td><td>'.esc_html($r['product_name']?:'-').'<br><small>'.esc_html($r['sku']?:($r['variant_id']?'Variant #'.$r['variant_id']:'Produk umum')).'</small></td><td>'.esc_html($r['material']?:'Umum').'</td><td>'.esc_html(rtrim(rtrim((string)$r['width'],'0'),'.').' × '.rtrim(rtrim((string)$r['height'],'0'),'.').' mm').'</td><td>'.esc_html($r['version']).'</td><td>'.esc_html($r['status']).'</td><td><a class="pk01-op-button is-small" href="'.esc_url($download).'">⬇ Ambil G-code</a></td></tr>';}
        if(!$rows) echo '<tr><td colspan="7">Belum ada G-code Master.</td></tr>'; echo '</tbody></table></div></section>';
        echo '<section class="pk01-op-card" style="margin-top:18px"><div class="pk01-op-card-head"><h3>Alur Job CNC</h3><p>Job baru tidak membuat G-code secara otomatis dari file acak. Sistem hanya memilih Master yang cocok dan menampilkan file untuk operator.</p></div><div class="pk01-simple-flow"><div><b>1. Job dibuat</b><span>Produk + SKU + material</span></div><div><b>2. Cari Master</b><span>Variant → Product → Material</span></div><div><b>3. Validasi</b><span>Ukuran/tool/depth diperiksa</span></div><div><b>4. Operator ambil file</b><span>G-code diberikan manual ke CNC</span></div><div><b>5. Jalankan</b><span>Preview di CONTROL sebelum start</span></div></div></section>';
        return ob_get_clean();
    }
}
