<?php if (!defined('ABSPATH')) exit; global $wpdb;
$action=PK01_Shortcodes::frontend_url_public('production'); $notice=''; $last_batch=null;
$dodi_cnc_url=apply_filters('pk01_dodi_cnc_url',home_url('/dodi-cnc/'));
$current_user=wp_get_current_user();
$can_assign_jobs=current_user_can('manage_options') || current_user_can('edit_posts') || in_array('pk01_produksi',(array)$current_user->roles,true) || in_array('pk01_admin',(array)$current_user->roles,true);
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pk01_production_action']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_production_nonce']??'')),'pk01_production')){
 try{
  $act=sanitize_key($_POST['pk01_production_action']);
  if($act==='create'){PK01_Engine::create_production_job($_POST['job_no']??'',(int)$_POST['variant_id'],(float)$_POST['qty'],$_POST['location']??'',$_POST['deadline']??'',$_POST['production_date']??'',$_POST['instructions']??'',$_POST['priority']??'normal');$notice='<div class="pk01-op-notice is-success">Job produksi berhasil dibuat. Spesifikasi produk disimpan sebagai referensi pekerjaan.</div>';}
  elseif($act==='result'){ $last_batch=PK01_Engine::record_production_result((int)$_POST['job_id'],(float)$_POST['good_qty'],(float)$_POST['reject_qty'],true); $notice='<div class="pk01-op-notice is-success"><strong>Hasil produksi disimpan.</strong> Stok barang jadi bertambah dan batch resmi dibuat.</div>'; }
  elseif($act==='assign'){
   if(!$can_assign_jobs) throw new Exception('Anda tidak berwenang memberikan Job.');
   PK01_Engine::assign_job_employee_with_role(absint($_POST['job_id']??0),absint($_POST['employee_id']??0),$_POST['role_code']??'','manual',0,$_POST['notes']??'');
   $notice='<div class="pk01-op-notice is-success">✅ Job berhasil diberikan. Pekerja akan melihat Job yang sama di Dashboard Pekerja Borongan sebagai <strong>Menunggu Diterima</strong>.</div>';
  }
 }catch(Throwable $e){$notice='<div class="pk01-op-notice is-error">'.esc_html($e->getMessage()).'</div>';}
}
$variants=$wpdb->get_results('SELECT v.id,v.sku,v.name,p.name product_name FROM '.PK01_DB::t('product_variants').' v JOIN '.PK01_DB::t('products').' p ON p.id=v.product_id WHERE v.status="active" ORDER BY p.name,v.name',ARRAY_A)?:[];
$jobs=$wpdb->get_results('SELECT j.*,ji.variant_id,v.sku,v.name variant_name,p.name product_name,p.image_id,p.product_description,p.production_notes,p.production_instructions,p.product_length,p.product_width,p.product_height,p.product_thickness,p.dimension_unit,p.finishing product_finishing,p.cnc_required,p.color,v.material,v.finishing variant_finishing,COALESCE(SUM(pr.good_qty),0) good_qty,COALESCE(SUM(pr.reject_qty),0) reject_qty,(SELECT pr2.production_code FROM '.PK01_DB::t('production_results').' pr2 WHERE pr2.job_id=j.id ORDER BY pr2.id DESC LIMIT 1) latest_production_code,(SELECT pr2.batch_code FROM '.PK01_DB::t('production_results').' pr2 WHERE pr2.job_id=j.id ORDER BY pr2.id DESC LIMIT 1) latest_batch_code,ja.id assignment_id,ja.status assignment_status,ja.notes assignment_notes,e.name employee_name,e.code employee_code FROM '.PK01_DB::t('jobs').' j LEFT JOIN '.PK01_DB::t('job_items').' ji ON ji.job_id=j.id LEFT JOIN '.PK01_DB::t('product_variants').' v ON v.id=ji.variant_id LEFT JOIN '.PK01_DB::t('products').' p ON p.id=v.product_id LEFT JOIN '.PK01_DB::t('production_results').' pr ON pr.job_id=j.id LEFT JOIN '.PK01_DB::t('job_assignments').' ja ON ja.job_id=j.id AND ja.id=(SELECT MAX(ja2.id) FROM '.PK01_DB::t('job_assignments').' ja2 WHERE ja2.job_id=j.id) LEFT JOIN '.PK01_DB::t('employees').' e ON e.id=ja.employee_id GROUP BY j.id ORDER BY j.id DESC LIMIT 50',ARRAY_A)?:[];
$job_assignment_map=[];
if(!empty($jobs)){
 $ids=implode(',',array_map('intval',array_column($jobs,'id')));
 $rows=$wpdb->get_results("SELECT ja.id,ja.job_id,ja.employee_id,ja.role_code,ja.status,ja.notes,e.name employee_name,e.code employee_code FROM `".PK01_DB::t('job_assignments')."` ja LEFT JOIN `".PK01_DB::t('employees')."` e ON e.id=ja.employee_id WHERE ja.job_id IN ({$ids}) ORDER BY ja.job_id DESC, ja.id ASC",ARRAY_A)?:[];
 foreach($rows as $ar) $job_assignment_map[(int)$ar['job_id']][]=$ar;
 foreach($jobs as &$jj) $jj['assignment_list']=$job_assignment_map[(int)$jj['id']]??[];
 unset($jj);
}
$employees=$can_assign_jobs ? ($wpdb->get_results('SELECT id,code,name FROM `'.PK01_DB::t('employees').'` WHERE status="active" ORDER BY name',ARRAY_A)?:[]) : [];
?>
<div class="pk01-op-card">
 <div class="pk01-op-card-head"><span class="pk01-op-eyebrow">OPERASIONAL</span><h2>Produksi & Pekerjaan</h2><p>Order Produksi dari Kasir menjadi satu-satunya pintu resmi ke Team Produksi. Model lama memakai Master PK01; model baru wajib membawa ukuran, Gambar Produk, Gambar Kerja, dan File CNC bila metode CNC.</p></div>
 <div class="pk01-dodi-launch"><div><span class="pk01-op-eyebrow">MODUL CNC</span><h3 style="margin:3px 0">DODI CNC</h3><p style="margin:4px 0;color:#64748b">Buka Dashboard CNC tanpa login kedua. Akses pengguna tetap mengikuti Login Operasional PK01.</p></div><a class="pk01-op-button" href="<?php echo esc_url($dodi_cnc_url); ?>" target="_blank" rel="noopener">⚙️ Buka Dashboard DODI CNC</a></div>
 <?php echo $notice; ?>
 <?php if(is_array($last_batch) && !empty($last_batch['batch_code'])): ?>
 <div class="pk01-batch-result-card" data-batch-code="<?php echo esc_attr($last_batch['batch_code']); ?>" data-qr="<?php echo esc_attr($last_batch['qr_payload']); ?>">
   <div><span class="pk01-op-eyebrow">BATCH PRODUKSI RESMI</span><h3><?php echo esc_html($last_batch['batch_code']); ?></h3><p>Gunakan kode ini untuk pencarian, pelacakan produksi, label barang jadi, dan scan berikutnya.</p></div>
   <div class="pk01-batch-code-preview"><div class="pk01-barcode" data-barcode="<?php echo esc_attr($last_batch['barcode_value']); ?>"></div><small><?php echo esc_html($last_batch['barcode_value']); ?></small></div>
   <div id="pk01-batch-qr-<?php echo (int)$last_batch['result_id']; ?>" class="pk01-qr-preview" data-qr="<?php echo esc_attr($last_batch['qr_payload']); ?>"></div>
   <div class="pk01-batch-actions"><?php if (!empty($last_batch['job_id']) && function_exists('pk01_print_url')): ?><a class="pk01-op-button is-small" target="_blank" rel="noopener" href="<?php echo esc_url(pk01_print_url('produksi',(int)$last_batch['job_id'])); ?>">Cetak Label Batch PDF</a><?php endif; ?><button type="button" class="pk01-op-button is-small pk01-copy-batch">Salin Kode</button></div>
 </div>
 <?php endif; ?>
 <div class="pk01-supplier-grid"><div class="pk01-supplier-form"><h3>Buat Job Produksi</h3>
 <form method="post" action="<?php echo esc_url($action); ?>"><?php echo wp_nonce_field('pk01_production','pk01_production_nonce',true,false); ?><input type="hidden" name="pk01_production_action" value="create">
 <div class="pk01-op-form-grid">
  <label>No. Job / Batch<input name="job_no" placeholder="BATCH-20260904-001"></label>
  <label>Produk / SKU<select name="variant_id" required><option value="">Pilih produk...</option><?php foreach($variants as $v): ?><option value="<?php echo (int)$v['id']; ?>"><?php echo esc_html($v['product_name'].' — '.$v['sku'].' — '.$v['name']); ?></option><?php endforeach; ?></select></label>
  <label>Tanggal Produksi<input type="date" name="production_date" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" required></label>
  <label>Jumlah Target<input type="number" name="qty" min="1" step="1" required></label>
  <label>Lokasi Produksi<input name="location" placeholder="Workshop Utama"></label>
  <label>Deadline<input type="date" name="deadline"></label>
  <label>Prioritas<select name="priority"><option value="normal">Normal</option><option value="high">Tinggi</option><option value="urgent">Mendesak</option><option value="low">Rendah</option></select></label>
 </div>
 <label style="display:block;margin-top:12px">Instruksi Khusus Job<textarea name="instructions" rows="4" placeholder="Instruksi tambahan untuk pekerjaan ini."></textarea></label>
 <button class="pk01-op-button" style="margin-top:12px">Buat Job Produksi</button>
 </form></div>
 <div class="pk01-supplier-help"><h3>Alur Kerja</h3><p>Penjualan Kasir → Cek Stok → jika kurang: Order Produksi → Team Produksi → Hasil Produksi → Stok Barang Jadi → Fulfillment.</p><p><b>Penting:</b> gambar referensi dan spesifikasi disimpan sebagai acuan Job agar perubahan Produk berikutnya tidak mengubah histori pekerjaan lama.</p></div></div>
 <div class="pk01-section-title" style="margin-top:24px"><h3>Job Produksi</h3></div>
 <?php if($can_assign_jobs): ?>
 <div class="pk01-op-card" style="margin:16px 0;border:1px solid #bfdbfe;background:#f8fbff">
  <div class="pk01-section-title"><div><span class="pk01-op-eyebrow">PEMBERI JOB</span><h3 style="margin:3px 0">Pemberian Job Pekerja Borongan</h3><p style="margin:4px 0;color:#64748b;font-size:13px">Satu Job dapat memiliki beberapa tahap. Jika produk membutuhkan CNC + Prema, PK01 membuat dua assignment ke dua pekerja berbeda dan masing-masing menerima instruksi tahapnya sendiri.</p></div></div>
  <div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr><th style="text-align:left;padding:8px">Job</th><th style="text-align:left;padding:8px">Penerima</th><th style="text-align:left;padding:8px">Status</th><th style="text-align:left;padding:8px">Aksi</th></tr></thead><tbody>
  <?php foreach($jobs as $j): ?>
   <tr style="border-top:1px solid #e2e8f0"><td style="padding:8px"><strong><?php echo esc_html($j['job_no']); ?></strong><br><?php echo esc_html($j['product_name']?:$j['variant_name']); ?></td><td style="padding:8px"><?php if(!empty($j['assignment_list'])): foreach($j['assignment_list'] as $al): ?><div style="margin-bottom:4px"><b><?php echo esc_html(strtoupper($al['role_code']?:'tahap')); ?></b> → <?php echo esc_html($al['employee_name'].' ('.$al['employee_code'].')'); ?> <span style="color:#64748b">[<?php echo esc_html($al['status']); ?>]</span></div><?php endforeach; else: ?><span style="color:#94a3b8">Belum ditugaskan</span><?php endif; ?></td><td style="padding:8px"><strong><?php echo esc_html($j['assignment_status']?:'Belum Ditugaskan'); ?></strong></td><td style="padding:8px">
   <?php $active_assignments=array_filter($j['assignment_list']??[],function($aa){return !in_array($aa['status'],['completed','returned'],true);}); if(!$active_assignments): ?>
    <form method="post" style="display:flex;gap:6px;flex-wrap:wrap"><?php echo wp_nonce_field('pk01_production','pk01_production_nonce',true,false); ?><input type="hidden" name="pk01_production_action" value="assign"><input type="hidden" name="job_id" value="<?php echo (int)$j['id']; ?>"><select name="employee_id" required><option value="">Pilih pekerja...</option><?php foreach($employees as $emp): ?><option value="<?php echo (int)$emp['id']; ?>"><?php echo esc_html($emp['name'].' — '.$emp['code']); ?></option><?php endforeach; ?></select><input name="role_code" placeholder="Peran (opsional)"><button class="pk01-op-button is-small">Kirim Job</button></form>
   <?php else: ?><span style="font-size:12px;color:#64748b">Sinkron. Status penerimaan akan berubah dari Dashboard Pekerja.</span><?php endif; ?>
   </td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
 </div>
 <?php endif; ?>
 <div class="pk01-production-job-list">
 <?php foreach($jobs as $j):
  $img=$j['image_id']?wp_get_attachment_image_url((int)$j['image_id'],'medium'):'';
  $snap=json_decode((string)($j['spec_snapshot']??''),true); $snap=is_array($snap)?$snap:[];
  $L=$snap['length']??$j['product_length']; $W=$snap['width']??$j['product_width']; $H=$snap['height']??$j['product_height']; $T=$snap['thickness']??$j['product_thickness']; $du=$snap['dimension_unit']??$j['dimension_unit']??'cm';
  $desc=$snap['description']??$j['product_description']; $notes=$snap['production_notes']??$j['production_notes']; $instr=$j['instructions']?:($snap['production_instructions']??$j['production_instructions']); $mat=$snap['material']??$j['material']; $fin=$snap['variant_finishing']??($j['variant_finishing']?:$j['product_finishing']); $color=$snap['color']??$j['color'];
 ?>
 <article class="pk01-op-card pk01-production-job" style="margin-bottom:16px"><div style="display:grid;grid-template-columns:minmax(180px,240px) 1fr;gap:20px;align-items:start">
  <div><?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($j['product_name']); ?>" style="width:100%;max-height:240px;object-fit:cover;border-radius:12px"><?php else: ?><div style="height:180px;display:grid;place-items:center;background:#f1f5f9;border-radius:12px">Belum ada gambar</div><?php endif; ?><div style="margin-top:8px;font-weight:700"><?php echo esc_html($j['job_no']); ?></div></div>
  <div><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><span class="pk01-op-eyebrow">JOB PRODUKSI</span><h3 style="margin:4px 0"><?php echo esc_html($j['product_name']?:$j['variant_name']); ?></h3><div><?php echo esc_html($j['sku']); ?> • Target <?php echo esc_html($j['target_qty']); ?></div><?php if(!empty($j['source_order_id'])): ?><div style="margin-top:5px;font-size:12px;color:#1d4ed8;font-weight:700">🧾 Sumber: Order Penjualan Kasir #<?php echo (int)$j['source_order_id']; ?> — Kasir adalah pemberi Order Produksi</div><?php endif; ?></div><span class="pk01-op-badge"><?php echo esc_html($j['status']); ?></span></div>
  <div style="margin-top:8px;padding:9px 12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;font-size:12px"><strong>Pemberi → Penerima:</strong> <?php echo $j['employee_name'] ? esc_html($j['employee_name'].' ('.$j['employee_code'].')') : 'Belum ada pekerja'; ?> · <strong>Status Penugasan:</strong> <?php echo esc_html($j['assignment_status']?:'belum ditugaskan'); ?></div>
  <div class="pk01-op-form-grid" style="margin-top:14px"><div><b>Ukuran</b><br><?php echo esc_html($L.' × '.$W.' × '.$H.' '.$du); ?><?php if((float)$T>0): ?><br>Tebal: <?php echo esc_html($T.' '.$du); ?><?php endif; ?></div><div><b>Bahan</b><br><?php echo esc_html($mat?:'-'); ?></div><div><b>Finishing</b><br><?php echo esc_html(trim($fin.' '.$color)?:'-'); ?></div><div><b>Deadline</b><br><?php echo esc_html($j['deadline']?:'-'); ?></div></div>
  <?php if($desc): ?><div style="margin-top:12px"><b>Deskripsi Produk</b><p><?php echo nl2br(esc_html($desc)); ?></p></div><?php endif; ?>
  <?php if($notes): ?><div style="margin-top:12px"><b>Catatan Untuk Produksi</b><p><?php echo nl2br(esc_html($notes)); ?></p></div><?php endif; ?>
  <?php if($instr): ?><div style="margin-top:12px;padding:12px;border:1px solid #e2e8f0;border-radius:10px"><b>Instruksi Kerja</b><p><?php echo nl2br(esc_html($instr)); ?></p></div><?php endif; ?>
  <div style="margin-top:14px;padding:12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc"><b>Rekomendasi Peran Pekerjaan</b><p style="margin:4px 0 8px;font-size:12px;color:#64748b">PK01 mencocokkan job dengan posisi/divisi karyawan yang benar-benar tersimpan. Jika AI aktif, rekomendasi ini dapat dianalisis AI; eksekusi penugasan tetap melewati permission, validasi, dan Engine.</p><?php try{$recs=class_exists('PK01_Finance')?PK01_Finance::job_role_recommendations((int)$j['id']):[];}catch(Throwable $e){$recs=[];} ?><?php if($recs): ?><div style="display:flex;gap:8px;flex-wrap:wrap"><?php foreach(array_slice($recs,0,3) as $rec): ?><span class="pk01-op-badge"><?php echo esc_html($rec['employee_name'].' → '.($rec['role_name']?:'Belum ada kecocokan').' ('.number_format($rec['confidence']*100,0).'%)'); ?></span><?php endforeach; ?></div><?php else: ?><span style="font-size:12px;color:#64748b">Belum ada karyawan aktif yang dapat dicocokkan.</span><?php endif; ?></div>
  <?php if(!empty($j['latest_production_code'])): ?>
  <div style="margin-top:14px;padding:12px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff">
   <div style="font-size:11px;font-weight:800;color:#1d4ed8;letter-spacing:.05em">IDENTITAS HASIL PRODUKSI TERSIMPAN</div>
   <div style="margin-top:5px;font-size:13px"><strong>Kode Produksi:</strong> <?php echo esc_html($j['latest_production_code']); ?> · <strong>Batch:</strong> <?php echo esc_html($j['latest_batch_code']); ?></div>
   <div style="margin-top:3px;font-size:11px;color:#475569">Kode CNC dibuat otomatis untuk setiap unit baik dan dicatat di database PK01. Scan kode akan mengarah kembali ke identitas produk, ukuran, Job, dan riwayat produksi.</div>
  </div>
  <?php endif; ?>
  <?php
   $cnc_master = null;
   try { if (class_exists('PK01_CNC_Library')) $cnc_master = PK01_CNC_Library::best_match((int)($j['product_id']??0),(int)($j['variant_id']??0),(string)$mat); } catch(Throwable $e) { $cnc_master=null; }
  ?>
  <div style="margin-top:12px;padding:12px;border:1px solid <?php echo $cnc_master ? '#bbf7d0' : '#fecaca'; ?>;border-radius:10px;background:<?php echo $cnc_master ? '#f0fdf4' : '#fef2f2'; ?>">
   <b>⚙️ G-code CNC Master</b>
   <?php if($cnc_master): ?>
    <div style="margin-top:5px;font-size:12px"><strong><?php echo esc_html($cnc_master['name']); ?></strong> · <?php echo esc_html($cnc_master['code']); ?> · v<?php echo esc_html($cnc_master['version']); ?></div>
    <div style="font-size:12px;color:#475569">Ukuran <?php echo esc_html($cnc_master['width'].' × '.$cnc_master['height'].' mm'); ?> · Depth <?php echo esc_html($cnc_master['depth'].' mm'); ?> · Material <?php echo esc_html($cnc_master['material']?:'Umum'); ?></div>
    <?php if(!empty($cnc_master['file_name'])): ?><a class="pk01-op-button is-small" style="margin-top:8px" href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action'=>'pk01_cnc_library_download','id'=>(int)$cnc_master['id']],admin_url('admin-post.php')),'pk01_cnc_library_download')); ?>">⬇ Ambil G-code untuk Job ini</a><?php endif; ?>
   <?php else: ?>
    <div style="margin-top:5px;font-size:12px;color:#991b1b"><strong>G-code belum tersedia.</strong> Jangan gunakan G-code produk lain. Simpan Master yang sesuai dengan produk/varian ini terlebih dahulu.</div>
   <?php endif; ?>
  </div>
  <?php if(!empty($snap['technical_drawing_id']) || !empty($snap['cnc_file_id'])): ?><div style="margin-top:12px;padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:9px;font-size:12px"><b>📎 Dokumen Produksi dari Kasir / Master:</b> <?php if(!empty($snap['technical_drawing_id'])): ?><a href="<?php echo esc_url(wp_get_attachment_url((int)$snap['technical_drawing_id'])); ?>" target="_blank" rel="noopener">Gambar Kerja</a><?php endif; ?> <?php if(!empty($snap['cnc_file_id'])): ?> • <a href="<?php echo esc_url(wp_get_attachment_url((int)$snap['cnc_file_id'])); ?>" target="_blank" rel="noopener">File CNC</a><?php endif; ?></div><?php endif; ?>
  <div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="pk01-op-button is-small pk01-chat-job" data-job-id="<?php echo (int)$j['id']; ?>">💬 Chat CNC / Operasional</button><a class="pk01-op-button is-small" target="_blank" rel="noopener" href="<?php echo esc_url(add_query_arg('job_id',(int)$j['id'],$dodi_cnc_url)); ?>">⚙️ Buka di DODI CNC</a><a class="pk01-op-button is-small" target="_blank" href="<?php echo esc_url(pk01_print_url('produksi',(int)$j['id'])); ?>">Cetak Job</a><a class="pk01-op-button is-small" target="_blank" href="<?php echo esc_url(pk01_print_url('label-produksi',(int)$j['id'])); ?>">Cetak Label</a><a class="pk01-op-button is-small" target="_blank" href="<?php echo esc_url(pk01_print_url('label-thermal',(int)$j['id'])); ?>">🧾 Label Thermal 58mm</a><a class="pk01-op-button is-small" target="_blank" href="<?php echo esc_url(pk01_print_url('pemasangan',(int)$j['variant_id'])); ?>">Petunjuk Pemasangan</a><?php if($j['status']!=='completed'): ?><details><summary class="pk01-op-button is-small" style="display:inline-block">Catat Hasil</summary><form method="post" style="margin-top:8px"><?php echo wp_nonce_field('pk01_production','pk01_production_nonce',true,false); ?><input type="hidden" name="pk01_production_action" value="result"><input type="hidden" name="job_id" value="<?php echo (int)$j['id']; ?>"><input type="number" name="good_qty" placeholder="Jumlah baik" min="0" required><input type="number" name="reject_qty" placeholder="Rusak" min="0" value="0"><button class="pk01-op-button is-small">Simpan Hasil</button></form></details><?php endif; ?></div>
  </div></div></article>
 <?php endforeach; if(!$jobs): ?><div class="pk01-op-empty">Belum ada Job Produksi.</div><?php endif; ?>
 </div>
</div>

<div id="pk01DodiChatModal" class="pk01-dodi-chat-modal" hidden>
  <div class="pk01-dodi-chat-box">
    <div class="pk01-dodi-chat-head">
      <div><strong id="pk01DodiChatTitle">CNC ↔ Operasional</strong><small id="pk01DodiChatSub">Komunikasi Job</small></div>
      <button type="button" id="pk01DodiChatClose">Tutup</button>
    </div>
    <div id="pk01DodiChatList" class="pk01-dodi-chat-list"></div>
    <form id="pk01DodiChatForm" class="pk01-dodi-chat-form">
      <input id="pk01DodiChatInput" maxlength="5000" autocomplete="off" placeholder="Tulis pesan untuk pekerja CNC / operasional...">
      <button type="submit">Kirim</button>
    </form>
    <div class="pk01-dodi-chat-note">Pesan tersimpan di server PK01 dan dapat dibaca oleh pengguna yang berwenang pada Job ini.</div>
  </div>
</div>
<script>
(function(){
 const api=<?php echo wp_json_encode(rest_url('pk01/v1')); ?>;
 const nonce=<?php echo wp_json_encode(wp_create_nonce('wp_rest')); ?>;
 let job=0,last=0,timer=null;
 const modal=document.getElementById('pk01DodiChatModal'), list=document.getElementById('pk01DodiChatList');
 function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
 async function req(path,opt){let r=await fetch(api+path,Object.assign({credentials:'same-origin',headers:{'X-WP-Nonce':nonce,'Content-Type':'application/json'}},opt||{}));let j=await r.json();if(!r.ok)throw new Error(j.message||'Chat gagal');return j}
 async function load(mark){
   if(!job)return; let j=await req('/chat/job/'+job);
   list.innerHTML=(j.messages||[]).map(m=>'<div class="pk01-dodi-msg '+(Number(m.sender_id)===Number(j.current_user_id)?'mine':'')+'"><b>'+esc(m.display_name||m.user_login||'Pengguna')+'</b><span>'+esc(m.message)+'</span><small>'+new Date(m.created_at.replace(' ','T')).toLocaleString('id-ID')+'</small></div>').join('')||'<div class="pk01-dodi-empty">Belum ada komunikasi.</div>';
   let lastMsg=(j.messages||[]).slice(-1)[0]; if(lastMsg)last=Number(lastMsg.id);
   list.scrollTop=list.scrollHeight;
   if(mark && last) await req('/chat/job/'+job+'/read',{method:'POST',body:JSON.stringify({last_read_id:last})});
 }
 function open(id,title){
   job=Number(id);document.getElementById('pk01DodiChatTitle').textContent='💬 '+(title||'CNC ↔ Operasional');
   modal.hidden=false;load(true).catch(e=>alert(e.message));
   clearInterval(timer);timer=setInterval(()=>load(false).catch(()=>{}),5000);
   document.getElementById('pk01DodiChatInput').focus();
 }
 document.querySelectorAll('.pk01-chat-job').forEach(b=>b.addEventListener('click',()=>open(b.dataset.jobId,b.closest('.pk01-production-job')?.querySelector('h3')?.textContent)));
 document.getElementById('pk01DodiChatClose').onclick=()=>{modal.hidden=true;clearInterval(timer);timer=null};
 document.getElementById('pk01DodiChatForm').onsubmit=async e=>{
   e.preventDefault();let i=document.getElementById('pk01DodiChatInput'),v=i.value.trim();if(!v||!job)return;
   try{await req('/chat/job/'+job+'/send',{method:'POST',body:JSON.stringify({message:v})});i.value='';await load(true)}catch(err){alert(err.message)}
 };
})();
</script>
<style>
@media(max-width:760px){.pk01-production-job>div{grid-template-columns:1fr!important}.pk01-production-job img{max-height:300px!important}}
</style>
