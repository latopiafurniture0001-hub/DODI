<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// 1. CEK LOGIN
if (!is_user_logged_in()) {
    echo '<div style="max-width:440px;margin:30px auto;text-align:center;padding:28px 20px;background:#ffffff;border-radius:16px;box-shadow:0 10px 25px rgba(0,0,0,0.06);font-family:sans-serif;">'
       . '<div style="font-size:54px;margin-bottom:12px;">👷‍♂️</div>'
       . '<h2 style="margin:0 0 6px 0;color:#0f172a;font-size:22px;font-weight:800;">Portal Kerja &amp; Gaji</h2>'
       . '<p style="color:#64748b;font-size:14px;line-height:1.5;margin:0 0 20px 0;">Masuk dengan akun Anda untuk melihat tugas job mebel hari ini, melapor kendala, dan memeriksa slip gaji.</p>'
       . '<a style="display:block;background:#2563eb;color:#ffffff;text-decoration:none;font-size:15px;font-weight:700;padding:14px 20px;border-radius:12px;" href="' . esc_url(class_exists('PK01_Login') ? PK01_Login::url(class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes','frontend_url_public') ? PK01_Shortcodes::frontend_url_public('job_karyawan') : get_permalink()) : wp_login_url(class_exists('PK01_Shortcodes') && method_exists('PK01_Shortcodes','frontend_url_public') ? PK01_Shortcodes::frontend_url_public('job_karyawan') : get_permalink())) . '">Masuk ke Akun Saya &rarr;</a>'
       . '</div>'; 
    return;
}

$uid = get_current_user_id();
$is_preview = class_exists('PK01_Authorization') && PK01_Authorization::is_role_preview();
$current_user = wp_get_current_user();
$is_superadmin = current_user_can('manage_options') || in_array('administrator', (array) $current_user->roles, true);
$is_admin = $is_superadmin && !$is_preview;
$is_admin_view = $is_superadmin;

$notice = '';

// Helper Nama Tabel Resmi PK01
$tbl_assignments = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('job_assignments') : $wpdb->prefix . 'pk01_job_assignments';
$tbl_jobs        = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('jobs') : $wpdb->prefix . 'pk01_jobs';
$tbl_employees   = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('employees') : $wpdb->prefix . 'pk01_employees';
$tbl_materials   = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('materials') : $wpdb->prefix . 'pk01_materials';
$tbl_job_mats    = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('job_materials') : $wpdb->prefix . 'pk01_job_materials';
$tbl_completion  = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('job_completion_reports') : $wpdb->prefix . 'pk01_job_completion_reports';
$tbl_wages       = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('job_wages') : $wpdb->prefix . 'pk01_job_wages';
$tbl_items       = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('job_items') : $wpdb->prefix . 'pk01_job_items';
$tbl_variants    = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('product_variants') : $wpdb->prefix . 'pk01_product_variants';
$tbl_products    = class_exists('PK01_DB') && method_exists('PK01_DB', 't') ? PK01_DB::t('products') : $wpdb->prefix . 'pk01_products';

// AUTO-MIGRATION KOLOM: RATING, SLIP GAJI, REKENING & KENDALA PRODUKSI
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_assignments)) === $tbl_assignments) {
    $cols_assign = $wpdb->get_col("SHOW COLUMNS FROM `{$tbl_assignments}`");
    if (!in_array('rating', $cols_assign, true)) {
        $wpdb->query("ALTER TABLE `{$tbl_assignments}` 
            ADD COLUMN `rating` tinyint(1) NOT NULL DEFAULT 0, 
            ADD COLUMN `rating_notes` text DEFAULT NULL, 
            ADD COLUMN `rated_by` bigint(20) unsigned DEFAULT 0, 
            ADD COLUMN `rated_at` datetime DEFAULT NULL");
    }
    // Kolom Kendala Produksi
    if (!in_array('obstacle_type', $cols_assign, true)) {
        $wpdb->query("ALTER TABLE `{$tbl_assignments}` 
            ADD COLUMN `obstacle_type` varchar(64) DEFAULT NULL,
            ADD COLUMN `obstacle_notes` text DEFAULT NULL,
            ADD COLUMN `obstacle_status` varchar(30) NOT NULL DEFAULT 'none',
            ADD COLUMN `obstacle_reported_at` datetime DEFAULT NULL,
            ADD COLUMN `obstacle_resolved_at` datetime DEFAULT NULL");
    }
}
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_wages)) === $tbl_wages) {
    $cols_wages = $wpdb->get_col("SHOW COLUMNS FROM `{$tbl_wages}`");
    if (!in_array('slip_no', $cols_wages, true)) {
        $wpdb->query("ALTER TABLE `{$tbl_wages}` 
            ADD COLUMN `slip_no` varchar(64) DEFAULT NULL, 
            ADD COLUMN `paid_at` datetime DEFAULT NULL, 
            ADD COLUMN `payment_method` varchar(64) DEFAULT 'Transfer Bank'");
    }
}
if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl_employees)) === $tbl_employees) {
    $cols_emp = $wpdb->get_col("SHOW COLUMNS FROM `{$tbl_employees}`");
    if (!in_array('payment_pref', $cols_emp, true)) {
        $wpdb->query("ALTER TABLE `{$tbl_employees}` 
            ADD COLUMN `payment_pref` varchar(20) NOT NULL DEFAULT 'transfer',
            ADD COLUMN `bank_name` varchar(64) DEFAULT NULL,
            ADD COLUMN `bank_account_no` varchar(64) DEFAULT NULL,
            ADD COLUMN `bank_account_name` varchar(128) DEFAULT NULL,
            ADD COLUMN `phone` varchar(30) DEFAULT NULL");
    }
}

// 2. PROSES UPDATE PROFIL & REKENING PEKERJA
if (!$is_preview && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_worker_update_profile'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_profile_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_worker_profile')) {
        $notice = '<div class="pk-alert pk-alert-error">⚠️ Sesi keamanan habis. Silakan muat ulang halaman.</div>';
    } else {
        try {
            $emp_target_id = absint($_POST['target_employee_id'] ?? 0);
            $payment_pref  = sanitize_key($_POST['payment_pref'] ?? 'transfer');
            $payment_pref  = in_array($payment_pref, ['transfer', 'cash'], true) ? $payment_pref : 'transfer';
            $bank_name     = sanitize_text_field($_POST['bank_name'] ?? '');
            $bank_no       = sanitize_text_field($_POST['bank_account_no'] ?? '');
            $bank_holder   = sanitize_text_field($_POST['bank_account_name'] ?? '');
            $phone         = sanitize_text_field($_POST['phone'] ?? '');

            if ($emp_target_id <= 0) throw new Exception('ID Pekerja tidak valid.');

            $wpdb->update($tbl_employees, [
                'payment_pref'      => $payment_pref,
                'bank_name'         => $bank_name,
                'bank_account_no'   => $bank_no,
                'bank_account_name' => $bank_holder,
                'phone'             => $phone
            ], ['id' => $emp_target_id]);

            $notice = '<div class="pk-alert pk-alert-success">✅ Pilihan pencairan gaji berhasil disimpan!</div>';
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error">❌ Gagal Simpan: ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 3. PROSES PENERBITAN SLIP GAJI OLEH ADMIN
if (!$is_preview && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_issue_payslip_action']) && $is_admin) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_payslip_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_issue_payslip')) {
        $notice = '<div class="pk-alert pk-alert-error">⚠️ Sesi keamanan habis.</div>';
    } else {
        try {
            $emp_id         = absint($_POST['employee_id'] ?? 0);
            $wage_ids       = array_filter(array_map('absint', (array)($_POST['wage_ids'] ?? [])));
            $slip_no        = sanitize_text_field($_POST['slip_no'] ?? (class_exists('PK01_Engine') ? PK01_Engine::document_number('payroll') : 'PAY-' . date('YmdHis')));
            $payment_method = sanitize_text_field($_POST['payment_method'] ?? 'Transfer Bank');

            if ($emp_id <= 0 || empty($wage_ids)) throw new Exception('Pilih minimal satu pekerjaan untuk dibuatkan slip.');

            $in_list = implode(',', $wage_ids);
            $wpdb->query($wpdb->prepare(
                "UPDATE `{$tbl_wages}` 
                 SET status = 'paid', paid_amount = amount, paid_at = %s, slip_no = %s, payment_method = %s 
                 WHERE id IN ($in_list) AND employee_id = %d",
                current_time('mysql'), $slip_no, $payment_method, $emp_id
            ));

            $notice = '<div class="pk-alert pk-alert-success">🧾 <strong>Slip Gaji ' . esc_html($slip_no) . '</strong> berhasil diterbitkan dan dikirim ke pekerja!</div>';
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error">❌ Gagal: ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 4. PROSES PENILAIAN RATING BINTANG
if (!$is_preview && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_job_admin_rate']) && $is_admin) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_job_rating_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_job_rating_action')) {
        $notice = '<div class="pk-alert pk-alert-error">⚠️ Sesi keamanan tidak valid.</div>';
    } else {
        try {
            $assignment_id = absint($_POST['assignment_id'] ?? 0);
            $rating        = max(1, min(5, absint($_POST['rating'] ?? 5)));
            $rating_notes  = sanitize_textarea_field(wp_unslash($_POST['rating_notes'] ?? ''));

            if ($assignment_id <= 0) throw new Exception('Pekerjaan tidak ditemukan.');

            $wpdb->update($tbl_assignments, [
                'rating'       => $rating,
                'rating_notes' => $rating_notes,
                'rated_by'     => $current_user->ID,
                'rated_at'     => current_time('mysql')
            ], ['id' => $assignment_id]);

            $notice = '<div class="pk-alert pk-alert-success">⭐ Penilaian mutu (' . $rating . ' Bintang) tersimpan.</div>';
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 5. PROSES AKSI PEKERJA (STATUS, SELESAI, BAHAN & LAPOR KENDALA)
if (!$is_preview && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_job_worker_action'])) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_job_worker_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_job_worker')) {
        $notice = '<div class="pk-alert pk-alert-error">⚠️ Sesi keamanan kedaluwarsa. Silakan refresh halaman.</div>';
    } else {
        try {
            $act = sanitize_key($_POST['pk01_job_worker_action']);
            if ($act === 'status') {
                PK01_Engine::update_job_worker_status((int)$_POST['assignment_id'], sanitize_key($_POST['status'] ?? ''), $_POST['notes'] ?? '');
                $notice = '<div class="pk-alert pk-alert-success">✅ Status pekerjaan berhasil diperbarui!</div>';
            } elseif ($act === 'complete') {
                $files = [];
                if (isset($_FILES['completion_photos']) && is_array($_FILES['completion_photos']['name'] ?? null)) {
                    foreach ($_FILES['completion_photos']['name'] as $i => $name) {
                        $files[] = [
                            'name'     => $name,
                            'type'     => $_FILES['completion_photos']['type'][$i] ?? '',
                            'tmp_name' => $_FILES['completion_photos']['tmp_name'][$i] ?? '',
                            'error'    => $_FILES['completion_photos']['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                            'size'     => $_FILES['completion_photos']['size'][$i] ?? 0
                        ];
                    }
                }
                PK01_Engine::complete_job_assignment((int)$_POST['assignment_id'], (float)$_POST['good_qty'], (float)$_POST['reject_qty'], $_POST['notes'] ?? '', $files);
                // Bila ada kendala aktif, otomatis di-clearkan saat selesai
                $wpdb->update($tbl_assignments, ['obstacle_status' => 'resolved', 'obstacle_resolved_at' => current_time('mysql')], ['id' => (int)$_POST['assignment_id']]);
                $notice = '<div class="pk-alert pk-alert-success">🎉 <strong>Tugas selesai dicatat!</strong> Hasil dan upah Anda telah dibukukan.</div>';
            } elseif ($act === 'report_obstacle') {
                // LOGIKA BARU: LAPOR KENDALA PRODUKSI DARI LAPANGAN
                $assign_id = absint($_POST['assignment_id'] ?? 0);
                $obs_type  = sanitize_text_field($_POST['obstacle_type'] ?? 'Lainnya');
                $obs_notes = sanitize_textarea_field($_POST['obstacle_notes'] ?? '');

                if ($assign_id <= 0) throw new Exception('ID Tugas tidak ditemukan.');

                $wpdb->update($tbl_assignments, [
                    'obstacle_type'        => $obs_type,
                    'obstacle_notes'       => $obs_notes,
                    'obstacle_status'      => 'reported',
                    'obstacle_reported_at' => current_time('mysql')
                ], ['id' => $assign_id]);

                $notice = '<div class="pk-alert pk-alert-error">⚠️ <strong>Laporan Kendala Terkirim!</strong> Mandor &amp; Pemberi Job telah menerima pemberitahuan kendala ini.</div>';
            } elseif ($act === 'edit_material') {
                PK01_Engine::edit_job_material_usage((int)$_POST['job_material_id'], (float)$_POST['used_qty'], (float)$_POST['return_qty'], $_POST['notes'] ?? '');
                $notice = '<div class="pk-alert pk-alert-success">✅ Data bahan berhasil diperbarui.</div>';
            } elseif ($act === 'usage') {
                PK01_Engine::record_job_material_usage((int)$_POST['job_material_id'], (float)$_POST['used_qty'], $_POST['notes'] ?? '');
                $notice = '<div class="pk-alert pk-alert-success">✅ Pemakaian bahan tersimpan.</div>';
            } elseif ($act === 'return_material') {
                PK01_Engine::return_job_material((int)$_POST['job_material_id'], (float)$_POST['return_qty'], $_POST['notes'] ?? '');
                $notice = '<div class="pk-alert pk-alert-success">✅ Sisa bahan berhasil dikembalikan ke stok gudang.</div>';
            }
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error">❌ Ada masalah: ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 6. PROSES AKSI ADMIN (PENUGASAN & SELESAIKAN KENDALA)
if (!$is_preview && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_job_admin_action']) && $is_admin) {
    $nonce = sanitize_text_field(wp_unslash($_POST['pk01_job_admin_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'pk01_job_admin')) {
        $notice = '<div class="pk-alert pk-alert-error">⚠️ Sesi keamanan admin habis.</div>';
    } else {
        try {
            $act = sanitize_key($_POST['pk01_job_admin_action']);
            if ($act === 'assign') {
                PK01_Engine::assign_job_employee((int)$_POST['job_id'], (int)$_POST['employee_id'], $_POST['notes'] ?? '');
                $notice = '<div class="pk-alert pk-alert-success">✅ Pekerjaan berhasil ditugaskan ke pekerja.</div>';
            } elseif ($act === 'resolve_obstacle') {
                // ADMIN MENYELESAIKAN KENDALA PEKERJA
                $assign_id = absint($_POST['assignment_id'] ?? 0);
                $wpdb->update($tbl_assignments, [
                    'obstacle_status'      => 'resolved',
                    'obstacle_resolved_at' => current_time('mysql')
                ], ['id' => $assign_id]);
                $notice = '<div class="pk-alert pk-alert-success">✅ <strong>Kendala Berhasil Ditandai Selesai!</strong> Pekerja dapat melanjutkan pengerjaan.</div>';
            } elseif ($act === 'issue') {
                PK01_Engine::issue_job_material((int)$_POST['job_id'], (int)$_POST['material_id'], (float)$_POST['qty'], $_POST['notes'] ?? '');
                $notice = '<div class="pk-alert pk-alert-success">✅ Bahan baku berhasil diserahkan ke Job.</div>';
            } elseif ($act === 'link_account') {
                $emp   = (int)$_POST['employee_id'];
                $wpuid = (int)$_POST['user_id'];
                $wpdb->update($tbl_employees, ['user_id' => $wpuid], ['id' => $emp]);
                $notice = '<div class="pk-alert pk-alert-success">✅ Akun login berhasil dihubungkan.</div>';
            }
        } catch (Throwable $e) {
            $notice = '<div class="pk-alert pk-alert-error">❌ ' . esc_html($e->getMessage()) . '</div>';
        }
    }
}

// 7. IDENTIFIKASI PROFIL PEKERJA
$myemp = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_employees}` WHERE user_id = %d AND status = 'active' LIMIT 1", $uid), ARRAY_A);

if (!$is_admin && !$myemp && !($is_preview && $is_superadmin)) {
    echo '<div style="max-width:440px;margin:30px auto;text-align:center;padding:28px 20px;background:#ffffff;border-radius:16px;border:1px solid #e2e8f0;font-family:sans-serif;">'
       . '<div style="font-size:48px;margin-bottom:10px;">⚠️</div>'
       . '<h3 style="margin:0 0 6px 0;color:#0f172a;">Akun Belum Dihubungkan</h3>'
       . '<p style="color:#64748b;font-size:13px;line-height:1.5;">Akun login <b>' . esc_html($current_user->user_login) . '</b> belum dipasangkan dengan profil karyawan. Hubungi mandor/kantor.</p>'
       . '</div>'; 
    return;
}

// Saat Administrator hanya melihat tampilan Dashboard Pekerja, gunakan satu
// profil karyawan aktif yang benar-benar ada sebagai konteks baca. Tidak membuat
// akun/data baru dan tidak mengubah akun login Administrator.
$target_emp_id = $myemp ? (int)$myemp['id'] : 0;
if ($is_preview && $is_superadmin && !$target_emp_id) {
    $target_emp_id = (int)$wpdb->get_var("SELECT id FROM `{$tbl_employees}` WHERE status = 'active' ORDER BY id ASC LIMIT 1");
}
if ($is_admin_view && isset($_GET['filter_emp_id']) && (int)$_GET['filter_emp_id'] > 0) {
    $target_emp_id = absint($_GET['filter_emp_id']);
}
$target_emp_data = $target_emp_id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$tbl_employees}` WHERE id = %d LIMIT 1", $target_emp_id), ARRAY_A) : null;

// 8. LOGIKA FILTER BULAN & TAHUN (ANTI TAHUN 0 & OTOMATIS TAHUN AKTIF)
$current_real_year = (int)current_time('Y');
$filter_year  = sanitize_text_field($_GET['filter_year'] ?? 'all');
$filter_month = sanitize_text_field($_GET['filter_month'] ?? 'all');

if ($filter_year !== 'all' && (int)$filter_year <= 0) {
    $filter_year = 'all';
}

$available_years = [];
if ($target_emp_id > 0) {
    $raw_years = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT YEAR(created_at) FROM `{$tbl_assignments}` 
         WHERE employee_id = %d 
           AND created_at IS NOT NULL 
           AND created_at != '0000-00-00 00:00:00' 
           AND YEAR(created_at) >= 2020 
         ORDER BY created_at DESC", 
        $target_emp_id
    )) ?: [];
    $available_years = array_filter(array_map('intval', $raw_years), function($y){return $y >= 2020;});
}

// Pastikan tahun berjalan selalu ada dan tidak pernah kosong/0
if (!in_array($current_real_year, $available_years, true)) {
    $available_years[] = $current_real_year;
}
rsort($available_years);

// 9. QUERY SELURUH KENDALA PRODUKSI AKTIF UNTUK MENU PEMBERI JOB (ADMIN NOTICE)
$active_obstacles = [];
if ($is_admin) {
    $active_obstacles = $wpdb->get_results("
        SELECT ja.id as assignment_id, ja.obstacle_type, ja.obstacle_notes, ja.obstacle_reported_at,
               j.job_no, p.name as product_name, e.name as employee_name, e.code as employee_code
        FROM `{$tbl_assignments}` ja
        JOIN `{$tbl_jobs}` j ON j.id = ja.job_id
        JOIN `{$tbl_employees}` e ON e.id = ja.employee_id
        LEFT JOIN `{$tbl_items}` ji ON ji.job_id = j.id
        LEFT JOIN `{$tbl_variants}` v ON v.id = ji.variant_id
        LEFT JOIN `{$tbl_products}` p ON p.id = v.product_id
        WHERE ja.obstacle_status = 'reported'
        ORDER BY ja.obstacle_reported_at DESC
    ", ARRAY_A) ?: [];
}

// 10. QUERY DATA PEKERJAAN BERDASARKAN PERIODE
$where_emp = ($is_admin_view || $is_preview) ? " WHERE 1=1 " : " WHERE ja.employee_id = " . (int)$target_emp_id;
if ($target_emp_id > 0 && ($is_admin_view || $is_preview)) {
    $where_emp = " WHERE ja.employee_id = " . (int)$target_emp_id;
}

$period_sql_filter = "";
if ($filter_year !== 'all' && is_numeric($filter_year) && (int)$filter_year > 0) {
    $period_sql_filter .= $wpdb->prepare(" AND YEAR(COALESCE(NULLIF(jcr.created_at, '0000-00-00 00:00:00'), NULLIF(ja.created_at, '0000-00-00 00:00:00'), NULLIF(j.production_date, '0000-00-00'), NOW())) = %d ", (int)$filter_year);
}
if ($filter_month !== 'all' && is_numeric($filter_month) && (int)$filter_month > 0) {
    $period_sql_filter .= $wpdb->prepare(" AND MONTH(COALESCE(NULLIF(jcr.created_at, '0000-00-00 00:00:00'), NULLIF(ja.created_at, '0000-00-00 00:00:00'), NULLIF(j.production_date, '0000-00-00'), NOW())) = %d ", (int)$filter_month);
}

$sql_all_jobs = "SELECT ja.*, j.job_no, j.location, j.production_date, j.deadline, j.status AS job_status, j.priority, j.instructions, j.spec_snapshot, 
                      e.name AS employee_name, e.code AS employee_code, ab.display_name AS assigned_by_name, ab.user_login AS assigned_by_login, ji.variant_id, ji.qty AS target_qty, v.sku, v.name AS variant_name, 
                      p.name AS product_name, p.image_id, p.product_length, p.product_width, p.product_height, p.product_thickness, 
                      p.dimension_unit, v.material, v.finishing AS variant_finishing, p.finishing AS product_finishing,
                      jcr.good_qty as result_good_qty, jcr.reject_qty as result_reject_qty, jcr.created_at as completed_date,
                      w.amount as wage_amount, w.status as wage_status, w.paid_amount, w.slip_no
               FROM `{$tbl_assignments}` ja 
               JOIN `{$tbl_jobs}` j ON j.id = ja.job_id 
               JOIN `{$tbl_employees}` e ON e.id = ja.employee_id 
               LEFT JOIN `{$tbl_completion}` jcr ON jcr.assignment_id = ja.id
               LEFT JOIN `{$wpdb->users}` ab ON ab.ID = ja.assigned_by
               LEFT JOIN `{$tbl_items}` ji ON ji.job_id = j.id 
               LEFT JOIN `{$tbl_variants}` v ON v.id = ji.variant_id 
               LEFT JOIN `{$tbl_products}` p ON p.id = v.product_id 
               LEFT JOIN `{$tbl_wages}` w ON (w.job_id = ja.job_id AND w.employee_id = ja.employee_id)
               {$where_emp} {$period_sql_filter}
               ORDER BY FIELD(ja.status,'in_progress','accepted','assigned','completed'), ja.id DESC LIMIT 100";
$all_jobs = $wpdb->get_results($sql_all_jobs, ARRAY_A) ?: [];

// KALKULASI STATISTIK PERIODE
$cnt_total    = count($all_jobs);
$cnt_new      = 0;
$cnt_progress = 0;
$cnt_done     = 0;
$cnt_obstacle = 0;

$period_wages_paid    = 0;
$period_wages_pending = 0;
$period_units_made    = 0;

$ontime_jobs_count = 0;
$rating_sum        = 0;
$rated_count       = 0;

foreach ($all_jobs as $jb) {
    $st = sanitize_key($jb['status'] ?? '');
    if (($jb['obstacle_status'] ?? '') === 'reported') {
        $cnt_obstacle++;
    }

    if ($st === 'assigned') {
        $cnt_new++;
    } elseif ($st === 'accepted' || $st === 'in_progress') {
        $cnt_progress++;
    } elseif ($st === 'completed') {
        $cnt_done++;
        
        // Track Kecepatan
        $is_ontime = true;
        if (!empty($jb['deadline']) && !empty($jb['completed_date'])) {
            if (strtotime($jb['completed_date']) > strtotime($jb['deadline'] . ' 23:59:59')) {
                $is_ontime = false;
            }
        }
        if ($is_ontime) $ontime_jobs_count++;

        // Rating QC
        $r_val = (int)($jb['rating'] ?? 0);
        if ($r_val > 0) {
            $rating_sum += $r_val;
            $rated_count++;
        }
    }

    $w_amt = (float)($jb['wage_amount'] ?? 0);
    if (($jb['wage_status'] ?? '') === 'paid') {
        $period_wages_paid += $w_amt;
    } else {
        $period_wages_pending += $w_amt;
    }
    $period_units_made += (float)($jb['result_good_qty'] ?? 0);
}

$speed_percent = ($cnt_done > 0) ? round(($ontime_jobs_count / $cnt_done) * 100) : 100;
$avg_rating    = ($rated_count > 0) ? round($rating_sum / $rated_count, 1) : 0;

// Data Slip Gaji
$paid_wages_raw = $wpdb->get_results($wpdb->prepare("
    SELECT w.id as wage_id, w.amount, w.status, w.paid_amount, w.paid_at, w.slip_no, w.payment_method, w.created_at,
           j.job_no, p.name AS product_name, v.name AS variant_name, v.sku,
           jcr.good_qty, jcr.reject_qty, ja.rating
    FROM `{$tbl_wages}` w
    JOIN `{$tbl_jobs}` j ON j.id = w.job_id
    JOIN `{$tbl_assignments}` ja ON (ja.job_id = w.job_id AND ja.employee_id = w.employee_id)
    LEFT JOIN `{$tbl_completion}` jcr ON jcr.assignment_id = ja.id
    LEFT JOIN `{$tbl_items}` ji ON ji.job_id = j.id
    LEFT JOIN `{$tbl_variants}` v ON v.id = ji.variant_id
    LEFT JOIN `{$tbl_products}` p ON p.id = v.product_id
    WHERE w.employee_id = %d AND w.status = 'paid'
    ORDER BY COALESCE(w.paid_at, w.created_at) DESC
", $target_emp_id), ARRAY_A) ?: [];

$grouped_slips = [];
foreach ($paid_wages_raw as $pw) {
    $s_no = !empty($pw['slip_no']) ? $pw['slip_no'] : 'SLIP-' . date('Ym', strtotime($pw['paid_at'] ?: $pw['created_at'])) . '-' . $pw['wage_id'];
    if (!isset($grouped_slips[$s_no])) {
        $grouped_slips[$s_no] = [
            'slip_no'        => $s_no,
            'wage_id'        => (int)$pw['wage_id'],
            'paid_at'        => $pw['paid_at'] ?: $pw['created_at'],
            'payment_method' => $pw['payment_method'] ?: 'Transfer Bank',
            'total_amount'   => 0,
            'jobs'           => []
        ];
    }
    $grouped_slips[$s_no]['total_amount'] += (float)$pw['amount'];
    $grouped_slips[$s_no]['jobs'][]        = $pw;
}

$employees = $is_admin_view ? $wpdb->get_results("SELECT id, code, name FROM `{$tbl_employees}` WHERE status = 'active' ORDER BY name", ARRAY_A) : [];
$month_names = [
    '01'=>'Januari', '02'=>'Februari', '03'=>'Maret', '04'=>'April',
    '05'=>'Mei', '06'=>'Juni', '07'=>'Juli', '08'=>'Agustus',
    '09'=>'September', '10'=>'Oktober', '11'=>'November', '12'=>'Desember'
];
?>

<style>
.pk-worker-app {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    max-width: 760px;
    margin: 10px auto 40px;
    color: #1e293b;
    padding: 0 12px;
}
.pk-worker-app * { box-sizing: border-box; }

.pk-alert {
    padding: 14px 16px;
    border-radius: 12px;
    font-size: 14px;
    font-weight: 700;
    margin-bottom: 16px;
}
.pk-alert-success { background: #dcfce7; color: #15803d; border: 1px solid #86efac; }
.pk-alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

/* NOTIFIKASI KENDALA MENDESAK UNTUK PEMBERI JOB (ADMIN) */
.pk-admin-obstacle-banner {
    background: #fef2f2;
    border: 2px solid #ef4444;
    border-radius: 16px;
    padding: 16px 18px;
    margin-bottom: 20px;
    box-shadow: 0 10px 25px -5px rgba(239, 68, 68, 0.2);
}
.pk-obs-item {
    background: #ffffff;
    border: 1px solid #fecaca;
    border-radius: 10px;
    padding: 12px;
    margin-top: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.pk-app-header {
    background: #0f172a;
    color: #ffffff;
    border-radius: 18px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 4px 14px rgba(15, 23, 42, 0.15);
}
.pk-app-header-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
}
.pk-user-greet { display: flex; align-items: center; gap: 12px; }
.pk-avatar-circle {
    width: 46px;
    height: 46px;
    background: #2563eb;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    font-weight: bold;
}
.pk-user-info h2 { margin: 0; font-size: 18px; font-weight: 800; color: #fff; }
.pk-user-info span { font-size: 12px; color: #94a3b8; }

.pk-period-filter-card {
    background: #ffffff;
    border: 2px solid #e2e8f0;
    border-radius: 14px;
    padding: 14px;
    margin-bottom: 14px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.03);
}
.pk-period-form {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap;
}
.pk-period-form select {
    padding: 8px 12px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    font-size: 13px;
    font-weight: bold;
    background: #f8fafc;
    flex: 1;
}
.pk-period-form button {
    padding: 8px 16px;
    background: #0f172a;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    font-size: 13px;
    cursor: pointer;
}

.pk-kpi-quad {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 16px;
}
.pk-kpi-quad-box {
    background: #ffffff;
    border: 2px solid #e2e8f0;
    border-radius: 14px;
    padding: 14px;
    border-left: 5px solid #cbd5e1;
}
.pk-kpi-quad-box small { display: block; font-size: 11px; font-weight: 800; text-transform: uppercase; color: #64748b; margin-bottom: 4px; }
.pk-kpi-quad-box strong { display: block; font-size: 20px; font-weight: 900; color: #0f172a; line-height: 1.1; }
.pk-kpi-quad-box span { display: block; font-size: 11px; color: #64748b; margin-top: 4px; }

.box-wages { border-left-color: #16a34a; background: #f0fdf4; }
.box-jobs  { border-left-color: #2563eb; }
.box-speed { border-left-color: #d97706; background: #fffdf5; }
.box-qc    { border-left-color: #7c3aed; }

/* STATUS BOARD 4 PILAR */
.pk-job-status-board {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
    margin-bottom: 16px;
}
@media (max-width: 480px) {
    .pk-job-status-board { grid-template-columns: repeat(2, 1fr); }
}
.pk-status-kpi-card {
    background: #ffffff;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    padding: 10px 8px;
    text-align: center;
    cursor: pointer;
    transition: all 0.15s;
}
.pk-status-kpi-card.is-active {
    border-color: #0f172a;
    background: #f8fafc;
    box-shadow: 0 4px 8px rgba(0,0,0,0.06);
}
.pk-status-kpi-card small { display: block; font-size: 10px; font-weight: 800; text-transform: uppercase; color: #64748b; }
.pk-status-kpi-card strong { display: block; font-size: 18px; font-weight: 900; color: #0f172a; margin-top: 2px; }

.pk-tab-nav {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 6px;
    margin-bottom: 18px;
    background: #e2e8f0;
    padding: 6px;
    border-radius: 14px;
}
.pk-tab-btn {
    padding: 12px 6px;
    border: none;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 800;
    cursor: pointer;
    background: transparent;
    color: #475569;
    text-align: center;
}
.pk-tab-btn.active {
    background: #ffffff;
    color: #0f172a;
    box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}

/* KARTU PEKERJAAN */
.pk-job-card-simple {
    background: #ffffff;
    border: 2px solid #e2e8f0;
    border-radius: 16px;
    padding: 18px;
    margin-bottom: 18px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.03);
    position: relative;
}
.pk-job-card-simple.has-obstacle {
    border-color: #ef4444 !important;
    background: #fffdfd;
}

.pk-speed-track-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    font-weight: 800;
    padding: 4px 8px;
    border-radius: 6px;
    margin-top: 4px;
}
.speed-badge-green  { background: #dcfce7; color: #15803d; }
.speed-badge-yellow { background: #fef3c7; color: #92400e; }
.speed-badge-red    { background: #fee2e2; color: #991b1b; }

.pk-btn-jumbo {
    display: block;
    width: 100%;
    padding: 15px;
    font-size: 15px;
    font-weight: 800;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    text-align: center;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
}
.pk-btn-jumbo-blue   { background: #2563eb; color: #fff; }
.pk-btn-jumbo-purple { background: #7c3aed; color: #fff; }
.pk-btn-jumbo-green  { background: #16a34a; color: #fff; }

.pk-slip-receipt {
    background: #ffffff;
    border: 1px dashed #94a3b8;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.pk-modal {
    display: none;
    position: fixed;
    z-index: 99999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.7);
    overflow-y: auto;
    padding: 16px;
}
.pk-modal-content {
    background: #fff;
    margin: 20px auto;
    padding: 24px;
    border-radius: 14px;
    max-width: 580px;
    font-family: monospace, sans-serif;
}
@media print {
    body * { visibility: hidden !important; }
    .pk-modal, .pk-modal-content, .pk-modal-content * { visibility: visible !important; }
    .pk-modal { position: absolute; left: 0; top: 0; width: 100%; background: #fff !important; padding: 0 !important; }
    .no-print { display: none !important; }
}
</style>

<div class="pk-worker-app">

    <!-- 1. NOTIFIKASI KENDALA MENDESAK KHUSUS UNTUK MENU PEMBERI JOB (ADMIN) -->
    <?php if ($is_admin && !empty($active_obstacles)): ?>
    <section class="pk-admin-obstacle-banner">
        <div style="display:flex;align-items:center;gap:8px;">
            <span style="font-size:24px;">🚨</span>
            <div>
                <strong style="color:#991b1b;font-size:15px;display:block;">PERHATIAN PEMBERI JOB: KENDALA PRODUKSI DILAPORKAN!</strong>
                <span style="color:#b91c1c;font-size:12px;">Ada <?php echo count($active_obstacles); ?> pekerjaan yang sedang macet di bengkel dan butuh tindakan kantor:</span>
            </div>
        </div>

        <div style="margin-top:10px;">
            <?php foreach ($active_obstacles as $obs): ?>
            <div class="pk-obs-item">
                <div>
                    <span style="font-family:monospace;font-weight:bold;background:#fee2e2;color:#991b1b;padding:2px 6px;border-radius:4px;font-size:11px;">
                        <?php echo esc_html($obs['job_no']); ?>
                    </span>
                    <strong style="margin-left:6px;font-size:13px;color:#0f172a;"><?php echo esc_html($obs['product_name']); ?></strong>
                    <div style="font-size:12px;color:#b91c1c;margin-top:4px;">
                        ⚠️ <b>Kendala: <?php echo esc_html($obs['obstacle_type']); ?></b> &bull; Dilaporkan oleh: <b><?php echo esc_html($obs['employee_name']); ?></b>
                        <?php if (!empty($obs['obstacle_notes'])): ?>
                            <div style="font-style:italic;color:#475569;margin-top:2px;">"<?php echo esc_html($obs['obstacle_notes']); ?>"</div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Tombol Selesaikan Kendala oleh Admin -->
                <form method="post" style="margin:0;">
                    <?php echo wp_nonce_field('pk01_job_admin', 'pk01_job_admin_nonce', true, false); ?>
                    <input type="hidden" name="pk01_job_admin_action" value="resolve_obstacle">
                    <input type="hidden" name="assignment_id" value="<?php echo (int)$obs['assignment_id']; ?>">
                    <button type="submit" style="background:#16a34a;color:#fff;border:none;padding:7px 12px;border-radius:6px;font-weight:bold;font-size:11px;cursor:pointer;">
                        ✓ Selesaikan Kendala Ini
                    </button>
                </form>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- 2. HEADER PROFIL PEKERJA -->
    <header class="pk-app-header">
        <div class="pk-app-header-top">
            <div class="pk-user-greet">
                <div class="pk-avatar-circle">
                    <?php echo esc_html(strtoupper(substr($target_emp_data['name'] ?? 'T', 0, 1))); ?>
                </div>
                <div class="pk-user-info">
                    <h2><?php echo esc_html($target_emp_data['name'] ?? 'Pekerja'); ?></h2>
                    <span>Kode: <b><?php echo esc_html($target_emp_data['code'] ?? 'KRY-01'); ?></b></span>
                </div>
            </div>

            <?php if ($is_admin && !empty($employees)): ?>
                <form method="get" style="margin:0;">
                    <input type="hidden" name="pk01_view" value="<?php echo esc_attr($_GET['pk01_view'] ?? 'job_karyawan'); ?>">
                    <select name="filter_emp_id" onchange="this.form.submit()" style="padding:6px 8px;border-radius:8px;font-size:12px;font-weight:bold;">
                        <?php foreach ($employees as $e): ?>
                            <option value="<?php echo (int)$e['id']; ?>" <?php selected($target_emp_id, (int)$e['id']); ?>>
                                👤 <?php echo esc_html($e['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            <?php endif; ?>
        </div>
    </header>

    <?php echo $notice; ?>

    <!-- 3. KOTAK FILTER BULAN & TAHUN (ANTI TAHUN 0) -->
    <div class="pk-period-filter-card">
        <form method="get" class="pk-period-form">
            <input type="hidden" name="pk01_view" value="<?php echo esc_attr($_GET['pk01_view'] ?? 'job_karyawan'); ?>">
            <?php if ($is_admin && $target_emp_id > 0): ?>
                <input type="hidden" name="filter_emp_id" value="<?php echo (int)$target_emp_id; ?>">
            <?php endif; ?>

            <select name="filter_month">
                <option value="all" <?php selected($filter_month, 'all'); ?>>— Semua Bulan —</option>
                <?php foreach ($month_names as $m_code => $m_title): ?>
                    <option value="<?php echo esc_attr($m_code); ?>" <?php selected($filter_month, $m_code); ?>>
                        Bulan <?php echo esc_html($m_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="filter_year">
                <option value="all" <?php selected($filter_year, 'all'); ?>>— Semua Tahun —</option>
                <?php foreach ($available_years as $yr): if ((int)$yr <= 0) continue; ?>
                    <option value="<?php echo (int)$yr; ?>" <?php selected((string)$filter_year, (string)$yr); ?>>
                        Tahun <?php echo (int)$yr; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">🔍 Cek Rekap</button>
        </form>
    </div>

    <!-- 4. RAPOR KINERJA & GAJI BULANAN/TAHUNAN -->
    <div class="pk-kpi-quad">
        <div class="pk-kpi-quad-box box-wages">
            <small>💵 Gaji Diterima (Periode Ini)</small>
            <strong style="color:#16a34a;">Rp <?php echo number_format($period_wages_paid, 0, ',', '.'); ?></strong>
            <span>Menunggu Cair: Rp <?php echo number_format($period_wages_pending, 0, ',', '.'); ?></span>
        </div>

        <div class="pk-kpi-quad-box box-jobs">
            <small>📦 Total Pekerjaan Diterima</small>
            <strong style="color:#2563eb;"><?php echo (int)$cnt_total; ?> SPK</strong>
            <span><?php echo (int)$cnt_done; ?> Selesai &bull; <?php echo (int)$cnt_progress; ?> Dalam Proses</span>
        </div>

        <div class="pk-kpi-quad-box box-speed">
            <small>⏱️ Kecepatan Kerja</small>
            <strong style="color:#d97706;"><?php echo $speed_percent; ?>% Tepat Waktu</strong>
            <span><?php echo (int)$ontime_jobs_count; ?> dari <?php echo (int)$cnt_done; ?> SPK tuntas sebelum deadline</span>
        </div>

        <div class="pk-kpi-quad-box box-qc">
            <small>⭐ Mutu Hasil (QC)</small>
            <strong style="color:#7c3aed;"><?php echo ($avg_rating > 0) ? $avg_rating . ' / 5.0' : '—'; ?></strong>
            <span><?php echo number_format($period_units_made); ?> Unit mebel lolos QC</span>
        </div>
    </div>

    <!-- 5. KOTAK FILTER STATUS INSTAN -->
    <div class="pk-job-status-board">
        <div class="pk-status-kpi-card is-active" onclick="filterJobStatus('all', this)">
            <small>Semua Job</small>
            <strong style="color:#2563eb;"><?php echo (int)$cnt_total; ?></strong>
        </div>
        <div class="pk-status-kpi-card" onclick="filterJobStatus('assigned', this)">
            <small>Job Baru</small>
            <strong style="color:#0ea5e9;"><?php echo (int)$cnt_new; ?></strong>
        </div>
        <div class="pk-status-kpi-card" onclick="filterJobStatus('progress', this)">
            <small>Dalam Proses</small>
            <strong style="color:#d97706;"><?php echo (int)$cnt_progress; ?></strong>
        </div>
        <div class="pk-status-kpi-card" onclick="filterJobStatus('completed', this)">
            <small>Selesai</small>
            <strong style="color:#16a34a;"><?php echo (int)$cnt_done; ?></strong>
        </div>
    </div>

    <!-- 6. NAVIGASI 3 TAB MENU UTAMA -->
    <div class="pk-tab-nav">
        <button type="button" class="pk-tab-btn active" onclick="switchWorkerTab('tab-job', this)">
            🔨 Pekerjaan &amp; Track (<?php echo (int)$cnt_total; ?>)
        </button>
        <button type="button" class="pk-tab-btn" onclick="switchWorkerTab('tab-slip', this)">
            💵 Slip Gaji (<?php echo count($grouped_slips); ?>)
        </button>
        <button type="button" class="pk-tab-btn" onclick="switchWorkerTab('tab-profile', this)">
            👤 Rekening Saya
        </button>
    </div>

    <!-- =======================================================
         TAB 1: DAFTAR SEMUA JOB DENGAN FITUR LAPOR KENDALA
         ======================================================= -->
    <div id="tab-job" class="pk-worker-tab-content">
        <?php if (empty($all_jobs)): ?>
            <div style="text-align:center;padding:40px 20px;background:#ffffff;border-radius:16px;border:2px dashed #cbd5e1;">
                <div style="font-size:48px;margin-bottom:8px;">☕</div>
                <h3 style="margin:0 0 6px 0;color:#0f172a;">Tidak Ada Job Pada Periode Ini</h3>
                <p style="font-size:13px;color:#64748b;margin:0;">Pilih bulan dan tahun di atas atau buat SPK baru.</p>
            </div>
        <?php else: ?>
            <div id="pk-job-list-wrapper">
                <?php foreach ($all_jobs as $a): 
                    $img = $a['image_id'] ? wp_get_attachment_image_url((int)$a['image_id'], 'medium') : '';
                    $status = sanitize_key($a['status']);
                    $filter_category = ($status === 'assigned') ? 'assigned' : (($status === 'completed') ? 'completed' : 'progress');
                    $has_obstacle = (($a['obstacle_status'] ?? '') === 'reported');
                    $worker_role = sanitize_key($a['role_code'] ?? '');
                    $worker_role_label = $worker_role === 'cnc' ? 'OPERATOR CNC' : ($worker_role === 'prema' ? 'PREMA / FINISHING' : strtoupper(str_replace('_',' ',$worker_role ?: 'PEKERJA')));
                    $worker_cnc_master = null;
                    if ($worker_role === 'cnc' && class_exists('PK01_CNC_Library')) {
                        try {
                            $worker_snap = json_decode((string)($a['spec_snapshot'] ?? ''), true);
                            if (!is_array($worker_snap)) $worker_snap = [];
                            $worker_cnc_master = PK01_CNC_Library::best_match((int)($worker_snap['product_id'] ?? 0), (int)($a['variant_id'] ?? 0), (string)($a['material'] ?? ($worker_snap['material'] ?? '')));
                        } catch (Throwable $e) { $worker_cnc_master = null; }
                    }

                    // SPEED TRACKER PER SPK
                    $speed_badge_html = '';
                    if (!empty($a['deadline'])) {
                        if ($status === 'completed' && !empty($a['completed_date'])) {
                            $ddl_ts = strtotime($a['deadline'] . ' 23:59:59');
                            $cmp_ts = strtotime($a['completed_date']);
                            if ($cmp_ts <= $ddl_ts) {
                                $speed_badge_html = '<span class="pk-speed-track-badge speed-badge-green">⚡ Selesai Tepat Waktu</span>';
                            } else {
                                $telat_hari = max(1, round(($cmp_ts - $ddl_ts) / 86400));
                                $speed_badge_html = '<span class="pk-speed-track-badge speed-badge-red">⚠️ Selesai (Telat ' . $telat_hari . ' Hari)</span>';
                            }
                        } elseif ($status !== 'completed') {
                            $now_ts = current_time('timestamp');
                            $ddl_ts = strtotime($a['deadline'] . ' 23:59:59');
                            $sisa_hari = round(($ddl_ts - $now_ts) / 86400);

                            if ($sisa_hari < 0) {
                                $speed_badge_html = '<span class="pk-speed-track-badge speed-badge-red">🚨 Terlambat ' . abs($sisa_hari) . ' Hari!</span>';
                            } elseif ($sisa_hari == 0) {
                                $speed_badge_html = '<span class="pk-speed-track-badge speed-badge-yellow">⏱️ Deadline Hari Ini!</span>';
                            } else {
                                $speed_badge_html = '<span class="pk-speed-track-badge speed-badge-green">⏱️ Sisa ' . $sisa_hari . ' Hari Lagi</span>';
                            }
                        }
                    }
                ?>
                <article class="pk-job-card-simple <?php echo $has_obstacle ? 'has-obstacle' : ''; ?>" data-status="<?php echo esc_attr($filter_category); ?>">
                    
                    <!-- INDIKATOR KENDALA AKTIF (JIKA ADA) -->
                    <?php if ($has_obstacle): ?>
                    <div style="background:#fee2e2;border:1px solid #f87171;border-radius:8px;padding:8px 12px;margin-bottom:12px;font-size:12px;color:#991b1b;">
                        <strong>⚠️ PRODUKSI TERKENDALA: <?php echo esc_html($a['obstacle_type']); ?></strong>
                        <div style="margin-top:2px;">Catatan: <em>"<?php echo esc_html($a['obstacle_notes'] ?: 'Tidak ada catatan'); ?>"</em></div>
                        <small style="color:#7f1d1d;display:block;margin-top:4px;">Pemberitahuan telah terkirim ke Mandor/Pemberi Job.</small>
                    </div>
                    <?php endif; ?>

                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                        <span style="font-family:monospace;font-size:13px;font-weight:800;background:#f1f5f9;padding:4px 8px;border-radius:6px;">
                            <?php echo esc_html($a['job_no']); ?>
                        </span>
                        <div>
                            <?php if ($status === 'assigned'): ?>
                                <span style="font-size:11px;font-weight:800;background:#eff6ff;color:#1d4ed8;padding:4px 8px;border-radius:20px;">🆕 Job Baru</span>
                            <?php elseif ($status === 'accepted' || $status === 'in_progress'): ?>
                                <span style="font-size:11px;font-weight:800;background:#fffbeb;color:#b45309;padding:4px 8px;border-radius:20px;">⚙️ Dalam Proses</span>
                            <?php else: ?>
                                <span style="font-size:11px;font-weight:800;background:#dcfce7;color:#15803d;padding:4px 8px;border-radius:20px;">✅ Selesai</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div style="margin:-2px 0 12px;padding:9px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:9px;font-size:12px;color:#1e3a8a;">
                        <strong>📨 Pemberi Job:</strong> <?php echo esc_html($a['assigned_by_name'] ?: ($a['assigned_by_login'] ?: 'Admin/Kasir')); ?>
                        <span style="margin-left:10px"><strong>Tahap:</strong> <?php echo esc_html($worker_role_label); ?></span>
                        <span style="margin-left:10px"><strong>Status:</strong> <?php echo esc_html($a['status']); ?></span>
                    </div>
                    <?php if ($worker_role === 'cnc'): ?>
                        <div style="margin-bottom:12px;padding:12px;background:<?php echo $worker_cnc_master ? '#f0fdf4' : '#fef2f2'; ?>;border:1px solid <?php echo $worker_cnc_master ? '#86efac' : '#fca5a5'; ?>;border-radius:10px;font-size:12px;">
                            <strong>⚙️ INSTRUKSI CNC</strong>
                            <?php if ($worker_cnc_master): ?>
                                <div style="margin-top:5px"><b><?php echo esc_html($worker_cnc_master['name']); ?></b> · <?php echo esc_html($worker_cnc_master['code']); ?> · v<?php echo esc_html($worker_cnc_master['version']); ?></div>
                                <div>Ukuran: <b><?php echo esc_html($worker_cnc_master['width'].' × '.$worker_cnc_master['height'].' mm'); ?></b> · Depth: <?php echo esc_html($worker_cnc_master['depth'].' mm'); ?> · Material: <?php echo esc_html($worker_cnc_master['material'] ?: 'Umum'); ?></div>
                                <a class="pk-op-button pk-op-button-small" style="display:inline-block;margin-top:7px" href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action'=>'pk01_cnc_library_download','id'=>(int)$worker_cnc_master['id']],admin_url('admin-post.php')),'pk01_cnc_library_download')); ?>">⬇ Ambil G-code Master</a>
                                <div style="margin-top:5px;color:#166534">Berikan file ini secara manual ke komputer CNC. PK01 tidak menjalankan mesin otomatis.</div>
                            <?php else: ?>
                                <div style="margin-top:5px;color:#991b1b;font-weight:700">Master G-code yang sesuai belum tersedia. Jangan menggunakan file produk lain.</div>
                            <?php endif; ?>
                        </div>
                    <?php elseif ($worker_role === 'prema'): ?>
                        <div style="margin-bottom:12px;padding:10px 12px;background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;font-size:12px;color:#9a3412;"><strong>🎨 PREMA / FINISHING</strong><div style="margin-top:3px">Jika Job memiliki tahap CNC, tombol mulai akan aktif setelah operator CNC menyelesaikan tahap CNC.</div></div>
                    <?php endif; ?>

                    <div style="display:flex;gap:12px;align-items:flex-start;margin-bottom:12px;">
                        <?php if ($img): ?>
                            <img src="<?php echo esc_url($img); ?>" alt="" style="width:75px;height:75px;border-radius:10px;object-fit:cover;border:1px solid #e2e8f0;flex-shrink:0;">
                        <?php else: ?>
                            <div style="width:75px;height:75px;border-radius:10px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0;">🪑</div>
                        <?php endif; ?>
                        <div>
                            <h3 style="margin:0 0 2px 0;font-size:16px;font-weight:800;color:#0f172a;line-height:1.3;">
                                <?php echo esc_html($a['product_name'] ?: $a['variant_name']); ?>
                            </h3>
                            <div style="font-size:13px;color:#2563eb;font-weight:bold;">
                                Target: <?php echo esc_html(rtrim(rtrim((string)$a['target_qty'], '0'), '.')); ?> Unit
                            </div>
                            <div><?php echo $speed_badge_html; ?></div>
                        </div>
                    </div>

                    <div style="display:flex;justify-content:space-between;align-items:center;background:#f8fafc;padding:8px 12px;border-radius:8px;border:1px solid #e2e8f0;font-size:12px;margin-bottom:12px;">
                        <span>Upah SPK Ini:</span>
                        <strong style="color:#0f172a;">Rp <?php echo number_format((float)($a['wage_amount'] ?? 0), 0, ',', '.'); ?></strong>
                    </div>

                    <!-- TOMBOL AKSI KERJA & LAPOR KENDALA -->
                    <?php if (!$is_preview && $status === 'assigned'): ?>
                        <form method="post" style="margin:0;">
                            <?php echo wp_nonce_field('pk01_job_worker', 'pk01_job_worker_nonce', true, false); ?>
                            <input type="hidden" name="pk01_job_worker_action" value="status">
                            <input type="hidden" name="assignment_id" value="<?php echo (int)$a['id']; ?>">
                            <input type="hidden" name="status" value="accepted">
                            <button type="submit" class="pk-btn-jumbo pk-btn-jumbo-blue">👉 TERIMA JOB INI</button>
                        </form>
                    <?php elseif (!$is_preview && $status === 'accepted'): ?>
                        <form method="post" style="margin:0;">
                            <?php echo wp_nonce_field('pk01_job_worker', 'pk01_job_worker_nonce', true, false); ?>
                            <input type="hidden" name="pk01_job_worker_action" value="status">
                            <input type="hidden" name="assignment_id" value="<?php echo (int)$a['id']; ?>">
                            <input type="hidden" name="status" value="in_progress">
                            <button type="submit" class="pk-btn-jumbo pk-btn-jumbo-purple">▶️ MULAI KERJAKAN SEKARANG</button>
                        </form>
                    <?php elseif (!$is_preview && $status === 'in_progress'): ?>
                        <div style="background:#f0fdf4;border:2px solid #86efac;border-radius:12px;padding:12px;margin-bottom:10px;">
                            <div style="font-size:13px;font-weight:bold;color:#166534;margin-bottom:8px;">🏁 Lapor Selesai &amp; Buktikan Foto:</div>
                            <form method="post" enctype="multipart/form-data" style="margin:0;">
                                <?php echo wp_nonce_field('pk01_job_worker', 'pk01_job_worker_nonce', true, false); ?>
                                <input type="hidden" name="pk01_job_worker_action" value="complete">
                                <input type="hidden" name="assignment_id" value="<?php echo (int)$a['id']; ?>">
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
                                    <input type="number" step="0.001" min="0" name="good_qty" value="<?php echo esc_attr($a['target_qty']); ?>" placeholder="Unit Jadi" style="padding:10px;font-weight:bold;font-size:15px;border-radius:8px;border:1px solid #cbd5e1;text-align:center;" required>
                                    <input type="number" step="0.001" min="0" name="reject_qty" value="0" placeholder="Reject" style="padding:10px;font-weight:bold;font-size:15px;border-radius:8px;border:1px solid #cbd5e1;text-align:center;">
                                </div>
                                <input type="file" name="completion_photos[]" accept="image/*" multiple style="font-size:12px;width:100%;margin-bottom:10px;">
                                <button type="submit" class="pk-btn-jumbo pk-btn-jumbo-green">✅ SIMPAN LAPORAN SELESAI</button>
                            </form>
                        </div>

                        <!-- MODUL LAPOR KENDALA UNTUK PEKERJA -->
                        <details style="background:#fef2f2;border:1px dashed #ef4444;border-radius:10px;padding:10px;">
                            <summary style="font-size:12px;font-weight:bold;color:#991b1b;cursor:pointer;">
                                ⚠️ Laporkan Kendala / Masalah Kerja (Penyebab Telat)
                            </summary>
                            <form method="post" style="margin-top:10px;">
                                <?php echo wp_nonce_field('pk01_job_worker', 'pk01_job_worker_nonce', true, false); ?>
                                <input type="hidden" name="pk01_job_worker_action" value="report_obstacle">
                                <input type="hidden" name="assignment_id" value="<?php echo (int)$a['id']; ?>">
                                
                                <div style="margin-bottom:8px;">
                                    <label style="display:block;font-size:11px;font-weight:bold;color:#991b1b;margin-bottom:3px;">Pilih Jenis Masalah:</label>
                                    <select name="obstacle_type" style="width:100%;padding:8px;border-radius:6px;border:1px solid #cbd5e1;font-size:12px;font-weight:bold;" required>
                                        <option value="Bahan Baku Kurang / Habis">Bahan Baku Kurang / Habis</option>
                                        <option value="Mesin / Alat Rusak">Mesin / Alat Rusak</option>
                                        <option value="Ukuran Gambar / Desain Tidak Jelas">Ukuran Gambar / Desain Tidak Jelas</option>
                                        <option value="Listrik Padam / Kendala Bengkel">Listrik Padam / Kendala Bengkel</option>
                                        <option value="Karyawan Sakit / Kurang Tenaga">Karyawan Sakit / Kurang Tenaga</option>
                                        <option value="Lainnya">Kendala Lainnya</option>
                                    </select>
                                </div>
                                <div style="margin-bottom:8px;">
                                    <textarea name="obstacle_notes" rows="2" placeholder="Tuliskan keterangan kendala lebih detail..." style="width:100%;padding:8px;border-radius:6px;border:1px solid #cbd5e1;font-size:12px;"></textarea>
                                </div>
                                <button type="submit" style="width:100%;background:#ef4444;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:bold;font-size:12px;cursor:pointer;">
                                    🚨 Kirim Laporan Kendala ke Mandor/Pemberi Job
                                </button>
                            </form>
                        </details>
                    <?php else: ?>
                        <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:8px;padding:10px;text-align:center;color:#166534;font-size:12px;font-weight:bold;">
                            ✓ Selesai &bull; Hasil Jadi: <?php echo (float)$a['result_good_qty']; ?> Unit
                        </div>
                    <?php endif; ?>
                </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- =======================================================
         TAB 2: SLIP GAJI SAYA
         ======================================================= -->
    <div id="tab-slip" class="pk-worker-tab-content" style="display:none;">
        <?php if (empty($grouped_slips)): ?>
            <div style="text-align:center;padding:40px 20px;background:#ffffff;border-radius:16px;border:2px dashed #cbd5e1;">
                <div style="font-size:48px;margin-bottom:8px;">🧾</div>
                <h3 style="margin:0 0 6px 0;color:#0f172a;">Belum Ada Slip Gaji Diterbitkan</h3>
                <p style="font-size:13px;color:#64748b;margin:0;">Slip resmi akan muncul begitu kasir mentransfer upah Anda.</p>
            </div>
        <?php else: ?>
            <?php $counter = 0; foreach ($grouped_slips as $slip): $counter++; ?>
            <div class="pk-slip-receipt">
                <div style="text-align:center;border-bottom:1px dashed #cbd5e1;padding-bottom:12px;margin-bottom:12px;">
                    <h3 style="margin:0;font-size:16px;">BUKTI PEMBAYARAN GAJI</h3>
                    <div style="font-size:12px;font-family:monospace;color:#64748b;">No: <b><?php echo esc_html($slip['slip_no']); ?></b></div>
                    <div style="display:inline-block;background:#dcfce7;color:#15803d;font-size:11px;font-weight:800;padding:4px 10px;border-radius:6px;margin-top:6px;">
                        ✓ LUNAS PADA <?php echo esc_html(date('d/m/Y', strtotime($slip['paid_at']))); ?>
                    </div>
                </div>

                <div style="text-align:center;margin-bottom:14px;">
                    <div style="font-size:12px;color:#64748b;">Total Uang Diterima:</div>
                    <div style="font-size:24px;font-weight:900;color:#15803d;margin-top:2px;">
                        Rp <?php echo number_format($slip['total_amount'], 0, ',', '.'); ?>
                    </div>
                    <div style="font-size:11px;color:#64748b;margin-top:2px;">Penyaluran: <b><?php echo esc_html($slip['payment_method']); ?></b></div>
                </div>

                <button type="button" onclick="openSlipModal('slip-modal-<?php echo $counter; ?>')" style="width:100%;padding:10px;border-radius:10px;background:#f1f5f9;border:1px solid #cbd5e1;font-weight:bold;font-size:13px;cursor:pointer;">
                    📄 Lihat &amp; Cetak Lembaran Slip
                </button>
            </div>

            <div id="slip-modal-<?php echo $counter; ?>" class="pk-modal">
                <div class="pk-modal-content">
                    <div style="border-bottom:2px solid #000;padding-bottom:8px;text-align:center;">
                        <h2 style="margin:0;font-size:18px;">SLIP PEMBAYARAN UPAH KERJA</h2>
                        <div style="font-size:12px;">BENGKEL PRODUKSI / WORKSHOP MEBEL</div>
                    </div>
                    <div style="margin:12px 0;font-size:12px;line-height:1.6;">
                        <div>No. Bukti : <b><?php echo esc_html($slip['slip_no']); ?></b></div>
                        <div>Penerima  : <b><?php echo esc_html($target_emp_data['name'] ?? 'Pekerja'); ?></b></div>
                        <div>Tanggal   : <?php echo esc_html(date('d F Y', strtotime($slip['paid_at']))); ?></div>
                        <div>Metode    : <?php echo esc_html($slip['payment_method']); ?> (LUNAS)</div>
                    </div>

                    <table style="width:100%;border-collapse:collapse;font-size:11px;margin:12px 0;">
                        <thead>
                            <tr style="border-top:1px solid #000;border-bottom:1px solid #000;">
                                <th style="text-align:left;padding:6px 0;">No SPK / Produk</th>
                                <th style="text-align:center;padding:6px 0;">Qty</th>
                                <th style="text-align:right;padding:6px 0;">Upah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($slip['jobs'] as $jb): ?>
                            <tr>
                                <td style="padding:6px 0;">
                                    <?php echo esc_html($jb['job_no']); ?><br>
                                    <small><?php echo esc_html($jb['product_name']); ?></small>
                                </td>
                                <td style="text-align:center;padding:6px 0;"><?php echo (float)$jb['good_qty']; ?></td>
                                <td style="text-align:right;padding:6px 0;">Rp <?php echo number_format((float)$jb['amount'], 0, ',', '.'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr style="border-top:1px solid #000;border-bottom:2px solid #000;font-size:12px;">
                                <th colspan="2" style="text-align:left;padding:8px 0;">TOTAL GAJI DITERIMA:</th>
                                <th style="text-align:right;padding:8px 0;">Rp <?php echo number_format($slip['total_amount'], 0, ',', '.'); ?></th>
                            </tr>
                        </tfoot>
                    </table>

                    <div style="display:grid;grid-template-columns:1fr 1fr;margin-top:24px;text-align:center;font-size:11px;">
                        <div>Penerima,<br><br><br>( <?php echo esc_html($target_emp_data['name'] ?? 'Pekerja'); ?> )</div>
                        <div>Bagian Keuangan,<br><br><br>( Kasir / HRD )</div>
                    </div>

                    <div class="no-print" style="margin-top:20px;text-align:center;">
                        <?php if (!empty($slip['wage_id']) && function_exists('pk01_print_url')): ?><a target="_blank" rel="noopener" href="<?php echo esc_url(pk01_print_url('upah-job',(int)$slip['wage_id'])); ?>" style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;border-radius:8px;font-weight:bold;text-decoration:none;">🖨️ Cetak PDF Profesional</a><?php endif; ?>
                        <button type="button" onclick="closeSlipModal('slip-modal-<?php echo $counter; ?>')" style="padding:10px 16px;background:#e2e8f0;border:none;border-radius:8px;font-weight:bold;cursor:pointer;margin-left:8px;">Tutup</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- =======================================================
         TAB 3: REKENING SAYA
         ======================================================= -->
    <div id="tab-profile" class="pk-worker-tab-content" style="display:none;">
        <div style="background:#fff;border:2px solid #e2e8f0;border-radius:16px;padding:20px;">
            <h3 style="margin:0 0 6px 0;font-size:17px;font-weight:800;color:#0f172a;">🏦 Pilihan Cara Terima Gaji</h3>
            <p style="font-size:13px;color:#64748b;margin:0 0 16px 0;">Pilih apakah gaji ingin <b>ditransfer ke bank/e-wallet</b> atau <b>diambil tunai di kasir kantor</b>:</p>

            <form method="post" style="margin:0;">
                <?php echo wp_nonce_field('pk01_worker_profile', 'pk01_profile_nonce', true, false); ?>
                <input type="hidden" name="pk01_worker_update_profile" value="1">
                <input type="hidden" name="target_employee_id" value="<?php echo (int)$target_emp_id; ?>">

                <?php 
                    $cur_pref = $target_emp_data['payment_pref'] ?? 'transfer';
                    $cur_bank = $target_emp_data['bank_name'] ?? '';
                    $cur_acc  = $target_emp_data['bank_account_no'] ?? '';
                    $cur_name = $target_emp_data['bank_account_name'] ?? '';
                    $cur_wa   = $target_emp_data['phone'] ?? '';
                ?>

                <label style="display:flex;align-items:center;gap:10px;padding:12px;border:2px solid #cbd5e1;border-radius:10px;margin-bottom:10px;cursor:pointer;">
                    <input type="radio" name="payment_pref" value="transfer" <?php checked($cur_pref, 'transfer'); ?> onchange="toggleBankFields(this.value)">
                    <div>
                        <strong style="display:block;font-size:14px;color:#0f172a;">📲 Minta Ditransfer (Bank / E-Wallet)</strong>
                        <span style="font-size:12px;color:#64748b;">Kirim langsung ke rekening tabungan atau akun DANA/OVO.</span>
                    </div>
                </label>

                <label style="display:flex;align-items:center;gap:10px;padding:12px;border:2px solid #cbd5e1;border-radius:10px;margin-bottom:12px;cursor:pointer;">
                    <input type="radio" name="payment_pref" value="cash" <?php checked($cur_pref, 'cash'); ?> onchange="toggleBankFields(this.value)">
                    <div>
                        <strong style="display:block;font-size:14px;color:#0f172a;">💵 Ambil Cash / Tunai di Kasir Saja</strong>
                        <span style="font-size:12px;color:#64748b;">Saya mau ambil uang tunai langsung ke kasir.</span>
                    </div>
                </label>

                <div id="bank-input-fields" style="<?php echo ($cur_pref === 'cash') ? 'display:none;' : 'display:block;'; ?>background:#f8fafc;padding:12px;border-radius:10px;border:1px solid #cbd5e1;margin-bottom:12px;">
                    <div style="margin-bottom:10px;">
                        <label style="display:block;font-size:12px;font-weight:bold;margin-bottom:4px;">Nama Bank / E-Wallet:</label>
                        <select name="bank_name" style="width:100%;padding:10px;border-radius:6px;border:1px solid #cbd5e1;font-weight:bold;">
                            <option value="BCA" <?php selected($cur_bank, 'BCA'); ?>>BCA</option>
                            <option value="BRI" <?php selected($cur_bank, 'BRI'); ?>>BRI</option>
                            <option value="Mandiri" <?php selected($cur_bank, 'Mandiri'); ?>>Mandiri</option>
                            <option value="BNI" <?php selected($cur_bank, 'BNI'); ?>>BNI</option>
                            <option value="BSI" <?php selected($cur_bank, 'BSI'); ?>>BSI (Syariah)</option>
                            <option value="DANA" <?php selected($cur_bank, 'DANA'); ?>>DANA</option>
                            <option value="OVO" <?php selected($cur_bank, 'OVO'); ?>>OVO</option>
                            <option value="Lainnya" <?php selected($cur_bank, 'Lainnya'); ?>>Lainnya</option>
                        </select>
                    </div>

                    <div style="margin-bottom:10px;">
                        <label style="display:block;font-size:12px;font-weight:bold;margin-bottom:4px;">Nomor Rekening / No. HP E-Wallet:</label>
                        <input type="text" name="bank_account_no" value="<?php echo esc_attr($cur_acc); ?>" placeholder="Contoh: 8291029312" style="width:100%;padding:10px;border-radius:6px;border:1px solid #cbd5e1;font-weight:bold;font-size:15px;">
                    </div>

                    <div>
                        <label style="display:block;font-size:12px;font-weight:bold;margin-bottom:4px;">Nama Pemilik Rekening:</label>
                        <input type="text" name="bank_account_name" value="<?php echo esc_attr($cur_name); ?>" placeholder="Contoh: Budi Santoso" style="width:100%;padding:10px;border-radius:6px;border:1px solid #cbd5e1;">
                    </div>
                </div>

                <div style="margin-bottom:14px;">
                    <label style="display:block;font-size:12px;font-weight:bold;margin-bottom:4px;">Nomor WhatsApp / HP Anda:</label>
                    <input type="tel" name="phone" value="<?php echo esc_attr($cur_wa); ?>" placeholder="08xxxxxxxxxx" style="width:100%;padding:10px;border-radius:6px;border:1px solid #cbd5e1;">
                </div>

                <button type="submit" class="pk-btn-jumbo pk-btn-jumbo-blue">💾 SIMPAN REKENING SAYA</button>
            </form>
        </div>
    </div>

</div>

<!-- SCRIPT GANTI TAB, FILTER STATUS & MODAL PRINT -->
<script>
function filterJobStatus(statusType, cardElement) {
    var jobTabBtn = document.querySelector('.pk-tab-nav .pk-tab-btn:first-child');
    if (jobTabBtn) switchWorkerTab('tab-job', jobTabBtn);

    document.querySelectorAll('.pk-status-kpi-card').forEach(function(c) {
        c.classList.remove('is-active');
    });
    if (cardElement) cardElement.classList.add('is-active');

    var cards = document.querySelectorAll('#pk-job-list-wrapper .pk-job-card-simple');
    cards.forEach(function(card) {
        var cardStatus = card.getAttribute('data-status');
        if (statusType === 'all' || cardStatus === statusType) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

function switchWorkerTab(tabId, btn) {
    document.querySelectorAll('.pk-worker-tab-content').forEach(function(el) {
        el.style.display = 'none';
    });
    document.querySelectorAll('.pk-tab-btn').forEach(function(b) {
        b.classList.remove('active');
    });
    var target = document.getElementById(tabId);
    if (target) target.style.display = 'block';
    if (btn) btn.classList.add('active');
}

function toggleBankFields(val) {
    var box = document.getElementById('bank-input-fields');
    if (box) box.style.display = (val === 'transfer') ? 'block' : 'none';
}

function openSlipModal(id) {
    var el = document.getElementById(id);
    if (el) el.style.display = 'block';
}

function closeSlipModal(id) {
    var el = document.getElementById(id);
    if (el) el.style.display = 'none';
}

window.onclick = function(e) {
    if (e.target.classList.contains('pk-modal')) {
        e.target.style.display = 'none';
    }
};
</script>