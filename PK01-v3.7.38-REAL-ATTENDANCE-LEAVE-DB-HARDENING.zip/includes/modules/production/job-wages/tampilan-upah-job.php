<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

$can = current_user_can('manage_options') || (class_exists('PK01_Authorization') && PK01_Authorization::can('job_wages'));
$msg = ''; 
$err = '';

// ==========================================================================
// 1. PROSES AKSI PENGELOLAAN UPAH (LOGIKA LAMA UTUH & AMAN)
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pk01_job_wage_action'])) {
    if (!$can || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pk01_job_wage_nonce'] ?? '')), 'pk01_job_wage')) {
        $err = 'Anda tidak memiliki izin atau sesi keamanan sudah kedaluwarsa. Silakan muat ulang.';
    } else {
        try {
            $action = sanitize_key($_POST['pk01_job_wage_action']);
            
            if ($action === 'create') {
                $job    = (int)($_POST['job_id'] ?? 0); 
                $emp    = (int)($_POST['employee_id'] ?? 0); 
                $detail = sanitize_text_field(wp_unslash($_POST['job_detail'] ?? ''));
                $qty    = (float)($_POST['qty'] ?? 1); 
                $rate   = (float)($_POST['rate'] ?? 0); 
                $unit   = sanitize_text_field(wp_unslash($_POST['unit'] ?? 'job')); 
                $period = sanitize_text_field($_POST['period_key'] ?? current_time('Y-m')); 
                $method = sanitize_text_field(wp_unslash($_POST['payment_method'] ?? 'Transfer Bank'));
                $notes  = sanitize_textarea_field(wp_unslash($_POST['notes'] ?? ''));

                $id = PK01_Engine::create_job_wage($job, $emp, $detail, $qty, $rate, $unit, $period, 'pending', $method, $notes);
                $msg = 'Upah job berhasil dicatat sebagai kewajiban upah. Saldo kas belum berkurang sampai dicairkan.';
            } elseif ($action === 'pay') { 
                PK01_Engine::pay_job_wage((int)$_POST['wage_id']); 
                $msg = 'Upah job berhasil dilunasi penuh dan disinkronkan otomatis ke laporan biaya serta kas.'; 
            } elseif ($action === 'partial_pay') { 
                PK01_Engine::pay_job_wage_partial(
                    (int)$_POST['wage_id'],
                    (float)$_POST['pay_amount'],
                    $_POST['payment_method'] ?? 'Transfer Bank',
                    $_POST['payment_notes'] ?? ''
                ); 
                $msg = 'Pembayaran upah bertahap berhasil dicatat. Sisa saldo upah tetap melekat pada Job ini.'; 
            } elseif ($action === 'edit') { 
                PK01_Engine::edit_job_wage(
                    (int)$_POST['wage_id'],
                    $_POST['job_detail'] ?? '',
                    (float)$_POST['qty'],
                    (float)$_POST['rate'],
                    $_POST['unit'] ?? 'job',
                    $_POST['period_key'] ?? current_time('Y-m'),
                    $_POST['notes'] ?? ''
                ); 
                $msg = 'Data upah yang belum dibayar berhasil disesuaikan.'; 
            }
        } catch (Throwable $e) {
            $err = $e->getMessage();
        }
    }
}

// ==========================================================================
// 2. QUERY DATA DARI DATABASE (DENGAN INFORMASI REKENING PEKERJA)
// ==========================================================================
$jobs   = PK01_DB::t('jobs'); 
$assign = PK01_DB::t('job_assignments'); 
$emp    = PK01_DB::t('employees'); 
$w      = PK01_DB::t('job_wages'); 

$job_rows = $wpdb->get_results("
    SELECT j.id, j.job_no, j.status, j.target_qty, j.product_id, 
           ja.employee_id, e.name AS employee_name, e.pay_type, e.rate AS emp_rate 
    FROM {$jobs} j 
    JOIN {$assign} ja ON ja.job_id = j.id 
    JOIN {$emp} e ON e.id = ja.employee_id 
    WHERE ja.status IN ('completed','assigned','accepted','in_progress') 
    ORDER BY j.id DESC 
    LIMIT 100
", ARRAY_A) ?: [];

$active_employees = $wpdb->get_results("
    SELECT id, name, position, rate, payment_pref, bank_name, bank_account_no, bank_account_name 
    FROM {$emp} 
    WHERE status = 'active' 
    ORDER BY name ASC
", ARRAY_A) ?: [];

$rows = $wpdb->get_results("
    SELECT w.*, j.job_no, e.name AS employee_name, e.payment_pref, e.bank_name, e.bank_account_no, e.bank_account_name 
    FROM {$w} w 
    LEFT JOIN {$jobs} j ON j.id = w.job_id 
    LEFT JOIN {$emp} e ON e.id = w.employee_id 
    ORDER BY w.id DESC 
    LIMIT 100
", ARRAY_A) ?: [];

// Kalkulasi Metrik Finansial Upah (KPI Cockpit)
$kpi_total_accrued = 0.0;
$kpi_total_paid    = 0.0;
$kpi_total_pending = 0.0;
$kpi_count_pending = 0;
$kpi_count_paid    = 0;

foreach ($rows as $r_stat) {
    $amt   = (float)($r_stat['amount'] ?? 0);
    $p_amt = (float)($r_stat['paid_amount'] ?? (($r_stat['status'] === 'paid') ? $amt : 0));
    $s_bal = max(0, $amt - $p_amt);

    $kpi_total_accrued += $amt;
    $kpi_total_paid    += $p_amt;
    $kpi_total_pending += $s_bal;

    if ($s_bal <= 0 && $r_stat['status'] === 'paid') {
        $kpi_count_paid++;
    } else {
        $kpi_count_pending++;
    }
}
?>

<style>
/* ==========================================================================
   MASTERPIECE UPAH & PAYROLL PRODUKSI STYLES
   ========================================================================== */
.pk-wage-wrap {
    --pk-primary: #0f172a;
    --pk-accent: #2563eb;
    --pk-accent-hover: #1d4ed8;
    --pk-surface: #ffffff;
    --pk-bg: #f8fafc;
    --pk-border: #e2e8f0;
    --pk-text-main: #0f172a;
    --pk-text-muted: #64748b;
    --pk-green: #10b981;
    --pk-green-dark: #047857;
    --pk-amber: #f59e0b;
    --pk-red: #ef4444;
    --pk-purple: #7c3aed;
    --pk-radius: 14px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: var(--pk-text-main);
    margin-top: 15px;
}
.pk-wage-wrap * { box-sizing: border-box; }

/* Alert Styles */
.pk-alert {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 18px;
    border-radius: var(--pk-radius);
    margin-bottom: 22px;
    font-size: 14px;
    line-height: 1.5;
}
.pk-alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
.pk-alert-error   { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
.pk-alert-icon { font-weight: bold; font-size: 18px; line-height: 1; }

/* Hero Banner */
.pk-hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #1e3a8a 100%);
    color: #ffffff;
    border-radius: var(--pk-radius);
    padding: 24px 28px;
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15);
}
.pk-hero-eyebrow {
    display: inline-block;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.3);
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    padding: 4px 10px;
    border-radius: 6px;
    margin-bottom: 6px;
}
.pk-hero-banner h2 { margin: 0 0 6px 0; font-size: 24px; font-weight: 800; color: #f8fafc; }
.pk-hero-banner p { color: #cbd5e1; font-size: 13px; margin: 0; max-width: 650px; line-height: 1.5; }

/* KPI Scorecards */
.pk-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 14px;
    margin-bottom: 24px;
}
.pk-kpi-card {
    background: var(--pk-surface);
    border: 1px solid var(--pk-border);
    border-radius: 12px;
    padding: 16px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    border-left: 4px solid #cbd5e1;
}
.pk-kpi-card.c-blue  { border-left-color: #3b82f6; }
.pk-kpi-card.c-green { border-left-color: #10b981; background: #fafdfc; }
.pk-kpi-card.c-amber { border-left-color: #f59e0b; background: #fffdf5; }
.pk-kpi-card.c-purple{ border-left-color: #7c3aed; }
.pk-kpi-card small { font-size: 11px; font-weight: 700; text-transform: uppercase; color: var(--pk-text-muted); display: block; }
.pk-kpi-card strong { font-size: 22px; font-weight: 900; color: var(--pk-text-main); display: block; margin: 4px 0 2px 0; }
.pk-kpi-card span { font-size: 11px; color: var(--pk-text-muted); }

/* Main Grid Form & Policy */
.pk-main-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 22px;
    align-items: start;
    margin-bottom: 26px;
}
@media (max-width: 960px) {
    .pk-main-grid { grid-template-columns: 1fr; }
}

.pk-panel {
    background: var(--pk-surface);
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-panel-head {
    padding: 16px 20px;
    background: #fafbfc;
    border-bottom: 1px solid var(--pk-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.pk-panel-head h3 { margin: 0; font-size: 16px; font-weight: 700; color: var(--pk-text-main); }
.pk-panel-body { padding: 20px; }

/* Form Controls */
.pk-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 14px;
}
.pk-field { display: flex; flex-direction: column; gap: 5px; }
.pk-field.is-wide { grid-column: 1 / -1; }
.pk-field label { font-size: 12px; font-weight: 700; color: #334155; }
.pk-field input, .pk-field select, .pk-field textarea {
    width: 100%;
    border: 1px solid var(--pk-border);
    border-radius: 8px;
    padding: 9px 12px;
    font-size: 13px;
    background: #fff;
    color: var(--pk-text-main);
    transition: all 0.2s ease;
}
.pk-field input:focus, .pk-field select:focus, .pk-field textarea:focus {
    border-color: var(--pk-accent);
    outline: none;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

/* Live Total Preview Box */
.pk-total-preview-box {
    grid-column: 1 / -1;
    background: #f1f5f9;
    border: 1px dashed #cbd5e1;
    border-radius: 10px;
    padding: 12px 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
}
.pk-total-preview-box strong { font-size: 18px; color: #2563eb; }

.pk-submit-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: var(--pk-primary);
    color: white;
    border: none;
    font-weight: 700;
    font-size: 13px;
    padding: 12px 20px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    margin-top: 14px;
    width: 100%;
}
.pk-submit-btn:hover { background: #1e293b; transform: translateY(-1px); }

/* Sidebar Guidance */
.pk-policy-card {
    background: #ffffff;
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-policy-item {
    display: flex;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 12px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
}
.pk-policy-icon { font-size: 20px; line-height: 1; }
.pk-policy-item strong { display: block; font-size: 13px; margin-bottom: 2px; color: #0f172a; }
.pk-policy-item p { margin: 0; font-size: 12px; color: #64748b; line-height: 1.4; }

/* Table Container & Toolbar */
.pk-table-panel {
    background: var(--pk-surface);
    border-radius: var(--pk-radius);
    border: 1px solid var(--pk-border);
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
.pk-table-toolbar {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    background: #fafbfc;
    border-bottom: 1px solid var(--pk-border);
}
.pk-filter-chips { display: flex; gap: 6px; flex-wrap: wrap; }
.pk-chip {
    padding: 6px 14px;
    border-radius: 20px;
    border: 1px solid var(--pk-border);
    background: #fff;
    font-size: 12px;
    font-weight: 700;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s ease;
}
.pk-chip.is-active { background: var(--pk-primary); color: #ffffff; border-color: var(--pk-primary); }

.pk-search-box { position: relative; width: 260px; }
.pk-search-box input {
    width: 100%;
    padding: 8px 12px 8px 32px;
    font-size: 13px;
    border: 1px solid var(--pk-border);
    border-radius: 8px;
}
.pk-search-box::before { content: "🔍"; position: absolute; left: 10px; top: 8px; font-size: 12px; opacity: 0.5; }

/* Real Table Styling */
.pk-table-responsive { width: 100%; overflow-x: auto; }
.pk-table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
.pk-table th {
    background: #f8fafc;
    color: var(--pk-text-muted);
    font-weight: 700;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.05em;
    padding: 12px 16px;
    border-bottom: 1px solid var(--pk-border);
    white-space: nowrap;
}
.pk-table td { padding: 13px 16px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.pk-table tr:hover td { background: #fbfcfe; }

/* Status Badges */
.pk-badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
}
.pk-badge-paid    { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
.pk-badge-pending { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }

.pk-btn-action {
    padding: 5px 10px;
    font-size: 11px;
    font-weight: 700;
    border-radius: 6px;
    cursor: pointer;
    border: none;
    text-decoration: none !important;
}
.pk-btn-pay-full { background: #10b981; color: #fff; }
.pk-btn-pay-full:hover { background: #059669; }
.pk-btn-partial { background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; }
.pk-btn-partial:hover { background: #e2e8f0; }
</style>

<div class="pk-wage-wrap">

    <!-- 1. HERO COCKPIT BANNER -->
    <header class="pk-hero-banner">
        <div>
            <span class="pk-hero-eyebrow">WORKFORCE COMPENSATION &bull; REAL ACCRUAL</span>
            <h2>Upah Pekerjaan &amp; Borongan Job</h2>
            <p>Sistem pencatatan upah berbasis hasil pengerjaan SPK bengkel. Dicatat sebagai kewajiban akrual dan <strong>saldo kas/bank hanya berkurang saat pencairan nyata dibukukan</strong>.</p>
        </div>
        <div style="text-align:right;">
            <span style="font-size:12px;font-weight:bold;background:rgba(255,255,255,0.15);padding:6px 12px;border-radius:8px;">
                🗓️ Periode Aktif: <?php echo esc_html(wp_date('F Y')); ?>
            </span>
        </div>
    </header>

    <!-- NOTIFIKASI -->
    <?php if ($msg): ?>
        <div class="pk-alert pk-alert-success"><div class="pk-alert-icon">✓</div><div><?php echo esc_html($msg); ?></div></div>
    <?php endif; ?>
    <?php if ($err): ?>
        <div class="pk-alert pk-alert-error"><div class="pk-alert-icon">✕</div><div><?php echo esc_html($err); ?></div></div>
    <?php endif; ?>

    <!-- 2. KPI COCKPIT (METRIK KEWAJIBAN & REALISASI UPAH) -->
    <div class="pk-kpi-grid">
        <div class="pk-kpi-card c-blue">
            <small>Total Kewajiban Upah (Akrual)</small>
            <strong style="color:#2563eb;">Rp <?php echo number_format($kpi_total_accrued, 0, ',', '.'); ?></strong>
            <span>Seluruh biaya upah terbit</span>
        </div>
        <div class="pk-kpi-card c-green">
            <small>Upah Sudah Dicairkan (Kas Keluar)</small>
            <strong style="color:#10b981;">Rp <?php echo number_format($kpi_total_paid, 0, ',', '.'); ?></strong>
            <span><?php echo (int)$kpi_count_paid; ?> Transaksi telah lunas</span>
        </div>
        <div class="pk-kpi-card c-amber">
            <small>Sisa Utang Upah (Pending)</small>
            <strong style="color:#d97706;">Rp <?php echo number_format($kpi_total_pending, 0, ',', '.'); ?></strong>
            <span><?php echo (int)$kpi_count_pending; ?> Transaksi menunggu cair</span>
        </div>
        <div class="pk-kpi-card c-purple">
            <small>Jumlah Catatan Upah</small>
            <strong><?php echo count($rows); ?></strong>
            <span>Riwayat pembukuan SPK</span>
        </div>
    </div>

    <!-- 3. FORM INPUT UPAH JOB & PANDUAN FINANCIAL POLICY -->
    <div class="pk-main-grid">
        <!-- FORM INPUT UPAH -->
        <div class="pk-panel">
            <div class="pk-panel-head">
                <h3>➕ Penerbitan Beban Upah Job Baru</h3>
            </div>
            <div class="pk-panel-body">
                <?php if ($can): ?>
                <form method="post" action="" id="pk-create-wage-form">
                    <?php wp_nonce_field('pk01_job_wage', 'pk01_job_wage_nonce'); ?>
                    <input type="hidden" name="pk01_job_wage_action" value="create">

                    <div class="pk-form-grid">
                        <div class="pk-field">
                            <label>Pilih Job Produksi (SPK) *</label>
                            <select name="job_id" id="in-job-select" required>
                                <option value="">-- Pilih SPK Job --</option>
                                <?php foreach ($job_rows as $r): ?>
                                    <option value="<?php echo (int)$r['id']; ?>" 
                                            data-empid="<?php echo (int)$r['employee_id']; ?>" 
                                            data-empname="<?php echo esc_attr($r['employee_name']); ?>" 
                                            data-qty="<?php echo esc_attr($r['target_qty'] ?? 1); ?>" 
                                            data-rate="<?php echo esc_attr($r['emp_rate'] ?? 0); ?>">
                                        <?php echo esc_html($r['job_no'] . ' — ' . $r['employee_name'] . ' [' . strtoupper($r['status']) . ']'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk-field">
                            <label>Karyawan / Penerima Upah *</label>
                            <select name="employee_id" id="in-emp-select" required>
                                <option value="">-- Pilih Karyawan --</option>
                                <?php foreach ($active_employees as $e): ?>
                                    <option value="<?php echo (int)$e['id']; ?>" data-rate="<?php echo esc_attr($e['rate'] ?? 0); ?>">
                                        <?php echo esc_html($e['name'] . ' — ' . ($e['position'] ?: 'Tukang/Staf')); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="pk-field is-wide">
                            <label>Rincian / Uraian Tugas Pekerjaan *</label>
                            <input name="job_detail" id="in-job-detail" placeholder="Contoh: Rakit kabinet bodi HPL 2 unit & finishing edging" required>
                        </div>

                        <div class="pk-field">
                            <label>Kuantitas (Qty) *</label>
                            <input type="number" name="qty" id="in-qty" step="0.01" min="0.01" value="1" required>
                        </div>

                        <div class="pk-field">
                            <label>Tarif Upah per Satuan (Rp) *</label>
                            <input type="number" name="rate" id="in-rate" step="0.01" min="0" placeholder="0" required>
                        </div>

                        <div class="pk-field">
                            <label>Satuan Pembayaran</label>
                            <input name="unit" value="job" placeholder="job / unit / pcs / m2">
                        </div>

                        <div class="pk-field">
                            <label>Periode Pembukuan</label>
                            <input type="month" name="period_key" value="<?php echo esc_attr(current_time('Y-m')); ?>" required>
                        </div>

                        <div class="pk-field">
                            <label>Rencana Metode Bayar</label>
                            <select name="payment_method">
                                <option value="Transfer Bank">Transfer Bank</option>
                                <option value="Kas Tunai">Kas Tunai</option>
                            </select>
                        </div>

                        <!-- Live Total Preview Box -->
                        <div class="pk-total-preview-box">
                            <div>
                                <span style="color:#64748b;font-size:11px;font-weight:bold;text-transform:uppercase;display:block;">Total Nilai Upah Dihitung:</span>
                                <span id="in-calc-formula">1 unit × Rp 0</span>
                            </div>
                            <strong id="in-calc-total">Rp 0</strong>
                        </div>

                        <div class="pk-field is-wide">
                            <label>Catatan Tambahan (Opsional)</label>
                            <textarea name="notes" rows="2" placeholder="Catatan teknis atau ketentuan potongan/bonus..."></textarea>
                        </div>
                    </div>

                    <button type="submit" class="pk-submit-btn">
                        💾 Simpan Kewajiban Upah Job
                    </button>
                </form>
                <?php else: ?>
                    <p style="color:#64748b;font-size:13px;margin:0;">Anda hanya memiliki izin melihat catatan upah tanpa hak menerbitkan beban upah baru.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- SIDEBAR FINANCIAL POLICY -->
        <div class="pk-policy-card">
            <h3 style="margin:0 0 14px 0;font-size:15px;font-weight:800;color:#0f172a;">
                🛡️ Kebijakan Pembukuan Upah PK01
            </h3>

            <div class="pk-policy-item">
                <div class="pk-policy-icon">⚖️</div>
                <div>
                    <strong>Pemisahan Upah vs Gaji Pokok</strong>
                    <p>Upah borongan langsung dibebankan ke HPP Job terkait agar kalkulasi laba-rugi produk presisi.</p>
                </div>
            </div>

            <div class="pk-policy-item">
                <div class="pk-policy-icon">🏦</div>
                <div>
                    <strong>Akrual &amp; Realisasi Kas</strong>
                    <p>Saat upah dicatat, statusnya adalah <em>Pending</em> (utang beban). Kas riil baru berkurang saat tombol <strong>Bayar</strong> dikonfirmasi.</p>
                </div>
            </div>

            <div class="pk-policy-item">
                <div class="pk-policy-icon">🧾</div>
                <div>
                    <strong>Tersinkron ke Portal Pekerja</strong>
                    <p>Upah yang dilunasi di menu ini otomatis terbit sebagai <strong>Slip Gaji Resmi</strong> di portal staf lapangan.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- 4. TABEL RIWAYAT UPAH PEKERJAAN & REALISASI BAYAR -->
    <div class="pk-table-panel">
        <div class="pk-table-toolbar">
            <div class="pk-filter-chips">
                <button type="button" class="pk-chip is-active" data-filter="all">Semua (<?php echo count($rows); ?>)</button>
                <button type="button" class="pk-chip" data-filter="pending">Belum Lunas (<?php echo (int)$kpi_count_pending; ?>)</button>
                <button type="button" class="pk-chip" data-filter="paid">Sudah Lunas (<?php echo (int)$kpi_count_paid; ?>)</button>
            </div>

            <div class="pk-search-box">
                <input type="text" id="pk-wage-search" placeholder="Cari SPK, nama tukang, uraian...">
            </div>
        </div>

        <div class="pk-table-responsive">
            <table class="pk-table" id="pk-wage-table">
                <thead>
                    <tr>
                        <th style="width:110px;">No. SPK</th>
                        <th>Karyawan / Rekening</th>
                        <th>Uraian Tugas</th>
                        <th>Qty &times; Tarif</th>
                        <th style="text-align:right;">Total Kewajiban</th>
                        <th style="text-align:right;">Sudah Cair</th>
                        <th style="text-align:right;color:#dc2626;">Sisa Tagihan</th>
                        <th style="text-align:center;">Status</th>
                        <th style="text-align:right;min-width:200px;">Aksi Pembayaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)): ?>
                        <tr><td colspan="9" style="text-align:center;padding:36px;color:#64748b;">Belum ada catatan upah pengerjaan job di database.</td></tr>
                    <?php else: foreach ($rows as $r): 
                        // Perhitungan $paid dan $bal dilakukan sebelum dirender ke HTML (Bugfix dari kode lama)
                        $paid = (float)($r['paid_amount'] ?? ($r['status'] === 'paid' ? $r['amount'] : 0));
                        $bal  = max(0, (float)$r['amount'] - $paid);
                        $is_lunas = ($bal <= 0 && $r['status'] === 'paid');
                        $search_meta = strtolower(($r['job_no'] ?? '') . ' ' . ($r['employee_name'] ?? '') . ' ' . ($r['job_detail'] ?? ''));
                    ?>
                    <tr class="pk-wage-row" data-status="<?php echo $is_lunas ? 'paid' : 'pending'; ?>" data-search="<?php echo esc_attr($search_meta); ?>">
                        <td>
                            <strong style="font-family:monospace;color:#0f172a;"><?php echo esc_html($r['job_no'] ?: '—'); ?></strong>
                            <div style="font-size:10px;color:#64748b;"><?php echo esc_html($r['period_key']); ?></div>
                        </td>
                        <td>
                            <strong style="color:#0f172a;"><?php echo esc_html($r['employee_name'] ?: '—'); ?></strong>
                            <?php if (!empty($r['bank_name'])): ?>
                                <div style="font-size:11px;color:#2563eb;margin-top:2px;">
                                    💳 <?php echo esc_html($r['bank_name']); ?>: <code><?php echo esc_html($r['bank_account_no']); ?></code>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="font-weight:600;color:#334155;"><?php echo esc_html($r['job_detail']); ?></div>
                            <?php if (!empty($r['notes'])): ?>
                                <small style="color:#64748b;font-style:italic;">"<?php echo esc_html(mb_strimwidth($r['notes'], 0, 35, '...')); ?>"</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo number_format((float)$r['qty'], 2, ',', '.'); ?> <?php echo esc_html($r['unit'] ?: 'job'); ?><br>
                            <small style="color:#64748b;">@ Rp <?php echo number_format((float)$r['rate'], 0, ',', '.'); ?></small>
                        </td>
                        <td style="text-align:right;">
                            <strong style="font-size:14px;color:#0f172a;">Rp <?php echo number_format((float)$r['amount'], 0, ',', '.'); ?></strong>
                        </td>
                        <td style="text-align:right;color:#059669;font-weight:700;">
                            Rp <?php echo number_format($paid, 0, ',', '.'); ?>
                        </td>
                        <td style="text-align:right;color:<?php echo $bal > 0 ? '#dc2626' : '#64748b'; ?>;font-weight:700;">
                            Rp <?php echo number_format($bal, 0, ',', '.'); ?>
                        </td>
                        <td style="text-align:center;">
                            <span class="pk-badge <?php echo $is_lunas ? 'pk-badge-paid' : 'pk-badge-pending'; ?>">
                                <?php echo $is_lunas ? '✓ LUNAS' : ($paid > 0 ? 'PARTIAL' : 'PENDING'); ?>
                            </span>
                        </td>
                        <td style="text-align:right;">
                            <?php if ($can && $bal > 0): ?>
                                <div style="display:inline-flex;gap:4px;align-items:center;">
                                    <!-- Pelunasan Instan Penuh -->
                                    <form method="post" style="display:inline;margin:0;" onsubmit="return confirm('Lunasi penuh upah ini sebesar Rp <?php echo number_format($bal, 0, ',', '.'); ?>? Saldo kas akan berkurang.');">
                                        <?php wp_nonce_field('pk01_job_wage', 'pk01_job_wage_nonce'); ?>
                                        <input type="hidden" name="pk01_job_wage_action" value="pay">
                                        <input type="hidden" name="wage_id" value="<?php echo (int)$r['id']; ?>">
                                        <button type="submit" class="pk-btn-action pk-btn-pay-full" title="Lunasi seluruh sisa">
                                            ✓ Lunasi
                                        </button>
                                    </form>

                                    <!-- Angsur / Bayar Bertahap -->
                                    <details style="position:relative;display:inline-block;text-align:left;">
                                        <summary class="pk-btn-action pk-btn-partial" style="list-style:none;">Angsur ▾</summary>
                                        <div style="position:absolute;right:0;top:100%;z-index:99;background:#fff;border:1px solid #cbd5e1;box-shadow:0 10px 25px rgba(0,0,0,0.15);border-radius:10px;padding:12px;width:240px;margin-top:6px;">
                                            <form method="post" style="display:grid;gap:6px;margin:0;">
                                                <?php wp_nonce_field('pk01_job_wage', 'pk01_job_wage_nonce'); ?>
                                                <input type="hidden" name="pk01_job_wage_action" value="partial_pay">
                                                <input type="hidden" name="wage_id" value="<?php echo (int)$r['id']; ?>">
                                                
                                                <label style="font-size:11px;font-weight:bold;">Jumlah Bayar (Rp):</label>
                                                <input type="number" name="pay_amount" min="0.01" max="<?php echo esc_attr($bal); ?>" step="0.01" value="<?php echo esc_attr($bal); ?>" style="padding:6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;" required>

                                                <label style="font-size:11px;font-weight:bold;">Metode:</label>
                                                <select name="payment_method" style="padding:6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">
                                                    <option value="Transfer Bank">Transfer Bank</option>
                                                    <option value="Kas Tunai">Kas Tunai</option>
                                                </select>

                                                <label style="font-size:11px;font-weight:bold;">Catatan:</label>
                                                <input name="payment_notes" placeholder="Contoh: DP 50%" style="padding:6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">

                                                <button type="submit" class="pk-btn-action pk-btn-pay-full" style="padding:7px;margin-top:4px;">
                                                    Catat Pencairan
                                                </button>
                                            </form>
                                        </div>
                                    </details>
                                </div>
                            <?php endif; ?>

                            <?php if ($can && $paid <= 0): ?>
                                <!-- Edit Catatan Upah (Hanya jika belum ada pembayaran) -->
                                <details style="position:relative;display:inline-block;margin-left:4px;text-align:left;">
                                    <summary class="pk-btn-action pk-btn-partial" style="list-style:none;">✏️</summary>
                                    <div style="position:absolute;right:0;top:100%;z-index:99;background:#fff;border:1px solid #cbd5e1;box-shadow:0 10px 25px rgba(0,0,0,0.15);border-radius:10px;padding:12px;width:240px;margin-top:6px;">
                                        <form method="post" style="display:grid;gap:6px;margin:0;">
                                            <?php wp_nonce_field('pk01_job_wage', 'pk01_job_wage_nonce'); ?>
                                            <input type="hidden" name="pk01_job_wage_action" value="edit">
                                            <input type="hidden" name="wage_id" value="<?php echo (int)$r['id']; ?>">
                                            
                                            <label style="font-size:11px;font-weight:bold;">Rincian:</label>
                                            <input name="job_detail" value="<?php echo esc_attr($r['job_detail']); ?>" style="padding:6px;font-size:12px;border:1px solid #cbd5e1;border-radius:6px;" required>

                                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
                                                <div>
                                                    <label style="font-size:11px;font-weight:bold;">Qty:</label>
                                                    <input name="qty" type="number" step="0.01" min="0.01" value="<?php echo esc_attr($r['qty']); ?>" style="padding:6px;font-size:12px;border:1px solid #cbd5e1;border-radius:6px;" required>
                                                </div>
                                                <div>
                                                    <label style="font-size:11px;font-weight:bold;">Tarif (Rp):</label>
                                                    <input name="rate" type="number" step="0.01" min="0" value="<?php echo esc_attr($r['rate']); ?>" style="padding:6px;font-size:12px;border:1px solid #cbd5e1;border-radius:6px;" required>
                                                </div>
                                            </div>

                                            <label style="font-size:11px;font-weight:bold;">Satuan:</label>
                                            <input name="unit" value="<?php echo esc_attr($r['unit']); ?>" style="padding:6px;font-size:12px;border:1px solid #cbd5e1;border-radius:6px;">

                                            <label style="font-size:11px;font-weight:bold;">Catatan:</label>
                                            <input name="notes" value="<?php echo esc_attr($r['notes']); ?>" style="padding:6px;font-size:12px;border:1px solid #cbd5e1;border-radius:6px;">

                                            <button type="submit" class="pk-btn-action pk-btn-pay-full" style="padding:7px;margin-top:4px;">
                                                Simpan Perubahan
                                            </button>
                                        </form>
                                    </div>
                                </details>
                            <?php endif; ?>

                            <?php if ($is_lunas): ?>
                                <span style="font-weight:800;color:#059669;font-size:12px;">✓ Lunas</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- JAVASCRIPT: REAL-TIME SEARCH, FILTER CHIPS & FORM AUTO-CALCULATION -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Live Filter & Real-Time Search di Tabel
    var searchInput = document.getElementById('pk-wage-search');
    var filterChips = document.querySelectorAll('.pk-chip');
    var activeFilter = 'all';

    function applyWageFilters() {
        var query = searchInput ? searchInput.value.toLowerCase().trim() : '';
        var rows  = document.querySelectorAll('#pk-wage-table tbody tr.pk-wage-row');

        rows.forEach(function(row) {
            var status = row.getAttribute('data-status') || '';
            var text   = row.getAttribute('data-search') || '';

            var matchSearch = (text.indexOf(query) > -1);
            var matchChip   = (activeFilter === 'all' || status === activeFilter);

            if (matchSearch && matchChip) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyWageFilters);
    }

    if (filterChips.length > 0) {
        filterChips.forEach(function(chip) {
            chip.addEventListener('click', function() {
                filterChips.forEach(function(c) { c.classList.remove('is-active'); });
                this.classList.add('is-active');
                activeFilter = this.getAttribute('data-filter') || 'all';
                applyWageFilters();
            });
        });
    }

    // 2. Form Auto-Sync & Live Formula Calculator
    var jobSelect  = document.getElementById('in-job-select');
    var empSelect  = document.getElementById('in-emp-select');
    var qtyInput   = document.getElementById('in-qty');
    var rateInput  = document.getElementById('in-rate');
    var formulaEl  = document.getElementById('in-calc-formula');
    var totalEl    = document.getElementById('in-calc-total');

    function updateCalculations() {
        var qty  = parseFloat(qtyInput.value) || 0;
        var rate = parseFloat(rateInput.value) || 0;
        var total = qty * rate;

        if (formulaEl) formulaEl.innerText = qty.toLocaleString('id-ID') + ' unit × Rp ' + rate.toLocaleString('id-ID');
        if (totalEl)   totalEl.innerText   = 'Rp ' + total.toLocaleString('id-ID');
    }

    if (jobSelect) {
        jobSelect.addEventListener('change', function() {
            var opt = jobSelect.options[jobSelect.selectedIndex];
            if (opt && opt.value) {
                var empId   = opt.getAttribute('data-empid');
                var defQty  = opt.getAttribute('data-qty');
                var defRate = opt.getAttribute('data-rate');

                if (empSelect && empId) {
                    empSelect.value = empId;
                }
                if (qtyInput && defQty && parseFloat(defQty) > 0) {
                    qtyInput.value = defQty;
                }
                if (rateInput && defRate && parseFloat(defRate) > 0) {
                    rateInput.value = defRate;
                }
            }
            updateCalculations();
        });
    }

    if (empSelect) {
        empSelect.addEventListener('change', function() {
            var opt = empSelect.options[empSelect.selectedIndex];
            if (opt && opt.value) {
                var defRate = opt.getAttribute('data-rate');
                if (rateInput && (!rateInput.value || parseFloat(rateInput.value) === 0) && defRate) {
                    rateInput.value = defRate;
                }
            }
            updateCalculations();
        });
    }

    if (qtyInput)  qtyInput.addEventListener('input', updateCalculations);
    if (rateInput) rateInput.addEventListener('input', updateCalculations);
});
</script>