<?php
if (!defined('ABSPATH')) exit;

/**
 * PK01 DODI Chat 1.0
 * Chat server-side untuk komunikasi CNC/Produksi <-> Operasional.
 * Tidak memakai localStorage sebagai sumber kebenaran.
 */
class PK01_DODI_Chat {
    const NS='pk01/v1';

    public static function init(){
        add_action('rest_api_init',[__CLASS__,'routes']);
        add_action('wp_footer',[__CLASS__,'floating_widget'],99);
        add_action('init',[__CLASS__,'maybe_install'],4);
        add_action('init',[__CLASS__,'maybe_install_customer_chat'],5);
    }
    static function table($k){
        return class_exists('PK01_DB') && method_exists('PK01_DB','t') ? PK01_DB::t($k) : '';
    }
    static function maybe_install(){
        global $wpdb;
        $rooms=self::table('chat_rooms'); $msgs=self::table('chat_messages'); $parts=self::table('chat_participants');
        if(!$rooms||!$msgs||!$parts)return;
        if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$rooms))===$rooms &&
           $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$msgs))===$msgs &&
           $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$parts))===$parts)return;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $charset=$wpdb->get_charset_collate();
        PK01_DB::dbDelta_safe("CREATE TABLE {$rooms} (
          id bigint unsigned NOT NULL AUTO_INCREMENT,
          room_key varchar(180) NOT NULL,
          room_type varchar(40) NOT NULL DEFAULT 'production_job',
          title varchar(180) NOT NULL,
          job_id bigint unsigned NULL,
          created_by bigint unsigned NOT NULL DEFAULT 0,
          created_at datetime NOT NULL,
          updated_at datetime NOT NULL,
          PRIMARY KEY(id), UNIQUE KEY room_key(room_key), KEY job_id(job_id)
        ) {$charset};");
        PK01_DB::dbDelta_safe("CREATE TABLE {$parts} (
          id bigint unsigned NOT NULL AUTO_INCREMENT,
          room_id bigint unsigned NOT NULL,
          user_id bigint unsigned NOT NULL,
          last_read_id bigint unsigned NOT NULL DEFAULT 0,
          joined_at datetime NOT NULL,
          PRIMARY KEY(id), UNIQUE KEY room_user(room_id,user_id), KEY user_id(user_id)
        ) {$charset};");
        PK01_DB::dbDelta_safe("CREATE TABLE {$msgs} (
          id bigint unsigned NOT NULL AUTO_INCREMENT,
          room_id bigint unsigned NOT NULL,
          sender_id bigint unsigned NOT NULL,
          message longtext NOT NULL,
          reply_to bigint unsigned NULL,
          created_at datetime NOT NULL,
          PRIMARY KEY(id), KEY room_created(room_id,created_at), KEY sender_id(sender_id)
        ) {$charset};");
    }
    public static function maybe_install_customer_chat(){
        global $wpdb;
        $threads=self::table('customer_chat_threads'); $msgs=self::table('customer_chat_messages');
        if(!$threads || !$msgs) return;
        // Jangan percaya flag schema saja. Jika tabel pernah gagal dibuat/dihapus,
        // cek keberadaan tabel dan pulihkan otomatis dengan dbDelta.
        $threads_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$threads)) === $threads;
        $msgs_exists    = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$msgs)) === $msgs;
        if ($threads_exists && $msgs_exists) {
            if (get_option('pk01_customer_chat_schema','') !== '1') update_option('pk01_customer_chat_schema','1',false);
            return;
        }
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $charset=$wpdb->get_charset_collate();
        PK01_DB::dbDelta_safe("CREATE TABLE {$threads} (
          id bigint unsigned NOT NULL AUTO_INCREMENT,
          public_token_hash char(64) NOT NULL,
          customer_name varchar(120) NOT NULL DEFAULT '',
          customer_phone varchar(40) NOT NULL DEFAULT '',
          customer_email varchar(190) NOT NULL DEFAULT '',
          subject varchar(180) NOT NULL DEFAULT 'Pertanyaan pelanggan',
          status varchar(20) NOT NULL DEFAULT 'open',
          assigned_user_id bigint unsigned NOT NULL DEFAULT 0,
          last_message_at datetime NULL,
          created_at datetime NOT NULL,
          updated_at datetime NOT NULL,
          PRIMARY KEY(id), UNIQUE KEY public_token_hash(public_token_hash), KEY status(status), KEY assigned_user_id(assigned_user_id), KEY updated_at(updated_at)
        ) {$charset};");
        PK01_DB::dbDelta_safe("CREATE TABLE {$msgs} (
          id bigint unsigned NOT NULL AUTO_INCREMENT,
          thread_id bigint unsigned NOT NULL,
          sender_type varchar(20) NOT NULL DEFAULT 'customer',
          sender_user_id bigint unsigned NOT NULL DEFAULT 0,
          message longtext NOT NULL,
          created_at datetime NOT NULL,
          PRIMARY KEY(id), KEY thread_created(thread_id,created_at), KEY sender_user_id(sender_user_id)
        ) {$charset};");
        update_option('pk01_customer_chat_schema','1',false);
    }

    static function customer_token($r=null){
        $token='';
        if($r instanceof WP_REST_Request) $token=sanitize_text_field((string)$r->get_param('token'));
        if($token==='') $token=sanitize_text_field((string)($_COOKIE['pk01_customer_chat_token']??''));
        return preg_match('/^[A-Za-z0-9_-]{40,100}$/',$token)?$token:'';
    }
    static function customer_hash($token){ return hash('sha256',(string)$token); }
    static function staff_allowed(){
        if(!is_user_logged_in()) return false;
        $u=wp_get_current_user();
        return current_user_can('manage_options') || (bool)array_intersect(['administrator','pk01_admin','pk01_owner','shop_manager','pk01_customer_service'],(array)$u->roles);
    }
    static function customer_thread($id,$token=''){
        global $wpdb; $t=self::table('customer_chat_threads');
        if(!$t)return null;
        if($token!=='') return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d AND public_token_hash=%s LIMIT 1",$id,self::customer_hash($token)),ARRAY_A);
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d LIMIT 1",$id),ARRAY_A);
    }
    static function customer_routes(){
        register_rest_route(self::NS,'/customer-chat/start',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>[__CLASS__,'customer_start']]);
        register_rest_route(self::NS,'/customer-chat/thread/(?P<id>\d+)',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>[__CLASS__,'customer_get']]);
        register_rest_route(self::NS,'/customer-chat/thread/(?P<id>\d+)/send',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>[__CLASS__,'customer_send']]);
        register_rest_route(self::NS,'/customer-chat/inbox',['methods'=>'GET','permission_callback'=>function(){return self::staff_allowed();},'callback'=>[__CLASS__,'customer_inbox']]);
        register_rest_route(self::NS,'/customer-chat/staff/(?P<id>\d+)',['methods'=>'GET','permission_callback'=>function(){return self::staff_allowed();},'callback'=>[__CLASS__,'customer_staff_get']]);
        register_rest_route(self::NS,'/customer-chat/staff/(?P<id>\d+)/send',['methods'=>'POST','permission_callback'=>function(){return self::staff_allowed();},'callback'=>[__CLASS__,'customer_staff_send']]);
    }
    static function customer_start($r){
        self::maybe_install_customer_chat(); global $wpdb; $t=self::table('customer_chat_threads'); $m=self::table('customer_chat_messages');
        $p=$r->get_json_params()?:[]; $msg=trim(wp_strip_all_tags((string)($p['message']??'')));
        if($msg==='') return new WP_Error('empty_message','Pesan tidak boleh kosong.',['status'=>422]);
        if(mb_strlen($msg)>3000)return new WP_Error('message_too_long','Pesan maksimal 3.000 karakter.',['status'=>422]);
        $token=bin2hex(random_bytes(32)); $now=current_time('mysql');
        $ok=$wpdb->insert($t,['public_token_hash'=>self::customer_hash($token),'customer_name'=>sanitize_text_field((string)($p['name']??'')),'customer_phone'=>sanitize_text_field((string)($p['phone']??'')),'customer_email'=>sanitize_email((string)($p['email']??'')),'subject'=>sanitize_text_field((string)($p['subject']??'Pertanyaan pelanggan')),'status'=>'open','last_message_at'=>$now,'created_at'=>$now,'updated_at'=>$now]);
        if(!$ok)return new WP_Error('customer_chat_create_failed','Chat belum dapat dibuat.',['status'=>500]);
        $id=(int)$wpdb->insert_id;
        $wpdb->insert($m,['thread_id'=>$id,'sender_type'=>'customer','sender_user_id'=>0,'message'=>$msg,'created_at'=>$now]);
        return ['ok'=>true,'thread_id'=>$id,'token'=>$token,'message_id'=>(int)$wpdb->insert_id,'created_at'=>$now];
    }
    static function customer_get($r){
        self::maybe_install_customer_chat(); global $wpdb; $id=(int)$r['id']; $token=self::customer_token($r); $thread=self::customer_thread($id,$token);
        if(!$thread)return new WP_Error('chat_not_found','Percakapan tidak ditemukan.',['status'=>404]);
        $m=self::table('customer_chat_messages'); $rows=$wpdb->get_results($wpdb->prepare("SELECT id,sender_type,sender_user_id,message,created_at FROM {$m} WHERE thread_id=%d ORDER BY id ASC LIMIT 200",$id),ARRAY_A);
        $wpdb->update(self::table('customer_chat_threads'),['updated_at'=>current_time('mysql')],['id'=>$id]);
        return ['ok'=>true,'thread'=>['id'=>$id,'name'=>$thread['customer_name'],'status'=>$thread['status'],'subject'=>$thread['subject']],'messages'=>$rows];
    }
    static function customer_send($r){
        self::maybe_install_customer_chat(); global $wpdb; $id=(int)$r['id']; $token=self::customer_token($r); $thread=self::customer_thread($id,$token);
        if(!$thread)return new WP_Error('chat_not_found','Percakapan tidak ditemukan.',['status'=>404]);
        $p=$r->get_json_params()?:[]; $msg=trim(wp_strip_all_tags((string)($p['message']??'')));
        if($msg==='')return new WP_Error('empty_message','Pesan tidak boleh kosong.',['status'=>422]);
        if(mb_strlen($msg)>3000)return new WP_Error('message_too_long','Pesan maksimal 3.000 karakter.',['status'=>422]);
        if($thread['status']==='closed')return new WP_Error('chat_closed','Percakapan sudah ditutup.',['status'=>409]);
        $now=current_time('mysql'); $m=self::table('customer_chat_messages');
        $wpdb->insert($m,['thread_id'=>$id,'sender_type'=>'customer','sender_user_id'=>0,'message'=>$msg,'created_at'=>$now]);
        $wpdb->update(self::table('customer_chat_threads'),['last_message_at'=>$now,'updated_at'=>$now,'status'=>'open'],['id'=>$id]);
        return ['ok'=>true,'id'=>(int)$wpdb->insert_id,'created_at'=>$now];
    }
    static function customer_inbox($r){
        self::maybe_install_customer_chat(); global $wpdb; $t=self::table('customer_chat_threads');
        $rows=$wpdb->get_results("SELECT id,customer_name,customer_phone,subject,status,assigned_user_id,last_message_at,updated_at FROM {$t} ORDER BY updated_at DESC LIMIT 100",ARRAY_A);
        return ['ok'=>true,'threads'=>$rows];
    }
    static function customer_staff_get($r){
        self::maybe_install_customer_chat(); global $wpdb; $id=(int)$r['id']; $thread=self::customer_thread($id,''); if(!$thread)return new WP_Error('chat_not_found','Percakapan tidak ditemukan.',['status'=>404]);
        $m=self::table('customer_chat_messages'); $rows=$wpdb->get_results($wpdb->prepare("SELECT m.id,m.sender_type,m.sender_user_id,m.message,m.created_at,u.display_name FROM {$m} m LEFT JOIN {$wpdb->users} u ON u.ID=m.sender_user_id WHERE m.thread_id=%d ORDER BY m.id ASC LIMIT 300",$id),ARRAY_A);
        return ['ok'=>true,'thread'=>$thread,'messages'=>$rows];
    }
    static function customer_staff_send($r){
        self::maybe_install_customer_chat(); global $wpdb; $id=(int)$r['id']; $thread=self::customer_thread($id,''); if(!$thread)return new WP_Error('chat_not_found','Percakapan tidak ditemukan.',['status'=>404]);
        $p=$r->get_json_params()?:[]; $msg=trim(wp_strip_all_tags((string)($p['message']??''))); if($msg==='')return new WP_Error('empty_message','Pesan tidak boleh kosong.',['status'=>422]);
        if(mb_strlen($msg)>3000)return new WP_Error('message_too_long','Pesan maksimal 3.000 karakter.',['status'=>422]);
        $now=current_time('mysql'); $m=self::table('customer_chat_messages'); $uid=get_current_user_id();
        $wpdb->insert($m,['thread_id'=>$id,'sender_type'=>'staff','sender_user_id'=>$uid,'message'=>$msg,'created_at'=>$now]);
        $wpdb->update(self::table('customer_chat_threads'),['last_message_at'=>$now,'updated_at'=>$now,'status'=>'open','assigned_user_id'=>$uid,'updated_at'=>$now],['id'=>$id]);
        return ['ok'=>true,'id'=>(int)$wpdb->insert_id,'created_at'=>$now];
    }

    static function actor_id($r=null){
        if(is_user_logged_in()) return (int)get_current_user_id();
        if($r instanceof WP_REST_Request && class_exists('PK01_REST') && PK01_REST::authorize('production','view',$r)){
            $username=sanitize_user($r->get_header('x-pk01-chat-username') ?: '');
            if($username!==''){ $u=get_user_by('login',$username); if($u)return (int)$u->ID; }
        }
        return 0;
    }
    static function current_user_id(){return (int)get_current_user_id();}
    static function role_allowed($r=null){
        $actor=self::actor_id($r);
        if(!$actor)return false;
        $u=get_user_by('id',$actor); if(!$u)return false;
        $roles=(array)$u->roles;
        $allowed=['administrator','pk01_admin','pk01_owner','shop_manager','pk01_produksi','pk01_employee','pk01_gudang','pk01_logistik','pk01_hr','pk01_kasir','pk01_keuangan','pk01_seller','pk01_packing','pk01_customer_service'];
        return (bool)array_intersect($allowed,$roles);
    }
    static function can_job($job_id,$r=null){
        if(current_user_can('manage_options'))return true;
        $uid=self::actor_id($r); if(!$uid||!self::role_allowed($r))return false;
        global $wpdb; $a=self::table('job_assignments'); $e=self::table('employees');
        if($a && $e){
            $ok=$wpdb->get_var($wpdb->prepare(
                "SELECT ja.id FROM {$a} ja INNER JOIN {$e} e ON e.id=ja.employee_id WHERE ja.job_id=%d AND e.user_id=%d LIMIT 1",
                $job_id,$uid
            ));
            if($ok)return true;
        }
        // Seller may chat only on a Job created from that Seller's own order.
        $u=wp_get_current_user();
        if(in_array('pk01_seller',(array)$u->roles,true)){
            $so=self::table('seller_orders'); $sa=self::table('sales_accounts'); $jobs=self::table('jobs');
            if($so && $sa && $jobs){
                $ok=$wpdb->get_var($wpdb->prepare(
                    "SELECT j.id FROM {$jobs} j INNER JOIN {$so} o ON o.id=j.source_order_id INNER JOIN {$sa} s ON s.id=o.seller_account_id WHERE j.id=%d AND j.source_type='seller_order' AND s.user_id=%d LIMIT 1",
                    $job_id,$uid
                ));
                if($ok)return true;
            }
        }
        return (bool)array_intersect(['administrator','pk01_admin','pk01_owner','shop_manager','pk01_produksi','pk01_kasir','pk01_customer_service'],$u->roles);
    }
    static function room($job_id,$r=null){
        global $wpdb; $rooms=self::table('chat_rooms'); $uid=self::actor_id($r);
        $key='production:job:'.absint($job_id);
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$rooms} WHERE room_key=%s LIMIT 1",$key),ARRAY_A);
        if(!$r){
            $j=self::table('jobs'); $job=$j?$wpdb->get_row($wpdb->prepare("SELECT job_no FROM {$j} WHERE id=%d",$job_id),ARRAY_A):null;
            if(!$job) return new WP_Error('job_not_found','Job produksi tidak ditemukan.',['status'=>404]);
            $now=current_time('mysql');
            $wpdb->insert($rooms,['room_key'=>$key,'room_type'=>'production_job','title'=>'Komunikasi Job · '.($job['job_no']?:'Job '.$job_id),'job_id'=>$job_id,'created_by'=>$uid,'created_at'=>$now,'updated_at'=>$now]);
            $rid=(int)$wpdb->insert_id;
            $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$rooms} WHERE id=%d",$rid),ARRAY_A);
        }
        $parts=self::table('chat_participants');
        $exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$parts} WHERE room_id=%d AND user_id=%d",$r['id'],$uid));
        if(!$exists)$wpdb->insert($parts,['room_id'=>$r['id'],'user_id'=>$uid,'joined_at'=>current_time('mysql')]);
        // A Job room is a real operational room. Seed every assigned employee and the
        // Seller who owns the source order so they can communicate without an admin manually
        // adding participants. No user is invented; only existing linked accounts are added.
        $job_id=(int)$r['job_id'];
        $emp=self::table('employees'); $as=self::table('job_assignments');
        if($emp && $as){
            $users=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT e.user_id FROM {$as} ja INNER JOIN {$emp} e ON e.id=ja.employee_id WHERE ja.job_id=%d AND e.user_id>0",$job_id));
            foreach((array)$users as $pu){$pu=(int)$pu;if($pu && !$wpdb->get_var($wpdb->prepare("SELECT id FROM {$parts} WHERE room_id=%d AND user_id=%d",$r['id'],$pu)))$wpdb->insert($parts,['room_id'=>(int)$r['id'],'user_id'=>$pu,'joined_at'=>current_time('mysql')]);}
        }
        $jobs=self::table('jobs'); $so=self::table('seller_orders'); $sa=self::table('sales_accounts');
        if($jobs && $so && $sa){
            $seller_uid=$wpdb->get_var($wpdb->prepare("SELECT s.user_id FROM {$jobs} j INNER JOIN {$so} o ON o.id=j.source_order_id INNER JOIN {$sa} s ON s.id=o.seller_account_id WHERE j.id=%d AND j.source_type='seller_order' AND s.user_id>0 LIMIT 1",$job_id));
            if($seller_uid && !$wpdb->get_var($wpdb->prepare("SELECT id FROM {$parts} WHERE room_id=%d AND user_id=%d",$r['id'],$seller_uid)))$wpdb->insert($parts,['room_id'=>(int)$r['id'],'user_id'=>(int)$seller_uid,'joined_at'=>current_time('mysql')]);
        }
        return $r;
    }
    static function internal_allowed($r=null){
        if(!is_user_logged_in()) return false;
        $u=wp_get_current_user();
        $roles=(array)$u->roles;
        $allowed=['administrator','pk01_admin','pk01_owner','shop_manager','pk01_produksi','pk01_employee','pk01_gudang','pk01_logistik','pk01_hr','pk01_kasir','pk01_keuangan','pk01_packing','pk01_customer_service'];
        return current_user_can('manage_options') || (bool)array_intersect($allowed,$roles);
    }
    static function internal_room($r=null){
        global $wpdb; $rooms=self::table('chat_rooms'); $uid=self::actor_id($r);
        if(!$rooms || !$uid || !self::internal_allowed($r)) return new WP_Error('internal_chat_denied','Chat internal hanya untuk karyawan/staf perusahaan.',['status'=>403]);
        $key='internal:company';
        $room=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$rooms} WHERE room_key=%s LIMIT 1",$key),ARRAY_A);
        if(!$room){
            $now=current_time('mysql');
            $wpdb->insert($rooms,['room_key'=>$key,'room_type'=>'internal_company','title'=>'Chat Internal Perusahaan','job_id'=>null,'created_by'=>$uid,'created_at'=>$now,'updated_at'=>$now]);
            $room=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$rooms} WHERE id=%d",(int)$wpdb->insert_id),ARRAY_A);
        }
        $parts=self::table('chat_participants');
        if($parts && !$wpdb->get_var($wpdb->prepare("SELECT id FROM {$parts} WHERE room_id=%d AND user_id=%d",$room['id'],$uid)))
            $wpdb->insert($parts,['room_id'=>(int)$room['id'],'user_id'=>$uid,'joined_at'=>current_time('mysql')]);
        return $room;
    }
    static function get_internal($r){
        global $wpdb; $room=self::internal_room($r); if(is_wp_error($room))return $room;
        $m=self::table('chat_messages'); $limit=min(200,max(20,absint($r->get_param('limit')?:100)));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT m.id,m.message,m.reply_to,m.created_at,m.sender_id,u.display_name,u.user_login FROM {$m} m LEFT JOIN {$wpdb->users} u ON u.ID=m.sender_id WHERE m.room_id=%d ORDER BY m.id DESC LIMIT %d",$room['id'],$limit),ARRAY_A);
        return ['ok'=>true,'room'=>$room,'messages'=>array_reverse($rows),'current_user_id'=>get_current_user_id()];
    }
    static function send_internal($r){
        global $wpdb; $room=self::internal_room($r); if(is_wp_error($room))return $room;
        $p=$r->get_json_params()?:[]; $msg=trim(wp_strip_all_tags((string)($p['message']??'')));
        if($msg==='')return new WP_Error('empty_message','Pesan tidak boleh kosong.',['status'=>422]);
        if(mb_strlen($msg)>5000)return new WP_Error('message_too_long','Pesan maksimal 5.000 karakter.',['status'=>422]);
        $now=current_time('mysql'); $m=self::table('chat_messages');
        $wpdb->insert($m,['room_id'=>(int)$room['id'],'sender_id'=>get_current_user_id(),'message'=>$msg,'reply_to'=>absint($p['reply_to']??0)?:null,'created_at'=>$now]);
        $wpdb->update(self::table('chat_rooms'),['updated_at'=>$now],['id'=>(int)$room['id']]);
        return ['ok'=>true,'id'=>(int)$wpdb->insert_id,'created_at'=>$now];
    }
    static function list_rooms($r){
        if(!self::role_allowed($r)) return new WP_Error('chat_denied','Akses chat ditolak.',['status'=>403]);
        global $wpdb; $uid=self::actor_id($r); $rooms=self::table('chat_rooms'); $p=self::table('chat_participants'); $m=self::table('chat_messages');
        $out=[];
        if(self::internal_allowed($r)){
            $room=self::internal_room($r);
            if(!is_wp_error($room)){
                $un=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p} pp INNER JOIN {$m} mm ON mm.room_id=pp.room_id AND mm.id>pp.last_read_id AND mm.sender_id<>%d WHERE pp.room_id=%d AND pp.user_id=%d",$uid,$room['id'],$uid));
                $out[]=['type'=>'internal','id'=>(int)$room['id'],'title'=>'Chat Internal Perusahaan','subtitle'=>'Karyawan ↔ Karyawan','unread'=>$un];
            }
        }
        $jobs=self::table('jobs'); $a=self::table('job_assignments'); $e=self::table('employees'); $so=self::table('seller_orders'); $sa=self::table('sales_accounts'); $ji=self::table('job_items'); $v=self::table('product_variants'); $pr=self::table('products');
        if($jobs){
            $ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT j.id FROM {$jobs} j LEFT JOIN {$a} ja ON ja.job_id=j.id LEFT JOIN {$e} e ON e.id=ja.employee_id LEFT JOIN {$so} so ON so.id=j.source_order_id LEFT JOIN {$sa} sa ON sa.id=so.seller_account_id WHERE e.user_id=%d OR sa.user_id=%d ORDER BY j.id DESC LIMIT 50",$uid,$uid));
            foreach((array)$ids as $jid){
                $room=self::room((int)$jid,$r); if(is_wp_error($room))continue;
                $un=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p} pp INNER JOIN {$m} mm ON mm.room_id=pp.room_id AND mm.id>pp.last_read_id AND mm.sender_id<>%d WHERE pp.room_id=%d AND pp.user_id=%d",$uid,$room['id'],$uid));
                $prod=$wpdb->get_row($wpdb->prepare("SELECT j.job_no,pr.name product_name,v.sku FROM {$jobs} j LEFT JOIN {$ji} ji ON ji.job_id=j.id LEFT JOIN {$v} v ON v.id=ji.variant_id LEFT JOIN {$pr} pr ON pr.id=v.product_id WHERE j.id=%d LIMIT 1",(int)$jid),ARRAY_A);
                $out[]=['type'=>'job','id'=>(int)$jid,'title'=>$room['title'],'subtitle'=>trim(($prod['product_name']??'').' '.($prod['sku']??'')),'unread'=>$un];
            }
        }
        return ['ok'=>true,'rooms'=>$out];
    }
    static function read_internal($r){
        global $wpdb; $room=self::internal_room($r); if(is_wp_error($room))return $room; $p=$r->get_json_params()?:[];
        $wpdb->query($wpdb->prepare("UPDATE ".self::table('chat_participants')." SET last_read_id=GREATEST(last_read_id,%d) WHERE room_id=%d AND user_id=%d",absint($p['last_read_id']??0),$room['id'],get_current_user_id()));
        return ['ok'=>true];
    }

    static function routes(){
        register_rest_route(self::NS,'/chat/job/(?P<id>\d+)',['methods'=>'GET','permission_callback'=>function($r){return self::can_job((int)$r['id'],$r);},'callback'=>[__CLASS__,'get_job']]);
        register_rest_route(self::NS,'/chat/job/(?P<id>\d+)/send',['methods'=>'POST','permission_callback'=>function($r){return self::can_job((int)$r['id'],$r);},'callback'=>[__CLASS__,'send_job']]);
        register_rest_route(self::NS,'/chat/job/(?P<id>\d+)/read',['methods'=>'POST','permission_callback'=>function($r){return self::can_job((int)$r['id'],$r);},'callback'=>[__CLASS__,'read_job']]);
        register_rest_route(self::NS,'/chat/rooms',['methods'=>'GET','permission_callback'=>function($r){return self::role_allowed($r);},'callback'=>[__CLASS__,'list_rooms']]);
        register_rest_route(self::NS,'/chat/internal',['methods'=>'GET','permission_callback'=>function($r){return self::internal_allowed($r);},'callback'=>[__CLASS__,'get_internal']]);
        register_rest_route(self::NS,'/chat/internal/send',['methods'=>'POST','permission_callback'=>function($r){return self::internal_allowed($r);},'callback'=>[__CLASS__,'send_internal']]);
        register_rest_route(self::NS,'/chat/internal/read',['methods'=>'POST','permission_callback'=>function($r){return self::internal_allowed($r);},'callback'=>[__CLASS__,'read_internal']]);
        self::customer_routes();
        register_rest_route(self::NS,'/chat/unread',['methods'=>'GET','permission_callback'=>function($r){return self::role_allowed($r);},'callback'=>[__CLASS__,'unread']]);
    }
    static function get_job($r){
        global $wpdb; $room=self::room((int)$r['id'],$r); if(is_wp_error($room))return $room;
        $m=self::table('chat_messages'); $limit=min(200,max(20,absint($r->get_param('limit')?:100)));
        $rows=$wpdb->get_results($wpdb->prepare(
            "SELECT m.id,m.message,m.reply_to,m.created_at,m.sender_id,u.display_name,u.user_login
             FROM {$m} m LEFT JOIN {$wpdb->users} u ON u.ID=m.sender_id
             WHERE m.room_id=%d ORDER BY m.id DESC LIMIT %d",$room['id'],$limit
        ),ARRAY_A);
        return ['ok'=>true,'room'=>$room,'messages'=>array_reverse($rows),'current_user_id'=>self::actor_id($r)];
    }
    static function send_job($r){
        global $wpdb; $room=self::room((int)$r['id'],$r); if(is_wp_error($room))return $room;
        $p=$r->get_json_params()?:[]; $msg=trim(wp_strip_all_tags((string)($p['message']??'')));
        if($msg==='')return new WP_Error('empty_message','Pesan tidak boleh kosong.',['status'=>422]);
        if(mb_strlen($msg)>5000)return new WP_Error('message_too_long','Pesan maksimal 5.000 karakter.',['status'=>422]);
        $m=self::table('chat_messages'); $now=current_time('mysql');
        $wpdb->insert($m,['room_id'=>(int)$room['id'],'sender_id'=>self::actor_id($r),'message'=>$msg,'reply_to'=>absint($p['reply_to']??0)?:null,'created_at'=>$now]);
        $id=(int)$wpdb->insert_id;
        $rooms=self::table('chat_rooms'); $wpdb->update($rooms,['updated_at'=>$now],['id'=>(int)$room['id']]);
        if(class_exists('PK01_Audit'))PK01_Audit::info('chat_message','production','Pesan chat Job '.$room['job_id'],'chat_room',(string)$room['id']);
        return ['ok'=>true,'id'=>$id,'created_at'=>$now];
    }
    static function read_job($r){
        global $wpdb; $room=self::room((int)$r['id'],$r); if(is_wp_error($room))return $room;
        $p=self::table('chat_participants'); $last=absint(($r->get_json_params()['last_read_id']??0));
        $wpdb->query($wpdb->prepare("UPDATE {$p} SET last_read_id=GREATEST(last_read_id,%d) WHERE room_id=%d AND user_id=%d",$last,$room['id'],self::actor_id($r)));
        return ['ok'=>true];
    }
    static function unread($r){
        self::maybe_install_customer_chat();
        global $wpdb; $p=self::table('chat_participants'); $m=self::table('chat_messages'); $uid=self::actor_id($r);
        // Pastikan user menerima notice walaupun belum pernah membuka ruang chat tersebut.
        // Peserta tetap berasal dari Job nyata: assignment karyawan atau Seller pemilik order.
        $j=self::table('jobs'); $a=self::table('job_assignments'); $e=self::table('employees'); $so=self::table('seller_orders'); $sa=self::table('sales_accounts');
        if($uid && $j){
            if(current_user_can('manage_options')){
                $ids=$wpdb->get_col("SELECT id FROM {$j} ORDER BY id DESC LIMIT 100");
            }else{
                $ids=$wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT j.id FROM {$j} j LEFT JOIN {$a} ja ON ja.job_id=j.id LEFT JOIN {$e} e ON e.id=ja.employee_id LEFT JOIN {$so} so ON so.id=j.source_order_id LEFT JOIN {$sa} sa ON sa.id=so.seller_account_id WHERE e.user_id=%d OR sa.user_id=%d LIMIT 100",$uid,$uid
                ));
            }
            foreach((array)$ids as $jid){ self::room((int)$jid,$r); }
            if(self::internal_allowed($r)) self::internal_room($r);
        }
        $rows=$wpdb->get_results($wpdb->prepare(
            "SELECT p.room_id,COUNT(m.id) unread FROM {$p} p INNER JOIN {$m} m ON m.room_id=p.room_id AND m.id>p.last_read_id AND m.sender_id<>%d WHERE p.user_id=%d GROUP BY p.room_id",$uid,$uid
        ),ARRAY_A);
        return ['ok'=>true,'rooms'=>$rows,'total'=>array_sum(array_map(function($x){return (int)$x['unread'];},$rows))];
    }
    public static function floating_widget(){
        $rest=esc_url_raw(rest_url('pk01/v1'));
        $wa='';
        if(class_exists('PK01_Settings')) $wa=(string)PK01_Settings::get('company_whatsapp','');
        if($wa==='') $wa=(string)get_option('pk01_company_whatsapp','');
        $wa=preg_replace('/\D+/','',$wa);
        // Semua halaman PK01 internal yang memakai ?pk01_view=... harus memakai Chat PK01.
        // Customer Care hanya ditampilkan pada Theme/public website tanpa pk01_view.
        $internal_view = is_user_logged_in() && isset($_GET['pk01_view']) && sanitize_key($_GET['pk01_view']) !== '';
        if($internal_view){
            $roles=(array)wp_get_current_user()->roles;
            $allowed=['administrator','pk01_admin','pk01_owner','shop_manager','pk01_produksi','pk01_employee','pk01_gudang','pk01_logistik','pk01_hr','pk01_kasir','pk01_keuangan','pk01_seller','pk01_packing','pk01_customer_service'];
            if(!array_intersect($allowed,$roles) && !current_user_can('manage_options')) return;
            ?>
            <div id="pk01FloatChat" class="pk01-float-chat pk01-float-internal">
              <button type="button" class="pk01-float-chat-btn" aria-label="Buka Chat PK01"><span>💬</span><b>Chat</b><em id="pk01FloatBadge" hidden>0</em></button>
              <div class="pk01-float-panel" hidden>
                <div class="pk01-float-head"><div><strong>Chat PK01</strong><small id="pk01FloatSub">Komunikasi kerja</small></div><button type="button" data-close>×</button></div>
                <div class="pk01-float-layout">
                  <div class="pk01-float-rooms" id="pk01FloatRooms"><div class="pk01-float-empty">Memuat percakapan...</div></div>
                  <div class="pk01-float-conv">
                    <div class="pk01-float-conv-head" id="pk01FloatTitle">Pilih percakapan</div>
                    <div class="pk01-float-msgs" id="pk01FloatMsgs"><div class="pk01-float-empty">Pilih chat di sebelah kiri.</div></div>
                    <form id="pk01FloatForm"><input id="pk01FloatInput" maxlength="5000" placeholder="Tulis pesan..." disabled><button type="submit" disabled>Kirim</button></form>
                  </div>
                </div>
                <a class="pk01-float-open" href="<?php echo esc_url(PK01_Shortcodes::frontend_url_public('communications')); ?>">Buka semua percakapan →</a>
              </div>
            </div>
            <style>
            .pk01-float-chat{position:fixed;right:22px;bottom:22px;z-index:99999;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.pk01-float-chat-btn{position:relative;border:0;border-radius:28px;padding:12px 18px;background:#111827;color:#fff;box-shadow:0 8px 25px rgba(0,0,0,.2);cursor:pointer;display:flex;gap:8px;align-items:center}.pk01-float-chat-btn span{font-size:19px}.pk01-float-chat-btn em{position:absolute;right:-5px;top:-6px;min-width:21px;height:21px;padding:0 5px;border-radius:12px;background:#ef4444;color:#fff;font-size:11px;font-style:normal;display:flex;align-items:center;justify-content:center}.pk01-float-panel{position:absolute;right:0;bottom:55px;width:430px;height:520px;background:#fff;border:1px solid #e5e7eb;border-radius:16px;box-shadow:0 15px 45px rgba(15,23,42,.25);overflow:hidden}.pk01-float-head{height:54px;padding:0 14px;background:#111827;color:#fff;display:flex;justify-content:space-between;align-items:center}.pk01-float-head small{display:block;color:#cbd5e1;font-size:10px;margin-top:2px}.pk01-float-head button{background:none;border:0;color:#fff;font-size:24px;cursor:pointer}.pk01-float-layout{display:grid;grid-template-columns:145px 1fr;height:415px}.pk01-float-rooms{border-right:1px solid #e5e7eb;background:#f8fafc;overflow:auto;padding:8px}.pk01-float-room{width:100%;text-align:left;border:0;background:#fff;border-radius:9px;padding:9px;margin-bottom:7px;cursor:pointer;border:1px solid #e5e7eb}.pk01-float-room.active{background:#eff6ff;border-color:#93c5fd}.pk01-float-room b{font-size:12px;display:block}.pk01-float-room span{font-size:10px;color:#64748b;display:block;margin-top:2px}.pk01-float-room em{float:right;background:#ef4444;color:#fff;border-radius:10px;font-size:9px;padding:2px 5px;font-style:normal}.pk01-float-conv{min-width:0;display:flex;flex-direction:column}.pk01-float-conv-head{padding:10px 12px;font-weight:800;border-bottom:1px solid #e5e7eb;font-size:13px}.pk01-float-msgs{flex:1;overflow:auto;padding:10px;background:#f8fafc}.pk01-float-msg{max-width:82%;padding:8px 10px;border-radius:11px;background:#fff;border:1px solid #e5e7eb;margin-bottom:7px;font-size:12px}.pk01-float-msg.mine{margin-left:auto;background:#eff6ff;border-color:#bfdbfe}.pk01-float-msg small{display:block;color:#94a3b8;font-size:9px;margin-top:3px}.pk01-float-empty{color:#64748b;font-size:11px;padding:12px;text-align:center}.pk01-float-conv form{display:flex;gap:6px;padding:8px;border-top:1px solid #e5e7eb}.pk01-float-conv input{min-width:0;flex:1;padding:9px;border:1px solid #cbd5e1;border-radius:9px}.pk01-float-conv form button{border:0;border-radius:9px;background:#2563eb;color:#fff;padding:0 11px;font-weight:700}.pk01-float-open{display:block;height:50px;box-sizing:border-box;text-align:center;padding:15px;background:#fff;border-top:1px solid #e5e7eb;color:#1d4ed8;text-decoration:none;font-weight:700;font-size:12px}@media(max-width:600px){.pk01-float-chat{right:12px;bottom:12px}.pk01-float-panel{width:min(430px,calc(100vw - 24px));height:min(520px,calc(100vh - 90px))}.pk01-float-layout{grid-template-columns:125px 1fr}}
            </style>
            <script>(function(){const root=document.getElementById('pk01FloatChat');if(!root)return;const rest='<?php echo esc_js($rest); ?>',btn=root.querySelector('.pk01-float-chat-btn'),panel=root.querySelector('.pk01-float-panel'),close=root.querySelector('[data-close]'),rooms=root.querySelector('#pk01FloatRooms'),msgs=root.querySelector('#pk01FloatMsgs'),title=root.querySelector('#pk01FloatTitle'),form=root.querySelector('#pk01FloatForm'),input=root.querySelector('#pk01FloatInput'),send=form.querySelector('button'),badge=root.querySelector('#pk01FloatBadge');let activeType='',activeId=0;function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}function setActive(t,id){activeType=t;activeId=Number(id)}async function loadRooms(){try{const r=await fetch(rest+'/chat/rooms',{credentials:'same-origin'}),j=await r.json();if(!r.ok)throw new Error(j.message||'Chat tidak tersedia');const rows=j.rooms||[];const total=rows.reduce((n,x)=>n+Number(x.unread||0),0);badge.textContent=total>99?'99+':total;badge.hidden=total<1;rooms.innerHTML=rows.length?rows.map(x=>'<button type="button" class="pk01-float-room" data-t="'+esc(x.type)+'" data-i="'+Number(x.id)+'"><em '+(Number(x.unread)?'':'hidden')+'>'+Number(x.unread)+'</em><b>'+esc(x.type==='internal'?'🏢 Chat Internal':(x.title||'Chat Job'))+'</b><span>'+esc(x.subtitle||'Komunikasi kerja')+'</span></button>').join(''):'<div class="pk01-float-empty">Belum ada percakapan.</div>';rooms.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>openRoom(b.dataset.t,Number(b.dataset.i)));}catch(e){rooms.innerHTML='<div class="pk01-float-empty">'+esc(e.message)+'</div>'}}async function openRoom(t,id){setActive(t,id);rooms.querySelectorAll('.pk01-float-room').forEach(b=>b.classList.toggle('active',b.dataset.t===t&&Number(b.dataset.i)===Number(id)));msgs.innerHTML='<div class="pk01-float-empty">Memuat...</div>';try{let url=t==='internal'?rest+'/chat/internal':rest+'/chat/job/'+id;const r=await fetch(url,{credentials:'same-origin'}),j=await r.json();if(!r.ok)throw new Error(j.message||'Akses chat ditolak');title.textContent=j.room?.title||'Chat';msgs.innerHTML=(j.messages||[]).map(m=>'<div class="pk01-float-msg '+(Number(m.sender_id)===Number(j.current_user_id)?'mine':'')+'"><b>'+esc(m.display_name||m.user_login||'Pengguna')+'</b><div>'+esc(m.message)+'</div><small>'+esc(m.created_at||'')+'</small></div>').join('')||'<div class="pk01-float-empty">Belum ada pesan.</div>';msgs.scrollTop=msgs.scrollHeight;input.disabled=false;send.disabled=false;const last=(j.messages||[]).length?Number(j.messages[j.messages.length-1].id):0;if(last){fetch(t==='internal'?rest+'/chat/internal/read':rest+'/chat/job/'+id+'/read',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({last_read_id:last})}).catch(()=>{})}}catch(e){input.disabled=true;send.disabled=true;msgs.innerHTML='<div class="pk01-float-empty">'+esc(e.message)+'</div>'}}form.onsubmit=async e=>{e.preventDefault();const v=input.value.trim();if(!v||!activeType)return;send.disabled=true;try{const url=activeType==='internal'?rest+'/chat/internal/send':rest+'/chat/job/'+activeId+'/send';const r=await fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:v})}),j=await r.json();if(!r.ok)throw new Error(j.message||'Gagal mengirim');input.value='';await openRoom(activeType,activeId);await loadRooms()}catch(e){alert(e.message)}finally{send.disabled=false}}btn.onclick=()=>{panel.hidden=!panel.hidden;if(!panel.hidden)loadRooms()};close.onclick=()=>panel.hidden=true;loadRooms();setInterval(loadRooms,15000);if(document.visibilityState==='visible')setInterval(()=>{if(!panel.hidden&&activeType)openRoom(activeType,activeId)},12000)})();</script>
            <?php
            return;
        }
        // Public theme: customer support launcher. No login required.
        $wa_url=$wa!==''?'https://wa.me/'.$wa.'?text='.rawurlencode('Halo, saya ingin bertanya tentang produk Dekora Living.') : '';
        ?>
        <div id="pk01CustomerChat" class="pk01-customer-launcher"><button type="button" class="pk01-customer-btn" aria-label="Hubungi CS"><span>💬</span><b>Butuh bantuan?</b><em id="pk01CustomerBadge" hidden>!</em></button><div class="pk01-customer-panel" hidden><div class="pk01-customer-head"><div><strong>Customer Care</strong><small>Biasanya kami membalas secepatnya</small></div><button type="button" data-close>×</button></div><div class="pk01-customer-actions"><?php if($wa_url): ?><a class="pk01-customer-wa" target="_blank" rel="noopener" href="<?php echo esc_url($wa_url); ?>">🟢 Chat WhatsApp CS</a><?php endif; ?><button type="button" class="pk01-customer-web" data-open-web>💬 Chat langsung di website</button></div><div class="pk01-customer-webbox" hidden><div class="pk01-customer-messages" id="pk01CustomerMessages"><div class="pk01-customer-muted">Sampaikan pertanyaan Anda. Tim kami akan membalas melalui chat ini.</div></div><form id="pk01CustomerForm"><input id="pk01CustomerName" placeholder="Nama Anda" maxlength="120"><input id="pk01CustomerPhone" placeholder="No. WhatsApp (opsional)" maxlength="40"><textarea id="pk01CustomerInput" placeholder="Tulis pesan..." maxlength="3000" required></textarea><button type="submit">Kirim Pesan</button></form></div></div></div>
        <style>.pk01-customer-launcher{position:fixed;left:22px;bottom:22px;z-index:99999;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.pk01-customer-btn{border:0;border-radius:28px;padding:12px 18px;background:#111827;color:#fff;box-shadow:0 8px 25px rgba(0,0,0,.22);cursor:pointer;display:flex;align-items:center;gap:8px;position:relative}.pk01-customer-btn span{font-size:19px}.pk01-customer-btn em{position:absolute;right:-5px;top:-6px;background:#ef4444;color:#fff;border-radius:12px;min-width:21px;height:21px;font-style:normal;font-size:11px;display:flex;align-items:center;justify-content:center}.pk01-customer-panel{position:absolute;left:0;bottom:55px;width:340px;background:#fff;border:1px solid #e5e7eb;border-radius:17px;box-shadow:0 18px 50px rgba(15,23,42,.24);overflow:hidden}.pk01-customer-head{background:#111827;color:#fff;padding:14px 16px;display:flex;justify-content:space-between}.pk01-customer-head small{display:block;color:#cbd5e1;font-size:11px;margin-top:2px}.pk01-customer-head button{background:none;border:0;color:#fff;font-size:22px;cursor:pointer}.pk01-customer-actions{padding:14px;display:grid;gap:9px}.pk01-customer-actions a,.pk01-customer-actions button{display:block;text-decoration:none;text-align:center;border:0;border-radius:10px;padding:11px;font-weight:700;cursor:pointer}.pk01-customer-wa{background:#dcfce7;color:#166534}.pk01-customer-web{background:#eff6ff;color:#1d4ed8}.pk01-customer-webbox{padding:0 14px 14px}.pk01-customer-messages{height:230px;overflow:auto;border:1px solid #e5e7eb;border-radius:11px;padding:10px;background:#f8fafc}.pk01-customer-message{padding:8px 10px;border-radius:10px;background:#fff;border:1px solid #e5e7eb;margin-bottom:7px;font-size:13px}.pk01-customer-message.staff{background:#eff6ff}.pk01-customer-muted{color:#64748b;font-size:12px}.pk01-customer-webbox form{display:grid;gap:7px;margin-top:8px}.pk01-customer-webbox input,.pk01-customer-webbox textarea{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:9px;padding:9px}.pk01-customer-webbox textarea{min-height:70px;resize:vertical}.pk01-customer-webbox button{border:0;border-radius:9px;padding:10px;background:#111827;color:#fff;font-weight:700}@media(max-width:600px){.pk01-customer-launcher{left:12px;bottom:12px}.pk01-customer-panel{width:min(340px,calc(100vw - 24px))}}</style>
        <script>(function(){const root=document.getElementById('pk01CustomerChat');if(!root)return;const btn=root.querySelector('.pk01-customer-btn'),panel=root.querySelector('.pk01-customer-panel'),close=root.querySelector('[data-close]'),web=root.querySelector('[data-open-web]'),box=root.querySelector('.pk01-customer-webbox'),form=root.querySelector('#pk01CustomerForm'),msgs=root.querySelector('#pk01CustomerMessages'),rest='<?php echo esc_js($rest); ?>';let threadId=0,token='';try{token=sessionStorage.getItem('pk01_customer_chat_token')||'';threadId=Number(sessionStorage.getItem('pk01_customer_chat_thread')||0)}catch(e){}btn.onclick=()=>panel.hidden=!panel.hidden;close.onclick=()=>panel.hidden=true;web.onclick=()=>{box.hidden=!box.hidden;if(!box.hidden)load()};function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}function render(j){msgs.innerHTML=(j.messages||[]).map(m=>'<div class="pk01-customer-message '+(m.sender_type==='staff'?'staff':'')+'"><b>'+(m.sender_type==='staff'?'CS':'Anda')+'</b><div>'+esc(m.message)+'</div><small class="pk01-customer-muted">'+esc(m.created_at||'')+'</small></div>').join('')||'<div class="pk01-customer-muted">Belum ada pesan.</div>';msgs.scrollTop=msgs.scrollHeight}async function load(){if(!threadId||!token)return;try{const r=await fetch(rest+'/customer-chat/thread/'+threadId+'?token='+encodeURIComponent(token));const j=await r.json();if(r.ok)render(j)}catch(e){}}form.onsubmit=async e=>{e.preventDefault();const input=document.getElementById('pk01CustomerInput'),msg=input.value.trim();if(!msg)return;const body={message:msg};if(threadId&&token){body.token=token;try{const r=await fetch(rest+'/customer-chat/thread/'+threadId+'/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok)throw new Error();input.value='';await load();return}catch(e){}}try{const r=await fetch(rest+'/customer-chat/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:document.getElementById('pk01CustomerName').value.trim(),phone:document.getElementById('pk01CustomerPhone').value.trim(),message:msg})});const j=await r.json();if(!r.ok)throw new Error(j.message||'Gagal membuat chat');threadId=Number(j.thread_id);token=j.token;try{sessionStorage.setItem('pk01_customer_chat_thread',threadId);sessionStorage.setItem('pk01_customer_chat_token',token)}catch(e){}input.value='';await load()}catch(e){alert(e.message)}};if(threadId&&token){web.textContent='💬 Lanjutkan Chat';setInterval(load,12000);load()}})();</script>
        <?php
    }

}
