# PK01 — Modul Production

Folder canonical: `includes/modules/production/`

## Aturan maintenance
- Semua UI dan logic khusus domain ini ditempatkan di folder ini.
- Jangan menyalin class/engine shared dari `includes/core/` ke folder ini.
- Jika perubahan hanya untuk domain ini, mulai pencarian dari folder ini.
- Jika perubahan menyentuh permission/menu lintas domain, cek `includes/core/class-pk01-authorization.php` dan `includes/core/class-pk01-module-registry.php`.

## Isi folder saat ini
- `includes/modules/production/core/class-pk01-dodi-chat.php`
- `includes/modules/production/core/class-pk01-dodi-cnc.php`
- `includes/modules/production/employee-jobs/tampilan-penerimaan-job-karyawan.php`
- `includes/modules/production/job-wages/tampilan-upah-job.php`
- `includes/modules/production/jobs/tampilan-produksi.php`

## Catatan
File di `includes/core/` tetap menjadi dependency bersama dan bukan duplikasi modul.

- `includes/modules/production/cnc-library/class-pk01-cnc-library.php`
  - Master G-code CNC per produk/varian.
  - Prioritas pencocokan: variant/SKU → product → material.
  - G-code diberikan manual ke CNC; modul ini tidak membuat/mengubah G-code CAM.
