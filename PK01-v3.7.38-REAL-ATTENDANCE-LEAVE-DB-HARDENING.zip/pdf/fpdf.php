<?php
/** PK01 compatibility shim. Canonical FPDF library lives in /fpdf/fpdf.php. */
if (!class_exists('FPDF', false)) { require_once dirname(__DIR__) . '/fpdf/fpdf.php'; }
