(function(){'use strict';
 function init(){
  document.documentElement.classList.add('pk01-fullscreen-ready');
  document.body.classList.add('pk01-fullscreen-ready');
  document.querySelectorAll('.pk01-menu-toggle').forEach(function(btn){
   btn.addEventListener('click',function(){
    var app=btn.closest('.pk01-op-app'); if(!app)return;
    var open=app.classList.toggle('sidebar-open');
    btn.setAttribute('aria-expanded',open?'true':'false');
   });
  });
  document.querySelectorAll('.pk01-side-link').forEach(function(a){a.addEventListener('click',function(){var app=a.closest('.pk01-op-app');if(app)app.classList.remove('sidebar-open');});});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* PK01 Profit Distribution: preview uses current undistributed profit and per-distribution manual percentages. */
document.addEventListener('input', function(e){
  if (!e.target.matches('input[name^="distribution_share["]')) return;
  var card=e.target.closest('.pk01-op-card');
  if(!card) return;
  var availableText=card.querySelector('.pk01-op-grid-3 div:nth-child(3) h3');
  if(!availableText) return;
  var raw=(availableText.textContent||'').replace(/[^0-9]/g,'');
  var available=parseFloat(raw||'0');
  var row=e.target.closest('tr'); var out=row && row.querySelector('.pk01-distribution-preview');
  if(out) out.textContent='Rp '+Math.round(available*(parseFloat(e.target.value||0)/100)).toLocaleString('id-ID');
});


// PK01 Data Governance: destructive actions always require an explicit confirmation.
document.addEventListener('submit', function(e){
  var f=e.target; if(!f || !f.querySelector) return;
  var a=f.querySelector('input[name$="_action"]'); var v=a ? String(a.value||'').toLowerCase() : '';
  if(['delete','remove','purge','purge_all','destroy','erase','rollback','reverse','correct'].indexOf(v)!==-1){
    if(!window.confirm('Konfirmasi Administrator: tindakan ini mengubah atau menghapus data PK01. Lanjutkan?')) e.preventDefault();
  }
}, true);

/* PK01 v3.6.47 — Universal product/resi/batch scanner */
(function(){'use strict';
function initOpsTools(){
 document.querySelectorAll('.pk01-ops-command').forEach(function(root){
  if(root.dataset.ready==='1') return; root.dataset.ready='1';
  var base=root.getAttribute('data-rest-base')||''; var nonce=root.getAttribute('data-rest-nonce')||'';
  var input=root.querySelector('.pk01-universal-search'), results=root.querySelector('.pk01-lookup-results');
  var active='product', video=root.querySelector('.pk01-scanner-video'), panel=root.querySelector('.pk01-scanner-panel'), stream=null, timer=null;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]})}
  function show(msg,ok){results.innerHTML='<div style="padding:10px;border:1px solid '+(ok?'#bbf7d0':'#fecaca')+';background:'+(ok?'#f0fdf4':'#fef2f2')+';border-radius:9px;color:'+(ok?'#166534':'#991b1b')+';font-size:12px">'+esc(msg)+'</div>';}
  function lookup(q){q=(q||input.value||'').trim(); try{if(/^https?:\/\//i.test(q)){var u=new URL(q);var c=u.searchParams.get('pk01_unit')||u.searchParams.get('pk01_production')||u.searchParams.get('pk01_batch');if(c)q=c;}}catch(e){} if(q.length<2){show('Masukkan minimal 2 karakter.',false);return;} results.innerHTML='<div style="padding:12px;color:#64748b;font-size:12px">Mencari data PK01...</div>';
   if(active==='resi'){ fetch(base+'shipping/track?waybill='+encodeURIComponent(q)+'&courier=auto').then(function(r){return r.json()}).then(function(d){ if(d&&d.success!==false&&d.code!=='pk01_not_found'){results.innerHTML='<div class="pk01-lookup-item"><div><strong>Resi '+esc(q)+'</strong><div class="pk01-lookup-meta">'+esc(d.status||d.message||'Data tracking diterima')+'</div></div></div>';} else show((d&&d.message)||'Resi tidak ditemukan.',false);}).catch(function(){show('Koneksi tracking gagal. Silakan coba lagi.',false);}); return; }
   if(active==='batch'){ lookupBatch(q); return; }
   fetch(base+'lookup/product?q='+encodeURIComponent(q),{headers:{'X-WP-Nonce':nonce}}).then(function(r){return r.json()}).then(function(d){var items=d&&d.items?d.items:[];if(!items.length){show('Produk tidak ditemukan.',false);return;}results.innerHTML=items.map(function(x){return '<div class="pk01-lookup-item"><div><strong>'+esc(x.product_name)+'</strong><div class="pk01-lookup-meta">SKU '+esc(x.sku)+' · '+esc(x.variant_name||'')+' · Stok '+esc(x.stock)+'</div></div><span style="font-size:11px;font-weight:800;color:#2563eb">'+esc(x.product_code)+'</span></div>';}).join('');}).catch(function(){show('Pencarian produk gagal. Periksa koneksi PK01.',false);});
  }
  function lookupBatch(q){fetch(base+'production/identity/'+encodeURIComponent(q),{headers:{'X-WP-Nonce':nonce}}).then(function(r){return r.json()}).then(function(d){if(!d||d.code){show((d&&d.message)||'Kode produksi/CNC tidak ditemukan.',false);return;}results.innerHTML='<div class="pk01-lookup-item"><div><strong>'+esc(d.type==='cnc_unit'?d.cnc_code:d.production_code)+'</strong><div class="pk01-lookup-meta">'+esc(d.product_name)+' · '+esc(d.size||'-')+' · SKU '+esc(d.sku||'-')+' · Job '+esc(d.job_no||'-')+'</div><div class="pk01-lookup-meta">Produksi '+esc(d.production_date||'-')+' · Batch '+esc(d.batch_code||'-')+(d.unit_no?' · Unit '+esc(d.unit_no):'')+'</div></div><span style="font-size:11px;font-weight:800;color:#059669">'+esc(d.status||'tercatat')+'</span></div>';}).catch(function(){show('Pencarian identitas produksi gagal.',false);});}
  root.querySelectorAll('.pk01-lookup-tabs button').forEach(function(b){b.addEventListener('click',function(){root.querySelectorAll('.pk01-lookup-tabs button').forEach(function(x){x.classList.remove('is-active')});b.classList.add('is-active');active=b.getAttribute('data-lookup')||'product';input.placeholder=active==='resi'?'Masukkan nomor resi...':active==='batch'?'Masukkan kode batch / Job...':'Cari SKU, kode produk, nama produk...';input.focus();});});
  root.querySelector('.pk01-lookup-submit').addEventListener('click',function(){lookup(input.value)}); input.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();lookup(input.value)}});
  function stop(){if(timer){clearInterval(timer);timer=null;}if(stream){stream.getTracks().forEach(function(t){t.stop()});stream=null;}if(video)video.srcObject=null;}
  function start(){panel.hidden=false;if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){show('Kamera tidak tersedia di browser ini. Gunakan input manual.',false);return;} if(!('BarcodeDetector' in window)){show('Browser belum mendukung pembacaan barcode/QR native. Gunakan Chrome/Edge terbaru atau input manual.',false);return;} navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false}).then(function(st){stream=st;video.srcObject=st;video.play();var detector=new BarcodeDetector({formats:['qr_code','code_128','code_39','ean_13','ean_8','upc_a','upc_e','itf','data_matrix','codabar']}); timer=setInterval(function(){detector.detect(video).then(function(codes){if(codes&&codes[0]&&codes[0].rawValue){input.value=codes[0].rawValue;stop();panel.hidden=true;lookup(codes[0].rawValue);}}).catch(function(){});},450);}).catch(function(){show('Izin kamera ditolak atau kamera tidak tersedia. Masukkan kode secara manual.',false);});}
  root.querySelector('.pk01-open-scanner').addEventListener('click',start);root.querySelector('.pk01-scanner-close').addEventListener('click',function(){stop();panel.hidden=true;});
  root.addEventListener('DOMNodeRemoved',stop);
 });
 document.querySelectorAll('.pk01-barcode[data-barcode]').forEach(function(el){if(el.dataset.rendered==='1')return;el.dataset.rendered='1';renderCode39(el,el.getAttribute('data-barcode')||'');});
 document.querySelectorAll('.pk01-qr-preview[data-qr]').forEach(function(el){if(el.dataset.rendered==='1')return;el.dataset.rendered='1';loadQR(el,el.getAttribute('data-qr')||'');});
 document.querySelectorAll('.pk01-copy-batch').forEach(function(b){b.addEventListener('click',function(){var card=b.closest('.pk01-batch-result-card'),code=card&&card.getAttribute('data-batch-code');if(code&&navigator.clipboard)navigator.clipboard.writeText(code).then(function(){b.textContent='Tersalin ✓';setTimeout(function(){b.textContent='Salin Kode'},1400);});});});
}
function renderCode39(el,value){var patterns={'0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw','5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn','A':'wnnnnwnnw','B':'nnwnnwnnw','C':'wnwnnwnnn','D':'nnnnwwnnw','E':'wnnnwwnnn','F':'nnwnwwnnn','G':'nnnnnwwnw','H':'wnnnnwwnn','I':'nnwnnwwnn','J':'nnnnwwwnn','K':'wnnnnnnww','L':'nnwnnnnww','M':'wnwnnnnwn','N':'nnnnwnnww','O':'wnnnwnnwn','P':'nnwnwnnwn','Q':'nnnnnnwww','R':'wnnnnnwwn','S':'nnwnnnwwn','T':'nnnnwnwwn','U':'wwnnnnnnw','V':'nwwnnnnnw','W':'wwwnnnnnn','X':'nwnnwnnnw','Y':'wwnnwnnnn','Z':'nwwnwnnnn','-':'nwnnnnwnw','.':'wwnnnnwnn',' ':'nwwnnnwnn','$':'nwnwnwnnn','/':'nwnwnnnwn','+':'nwnnnwnwn','%':'nnnwnwnwn','*':'nwnnwnwnn'};value=String(value||'').toUpperCase().replace(/[^0-9A-Z. \-$\/+%]/g,'-');var text='*'+value+'*',x=8,unit=2,bars=[];for(var c=0;c<text.length;c++){var pat=patterns[text[c]]||patterns['-'];for(var i=0;i<9;i++){var w=(pat[i]==='w'?3:1)*unit;if(i%2===0)bars.push('<rect x="'+x+'" y="8" width="'+w+'" height="52"/>');x+=w;}x+=unit;}var width=x+8;el.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+width+' 68" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Barcode '+String(value).replace(/&/g,'&amp;')+'"><rect width="100%" height="100%" fill="#fff"/>'+bars.join('')+'</svg>';}
function loadQR(el,value){function go(){if(window.QRCode){new QRCode(el,{text:value,width:120,height:120,correctLevel:QRCode.CorrectLevel.M});return;}var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';s.onload=go;s.onerror=function(){el.innerHTML='<small style="color:#64748b;text-align:center;padding:8px">QR gagal dimuat. Barcode tetap tersedia.</small>';};document.head.appendChild(s);}go();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initOpsTools);else initOpsTools();
})();
