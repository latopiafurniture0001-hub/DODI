PK01 v3.7.32 — Chat Messenger + Internal Company Chat

# PK01 Operasional — v3.6.74 Production Clean

## Prinsip
PK01 memakai satu sumber data/database dan satu Engine untuk seluruh alur. Folder mengelompokkan kode berdasarkan pekerjaan bisnis; folder bukan database baru.

## Peta coding
```text
includes/
├── core/                       # Engine, DB, workflow, security, registry, bridge
└── modules/
    ├── admin/                  # Administrasi, master data, dokumen, user, settings
    ├── ai/                     # AI assistant & center
    ├── customer-service/       # CS, kanal, dashboard
    ├── finance/                # Kas, keuangan, closing, laporan, biaya, modal
    ├── hr/                     # Karyawan, absensi, payroll
    ├── inventory/              # Produk, bahan, stok, aset, manajemen inventory
    ├── warehouse/              # SEMUA proses fisik barang
    │   ├── dashboard/          # Pintu barang, barang masuk/keluar, tanda terima, QC
    │   └── returns/            # Retur masuk, scan retur, tanda terima retur, QC retur
    ├── logistics/              # Fulfillment setelah gudang
    │   ├── packing/            # Packing
    │   ├── shipping/           # Resi & pengiriman
    │   └── tracking/           # Tracking
    ├── marketplace/            # Rekonsiliasi marketplace
    ├── owner/                  # Dashboard & modal owner
    ├── production/             # Job produksi & upah
    ├── purchasing/             # PO & supplier
    ├── sales/                  # Penjualan, pelanggan, harga
    ├── security/               # Security/CCTV
    └── seller/                 # Seller, portal, pendaftaran
```

## Lokasi update paling sering
- Retur: `includes/modules/warehouse/returns/`
- Gudang: `includes/modules/warehouse/dashboard/`
- Kasir/penjualan: `includes/modules/sales/cashier/`
- Packing: `includes/modules/logistics/packing/`
- Resi/pengiriman: `includes/modules/logistics/shipping/`
- Tracking: `includes/modules/logistics/tracking/`
- Seller: `includes/modules/seller/`
- Tagihan/keuangan: `includes/modules/finance/`
- Produk & stok: `includes/modules/inventory/`

## Aturan anti-acak
1. Jangan membuat folder `sales/returns` atau `inventory/warehouse` baru.
2. Retur fisik selalu berada di `warehouse/returns`.
3. Satu proses bisnis tidak boleh punya dua UI canonical.
4. Jangan membuat data transaksi dummy dari UI produksi.
5. Semua angka laporan harus membaca transaksi/ledger nyata melalui Engine/DB PK01.
6. `core/` hanya untuk mesin lintas modul; UI bisnis tetap di `modules/`.

## Production clean
Build ini tidak memuat Test Lab/dummy generator dan tidak memuat dashboard legacy. Fitur pengujian dummy sengaja dikeluarkan dari runtime produksi agar tidak menjadi sumber data palsu atau alur ganda.

Riwayat perubahan lama dipindahkan ke `docs/releases/` dan tidak ikut dijalankan oleh WordPress.

---
## v3.7.8 — Peta Folder Maintenance

Untuk mencari file berdasarkan dashboard, mulai dari:
`docs/architecture/DASHBOARD-FOLDER-MAP.md`

Untuk daftar lengkap ownership setiap modul:
`docs/architecture/MODULE-OWNERSHIP-INDEX.md`

Aturan utama: satu domain memiliki satu folder canonical di `includes/modules/<domain>/`; shared service tetap di `includes/core/`.

## v3.7.9 — Pembayaran Seller Kasir
Kasir memiliki menu Pembayaran Seller yang mencari tagihan berdasarkan Resi/AWB, Invoice/Order, atau Seller terdaftar. Termin pembayaran menjadi master Seller, jatuh tempo invoice mengikuti termin, dan pembayaran dicatat melalui Engine ke invoice serta Buku Kas. Tidak membuat tagihan baru dari resi.
