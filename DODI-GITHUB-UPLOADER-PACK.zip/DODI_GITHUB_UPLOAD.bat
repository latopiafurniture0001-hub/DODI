@echo off
setlocal EnableExtensions

set "REPO=https://github.com/latopiafurniture0001-hub/DODI.git"
set "ZIP=%~dp0DODI-CAM-FINAL-NATIVE-OPERATOR-SIMPLE-PLASMA-READY-SOURCE.zip"
set "WORK=%~dp0DODI-GITHUB-SOURCE"
set "TEMP=%TEMP%\DODI_CAM_UPLOAD_%RANDOM%"

echo ================================================
echo DODI CAM - GitHub Source Uploader
echo ================================================
echo.

if not exist "%ZIP%" (
  echo ERROR: ZIP tidak ditemukan:
  echo %ZIP%
  echo.
  echo Letakkan file ZIP di folder yang sama dengan BAT ini.
  pause
  exit /b 1
)

git --version >nul 2>&1
if errorlevel 1 (
  echo ERROR: Git belum terpasang.
  echo Install Git for Windows terlebih dahulu.
  pause
  exit /b 1
)

if exist "%WORK%\.git" (
  echo Repository lokal sudah ada. Mengambil update GitHub...
  cd /d "%WORK%"
  git pull --rebase
  if errorlevel 1 (
    echo.
    echo Git pull gagal. Periksa login/konflik repository.
    pause
    exit /b 1
  )
) else (
  if exist "%WORK%" rmdir /s /q "%WORK%"
  echo Clone repository DODI...
  git clone "%REPO%" "%WORK%"
  if errorlevel 1 (
    echo.
    echo Clone gagal. GitHub mungkin meminta login.
    echo Login melalui Credential Manager/GitHub Desktop lalu jalankan lagi.
    pause
    exit /b 1
  )
  cd /d "%WORK%"
)

echo.
echo Mengekstrak source DODI CAM...
if exist "%TEMP%" rmdir /s /q "%TEMP%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%TEMP%' -Force"
if errorlevel 1 (
  echo ERROR: Ekstraksi ZIP gagal.
  pause
  exit /b 1
)

if not exist "%TEMP%\FreeCAD-main" (
  echo ERROR: Folder FreeCAD-main tidak ditemukan di dalam ZIP.
  pause
  exit /b 1
)

echo Menyalin source ke repository...
robocopy "%TEMP%\FreeCAD-main" "%WORK%" /E /COPY:DAT /R:2 /W:2 /XD .git build out dist __pycache__ .cache
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo ERROR: Penyalinan source gagal. Robocopy code=%RC%
  pause
  exit /b 1
)

if not exist "%WORK%\.gitignore" (
  >"%WORK%\.gitignore" echo # DODI CAM / FreeCAD build and local artifacts
  >>"%WORK%\.gitignore" echo build/
  >>"%WORK%\.gitignore" echo out/
  >>"%WORK%\.gitignore" echo dist/
  >>"%WORK%\.gitignore" echo __pycache__/
  >>"%WORK%\.gitignore" echo .cache/
  >>"%WORK%\.gitignore" echo *.log
  >>"%WORK%\.gitignore" echo *.tmp
  >>"%WORK%\.gitignore" echo *.bak
)

if not exist "%WORK%\DODI-GITHUB-SOURCE.md" (
  >"%WORK%\DODI-GITHUB-SOURCE.md" echo # DODI CAM Native Operator Source
  >>"%WORK%\DODI-GITHUB-SOURCE.md" echo.
  >>"%WORK%\DODI-GITHUB-SOURCE.md" echo Source package prepared for the DODI repository.
  >>"%WORK%\DODI-GITHUB-SOURCE.md" echo This repository contains the native source tree used as the DODI CAM base.
)

echo.
echo Memeriksa file besar dan status Git...
git status --short

echo.
echo Menambahkan source ke Git...
git add -A
if errorlevel 1 (
  echo ERROR: git add gagal.
  pause
  exit /b 1
)

git diff --cached --quiet
if not errorlevel 1 (
  echo Tidak ada perubahan baru untuk di-commit.
) else (
  git commit -m "Add DODI CAM native operator source"
  if errorlevel 1 (
    echo ERROR: git commit gagal.
    pause
    exit /b 1
  )
)

echo.
echo Mengirim source ke GitHub...
git push origin HEAD
if errorlevel 1 (
  echo.
  echo PUSH GAGAL.
  echo Jika GitHub meminta login, selesaikan login lalu jalankan BAT ini lagi.
  echo Jangan menghapus folder DODI-GITHUB-SOURCE karena isinya sudah siap.
  pause
  exit /b 1
)

rmdir /s /q "%TEMP%" 2>nul

echo.
echo ================================================
echo SELESAI - Source DODI CAM sudah dikirim ke GitHub.
echo Repository: %REPO%
echo ================================================
pause
