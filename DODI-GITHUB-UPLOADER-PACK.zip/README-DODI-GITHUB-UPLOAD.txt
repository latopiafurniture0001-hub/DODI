DODI CAM - UPLOAD KE GITHUB

Repository:
https://github.com/latopiafurniture0001-hub/DODI

Cara:
1. Letakkan file DODI-CAM-FINAL-NATIVE-OPERATOR-SIMPLE-PLASMA-READY-SOURCE.zip di folder yang sama dengan DODI_GITHUB_UPLOAD.bat.
2. Pastikan Git for Windows sudah terpasang.
3. Klik dua kali DODI_GITHUB_UPLOAD.bat.
4. Jika GitHub meminta login, selesaikan login.
5. Script akan clone repository, ekstrak source, menyalin source, commit, lalu push.

Catatan:
- ZIP source sekitar 87 MB dan berisi sekitar 14.000 file.
- Source hasil ekstrak sekitar 415 MB.
- Upload melalui tombol web GitHub tidak cocok untuk paket ini. Script menggunakan Git sehingga file source dikirim satu per satu.
- Jangan menutup jendela saat proses git push berjalan.
